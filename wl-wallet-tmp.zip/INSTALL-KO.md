# 설치 가이드 (Korean Install Guide)

**White-label Mining Wallet (Polaris OEM Edition)**

본 가이드는 `wallet-source/` 소스를 로컬에서 실행하고, 데이터베이스를 구성하며,
관리자 계정을 생성하기까지의 전 과정을 안내합니다.

---

## 1. 사전 요구사항

| 항목 | 버전 | 비고 |
|---|---|---|
| Node.js | **22.12 이상** | `node -v`로 확인 |
| PostgreSQL | 14 이상 권장 | 로컬 또는 클라우드(Railway, RDS 등) |
| npm | Node.js에 포함 | — |

> Windows 사용자는 `npm run dev` 스크립트가 `sh`을 사용하므로 **WSL 또는 Git Bash**에서
> 실행하는 것을 권장합니다.

## 2. 의존성 설치

```bash
cd wallet-source
npm install
```

`postinstall`에서 Prisma 클라이언트가 자동 생성됩니다.

## 3. 환경변수(.env) 구성

```bash
cp .env.example .env
```

`.env`를 열어 최소한 다음 값을 설정하세요.

| 변수 | 설명 | 예시 |
|---|---|---|
| `DATABASE_URL` | PostgreSQL 연결 문자열 | `postgresql://user:password@localhost:5432/whitelabel_wallet` |
| `JWT_SECRET` | JWT 서명 시크릿 | **운영 전 반드시 강한 랜덤 값으로 변경** |
| `SESSION_SECRET` | 세션 시크릿 | 동일하게 변경 |
| `NEXT_PUBLIC_BASE_URL` | 서비스 기본 URL | `http://localhost:3009` |
| `ADMIN_ID` | 관리자 식별자 | 임의 값 |

선택 항목(SMTP 메일, Redis, 마이닝/스테이킹 파라미터, 잭팟, 스케줄러 등)은
`.env.example`의 주석을 참고하세요.

- `APP_MODE=foundation`(기본): 관리자·지갑 중심 모드 (채굴/스테이킹 UI 비활성)
- `APP_MODE=operation` + `ENABLE_REWARD_SCHEDULER=true`: 전체 기능 + 데일리 리워드 스케줄러 활성

## 4. 데이터베이스 생성 및 스키마 반영

DB가 없다면 먼저 생성합니다:

```bash
createdb whitelabel_wallet    # 또는 psql에서 CREATE DATABASE
```

스키마를 반영합니다:

```bash
npx prisma db push
```

(선택) 리더십 보너스 검증용 **데모 시드 데이터**를 넣으려면:

```bash
npx prisma db seed
```

시드 계정: 슈퍼관리자 `admin` / `admin@upcwallet.com` / `admin123`,
테스트 유저 `GrandMaster`·`MiddleBoss`·`Newbie` / `password123`
→ **운영 전 반드시 비밀번호를 변경하세요.**

## 5. 개발 서버 실행

```bash
npm run dev
```

- 웹: http://localhost:3009
- 관리자: http://localhost:3009/u0-admin
- Swagger UI: http://localhost:3009/api-docs
- OpenAPI 스펙: http://localhost:3009/api/docs

## 6. 관리자 계정 생성 (시드 미사용 시)

```bash
npm run create-super-admin    # 대화형: 아이디/이메일/비밀번호 입력
# 또는
npm run setup:admin           # .env의 DATABASE_URL 사용
```

그 외 유틸리티 스크립트:

```bash
npm run init-investment-products   # 투자 상품 티어 초기화
npm run init-game-shares           # 게임 지분 초기화
npm run generate-referral-codes    # 추천 코드 생성
npm run mainnet:start              # 로컬 메인넷 시뮬레이터 (MAINNET_API_URL 연동)
```

## 7. 모바일 빌드 (선택 — Capacitor Android)

```bash
npx cap sync android          # 웹 에셋을 android/ 로 동기화
npm run open:android          # Android Studio에서 열기
```

`capacitor.config.ts`의 `appId`·`appName`·`server.url`을 먼저 your 서비스에 맞게 수정하세요.
자세한 내용은 `CAPACITOR_GUIDE.md`, `APK_BUILD_GUIDE.md`를 참고하세요.

## 8. OEM 신규 프로젝트 생성 (납품용)

```bash
npm run create-oem            # 또는 npx tsx ../tools/create-oem-template.ts
```

상호명·심볼·총 발행량을 입력하면 브랜딩이 교체된 프로젝트 사본이 생성됩니다.
자세한 내용은 `README.md`의 "OEM 생성기 사용법" 또는 생성되는 `OEM_GUIDE.md`를 참고하세요.

## 9. 운영 배포 시 체크리스트

- [ ] `JWT_SECRET`, `SESSION_SECRET`을 랜덤 강한 값으로 교체
- [ ] 데모/시드 계정 비밀번호 변경 또는 계정 삭제
- [ ] `.env`를 절대 저장소에 커밋하지 않기 (`.gitignore`에 이미 포함)
- [ ] `APP_MODE`, `ENABLE_REWARD_SCHEDULER` 값을 운영 정책에 맞게 설정
- [ ] HTTPS 적용 및 `NEXT_PUBLIC_BASE_URL`을 실제 도메인으로 변경
- [ ] 데이터베이스 정기 백업: `npm run backup-db` / `npm run backup-db-local`

문제 발생 시 `docs/TROUBLESHOOTING.md`를 참고하세요.
