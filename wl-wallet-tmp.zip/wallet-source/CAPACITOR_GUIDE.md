# Capacitor 모바일 앱 빌드 가이드

이 프로젝트는 Capacitor가 설정되어 있어 Android 앱으로 빌드할 수 있습니다.

## 사전 요구사항
- Android Studio 설치 필요
- Java (JDK) 설치 필요

## 설정 확인
`capacitor.config.ts` 파일을 열어 `server.url` 설정을 확인하세요.

### 1. 로컬 개발 (Android Emulator)
로컬에서 개발 중인 서버를 앱에서 띄우려면:
1. PC에서 `npm run dev`로 서버 실행 (보통 3000번 포트)
2. `capacitor.config.ts`에서 다음 주석 해제:
   ```typescript
   url: 'http://10.0.2.2:3000',
   cleartext: true
   ```
   (*10.0.2.2는 Android Emulator에서 PC의 localhost를 가리키는 주소입니다*)
3. `npx cap copy` 실행
4. `npm run open:android` 실행 후 Android Studio에서 앱 실행

### 2. 프로덕션 빌드 (배포용)
실제 배포된 웹사이트를 앱으로 만들려면:
1. `capacitor.config.ts`에서 `url`을 실제 배포된 도메인으로 변경:
   ```typescript
   url: 'https://your-domain.com',
   // cleartext: true  <-- 제거 또는 주석 처리 (https는 불필요)
   ```
2. `npx cap copy` 실행
3. `npm run open:android` 실행
4. Android Studio 메뉴에서 `Build > Generate Signed Bundle / APK` 선택하여 APK 생성

## 주요 명령어
- **Android 프로젝트 열기**: `npm run open:android`
- **설정/리소스 동기화**: `npx cap sync` (설정이나 아이콘 변경 시 실행)
