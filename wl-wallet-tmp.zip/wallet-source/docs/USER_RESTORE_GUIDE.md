# 사용자 데이터 복구 가이드

## 🚨 현재 상황

데이터베이스가 리셋되어 기존에 관리자에서 생성했던 회원 데이터가 모두 삭제되었습니다.

## 📋 복구 방법

### 방법 1: 백업 파일이 있는 경우

1. **백업 파일 준비**
   - 백업 파일을 `backup/users-backup.json` 경로에 저장하세요.
   - 또는 `scripts/restore-users-from-backup.ts` 파일에서 경로를 수정하세요.

2. **복구 실행**
   ```bash
   npx tsx scripts/restore-users-from-backup.ts
   ```

### 방법 2: 백업 파일이 없는 경우

#### 옵션 A: 수동으로 재생성

관리자 페이지(`/a0-admin/users`)에서 기존 회원들을 다시 생성하세요.

#### 옵션 B: 스크립트로 일괄 생성

백업 파일을 직접 생성하여 복구할 수 있습니다:

1. **백업 파일 생성** (`backup/users-backup.json`)
   ```json
   [
     {
       "username": "회원1",
       "email": "user1@example.com",
       "password": "password123",
       "referrerUsername": "aoadmin",
       "rank": 1,
       "totalInvestment": 100,
       "personalCoin": 1000,
       "role": "USER",
       "status": "ACTIVE"
     },
     {
       "username": "회원2",
       "email": "user2@example.com",
       "password": "password123",
       "referrerUsername": "회원1",
       "rank": 1,
       "totalInvestment": 200,
       "personalCoin": 2000,
       "role": "USER",
       "status": "ACTIVE"
     }
   ]
   ```

2. **복구 실행**
   ```bash
   npx tsx scripts/restore-users-from-backup.ts
   ```

## 📝 백업 파일 형식

백업 파일은 다음 필드를 포함할 수 있습니다:

### 필수 필드
- `username` 또는 `email`: 둘 중 하나는 반드시 필요

### 선택 필드
- `password`: 비밀번호 (평문 또는 해시된 비밀번호)
- `walletAddress`: 지갑 주소
- `referralCode`: 추천인 코드
- `referrerUsername`: 추천인 사용자명 (이미 존재하는 사용자)
- `sponsorUsername`: 후원인 사용자명 (이미 존재하는 사용자)
- `rank`: 랭크 (기본값: 1)
- `totalInvestment`: 총 투자 금액 (기본값: 0)
- `personalCoin`: 보유 코인 (기본값: 0)
- `role`: 역할 - `USER`, `ADMIN`, `SUPER_ADMIN` (기본값: `USER`)
- `status`: 상태 - `ACTIVE`, `INACTIVE`, `SUSPENDED` (기본값: `ACTIVE`)
- `isActive`: 활성 여부 (기본값: `true`)

## ⚠️ 주의사항

1. **추천인/후원인 관계**
   - `referrerUsername`과 `sponsorUsername`은 **이미 데이터베이스에 존재하는 사용자명**이어야 합니다.
   - 복구 순서: 추천인 → 추천받은 사용자 순서로 정렬하세요.

2. **비밀번호**
   - 평문 비밀번호는 자동으로 해시됩니다.
   - 해시된 비밀번호(`$2a$...`)는 그대로 사용할 수 있습니다.

3. **중복 방지**
   - 이미 존재하는 사용자명 또는 이메일은 건너뜁니다.

4. **데이터 손실 방지**
   - 복구 전에 현재 데이터베이스를 백업하세요.
   - 프로덕션 환경에서는 특히 주의하세요.

## 🔄 향후 백업 방법

앞으로는 정기적으로 백업을 수행하세요:

```bash
# 사용자 데이터 내보내기
npx tsx scripts/export-users.ts
```

백업 파일은 `backup/users-backup-YYYYMMDD-HHMMSS.json` 형식으로 저장됩니다.

## 📊 복구 후 확인

복구 후 다음을 확인하세요:

1. **사용자 목록 확인**
   - 관리자 페이지(`/a0-admin/users`)에서 사용자 목록 확인

2. **추천인 관계 확인**
   - 각 사용자의 상세 페이지에서 추천인/후원인 관계 확인

3. **로그인 테스트**
   - 복구된 사용자 계정으로 로그인 테스트

## 🆘 문제 해결

### 백업 파일을 찾을 수 없음

`scripts/restore-users-from-backup.ts` 파일에서 경로를 수정하세요:

```typescript
const backupFilePath = path.join(process.cwd(), 'backup', 'your-backup-file.json');
```

### 추천인 관계가 설정되지 않음

1. 추천인 사용자가 먼저 복구되어야 합니다.
2. 백업 파일에서 사용자를 순서대로 정렬하세요.

### 비밀번호가 작동하지 않음

- 평문 비밀번호를 사용하는 경우, 스크립트가 자동으로 해시합니다.
- 해시된 비밀번호를 사용하는 경우, 그대로 사용할 수 있습니다.

