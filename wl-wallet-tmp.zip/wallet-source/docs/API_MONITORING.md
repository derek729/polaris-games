# API 성능 모니터링 가이드

## 개요
API 성능 모니터링 시스템을 구현하여 응답 시간, 에러율, 사용량 통계를 추적합니다.

## 주요 기능

### 1. 메트릭 수집
- **응답 시간**: 각 API 요청의 응답 시간 추적
- **요청 수**: 엔드포인트별 요청 횟수
- **에러율**: 에러 발생 비율 계산
- **최소/최대 응답 시간**: 성능 범위 파악

### 2. 에러 로그
- 에러 발생 시 자동 로깅
- 에러 메시지, 상태 코드, 타임스탬프 기록
- 사용자 ID 및 IP 주소 추적
- 최대 1000개의 최신 에러 로그 유지

### 3. 통계 요약
- 전체 요청 수 및 에러 수
- 평균 응답 시간
- 전체 에러율
- 상위 엔드포인트 (요청 수 기준)
- 상위 에러 (발생 빈도 기준)

## 사용 방법

### API Route에 모니터링 적용

#### 방법 1: monitorApi 래퍼 사용
```typescript
import { monitorApi, getClientIp } from '@/lib/monitoring';

export async function POST(request: Request) {
  const endpoint = '/api/user/invest';
  const method = 'POST';
  const ip = getClientIp(request);

  return monitorApi(endpoint, method, async () => {
    // API 로직
    const result = await processInvestment();
    return successResponse(result);
  }, userId, ip);
}
```

#### 방법 2: 수동 모니터링
```typescript
import { getMetrics, recordRequest, recordError } from '@/lib/monitoring';

export async function POST(request: Request) {
  const startTime = Date.now();
  const endpoint = '/api/user/invest';
  const method = 'POST';

  try {
    const result = await processInvestment();
    const responseTime = Date.now() - startTime;
    recordRequest(endpoint, method, responseTime, false, 200);
    return successResponse(result);
  } catch (error) {
    const responseTime = Date.now() - startTime;
    recordError(endpoint, method, error.message, 500);
    recordRequest(endpoint, method, responseTime, true, 500);
    throw error;
  }
}
```

## 관리자 API

### 메트릭 조회
**GET** `/api/admin/monitoring/metrics`

#### 쿼리 파라미터
- `type`: 조회 타입 (`summary`, `detailed`, `errors`, `endpoint`)
- `endpoint`: 특정 엔드포인트 필터링 (선택)
- `limit`: 에러 로그 조회 시 제한 수 (기본: 100)

#### 응답 예시

##### Summary (요약)
```json
{
  "ok": true,
  "data": {
    "totalRequests": 1000,
    "totalErrors": 50,
    "averageResponseTime": 150,
    "errorRate": 5.0,
    "topEndpoints": [
      { "endpoint": "/api/dashboard", "count": 500 },
      { "endpoint": "/api/user/invest", "count": 300 }
    ],
    "topErrors": [
      { "error": "500:Internal Server Error", "count": 30 },
      { "error": "400:Validation Error", "count": 20 }
    ]
  }
}
```

##### Detailed (상세)
```json
{
  "ok": true,
  "data": {
    "metrics": [
      {
        "endpoint": "/api/dashboard",
        "method": "GET",
        "count": 500,
        "averageResponseTime": 120,
        "minResponseTime": 50,
        "maxResponseTime": 500,
        "errorCount": 10,
        "errorRate": 2.0,
        "lastRequestTime": "2024-01-01T12:00:00Z",
        "lastErrorTime": "2024-01-01T11:30:00Z"
      }
    ],
    "totalEndpoints": 10
  }
}
```

##### Errors (에러 로그)
```json
{
  "ok": true,
  "data": {
    "errors": [
      {
        "endpoint": "/api/user/invest",
        "method": "POST",
        "error": "Insufficient balance",
        "statusCode": 400,
        "timestamp": "2024-01-01T12:00:00Z",
        "userId": "user123",
        "ip": "192.168.1.1"
      }
    ],
    "total": 50
  }
}
```

##### Endpoint (특정 엔드포인트)
```json
{
  "ok": true,
  "data": {
    "endpoint": "/api/dashboard",
    "count": 500,
    "averageResponseTime": 120,
    "minResponseTime": 50,
    "maxResponseTime": 500,
    "errorCount": 10,
    "errorRate": 2.0,
    "lastRequestTime": "2024-01-01T12:00:00Z",
    "lastErrorTime": "2024-01-01T11:30:00Z"
  }
}
```

## 메트릭 데이터 구조

### ApiMetrics
```typescript
interface ApiMetrics {
  endpoint: string;        // 엔드포인트 경로
  method: string;          // HTTP 메서드
  count: number;           // 총 요청 수
  totalResponseTime: number; // 총 응답 시간 (ms)
  minResponseTime: number;   // 최소 응답 시간 (ms)
  maxResponseTime: number;   // 최대 응답 시간 (ms)
  errorCount: number;        // 에러 발생 수
  lastRequestTime: Date;     // 마지막 요청 시간
  lastErrorTime?: Date;       // 마지막 에러 시간
}
```

### ErrorLog
```typescript
interface ErrorLog {
  endpoint: string;        // 엔드포인트 경로
  method: string;          // HTTP 메서드
  error: string;           // 에러 메시지
  statusCode: number;      // HTTP 상태 코드
  timestamp: Date;         // 발생 시간
  userId?: string;         // 사용자 ID (선택)
  ip?: string;             // IP 주소 (선택)
}
```

## 자동 정리

- **에러 로그**: 24시간 이상 된 로그 자동 삭제
- **메트릭**: 24시간 이상 요청이 없는 메트릭 자동 삭제
- **정리 주기**: 1시간마다 자동 실행

## 프로덕션 환경 권장사항

### Redis/시계열 DB 통합
메모리 기반 저장소는 서버 재시작 시 데이터가 초기화되고, 여러 서버 인스턴스 간 공유가 불가능합니다. 프로덕션 환경에서는 다음을 권장합니다:

1. **Redis**: 실시간 메트릭 저장
2. **시계열 DB** (InfluxDB, TimescaleDB): 장기 메트릭 저장 및 분석
3. **분산 추적** (Jaeger, Zipkin): 마이크로서비스 환경에서의 요청 추적

### 모니터링 대시보드
- Grafana를 사용한 시각화
- 실시간 알림 설정
- 성능 트렌드 분석

### 알림 설정
- 에러율 임계값 초과 시 알림
- 응답 시간 임계값 초과 시 알림
- 특정 에러 패턴 감지 시 알림

## 성능 고려사항

1. **비동기 처리**: 메트릭 기록은 비동기로 처리
2. **배치 처리**: 여러 요청을 배치로 기록
3. **샘플링**: 높은 트래픽 시 샘플링 적용
4. **메모리 관리**: 오래된 데이터 자동 정리

## 다음 단계

1. **실시간 대시보드**: WebSocket을 통한 실시간 메트릭 업데이트
2. **알림 시스템**: 임계값 초과 시 이메일/Slack 알림
3. **성능 분석**: 느린 쿼리 및 병목 지점 자동 감지
4. **사용자 행동 분석**: 사용자별 API 사용 패턴 분석

