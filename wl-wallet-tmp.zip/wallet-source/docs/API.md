# API 문서

## 개요

모든 API는 JSON 형식으로 요청/응답하며, 성공 시 `ok: true`, 실패 시 `ok: false`를 반환합니다.

## 공통 응답 형식

### 성공 응답
```json
{
  "ok": true,
  "data": { ... },
  "message": "성공 메시지 (선택사항)"
}
```

### 에러 응답
```json
{
  "ok": false,
  "error": "에러 메시지",
  "code": "에러 코드 (선택사항)",
  "details": "상세 정보 (개발 환경에서만)"
}
```

## 인증

대부분의 API는 인증이 필요합니다. 인증은 쿠키 기반 세션을 사용합니다.

### 로그인 후 쿠키 설정
로그인 성공 시 `userId` 쿠키가 설정되며, 이후 요청에서 자동으로 전송됩니다.

---

## 인증 API

### POST /api/auth/login

로그인

**요청 본문:**
```json
{
  "username": "string",
  "password": "string"
}
```

**성공 응답 (200):**
```json
{
  "ok": true,
  "message": "로그인 성공",
  "data": {
    "id": "string",
    "username": "string",
    "email": "string"
  }
}
```

**에러 응답:**
- `400`: 필수 필드 누락
- `401`: 인증 실패
- `403`: 비활성화된 계정

---

### POST /api/auth/register

회원가입

**요청 본문:**
```json
{
  "username": "string",
  "email": "string",
  "password": "string",
  "referrerCode": "string (선택사항)"
}
```

**성공 응답 (200):**
```json
{
  "ok": true,
  "message": "회원가입이 완료되었습니다.",
  "data": {
    "id": "string",
    "username": "string",
    "email": "string"
  }
}
```

---

### POST /api/auth/logout

로그아웃

**성공 응답 (200):**
```json
{
  "ok": true,
  "message": "로그아웃되었습니다."
}
```

---

### GET /api/auth/session

현재 세션 확인

**성공 응답 (200):**
```json
{
  "ok": true,
  "user": {
    "id": "string",
    "username": "string",
    "email": "string",
    "role": "USER" | "ADMIN" | "SUPER_ADMIN",
    "rank": 1-5
  }
}
```

---

## 사용자 API

### GET /api/dashboard

대시보드 데이터 조회

**성공 응답 (200):**
```json
{
  "ok": true,
  "data": {
    "user": {
      "id": "string",
      "username": "string",
      "email": "string",
      "rank": 1,
      "totalInvestment": 1000,
      "personalCoin": 5000,
      "createdAt": "2024-01-01T00:00:00Z",
      "_count": {
        "referredUsers": 10,
        "investments": 3
      }
    },
    "stats": {
      "totalInvestment": 1000,
      "activeInvestments": 2,
      "todayEarnings": 10,
      "monthlyEarnings": 300,
      "totalEarnings": 5000,
      "expectedDailyEarnings": 10,
      "availableBalance": 5000
    },
    "recentActivities": {
      "investments": [...],
      "rewards": [...]
    },
    "orgTree": {
      "name": "사용자명",
      "attributes": {
        "Rank": "1성",
        "투자": "$1000"
      },
      "children": [...]
    }
  }
}
```

---

### POST /api/user/invest

투자 신청

**요청 본문:**
```json
{
  "userId": "string",
  "amount": 1000
}
```

**성공 응답 (200):**
```json
{
  "ok": true,
  "message": "1등급 투자가 완료되었습니다. (일이율: 0.3%)",
  "data": {
    "investmentId": "string",
    "amount": 1000,
    "dailyRate": 0.003,
    "matchingDepth": 4,
    "investmentTier": 1,
    "startDate": "2024-01-01T00:00:00Z",
    "endDate": "2024-07-01T00:00:00Z",
    "isActive": true,
    "remainingBalance": 4000
  }
}
```

**에러 응답:**
- `400`: 잔액 부족, 최소 투자 금액 미달
- `404`: 사용자를 찾을 수 없음

---

### GET /api/user/invest

투자 내역 조회

**쿼리 파라미터:**
- `userId` (필수): 사용자 ID

**성공 응답 (200):**
```json
{
  "ok": true,
  "data": [
    {
      "id": "string",
      "amount": 1000,
      "dailyRate": 0.003,
      "matchingDepth": 4,
      "investmentTier": 1,
      "startDate": "2024-01-01T00:00:00Z",
      "endDate": "2024-07-01T00:00:00Z",
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00Z",
      "dailyProfit": 3
    }
  ]
}
```

---

### POST /api/user/transfer

코인 이체

**요청 본문:**
```json
{
  "receiverEmail": "string",
  "amount": 100,
  "password": "string"
}
```

**성공 응답 (200):**
```json
{
  "ok": true,
  "message": "이체가 완료되었습니다.",
  "data": {
    "transferId": "string",
    "amount": 100,
    "fee": 0,
    "transferredAt": "2024-01-01T00:00:00Z"
  }
}
```

---

### POST /api/user/withdraw

출금 신청

**요청 본문:**
```json
{
  "amount": 1000,
  "address": "string"
}
```

**성공 응답 (200):**
```json
{
  "ok": true,
  "message": "출금 신청이 완료되었습니다.",
  "data": {
    "id": "string",
    "amount": 1000,
    "address": "string",
    "status": "PENDING",
    "requestedAt": "2024-01-01T00:00:00Z"
  }
}
```

---

## 관리자 API

모든 관리자 API는 관리자 권한이 필요합니다.

### GET /api/admin/dashboard

관리자 대시보드 데이터

**성공 응답 (200):**
```json
{
  "ok": true,
  "data": {
    "overview": {
      "totalUsers": 1000,
      "totalInvestment": 1000000,
      "pendingWithdrawals": 50000,
      "totalRewards": 200000
    },
    "rankDistribution": [...],
    "withdrawalStatus": {...},
    "recentActivities": {...},
    "topInvestors": [...]
  }
}
```

---

### GET /api/admin/users

사용자 목록 조회

**쿼리 파라미터:**
- `page` (선택): 페이지 번호 (기본값: 1)
- `limit` (선택): 페이지당 항목 수 (기본값: 20)
- `search` (선택): 검색어 (사용자명, 이메일)

**성공 응답 (200):**
```json
{
  "ok": true,
  "data": {
    "users": [...],
    "pagination": {
      "total": 1000,
      "page": 1,
      "limit": 20,
      "totalPages": 50
    }
  }
}
```

---

### GET /api/admin/reward-settings

보상 설정 조회

**성공 응답 (200):**
```json
{
  "ok": true,
  "data": {
    "referralBonus": {
      "rate": 0.1,
      "description": "직접 추천 시 지급되는 보너스 비율"
    },
    "matchingBonus": {
      "generation1": 0.12,
      "generation2to4": 0.08,
      "generation5to8": 0.05,
      "generation9to12": 0.03
    },
    "leadershipBonus": {
      "rank1": 0.04,
      "rank2": 0.08,
      "rank3": 0.12,
      "rank4": 0.16,
      "rank5": 0.20
    }
  }
}
```

---

### PUT /api/admin/reward-settings

보상 설정 수정

**요청 본문:**
```json
{
  "referralBonus": {
    "rate": 0.1
  },
  "matchingBonus": {
    "generation1": 0.12,
    "generation2to4": 0.08,
    "generation5to8": 0.05,
    "generation9to12": 0.03
  },
  "leadershipBonus": {
    "rank1": 0.04,
    "rank2": 0.08,
    "rank3": 0.12,
    "rank4": 0.16,
    "rank5": 0.20
  }
}
```

---

### POST /api/admin/start-scheduler

스케줄러 수동 시작

**성공 응답 (200):**
```json
{
  "ok": true,
  "message": "스케줄러가 시작되었습니다."
}
```

---

### POST /api/admin/run-daily

일일 리워드 수동 실행

**성공 응답 (200):**
```json
{
  "ok": true,
  "message": "일일 리워드 처리가 완료되었습니다.",
  "data": {
    "processedCount": 100,
    "errorCount": 0,
    "totalInvestments": 100
  }
}
```

---

## 에러 코드

| 코드 | 설명 |
|------|------|
| `UNAUTHORIZED` | 인증 필요 |
| `FORBIDDEN` | 권한 없음 |
| `VALIDATION_ERROR` | 입력 검증 실패 |
| `NOT_FOUND` | 리소스를 찾을 수 없음 |
| `DUPLICATE_ENTRY` | 중복된 데이터 |
| `DATABASE_ERROR` | 데이터베이스 오류 |
| `SERVER_ERROR` | 서버 오류 |

---

## 상태 코드

| 코드 | 설명 |
|------|------|
| `200` | 성공 |
| `400` | 잘못된 요청 |
| `401` | 인증 필요 |
| `403` | 권한 없음 |
| `404` | 리소스를 찾을 수 없음 |
| `409` | 충돌 (중복 등) |
| `500` | 서버 오류 |

---

## 참고사항

- 모든 금액은 AO 코인 단위입니다.
- 날짜는 ISO 8601 형식입니다.
- 관리자 API는 `ADMIN` 또는 `SUPER_ADMIN` 권한이 필요합니다.
- 일부 API는 `SUPER_ADMIN` 권한만 필요합니다 (예: 사용자 생성).

