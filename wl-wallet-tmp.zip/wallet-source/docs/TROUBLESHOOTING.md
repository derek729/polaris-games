# 문제 해결 가이드

## 🔴 404 에러 해결

### 문제: `GET http://localhost:3009/ 404 (Not Found)`

#### 원인
- Next.js 서버 사이드 리다이렉트가 제대로 작동하지 않음
- 데이터베이스 연결 문제로 인한 에러
- 서버가 완전히 시작되지 않음

#### 해결 방법

1. **페이지를 클라이언트 컴포넌트로 변경**
   - `src/app/page.tsx`를 클라이언트 컴포넌트로 수정 완료
   - `useRouter`를 사용한 클라이언트 사이드 리다이렉트

2. **서버 재시작**
   ```bash
   # 서버 중지 후 재시작
   npm run dev
   ```

3. **직접 로그인 페이지 접근**
   ```
   http://localhost:3009/login
   ```

## 🔧 일반적인 문제 해결

### 1. 데이터베이스 연결 오류

#### 증상
- API 요청 시 500 에러
- 콘솔에 Prisma 연결 오류

#### 해결
1. `.env` 파일 확인
   ```env
   DATABASE_URL="postgresql://user:password@localhost:5432/dbname?schema=public"
   ```

2. PostgreSQL 서버 실행 확인
   ```bash
   # Windows
   Get-Service -Name postgresql*
   
   # 또는
   netstat -ano | findstr :5432
   ```

3. Prisma 마이그레이션 실행
   ```bash
   npx prisma db push
   # 또는
   npx prisma migrate dev
   ```

### 2. 포트 충돌

#### 증상
- `Error: listen EADDRINUSE: address already in use :::3009`

#### 해결
```bash
# 포트 사용 중인 프로세스 확인
netstat -ano | findstr :3009

# 프로세스 종료 (PID 확인 후)
taskkill /PID <PID> /F

# 또는 다른 포트 사용
npm run dev -- -p 3010
```

### 3. 모듈을 찾을 수 없음

#### 증상
- `Module not found: Can't resolve '@/lib/...'`

#### 해결
1. TypeScript 경로 별칭 확인 (`tsconfig.json`)
2. 서버 재시작
3. `node_modules` 재설치
   ```bash
   rm -rf node_modules
   npm install
   ```

### 4. 빌드 오류

#### 증상
- 컴파일 에러
- 타입 에러

#### 해결
1. 타입 에러 확인
   ```bash
   npm run build
   ```

2. ESLint 확인
   ```bash
   npm run lint
   ```

3. Prisma 클라이언트 재생성
   ```bash
   npx prisma generate
   ```

### 5. 쿠키 문제

#### 증상
- 로그인 후 세션이 유지되지 않음
- 자동 로그아웃

#### 해결
1. 브라우저 쿠키 확인
   - 개발자 도구 > Application > Cookies
   - `userId` 쿠키 존재 확인

2. 쿠키 설정 확인
   - `httpOnly: true`
   - `secure: false` (개발 환경)
   - `sameSite: 'lax'`

### 6. Rate Limiting 문제

#### 증상
- `429 Too Many Requests` 에러

#### 해결
1. Rate Limit 설정 확인
   - `src/lib/rate-limit.ts`에서 설정 확인

2. 메모리 스토어 초기화
   - 서버 재시작으로 초기화됨

3. Rate Limit 헤더 확인
   - `X-RateLimit-Remaining`
   - `Retry-After`

## 📊 서버 상태 확인

### 1. 서버 실행 확인
```bash
# 포트 확인
netstat -ano | findstr :3009

# Node 프로세스 확인
Get-Process -Name node | Select-Object Id, ProcessName, StartTime
```

### 2. 로그 확인
- 콘솔 출력 확인
- 에러 메시지 확인
- 스케줄러 시작 메시지 확인

### 3. API 테스트
```bash
# 세션 확인
curl http://localhost:3009/api/auth/session

# 로그인 테스트
curl -X POST http://localhost:3009/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"test","password":"test"}'
```

## 🔍 디버깅 팁

### 1. 콘솔 로그 확인
- 서버 콘솔에서 에러 메시지 확인
- 브라우저 콘솔에서 클라이언트 에러 확인

### 2. 네트워크 탭 확인
- 개발자 도구 > Network 탭
- 요청/응답 확인
- 상태 코드 확인

### 3. Prisma Studio 사용
```bash
npx prisma studio
```
- 데이터베이스 데이터 직접 확인
- http://localhost:5555 접속

### 4. 환경 변수 확인
```bash
# Windows PowerShell
Get-Content .env

# 또는
$env:DATABASE_URL
```

## 🚀 빠른 복구 방법

### 서버 완전 재시작
```bash
# 1. 서버 중지 (Ctrl+C)

# 2. 포트 사용 중인 프로세스 종료
netstat -ano | findstr :3009
taskkill /PID <PID> /F

# 3. node_modules 재설치 (필요시)
rm -rf node_modules
npm install

# 4. Prisma 클라이언트 재생성
npx prisma generate

# 5. 서버 재시작
npm run dev
```

## 📝 체크리스트

서버 실행 전 확인:
- [ ] `.env` 파일 존재 및 설정 확인
- [ ] PostgreSQL 서버 실행 중
- [ ] `DATABASE_URL` 올바르게 설정
- [ ] 포트 3009 사용 가능
- [ ] `node_modules` 설치 완료
- [ ] Prisma 마이그레이션 완료

서버 실행 후 확인:
- [ ] 서버가 포트 3009에서 실행 중
- [ ] 콘솔에 "Ready" 메시지 표시
- [ ] 스케줄러 시작 메시지 확인
- [ ] http://localhost:3009 접근 가능
- [ ] 로그인 페이지 표시

## 💡 추가 도움말

문제가 계속되면:
1. 서버 콘솔 로그 전체 확인
2. 브라우저 콘솔 에러 확인
3. 네트워크 탭에서 실패한 요청 확인
4. 데이터베이스 연결 상태 확인

