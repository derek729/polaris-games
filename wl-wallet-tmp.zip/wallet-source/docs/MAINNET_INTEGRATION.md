# 메인넷 연동 가이드

## 개요

AO 코인 메인넷과의 연동을 위해 P2P 거래 이력에 메인넷 정보를 저장할 수 있도록 시스템이 설계되었습니다.

## 데이터베이스 스키마

### Transfer 모델 확장

P2P 거래 이력(`Transfer` 모델)에 메인넷 연동을 위한 필드들이 추가되었습니다:

```prisma
model Transfer {
  // 기본 필드
  id          String   @id @default(cuid())
  senderId    String
  receiverId  String
  amount      Decimal  @db.Decimal(18, 8)
  fee         Decimal  @db.Decimal(18, 8) @default(0)
  
  // 메인넷 연동 필드
  networkType String   @default("OFF_CHAIN") // OFF_CHAIN, MAINNET, TESTNET
  txHash      String?  @unique // 트랜잭션 해시 (TXID)
  blockNumber Int?     // 블록 번호
  confirmations Int?   @default(0) // 컨펌 수
  mainnetStatus String? // PENDING, CONFIRMED, FAILED
  senderMainnetAddress String? // 보내는 사람의 메인넷 주소
  receiverMainnetAddress String? // 받는 사람의 메인넷 주소
  gasFee      Decimal? @db.Decimal(18, 8) // 가스 수수료
  
  // 메타데이터
  description String?  // 거래 설명/메모
  metadata    Json?    // 추가 메타데이터 (JSON 형식)
  
  transferredAt DateTime @default(now())
  mainnetSyncedAt DateTime? // 메인넷 동기화 시간
  
  @@index([txHash])
  @@index([senderId, transferredAt])
  @@index([receiverId, transferredAt])
  @@index([mainnetStatus])
}
```

## API 엔드포인트

### 1. P2P 거래 생성 (기존)

**POST** `/api/user/transfer`

기존과 동일하게 작동하지만, 자동으로 다음 정보가 저장됩니다:
- `networkType: "OFF_CHAIN"` (현재는 오프체인 거래)
- `description`: 자동 생성된 거래 설명
- `metadata`: 플랫폼 정보

### 2. 메인넷 동기화

**POST** `/api/user/transfer/sync-mainnet`

메인넷에서 거래가 완료되면 이 API를 호출하여 Transfer 레코드를 업데이트합니다.

**요청 본문:**
```json
{
  "transferId": "clx123...",
  "txHash": "0xabc123...",
  "blockNumber": 12345,
  "confirmations": 12,
  "mainnetStatus": "CONFIRMED",
  "gasFee": "0.001"
}
```

**응답:**
```json
{
  "ok": true,
  "message": "메인넷 동기화가 완료되었습니다.",
  "data": {
    "id": "clx123...",
    "txHash": "0xabc123...",
    "blockNumber": 12345,
    "confirmations": 12,
    "mainnetStatus": "CONFIRMED",
    "mainnetSyncedAt": "2025-01-20T10:30:00Z"
  }
}
```

**권한:** 관리자만 호출 가능

### 3. 메인넷 동기화 상태 조회

**GET** `/api/user/transfer/sync-mainnet?transferId=clx123...`

특정 거래의 메인넷 동기화 상태를 조회합니다.

**응답:**
```json
{
  "ok": true,
  "data": {
    "id": "clx123...",
    "networkType": "MAINNET",
    "txHash": "0xabc123...",
    "blockNumber": 12345,
    "confirmations": 12,
    "mainnetStatus": "CONFIRMED",
    "mainnetSyncedAt": "2025-01-20T10:30:00Z"
  }
}
```

## 거래 내역 조회

### 거래 내역 API

**GET** `/api/user/transactions`

거래 내역 조회 시 P2P 거래에 대해 다음 정보가 포함됩니다:
- `txHash`: 트랜잭션 해시 (있는 경우)
- `networkType`: 네트워크 타입 (OFF_CHAIN, MAINNET, TESTNET)
- `relatedInfo`: TXID가 있으면 표시, 없으면 내부 거래 ID 표시

**예시 응답:**
```json
{
  "ok": true,
  "data": {
    "transactions": [
      {
        "id": "clx123...",
        "type": "transfer_sent",
        "typeLabel": "이체",
        "amount": 100.5,
        "description": "user@example.com에게 이체",
        "relatedInfo": "TXID: 0xabc123...def456 | 회원: user@example.com",
        "txHash": "0xabc123...",
        "networkType": "MAINNET",
        "createdAt": "2025-01-20T10:30:00Z"
      }
    ]
  }
}
```

## 메인넷 연동 워크플로우

### 1. 오프체인 거래 (현재)

1. 사용자가 P2P 이체를 요청
2. 시스템이 즉시 처리하고 `Transfer` 레코드 생성
3. `networkType: "OFF_CHAIN"`으로 저장

### 2. 메인넷 연동 시 (향후)

1. 사용자가 P2P 이체를 요청
2. 시스템이 오프체인으로 즉시 처리하고 `Transfer` 레코드 생성
3. 백그라운드에서 메인넷에 거래 전송
4. 메인넷에서 거래 완료 후 `/api/user/transfer/sync-mainnet` 호출
5. `Transfer` 레코드가 메인넷 정보로 업데이트됨

### 3. 메인넷 직접 거래 (향후)

1. 사용자가 메인넷을 통한 직접 거래 요청
2. 메인넷에서 거래 생성
3. 거래 완료 후 `/api/user/transfer/sync-mainnet` 호출하여 `Transfer` 레코드 생성

## 인덱스 최적화

다음 필드에 인덱스가 생성되어 빠른 조회가 가능합니다:
- `txHash`: 트랜잭션 해시로 조회
- `senderId + transferredAt`: 보낸 사람별 조회
- `receiverId + transferredAt`: 받은 사람별 조회
- `mainnetStatus`: 메인넷 상태별 조회

## 주의사항

1. **데이터 무결성**: `txHash`는 고유값이므로 중복 저장 방지
2. **트랜잭션 안전성**: 메인넷 동기화는 별도 트랜잭션으로 처리
3. **권한 관리**: 메인넷 동기화 API는 관리자만 호출 가능
4. **에러 처리**: 메인넷 동기화 실패 시에도 오프체인 거래는 유지됨

## 향후 확장 계획

1. **자동 동기화**: 메인넷 이벤트 리스너를 통한 자동 동기화
2. **상태 모니터링**: 메인넷 거래 상태 실시간 모니터링
3. **재시도 메커니즘**: 메인넷 동기화 실패 시 자동 재시도
4. **배치 처리**: 여러 거래를 한 번에 동기화

