# Rate Limiting 가이드

## 개요
API 호출 빈도를 제한하여 서버 보호 및 남용 방지를 위한 Rate Limiting 시스템을 구현했습니다.

## 구현 방식

### 메모리 기반 저장소
- 현재는 메모리 기반 저장소를 사용합니다 (개발/소규모 프로덕션용)
- 프로덕션 환경에서는 Redis 사용을 권장합니다
- 자동으로 만료된 항목을 정리합니다 (1분마다)

### Rate Limit 설정

#### 1. 일반 API (IP 기반)
```typescript
{
  windowMs: 15 * 60 * 1000, // 15분
  maxRequests: 100, // 최대 100회
}
```

#### 2. 인증 API (IP 기반, 더 엄격)
```typescript
{
  windowMs: 15 * 60 * 1000, // 15분
  maxRequests: 10, // 최대 10회
  skipSuccessfulRequests: true, // 성공한 로그인은 카운트하지 않음
}
```

#### 3. 투자 API (사용자 기반)
```typescript
{
  windowMs: 60 * 60 * 1000, // 1시간
  maxRequests: 20, // 최대 20회
}
```

#### 4. 출금 API (사용자 기반, 매우 엄격)
```typescript
{
  windowMs: 24 * 60 * 60 * 1000, // 24시간
  maxRequests: 5, // 최대 5회
}
```

#### 5. 관리자 API (IP 기반)
```typescript
{
  windowMs: 15 * 60 * 1000, // 15분
  maxRequests: 200, // 최대 200회
}
```

#### 6. 대시보드 API (사용자 기반)
```typescript
{
  windowMs: 1 * 60 * 1000, // 1분
  maxRequests: 30, // 최대 30회
}
```

## 적용된 API

### 사용자 API
- ✅ `/api/auth/login` - 로그인 (IP 기반, 15분에 10회)
- ✅ `/api/user/invest` - 투자 신청 (사용자 기반, 1시간에 20회)
- ✅ `/api/user/withdraw` - 출금 신청 (사용자 기반, 24시간에 5회)
- ✅ `/api/dashboard` - 대시보드 조회 (사용자 기반, 1분에 30회)

## 사용 방법

### IP 기반 Rate Limiting
```typescript
import { checkRateLimit, rateLimitConfigs } from '@/lib/rate-limit';

export async function POST(request: Request) {
  // Rate Limiting 체크
  const rateLimitResult = await checkRateLimit(request, rateLimitConfigs.auth);
  if (!rateLimitResult.success) {
    return rateLimitResult.response;
  }

  // API 로직 실행
  // ...
}
```

### 사용자 기반 Rate Limiting
```typescript
import { checkUserRateLimit, rateLimitConfigs } from '@/lib/rate-limit';

export async function POST(request: Request) {
  const { userId } = await request.json();

  // Rate Limiting 체크
  const rateLimitResult = await checkUserRateLimit(userId, rateLimitConfigs.investment);
  if (!rateLimitResult.success) {
    return rateLimitResult.response;
  }

  // API 로직 실행
  // ...
}
```

### Rate Limit 헤더 추가
```typescript
const response = successResponse(data);

// Rate Limit 헤더 추가
if (rateLimitResult.remaining !== undefined && rateLimitResult.resetTime) {
  response.headers.set('X-RateLimit-Remaining', rateLimitResult.remaining.toString());
  response.headers.set('X-RateLimit-Reset', new Date(rateLimitResult.resetTime).toISOString());
}

return response;
```

## 응답 형식

### Rate Limit 초과 시 (429 Too Many Requests)
```json
{
  "ok": false,
  "error": "너무 많은 요청이 발생했습니다. 잠시 후 다시 시도해주세요.",
  "code": "RATE_LIMIT_EXCEEDED",
  "retryAfter": 900
}
```

### Rate Limit 헤더
- `X-RateLimit-Limit`: 최대 요청 수
- `X-RateLimit-Remaining`: 남은 요청 수
- `X-RateLimit-Reset`: 리셋 시간 (ISO 8601)
- `Retry-After`: 재시도 가능 시간 (초)

## 프로덕션 환경 권장사항

### Redis 기반 Rate Limiting
메모리 기반 저장소는 서버 재시작 시 데이터가 초기화되고, 여러 서버 인스턴스 간 공유가 불가능합니다. 프로덕션 환경에서는 Redis를 사용하는 것을 권장합니다.

#### Redis 구현 예시
```typescript
import Redis from 'ioredis';

const redis = new Redis(process.env.REDIS_URL);

class RedisStore {
  async increment(key: string, windowMs: number) {
    const now = Date.now();
    const resetTime = now + windowMs;
    
    const count = await redis.incr(key);
    if (count === 1) {
      await redis.pexpire(key, windowMs);
    }
    
    return { count, resetTime };
  }
}
```

### Rate Limit 모니터링
- Rate Limit 초과 횟수 추적
- IP/사용자별 요청 패턴 분석
- 이상 징후 감지 및 알림

### 동적 Rate Limit 조정
- 사용자 등급에 따른 Rate Limit 차등 적용
- 시간대별 Rate Limit 조정
- 시스템 부하에 따른 자동 조정

## 보안 고려사항

1. **IP 스푸핑 방지**: X-Forwarded-For 헤더 검증
2. **사용자 인증**: 사용자 기반 Rate Limiting은 인증된 사용자만 적용
3. **에러 처리**: Rate Limit 체크 실패 시 안전한 폴백
4. **로깅**: Rate Limit 초과 시도 로깅

## 성능 최적화

1. **비동기 처리**: Rate Limit 체크는 비동기로 처리
2. **메모리 관리**: 만료된 항목 자동 정리
3. **캐싱**: 자주 사용되는 Rate Limit 설정 캐싱

## 다음 단계

1. **Redis 통합**: 프로덕션 환경을 위한 Redis 기반 Rate Limiting
2. **모니터링 대시보드**: Rate Limit 통계 및 시각화
3. **동적 조정**: 시스템 부하에 따른 자동 Rate Limit 조정
4. **화이트리스트**: 특정 IP/사용자에 대한 Rate Limit 면제

