# 아이콘 설정 가이드

## 현재 상태
아이콘 파일들이 `public/icons/` 디렉토리에 없어서 404 에러가 발생했습니다.
임시로 기본 favicon을 사용하도록 수정했습니다.

## 아이콘 파일 생성 방법

### 1. 온라인 도구 사용
- https://realfavicongenerator.net/
- https://www.favicon-generator.org/
- https://favicon.io/

### 2. 필요한 아이콘 크기
- 16x16 (favicon)
- 32x32 (favicon)
- 72x72 (PWA)
- 96x96 (PWA)
- 128x128 (PWA)
- 144x144 (PWA)
- 152x152 (PWA)
- 192x192 (PWA, Apple Touch Icon)
- 384x384 (PWA)
- 512x512 (PWA)

### 3. 아이콘 파일 배치
아이콘 파일을 생성한 후 `public/icons/` 디렉토리에 배치하세요:

```
public/
  icons/
    icon-16x16.png
    icon-32x32.png
    icon-72x72.png
    icon-96x96.png
    icon-128x128.png
    icon-144x144.png
    icon-152x152.png
    icon-192x192.png
    icon-384x384.png
    icon-512x512.png
```

### 4. 설정 복원
아이콘 파일을 추가한 후:

1. `src/app/layout.tsx` 수정:
```tsx
<link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
<link rel="icon" type="image/png" sizes="32x32" href="/icons/icon-32x32.png" />
<link rel="icon" type="image/png" sizes="16x16" href="/icons/icon-16x16.png" />
```

2. `public/manifest.json` 수정:
```json
"icons": [
  {
    "src": "/icons/icon-72x72.png",
    "sizes": "72x72",
    "type": "image/png"
  },
  // ... 다른 크기들
]
```

3. `public/sw.js` 수정:
```javascript
const urlsToCache = [
  // ...
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png'
];
```

## 임시 해결책
현재는 기본 favicon만 사용하도록 설정되어 있습니다.
아이콘 파일이 없어도 애플리케이션은 정상적으로 작동합니다.

