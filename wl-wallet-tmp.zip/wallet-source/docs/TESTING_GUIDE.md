# 테스트 가이드

## 🚀 서버 실행 확인

### 1. 서버 실행
```bash
npm run dev
```

서버가 정상적으로 실행되면:
- 콘솔에 "Ready" 메시지 표시
- http://localhost:3009 접근 가능
- 스케줄러 자동 시작 메시지 확인

### 2. 기본 페이지 접근 테스트

#### 홈페이지
```
GET http://localhost:3009
```

#### 로그인 페이지
```
GET http://localhost:3009/login
```

#### 회원가입 페이지
```
GET http://localhost:3009/register
```

## 📋 기능별 테스트 체크리스트

### 인증 기능 테스트

#### 1. 회원가입
```bash
POST http://localhost:3009/api/auth/register
Content-Type: application/json

{
  "username": "testuser",
  "email": "test@example.com",
  "password": "password123",
  "referrerCode": "optional"
}
```

**확인 사항:**
- ✅ 회원가입 성공
- ✅ 자동 로그인 (쿠키 설정)
- ✅ 입력 검증 동작
- ✅ 중복 체크 동작

#### 2. 로그인
```bash
POST http://localhost:3009/api/auth/login
Content-Type: application/json

{
  "username": "testuser",
  "password": "password123"
}
```

**확인 사항:**
- ✅ 로그인 성공
- ✅ 쿠키 설정 확인
- ✅ Rate Limiting 헤더 확인
- ✅ 잘못된 비밀번호 시 에러

#### 3. 세션 확인
```bash
GET http://localhost:3009/api/auth/session
```

**확인 사항:**
- ✅ 로그인 상태 확인
- ✅ 사용자 정보 반환

### 사용자 기능 테스트

#### 1. 대시보드 조회
```bash
GET http://localhost:3009/api/dashboard
```

**확인 사항:**
- ✅ 사용자 통계 반환
- ✅ 최근 활동 반환
- ✅ 조직도 데이터 반환
- ✅ Rate Limiting 동작

#### 2. 투자 신청
```bash
POST http://localhost:3009/api/user/invest
Content-Type: application/json

{
  "userId": "user_id",
  "amount": 100
}
```

**확인 사항:**
- ✅ 투자 등급 자동 계산
- ✅ 일일 수익률 설정
- ✅ 매칭 깊이 설정
- ✅ 잔고 부족 시 에러
- ✅ 입력 검증 동작

#### 3. 코인 이체
```bash
POST http://localhost:3009/api/user/transfer
Content-Type: application/json

{
  "receiverEmail": "receiver@example.com",
  "amount": 50,
  "password": "password123"
}
```

**확인 사항:**
- ✅ 이체 성공
- ✅ 수수료 차감
- ✅ 잔고 부족 시 에러
- ✅ 비밀번호 확인

#### 4. 출금 신청
```bash
POST http://localhost:3009/api/user/withdraw
Content-Type: application/json

{
  "userId": "user_id",
  "amount": 100,
  "address": "wallet_address_here"
}
```

**확인 사항:**
- ✅ 출금 신청 성공
- ✅ 잔고 차감
- ✅ 지갑 주소 검증
- ✅ Rate Limiting 동작 (24시간에 5회)

### 관리자 기능 테스트

#### 1. 관리자 대시보드
```bash
GET http://localhost:3009/api/admin/dashboard
```

**확인 사항:**
- ✅ 전체 통계 반환
- ✅ 랭크 분포 반환
- ✅ 최근 활동 반환
- ✅ 관리자 권한 확인

#### 2. 사용자 목록
```bash
GET http://localhost:3009/api/admin/users?page=1&limit=20
```

**확인 사항:**
- ✅ 페이지네이션 동작
- ✅ 검색 기능
- ✅ 필터링 기능
- ✅ 입력 검증 동작

#### 3. 보상 설정 조회/수정
```bash
# 조회
GET http://localhost:3009/api/admin/reward-settings

# 수정
PUT http://localhost:3009/api/admin/reward-settings
Content-Type: application/json

{
  "referralBonus": { "rate": 0.1 },
  "matchingBonus": {
    "generation1": 0.12,
    "generation2to4": 0.08,
    "generation5to8": 0.05,
    "generation9to12": 0.03
  }
}
```

**확인 사항:**
- ✅ 설정 조회 성공
- ✅ 설정 수정 성공
- ✅ 입력 검증 동작 (0-1 범위)

#### 4. 투자 등급 설정 조회/수정
```bash
# 조회
GET http://localhost:3009/api/admin/investment/tiers

# 수정
PUT http://localhost:3009/api/admin/investment/tiers
Content-Type: application/json

{
  "tiers": [
    {
      "tier": 1,
      "minAmount": 50,
      "maxAmount": 99,
      "dailyRate": 0.003,
      "matchingDepth": 0
    }
  ]
}
```

**확인 사항:**
- ✅ 등급 조회 성공
- ✅ 등급 수정 성공
- ✅ 입력 검증 동작

#### 5. 모니터링 메트릭 조회
```bash
# 요약
GET http://localhost:3009/api/admin/monitoring/metrics?type=summary

# 상세
GET http://localhost:3009/api/admin/monitoring/metrics?type=detailed

# 에러 로그
GET http://localhost:3009/api/admin/monitoring/metrics?type=errors&limit=50
```

**확인 사항:**
- ✅ 메트릭 데이터 반환
- ✅ 에러 로그 반환
- ✅ 통계 요약 반환

### 리워드 시스템 테스트

#### 1. 일일 리워드 수동 실행
```bash
POST http://localhost:3009/api/admin/run-daily
```

**확인 사항:**
- ✅ 리워드 분배 성공
- ✅ 로그 확인
- ✅ 에러 처리

#### 2. 리더십 보너스 수동 실행
```bash
POST http://localhost:3009/api/admin/run-leadership
```

**확인 사항:**
- ✅ 보너스 분배 성공
- ✅ 로그 확인

#### 3. 랭크 계산 수동 실행
```bash
POST http://localhost:3009/api/admin/calc-rank
```

**확인 사항:**
- ✅ 랭크 계산 성공
- ✅ 승급 처리

## 🔍 Rate Limiting 테스트

### 1. 로그인 Rate Limiting
```bash
# 10회 이상 로그인 시도
for i in {1..15}; do
  curl -X POST http://localhost:3009/api/auth/login \
    -H "Content-Type: application/json" \
    -d '{"username":"test","password":"wrong"}'
done
```

**확인 사항:**
- ✅ 10회 후 429 에러 반환
- ✅ Retry-After 헤더 확인
- ✅ Rate Limit 헤더 확인

### 2. 출금 Rate Limiting
```bash
# 5회 이상 출금 시도
for i in {1..6}; do
  curl -X POST http://localhost:3009/api/user/withdraw \
    -H "Content-Type: application/json" \
    -d '{"userId":"user_id","amount":10,"address":"wallet"}'
done
```

**확인 사항:**
- ✅ 5회 후 429 에러 반환
- ✅ 24시간 제한 확인

## 🐛 에러 처리 테스트

### 1. 입력 검증 에러
```bash
POST http://localhost:3009/api/auth/register
Content-Type: application/json

{
  "username": "ab",  # 3자 미만
  "email": "invalid-email",  # 잘못된 이메일
  "password": "123"  # 6자 미만
}
```

**확인 사항:**
- ✅ 적절한 에러 메시지
- ✅ 400 상태 코드
- ✅ 에러 코드 반환

### 2. 인증 에러
```bash
GET http://localhost:3009/api/dashboard
# 쿠키 없이 요청
```

**확인 사항:**
- ✅ 401 상태 코드
- ✅ 명확한 에러 메시지

### 3. 권한 에러
```bash
GET http://localhost:3009/api/admin/dashboard
# 일반 사용자로 요청
```

**확인 사항:**
- ✅ 403 상태 코드
- ✅ 권한 에러 메시지

## 📊 성능 모니터링 확인

### 1. 메트릭 수집 확인
여러 API 요청 후:
```bash
GET http://localhost:3009/api/admin/monitoring/metrics?type=summary
```

**확인 사항:**
- ✅ 요청 수 집계
- ✅ 평균 응답 시간
- ✅ 에러율 계산

### 2. 에러 로그 확인
에러 발생 후:
```bash
GET http://localhost:3009/api/admin/monitoring/metrics?type=errors
```

**확인 사항:**
- ✅ 에러 로그 기록
- ✅ 타임스탬프 확인
- ✅ 사용자 ID/IP 확인

## ✅ 통합 테스트 시나리오

### 시나리오 1: 신규 사용자 가입 → 투자 → 리워드 수령
1. 회원가입
2. 로그인
3. 대시보드 확인
4. 투자 신청
5. 일일 리워드 실행 (관리자)
6. 대시보드에서 리워드 확인

### 시나리오 2: 추천인 시스템 테스트
1. 사용자 A 가입
2. 사용자 B 가입 (A를 추천인으로)
3. 사용자 B 투자
4. 사용자 A 추천 보너스 확인

### 시나리오 3: 관리자 작업 흐름
1. 관리자 로그인
2. 사용자 목록 조회
3. 출금 신청 목록 조회
4. 출금 승인
5. 보상 설정 변경
6. 모니터링 데이터 확인

## 🔧 문제 해결

### 서버가 시작되지 않는 경우
1. 포트 3009가 사용 중인지 확인
2. 데이터베이스 연결 확인
3. 환경 변수 확인
4. 의존성 설치 확인 (`npm install`)

### 데이터베이스 연결 오류
1. `.env` 파일의 `DATABASE_URL` 확인
2. PostgreSQL 서버 실행 확인
3. `npx prisma db push` 실행

### API 에러 발생 시
1. 콘솔 로그 확인
2. 네트워크 탭에서 응답 확인
3. 에러 코드 확인
4. 모니터링 메트릭 확인

## 📝 테스트 결과 기록

테스트 시 다음을 기록하세요:
- 테스트 날짜/시간
- 테스트한 기능
- 예상 결과 vs 실제 결과
- 발견된 문제점
- 개선 제안

