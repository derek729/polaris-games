/* ==========================================
   LocalStorage 관리
   ========================================== */

const Storage = {

  /* ==========================================
     기본 CRUD
     ========================================== */

  // 저장
  set(key, value) {
    try {
      const serialized = JSON.stringify(value);
      localStorage.setItem(key, serialized);
      return true;
    } catch (e) {
      console.error('Storage set error:', e);
      return false;
    }
  },

  // 가져오기
  get(key, defaultValue = null) {
    try {
      const item = localStorage.getItem(key);
      if (item === null) return defaultValue;
      return JSON.parse(item);
    } catch (e) {
      console.error('Storage get error:', e);
      return defaultValue;
    }
  },

  // 삭제
  remove(key) {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (e) {
      console.error('Storage remove error:', e);
      return false;
    }
  },

  // 전체 삭제
  clear() {
    try {
      // 바둑이 관련 키만 삭제
      Object.values(STORAGE_KEYS).forEach(key => {
        localStorage.removeItem(key);
      });
      return true;
    } catch (e) {
      console.error('Storage clear error:', e);
      return false;
    }
  },

  /* ==========================================
     게임 데이터 저장/로드
     ========================================== */

  // 전체 게임 데이터 저장
  saveGameData() {
    this.set(STORAGE_KEYS.CHIPS, State.myChips);
    this.set(STORAGE_KEYS.LAST_FREE, State.lastFreeCharge);
    this.set(STORAGE_KEYS.EVENT_USED, State.eventUsed);
    this.set(STORAGE_KEYS.PLAYER_NAME, State.playerName);
  },

  // 전체 게임 데이터 로드
  loadGameData() {
    State.myChips = this.get(STORAGE_KEYS.CHIPS, INITIAL_CHIPS);
    State.lastFreeCharge = this.get(STORAGE_KEYS.LAST_FREE, 0);
    State.eventUsed = this.get(STORAGE_KEYS.EVENT_USED, false);
    State.playerName = this.get(STORAGE_KEYS.PLAYER_NAME, 'Player');
  },

  /* ==========================================
     개별 데이터 저장/로드
     ========================================== */

  // 칩 저장
  saveChips(amount) {
    State.myChips = amount;
    this.set(STORAGE_KEYS.CHIPS, amount);
  },

  // 칩 추가
  addChips(amount) {
    State.myChips += amount;
    this.set(STORAGE_KEYS.CHIPS, State.myChips);
    return State.myChips;
  },

  // 칩 차감
  deductChips(amount) {
    State.myChips = Math.max(0, State.myChips - amount);
    this.set(STORAGE_KEYS.CHIPS, State.myChips);
    return State.myChips;
  },

  // 무료 충전 시간 저장
  saveFreeChargeTime() {
    State.lastFreeCharge = Date.now();
    this.set(STORAGE_KEYS.LAST_FREE, State.lastFreeCharge);
  },

  // 이벤트 사용 저장
  saveEventUsed() {
    State.eventUsed = true;
    this.set(STORAGE_KEYS.EVENT_USED, true);
  },

  // 플레이어 이름 저장
  savePlayerName(name) {
    State.playerName = name;
    this.set(STORAGE_KEYS.PLAYER_NAME, name);
  },

  /* ==========================================
     충전 가능 여부 확인
     ========================================== */

  // 무료 충전 가능 여부
  canFreeCharge() {
    const now = Date.now();
    const elapsed = now - State.lastFreeCharge;
    return elapsed >= CHARGE_CONFIG.FREE_COOLDOWN;
  },

  // 무료 충전까지 남은 시간 (ms)
  getFreeChargeRemaining() {
    const now = Date.now();
    const elapsed = now - State.lastFreeCharge;
    return Math.max(0, CHARGE_CONFIG.FREE_COOLDOWN - elapsed);
  },

  // 이벤트 보너스 가능 여부
  canEventBonus() {
    return !State.eventUsed;
  },

  /* ==========================================
     통계 데이터
     ========================================== */

  STATS_KEY: 'badugi_stats',

  // 기본 통계 데이터
  getDefaultStats() {
    return {
      totalGames: 0,
      wins: 0,
      losses: 0,
      totalEarnings: 0,
      badugis: 0,
      allIns: 0,
      maxWinStreak: 0,
      currentWinStreak: 0
    };
  },

  // 통계 조회
  getStats() {
    return this.get(this.STATS_KEY, this.getDefaultStats());
  },

  // 통계 저장
  saveStats(stats) {
    this.set(this.STATS_KEY, stats);
  },

  // 통계 업데이트
  updateStats(updates) {
    const stats = this.getStats();

    Object.keys(updates).forEach(key => {
      if (key === 'currentWinStreak') {
        stats.currentWinStreak = updates[key];
        stats.maxWinStreak = Math.max(stats.maxWinStreak, updates[key]);
      } else if (key === 'maxWinStreak') {
        stats.maxWinStreak = Math.max(stats.maxWinStreak, updates[key]);
      } else {
        stats[key] = (stats[key] || 0) + updates[key];
      }
    });

    this.saveStats(stats);
    return stats;
  }
};
