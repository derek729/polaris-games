/* ==========================================
   UI 이벤트 핸들러
   ========================================== */

const UI = {

  /* ==========================================
     화면 전환
     ========================================== */

  // 로비 화면 표시
  showLobbyScreen() {
    Utils.hide('#game-screen');
    Utils.show('#lobby-screen');

    // 데이터 갱신
    Renderer.updateChipsDisplay();
    Renderer.renderRoomList();

    // 게임 상태 초기화
    resetGameState();
  },

  // 게임 화면 표시
  showGameScreen() {
    Utils.hide('#lobby-screen');
    Utils.show('#game-screen');

    // 로그 초기화
    Renderer.clearLog();

    // 선택 카드 초기화
    State.selectedCards.clear();
  },

  /* ==========================================
     충전 모달
     ========================================== */

  // 충전 모달 열기
  openChargeModal() {
    const modal = Utils.$('#charge-modal');
    if (!modal) return;

    // 현재 칩 표시 업데이트
    Renderer.updateChipsDisplay();

    // 충전 옵션 렌더링
    Renderer.renderChargeOptions();

    // 타이머 업데이트
    this.updateFreeChargeTimer();

    // 모달 표시
    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  // 충전 모달 닫기
  closeChargeModal() {
    const modal = Utils.$('#charge-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  },

  // 무료 충전 타이머 업데이트
  updateFreeChargeTimer() {
    const timerEl = Utils.$('#free-timer');
    const btnEl = Utils.$('#btn-free-charge');

    if (!timerEl || !btnEl) return;

    const remaining = Storage.getFreeChargeRemaining();

    if (remaining > 0) {
      const mins = Math.floor(remaining / 60000);
      const secs = Math.floor((remaining % 60000) / 1000);
      timerEl.textContent = `다음 충전까지: ${mins}분 ${secs}초`;
      timerEl.classList.remove('hidden');
      btnEl.disabled = true;
    } else {
      timerEl.classList.add('hidden');
      btnEl.disabled = false;
    }
  },

  /* ==========================================
     충전 기능
     ========================================== */

  // 무료 충전
  freeCharge() {
    if (!Storage.canFreeCharge()) {
      return;
    }

    const amount = CHARGE_CONFIG.FREE_AMOUNT;
    Storage.addChips(amount);
    Storage.saveFreeChargeTime();

    this.showChargeResult('🎁', '무료 충전 완료!', `+${Utils.formatChips(amount)}`, 'gold');
  },

  // 이벤트 보너스
  eventBonus() {
    if (!Storage.canEventBonus()) {
      return;
    }

    const amount = CHARGE_CONFIG.EVENT_AMOUNT;
    Storage.addChips(amount);
    Storage.saveEventUsed();

    this.showChargeResult('🎉', '이벤트 보너스!', `+${Utils.formatChips(amount)}`, 'purple');
  },

  // 광고 시청
  watchAd() {
    // 광고 시청 중 UI 표시
    this.showAdOverlay();

    // 광고 시간 후 보상 지급
    setTimeout(() => {
      this.hideAdOverlay();

      const amount = CHARGE_CONFIG.AD_AMOUNT;
      Storage.addChips(amount);

      this.showChargeResult('📺', '광고 시청 완료!', `+${Utils.formatChips(amount)}`, 'blue');
    }, CHARGE_CONFIG.AD_DURATION);
  },

  // 광고 오버레이 표시
  showAdOverlay() {
    const modal = Utils.$('#charge-modal');
    if (!modal) return;

    const content = modal.querySelector('.modal-content');
    if (!content) return;

    content.innerHTML = `
      <div class="text-center py-12">
        <div class="text-6xl mb-4 animate-pulse">📺</div>
        <div class="text-white text-xl mb-4">광고 시청 중...</div>
        <div class="progress-bar">
          <div class="progress-bar-fill" style="animation: progress ${CHARGE_CONFIG.AD_DURATION}ms linear forwards;"></div>
        </div>
      </div>
    `;
  },

  // 광고 오버레이 숨기기
  hideAdOverlay() {
    // 모달 내용 복원은 showChargeResult에서 처리
  },

  // 럭키 스핀
  luckySpin() {
    const prizes = CHARGE_CONFIG.SPIN_PRIZES;
    const weights = CHARGE_CONFIG.SPIN_WEIGHTS;

    const prize = Utils.weightedRandom(prizes, weights);

    // 스핀 애니메이션 표시
    this.showSpinAnimation(prize);
  },

  // 스핀 애니메이션
  showSpinAnimation(prize) {
    const modal = Utils.$('#charge-modal');
    if (!modal) return;

    const content = modal.querySelector('.modal-content');
    if (!content) return;

    content.innerHTML = `
      <div class="text-center py-12">
        <div class="text-7xl mb-4 animate-spin">🎰</div>
        <div class="text-white text-xl">스핀 중...</div>
      </div>
    `;

    // 2초 후 결과 표시
    setTimeout(() => {
      Storage.addChips(prize);
      this.showChargeResult('🎰', '럭키 스핀!', `+${Utils.formatChips(prize)}`, 'pink');
    }, 2000);
  },

  // 충전 결과 표시
  showChargeResult(icon, title, amount, colorClass) {
    this.closeChargeModal();

    // 칩 표시 업데이트
    Renderer.updateChipsDisplay();
    Renderer.renderRoomList();

    // 결과 모달 표시
    this.showResultModal(icon, title, amount, colorClass);
  },

  /* ==========================================
     결과 모달
     ========================================== */

  // 결과 모달 표시
  showResultModal(icon, title, message, colorClass = '') {
    const modal = Utils.$('#result-modal');
    if (!modal) return;

    const iconEl = Utils.$('#result-icon');
    const titleEl = Utils.$('#result-title');
    const messageEl = Utils.$('#result-message');
    const detailsEl = Utils.$('#result-details');

    if (iconEl) iconEl.textContent = icon;
    if (titleEl) titleEl.textContent = title;
    if (messageEl) {
      messageEl.innerHTML = `<span class="text-${colorClass}-400 font-bold text-2xl">${message}</span>`;
    }
    if (detailsEl) {
      detailsEl.innerHTML = `
        <div class="text-center">
          <div class="text-gray-400 text-sm mb-1">현재 보유 칩</div>
          <div class="chip-amount text-2xl">${Utils.formatChips(State.myChips)}</div>
        </div>
      `;
    }

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  // 결과 모달 닫기
  closeResultModal() {
    const modal = Utils.$('#result-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }

    // 로비에 있으면 방 목록 갱신
    if (!Utils.$('#lobby-screen').classList.contains('hidden')) {
      Renderer.renderRoomList();
    }
  },

  /* ==========================================
     게임 결과 모달
     ========================================== */

  // 승리 모달
  showWinModal(amount, handName) {
    this.showResultModal(
      '🏆',
      '승리!',
      `+${Utils.formatChips(amount)}`,
      'gold'
    );

    const detailsEl = Utils.$('#result-details');
    if (detailsEl) {
      detailsEl.innerHTML = `
        <div class="space-y-2">
          <div class="flex justify-between">
            <span class="text-gray-400">내 패</span>
            <span class="text-green-400 font-bold">${handName}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-400">획득 금액</span>
            <span class="text-gold-400 font-bold">${Utils.formatChips(amount)}</span>
          </div>
          <div class="decoration-line my-2"></div>
          <div class="flex justify-between">
            <span class="text-gray-400">현재 보유</span>
            <span class="chip-amount">${Utils.formatChips(State.myChips)}</span>
          </div>
        </div>
      `;
    }
  },

  // 패배 모달
  showLoseModal(winnerName, winnerHand) {
    this.showResultModal(
      '😢',
      '패배',
      `${winnerName} 승리`,
      'gray'
    );

    const detailsEl = Utils.$('#result-details');
    if (detailsEl) {
      detailsEl.innerHTML = `
        <div class="space-y-2">
          <div class="flex justify-between">
            <span class="text-gray-400">승자</span>
            <span class="text-white font-bold">${winnerName}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-400">승자 패</span>
            <span class="text-green-400 font-bold">${winnerHand}</span>
          </div>
          <div class="decoration-line my-2"></div>
          <div class="flex justify-between">
            <span class="text-gray-400">현재 보유</span>
            <span class="chip-amount">${Utils.formatChips(State.myChips)}</span>
          </div>
        </div>
      `;
    }
  },

  // 파산 모달
  showBankruptModal() {
    const modal = Utils.$('#result-modal');
    if (!modal) return;

    const iconEl = Utils.$('#result-icon');
    const titleEl = Utils.$('#result-title');
    const messageEl = Utils.$('#result-message');
    const detailsEl = Utils.$('#result-details');

    if (iconEl) {
      iconEl.textContent = '💸';
      iconEl.classList.add('animate-shake');
    }
    if (titleEl) titleEl.textContent = '파산!';
    if (messageEl) messageEl.textContent = '칩이 부족합니다';
    if (detailsEl) {
      detailsEl.innerHTML = `
        <p class="text-gray-300 mb-4 text-center">충전 후 다시 도전하세요!</p>
        <button onclick="UI.closeResultModal(); UI.openChargeModal();"
                class="btn-gold w-full">
          💎 충전하러 가기
        </button>
      `;
    }

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  /* ==========================================
     타이머
     ========================================== */

  // 액션 타이머 시작
  startActionTimer(duration = TIMER_CONFIG.ACTION_TIMEOUT) {
    clearTimer();

    State.timerRemaining = duration;
    Renderer.updateTimerDisplay();

    State.timerInterval = setInterval(() => {
      State.timerRemaining -= 1000;
      Renderer.updateTimerDisplay();

      // 5초 이하면 타이머 경고 애니메이션
      if (State.timerRemaining <= 5000 && State.timerRemaining > 0) {
        if (typeof AnimationManager !== 'undefined') {
          AnimationManager.showTimerWarning();
        }
      }

      if (State.timerRemaining <= 0) {
        clearTimer();
        Game.handleTimeout();
      }
    }, 1000);
  },

  // 타이머 정지
  stopTimer() {
    clearTimer();

    // 타이머 경고 숨기기
    if (typeof AnimationManager !== 'undefined') {
      AnimationManager.hideTimerWarning();
    }

    Renderer.updateTimerDisplay();
  },

  /* ==========================================
     플레이어 이름
     ========================================== */

  // 플레이어 이름 입력 처리
  handlePlayerNameInput() {
    const input = Utils.$('#player-name');
    if (!input) return;

    input.addEventListener('change', (e) => {
      const name = e.target.value.trim() || 'Player';
      Storage.savePlayerName(name);
    });

    // 초기값 설정
    input.value = State.playerName;
  },

  /* ==========================================
     일일 보상 모달
     ========================================== */

  // 일일 보상 모달 열기
  openDailyRewardModal() {
    const modal = Utils.$('#daily-reward-modal');
    if (!modal) return;

    this.renderDailyReward();
    this.updateNotificationBadges();

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  // 일일 보상 모달 닫기
  closeDailyRewardModal() {
    const modal = Utils.$('#daily-reward-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  },

  // 일일 보상 렌더링
  renderDailyReward() {
    const status = DailyReward.getStatus();
    const gridEl = Utils.$('#daily-reward-grid');
    const streakEl = Utils.$('#daily-streak-display');
    const btnEl = Utils.$('#claim-daily-btn');

    if (!gridEl || !streakEl || !btnEl) return;

    // 연속 출석 일수 표시
    streakEl.textContent = `${status.currentStreak}일`;

    // 보상 그리드 렌더링
    gridEl.innerHTML = DailyReward.REWARDS.map((reward, index) => {
      const day = index + 1;
      const isClaimed = day < status.currentDay;
      const isCurrent = day === status.currentDay && !status.claimedToday;
      const isLocked = day > status.currentDay;

      const classes = ['daily-reward-item'];
      if (isClaimed) classes.push('claimed');
      if (isCurrent) classes.push('current');
      if (isLocked) classes.push('locked');

      return `
        <div class="${classes.join(' ')}">
          <div class="daily-reward-day">${day}일차</div>
          <div class="daily-reward-icon">${isClaimed ? '✅' : reward.icon}</div>
          <div class="daily-reward-amount">${Utils.formatChips(reward.amount)}</div>
        </div>
      `;
    }).join('');

    // 버튼 상태
    if (status.claimedToday) {
      btnEl.disabled = true;
      btnEl.textContent = '✓ 이미 받음';
    } else if (status.canClaim) {
      btnEl.disabled = false;
      btnEl.textContent = '🎁 보상 받기';
    } else {
      btnEl.disabled = true;
      btnEl.textContent = '연속 출석 초기화됨';
    }
  },

  // 일일 보상 수령
  claimDailyReward() {
    const result = DailyReward.claim();

    if (result.success) {
      this.showToast('success', '일일 보상', `+${Utils.formatChips(result.reward)}칩 획득!`);
      this.renderDailyReward();
      Renderer.updateChipsDisplay();
      this.updateNotificationBadges();
    } else {
      this.showToast('error', '오류', result.message);
    }
  },

  /* ==========================================
     업적 모달
     ========================================== */

  // 업적 모달 열기
  openAchievementsModal() {
    const modal = Utils.$('#achievements-modal');
    if (!modal) return;

    this.renderAchievements();

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  // 업적 모달 닫기
  closeAchievementsModal() {
    const modal = Utils.$('#achievements-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  },

  // 업적 렌더링
  renderAchievements() {
    const achievements = Achievements.getAchievements();
    const listEl = Utils.$('#achievements-list');
    const unlockedEl = Utils.$('#achievements-unlocked');
    const totalEl = Utils.$('#achievements-total');
    const rewardsEl = Utils.$('#achievements-rewards');

    if (!listEl) return;

    // 통계 업데이트
    const unlockedCount = achievements.filter(a => a.unlocked).length;
    if (unlockedEl) unlockedEl.textContent = unlockedCount;
    if (totalEl) totalEl.textContent = achievements.length;

    const totalRewards = achievements
      .filter(a => a.unlocked)
      .reduce((sum, a) => sum + a.reward, 0);
    if (rewardsEl) rewardsEl.textContent = Utils.formatChips(totalRewards);

    // 업적 목록 렌더링
    listEl.innerHTML = achievements.map(achievement => {
      const classes = ['achievement-card'];
      if (achievement.unlocked) classes.push('unlocked');
      else classes.push('locked');

      const progress = achievement.current >= achievement.target ? 100 :
        Math.floor((achievement.current / achievement.target) * 100);

      return `
        <div class="${classes.join(' ')}">
          <div class="achievement-icon">${achievement.unlocked ? achievement.icon : '🔒'}</div>
          <div class="achievement-info">
            <div class="achievement-name">${achievement.name}</div>
            <div class="achievement-desc">${achievement.desc}</div>
            ${!achievement.unlocked ? `
              <div class="achievement-progress">
                <div class="achievement-progress-bar">
                  <div class="achievement-progress-fill" style="width: ${progress}%"></div>
                </div>
                <div class="text-xs text-gray-400 mt-1">${achievement.current}/${achievement.target}</div>
              </div>
            ` : ''}
          </div>
          <div class="achievement-reward">
            <div class="achievement-reward-amount">+${Utils.formatChips(achievement.reward)}</div>
          </div>
        </div>
      `;
    }).join('');
  },

  /* ==========================================
     미션 모달
     ========================================== */

  // 미션 모달 열기
  openMissionsModal() {
    const modal = Utils.$('#missions-modal');
    if (!modal) return;

    this.renderMissions();
    this.startMissionTimer();
    this.updateNotificationBadges();

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  // 미션 모달 닫기
  closeMissionsModal() {
    const modal = Utils.$('#missions-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }

    if (State.missionTimerInterval) {
      clearInterval(State.missionTimerInterval);
      State.missionTimerInterval = null;
    }
  },

  // 미션 렌더링
  renderMissions() {
    const missions = Missions.getMissions();
    const listEl = Utils.$('#missions-list');
    const allCompleteEl = Utils.$('#all-complete-bonus');

    if (!listEl) return;

    // 미션 목록 렌더링
    listEl.innerHTML = missions.map(mission => {
      const classes = ['mission-card'];
      if (mission.completed) classes.push('completed');

      const progress = Math.min(100, Math.floor((mission.current / mission.target) * 100));

      return `
        <div class="${classes.join(' ')}">
          <div class="mission-icon">${mission.icon}</div>
          <div class="mission-info">
            <div class="mission-name">${mission.name}</div>
            <div class="mission-desc">${mission.desc}</div>
            <div class="mission-progress-text">${mission.current}/${mission.target}</div>
          </div>
          <div class="mission-reward">+${Utils.formatChips(mission.reward)}</div>
        </div>
      `;
    }).join('');

    // 전체 완료 보너스
    const allComplete = missions.length > 0 && missions.every(m => m.completed);
    if (allCompleteEl) {
      if (allComplete) {
        allCompleteEl.classList.remove('hidden');
      } else {
        allCompleteEl.classList.add('hidden');
      }
    }
  },

  // 미션 타이머 시작
  startMissionTimer() {
    const timerEl = Utils.$('#mission-timer');
    if (!timerEl) return;

    const updateTimer = () => {
      const remaining = Missions.getTimeRemaining();
      timerEl.textContent = remaining.formatted;
    };

    updateTimer();

    if (State.missionTimerInterval) {
      clearInterval(State.missionTimerInterval);
    }

    State.missionTimerInterval = setInterval(updateTimer, 60000);
  },

  // 전체 완료 보너스 수령
  claimAllCompleteBonus() {
    const result = Missions.checkAllCompleteBonus();

    if (result.success) {
      this.showToast('success', '🎉', `모든 미션 완료! +${Utils.formatChips(result.bonus)}칩 획득!`);
      this.renderMissions();
      Renderer.updateChipsDisplay();
      this.updateNotificationBadges();
    }
  },

  /* ==========================================
     VIP 모달
     ========================================== */

  // VIP 모달 열기
  openVIPModal() {
    const modal = Utils.$('#vip-modal');
    if (!modal) return;

    this.renderVIPStatus();

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  // VIP 모달 닫기
  closeVIPModal() {
    const modal = Utils.$('#vip-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  },

  // VIP 상태 렌더링
  renderVIPStatus() {
    const status = VIPSystem.getStatus();
    const statusCardEl = Utils.$('#vip-status-card');
    const benefitsEl = Utils.$('#vip-benefits');
    const levelsListEl = Utils.$('#vip-levels-list');

    if (!statusCardEl || !benefitsEl || !levelsListEl) return;

    const levelInfo = status.levelInfo;

    // 상태 카드
    statusCardEl.innerHTML = `
      <div class="vip-level-badge mb-4">
        <span class="text-2xl">${levelInfo.icon}</span>
        <span class="text-xl">${levelInfo.name}</span>
      </div>
      ${status.nextLevel ? `
        <div class="vip-progress-container">
          <div class="flex justify-between text-sm mb-2">
            <span class="text-gray-400">다음 레벨까지</span>
            <span class="text-gold-400">${status.expToNext.toLocaleString()}EXP</span>
          </div>
          <div class="vip-progress-bar">
            <div class="vip-progress-fill" style="width: ${status.progress}%"></div>
          </div>
        </div>
      ` : `
        <div class="text-center text-gold-400 font-bold mt-4">
          🎉 최고 레벨 달성!
        </div>
      `}
    `;

    // 혜택
    benefitsEl.innerHTML = `
      <div class="vip-benefit-item">
        <div class="vip-benefit-value">${Utils.formatChips(levelInfo.benefits.freeCharge)}</div>
        <div class="vip-benefit-label">무료 충전</div>
      </div>
      <div class="vip-benefit-item">
        <div class="vip-benefit-value">+${levelInfo.benefits.spinBonus}%</div>
        <div class="vip-benefit-label">휠 보너스</div>
      </div>
      <div class="vip-benefit-item">
        <div class="vip-benefit-value">+${levelInfo.benefits.expBonus}%</div>
        <div class="vip-benefit-label">EXP 보너스</div>
      </div>
    `;

    // 레벨 목록
    levelsListEl.innerHTML = VIPSystem.LEVELS.map((level, index) => {
      const classes = ['vip-level-item'];
      if (index === status.level) classes.push('current');
      if (index > status.level) classes.push('locked');

      return `
        <div class="${classes.join(' ')}">
          <div class="vip-level-icon">${level.icon}</div>
          <div class="vip-level-info">
            <div class="vip-level-name">${level.name}</div>
            <div class="vip-level-exp">${level.minExp.toLocaleString()}EXP</div>
          </div>
          <div class="vip-level-benefits">
            충전 ${Utils.formatChips(level.benefits.freeCharge)} / 휠 +${level.benefits.spinBonus}%
          </div>
        </div>
      `;
    }).join('');
  },

  // VIP 뱃지 업데이트
  updateVIPBadge() {
    const status = VIPSystem.getStatus();
    const badgeEl = Utils.$('#vip-badge-display');

    if (!badgeEl) return;

    const levelInfo = status.levelInfo;

    badgeEl.innerHTML = `
      <span class="vip-mini-icon">${levelInfo.icon}</span>
      <span class="vip-mini-name">${levelInfo.name}</span>
    `;
  },

  /* ==========================================
     럭키 휠 모달
     ========================================== */

  // 럭키 휠 모달 열기
  openLuckyWheelModal() {
    const modal = Utils.$('#lucky-wheel-modal');
    if (!modal) return;

    this.renderLuckyWheel();

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  // 럭키 휠 모달 닫기
  closeLuckyWheelModal() {
    const modal = Utils.$('#lucky-wheel-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }

    // 결과 숨기기
    const resultEl = Utils.$('#wheel-result');
    if (resultEl) {
      resultEl.classList.add('hidden');
    }
  },

  // 럭키 휠 렌더링
  renderLuckyWheel() {
    const status = LuckyWheel.getStatus();
    const canvas = Utils.$('#lucky-wheel-canvas');
    const spinsEl = Utils.$('#wheel-free-spins');
    const btnEl = Utils.$('#spin-wheel-btn');

    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 10;

    // 휠 그리기
    const slots = status.slots;
    const arcSize = (2 * Math.PI) / slots.length;

    slots.forEach((slot, index) => {
      const startAngle = index * arcSize - Math.PI / 2;
      const endAngle = startAngle + arcSize;

      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();

      ctx.fillStyle = slot.color;
      ctx.fill();

      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(startAngle + arcSize / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 14px Noto Sans KR';
      ctx.fillText(slot.label, radius - 20, 5);
      ctx.restore();
    });

    // 무료 스핀 정보
    if (spinsEl) {
      spinsEl.textContent = `무료 스핀: ${status.freeSpinsRemaining}회 남음`;
    }

    // 버튼 상태
    if (btnEl) {
      if (status.canFreeSpin) {
        btnEl.disabled = false;
        btnEl.textContent = '🎲 무료 스핀!';
      } else {
        btnEl.disabled = true;
        btnEl.textContent = '⚡ 칩 소모 (-₩1,000)';
      }
    }
  },

  // 휠 스핀
  spinWheel() {
    const status = LuckyWheel.getStatus();
    const canvas = Utils.$('#lucky-wheel-canvas');
    const btnEl = Utils.$('#spin-wheel-btn');
    const resultEl = Utils.$('#wheel-result');

    if (!canvas) return;

    // 칩 확인
    const isFree = status.canFreeSpin;
    if (!isFree && State.myChips < 1000) {
      this.showToast('error', '칩 부족', '스핀에 필요한 칩이 부족합니다.');
      return;
    }

    // 버튼 비활성화
    if (btnEl) btnEl.disabled = true;

    // 결과 계산
    const result = LuckyWheel.spin(isFree);

    if (!result.success) {
      this.showToast('error', '오류', result.message);
      if (btnEl) btnEl.disabled = false;
      return;
    }

    // 회전 애니메이션
    const ctx = canvas.getContext('2d');
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 10;

    let rotation = 0;
    const targetRotation = 1800 + Math.random() * 360; // 최소 5바퀴
    const duration = 4000;
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Easing
      const easeOut = 1 - Math.pow(1 - progress, 3);
      rotation = targetRotation * easeOut;

      // 휠 다시 그리기
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate((rotation * Math.PI) / 180);
      ctx.translate(-centerX, -centerY);

      this.renderLuckyWheel();

      ctx.restore();

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        // 애니메이션 완료
        if (resultEl) {
          resultEl.classList.remove('hidden');
          const resultDiv = resultEl.querySelector('div');
          if (resultDiv) {
            resultDiv.textContent = `${result.isJackpot ? '🎉 잭팟!' : result.slot.label} ${Utils.formatChips(result.prize)}${result.vipBonus ? ` (${result.vipBonus} VIP 보너스)` : ''}`;
          }
        }

        this.showToast('success', '럭키 휠', `+${Utils.formatChips(result.prize)}칩 획득!`);

        Renderer.updateChipsDisplay();
        this.renderLuckyWheel();

        if (btnEl) {
          const newStatus = LuckyWheel.getStatus();
          if (newStatus.canFreeSpin) {
            btnEl.disabled = false;
            btnEl.textContent = '🎲 무료 스핀!';
          } else if (State.myChips >= 1000) {
            btnEl.disabled = false;
            btnEl.textContent = '⚡ 칩 소모 (-₩1,000)';
          } else {
            btnEl.disabled = true;
            btnEl.textContent = '💸 칩 부족';
          }
        }
      }
    };

    requestAnimationFrame(animate);
  },

  /* ==========================================
     통계 모달
     ========================================== */

  // 통계 모달 열기
  openStatsModal() {
    const modal = Utils.$('#stats-modal');
    if (!modal) return;

    this.renderStats();

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  // 통계 모달 닫기
  closeStatsModal() {
    const modal = Utils.$('#stats-modal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  },

  // 통계 렌더링
  renderStats() {
    const stats = Storage.getStats();
    const gridEl = Utils.$('#stats-grid');

    if (!gridEl) return;

    const winRate = stats.totalGames > 0 ?
      Math.floor((stats.wins / stats.totalGames) * 100) : 0;

    gridEl.innerHTML = `
      <div class="stat-card">
        <div class="stat-icon">🎮</div>
        <div class="stat-label">총 게임</div>
        <div class="stat-value">${stats.totalGames}</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">🏆</div>
        <div class="stat-label">승리</div>
        <div class="stat-value green">${stats.wins}</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">😢</div>
        <div class="stat-label">패배</div>
        <div class="stat-value red">${stats.losses}</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">📊</div>
        <div class="stat-label">승률</div>
        <div class="stat-value gold">${winRate}%</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">💰</div>
        <div class="stat-label">총 수익</div>
        <div class="stat-value ${stats.totalEarnings >= 0 ? 'green' : 'red'}">
          ${stats.totalEarnings >= 0 ? '+' : ''}${Utils.formatChips(stats.totalEarnings)}
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">🎴</div>
        <div class="stat-label">바둑이</div>
        <div class="stat-value">${stats.badugis}</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">💥</div>
        <div class="stat-label">올인</div>
        <div class="stat-value">${stats.allIns}</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">🔥</div>
        <div class="stat-label">최대 연승</div>
        <div class="stat-value gold">${stats.maxWinStreak}</div>
      </div>
    `;
  },

  /* ==========================================
     토스트 알림
     ========================================== */

  // 토스트 표시
  showToast(type, title, message, duration = 3000) {
    const container = Utils.$('#toast-container');
    if (!container) return;

    const icons = {
      success: '✅',
      error: '❌',
      warning: '⚠️',
      info: 'ℹ️'
    };

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <div class="toast-icon">${icons[type] || icons.info}</div>
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        <div class="toast-message">${message}</div>
      </div>
      <div class="toast-close" onclick="this.parentElement.remove()">✕</div>
    `;

    container.appendChild(toast);

    // 자동 제거
    setTimeout(() => {
      toast.classList.add('animate-slideOutRight');
      setTimeout(() => {
        if (toast.parentElement) {
          toast.remove();
        }
      }, 300);
    }, duration);
  },

  /* ==========================================
     알림 뱃지 업데이트
     ========================================== */

  // 알림 뱃지 업데이트
  updateNotificationBadges() {
    // 일일 보상
    const dailyRewardStatus = DailyReward.getStatus();
    const dailyBadge = Utils.$('#daily-reward-badge');
    if (dailyBadge) {
      if (dailyRewardStatus.canClaim && !dailyRewardStatus.claimedToday) {
        dailyBadge.classList.remove('hidden');
      } else {
        dailyBadge.classList.add('hidden');
      }
    }

    // 미션
    const missions = Missions.getMissions();
    const missionsBadge = Utils.$('#missions-badge');
    if (missionsBadge) {
      const completableMissions = missions.filter(m =>
        !m.completed && m.current >= m.target
      );

      if (completableMissions.length > 0) {
        missionsBadge.textContent = completableMissions.length;
        missionsBadge.classList.remove('hidden');
      } else {
        missionsBadge.classList.add('hidden');
      }
    }
  },

  /* ==========================================
     설정 모달
     ========================================== */

  openSettingsModal() {
    const modal = Utils.$('#settings-modal');
    if (!modal) return;

    this.renderSettings();
    if (typeof SoundManager !== 'undefined') {
      SoundManager.playModalOpen();
    }

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  },

  closeSettingsModal() {
    const modal = Utils.$('#settings-modal');
    if (modal) {
      if (typeof SoundManager !== 'undefined') {
        SoundManager.playModalClose();
      }
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  },

  renderSettings() {
    if (typeof SoundManager === 'undefined') return;

    const settings = SoundManager.getSettings();

    // 마스터 사운드
    const masterCheck = Utils.$('#setting-sound-master');
    if (masterCheck) masterCheck.checked = settings.ENABLED;

    // BGM
    const bgmCheck = Utils.$('#setting-bgm');
    if (bgmCheck) bgmCheck.checked = settings.BGM_ENABLED;

    const bgmVolume = Utils.$('#setting-bgm-volume');
    if (bgmVolume) bgmVolume.value = settings.BGM_VOLUME * 100;

    const bgmDisplay = Utils.$('#bgm-volume-display');
    if (bgmDisplay) bgmDisplay.textContent = `${Math.round(settings.BGM_VOLUME * 100)}%`;

    // SFX
    const sfxCheck = Utils.$('#setting-sfx');
    if (sfxCheck) sfxCheck.checked = settings.SFX_ENABLED;

    const sfxVolume = Utils.$('#setting-sfx-volume');
    if (sfxVolume) sfxVolume.value = settings.SFX_VOLUME * 100;

    const sfxDisplay = Utils.$('#sfx-volume-display');
    if (sfxDisplay) sfxDisplay.textContent = `${Math.round(settings.SFX_VOLUME * 100)}%`;

    // 마스터 비활성화 시 하위 설정도 비활성화
    this.updateSettingsState(settings.ENABLED);
  },

  updateSettingsState(masterEnabled) {
    const bgmSetting = Utils.$('#bgm-setting');
    const sfxSetting = Utils.$('#sfx-setting');

    if (bgmSetting) bgmSetting.classList.toggle('disabled', !masterEnabled);
    if (sfxSetting) sfxSetting.classList.toggle('disabled', !masterEnabled);
  },

  toggleMasterSound() {
    const check = Utils.$('#setting-sound-master');
    const enabled = check ? check.checked : false;

    if (typeof SoundManager !== 'undefined') {
      SoundManager.setMasterEnabled(enabled);
    }
    this.updateSettingsState(enabled);

    if (enabled && typeof SoundManager !== 'undefined') {
      SoundManager.playButtonClick();
    }
  },

  toggleBGM() {
    const check = Utils.$('#setting-bgm');
    const enabled = check ? check.checked : false;

    if (typeof SoundManager !== 'undefined') {
      SoundManager.setBGMEnabled(enabled);
      SoundManager.playButtonClick();
    }
  },

  toggleSFX() {
    const check = Utils.$('#setting-sfx');
    const enabled = check ? check.checked : false;

    if (typeof SoundManager !== 'undefined') {
      SoundManager.setSFXEnabled(enabled);
      if (enabled) {
        SoundManager.playButtonClick();
      }
    }
  },

  setBGMVolume(value) {
    const volume = value / 100;
    if (typeof SoundManager !== 'undefined') {
      SoundManager.setBGMVolume(volume);
    }

    const display = Utils.$('#bgm-volume-display');
    if (display) display.textContent = `${value}%`;
  },

  setSFXVolume(value) {
    const volume = value / 100;
    if (typeof SoundManager !== 'undefined') {
      SoundManager.setSFXVolume(volume);
    }

    const display = Utils.$('#sfx-volume-display');
    if (display) display.textContent = `${value}%`;
  },

  // 방 만들기 모달 열기
  openCreateRoomModal() {
    const mode = window.currentGameMode ? window.currentGameMode() : 'local';

    const roomId = 'room_' + Date.now();
    const playerName = document.getElementById('player-name')?.value || 'Player';
    const roomName = playerName + '의 방';

    if (mode === 'local') {
      if (typeof Game !== 'undefined' && Game.startLocalGame) {
        Game.startLocalGame(roomId, roomName);
      } else {
        this.showToast('error', '오류', '게임을 초기화할 수 없습니다.');
      }
    } else {
      if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection()) {
        SocketManager.createRoom('badugi', 4, 1000);
      } else {
        this.showToast('error', '연결 오류', '서버에 연결되지 않았습니다.');
      }
    }
  }
};
