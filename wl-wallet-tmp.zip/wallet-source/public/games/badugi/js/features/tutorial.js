/* =========================================
   튜토리얼 시스템
   ========================================= */

const Tutorial = (function() {
  // 튜토리얼 데이터
  const TUTORIALS = {
    main: {
      id: 'main',
      name: '바둑이 기본',
      description: '바둑이 포커 기본 규칙을 학습합니다',
      icon: '🎴',
      difficulty: 'BEGINNER',
      steps: [
        {
          title: '바둑이 포커에 오신 것을 환영합니다! 👋',
          content: '바둑이는 4장의 카드로 최고의 조합을 만드는 포커 게임입니다.\n\n같은 무늬가 없고 서로 다른 숫자의 카드가 많을수록 강력한 핸드가 됩니다.',
          target: '#game-table',
          position: 'center',
          action: null,
          highlight: true
        },
        {
          title: '카드 받기 🃏',
          content: '각 플레이어는 4장의 카드를 받습니다.\n\n자신의 카드만 볼 수 있으며, 다른 플레이어의 카드는 보이지 않습니다.',
          target: '#player-hand',
          position: 'bottom',
          action: 'deal',
          highlight: true
        },
        {
          title: '베팅 라운드 1 💰',
          content: '첫 번째 베팅 라운드입니다.\n\n다음 액션을 선택할 수 있습니다:\n• 베팅: 칩을 걸고 게임 진행\n• 체크: 베팅 없이 다음 플레이어로\n• 폴드: 게임 포기\n• 올인: 모든 칩 걸기',
          target: '#action-buttons',
          position: 'top',
          action: 'bet1',
          highlight: true
        },
        {
          title: '카드 교환 1 🔄',
          content: '원하는 카드를 선택하고 교환 버튼을 누르세요.\n\n0~4장의 카드를 교환할 수 있으며, 이때 전략이 중요합니다!',
          target: '#player-hand',
          position: 'bottom',
          action: 'draw1',
          highlight: true
        },
        {
          title: '베팅 라운드 2 💰',
          content: '두 번째 베팅 라운드입니다.\n\n첫 베팅과 같은 방식으로 진행됩니다.',
          target: '#action-buttons',
          position: 'top',
          action: 'bet2',
          highlight: true
        },
        {
          title: '카드 교환 2 🔄',
          content: '두 번째이자 마지막 카드 교환 기회입니다.\n\n이제 최종 핸드를 만들 차례입니다.',
          target: '#player-hand',
          position: 'bottom',
          action: 'draw2',
          highlight: true
        },
        {
          title: '쇼다운! 🎯',
          content: '모든 플레이어가 카드를 공개하고 승부를 가립니다.\n\n가장 강한 핸드가 팟을 가져갑니다.',
          target: '#game-table',
          position: 'center',
          action: 'showdown',
          highlight: true
        }
      ]
    },
    firstGame: {
      id: 'first_game',
      name: '첫 게임 가이드',
      description: '처음 게임을 플레이하는 방법을 안내합니다',
      icon: '🌟',
      difficulty: 'BEGINNER',
      steps: [
        {
          title: '첫 게임 시작! 🎮',
          content: '축하합니다! 이제 첫 번째 게임을 시작합니다.\n\n안내에 따라 게임을 진행해보세요.',
          target: '#game-table',
          position: 'center',
          action: null,
          highlight: true
        },
        {
          title: '자신의 핸드 확인 👀',
          content: '자신의 4장의 카드를 확인하고 어떤 카드를 교환할지 생각해보세요.\n\n같은 무늬가 없고 낮은 숫자일수록 좋습니다.',
          target: '#player-hand',
          position: 'bottom',
          action: null,
          highlight: true
        },
        {
          title: '교환할 카드 선택 ☑️',
          content: '교환하고 싶은 카드를 클릭하여 선택하세요.\n\n선택한 카드는 빨간 테두리로 표시됩니다.',
          target: '#player-hand',
          position: 'bottom',
          action: 'select',
          highlight: true
        },
        {
          title: '교환 버튼 클릭 🔄',
          content: '선택한 카드를 교환하려면 "교환" 버튼을 클릭하세요.\n\n0장을 선택하고 교환하면 모두 교환합니다 (스탠드 패트)',
          target: '#action-buttons',
          position: 'top',
          action: 'draw',
          highlight: true
        },
        {
          title: '새 카드 확인! ✨',
          content: '선택한 카드가 새로운 카드로 교환되었습니다.\n\n이제 핸드가 얼마나 강력해졌는지 확인해보세요.',
          target: '#player-hand',
          position: 'bottom',
          action: null,
          highlight: true
        },
        {
          title: '베팅 또는 체크 💰',
          content: '자신의 핸드가 강력하다면 베팅을 하고,\n\n확실하지 않다면 체크를 할 수도 있습니다.',
          target: '#action-buttons',
          position: 'top',
          action: null,
          highlight: true
        },
        {
          title: '쇼다운 승리? 🏆',
          content: '쇼다운에서 상대방보다 강한 핸드를 가지면 승리합니다!\n\n첫 승리를 목표로 도전해보세요!',
          target: '#game-table',
          position: 'center',
          action: null,
          highlight: true
        }
      ]
    },
    advanced: {
      id: 'advanced',
      name: '고급 전략',
      description: '바둑이 심화 전략과 확률을 학습합니다',
      icon: '🎯',
      difficulty: 'ADVANCED',
      steps: [
        {
          title: '바둑이 핸드 랭킹 📊',
          content: '핸드 강도 순서:\n\n1️⃣ 바둑이 (4카드): 최고!\n2️⃣ 쓰리카드 (3카드)\n3️⃣ 투카드 (2카드)\n4️⃣ 원카드 (1카드): 최악\n\n같은 카드 수라면 숫자 합이 작을수록 강합니다.',
          target: '#game-table',
          position: 'center',
          action: null,
          highlight: false
        },
        {
          title: '스타팅 핸드 평가 🔍',
          content: '좋은 스타팅 핸드:\n• 바둑이 가능한 핸드\n• 3장이 바둑이 가능한 핸드\n• 낮은 숫자 중심의 핸드\n\n나쁜 스타팅 핸드:\n• 같은 무늬가 많은 핸드\n• 높은 숫자 중심의 핸드\n• 모두 다른 무느지만 숫자가 높은 핸드',
          target: '#player-hand',
          position: 'bottom',
          action: null,
          highlight: false
        },
        {
          title: '첫 번째 교환 전략 🎯',
          content: '첫 교환에서의 전략:\n\n• 바둑이: 0장 교환 (스탠드 패트)\n• 쓰리카드: 1장 교환으로 바둑이 목표\n• 투카드: 2장 교환으로 쓰리카드 목표\n• 원카드: 3장 교환으로 바둑이 도전',
          target: '#player-hand',
          position: 'bottom',
          action: null,
          highlight: false
        },
        {
          title: '포지션과 액션 📍',
          content: '포지션의 중요성:\n\n• 늦은 포지션: 다른 플레이어의 액션을 보고 결정 가능\n• 빠른 포지션: 정보 부족으로 어려운 결정\n\n포지션을 고려하여 베팅과 교환을 결정하세요.',
          target: '#game-table',
          position: 'center',
          action: null,
          highlight: false
        },
        {
          title: '확률 계산 📐',
          content: '바둑이 완성 확률:\n\n• 4장 중 바둑이: 약 6%\n• 3장 보유 시 4번째 카드로 완성: 약 20%\n• 2장 보유 시 2장으로 완성: 약 4%\n\n이 확률을 고려하여 교환을 결정하세요.',
          target: '#game-table',
          position: 'center',
          action: null,
          highlight: false
        },
        {
          title: '블러핑과 심리전 🎭',
          content: '심리전 요소:\n\n• 공격적인 베팅으로 강한 핸드 흉내\n• 패시브 플레이로 약한 핸드 숨기기\n• 상대방의 교환 패턴 관찰\n• 베팅 패턴에서 텔(징후) 읽기\n\n상대방의 플레이 스타일을 파악하세요!',
          target: '#action-buttons',
          position: 'top',
          action: null,
          highlight: false
        },
        {
          title: '뱅크롤 관리 💰',
          content: '자금 관리 원칙:\n\n• 한 게임에 전체의 5-10%만 베팅\n• 연속 패배 시 휴식 또는 하향 이동\n• 승리 시 기분 좋게 중단하는 것도 방법\n• 감정에 휘둘리지 않는 냉철함 유지\n\n장기적인 관점에서 접근하세요!',
          target: '#chips-display',
          position: 'top',
          action: null,
          highlight: false
        }
      ]
    },
    tournament: {
      id: 'tournament',
      name: '토너먼트 가이드',
      description: '토너먼트 참가 방법을 안내합니다',
      icon: '🏆',
      difficulty: 'INTERMEDIATE',
      steps: [
        {
          title: '토너먼트 입장 🏆',
          content: '토너먼트는 여러 플레이어가 경쟁하는 대회입니다.\n\n참가비를 내고 시작하며, 최후까지 남은 플레이어가 우승합니다!',
          target: '#tournament-list',
          position: 'center',
          action: null,
          highlight: true
        },
        {
          title: '토너먼트 목록 보기 📋',
          content: '메인 화면에서 "토너먼트" 버튼을 클릭하세요.\n\n참가 가능한 토너먼트 목록이 표시됩니다.',
          target: '#tournament-list',
          position: 'center',
          action: null,
          highlight: true
        },
        {
          title: '토너먼트 선택 🔍',
          content: '원하는 토너먼트를 선택하고 상세 정보를 확인하세요.\n\n• 참가비: 입장에 필요한 칩\n• 플레이어 수: 전체 참가자\n• 상금: 순위별 보상\n• 현재 참가자: 등록된 인원',
          target: '#tournament-detail',
          position: 'center',
          action: null,
          highlight: true
        },
        {
          title: '참가 신청 📝',
          content: '"참가하기" 버튼을 클릭하여 신청하세요.\n\n참가비가 차감되며, 토너먼트 대기실로 이동합니다.',
          target: '#btn-tournament-join',
          position: 'bottom',
          action: null,
          highlight: true
        },
        {
          title: '토너먼트 시작 ▶️',
          content: '정해진 인원이 모이면 토너먼트가 자동으로 시작됩니다.\n\n테이블이 배정되고 게임이 시작됩니다.',
          target: '#game-table',
          position: 'center',
          action: null,
          highlight: true
        },
        {
          title: '블라인드 증가 ⏱️',
          content: '토너먼트는 정해진 시간마다 블라인드가 증가합니다.\n\n• 레벨 1: 50/100\n• 레벨 2: 100/200\n• 레벨 3: 150/300\n\n시간이 지날수록 더 공격적으로 플레이해야 합니다!',
          target: '#blind-display',
          position: 'top',
          action: null,
          highlight: true
        },
        {
          title: '탈락과 생존 💀',
          content: '칩이 모두 고갈되면 탈락합니다.\n\n마지막까지 남아 우승을 차지하세요!\n\n• 우승: 전체 상금의 50%\n• 2위: 30%\n• 3위: 20%',
          target: '#game-table',
          position: 'center',
          action: null,
          highlight: true
        }
      ]
    }
  };

  // 현재 튜토리얼 상태
  let currentTutorial = null;
  let currentStep = 0;
  let overlayElement = null;
  let highlightElement = null;
  let tooltipElement = null;

  // 완료한 튜토리얼
  let completedTutorials = new Set();

  // 데이터 로드
  function loadProgress() {
    const saved = localStorage.getItem('badugi_tutorial_progress');
    if (saved) {
      completedTutorials = new Set(JSON.parse(saved));
    }
  }

  // 데이터 저장
  function saveProgress() {
    localStorage.setItem('badugi_tutorial_progress', JSON.stringify([...completedTutorials]));
  }

  // 오버레이 생성
  function createOverlay() {
    if (overlayElement) return;

    overlayElement = document.createElement('div');
    overlayElement.id = 'tutorial-overlay';
    overlayElement.className = 'tutorial-overlay';
    overlayElement.innerHTML = `
      <div class="tutorial-highlight"></div>
      <div class="tutorial-tooltip">
        <div class="tutorial-header">
          <div class="tutorial-progress">
            <span class="current-step">1</span> / <span class="total-steps">5</span>
          </div>
          <button class="tutorial-close" onclick="Tutorial.skip()">×</button>
        </div>
        <div class="tutorial-content">
          <h3 class="tutorial-title"></h3>
          <div class="tutorial-body"></div>
        </div>
        <div class="tutorial-footer">
          <button class="btn btn-prev" onclick="Tutorial.prevStep()">이전</button>
          <button class="btn btn-next" onclick="Tutorial.nextStep()">다음</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlayElement);

    highlightElement = overlayElement.querySelector('.tutorial-highlight');
    tooltipElement = overlayElement.querySelector('.tutorial-tooltip');
  }

  // 오버레이 제거
  function removeOverlay() {
    if (overlayElement) {
      overlayElement.remove();
      overlayElement = null;
      highlightElement = null;
      tooltipElement = null;
    }
  }

  // 하이라이트 업데이트
  function updateHighlight(target, position) {
    if (!highlightElement || !tooltipElement) return;

    const targetElement = document.querySelector(target);
    if (targetElement) {
      const rect = targetElement.getBoundingClientRect();
      const padding = 8;

      highlightElement.style.display = 'block';
      highlightElement.style.left = rect.left - padding + 'px';
      highlightElement.style.top = rect.top - padding + 'px';
      highlightElement.style.width = rect.width + padding * 2 + 'px';
      highlightElement.style.height = rect.height + padding * 2 + 'px';

      // 툴팁 위치 설정
      const tooltipRect = tooltipElement.getBoundingClientRect();
      let tooltipLeft, tooltipTop;

      switch (position) {
        case 'top':
          tooltipLeft = rect.left + rect.width / 2 - tooltipRect.width / 2;
          tooltipTop = rect.top - tooltipRect.height - 16;
          break;
        case 'bottom':
          tooltipLeft = rect.left + rect.width / 2 - tooltipRect.width / 2;
          tooltipTop = rect.bottom + 16;
          break;
        case 'left':
          tooltipLeft = rect.left - tooltipRect.width - 16;
          tooltipTop = rect.top + rect.height / 2 - tooltipRect.height / 2;
          break;
        case 'right':
          tooltipLeft = rect.right + 16;
          tooltipTop = rect.top + rect.height / 2 - tooltipRect.height / 2;
          break;
        case 'center':
        default:
          tooltipLeft = window.innerWidth / 2 - tooltipRect.width / 2;
          tooltipTop = window.innerHeight / 2 - tooltipRect.height / 2;
          break;
      }

      // 화면 밖으로 나가는 경우 보정
      if (tooltipLeft < 16) tooltipLeft = 16;
      if (tooltipTop < 16) tooltipTop = 16;
      if (tooltipLeft + tooltipRect.width > window.innerWidth - 16) {
        tooltipLeft = window.innerWidth - tooltipRect.width - 16;
      }
      if (tooltipTop + tooltipRect.height > window.innerHeight - 16) {
        tooltipTop = window.innerHeight - tooltipRect.height - 16;
      }

      tooltipElement.style.left = tooltipLeft + 'px';
      tooltipElement.style.top = tooltipTop + 'px';
    } else {
      highlightElement.style.display = 'none';
      tooltipElement.style.left = window.innerWidth / 2 - tooltipElement.offsetWidth / 2 + 'px';
      tooltipElement.style.top = window.innerHeight / 2 - tooltipElement.offsetHeight / 2 + 'px';
    }
  }

  // 스텝 렌더링
  function renderStep() {
    if (!currentTutorial || !overlayElement) return;

    const tutorial = TUTORIALS[currentTutorial];
    const step = tutorial.steps[currentStep];

    // 진행률 업데이트
    const currentStepEl = tooltipElement.querySelector('.current-step');
    const totalStepsEl = tooltipElement.querySelector('.total-steps');
    currentStepEl.textContent = currentStep + 1;
    totalStepsEl.textContent = tutorial.steps.length;

    // 제목과 내용
    const titleEl = tooltipElement.querySelector('.tutorial-title');
    const bodyEl = tooltipElement.querySelector('.tutorial-body');
    titleEl.textContent = step.title;
    bodyEl.innerHTML = step.content.replace(/\n/g, '<br>');

    // 하이라이트 업데이트
    if (step.highlight) {
      updateHighlight(step.target, step.position);
    } else {
      highlightElement.style.display = 'none';
    }

    // 버튼 상태
    const prevBtn = tooltipElement.querySelector('.btn-prev');
    const nextBtn = tooltipElement.querySelector('.btn-next');
    prevBtn.disabled = currentStep === 0;
    prevBtn.classList.toggle('disabled', currentStep === 0);

    if (currentStep === tutorial.steps.length - 1) {
      nextBtn.textContent = '완료';
    } else {
      nextBtn.textContent = '다음';
    }
  }

  // 튜토리얼 시작
  function start(tutorialId) {
    if (!TUTORIALS[tutorialId]) {
      console.error(`Tutorial not found: ${tutorialId}`);
      return;
    }

    loadProgress();

    if (completedTutorials.has(tutorialId)) {
      if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
        UI.showToast('info', '이미 완료한 튜토리얼입니다.');
      }
      return;
    }

    currentTutorial = tutorialId;
    currentStep = 0;

    createOverlay();
    renderStep();

    // 첫 번째 게임 튜토리얼 자동 시작 체크
    if (tutorialId === 'first_game') {
      const hasPlayed = localStorage.getItem('badugi_games_played');
      if (!hasPlayed || parseInt(hasPlayed) === 0) {
        start('first_game');
      }
    }
  }

  // 다음 스텝
  function nextStep() {
    if (!currentTutorial) return;

    const tutorial = TUTORIALS[currentTutorial];
    const step = tutorial.steps[currentStep];

    // 액션 실행
    if (step.action) {
      executeAction(step.action);
    }

    currentStep++;

    if (currentStep >= tutorial.steps.length) {
      complete();
    } else {
      renderStep();
    }
  }

  // 이전 스텝
  function prevStep() {
    if (!currentTutorial || currentStep === 0) return;

    currentStep--;
    renderStep();
  }

  // 액션 실행
  function executeAction(action) {
    // 게임 상태에 따른 액션 처리
    console.log('Tutorial action:', action);
  }

  // 완료
  function complete() {
    if (!currentTutorial) return;

    completedTutorials.add(currentTutorial);
    saveProgress();

    const tutorial = TUTORIALS[currentTutorial];

    if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
      UI.showToast(
        'success',
        '🎉 튜토리얼 완료!',
        `${tutorial.icon} ${tutorial.name}`
      );
    }

    removeOverlay();
    currentTutorial = null;
    currentStep = 0;

    // 첫 게임 보상
    if (completedTutorials.has('first_game')) {
      if (typeof State !== 'undefined') {
        State.addChips(10000);
      }
      if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
        UI.showToast('보상: 10,000칩 지급!');
      }
    }
  }

  // 스킵
  function skip() {
    removeOverlay();
    currentTutorial = null;
    currentStep = 0;
  }

  // 튜토리얼 리스트 렌더링
  function renderTutorialList() {
    const container = document.getElementById('tutorial-list');
    if (!container) return;

    loadProgress();

    container.innerHTML = Object.values(TUTORIALS).map(tutorial => {
      const isCompleted = completedTutorials.has(tutorial.id);

      return `
        <div class="tutorial-item ${isCompleted ? 'completed' : ''}" data-tutorial-id="${tutorial.id}">
          <div class="tutorial-icon">${tutorial.icon}</div>
          <div class="tutorial-info">
            <div class="tutorial-name">${tutorial.name}</div>
            <div class="tutorial-desc">${tutorial.description}</div>
            <div class="tutorial-meta">
              <span class="difficulty-${tutorial.difficulty.toLowerCase()}">${getDifficultyText(tutorial.difficulty)}</span>
              <span class="step-count">${tutorial.steps.length}단계</span>
            </div>
          </div>
          <button class="btn ${isCompleted ? 'btn-disabled' : 'btn-primary'}"
                  onclick="Tutorial.start('${tutorial.id}')"
                  ${isCompleted ? 'disabled' : ''}>
            ${isCompleted ? '완료됨' : '시작하기'}
          </button>
        </div>
      `;
    }).join('');
  }

  // 난이도 텍스트
  function getDifficultyText(difficulty) {
    const texts = {
      BEGINNER: '입문',
      INTERMEDIATE: '중급',
      ADVANCED: '고급'
    };
    return texts[difficulty] || difficulty;
  }

  // 모달 열기
  function openModal() {
    const modal = document.getElementById('tutorial-modal');
    if (modal) {
      modal.classList.remove('hidden');
      renderTutorialList();
    }
  }

  // 모달 닫기
  function closeModal() {
    const modal = document.getElementById('tutorial-modal');
    if (modal) {
      modal.classList.add('hidden');
    }
  }

  // 첫 게임 플레이 체크
  function checkFirstGame() {
    const gamesPlayed = localStorage.getItem('badugi_games_played');
    if (!gamesPlayed || parseInt(gamesPlayed) === 0) {
      if (!completedTutorials.has('first_game')) {
        setTimeout(() => {
          if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
            UI.showToast(
              'info',
              '🌟 첫 게임 가이드',
              '튜토리얼에서 게임 방법을 배워보세요!',
              null,
              () => start('first_game')
            );
          }
        }, 2000);
      }
    }
  }

  // 완료 여부
  function isCompleted(tutorialId) {
    loadProgress();
    return completedTutorials.has(tutorialId);
  }

  // 모든 튜토리얼 완료 여부
  function isAllCompleted() {
    loadProgress();
    return Object.keys(TUTORIALS).every(id => completedTutorials.has(id));
  }

  // 초기화
  function init() {
    loadProgress();
    checkFirstGame();
  }

  // 공개 API
  return {
    init,
    start,
    nextStep,
    prevStep,
    skip,
    complete,
    openModal,
    closeModal,
    isCompleted,
    isAllCompleted,
    renderTutorialList
  };
})();

// 전역 노출
window.Tutorial = Tutorial;
