/* ==========================================
   사운드 생성기 (Web Audio API)
   사운드 파일 없이도 기본 효과음 재생 가능
   ========================================== */

const SoundGenerator = {

  audioContext: null,

  // 오디오 컨텍스트 초기화
  getAudioContext() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
    return this.audioContext;
  },

  // 기본 비프음 생성
  playBeep(frequency = 440, duration = 0.1, volume = 0.3, type = 'sine') {
    try {
      const ctx = this.getAudioContext();

      const oscillator = ctx.createOscillator();
      const gainNode = ctx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(ctx.destination);

      oscillator.frequency.value = frequency;
      oscillator.type = type;

      gainNode.gain.setValueAtTime(volume, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      oscillator.start(ctx.currentTime);
      oscillator.stop(ctx.currentTime + duration);
    } catch (e) {
      // 오디오 컨텍스트 에러 무시
    }
  },

  // 버튼 클릭음
  buttonClick() {
    this.playBeep(800, 0.05, 0.2);
  },

  // 카드 딜링음
  cardDeal() {
    this.playBeep(300, 0.08, 0.15);
    setTimeout(() => this.playBeep(350, 0.05, 0.1), 30);
  },

  // 카드 선택음
  cardSelect() {
    this.playBeep(600, 0.05, 0.15);
  },

  // 칩 베팅음
  chipBet() {
    this.playBeep(500, 0.05, 0.2);
    setTimeout(() => this.playBeep(600, 0.05, 0.15), 50);
  },

  // 칩 획득음
  chipWin() {
    this.playBeep(523, 0.1, 0.2); // C
    setTimeout(() => this.playBeep(659, 0.1, 0.2), 100); // E
    setTimeout(() => this.playBeep(784, 0.15, 0.25), 200); // G
  },

  // 칩 손실음
  chipLose() {
    this.playBeep(400, 0.1, 0.15);
    setTimeout(() => this.playBeep(300, 0.15, 0.1), 100);
  },

  // 폴드음
  fold() {
    this.playBeep(200, 0.15, 0.15, 'triangle');
  },

  // 체크음
  check() {
    this.playBeep(400, 0.05, 0.1);
    setTimeout(() => this.playBeep(400, 0.05, 0.1), 60);
  },

  // 콜음
  call() {
    this.playBeep(500, 0.08, 0.2);
  },

  // 레이즈음
  raise() {
    this.playBeep(600, 0.08, 0.2);
    setTimeout(() => this.playBeep(700, 0.08, 0.2), 80);
  },

  // 올인음
  allin() {
    this.playBeep(400, 0.1, 0.25);
    setTimeout(() => this.playBeep(500, 0.1, 0.25), 100);
    setTimeout(() => this.playBeep(600, 0.1, 0.25), 200);
    setTimeout(() => this.playBeep(800, 0.2, 0.3), 300);
  },

  // 턴 알림음
  turnNotify() {
    this.playBeep(880, 0.1, 0.2);
    setTimeout(() => this.playBeep(880, 0.1, 0.2), 150);
  },

  // 타이머 경고음
  timerWarning() {
    this.playBeep(1000, 0.05, 0.15);
  },

  // 승리 팡파레
  win() {
    const notes = [523, 659, 784, 1047]; // C E G C
    notes.forEach((freq, i) => {
      setTimeout(() => this.playBeep(freq, 0.15, 0.2), i * 120);
    });
  },

  // 패배음
  lose() {
    this.playBeep(400, 0.2, 0.15);
    setTimeout(() => this.playBeep(350, 0.2, 0.12), 150);
    setTimeout(() => this.playBeep(300, 0.3, 0.1), 300);
  },

  // 쇼다운음
  showdown() {
    this.playBeep(600, 0.1, 0.2);
    setTimeout(() => this.playBeep(800, 0.1, 0.2), 100);
    setTimeout(() => this.playBeep(1000, 0.15, 0.25), 200);
  },

  // 업적 달성음
  achievement() {
    const notes = [784, 988, 1175, 1568]; // G B D G
    notes.forEach((freq, i) => {
      setTimeout(() => this.playBeep(freq, 0.12, 0.2), i * 80);
    });
  },

  // 레벨업음
  levelUp() {
    const notes = [523, 659, 784, 880, 1047]; // C E G A C
    notes.forEach((freq, i) => {
      setTimeout(() => this.playBeep(freq, 0.1, 0.2), i * 100);
    });
  },

  // 일일 보상음
  dailyReward() {
    this.playBeep(700, 0.1, 0.2);
    setTimeout(() => this.playBeep(880, 0.1, 0.2), 100);
    setTimeout(() => this.playBeep(1100, 0.15, 0.25), 200);
  },

  // 스핀 시작음
  spinStart() {
    this.playBeep(400, 0.1, 0.15);
  },

  // 스핀 틱음
  spinTick() {
    this.playBeep(600 + Math.random() * 200, 0.03, 0.1);
  },

  // 스핀 당첨음
  spinWin() {
    const notes = [523, 659, 784, 1047];
    notes.forEach((freq, i) => {
      setTimeout(() => this.playBeep(freq, 0.15, 0.25), i * 100);
    });
  },

  // 잭팟음
  jackpot() {
    const pattern = [
      [523, 0.1], [659, 0.1], [784, 0.1], [1047, 0.15],
      [784, 0.1], [1047, 0.1], [1319, 0.2]
    ];
    let delay = 0;
    pattern.forEach(([freq, dur]) => {
      setTimeout(() => this.playBeep(freq, dur, 0.3), delay);
      delay += dur * 1000 + 50;
    });
  },

  // 모달 열기
  modalOpen() {
    this.playBeep(500, 0.05, 0.1);
    setTimeout(() => this.playBeep(700, 0.05, 0.1), 50);
  },

  // 모달 닫기
  modalClose() {
    this.playBeep(600, 0.05, 0.1);
    setTimeout(() => this.playBeep(400, 0.05, 0.08), 50);
  },

  // 알림음
  notification() {
    this.playBeep(880, 0.08, 0.15);
    setTimeout(() => this.playBeep(1100, 0.08, 0.15), 100);
  },

  // 에러음
  error() {
    this.playBeep(200, 0.15, 0.2, 'sawtooth');
  }
};
