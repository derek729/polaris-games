/* ==========================================
   애니메이션 매니저 - 강화 버전
   ========================================== */

const AnimationManager = {

  // 설정
  CONFIG: {
    ENABLED: true,
    CARD_DEAL_DURATION: 300,
    CARD_FLIP_DURATION: 400,
    CHIP_MOVE_DURATION: 500,
    CELEBRATION_DURATION: 2000,
    FLYING_CARD_SPEED: 800,
    PARTICLE_COUNT: 30,
    CONFETTI_COUNT: 100
  },

  // 활성 애니메이션 추적
  activeAnimations: new Set(),
  particleSystem: null,

  // 초기화
  init() {
    this.createParticleSystem();
    console.log('[AnimationManager] 초기화 완료');
  },

  /* ==========================================
     파티클 시스템
     ========================================== */

  createParticleSystem() {
    this.particleSystem = document.createElement('div');
    this.particleSystem.id = 'particle-system';
    this.particleSystem.style.cssText = `
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 9999;
      overflow: hidden;
    `;
    document.body.appendChild(this.particleSystem);
  },

  /* ==========================================
     카드 애니메이션 (강화)
     ========================================== */

  // 날아가는 카드 효과
  async flyCard(fromPosition, toPosition, options = {}) {
    if (!this.CONFIG.ENABLED) return;

    const {
      card = null,
      duration = this.CONFIG.FLYING_CARD_SPEED,
      delay = 0,
      arc = 100,
      rotation = 720
    } = options;

    const flyingCard = card || this.createFlyingCard();
    flyingCard.style.cssText = `
      position: fixed;
      left: ${fromPosition.x}px;
      top: ${fromPosition.y}px;
      width: 60px;
      height: 84px;
      z-index: 10000;
      transform-origin: center center;
    `;

    if (!card) {
      this.particleSystem.appendChild(flyingCard);
    } else {
      document.body.appendChild(flyingCard);
    }

    // 애니메이션 시작
    await Utils.delay(delay);

    const dx = toPosition.x - fromPosition.x;
    const dy = toPosition.y - fromPosition.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    // 곡선 경로 계산
    const midX = (fromPosition.x + toPosition.x) / 2;
    const midY = Math.min(fromPosition.y, toPosition.y) - arc - distance * 0.1;

    const keyframes = [
      { offset: 0, transform: 'translate(0, 0) rotate(0deg) scale(1)', opacity: 1 },
      { offset: 0.3, transform: `translate(${(midX - fromPosition.x) * 0.5}px, ${midY - fromPosition.y}px) rotate(${rotation * 0.3}deg) scale(0.8)`, opacity: 1 },
      { offset: 0.7, transform: `translate(${(midX - fromPosition.x) * 0.8}px, ${midY - fromPosition.y}px) rotate(${rotation * 0.7}deg) scale(0.9)`, opacity: 1 },
      { offset: 1, transform: `translate(${dx}px, ${dy}px) rotate(${rotation}deg) scale(0.5)`, opacity: 0 }
    ];

    const animation = flyingCard.animate(keyframes, {
      duration: duration,
      easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)'
    });

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playCardDeal();
    }

    await animation.finished;
    flyingCard.remove();
  },

  // 여러 카드가 동시에 날아가는 효과
  async flyCardsMultiple(fromPosition, toPosition, count, options = {}) {
    const { staggerDelay = 80 } = options;

    const promises = [];
    for (let i = 0; i < count; i++) {
      const card = this.createFlyingCard();
      promises.push(this.flyCard(fromPosition, toPosition, {
        ...options,
        card,
        delay: i * staggerDelay,
        arc: options.arc + i * 20
      }));
    }

    await Promise.all(promises);
  },

  // 카드 요소 생성
  createFlyingCard() {
    const card = document.createElement('div');
    card.className = 'flying-card';
    card.innerHTML = `
      <div class="flying-card-front">
        <div class="flying-card-corner top-left">A♠</div>
        <div class="flying-card-center">🂡</div>
        <div class="flying-card-corner bottom-right">A♠</div>
      </div>
    `;
    return card;
  },

  // 카드 딜링 애니메이션
  async dealCards(playerIndex, cardCount = 4) {
    if (!this.CONFIG.ENABLED) return;

    const playerArea = Utils.$(`#player-${playerIndex}-area`);
    if (!playerArea) return;

    const deckPosition = this.getDeckPosition();

    // 날아가는 카드 효과 사용
    for (let i = 0; i < cardCount; i++) {
      await this.flyCard(deckPosition, {
        x: deckPosition.x + (Math.random() - 0.5) * 100,
        y: deckPosition.y + 100 + i * 30
      }, {
        arc: 150 + i * 30,
        rotation: 360 + Math.random() * 360
      });
    }

    // 실제 카드 렌더링
    Renderer.renderMyCards();

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playCardDeal();
    }
  },

  /* ==========================================
     카드 애니메이션
     ========================================== */

  // 카드 딜링 애니메이션
  async dealCards(playerIndex, cardCount = 4) {
    if (!this.CONFIG.ENABLED) return;

    const playerArea = Utils.$(`#player-${playerIndex}-area`);
    if (!playerArea) return;

    const cardsContainer = playerArea.querySelector('.cards-container');
    if (!cardsContainer) return;

    const deckPosition = this.getDeckPosition();
    const cards = cardsContainer.querySelectorAll('.playing-card');

    for (let i = 0; i < cards.length; i++) {
      const card = cards[i];
      const targetRect = card.getBoundingClientRect();

      // 초기 위치 (덱에서)
      card.style.position = 'relative';
      card.style.opacity = '0';
      card.style.transform = `translate(${deckPosition.x - targetRect.left}px, ${deckPosition.y - targetRect.top}px) scale(0.5) rotateY(180deg)`;

      await Utils.delay(100);

      // 애니메이션 시작
      card.style.transition = `all ${this.CONFIG.CARD_DEAL_DURATION}ms cubic-bezier(0.25, 0.46, 0.45, 0.94)`;
      card.style.opacity = '1';
      card.style.transform = 'translate(0, 0) scale(1) rotateY(0deg)';

      if (typeof SoundManager !== 'undefined') {
        SoundManager.playCardDeal();
      }

      await Utils.delay(this.CONFIG.CARD_DEAL_DURATION * 0.5);
    }

    // 트랜지션 정리
    cards.forEach(card => {
      card.style.transition = '';
      card.style.position = '';
    });
  },

  // 덱 위치 가져오기
  getDeckPosition() {
    const table = Utils.$('#game-table');
    if (!table) return { x: window.innerWidth / 2, y: window.innerHeight / 2 };

    const rect = table.getBoundingClientRect();
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2
    };
  },

  // 카드 플립 애니메이션
  async flipCard(cardElement, showFront = true) {
    if (!this.CONFIG.ENABLED || !cardElement) return;

    cardElement.style.transition = `transform ${this.CONFIG.CARD_FLIP_DURATION}ms`;
    cardElement.style.transform = 'rotateY(90deg)';

    await Utils.delay(this.CONFIG.CARD_FLIP_DURATION / 2);

    // 카드 내용 변경 (콜백으로 처리)
    cardElement.classList.toggle('card-back', !showFront);
    cardElement.classList.toggle('card-front', showFront);

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playCardFlip();
    }

    cardElement.style.transform = 'rotateY(0deg)';

    await Utils.delay(this.CONFIG.CARD_FLIP_DURATION / 2);
    cardElement.style.transition = '';
  },

  // 카드 선택 애니메이션
  selectCard(cardElement, selected = true) {
    if (!cardElement) return;

    if (selected) {
      cardElement.classList.add('card-selected');
      cardElement.style.animation = 'cardSelect 0.3s ease-out';
    } else {
      cardElement.classList.remove('card-selected');
      cardElement.style.animation = 'cardDeselect 0.3s ease-out';
    }

    setTimeout(() => {
      cardElement.style.animation = '';
    }, 300);
  },

  // 카드 교환 애니메이션
  async exchangeCards(playerIndex, cardIndices) {
    if (!this.CONFIG.ENABLED) return;

    const playerArea = Utils.$(`#player-${playerIndex}-area`);
    if (!playerArea) return;

    const cards = playerArea.querySelectorAll('.playing-card');
    const deckPosition = this.getDeckPosition();

    // 선택된 카드들을 덱으로 이동
    for (const index of cardIndices) {
      const card = cards[index];
      if (!card) continue;

      const rect = card.getBoundingClientRect();

      card.style.transition = 'all 0.3s ease-in';
      card.style.transform = `translate(${deckPosition.x - rect.left - rect.width/2}px, ${deckPosition.y - rect.top - rect.height/2}px) scale(0.5) rotateY(180deg)`;
      card.style.opacity = '0';

      if (typeof SoundManager !== 'undefined') {
        SoundManager.playCardDeal();
      }

      await Utils.delay(100);
    }

    await Utils.delay(300);

    // 새 카드 받기 애니메이션은 렌더링 후 dealCards로 처리
  },

  /* ==========================================
     칩 애니메이션 (강화)
     ========================================== */

  // 칩 베팅 애니메이션 (강화)
  async betChips(fromPlayerIndex, amount) {
    if (!this.CONFIG.ENABLED) return;

    const fromArea = Utils.$(`#player-${fromPlayerIndex}-area`);
    const potArea = this.getDeckPosition();

    if (!fromArea) return;

    const fromRect = fromArea.getBoundingClientRect();
    const toPosition = { x: potArea.x + (Math.random() - 0.5) * 60, y: potArea.y + (Math.random() - 0.5) * 60 };
    const fromPosition = { x: fromRect.left + fromRect.width / 2, y: fromRect.top + fromRect.height / 2 };

    // 칩 수 계산
    const chipCount = Math.min(5, Math.max(1, Math.ceil(amount / 5000)));

    for (let i = 0; i < chipCount; i++) {
      const chip = this.createAnimatedChip(amount / chipCount);
      chip.style.left = `${fromPosition.x + (Math.random() - 0.5) * 30}px`;
      chip.style.top = `${fromPosition.y + (Math.random() - 0.5) * 30}px`;

      this.particleSystem.appendChild(chip);

      // 애니메이션
      const offsetX = toPosition.x - fromPosition.x + (Math.random() - 0.5) * 40;
      const offsetY = toPosition.y - fromPosition.y + (Math.random() - 0.5) * 40;

      chip.animate([
        { transform: 'translate(0, 0) scale(1) rotate(0deg)', opacity: 1 },
        { transform: `translate(${offsetX * 0.3}px, ${offsetY * 0.3 - 50}px) scale(0.8) rotate(90deg)`, opacity: 1 },
        { transform: `translate(${offsetX}px, ${offsetY}px) scale(0.6) rotate(180deg)`, opacity: 0.8 }
      ], {
        duration: this.CONFIG.CHIP_MOVE_DURATION,
        easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        delay: i * 60,
        fill: 'forwards'
      });

      await Utils.delay(60);
    }

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playChipBet();
    }

    await Utils.delay(this.CONFIG.CHIP_MOVE_DURATION);

    // 칩 제거
    const chips = this.particleSystem.querySelectorAll('.animated-chip');
    chips.forEach(chip => chip.remove());
  },

  // 칩 획득 애니메이션 (강화 - 폭죽 효과)
  async winChips(toPlayerIndex, amount) {
    if (!this.CONFIG.ENABLED) return;

    const potArea = this.getDeckPosition();
    const toArea = Utils.$(`#player-${toPlayerIndex}-area`);

    if (!toArea) return;

    const toRect = toArea.getBoundingClientRect();
    const toPosition = { x: toRect.left + toRect.width / 2, y: toRect.top + toRect.height / 2 };

    // 더 많은 칩 생성 (화려한 효과)
    const chipCount = Math.min(20, Math.ceil(amount / 1000));

    const chipPromises = [];

    for (let i = 0; i < chipCount; i++) {
      const chip = this.createAnimatedChip(amount / chipCount);

      const angle = (i / chipCount) * Math.PI * 2;
      const radius = 80 + Math.random() * 40;

      chip.style.left = `${potArea.x}px`;
      chip.style.top = `${potArea.y}px`;

      this.particleSystem.appendChild(chip);

      // 나선형으로 이동
      const spiralAnim = chip.animate([
        {
          transform: 'translate(0, 0) scale(0.5)',
          opacity: 1
        },
        {
          transform: `translate(${Math.cos(angle) * radius}px, ${Math.sin(angle) * radius - 100}px) scale(0.7)`,
          opacity: 1,
          offset: 0.3
        },
        {
          transform: `translate(${toPosition.x - potArea.x}px, ${toPosition.y - potArea.y}px) scale(1.2)`,
          opacity: 0,
          offset: 1
        }
      ], {
        duration: this.CONFIG.CHIP_MOVE_DURATION + 400,
        easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        delay: i * 40,
        fill: 'forwards'
      });

      chipPromises.push(spiralAnim.finished.then(() => chip.remove()));
    }

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playChipWin();
    }

    // 금빛 파티클 효과
    this.createGoldParticles(toPosition);

    await Promise.all(chipPromises);
  },

  // 금빛 파티클 효과
  createGoldParticles(position) {
    const particleCount = this.CONFIG.PARTICLE_COUNT;

    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'gold-particle';
      particle.style.cssText = `
        position: absolute;
        left: ${position.x}px;
        top: ${position.y}px;
        width: ${4 + Math.random() * 8}px;
        height: ${4 + Math.random() * 8}px;
        background: radial-gradient(circle, #fbbf24, #f59e0b);
        border-radius: 50%;
        box-shadow: 0 0 10px #fbbf24;
      `;

      this.particleSystem.appendChild(particle);

      const angle = Math.random() * Math.PI * 2;
      const velocity = 100 + Math.random() * 200;
      const vx = Math.cos(angle) * velocity;
      const vy = Math.sin(angle) * velocity - 100;

      particle.animate([
        {
          transform: 'translate(0, 0) scale(1)',
          opacity: 1
        },
        {
          transform: `translate(${vx}px, ${vy}px) scale(0)`,
          opacity: 0
        }
      ], {
        duration: 1000 + Math.random() * 500,
        easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        fill: 'forwards'
      }).finished.then(() => particle.remove());
    }
  },

  // 칩 요소 생성
  createAnimatedChip(amount) {
    const chip = document.createElement('div');
    chip.className = 'animated-chip';
    chip.innerHTML = `
      <div class="chip-stack-3d">
        <div class="chip-coin-3d chip-coin-back"></div>
        <div class="chip-coin-3d chip-coin-middle"></div>
        <div class="chip-coin-3d chip-coin-front"></div>
      </div>
    `;
    return chip;
  },

  // 팟 증가 애니메이션
  async animatePotIncrease(fromAmount, toAmount) {
    const potDisplay = Utils.$('#pot-display');
    if (!potDisplay) return;

    // 숫자 카운트업
    this.animateNumber(potDisplay, fromAmount, toAmount, 500);

    // 팟 주변 빛나는 효과
    const glow = document.createElement('div');
    glow.className = 'pot-glow';
    glow.style.cssText = `
      position: fixed;
      left: 50%;
      top: 45%;
      transform: translate(-50%, -50%);
      width: 100px;
      height: 100px;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.5), transparent);
      border-radius: 50%;
      pointer-events: none;
      z-index: 999;
    `;

    document.body.appendChild(glow);

    glow.animate([
      { transform: 'translate(-50%, -50%) scale(0)', opacity: 1 },
      { transform: 'translate(-50%, -50%) scale(2)', opacity: 0 }
    ], {
      duration: 600,
      easing: 'ease-out',
      fill: 'forwards'
    }).finished.then(() => glow.remove());
  },

  /* ==========================================
     승리/패배 애니메이션 (강화)
     ========================================== */

  // 승리 축하 애니메이션 (강화)
  async celebrateWin(playerIndex, amount = 0) {
    if (!this.CONFIG.ENABLED) return;

    // 컨페티 폭발
    this.showConfettiBurst();

    // 금빛 폭죽
    this.showGoldFireworks();

    // 플레이어 하이라이트
    const playerArea = Utils.$(`#player-${playerIndex}-area`);
    if (playerArea) {
      playerArea.classList.add('winner-highlight');

      // 빛나는 테두리 효과
      this.createGlowingBorder(playerArea);

      setTimeout(() => {
        playerArea.classList.remove('winner-highlight');
      }, this.CONFIG.CELEBRATION_DURATION);
    }

    // 승리 텍스트 애니메이션
    this.showFloatingText(amount > 0 ? `🎉 +${Utils.formatChips(amount)} 🎉` : '🎉 승리! 🎉', 'win');

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playWin();
    }
  },

  // 빛나는 테두리 효과
  createGlowingBorder(element) {
    const rect = element.getBoundingClientRect();
    const border = document.createElement('div');
    border.className = 'glowing-border';
    border.style.cssText = `
      position: fixed;
      left: ${rect.left - 4}px;
      top: ${rect.top - 4}px;
      width: ${rect.width + 8}px;
      height: ${rect.height + 8}px;
      border: 4px solid transparent;
      border-radius: 16px;
      pointer-events: none;
      z-index: 9999;
      background: linear-gradient(90deg, #fbbf24, #f59e0b, #fbbf24) border-box;
      -webkit-mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
      mask: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
      -webkit-mask-composite: xor;
      mask-composite: exclude;
    `;

    document.body.appendChild(border);

    border.animate([
      { opacity: 0 },
      { opacity: 1, offset: 0.1 },
      { opacity: 1, offset: 0.9 },
      { opacity: 0 }
    ], {
      duration: 2000,
      easing: 'ease-in-out'
    }).finished.then(() => border.remove());
  },

  // 컨페티 폭발 효과
  showConfettiBurst() {
    const container = Utils.$('#game-table') || this.particleSystem;
    const colors = ['#fbbf24', '#f59e0b', '#ef4444', '#22c55e', '#3b82f6', '#8b5cf6', '#ec4899'];
    const shapes = ['circle', 'square', 'triangle'];

    for (let i = 0; i < this.CONFIG.CONFETTI_COUNT; i++) {
      const confetti = document.createElement('div');
      confetti.className = 'confetti-piece';

      const shape = shapes[Math.floor(Math.random() * shapes.length)];
      const color = colors[Math.floor(Math.random() * colors.length)];
      const size = 5 + Math.random() * 10;
      const startX = 50;
      const startY = 50;
      const angle = Math.random() * Math.PI * 2;
      const velocity = 200 + Math.random() * 300;
      const rotation = Math.random() * 720;

      confetti.style.cssText = `
        position: absolute;
        left: ${startX}%;
        top: ${startY}%;
        width: ${size}px;
        height: ${size}px;
        background: ${color};
        clip-path: ${shape === 'circle' ? 'circle(50%)' : shape === 'triangle' ? 'polygon(50% 0%, 0% 100%, 100% 100%)' : 'none'};
        box-shadow: 0 0 ${size}px ${color};
      `;

      container.appendChild(confetti);

      const vx = Math.cos(angle) * velocity;
      const vy = Math.sin(angle) * velocity - 200;

      confetti.animate([
        {
          transform: 'translate(0, 0) rotate(0deg) scale(1)',
          opacity: 1
        },
        {
          transform: `translate(${vx * 0.3}px, ${vy * 0.3 - 100}px) rotate(${rotation * 0.3}deg) scale(0.8)`,
          opacity: 1,
          offset: 0.3
        },
        {
          transform: `translate(${vx}px, ${vy}px) rotate(${rotation}deg) scale(0.5)`,
          opacity: 0
        }
      ], {
        duration: 1500 + Math.random() * 1000,
        easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        delay: Math.random() * 200,
        fill: 'forwards'
      }).finished.then(() => confetti.remove());
    }
  },

  // 금빛 폭죽 효과
  showGoldFireworks() {
    const container = this.particleSystem;
    const centerX = window.innerWidth / 2;
    const centerY = window.innerHeight / 2;

    for (let i = 0; i < 5; i++) {
      setTimeout(() => {
        const firework = document.createElement('div');
        firework.className = 'firework';
        firework.style.cssText = `
          position: absolute;
          left: ${centerX + (Math.random() - 0.5) * 400}px;
          top: ${centerY + (Math.random() - 0.5) * 200}px;
          width: 4px;
          height: 4px;
          background: #fbbf24;
          border-radius: 50%;
          box-shadow: 0 0 20px #fbbf24, 0 0 40px #f59e0b;
        `;

        container.appendChild(firework);

        // 폭발 파티클
        for (let j = 0; j < 30; j++) {
          const particle = document.createElement('div');
          particle.className = 'firework-particle';
          particle.style.cssText = `
            position: absolute;
            left: ${firework.style.left};
            top: ${firework.style.top};
            width: ${2 + Math.random() * 4}px;
            height: ${2 + Math.random() * 4}px;
            background: radial-gradient(circle, #fbbf24, #f59e0b);
            border-radius: 50%;
            box-shadow: 0 0 6px #fbbf24;
          `;

          container.appendChild(particle);

          const angle = (j / 30) * Math.PI * 2;
          const velocity = 100 + Math.random() * 150;

          particle.animate([
            {
              transform: 'translate(0, 0) scale(1)',
              opacity: 1
            },
            {
              transform: `translate(${Math.cos(angle) * velocity}px, ${Math.sin(angle) * velocity}px) scale(0)`,
              opacity: 0
            }
          ], {
            duration: 800 + Math.random() * 400,
            easing: 'ease-out',
            fill: 'forwards'
          }).finished.then(() => particle.remove());
        }

        firework.animate([
          { transform: 'scale(0)', opacity: 1 },
          { transform: 'scale(3)', opacity: 0 }
        ], {
          duration: 300,
          easing: 'ease-out',
          fill: 'forwards'
        }).finished.then(() => firework.remove());

      }, i * 200);
    }
  },

  // 패배 애니메이션 (강화)
  async showLose(playerIndex) {
    if (!this.CONFIG.ENABLED) return;

    const playerArea = Utils.$(`#player-${playerIndex}-area`);
    if (playerArea) {
      playerArea.classList.add('loser-effect');

      // 회색 파티클
      const rect = playerArea.getBoundingClientRect();
      this.createGrayParticles({
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      });

      setTimeout(() => {
        playerArea.classList.remove('loser-effect');
      }, 1000);
    }

    this.showFloatingText('😢 패배', 'lose');

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playLose();
    }
  },

  // 회색 파티클 효과
  createGrayParticles(position) {
    const particleCount = 20;

    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'gray-particle';
      particle.style.cssText = `
        position: absolute;
        left: ${position.x}px;
        top: ${position.y}px;
        width: ${4 + Math.random() * 6}px;
        height: ${4 + Math.random() * 6}px;
        background: radial-gradient(circle, #9ca3af, #6b7280);
        border-radius: 50%;
        opacity: 0.6;
      `;

      this.particleSystem.appendChild(particle);

      const angle = Math.random() * Math.PI * 2;
      const velocity = 50 + Math.random() * 100;

      particle.animate([
        {
          transform: 'translate(0, 0) scale(1)',
          opacity: 0.6
        },
        {
          transform: `translate(${Math.cos(angle) * velocity}px, ${Math.sin(angle) * velocity}px) scale(0)`,
          opacity: 0
        }
      ], {
        duration: 800 + Math.random() * 400,
        easing: 'ease-out',
        fill: 'forwards'
      }).finished.then(() => particle.remove());
    }
  },

  // 플로팅 텍스트 (강화)
  showFloatingText(text, type = 'normal') {
    const container = Utils.$('#center-message');
    if (!container) return;

    // 기존 메시지 제거
    container.textContent = '';
    container.className = 'center-message';

    const textElement = document.createElement('div');
    textElement.className = `floating-text floating-text-${type}`;
    textElement.textContent = text;

    container.appendChild(textElement);

    // 애니메이션
    textElement.animate([
      {
        transform: 'translate(-50%, -50%) scale(0.5)',
        opacity: 0
      },
      {
        transform: 'translate(-50%, -50%) scale(1.2)',
        opacity: 1,
        offset: 0.2
      },
      {
        transform: 'translate(-50%, -50%) scale(1)',
        opacity: 1,
        offset: 0.8
      },
      {
        transform: 'translate(-50%, -50%) scale(0.8)',
        opacity: 0
      }
    ], {
      duration: 2500,
      easing: 'ease-out',
      fill: 'forwards'
    }).finished.then(() => {
      textElement.remove();
    });
  },

  /* ==========================================
     턴 표시 애니메이션
     ========================================== */

  // 턴 인디케이터 애니메이션
  showTurnIndicator(playerIndex) {
    // 모든 플레이어 턴 표시 제거
    for (let i = 0; i < 4; i++) {
      const area = Utils.$(`#player-${i}-area`);
      if (area) {
        const info = area.querySelector('.player-info-box');
        if (info) {
          info.classList.remove('current-turn', 'turn-pulse');
        }
      }
    }

    // 현재 플레이어 턴 표시
    const currentArea = Utils.$(`#player-${playerIndex}-area`);
    if (currentArea) {
      const info = currentArea.querySelector('.player-info-box');
      if (info) {
        info.classList.add('current-turn', 'turn-pulse');
      }
    }
  },

  // 타이머 경고 애니메이션
  showTimerWarning() {
    const timerDisplay = Utils.$('#timer-display');
    if (timerDisplay) {
      timerDisplay.classList.add('timer-warning-pulse');
    }
  },

  hideTimerWarning() {
    const timerDisplay = Utils.$('#timer-display');
    if (timerDisplay) {
      timerDisplay.classList.remove('timer-warning-pulse');
    }
  },

  /* ==========================================
     팟 애니메이션
     ========================================== */

  // 팟 업데이트 애니메이션
  animatePotUpdate(newAmount) {
    const potDisplay = Utils.$('#pot-display');
    if (!potDisplay) return;

    potDisplay.classList.add('pot-update');

    setTimeout(() => {
      potDisplay.classList.remove('pot-update');
    }, 500);
  },

  /* ==========================================
     쇼다운 애니메이션
     ========================================== */

  // 쇼다운 카드 공개 애니메이션
  async revealShowdownCards() {
    if (!this.CONFIG.ENABLED) return;

    // 모든 플레이어 카드 순차적으로 공개
    for (let i = 0; i < 4; i++) {
      const playerArea = Utils.$(`#player-${i}-area`);
      if (!playerArea) continue;

      const cards = playerArea.querySelectorAll('.playing-card.card-back');

      for (const card of cards) {
        await this.flipCard(card, true);
        await Utils.delay(150);
      }

      await Utils.delay(300);
    }
  },

  /* ==========================================
     럭키휠 애니메이션
     ========================================== */

  // 휠 스핀 애니메이션
  async spinWheel(canvas, targetSlotIndex, totalSlots) {
    if (!canvas) return;

    const slotAngle = 360 / totalSlots;
    const randomOffset = Math.random() * slotAngle * 0.5;
    const targetAngle = 360 * 5 + (360 - targetSlotIndex * slotAngle - slotAngle / 2) + randomOffset;

    canvas.style.transition = 'transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99)';
    canvas.style.transform = `rotate(${targetAngle}deg)`;

    // 틱 사운드
    if (typeof SoundManager !== 'undefined') {
      let tickCount = 0;
      const tickInterval = setInterval(() => {
        tickCount++;
        if (tickCount > 30) {
          clearInterval(tickInterval);
          return;
        }
        SoundManager.playSpinTick();
      }, 100 + tickCount * 5);
    }

    await Utils.delay(4000);
  },

  /* ==========================================
     레벨업 애니메이션
     ========================================== */

  showLevelUpEffect(levelInfo) {
    const overlay = document.createElement('div');
    overlay.className = 'levelup-overlay';
    overlay.innerHTML = `
      <div class="levelup-content">
        <div class="levelup-icon">${levelInfo.icon}</div>
        <div class="levelup-title">레벨 업!</div>
        <div class="levelup-level">${levelInfo.name}</div>
        <div class="levelup-stars">⭐⭐⭐</div>
      </div>
    `;

    document.body.appendChild(overlay);

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playLevelUp();
    }

    setTimeout(() => {
      overlay.classList.add('fade-out');
      setTimeout(() => overlay.remove(), 500);
    }, 2500);
  },

  /* ==========================================
     업적 팝업 애니메이션
     ========================================== */

  showAchievementPopup(achievement) {
    const popup = document.createElement('div');
    popup.className = 'achievement-popup';
    popup.innerHTML = `
      <div class="achievement-popup-icon">${achievement.icon}</div>
      <div class="achievement-popup-content">
        <div class="achievement-popup-title">업적 달성!</div>
        <div class="achievement-popup-name">${achievement.name}</div>
        <div class="achievement-popup-reward">+${Utils.formatChips(achievement.reward)}</div>
      </div>
    `;

    document.body.appendChild(popup);

    if (typeof SoundManager !== 'undefined') {
      SoundManager.playAchievement();
    }

    setTimeout(() => {
      popup.classList.add('slide-out');
      setTimeout(() => popup.remove(), 500);
    }, 3000);
  },

  /* ==========================================
     숫자 카운트 애니메이션
     ========================================== */

  animateNumber(element, from, to, duration = 1000) {
    if (!element) return;

    const startTime = performance.now();
    const diff = to - from;

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // easeOutQuart
      const eased = 1 - Math.pow(1 - progress, 4);
      const current = from + diff * eased;

      element.textContent = Utils.formatChips(Math.floor(current));

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  },

  /* ==========================================
     화면 전환 애니메이션
     ========================================== */

  // 화면 페이드 전환
  async transitionScreen(fromScreen, toScreen) {
    if (!this.CONFIG.ENABLED) {
      Utils.hide(fromScreen);
      Utils.show(toScreen);
      return;
    }

    const from = Utils.$(fromScreen);
    const to = Utils.$(toScreen);

    if (from) {
      from.classList.add('screen-fade-out');
      await Utils.delay(300);
      from.classList.add('hidden');
      from.classList.remove('screen-fade-out');
    }

    if (to) {
      to.classList.remove('hidden');
      to.classList.add('screen-fade-in');
      await Utils.delay(300);
      to.classList.remove('screen-fade-in');
    }
  }
};
