/* ==========================================
   일일 미션 시스템
   ========================================== */

const Missions = {

  // 미션 템플릿
  TEMPLATES: [
    { id: 'play_3', name: '워밍업', desc: '게임 3판 플레이', icon: '🎮', reward: 500, type: 'games', target: 3 },
    { id: 'play_5', name: '열정', desc: '게임 5판 플레이', icon: '🔥', reward: 1000, type: 'games', target: 5 },
    { id: 'play_10', name: '열혈', desc: '게임 10판 플레이', icon: '💪', reward: 2000, type: 'games', target: 10 },
    { id: 'win_1', name: '승리자', desc: '1번 승리', icon: '🏆', reward: 800, type: 'wins', target: 1 },
    { id: 'win_3', name: '연승왕', desc: '3번 승리', icon: '👑', reward: 2000, type: 'wins', target: 3 },
    { id: 'badugi_1', name: '바둑이', desc: '바둑이 1번 완성', icon: '🎴', reward: 1500, type: 'badugi', target: 1 },
    { id: 'exchange_5', name: '교환왕', desc: '카드 5번 교환', icon: '🔄', reward: 500, type: 'exchanges', target: 5 },
    { id: 'allin_1', name: '도전자', desc: '올인 1번', icon: '💥', reward: 1000, type: 'allins', target: 1 },
    { id: 'earn_5k', name: '돈벌이', desc: '5,000원 획득', icon: '💰', reward: 1000, type: 'earnings', target: 5000 },
    { id: 'earn_10k', name: '부자되기', desc: '10,000원 획득', icon: '💎', reward: 2000, type: 'earnings', target: 10000 }
  ],

  STORAGE_KEY: 'badugi_missions',
  DAILY_MISSION_COUNT: 3,

  // 오늘 날짜 문자열
  getTodayString() {
    return new Date().toISOString().split('T')[0];
  },

  // 데이터 로드
  loadData() {
    return Storage.get(this.STORAGE_KEY, {
      date: null,
      missions: [],
      progress: {},
      completed: []
    });
  },

  // 데이터 저장
  saveData(data) {
    Storage.set(this.STORAGE_KEY, data);
  },

  // 일일 미션 생성
  generateDailyMissions() {
    const shuffled = Utils.shuffle([...this.TEMPLATES]);
    return shuffled.slice(0, this.DAILY_MISSION_COUNT).map(template => ({
      ...template,
      dailyId: `${template.id}_${Date.now()}`
    }));
  },

  // 미션 초기화 (날짜 변경 시)
  initMissions() {
    const data = this.loadData();
    const today = this.getTodayString();

    if (data.date !== today) {
      // 새로운 날짜 - 미션 리셋
      data.date = today;
      data.missions = this.generateDailyMissions();
      data.progress = {};
      data.completed = [];
      this.saveData(data);
    }

    return data;
  },

  // 미션 진행도 업데이트
  updateProgress(type, amount = 1) {
    const data = this.initMissions();
    const newlyCompleted = [];

    data.missions.forEach(mission => {
      if (mission.type === type && !data.completed.includes(mission.dailyId)) {
        data.progress[mission.dailyId] = (data.progress[mission.dailyId] || 0) + amount;

        // 완료 체크
        if (data.progress[mission.dailyId] >= mission.target) {
          data.completed.push(mission.dailyId);
          Storage.addChips(mission.reward);
          newlyCompleted.push(mission);
        }
      }
    });

    this.saveData(data);
    return newlyCompleted;
  },

  // 미션 목록 조회
  getMissions() {
    const data = this.initMissions();

    return data.missions.map(mission => ({
      ...mission,
      current: data.progress[mission.dailyId] || 0,
      completed: data.completed.includes(mission.dailyId)
    }));
  },

  // 전체 완료 보너스 확인
  checkAllCompleteBonus() {
    const data = this.loadData();
    const allComplete = data.missions.length > 0 &&
                        data.missions.every(m => data.completed.includes(m.dailyId));

    if (allComplete && !data.allCompleteBonusClaimed) {
      data.allCompleteBonusClaimed = true;
      this.saveData(data);

      const bonusAmount = 5000;
      Storage.addChips(bonusAmount);

      return { success: true, bonus: bonusAmount };
    }

    return { success: false };
  },

  // 남은 시간 계산
  getTimeRemaining() {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);

    const diff = tomorrow - now;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    return { hours, minutes, formatted: `${hours}시간 ${minutes}분` };
  }
};
