/* ==========================================
   VIP 시스템
   ========================================== */

const VIPSystem = {

  // VIP 레벨 설정
  LEVELS: [
    { level: 0, name: '일반', minExp: 0, icon: '👤', benefits: { freeCharge: 5000, spinBonus: 0, expBonus: 0 } },
    { level: 1, name: '브론즈', minExp: 1000, icon: '🥉', benefits: { freeCharge: 6000, spinBonus: 10, expBonus: 5 } },
    { level: 2, name: '실버', minExp: 5000, icon: '🥈', benefits: { freeCharge: 7000, spinBonus: 15, expBonus: 10 } },
    { level: 3, name: '골드', minExp: 15000, icon: '🥇', benefits: { freeCharge: 8000, spinBonus: 20, expBonus: 15 } },
    { level: 4, name: '플래티넘', minExp: 50000, icon: '💎', benefits: { freeCharge: 10000, spinBonus: 25, expBonus: 20 } },
    { level: 5, name: '다이아몬드', minExp: 150000, icon: '💠', benefits: { freeCharge: 12000, spinBonus: 30, expBonus: 25 } },
    { level: 6, name: 'VIP', minExp: 500000, icon: '👑', benefits: { freeCharge: 15000, spinBonus: 50, expBonus: 30 } }
  ],

  // 경험치 획득 설정
  EXP_RATES: {
    game_play: 10,      // 게임 1판당
    win: 50,            // 승리당
    badugi: 100,        // 바둑이 완성
    pot_win: 0.01,      // 팟 1%
    daily_login: 100,   // 일일 출석
    mission_complete: 50 // 미션 완료당
  },

  STORAGE_KEY: 'badugi_vip',

  // 데이터 로드
  loadData() {
    return Storage.get(this.STORAGE_KEY, {
      exp: 0,
      totalExp: 0,
      level: 0
    });
  },

  // 데이터 저장
  saveData(data) {
    Storage.set(this.STORAGE_KEY, data);
  },

  // 레벨 계산
  calculateLevel(exp) {
    let level = 0;
    for (let i = this.LEVELS.length - 1; i >= 0; i--) {
      if (exp >= this.LEVELS[i].minExp) {
        level = i;
        break;
      }
    }
    return level;
  },

  // 경험치 추가
  addExp(type, value = 1) {
    const data = this.loadData();
    const oldLevel = data.level;

    // 경험치 계산
    let expGain = this.EXP_RATES[type] || 0;
    if (type === 'pot_win') {
      expGain = Math.floor(value * this.EXP_RATES.pot_win);
    }

    // 경험치 보너스 적용
    const currentBenefits = this.LEVELS[oldLevel].benefits;
    expGain = Math.floor(expGain * (1 + currentBenefits.expBonus / 100));

    data.exp += expGain;
    data.totalExp += expGain;
    data.level = this.calculateLevel(data.totalExp);

    this.saveData(data);

    // 레벨업 확인
    const leveledUp = data.level > oldLevel;

    return {
      expGain,
      totalExp: data.totalExp,
      level: data.level,
      leveledUp,
      newLevelInfo: leveledUp ? this.LEVELS[data.level] : null
    };
  },

  // 현재 상태 조회
  getStatus() {
    const data = this.loadData();
    const currentLevel = this.LEVELS[data.level];
    const nextLevel = this.LEVELS[data.level + 1];

    let progress = 100;
    let expToNext = 0;

    if (nextLevel) {
      const currentMin = currentLevel.minExp;
      const nextMin = nextLevel.minExp;
      expToNext = nextMin - data.totalExp;
      progress = Math.floor((data.totalExp - currentMin) / (nextMin - currentMin) * 100);
    }

    return {
      level: data.level,
      levelInfo: currentLevel,
      totalExp: data.totalExp,
      nextLevel: nextLevel,
      expToNext,
      progress
    };
  },

  // 혜택 조회
  getBenefits() {
    const data = this.loadData();
    return this.LEVELS[data.level].benefits;
  },

  // 무료 충전 금액 (VIP 보너스 적용)
  getFreeChargeAmount() {
    return this.getBenefits().freeCharge;
  },

  // 스핀 보너스 (VIP 보너스 적용)
  getSpinBonus() {
    return this.getBenefits().spinBonus;
  }
};
