// client/js/features/profile.js
// 프로필 시스템

const Profile = (function() {
    let currentProfile = null;
    let isMyProfile = false;

    // 초기화
    function init() {
        setupEventListeners();
        console.log('[Profile] 초기화 완료');
    }

    // 이벤트 리스너
    function setupEventListeners() {
        if (typeof SocketManager !== 'undefined' && SocketManager.socket) {
            SocketManager.socket.on('user_profile', handleProfileData);
            SocketManager.socket.on('my_stats', handleMyStats);
        }
    }

    // 프로필 데이터 수신
    function handleProfileData(data) {
        currentProfile = data.profile;
        isMyProfile = data.isMe;
        render(data.isFriend);
    }

    // 내 통계 수신
    function handleMyStats(data) {
        currentProfile = {
            name: State.playerName || '플레이어',
            chips: State.myChips,
            vip: data.vip || { level: 0, xp: 0, totalXP: 0 },
            stats: data.stats || {}
        };
        isMyProfile = true;
        render(false);
    }

    // 프로필 요청
    function requestProfile(userId) {
        if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
            SocketManager.emit('user_profile_get', { userId });
        }
    }

    // 내 프로필 요청
    function requestMyProfile() {
        if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
            SocketManager.emit('my_stats_get', {});
        } else {
            // 로컬 모드 더미 데이터
            const vipStatus = typeof VIPSystem !== 'undefined' ? VIPSystem.getStatus() : { level: 0, currentXP: 0, requiredXP: 100 };
            currentProfile = {
                name: State.playerName || '플레이어',
                chips: State.myChips,
                vip: vipStatus,
                stats: {
                    gamesPlayed: 0,
                    wins: 0,
                    totalWinnings: 0,
                    biggestWin: 0,
                    badugisMade: 0
                }
            };
            isMyProfile = true;
            render(false);
        }
    }

    // 렌더링
    function render(isFriend) {
        const content = Utils.$('#profile-content');
        if (!content || !currentProfile) return;

        const p = currentProfile;
        const stats = p.stats || {};
        const vip = p.vip || { level: 0, xp: 0, totalXP: 0 };
        const vipLevel = vip.level;

        // 필요 XP 계산
        const requiredXP = Math.floor(1000 * Math.pow(1.5, vipLevel));
        const currentXP = vip.xp || 0;

        content.innerHTML = `
            <!-- 헤더 -->
            <div class="profile-header">
                <div class="profile-avatar-large">
                    <div class="avatar-frame ${getVipFrameClass(vipLevel)}">
                        <span class="avatar-level-large">${vipLevel}</span>
                    </div>
                    ${vipLevel > 0 ? `<div class="vip-crown">👑</div>` : ''}
                </div>
                <div class="profile-name-section">
                    <h2 class="profile-name">${p.name}</h2>
                    <div class="profile-badges">
                        ${vipLevel > 0 ? `<span class="badge vip-badge">VIP ${vipLevel}</span>` : ''}
                        ${stats.gamesPlayed >= 100 ? `<span class="badge veteran-badge">베테랑</span>` : ''}
                        ${stats.badugisMade >= 10 ? `<span class="badge badugi-badge">바둑이 마스터</span>` : ''}
                    </div>
                </div>
            </div>

            <!-- 레벨/경험치 -->
            <div class="profile-level-section">
                <div class="level-info">
                    <span class="level-label">레벨 ${vipLevel}</span>
                    <span class="exp-text">${currentXP} / ${requiredXP} EXP</span>
                </div>
                <div class="exp-bar">
                    <div class="exp-fill" style="width: ${Math.min((currentXP / requiredXP) * 100, 100)}%"></div>
                </div>
            </div>

            <!-- 보유 칩 -->
            <div class="profile-chips">
                <span class="chips-icon">💰</span>
                <span class="chips-value">${Utils.formatChips(p.chips)}</span>
            </div>

            <!-- 통계 그리드 -->
            <div class="profile-stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">🎮</div>
                    <div class="stat-value">${stats.gamesPlayed || 0}</div>
                    <div class="stat-label">총 게임</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🏆</div>
                    <div class="stat-value">${stats.wins || 0}</div>
                    <div class="stat-label">승리</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📈</div>
                    <div class="stat-value">${getWinRate(stats)}%</div>
                    <div class="stat-label">승률</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">💎</div>
                    <div class="stat-value">${Utils.formatChips(stats.totalWinnings || stats.biggestWin || 0)}</div>
                    <div class="stat-label">총 수익</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🃏</div>
                    <div class="stat-value">${stats.badugisMade || 0}</div>
                    <div class="stat-label">바둑이</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🔥</div>
                    <div class="stat-value">${stats.bestStreak || 0}</div>
                    <div class="stat-label">최고 연승</div>
                </div>
            </div>

            <!-- 액션 버튼 -->
            ${!isMyProfile ? `
                <div class="profile-actions">
                    ${isFriend
                        ? `<button class="btn btn-secondary" onclick="Friends.removeFriend('${p.id}')">
                            친구 삭제
                           </button>`
                        : `<button class="btn btn-primary" onclick="Friends.sendFriendRequest('${p.id}')">
                            친구 추가
                           </button>`
                    }
                    <button class="btn btn-secondary" onclick="Friends.blockUser('${p.id}')">
                        차단
                    </button>
                </div>
            ` : ''}
        `;
    }

    // 승률 계산
    function getWinRate(stats) {
        if (!stats.gamesPlayed || stats.gamesPlayed === 0) return 0;
        return Math.round((stats.wins / stats.gamesPlayed) * 100);
    }

    // VIP 프레임 클래스
    function getVipFrameClass(vipLevel) {
        if (vipLevel >= 8) return 'frame-legendary';
        if (vipLevel >= 5) return 'frame-epic';
        if (vipLevel >= 3) return 'frame-rare';
        if (vipLevel >= 1) return 'frame-common';
        return '';
    }

    // 모달 열기
    function openModal(userId = null) {
        const modal = Utils.$('#profile-modal');
        if (modal) {
            Utils.show('#profile-modal');

            if (userId) {
                requestProfile(userId);
            } else {
                requestMyProfile();
            }
        }
    }

    // 모달 닫기
    function closeModal() {
        const modal = Utils.$('#profile-modal');
        if (modal) {
            Utils.hide('#profile-modal');
        }
    }

    // Public API
    return {
        init,
        openModal,
        closeModal,
        requestProfile,
        requestMyProfile
    };
})();

window.Profile = Profile;
