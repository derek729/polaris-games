/* =========================================
   다국어 지원 시스템 (i18n)
   ========================================== */

const I18n = (function() {
  // 현재 언어
  let currentLocale = 'ko';

  // 지원하는 언어
  const supportedLocales = ['ko', 'en', 'ja', 'zh'];

  // 번역 데이터
  const translations = {
    ko: {
      // 공통
      common: {
        loading: '로딩 중...',
        save: '저장',
        cancel: '취소',
        confirm: '확인',
        close: '닫기',
        delete: '삭제',
        edit: '편집',
        yes: '예',
        no: '아니오',
        back: '뒤로',
        next: '다음',
        prev: '이전',
        submit: '제출',
        search: '검색',
        filter: '필터',
        sort: '정렬',
        refresh: '새로고침'
      },

      // 게임
      game: {
        title: '바둑이 포커',
        deal: '카드 받기',
        bet: '베팅',
        raise: '레이즈',
        call: '콜',
        fold: '폴드',
        check: '체크',
        allin: '올인',
        draw: '교환',
        stand: '스탠드패트',
        showdown: '쇼다운',
        pot: '팟',
        chips: '칩',
        blind: '블라인드',
        ante: '앤테',
        dealer: '딜러',
        player: '플레이어',
        winner: '승리자',
        loser: '패자',
        tie: '무승부'
      },

      // 핸드 타입
      hands: {
        badugi: '바둑이',
        three_card: '쓰리카드',
        two_card: '투카드',
        one_card: '원카드',
        high: '하이',
        middle: '미들',
        low: '로우'
      },

      // 메뉴
      menu: {
        lobby: '로비',
        rooms: '방 목록',
        shop: '상점',
        inventory: '인벤토리',
        achievements: '업적',
        missions: '미션',
        challenges: '챌린지',
        season_pass: '시즌 패스',
        ranking: '랭킹',
        friends: '친구',
        profile: '프로필',
        settings: '설정',
        tutorial: '튜토리얼',
        hand_history: '핸드 히스토리'
      },

      // VIP
      vip: {
        level: 'VIP 레벨',
        exp: '경험치',
        benefits: '혜택',
        next_level: '다음 레벨까지',
        bronze: '브론즈',
        silver: '실버',
        gold: '골드',
        platinum: '플래티넘',
        diamond: '다이아몬드',
        master: '마스터',
        grandmaster: '그랜드마스터',
        legendary: '전설'
      },

      // 상점
      shop: {
        title: '상점',
        categories: '카테고리',
        chips: '칩 패키지',
        items: '아이템',
        cosmetics: '꾸미기',
        special: '특별 상품',
        purchase: '구매',
        owned: '보유 중',
        balance: '보유 칩',
        inventory: '인벤토리',
        lucky_box: '럭키 박스',
        best_value: '최고 가성비',
        popular: '인기',
        rare: '레어',
        legendary: '전설',
        discount: '할인'
      },

      // 토너먼트
      tournament: {
        title: '토너먼트',
        register: '참가 신청',
        registered: '참가 중',
        in_progress: '진행 중',
        completed: '완료',
        players: '플레이어',
        prize_pool: '상금',
        entry_fee: '참가비',
        start_time: '시작 시간',
        status: '상태',
        type: '유형',
        sitngo: ' Sit & Go',
        scheduled: '예약',
        freeroll: '프리롤',
        elimination: '탈락',
        winner: '우승',
        rank: '순위',
        table: '테이블',
        blind_level: '블라인드 레벨'
      },

      // 튜토리얼
      tutorial: {
        title: '튜토리얼',
        start: '시작하기',
        skip: '건너뛰기',
        next: '다음',
        prev: '이전',
        complete: '완료',
        step: '단계',
        difficulty: '난이도',
        beginner: '입문',
        intermediate: '중급',
        advanced: '고급',
        completed: '완료됨'
      },

      // 핸드 히스토리
      hand_history: {
        title: '핸드 히스토리',
        total_hands: '총 핸드',
        win_rate: '승률',
        showdown_win_rate: '쇼다운 승률',
        badugi_rate: '바둑이율',
        biggest_win: '최대 승리',
        biggest_loss: '최대 패배',
        total_winnings: '총 수익',
        export: '내보내기',
        clear: '비우기',
        detail: '상세',
        date: '날짜',
        result: '결과',
        win: '승리',
        loss: '패배',
        tie: '무승부',
        cards: '카드',
        winnings: '수익'
      },

      // 알림
      notifications: {
        success: '성공',
        error: '오류',
        warning: '경고',
        info: '정보',
        daily_reward_available: '일일 보상을 받을 수 있습니다!',
        challenge_completed: '챌린지 완료!',
        achievement_unlocked: '업적 해제!',
        level_up: '레벨 업!',
        insufficient_chips: '칩이 부족합니다.',
        purchase_success: '구매 성공!',
        purchase_failed: '구매 실패!'
      },

      // 기타
      other: {
        welcome: '환영합니다!',
        login_streak: '연속 로그인',
        days: '일',
        hours: '시간',
        minutes: '분',
        seconds: '초',
        today: '오늘',
        yesterday: '어제',
        week: '이번 주',
        month: '이번 달',
        year: '올해',
        free: '무료',
        premium: '프리미엄',
        limited: '한정',
        exclusive: '독점'
      }
    },

    en: {
      common: {
        loading: 'Loading...',
        save: 'Save',
        cancel: 'Cancel',
        confirm: 'Confirm',
        close: 'Close',
        delete: 'Delete',
        edit: 'Edit',
        yes: 'Yes',
        no: 'No',
        back: 'Back',
        next: 'Next',
        prev: 'Previous',
        submit: 'Submit',
        search: 'Search',
        filter: 'Filter',
        sort: 'Sort',
        refresh: 'Refresh'
      },

      game: {
        title: 'Badugi Poker',
        deal: 'Deal',
        bet: 'Bet',
        raise: 'Raise',
        call: 'Call',
        fold: 'Fold',
        check: 'Check',
        allin: 'All In',
        draw: 'Draw',
        stand: 'Stand Pat',
        showdown: 'Showdown',
        pot: 'Pot',
        chips: 'Chips',
        blind: 'Blind',
        ante: 'Ante',
        dealer: 'Dealer',
        player: 'Player',
        winner: 'Winner',
        loser: 'Loser',
        tie: 'Tie'
      },

      hands: {
        badugi: 'Badugi',
        three_card: 'Three Card',
        two_card: 'Two Card',
        one_card: 'One Card',
        high: 'High',
        middle: 'Middle',
        low: 'Low'
      },

      menu: {
        lobby: 'Lobby',
        rooms: 'Rooms',
        shop: 'Shop',
        inventory: 'Inventory',
        achievements: 'Achievements',
        missions: 'Missions',
        challenges: 'Challenges',
        season_pass: 'Season Pass',
        ranking: 'Ranking',
        friends: 'Friends',
        profile: 'Profile',
        settings: 'Settings',
        tutorial: 'Tutorial',
        hand_history: 'Hand History'
      },

      vip: {
        level: 'VIP Level',
        exp: 'Experience',
        benefits: 'Benefits',
        next_level: 'To Next Level',
        bronze: 'Bronze',
        silver: 'Silver',
        gold: 'Gold',
        platinum: 'Platinum',
        diamond: 'Diamond',
        master: 'Master',
        grandmaster: 'Grandmaster',
        legendary: 'Legendary'
      },

      shop: {
        title: 'Shop',
        categories: 'Categories',
        chips: 'Chip Packages',
        items: 'Items',
        cosmetics: 'Cosmetics',
        special: 'Special',
        purchase: 'Purchase',
        owned: 'Owned',
        balance: 'Balance',
        inventory: 'Inventory',
        lucky_box: 'Lucky Box',
        best_value: 'Best Value',
        popular: 'Popular',
        rare: 'Rare',
        legendary: 'Legendary',
        discount: 'Discount'
      },

      tournament: {
        title: 'Tournament',
        register: 'Register',
        registered: 'Registered',
        in_progress: 'In Progress',
        completed: 'Completed',
        players: 'Players',
        prize_pool: 'Prize Pool',
        entry_fee: 'Entry Fee',
        start_time: 'Start Time',
        status: 'Status',
        type: 'Type',
        sitngo: 'Sit & Go',
        scheduled: 'Scheduled',
        freeroll: 'Freeroll',
        elimination: 'Eliminated',
        winner: 'Winner',
        rank: 'Rank',
        table: 'Table',
        blind_level: 'Blind Level'
      },

      tutorial: {
        title: 'Tutorial',
        start: 'Start',
        skip: 'Skip',
        next: 'Next',
        prev: 'Previous',
        complete: 'Complete',
        step: 'Step',
        difficulty: 'Difficulty',
        beginner: 'Beginner',
        intermediate: 'Intermediate',
        advanced: 'Advanced',
        completed: 'Completed'
      },

      hand_history: {
        title: 'Hand History',
        total_hands: 'Total Hands',
        win_rate: 'Win Rate',
        showdown_win_rate: 'Showdown Win Rate',
        badugi_rate: 'Badugi Rate',
        biggest_win: 'Biggest Win',
        biggest_loss: 'Biggest Loss',
        total_winnings: 'Total Winnings',
        export: 'Export',
        clear: 'Clear',
        detail: 'Detail',
        date: 'Date',
        result: 'Result',
        win: 'Win',
        loss: 'Loss',
        tie: 'Tie',
        cards: 'Cards',
        winnings: 'Winnings'
      },

      notifications: {
        success: 'Success',
        error: 'Error',
        warning: 'Warning',
        info: 'Info',
        daily_reward_available: 'Daily reward available!',
        challenge_completed: 'Challenge completed!',
        achievement_unlocked: 'Achievement unlocked!',
        level_up: 'Level up!',
        insufficient_chips: 'Insufficient chips.',
        purchase_success: 'Purchase successful!',
        purchase_failed: 'Purchase failed!'
      },

      other: {
        welcome: 'Welcome!',
        login_streak: 'Login Streak',
        days: 'days',
        hours: 'hours',
        minutes: 'minutes',
        seconds: 'seconds',
        today: 'Today',
        yesterday: 'Yesterday',
        week: 'This Week',
        month: 'This Month',
        year: 'This Year',
        free: 'Free',
        premium: 'Premium',
        limited: 'Limited',
        exclusive: 'Exclusive'
      }
    },

    ja: {
      common: {
        loading: '読み込み中...',
        save: '保存',
        cancel: 'キャンセル',
        confirm: '確認',
        close: '閉じる',
        delete: '削除',
        edit: '編集',
        yes: 'はい',
        no: 'いいえ',
        back: '戻る',
        next: '次へ',
        prev: '前へ',
        submit: '送信',
        search: '検索',
        filter: 'フィルター',
        sort: '並び替え',
        refresh: '更新'
      },

      game: {
        title: 'バドゥキポーカー',
        deal: 'ディール',
        bet: 'ベット',
        raise: 'レイズ',
        call: 'コール',
        fold: 'フォルド',
        check: 'チェック',
        allin: 'オールイン',
        draw: '交換',
        stand: 'スタンドパット',
        showdown: 'ショーダウン',
        pot: 'ポット',
        chips: 'チップ',
        blind: 'ブラインド',
        ante: 'アンテ',
        dealer: 'ディーラー',
        player: 'プレイヤー',
        winner: '勝者',
        loser: '敗者',
        tie: '引き分け'
      },

      hands: {
        badugi: 'バドゥキ',
        three_card: 'スリーカード',
        two_card: 'ツーカード',
        one_card: 'ワンカード',
        high: 'ハイ',
        middle: 'ミドル',
        low: 'ロウ'
      },

      menu: {
        lobby: 'ロビー',
        rooms: 'ルーム一覧',
        shop: 'ショップ',
        inventory: 'インベントリ',
        achievements: '実績',
        missions: 'ミッション',
        challenges: 'チャレンジ',
        season_pass: 'シーズンパス',
        ranking: 'ランキング',
        friends: 'フレンド',
        profile: 'プロフィール',
        settings: '設定',
        tutorial: 'チュートリアル',
        hand_history: 'ハンド履歴'
      },

      vip: {
        level: 'VIPレベル',
        exp: '経験値',
        benefits: '特典',
        next_level: '次のレベルまで',
        bronze: 'ブロンズ',
        silver: 'シルバー',
        gold: 'ゴールド',
        platinum: 'プラチナ',
        diamond: 'ダイヤモンド',
        master: 'マスター',
        grandmaster: 'グランドマスター',
        legendary: 'レジェンド'
      },

      shop: {
        title: 'ショップ',
        categories: 'カテゴリー',
        chips: 'チップパッケージ',
        items: 'アイテム',
        cosmetics: 'コスメティック',
        special: 'スペシャル',
        purchase: '購入',
        owned: '所持中',
        balance: '残高',
        inventory: 'インベントリ',
        lucky_box: 'ラッキーボックス',
        best_value: 'お得',
        popular: '人気',
        rare: 'レア',
        legendary: 'レジェンド',
        discount: '割引'
      },

      tournament: {
        title: 'トーナメント',
        register: '登録',
        registered: '登録済み',
        in_progress: '進行中',
        completed: '完了',
        players: 'プレイヤー',
        prize_pool: '賞金',
        entry_fee: '参加費',
        start_time: '開始時刻',
        status: 'ステータス',
        type: 'タイプ',
        sitngo: 'Sit & Go',
        scheduled: '予約',
        freeroll: 'フリーロール',
        elimination: '敗退',
        winner: '優勝',
        rank: '順位',
        table: 'テーブル',
        blind_level: 'ブラインドレベル'
      },

      tutorial: {
        title: 'チュートリアル',
        start: '開始',
        skip: 'スキップ',
        next: '次へ',
        prev: '前へ',
        complete: '完了',
        step: 'ステップ',
        difficulty: '難易度',
        beginner: '初級',
        intermediate: '中級',
        advanced: '上級',
        completed: '完了'
      },

      hand_history: {
        title: 'ハンド履歴',
        total_hands: '総ハンド数',
        win_rate: '勝率',
        showdown_win_rate: 'ショーダウン勝率',
        badugi_rate: 'バドゥキ率',
        biggest_win: '最大勝利',
        biggest_loss: '最大敗北',
        total_winnings: '総収益',
        export: 'エクスポート',
        clear: 'クリア',
        detail: '詳細',
        date: '日付',
        result: '結果',
        win: '勝利',
        loss: '敗北',
        tie: '引き分け',
        cards: 'カード',
        winnings: '収益'
      },

      notifications: {
        success: '成功',
        error: 'エラー',
        warning: '警告',
        info: '情報',
        daily_reward_available: 'デイリーリワードを受け取れます！',
        challenge_completed: 'チャレンジ完了！',
        achievement_unlocked: '実績解除！',
        level_up: 'レベルアップ！',
        insufficient_chips: 'チップが不足しています。',
        purchase_success: '購入成功！',
        purchase_failed: '購入失敗！'
      },

      other: {
        welcome: 'ようこそ！',
        login_streak: '連続ログイン',
        days: '日',
        hours: '時間',
        minutes: '分',
        seconds: '秒',
        today: '今日',
        yesterday: '昨日',
        week: '今週',
        month: '今月',
        year: '今年',
        free: '無料',
        premium: 'プレミアム',
        limited: '限定',
        exclusive: 'エクスクルーシブ'
      }
    },

    zh: {
      common: {
        loading: '加载中...',
        save: '保存',
        cancel: '取消',
        confirm: '确认',
        close: '关闭',
        delete: '删除',
        edit: '编辑',
        yes: '是',
        no: '否',
        back: '返回',
        next: '下一步',
        prev: '上一步',
        submit: '提交',
        search: '搜索',
        filter: '筛选',
        sort: '排序',
        refresh: '刷新'
      },

      game: {
        title: ' Badugi扑克',
        deal: '发牌',
        bet: '下注',
        raise: '加注',
        call: '跟注',
        fold: '弃牌',
        check: '过牌',
        allin: '全押',
        draw: '换牌',
        stand: '不换',
        showdown: '摊牌',
        pot: '底池',
        chips: '筹码',
        blind: '盲注',
        ante: '前注',
        dealer: '庄家',
        player: '玩家',
        winner: '获胜者',
        loser: '失败者',
        tie: '平局'
      },

      hands: {
        badugi: 'Badugi',
        three_card: '三张',
        two_card: '两张',
        one_card: '一张',
        high: '高',
        middle: '中',
        low: '低'
      },

      menu: {
        lobby: '大厅',
        rooms: '房间列表',
        shop: '商店',
        inventory: '背包',
        achievements: '成就',
        missions: '任务',
        challenges: '挑战',
        season_pass: '赛季通行证',
        ranking: '排名',
        friends: '好友',
        profile: '个人资料',
        settings: '设置',
        tutorial: '教程',
        hand_history: '手牌历史'
      },

      vip: {
        level: 'VIP等级',
        exp: '经验值',
        benefits: '特权',
        next_level: '下一等级',
        bronze: '青铜',
        silver: '白银',
        gold: '黄金',
        platinum: '铂金',
        diamond: '钻石',
        master: '大师',
        grandmaster: '宗师',
        legendary: '传奇'
      },

      shop: {
        title: '商店',
        categories: '分类',
        chips: '筹码包',
        items: '道具',
        cosmetics: '装饰',
        special: '特殊商品',
        purchase: '购买',
        owned: '已拥有',
        balance: '余额',
        inventory: '背包',
        lucky_box: '幸运箱',
        best_value: '超值',
        popular: '热门',
        rare: '稀有',
        legendary: '传说',
        discount: '折扣'
      },

      tournament: {
        title: '锦标赛',
        register: '报名',
        registered: '已报名',
        in_progress: '进行中',
        completed: '已完成',
        players: '玩家',
        prize_pool: '奖池',
        entry_fee: '报名费',
        start_time: '开始时间',
        status: '状态',
        type: '类型',
        sitngo: '即开赛',
        scheduled: '定时赛',
        freeroll: '免费赛',
        elimination: '淘汰',
        winner: '冠军',
        rank: '排名',
        table: '桌子',
        blind_level: '盲注等级'
      },

      tutorial: {
        title: '教程',
        start: '开始',
        skip: '跳过',
        next: '下一步',
        prev: '上一步',
        complete: '完成',
        step: '步骤',
        difficulty: '难度',
        beginner: '初级',
        intermediate: '中级',
        advanced: '高级',
        completed: '已完成'
      },

      hand_history: {
        title: '手牌历史',
        total_hands: '总局数',
        win_rate: '胜率',
        showdown_win_rate: '摊牌胜率',
        badugi_rate: 'Badugi率',
        biggest_win: '最大胜利',
        biggest_loss: '最大失败',
        total_winnings: '总收益',
        export: '导出',
        clear: '清空',
        detail: '详情',
        date: '日期',
        result: '结果',
        win: '胜利',
        loss: '失败',
        tie: '平局',
        cards: '牌',
        winnings: '收益'
      },

      notifications: {
        success: '成功',
        error: '错误',
        warning: '警告',
        info: '信息',
        daily_reward_available: '可领取每日奖励！',
        challenge_completed: '挑战完成！',
        achievement_unlocked: '成就解锁！',
        level_up: '升级！',
        insufficient_chips: '筹码不足。',
        purchase_success: '购买成功！',
        purchase_failed: '购买失败！'
      },

      other: {
        welcome: '欢迎！',
        login_streak: '连续登录',
        days: '天',
        hours: '小时',
        minutes: '分钟',
        seconds: '秒',
        today: '今天',
        yesterday: '昨天',
        week: '本周',
        month: '本月',
        year: '今年',
        free: '免费',
        premium: '高级',
        limited: '限定',
        exclusive: '独家'
      }
    }
  };

  // 번역 함수
  function translate(key, locale = currentLocale) {
    const keys = key.split('.');
    let value = translations[locale];

    for (const k of keys) {
      if (value && typeof value === 'object') {
        value = value[k];
      } else {
        console.warn(`Translation not found: ${key} for locale: ${locale}`);
        return key;
      }
    }

    return value || key;
  }

  // 줄임말 (t)
  function t(key, params = {}) {
    let text = translate(key);

    // 파라미터 치환
    Object.keys(params).forEach(param => {
      text = text.replace(`{${param}}`, params[param]);
    });

    return text;
  }

  // 언어 설정
  function setLocale(locale) {
    if (!supportedLocales.includes(locale)) {
      console.warn(`Unsupported locale: ${locale}`);
      return;
    }

    currentLocale = locale;
    localStorage.setItem('badugi_locale', locale);
    updatePageLanguage();
  }

  // 현재 언어 가져오기
  function getLocale() {
    return currentLocale;
  }

  // 지원하는 언어 목록
  function getSupportedLocales() {
    return supportedLocales;
  }

  // 브라우저 언어 감지
  function detectBrowserLocale() {
    const browserLang = navigator.language || navigator.userLanguage;

    // ko-KR -> ko
    const locale = browserLang.split('-')[0];

    if (supportedLocales.includes(locale)) {
      return locale;
    }

    return 'en'; // 기본 영어
  }

  // 페이지 언어 업데이트
  function updatePageLanguage() {
    // HTML lang 속성
    document.documentElement.lang = currentLocale;

    // data-i18n 속성이 있는 요소 업데이트
    document.querySelectorAll('[data-i18n]').forEach(element => {
      const key = element.getAttribute('data-i18n');
      const translation = t(key);
      element.textContent = translation;
    });

    // data-i18n-placeholder 속성이 있는 요소의 placeholder 업데이트
    document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
      const key = element.getAttribute('data-i18n-placeholder');
      const translation = t(key);
      element.placeholder = translation;
    });

    // data-i18n-title 속성이 있는 요소의 title 업데이트
    document.querySelectorAll('[data-i18n-title]').forEach(element => {
      const key = element.getAttribute('data-i18n-title');
      const translation = t(key);
      element.title = translation;
    });

    // RTL 지원 (아랍어, 히브리어 등)
    const isRTL = currentLocale === 'ar' || currentLocale === 'he';
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
  }

  // 초기화
  function init() {
    // 저장된 언어 또는 브라우저 언어
    const savedLocale = localStorage.getItem('badugi_locale');
    currentLocale = savedLocale || detectBrowserLocale();

    updatePageLanguage();
  }

  // 공개 API
  return {
    init,
    t,
    translate,
    setLocale,
    getLocale,
    getSupportedLocales,
    detectBrowserLocale,
    updatePageLanguage
  };
})();

// 전역 노출
window.I18n = I18n;
// 편의 함수
window.t = I18n.t;
