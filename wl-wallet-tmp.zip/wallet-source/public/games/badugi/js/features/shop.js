// client/js/features/shop.js
// 상점 시스템

const Shop = (function() {
    // 상점 카테고리
    const CATEGORIES = {
        CHIPS: { id: 'chips', name: '칩 패키지', icon: '💰' },
        ITEMS: { id: 'items', name: '아이템', icon: '🎁' },
        COSMETICS: { id: 'cosmetics', name: '꾸미기', icon: '✨' },
        SPECIAL: { id: 'special', name: '특별 상품', icon: '⭐' }
    };

    // 상품 목록
    const PRODUCTS = {
        // 칩 패키지
        chips: [
            {
                id: 'chips_starter',
                name: '스타터 패키지',
                description: '입문자를 위한 기본 칩',
                price: 0,
                priceType: 'free',
                amount: 5000,
                icon: '💵',
                cooldown: 86400000, // 24시간
                limit: 1 // 하루 1회
            },
            {
                id: 'chips_small',
                name: '소형 칩 패키지',
                description: '10,000 칩 + 보너스 1,000',
                price: 1000,
                priceType: 'cash',
                amount: 11000,
                icon: '💰',
                bonus: 1000
            },
            {
                id: 'chips_medium',
                name: '중형 칩 패키지',
                description: '50,000 칩 + 보너스 10,000',
                price: 4500,
                priceType: 'cash',
                amount: 60000,
                icon: '💎',
                bonus: 10000,
                popular: true
            },
            {
                id: 'chips_large',
                name: '대형 칩 패키지',
                description: '100,000 칩 + 보너스 30,000',
                price: 8000,
                priceType: 'cash',
                amount: 130000,
                icon: '👑',
                bonus: 30000
            },
            {
                id: 'chips_mega',
                name: '메가 칩 패키지',
                description: '500,000 칩 + 보너스 200,000',
                price: 35000,
                priceType: 'cash',
                amount: 700000,
                icon: '🏆',
                bonus: 200000,
                bestValue: true
            }
        ],

        // 아이템
        items: [
            {
                id: 'double_exp',
                name: '경험치 2배 부스터',
                description: '1시간 동안 경험치 2배',
                price: 5000,
                priceType: 'chips',
                duration: 3600000,
                icon: '⚡',
                effect: { type: 'expBoost', value: 2 }
            },
            {
                id: 'double_exp_24h',
                name: '경험치 2배 (24시간)',
                description: '24시간 동안 경험치 2배',
                price: 50000,
                priceType: 'chips',
                duration: 86400000,
                icon: '🔥',
                effect: { type: 'expBoost', value: 2 },
                popular: true
            },
            {
                id: 'lucky_charm',
                name: '행운의 부적',
                description: '바둑이 확률 소폭 증가 (1시간)',
                price: 10000,
                priceType: 'chips',
                duration: 3600000,
                icon: '🍀',
                effect: { type: 'luckBoost', value: 1.1 }
            },
            {
                id: 'protection',
                name: '파산 보호권',
                description: '1회 파산 시 최소 칩 보장',
                price: 20000,
                priceType: 'chips',
                icon: '🛡️',
                effect: { type: 'protection', value: 10000 },
                stackable: true,
                maxStack: 3
            },
            {
                id: 'reroll_daily',
                name: '일일 챌린지 리롤',
                description: '일일 챌린지 새로고침',
                price: 3000,
                priceType: 'chips',
                icon: '🔄',
                consumable: true
            },
            {
                id: 'tournament_ticket',
                name: '토너먼트 티켓',
                description: '유료 토너먼트 무료 입장권',
                price: 15000,
                priceType: 'chips',
                icon: '🎫',
                consumable: true,
                stackable: true,
                maxStack: 5
            }
        ],

        // 꾸미기
        cosmetics: [
            // 카드 뒷면
            {
                id: 'card_back_gold',
                name: '골드 카드 뒷면',
                description: '화려한 골드 디자인',
                price: 30000,
                priceType: 'chips',
                icon: '🟡',
                type: 'cardBack'
            },
            {
                id: 'card_back_diamond',
                name: '다이아몬드 카드 뒷면',
                description: '빛나는 다이아몬드 패턴',
                price: 50000,
                priceType: 'chips',
                icon: '💎',
                type: 'cardBack',
                rare: true
            },
            {
                id: 'card_back_dragon',
                name: '드래곤 카드 뒷면',
                description: '전설의 드래곤 문양',
                price: 100000,
                priceType: 'chips',
                icon: '🐉',
                type: 'cardBack',
                legendary: true
            },

            // 테이블 테마
            {
                id: 'table_royal',
                name: '로얄 테이블',
                description: '왕실 스타일 테이블',
                price: 50000,
                priceType: 'chips',
                icon: '👑',
                type: 'tableTheme'
            },
            {
                id: 'table_neon',
                name: '네온 테이블',
                description: '사이버펑크 네온 스타일',
                price: 60000,
                priceType: 'chips',
                icon: '🌈',
                type: 'tableTheme',
                rare: true
            },

            // 프로필 프레임
            {
                id: 'frame_fire',
                name: '불꽃 프레임',
                description: '타오르는 불꽃 효과',
                price: 40000,
                priceType: 'chips',
                icon: '🔥',
                type: 'profileFrame'
            },
            {
                id: 'frame_ice',
                name: '얼음 프레임',
                description: '차가운 얼음 효과',
                price: 40000,
                priceType: 'chips',
                icon: '❄️',
                type: 'profileFrame'
            },
            {
                id: 'frame_rainbow',
                name: '무지개 프레임',
                description: '화려한 무지개 애니메이션',
                price: 80000,
                priceType: 'chips',
                icon: '🌈',
                type: 'profileFrame',
                rare: true
            },

            // 이모티콘 팩
            {
                id: 'emoji_pack_fun',
                name: '펀 이모티콘 팩',
                description: '재미있는 이모티콘 10종',
                price: 15000,
                priceType: 'chips',
                icon: '😂',
                type: 'emojiPack',
                contents: ['😂', '🤣', '😎', '🥳', '🤪', '😜', '🤑', '🤩', '😇', '🥴']
            },
            {
                id: 'emoji_pack_poker',
                name: '포커 이모티콘 팩',
                description: '포커 전용 이모티콘 10종',
                price: 20000,
                priceType: 'chips',
                icon: '🃏',
                type: 'emojiPack',
                contents: ['🃏', '🎰', '💰', '🏆', '🔥', '💎', '👑', '⭐', '🍀', '🎲']
            }
        ],

        // 특별 상품
        special: [
            {
                id: 'vip_pass_30',
                name: 'VIP 30일 패스',
                description: 'VIP 혜택 30일 이용권',
                price: 9900,
                priceType: 'cash',
                duration: 2592000000, // 30일
                icon: '👑',
                benefits: [
                    'VIP 전용 방 입장',
                    '일일 보너스 2배',
                    '경험치 획득 1.5배',
                    '전용 이모티콘'
                ]
            },
            {
                id: 'season_pass',
                name: '시즌 패스',
                description: '프리미엄 시즌 패스',
                price: 4900,
                priceType: 'cash',
                icon: '🎫',
                benefits: [
                    '프리미엄 보상 해금',
                    '독점 아이템',
                    '추가 경험치'
                ]
            },
            {
                id: 'starter_bundle',
                name: '스타터 번들',
                description: '신규 유저 특별 패키지',
                price: 4900,
                priceType: 'cash',
                icon: '🎁',
                contents: {
                    chips: 100000,
                    items: ['double_exp', 'lucky_charm', 'protection'],
                    cosmetics: ['card_back_gold']
                },
                oneTimePurchase: true,
                discount: 50
            },
            {
                id: 'lucky_box',
                name: '럭키 박스',
                description: '랜덤 보상이 들어있는 상자',
                price: 10000,
                priceType: 'chips',
                icon: '📦',
                rewards: [
                    { type: 'chips', min: 5000, max: 50000, weight: 50 },
                    { type: 'item', items: ['double_exp', 'lucky_charm'], weight: 30 },
                    { type: 'cosmetic', items: ['card_back_gold', 'frame_fire'], weight: 15 },
                    { type: 'jackpot', amount: 500000, weight: 5 }
                ]
            }
        ]
    };

    // 상태
    let currentCategory = 'chips';
    let ownedItems = new Set();
    let activeEffects = [];
    let itemInventory = {}; // 소모품 수량
    let purchaseHistory = [];
    let lastFreePurchase = {};

    const STORAGE_KEY = 'badugi_shop';

    // 초기화
    function init() {
        loadData();
        checkExpiredEffects();
        console.log('[Shop] 초기화 완료');
    }

    // 데이터 로드
    function loadData() {
        try {
            const saved = localStorage.getItem(STORAGE_KEY);
            if (saved) {
                const data = JSON.parse(saved);
                ownedItems = new Set(data.owned || []);
                activeEffects = data.effects || [];
                itemInventory = data.inventory || {};
                purchaseHistory = data.history || [];
                lastFreePurchase = data.lastFree || {};
            }
        } catch (e) {
            console.error('[Shop] 로드 실패:', e);
        }
    }

    // 데이터 저장
    function saveData() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify({
                owned: Array.from(ownedItems),
                effects: activeEffects,
                inventory: itemInventory,
                history: purchaseHistory.slice(-100), // 최근 100개만
                lastFree: lastFreePurchase
            }));
        } catch (e) {
            console.error('[Shop] 저장 실패:', e);
        }
    }

    // 만료된 효과 체크
    function checkExpiredEffects() {
        const now = Date.now();
        activeEffects = activeEffects.filter(effect => {
            if (effect.expiresAt && effect.expiresAt < now) {
                // 만료 알림
                UI.showToast(`${effect.name} 효과가 만료되었습니다.`, 'info');
                return false;
            }
            return true;
        });
        saveData();
    }

    // 상품 구매
    function purchase(productId) {
        const product = findProduct(productId);
        if (!product) {
            return { success: false, error: '상품을 찾을 수 없습니다.' };
        }

        // 이미 소유한 영구 아이템 체크
        if (!product.consumable && !product.stackable && ownedItems.has(productId)) {
            return { success: false, error: '이미 보유한 상품입니다.' };
        }

        // 1회 구매 제한 체크
        if (product.oneTimePurchase && purchaseHistory.some(h => h.productId === productId)) {
            return { success: false, error: '이미 구매한 상품입니다.' };
        }

        // 무료 상품 쿨다운 체크
        if (product.priceType === 'free' && product.cooldown) {
            const lastPurchase = lastFreePurchase[productId] || 0;
            const timeSince = Date.now() - lastPurchase;
            if (timeSince < product.cooldown) {
                const remaining = Math.ceil((product.cooldown - timeSince) / 60000);
                return { success: false, error: `${remaining}분 후에 다시 받을 수 있습니다.` };
            }
        }

        // 최대 보유 수량 체크
        if (product.stackable && product.maxStack) {
            const currentCount = itemInventory[productId] || 0;
            if (currentCount >= product.maxStack) {
                return { success: false, error: `최대 ${product.maxStack}개까지만 보유할 수 있습니다.` };
            }
        }

        // 가격 체크 및 차감
        if (product.priceType === 'chips') {
            if (State.myChips < product.price) {
                return { success: false, error: '칩이 부족합니다.' };
            }
            State.myChips -= product.price;
            Storage.saveChips(State.myChips);
        } else if (product.priceType === 'cash') {
            // 실제 결제 로직 (여기서는 시뮬레이션)
            return { success: false, error: '결제 시스템 준비 중입니다.', requirePayment: true };
        }
        // free는 무료

        // 상품 지급
        grantProduct(product);

        // 기록
        purchaseHistory.push({
            productId,
            purchasedAt: Date.now(),
            price: product.price,
            priceType: product.priceType
        });

        if (product.priceType === 'free') {
            lastFreePurchase[productId] = Date.now();
        }

        saveData();

        return { success: true, product };
    }

    // 상품 지급
    function grantProduct(product) {
        // 칩 패키지
        if (product.amount) {
            State.myChips += product.amount;
            Storage.saveChips(State.myChips);
        }

        // 효과 아이템
        if (product.effect) {
            if (product.duration) {
                activeEffects.push({
                    id: product.id,
                    name: product.name,
                    effect: product.effect,
                    activatedAt: Date.now(),
                    expiresAt: Date.now() + product.duration
                });
            } else if (product.consumable) {
                // 소모품 인벤토리에 추가
                itemInventory[product.id] = (itemInventory[product.id] || 0) + 1;
            }
        }

        // 꾸미기 아이템
        if (product.type && ['cardBack', 'tableTheme', 'profileFrame', 'emojiPack'].includes(product.type)) {
            ownedItems.add(product.id);
        }

        // 번들 상품
        if (product.contents) {
            if (product.contents.chips) {
                State.myChips += product.contents.chips;
                Storage.saveChips(State.myChips);
            }
            if (product.contents.items) {
                product.contents.items.forEach(itemId => {
                    itemInventory[itemId] = (itemInventory[itemId] || 0) + 1;
                });
            }
            if (product.contents.cosmetics) {
                product.contents.cosmetics.forEach(cosmeticId => {
                    ownedItems.add(cosmeticId);
                });
            }
        }

        // 럭키박스
        if (product.rewards) {
            return openLuckyBox(product);
        }

        // VIP 패스
        if (product.id === 'vip_pass_30') {
            if (typeof VIPSystem !== 'undefined') {
                VIPSystem.activatePass(product.duration);
            }
        }

        // 시즌 패스
        if (product.id === 'season_pass') {
            if (typeof SeasonPass !== 'undefined') {
                SeasonPass.purchasePremium();
            }
        }
    }

    // 럭키박스 열기
    function openLuckyBox(product) {
        const totalWeight = product.rewards.reduce((sum, r) => sum + r.weight, 0);
        let random = Math.random() * totalWeight;

        let selectedReward = null;
        for (const reward of product.rewards) {
            random -= reward.weight;
            if (random <= 0) {
                selectedReward = reward;
                break;
            }
        }

        if (!selectedReward) {
            selectedReward = product.rewards[0];
        }

        let result = { type: selectedReward.type };

        switch (selectedReward.type) {
            case 'chips':
                const amount = Math.floor(Math.random() * (selectedReward.max - selectedReward.min + 1)) + selectedReward.min;
                State.myChips += amount;
                Storage.saveChips(State.myChips);
                result.amount = amount;
                result.message = `${Utils.formatChips(amount)} 칩 획득!`;
                break;

            case 'item':
                const itemId = selectedReward.items[Math.floor(Math.random() * selectedReward.items.length)];
                itemInventory[itemId] = (itemInventory[itemId] || 0) + 1;
                const item = findProduct(itemId);
                result.item = item;
                result.message = `${item?.name || itemId} 획득!`;
                break;

            case 'cosmetic':
                const cosmeticId = selectedReward.items[Math.floor(Math.random() * selectedReward.items.length)];
                ownedItems.add(cosmeticId);
                const cosmetic = findProduct(cosmeticId);
                result.cosmetic = cosmetic;
                result.message = `${cosmetic?.name || cosmeticId} 획득!`;
                result.rare = true;
                break;

            case 'jackpot':
                State.myChips += selectedReward.amount;
                Storage.saveChips(State.myChips);
                result.amount = selectedReward.amount;
                result.message = `🎉 잭팟! ${Utils.formatChips(selectedReward.amount)} 칩!`;
                result.jackpot = true;
                break;
        }

        return result;
    }

    // 상품 찾기
    function findProduct(productId) {
        for (const category of Object.keys(PRODUCTS)) {
            const product = PRODUCTS[category].find(p => p.id === productId);
            if (product) return product;
        }
        return null;
    }

    // 아이템 사용
    function useItem(itemId) {
        const count = itemInventory[itemId] || 0;
        if (count <= 0) {
            return { success: false, error: '아이템이 없습니다.' };
        }

        const product = findProduct(itemId);
        if (!product) {
            return { success: false, error: '아이템을 찾을 수 없습니다.' };
        }

        // 효과 적용
        if (product.effect && product.duration) {
            // 이미 활성화된 같은 효과 체크
            const existingIndex = activeEffects.findIndex(e => e.effect.type === product.effect.type);
            if (existingIndex !== -1) {
                // 시간 연장
                activeEffects[existingIndex].expiresAt += product.duration;
            } else {
                activeEffects.push({
                    id: product.id,
                    name: product.name,
                    effect: product.effect,
                    activatedAt: Date.now(),
                    expiresAt: Date.now() + product.duration
                });
            }
        }

        // 수량 감소
        itemInventory[itemId]--;
        if (itemInventory[itemId] <= 0) {
            delete itemInventory[itemId];
        }

        saveData();

        return { success: true, effect: product.effect };
    }

    // 활성 효과 가져오기
    function getActiveEffect(effectType) {
        checkExpiredEffects();
        const effect = activeEffects.find(e => e.effect.type === effectType);
        return effect ? effect.effect.value : null;
    }

    // 아이템 보유 여부
    function hasItem(itemId) {
        return ownedItems.has(itemId);
    }

    // 아이템 수량
    function getItemCount(itemId) {
        return itemInventory[itemId] || 0;
    }

    // 인벤토리 가져오기
    function getInventory() {
        const inventory = [];

        // 소모품
        for (const [itemId, count] of Object.entries(itemInventory)) {
            const product = findProduct(itemId);
            if (product) {
                inventory.push({ ...product, count });
            }
        }

        return inventory;
    }

    // 보유 꾸미기 아이템
    function getOwnedCosmetics(type = null) {
        const cosmetics = [];

        ownedItems.forEach(itemId => {
            const product = findProduct(itemId);
            if (product && (!type || product.type === type)) {
                cosmetics.push(product);
            }
        });

        return cosmetics;
    }

    // 무료 패키지 남은 시간
    function getFreePackageCooldown(productId) {
        const product = findProduct(productId);
        if (!product || product.priceType !== 'free' || !product.cooldown) {
            return null;
        }

        const lastPurchase = lastFreePurchase[productId] || 0;
        const timeSince = Date.now() - lastPurchase;
        const remaining = product.cooldown - timeSince;

        return remaining > 0 ? remaining : 0;
    }

    // 렌더링
    function render() {
        const content = document.getElementById('shop-content');
        if (!content) return;

        const products = PRODUCTS[currentCategory] || [];

        content.innerHTML = `
            <!-- 상단 정보 -->
            <div class="shop-header">
                <div class="shop-balance">
                    <span class="balance-icon">💰</span>
                    <span class="balance-amount">${Utils.formatChips(State.myChips)}</span>
                </div>
                <button class="btn btn-inventory" onclick="Shop.openInventory()">
                    🎒 인벤토리
                </button>
            </div>

            <!-- 카테고리 탭 -->
            <div class="shop-categories">
                ${Object.values(CATEGORIES).map(cat => `
                    <button class="category-tab ${currentCategory === cat.id ? 'active' : ''}"
                            onclick="Shop.setCategory('${cat.id}')">
                        <span class="cat-icon">${cat.icon}</span>
                        <span class="cat-name">${cat.name}</span>
                    </button>
                `).join('')}
            </div>

            <!-- 상품 목록 -->
            <div class="shop-products">
                ${products.map(product => renderProductCard(product)).join('')}
            </div>
        `;
    }

    // 상품 카드 렌더링
    function renderProductCard(product) {
        const isOwned = !product.consumable && !product.stackable && ownedItems.has(product.id);
        const isPurchased = product.oneTimePurchase && purchaseHistory.some(h => h.productId === product.id);
        const cooldown = getFreePackageCooldown(product.id);
        const inventoryCount = itemInventory[product.id] || 0;

        let priceDisplay = '';
        if (product.priceType === 'free') {
            priceDisplay = cooldown > 0
                ? `<span class="cooldown">${formatCooldown(cooldown)}</span>`
                : '<span class="free">무료</span>';
        } else if (product.priceType === 'chips') {
            priceDisplay = `<span class="chips-price">${Utils.formatChips(product.price)}</span>`;
        } else {
            priceDisplay = `<span class="cash-price">₩${product.price.toLocaleString()}</span>`;
        }

        const canPurchase = !isOwned && !isPurchased && (!cooldown || cooldown <= 0);

        return `
            <div class="product-card ${product.popular ? 'popular' : ''} ${product.bestValue ? 'best-value' : ''}
                        ${product.rare ? 'rare' : ''} ${product.legendary ? 'legendary' : ''}
                        ${isOwned || isPurchased ? 'owned' : ''}">

                ${product.popular ? '<div class="product-badge popular-badge">인기</div>' : ''}
                ${product.bestValue ? '<div class="product-badge value-badge">최고 가치</div>' : ''}
                ${product.discount ? `<div class="product-badge discount-badge">${product.discount}% 할인</div>` : ''}
                ${product.rare ? '<div class="product-badge rare-badge">희귀</div>' : ''}
                ${product.legendary ? '<div class="product-badge legendary-badge">전설</div>' : ''}

                <div class="product-icon ${product.legendary ? 'legendary-glow' : ''}">${product.icon}</div>

                <div class="product-info">
                    <div class="product-name">${product.name}</div>
                    <div class="product-desc">${product.description}</div>

                    ${product.bonus ? `<div class="product-bonus">+${Utils.formatChips(product.bonus)} 보너스!</div>` : ''}
                    ${product.benefits ? `
                        <ul class="product-benefits">
                            ${product.benefits.map(b => `<li>${b}</li>`).join('')}
                        </ul>
                    ` : ''}
                    ${inventoryCount > 0 ? `<div class="inventory-count">보유: ${inventoryCount}개</div>` : ''}
                </div>

                <div class="product-footer">
                    <div class="product-price">${priceDisplay}</div>

                    ${isOwned
                        ? '<button class="btn btn-owned" disabled>보유 중</button>'
                        : isPurchased
                            ? '<button class="btn btn-owned" disabled>구매 완료</button>'
                            : `<button class="btn btn-purchase ${canPurchase ? '' : 'disabled'}"
                                       onclick="Shop.purchaseAndUpdate('${product.id}')"
                                       ${canPurchase ? '' : 'disabled'}>
                                구매
                               </button>`
                    }
                </div>
            </div>
        `;
    }

    // 쿨다운 포맷
    function formatCooldown(ms) {
        const hours = Math.floor(ms / 3600000);
        const minutes = Math.floor((ms % 3600000) / 60000);

        if (hours > 0) {
            return `${hours}시간 ${minutes}분`;
        }
        return `${minutes}분`;
    }

    // 구매 및 UI 업데이트
    function purchaseAndUpdate(productId) {
        const result = purchase(productId);

        if (result.success) {
            const product = result.product;

            // 럭키박스 결과
            if (result.type) {
                showLuckyBoxResult(result);
            } else {
                UI.showToast(`${product.name} 구매 완료!`, 'success');
            }

            Renderer.updateChipsDisplay();
            render();

            if (typeof SoundManager !== 'undefined') {
                SoundManager.playSFX('purchase');
            }
        } else {
            if (result.requirePayment) {
                // 결제 모달 표시
                showPaymentModal(productId);
            } else {
                UI.showToast(result.error, 'error');
            }
        }
    }

    // 럭키박스 결과 표시
    function showLuckyBoxResult(result) {
        const modal = document.createElement('div');
        modal.className = 'lucky-box-result-modal';
        modal.innerHTML = `
            <div class="lucky-box-content ${result.jackpot ? 'jackpot' : ''} ${result.rare ? 'rare' : ''}">
                <div class="box-animation">📦</div>
                <div class="result-message">${result.message}</div>
                <button class="btn btn-primary" onclick="this.closest('.lucky-box-result-modal').remove()">
                    확인
                </button>
            </div>
        `;
        document.body.appendChild(modal);

        if (result.jackpot && typeof AnimationManager !== 'undefined') {
            AnimationManager.showWinCelebration(null, result.amount);
        }
    }

    // 결제 모달 (플레이스홀더)
    function showPaymentModal(productId) {
        UI.showToast('결제 시스템은 준비 중입니다.', 'info');
    }

    // 인벤토리 모달
    function openInventory() {
        const inventory = getInventory();
        const cosmetics = getOwnedCosmetics();
        const effects = activeEffects;

        const modal = document.getElementById('inventory-modal');
        if (!modal) return;

        const content = document.getElementById('inventory-content');
        if (content) {
            content.innerHTML = `
                <!-- 활성 효과 -->
                ${effects.length > 0 ? `
                    <div class="inventory-section">
                        <h4 class="section-title">🔥 활성 효과</h4>
                        <div class="active-effects">
                            ${effects.map(e => {
                                const remaining = e.expiresAt - Date.now();
                                return `
                                    <div class="effect-item">
                                        <span class="effect-name">${e.name}</span>
                                        <span class="effect-time">${formatCooldown(remaining)} 남음</span>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                ` : ''}

                <!-- 소모품 -->
                <div class="inventory-section">
                    <h4 class="section-title">🎒 소모품</h4>
                    ${inventory.length > 0 ? `
                        <div class="inventory-grid">
                            ${inventory.map(item => `
                                <div class="inventory-item" onclick="Shop.useItemAndUpdate('${item.id}')">
                                    <div class="item-icon">${item.icon}</div>
                                    <div class="item-name">${item.name}</div>
                                    <div class="item-count">x${item.count}</div>
                                </div>
                            `).join('')}
                        </div>
                    ` : '<div class="empty-message">소모품이 없습니다.</div>'}
                </div>

                <!-- 꾸미기 아이템 -->
                <div class="inventory-section">
                    <h4 class="section-title">✨ 꾸미기</h4>
                    ${cosmetics.length > 0 ? `
                        <div class="inventory-grid">
                            ${cosmetics.map(item => `
                                <div class="inventory-item cosmetic ${item.type}"
                                     onclick="Shop.equipCosmetic('${item.id}')">
                                    <div class="item-icon">${item.icon}</div>
                                    <div class="item-name">${item.name}</div>
                                </div>
                            `).join('')}
                        </div>
                    ` : '<div class="empty-message">꾸미기 아이템이 없습니다.</div>'}
                </div>
            `;
        }

        modal.classList.remove('hidden');
    }

    // 인벤토리 닫기
    function closeInventory() {
        const modal = document.getElementById('inventory-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    // 아이템 사용 및 업데이트
    function useItemAndUpdate(itemId) {
        const result = useItem(itemId);

        if (result.success) {
            const product = findProduct(itemId);
            UI.showToast(`${product?.name || itemId} 사용!`, 'success');
            openInventory(); // 인벤토리 갱신

            if (typeof SoundManager !== 'undefined') {
                SoundManager.playSFX('itemUse');
            }
        } else {
            UI.showToast(result.error, 'error');
        }
    }

    // 꾸미기 장착
    function equipCosmetic(itemId) {
        const product = findProduct(itemId);
        if (!product) return;

        // 장착 로직 (State에 저장)
        State.equipped = State.equipped || {};
        State.equipped[product.type] = itemId;
        Storage.set('equipped_cosmetics', State.equipped);

        UI.showToast(`${product.name} 장착!`, 'success');
        openInventory(); // 갱신
    }

    // 카테고리 변경
    function setCategory(category) {
        currentCategory = category;
        render();
    }

    // 모달 열기
    function openModal() {
        const modal = document.getElementById('shop-modal');
        if (modal) {
            modal.classList.remove('hidden');
            render();
        }
    }

    // 모달 닫기
    function closeModal() {
        const modal = document.getElementById('shop-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    // Public API
    return {
        init,
        openModal,
        closeModal,
        setCategory,
        purchase,
        purchaseAndUpdate,
        useItem,
        useItemAndUpdate,
        getActiveEffect,
        hasItem,
        getItemCount,
        getInventory,
        getOwnedCosmetics,
        openInventory,
        closeInventory,
        equipCosmetic,
        render,
        CATEGORIES,
        PRODUCTS
    };
})();

window.Shop = Shop;
