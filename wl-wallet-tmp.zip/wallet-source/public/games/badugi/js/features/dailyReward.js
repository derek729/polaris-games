/* ==========================================
   일일 보상 시스템
   ========================================== */

const DailyReward = {

  // 일일 보상 설정
  REWARDS: [
    { day: 1, amount: 1000, bonus: null, icon: '🎁' },
    { day: 2, amount: 2000, bonus: null, icon: '💎' },
    { day: 3, amount: 3000, bonus: 'free_spin', icon: '🎰' },
    { day: 4, amount: 4000, bonus: null, icon: '⭐' },
    { day: 5, amount: 5000, bonus: null, icon: '🌟' },
    { day: 6, amount: 7000, bonus: 'double_exp', icon: '✨' },
    { day: 7, amount: 10000, bonus: 'premium_spin', icon: '👑' }
  ],

  STORAGE_KEY: 'badugi_daily',

  // 데이터 로드
  loadData() {
    const data = Storage.get(this.STORAGE_KEY, {
      lastClaim: null,
      streak: 0,
      totalClaims: 0
    });
    return data;
  },

  // 데이터 저장
  saveData(data) {
    Storage.set(this.STORAGE_KEY, data);
  },

  // 오늘 날짜 문자열
  getTodayString() {
    return new Date().toISOString().split('T')[0];
  },

  // 보상 수령 가능 여부
  canClaim() {
    const data = this.loadData();
    const today = this.getTodayString();
    return data.lastClaim !== today;
  },

  // 연속 출석 계산
  calculateStreak(data) {
    const today = new Date();
    const lastClaim = data.lastClaim ? new Date(data.lastClaim) : null;

    if (!lastClaim) return 1;

    const diffDays = Math.floor((today - lastClaim) / (1000 * 60 * 60 * 24));

    if (diffDays === 1) {
      // 연속 출석
      return (data.streak % 7) + 1;
    } else if (diffDays === 0) {
      // 오늘 이미 받음
      return data.streak;
    } else {
      // 연속 출석 끊김
      return 1;
    }
  },

  // 보상 수령
  claim() {
    if (!this.canClaim()) {
      return { success: false, message: '오늘 이미 보상을 받았습니다.' };
    }

    const data = this.loadData();
    const newStreak = this.calculateStreak(data);
    const reward = this.REWARDS[newStreak - 1];

    // 칩 지급
    Storage.addChips(reward.amount);

    // 데이터 업데이트
    data.lastClaim = this.getTodayString();
    data.streak = newStreak;
    data.totalClaims++;
    this.saveData(data);

    return {
      success: true,
      day: newStreak,
      reward: reward.amount,
      bonus: reward.bonus,
      message: `${newStreak}일차 보상: ${Utils.formatChips(reward.amount)}`
    };
  },

  // 현재 상태 조회
  getStatus() {
    const data = this.loadData();
    const today = this.getTodayString();
    const canClaim = this.canClaim();

    // 현재 출석 일수 계산
    const currentDay = data.lastClaim === today ? data.streak : data.streak + 1;
    if (currentDay > 7) {
      data.streak = 0; // 리셋 후 1일차부터
    }

    return {
      canClaim,
      claimedToday: data.lastClaim === today,
      currentDay,
      currentStreak: data.streak,
      rewards: this.REWARDS
    };
  }
};
