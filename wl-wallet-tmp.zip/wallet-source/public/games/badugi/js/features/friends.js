// client/js/features/friends.js
// 친구 시스템 클라이언트

const Friends = (function() {
    // 상태
    let friendsList = [];
    let onlineFriends = [];
    let friendRequests = [];
    let searchResults = [];
    let currentTab = 'friends'; // friends, requests, search

    // 초기화
    function init() {
        setupEventListeners();
        console.log('[Friends] 초기화 완료');
    }

    // 이벤트 리스너 설정
    function setupEventListeners() {
        if (typeof SocketManager !== 'undefined') {
            // 소켓 이벤트 리스너 등록 (서버에서 보내는 이벤트)
            if (SocketManager.socket) {
                SocketManager.socket.on('friends_data', handleFriendsData);
                SocketManager.socket.on('friends_updated', handleFriendsUpdated);
                SocketManager.socket.on('search_results', handleSearchResults);
                SocketManager.socket.on('friend_request', handleFriendRequest);
                SocketManager.socket.on('friend_accepted', handleFriendAccepted);
                SocketManager.socket.on('friend_request_sent', handleRequestSent);
                SocketManager.socket.on('friend_request_accepted', handleRequestAccepted);
                SocketManager.socket.on('friend_removed', handleFriendRemoved);
                SocketManager.socket.on('game_invite', handleGameInvite);
            }
        }
    }

    // 친구 데이터 수신
    function handleFriendsData(data) {
        friendsList = data.friends || [];
        onlineFriends = data.onlineFriends || [];
        friendRequests = data.requests || [];

        render();
        updateFriendBadge();
    }

    // 친구 목록 업데이트
    function handleFriendsUpdated(data) {
        friendsList = data.friends || [];
        onlineFriends = friendsList.filter(f => f.isOnline);
        render();
    }

    // 검색 결과 수신
    function handleSearchResults(data) {
        searchResults = data.results || data.users || [];
        renderSearchResults();
    }

    // 친구 요청 수신
    function handleFriendRequest(data) {
        friendRequests.push({
            fromId: data.from || data.fromId,
            fromName: data.fromName || data.name,
            fromLevel: data.fromLevel || data.level,
            sentAt: new Date()
        });

        updateFriendBadge();

        // 알림 표시
        UI.showToast(`${data.fromName || data.name}님이 친구 요청을 보냈습니다.`, 'info');

        if (typeof SoundManager !== 'undefined' && SoundManager.playSFX) {
            SoundManager.playSFX('notification');
        }
    }

    // 친구 수락 알림
    function handleFriendAccepted(data) {
        UI.showToast(`${data.userName || data.name}님과 친구가 되었습니다!`, 'success');
        requestFriendsList();
    }

    // 요청 전송 완료
    function handleRequestSent(data) {
        UI.showToast('친구 요청을 보냈습니다.', 'success');

        // 검색 결과 업데이트
        const idx = searchResults.findIndex(u => u.id === data.targetId);
        if (idx !== -1) {
            searchResults[idx].requestSent = true;
            renderSearchResults();
        }
    }

    // 요청 수락 완료
    function handleRequestAccepted(data) {
        friendRequests = friendRequests.filter(r => r.fromId !== data.friendId);
        updateFriendBadge();
        render();
    }

    // 친구 삭제 완료
    function handleFriendRemoved(data) {
        friendsList = friendsList.filter(f => f.id !== data.friendId);
        onlineFriends = onlineFriends.filter(f => f.id !== data.friendId);
        render();
    }

    // 게임 초대 수신
    function handleGameInvite(data) {
        showInviteModal(data);
    }

    // 친구 목록 요청
    function requestFriendsList() {
        if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
            SocketManager.emit('get_friends', {});
        }
    }

    // 사용자 검색
    function searchUsers(query) {
        if (!query || query.trim().length < 2) {
            searchResults = [];
            renderSearchResults();
            return;
        }

        if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
            SocketManager.emit('user_search', { query: query.trim() });
        }
    }

    // 친구 요청 보내기
    function sendFriendRequest(targetId) {
        if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
            SocketManager.emit('friend_request_send', { targetId });
        }
    }

    // 친구 요청 수락
    function acceptRequest(fromId) {
        if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
            SocketManager.emit('friend_request_accept', { requesterId: fromId });
        }
    }

    // 친구 요청 거절
    function rejectRequest(fromId) {
        if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
            SocketManager.emit('friend_request_decline', { requesterId: fromId });
        }
        friendRequests = friendRequests.filter(r => r.fromId !== fromId);
        updateFriendBadge();
        render();
    }

    // 친구 삭제
    function removeFriend(friendId) {
        if (confirm('정말 친구를 삭제하시겠습니까?')) {
            if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
                SocketManager.emit('friend_remove', { friendId });
            }
        }
    }

    // 사용자 차단
    function blockUser(targetId) {
        if (confirm('이 사용자를 차단하시겠습니까?')) {
            if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
                SocketManager.emit('user_block', { targetId });
            }
        }
    }

    // 게임 초대
    function inviteToGame(friendId) {
        // 현재 방 정보 가져오기
        if (typeof NetworkGame !== 'undefined' && NetworkGame.getCurrentRoom) {
            const room = NetworkGame.getCurrentRoom();
            if (!room) {
                UI.showToast('게임 방에 입장한 후 초대할 수 있습니다.', 'warning');
                return;
            }

            if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
                SocketManager.emit('friend_invite', { friendId, roomId: room.id });
            }
        }
    }

    // 탭 변경
    function setTab(tab) {
        currentTab = tab;
        render();
    }

    // 렌더링
    function render() {
        const content = Utils.$('#friends-content');
        if (!content) return;

        content.innerHTML = `
            <!-- 탭 -->
            <div class="friends-tabs">
                <button class="friends-tab ${currentTab === 'friends' ? 'active' : ''}"
                        onclick="Friends.setTab('friends')">
                    친구 (${friendsList.length})
                </button>
                <button class="friends-tab ${currentTab === 'requests' ? 'active' : ''}"
                        onclick="Friends.setTab('requests')">
                    요청
                    ${friendRequests.length > 0 ? `<span class="tab-badge">${friendRequests.length}</span>` : ''}
                </button>
                <button class="friends-tab ${currentTab === 'search' ? 'active' : ''}"
                        onclick="Friends.setTab('search')">
                    검색
                </button>
            </div>

            <!-- 콘텐츠 -->
            <div class="friends-tab-content">
                ${currentTab === 'friends' ? renderFriendsList() : ''}
                ${currentTab === 'requests' ? renderRequestsList() : ''}
                ${currentTab === 'search' ? renderSearchTab() : ''}
            </div>
        `;
    }

    // 친구 목록 렌더링
    function renderFriendsList() {
        if (friendsList.length === 0) {
            return `
                <div class="friends-empty">
                    <div class="empty-icon">👥</div>
                    <div class="empty-text">아직 친구가 없습니다.</div>
                    <div class="empty-hint">검색 탭에서 친구를 추가해보세요!</div>
                </div>
            `;
        }

        // 온라인/오프라인 분리
        const online = friendsList.filter(f => f.isOnline);
        const offline = friendsList.filter(f => !f.isOnline);

        return `
            ${online.length > 0 ? `
                <div class="friends-section">
                    <div class="section-title">
                        <span class="online-indicator"></span>
                        온라인 (${online.length})
                    </div>
                    <div class="friends-list">
                        ${online.map(renderFriendItem).join('')}
                    </div>
                </div>
            ` : ''}

            ${offline.length > 0 ? `
                <div class="friends-section">
                    <div class="section-title">오프라인 (${offline.length})</div>
                    <div class="friends-list">
                        ${offline.map(renderFriendItem).join('')}
                    </div>
                </div>
            ` : ''}
        `;
    }

    // 친구 아이템 렌더링
    function renderFriendItem(friend) {
        return `
            <div class="friend-item ${friend.isOnline ? 'online' : 'offline'}">
                <div class="friend-avatar">
                    <span class="avatar-level">${friend.vip ? friend.vip.level : 1}</span>
                    ${friend.isOnline ? '<span class="online-dot"></span>' : ''}
                </div>
                <div class="friend-info">
                    <div class="friend-name">${friend.name}</div>
                    <div class="friend-status">
                        ${friend.isOnline
                            ? (friend.currentRoom ? `${friend.currentRoom} 게임 중` : '로비')
                            : getLastSeenText(friend.lastSeen)}
                    </div>
                </div>
                <div class="friend-actions">
                    ${friend.isOnline ? `
                        <button class="btn-friend-action" onclick="Friends.inviteToGame('${friend.id}')" title="게임 초대">
                            🎮
                        </button>
                    ` : ''}
                    <button class="btn-friend-action" onclick="Profile.openModal('${friend.id}')" title="프로필">
                        👤
                    </button>
                    <button class="btn-friend-action danger" onclick="Friends.removeFriend('${friend.id}')" title="삭제">
                        ✕
                    </button>
                </div>
            </div>
        `;
    }

    // 요청 목록 렌더링
    function renderRequestsList() {
        if (friendRequests.length === 0) {
            return `
                <div class="friends-empty">
                    <div class="empty-icon">📬</div>
                    <div class="empty-text">받은 친구 요청이 없습니다.</div>
                </div>
            `;
        }

        return `
            <div class="requests-list">
                ${friendRequests.map(renderRequestItem).join('')}
            </div>
        `;
    }

    // 요청 아이템 렌더링
    function renderRequestItem(request) {
        return `
            <div class="request-item">
                <div class="request-avatar">
                    <span class="avatar-level">${request.fromLevel || 1}</span>
                </div>
                <div class="request-info">
                    <div class="request-name">${request.fromName}</div>
                    <div class="request-time">${getTimeAgo(request.sentAt)}</div>
                </div>
                <div class="request-actions">
                    <button class="btn-accept" onclick="Friends.acceptRequest('${request.fromId}')">
                        수락
                    </button>
                    <button class="btn-reject" onclick="Friends.rejectRequest('${request.fromId}')">
                        거절
                    </button>
                </div>
            </div>
        `;
    }

    // 검색 탭 렌더링
    function renderSearchTab() {
        return `
            <div class="search-container">
                <div class="search-input-wrapper">
                    <input type="text" id="friend-search-input" class="search-input"
                           placeholder="닉네임으로 검색 (2자 이상)"
                           oninput="Friends.onSearchInput(this.value)">
                    <span class="search-icon">🔍</span>
                </div>
            </div>
            <div id="search-results" class="search-results">
                ${renderSearchResults()}
            </div>
        `;
    }

    // 검색 입력 처리 (디바운스)
    let searchTimeout = null;
    function onSearchInput(value) {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            searchUsers(value);
        }, 300);
    }

    // 검색 결과 렌더링
    function renderSearchResults() {
        const container = Utils.$('#search-results');

        const html = searchResults.length === 0
            ? `
                <div class="search-empty">
                    <div class="empty-text">검색 결과가 없습니다.</div>
                </div>
            `
            : `
                <div class="search-results-list">
                    ${searchResults.map(renderSearchResultItem).join('')}
                </div>
            `;

        if (container) {
            container.innerHTML = html;
        }

        return html;
    }

    // 검색 결과 아이템 렌더링
    function renderSearchResultItem(user) {
        const isFriend = user.isFriend;
        const hasPending = user.hasPendingRequest || user.requestSent;

        return `
            <div class="search-result-item">
                <div class="result-avatar">
                    <span class="avatar-level">${user.vip ? user.vip.level : 1}</span>
                    ${user.isOnline ? '<span class="online-dot"></span>' : ''}
                </div>
                <div class="result-info">
                    <div class="result-name">${user.name}</div>
                    <div class="result-stats">
                        Lv.${user.vip ? user.vip.level : 1} · 승률 ${user.stats?.winRate || 0}%
                    </div>
                </div>
                <div class="result-action">
                    ${isFriend
                        ? '<span class="already-friend">친구</span>'
                        : hasPending
                            ? '<span class="request-pending">요청됨</span>'
                            : `<button class="btn-add-friend" onclick="Friends.sendFriendRequest('${user.id}')">
                                친구 추가
                               </button>`
                    }
                </div>
            </div>
        `;
    }

    // 초대 모달 표시
    function showInviteModal(data) {
        const modal = document.createElement('div');
        modal.className = 'invite-modal';
        modal.innerHTML = `
            <div class="invite-content">
                <div class="invite-icon">🎮</div>
                <div class="invite-text">
                    <strong>${data.fromName}</strong>님이<br>게임에 초대했습니다!
                </div>
                <div class="invite-actions">
                    <button class="btn-accept-invite" onclick="Friends.acceptInvite('${data.roomId}', this)">
                        참가
                    </button>
                    <button class="btn-reject-invite" onclick="Friends.rejectInvite(this)">
                        거절
                    </button>
                </div>
            </div>
        `;

        document.body.appendChild(modal);

        // 애니메이션
        requestAnimationFrame(() => {
            modal.classList.add('show');
        });

        // 30초 후 자동 닫기
        setTimeout(() => {
            if (modal.parentNode) {
                modal.classList.remove('show');
                setTimeout(() => modal.remove(), 300);
            }
        }, 30000);

        // 사운드
        if (typeof SoundManager !== 'undefined' && SoundManager.playSFX) {
            SoundManager.playSFX('notification');
        }
    }

    // 초대 수락
    function acceptInvite(roomId, btn) {
        const modal = btn.closest('.invite-modal');
        if (modal) {
            modal.classList.remove('show');
            setTimeout(() => modal.remove(), 300);
        }

        // 방 입장
        if (typeof SocketManager !== 'undefined' && SocketManager.joinRoom) {
            SocketManager.joinRoom(roomId);
        }
    }

    // 초대 거절
    function rejectInvite(btn) {
        const modal = btn.closest('.invite-modal');
        if (modal) {
            modal.classList.remove('show');
            setTimeout(() => modal.remove(), 300);
        }
    }

    // 친구 배지 업데이트
    function updateFriendBadge() {
        const badge = Utils.$('#friends-badge');
        if (badge) {
            if (friendRequests.length > 0) {
                badge.textContent = friendRequests.length;
                badge.style.display = 'flex';
            } else {
                badge.style.display = 'none';
            }
        }
    }

    // 마지막 접속 시간 텍스트
    function getLastSeenText(date) {
        if (!date) return '오프라인';

        const now = new Date();
        const last = new Date(date);
        const diffMs = now - last;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);

        if (diffMins < 1) return '방금 전';
        if (diffMins < 60) return `${diffMins}분 전`;
        if (diffHours < 24) return `${diffHours}시간 전`;
        if (diffDays < 7) return `${diffDays}일 전`;
        return '오래 전';
    }

    // 시간 경과 텍스트
    function getTimeAgo(date) {
        return getLastSeenText(date);
    }

    // 모달 열기
    function openModal() {
        const modal = Utils.$('#friends-modal');
        if (modal) {
            Utils.show('#friends-modal');
            requestFriendsList();
        }
    }

    // 모달 닫기
    function closeModal() {
        const modal = Utils.$('#friends-modal');
        if (modal) {
            Utils.hide('#friends-modal');
        }
    }

    // Public API
    return {
        init,
        openModal,
        closeModal,
        setTab,
        searchUsers,
        onSearchInput,
        sendFriendRequest,
        acceptRequest,
        rejectRequest,
        removeFriend,
        blockUser,
        inviteToGame,
        acceptInvite,
        rejectInvite,
        requestFriendsList
    };
})();

window.Friends = Friends;
