/* ==========================================
   일일 챌린지 시스템
   ========================================== */

const DailyChallenge = {
  // 챌린지 템플릿
  templates: [
    {
      id: 'win_3_games',
      name: '승리의 시작',
      description: '3게임 승리',
      difficulty: 'EASY',
      requirement: 3,
      reward: { chips: 5000, exp: 500 },
      icon: '🎯',
      type: 'wins'
    },
    {
      id: 'play_5_hands',
      name: '핸드 플레이',
      description: '5핸드 플레이',
      difficulty: 'EASY',
      requirement: 5,
      reward: { chips: 3000, exp: 300 },
      icon: '🃏',
      type: 'hands'
    },
    {
      id: 'badugi_2',
      name: '바둑이 헌터',
      description: '바둑이 2회 완성',
      difficulty: 'EASY',
      requirement: 2,
      reward: { chips: 7000, exp: 700 },
      icon: '🎴',
      type: 'badugi'
    },
    {
      id: 'win_50k',
      name: '소액 승리',
      description: '50,000칩 이상 획득',
      difficulty: 'EASY',
      requirement: 50000,
      reward: { chips: 4000, exp: 400 },
      icon: '💰',
      type: 'chips'
    },
    {
      id: 'allin_2',
      name: '올인 도전',
      description: '올인 2회',
      difficulty: 'EASY',
      requirement: 2,
      reward: { chips: 3000, exp: 300 },
      icon: '💥',
      type: 'allin'
    },
    {
      id: 'win_5_games',
      name: '연승 도전',
      description: '5게임 승리',
      difficulty: 'MEDIUM',
      requirement: 5,
      reward: { chips: 15000, exp: 1500 },
      icon: '⭐',
      type: 'wins'
    },
    {
      id: 'three_card_3',
      name: '쓰리카드 마스터',
      description: '쓰리카드 3회 완성',
      difficulty: 'MEDIUM',
      requirement: 3,
      reward: { chips: 12000, exp: 1200 },
      icon: '3️⃣',
      type: 'three_card'
    },
    {
      id: 'win_100k',
      name: '중형 승리',
      description: '100,000칩 이상 획득',
      difficulty: 'MEDIUM',
      requirement: 100000,
      reward: { chips: 10000, exp: 1000 },
      icon: '💎',
      type: 'chips'
    },
    {
      id: 'royal_badugi',
      name: '로열 바둑이',
      description: 'A-2-3-4 바둑이 완성',
      difficulty: 'MEDIUM',
      requirement: 1,
      reward: { chips: 20000, exp: 2000 },
      icon: '👑',
      type: 'royal'
    },
    {
      id: 'streak_3',
      name: '3연승',
      description: '3연승 달성',
      difficulty: 'MEDIUM',
      requirement: 3,
      reward: { chips: 18000, exp: 1800 },
      icon: '🔥',
      type: 'streak'
    },
    {
      id: 'win_10_games',
      name: '승리의 왕',
      description: '10게임 승리',
      difficulty: 'HARD',
      requirement: 10,
      reward: { chips: 50000, exp: 5000 },
      icon: '🏆',
      type: 'wins'
    },
    {
      id: 'badugi_5',
      name: '바둑이 마스터',
      description: '바둑이 5회 완성',
      difficulty: 'HARD',
      requirement: 5,
      reward: { chips: 40000, exp: 4000 },
      icon: '🎴',
      type: 'badugi'
    },
    {
      id: 'win_200k',
      name: '대형 승리',
      description: '200,000칩 이상 획득',
      difficulty: 'HARD',
      requirement: 200000,
      reward: { chips: 35000, exp: 3500 },
      icon: '💰',
      type: 'chips'
    },
    {
      id: 'streak_5',
      name: '무적의 5연승',
      description: '5연승 달성',
      difficulty: 'HARD',
      requirement: 5,
      reward: { chips: 60000, exp: 6000 },
      icon: '⚡',
      type: 'streak'
    },
    {
      id: 'showdown_10',
      name: '쇼다운 왕',
      description: '쇼다운 10회 승리',
      difficulty: 'HARD',
      requirement: 10,
      reward: { chips: 30000, exp: 3000 },
      icon: '🎯',
      type: 'showdown'
    }
  ],

  // 난이도별 보상 배수
  difficultyMultipliers: {
    EASY: 1,
    MEDIUM: 2,
    HARD: 3
  },

  // 플레이어 데이터
  playerData: {
    challenges: [],
    lastReset: null,
    completedToday: 0
  },

  // 초기화
  init() {
    this.loadData();
    this.checkReset();
    this.saveData();
  },

  // 데이터 로드
  loadData() {
    const saved = Storage.get('badugi_daily_challenges', {
      challenges: [],
      lastReset: null,
      completedToday: 0
    });
    this.playerData = saved;
  },

  // 데이터 저장
  saveData() {
    Storage.set('badugi_daily_challenges', this.playerData);
  },

  // 리셋 체크 (매일 자정)
  checkReset() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (!this.playerData.lastReset || new Date(this.playerData.lastReset) < today) {
      this.generateChallenges();
      this.playerData.lastReset = today.toISOString();
      this.playerData.completedToday = 0;
    }
  },

  // 챌린지 생성 (5개)
  generateChallenges() {
    const shuffled = [...this.templates].sort(() => Math.random() - 0.5);

    // 난이도 균형 배치: EASY 2개, MEDIUM 2개, HARD 1개
    const difficulties = ['EASY', 'EASY', 'MEDIUM', 'MEDIUM', 'HARD'];
    const challenges = [];

    difficulties.forEach((difficulty, index) => {
      const template = shuffled.find(t => t.difficulty === difficulty && !challenges.find(c => c.id === t.id));
      if (template) {
        const multiplier = this.difficultyMultipliers[difficulty];

        challenges.push({
          ...template,
          challengeId: `${template.id}_${Date.now()}_${index}`,
          progress: 0,
          completed: false,
          claimed: false
        });
      }
    });

    this.playerData.challenges = challenges;
  },

  // 챌린지 진행 업데이트
  updateProgress(type, value) {
    let updated = false;

    this.playerData.challenges.forEach(challenge => {
      if (challenge.completed || challenge.type !== type) return;

      challenge.progress = Math.min(challenge.progress + value, challenge.requirement);

      if (challenge.progress >= challenge.requirement) {
        challenge.completed = true;
        updated = true;

        // 완료 알림
        this.showCompletionNotification(challenge);
      }
    });

    if (updated) {
      this.saveData();
      this.renderChallenges();
    }
  },

  // 완료 알림
  showCompletionNotification(challenge) {
    UI.showToast(
      'success',
      '✅ 챌린지 완료!',
      `${challenge.icon} ${challenge.name}`,
      `보상: +${Utils.formatChips(challenge.reward.chips)}칩, +${challenge.reward.exp}EXP`
    );
  },

  // 보상 수령
  claimReward(challengeId) {
    const challenge = this.playerData.challenges.find(c => c.challengeId === challengeId);
    if (!challenge || !challenge.completed || challenge.claimed) {
      return;
    }

    challenge.claimed = true;
    this.playerData.completedToday++;

    // 보상 지급
    if (challenge.reward.chips) {
      State.addChips(challenge.reward.chips);
    }
    if (challenge.reward.exp && typeof VIPSystem !== 'undefined') {
      VIPSystem.addExp(challenge.reward.exp);
    }

    UI.showToast(
      'success',
      '보상 수령!',
      `+${Utils.formatChips(challenge.reward.chips)}칩, +${challenge.reward.exp}EXP`
    );

    this.saveData();
    this.renderChallenges();
  },

  // 전체 보상 수령
  claimAll() {
    let totalChips = 0;
    let totalExp = 0;
    let claimed = 0;

    this.playerData.challenges.forEach(challenge => {
      if (challenge.completed && !challenge.claimed) {
        challenge.claimed = true;
        totalChips += challenge.reward.chips;
        totalExp += challenge.reward.exp;
        claimed++;
      }
    });

    if (claimed === 0) {
      UI.showToast('수령할 보상이 없습니다.', 'info');
      return;
    }

    this.playerData.completedToday += claimed;

    // 보상 지급
    State.addChips(totalChips);
    if (typeof VIPSystem !== 'undefined') {
      VIPSystem.addExp(totalExp);
    }

    UI.showToast(
      'success',
      `전체 보상 수령! (${claimed}개)`,
      `+${Utils.formatChips(totalChips)}칩, +${totalExp}EXP`
    );

    this.saveData();
    this.renderChallenges();
  },

  // 챌린지 렌더링
  renderChallenges() {
    const container = Utils.$('#daily-challenges-list');
    if (!container) return;

    this.checkReset();

    if (this.playerData.challenges.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📋</div>
          <p>챌린지를 불러오는 중...</p>
        </div>
      `;
      return;
    }

    container.innerHTML = this.playerData.challenges.map(challenge => {
      const progress = Math.min(100, Math.floor((challenge.progress / challenge.requirement) * 100));
      const canClaim = challenge.completed && !challenge.claimed;

      return `
        <div class="challenge-card ${canClaim ? 'claimable' : ''} ${challenge.claimed ? 'claimed' : ''}" data-challenge-id="${challenge.challengeId}">
          <div class="challenge-header">
            <div class="challenge-icon">${challenge.icon}</div>
            <div class="challenge-info">
              <div class="challenge-title">${challenge.name}</div>
              <div class="challenge-desc">${challenge.description}</div>
            </div>
            <div class="challenge-difficulty difficulty-${challenge.difficulty.toLowerCase()}">
              ${this.getDifficultyText(challenge.difficulty)}
            </div>
          </div>

          <div class="challenge-progress">
            <div class="progress-bar">
              <div class="progress-fill" style="width: ${progress}%"></div>
            </div>
            <div class="progress-text">${challenge.progress}/${challenge.requirement}</div>
          </div>

          <div class="challenge-reward">
            <span class="reward-chips">💰 ${Utils.formatChips(challenge.reward.chips)}</span>
            <span class="reward-exp">⭐ ${challenge.reward.exp}EXP</span>
          </div>

          ${canClaim ? `
            <button class="btn btn-claim" onclick="DailyChallenge.claimReward('${challenge.challengeId}')">수령</button>
          ` : challenge.claimed ? `
            <button class="btn btn-disabled" disabled>수령 완료</button>
          ` : ''}
        </div>
      `;
    }).join('');

    // 전체 수령 버튼
    const claimAllBtn = Utils.$('#claim-all-challenges-btn');
    if (claimAllBtn) {
      const hasClaimable = this.playerData.challenges.some(c => c.completed && !c.claimed);
      claimAllBtn.disabled = !hasClaimable;
      claimAllBtn.classList.toggle('disabled', !hasClaimable);
    }

    // 남은 시간 업데이트
    this.updateTimeRemaining();
  },

  // 난이도 텍스트
  getDifficultyText(difficulty) {
    const texts = {
      EASY: '쉬움',
      MEDIUM: '보통',
      HARD: '어려움'
    };
    return texts[difficulty] || difficulty;
  },

  // 남은 시간 업데이트
  updateTimeRemaining() {
    const container = Utils.$('#challenge-time-remaining');
    if (!container) return;

    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);

    const remaining = tomorrow - now;
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));

    container.textContent = `리셋까지: ${hours}시간 ${minutes}분`;
  },

  // 완료된 챌린지 수
  getCompletedCount() {
    return this.playerData.challenges.filter(c => c.completed).length;
  },

  // 수령 가능한 챌린지 수
  getClaimableCount() {
    return this.playerData.challenges.filter(c => c.completed && !c.claimed).length;
  },

  // 모달 열기
  openModal() {
    const modal = Utils.$('#daily-challenge-modal');
    if (modal) {
      modal.classList.remove('hidden');
      this.renderChallenges();
    }
  },

  // 모달 닫기
  closeModal() {
    const modal = Utils.$('#daily-challenge-modal');
    if (modal) {
      modal.classList.add('hidden');
    }
  }
};

// 전역 노출
window.DailyChallenge = DailyChallenge;
