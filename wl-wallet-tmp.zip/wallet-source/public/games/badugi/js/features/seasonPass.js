/* ==========================================
   시즌 패스 시스템 (완성版)
   ========================================== */

const SeasonPass = (function() {
    // 상수
    const EXP_PER_LEVEL = 1000;
    const CURRENT_SEASON = {
        id: 1,
        name: '첫 번째 시즌',
        startDate: new Date('2024-01-01'),
        endDate: new Date('2024-12-31'),
        maxLevel: 50
    };

    // 아이템 정의
    const ITEMS = {
        // 카드 백
        'cardback_classic': { name: '클래식 카드 백', icon: '🃏', type: 'cardback', rare: false },
        'cardback_gold': { name: '골드 카드 백', icon: '✨', type: 'cardback', rare: true },
        'cardback_diamond': { name: '다이아몬드 카드 백', icon: '💎', type: 'cardback', rare: true },
        'cardback_dragon': { name: '드래곤 카드 백', icon: '🐉', type: 'cardback', rare: true },
        'cardback_phoenix': { name: '피닉스 카드 백', icon: '🔥', type: 'cardback', rare: true },

        // 아바타
        'avatar_cool': { name: '쿨 가이', icon: '😎', type: 'avatar', rare: false },
        'avatar_king': { name: '포커 왕', icon: '👑', type: 'avatar', rare: true },
        'avatar_wizard': { name: '마법사', icon: '🧙', type: 'avatar', rare: true },
        'avatar_alien': { name: '에이리언', icon: '👽', type: 'avatar', rare: true },

        // 이모트
        'emote_fire': { name: '파이어', icon: '🔥', type: 'emote', rare: false },
        'emote_rocket': { name: '로켓', icon: '🚀', type: 'emote', rare: false },
        'emote_rainbow': { name: '레인보우', icon: '🌈', type: 'emote', rare: true },

        // 프레임
        'frame_silver': { name: '실버 프레임', icon: '🥈', type: 'frame', rare: true },
        'frame_gold': { name: '골드 프레임', icon: '🥇', type: 'frame', rare: true },
        'frame_champion': { name: '챔피언 프레임', icon: '🏆', type: 'frame', rare: true },

        // 칭호
        'title_expert': { name: '전문가', icon: '🎯', type: 'title', rare: false },
        'title_master': { name: '마스터', icon: '👑', type: 'title', rare: true },
        'title_legend': { name: '전설', icon: '⭐', type: 'title', rare: true },
        'title_season_champion': { name: '시즌 챔피언', icon: '🏆', type: 'title', rare: true }
    };

    // 플레이어 상태
    let currentLevel = 1;
    let currentExp = 0;
    let isPremium = false;
    let claimedFree = [];
    let claimedPremium = [];
    let unlockedItems = new Set();

    // 초기화
    function init() {
        loadData();
        setupAutoSave();
        render();
    }

    // 데이터 로드
    function loadData() {
        const saved = localStorage.getItem('badugi_season_pass_v2');
        if (saved) {
            try {
                const data = JSON.parse(saved);
                currentLevel = data.level || 1;
                currentExp = data.exp || 0;
                isPremium = data.isPremium || false;
                claimedFree = data.claimedFree || [];
                claimedPremium = data.claimedPremium || [];
                unlockedItems = new Set(data.unlockedItems || []);
            } catch (e) {
                console.error('시즌 패스 데이터 로드 실패:', e);
            }
        }
    }

    // 데이터 저장
    function saveData() {
        const data = {
            level: currentLevel,
            exp: currentExp,
            isPremium,
            claimedFree,
            claimedPremium,
            unlockedItems: Array.from(unlockedItems)
        };
        localStorage.setItem('badugi_season_pass_v2', JSON.stringify(data));
    }

    // 자동 저장
    function setupAutoSave() {
        setInterval(saveData, 30000);
    }

    // EXP 추가
    function addExp(amount) {
        const totalExp = currentExp + amount;
        const levelsGained = Math.floor(totalExp / EXP_PER_LEVEL);

        currentLevel = Math.min(CURRENT_SEASON.maxLevel, currentLevel + levelsGained);
        currentExp = totalExp % EXP_PER_LEVEL;

        if (levelsGained > 0) {
            // 레벨업 알림
            UI.showToast(`레벨 ${currentLevel} 달성!`, 'success');
        }

        saveData();
        render();
    }

    // 보상 수령
    function claimReward(level, type) {
        if (level > currentLevel) {
            return { success: false, error: '레벨이 부족합니다.' };
        }

        const isPremiumReward = type === 'premium';
        const claimedList = isPremiumReward ? claimedPremium : claimedFree;

        if (claimedList.includes(level)) {
            return { success: false, error: '이미 수령한 보상입니다.' };
        }

        if (isPremiumReward && !isPremium) {
            return { success: false, error: '프리미엄이 필요합니다.' };
        }

        // 보상 설정
        const reward = getRewardForLevel(level, isPremiumReward);
        if (!reward) {
            return { success: false, error: '보상을 찾을 수 없습니다.' };
        }

        // 보상 지급
        let chips = 0;
        const newItemIds = [];

        if (reward.chips) {
            chips = reward.chips;
            State.addChips(chips);
        }

        if (reward.item) {
            unlockedItems.add(reward.item);
            newItemIds.push(reward.item);
        }

        claimedList.push(level);
        saveData();

        return {
            success: true,
            chips,
            items: newItemIds.map(id => ITEMS[id])
        };
    }

    // 전체 보상 수령
    function claimAllRewards() {
        let totalChips = 0;
        const newItems = [];

        for (let level = 1; level <= currentLevel; level++) {
            // 무료 보상
            if (!claimedFree.includes(level)) {
                const reward = getRewardForLevel(level, false);
                if (reward) {
                    if (reward.chips) totalChips += reward.chips;
                    if (reward.item) {
                        unlockedItems.add(reward.item);
                        newItems.push(reward.item);
                    }
                    claimedFree.push(level);
                }
            }

            // 프리미엄 보상
            if (isPremium && !claimedPremium.includes(level)) {
                const reward = getRewardForLevel(level, true);
                if (reward) {
                    if (reward.chips) totalChips += reward.chips;
                    if (reward.item) {
                        unlockedItems.add(reward.item);
                        newItems.push(reward.item);
                    }
                    claimedPremium.push(level);
                }
            }
        }

        if (totalChips > 0) {
            State.addChips(totalChips);
        }

        saveData();
        render();

        return {
            totalChips,
            newItems: newItems.map(id => ITEMS[id])
        };
    }

    // 레벨별 보상 가져오기
    function getRewardForLevel(level, isPremium) {
        const baseMultiplier = isPremium ? 2 : 1;
        const chips = Math.floor(1000 * level * baseMultiplier);

        // 특정 레벨에서 아이템 지급
        const itemLevels = {
            5: isPremium ? 'cardback_classic' : null,
            10: isPremium ? 'emote_fire' : null,
            15: isPremium ? 'cardback_gold' : null,
            20: isPremium ? 'avatar_cool' : null,
            25: isPremium ? 'emote_rocket' : null,
            30: isPremium ? 'frame_silver' : null,
            35: isPremium ? 'cardback_diamond' : null,
            40: isPremium ? 'avatar_king' : null,
            45: isPremium ? 'emote_rainbow' : null,
            50: isPremium ? 'cardback_phoenix' : 'title_expert'
        };

        const item = itemLevels[level] || null;

        return { chips, item };
    }

    // 프리미엄 구매
    function purchasePremium() {
        if (isPremium) {
            UI.showToast('이미 프리미엄입니다.', 'info');
            return;
        }

        const price = 100000;

        if (State.myChips < price) {
            UI.showToast('칩이 부족합니다.', 'error');
            return;
        }

        if (!confirm(`프리미엄 시즌 패스를 구매하시겠습니까?\n가격: ${Utils.formatChips(price)}`)) {
            return;
        }

        State.addChips(-price);
        isPremium = true;
        saveData();
        render();

        UI.showToast('프리미엄 시즌 패스를 구매했습니다!', 'success');
    }

    // 미수령 보상 수
    function getUnclaimedCount() {
        let count = 0;
        for (let level = 1; level <= currentLevel; level++) {
            if (!claimedFree.includes(level)) count++;
            if (isPremium && !claimedPremium.includes(level)) count++;
        }
        return count;
    }

    // 남은 시간
    function getTimeRemaining() {
        const now = new Date();
        const end = new Date(CURRENT_SEASON.endDate);
        const diff = end - now;

        if (diff <= 0) return '시즌 종료';

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

        return `${days}일 ${hours}시간`;
    }

    // 렌더링
    function render() {
        const container = document.getElementById('season-pass-content');
        if (!container) return;

        const progress = (currentExp / EXP_PER_LEVEL) * 100;

        let html = `
            <div class="season-header">
                <div>
                    <div class="season-name">${CURRENT_SEASON.name}</div>
                    <div class="season-timer">${getTimeRemaining()}</div>
                </div>
                <div class="level-display">
                    <div class="level-badge ${isPremium ? 'premium' : ''}">
                        <span class="level-number">${currentLevel}</span>
                    </div>
                    <div class="level-progress">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${progress}%"></div>
                        </div>
                        <div class="progress-text">${currentExp}/${EXP_PER_LEVEL} EXP</div>
                    </div>
                </div>
            </div>
        `;

        // 프리미엄 배너
        if (!isPremium) {
            html += `
                <div class="premium-banner" onclick="SeasonPass.purchasePremium()">
                    <div class="premium-icon">👑</div>
                    <div class="premium-text">
                        <div class="premium-title">프리미엄 시즌 패스</div>
                        <div class="premium-desc">모든 프리미엄 보상 해금!</div>
                    </div>
                    <div class="premium-price">${Utils.formatChips(100000)}</div>
                </div>
            `;
        }

        // 보상 트랙
        html += '<div class="reward-track">';

        for (let level = 1; level <= CURRENT_SEASON.maxLevel; level++) {
            const isUnlocked = level <= currentLevel;
            const freeClaimed = claimedFree.includes(level);
            const premiumClaimed = claimedPremium.includes(level);
            const freeReward = getRewardForLevel(level, false);
            const premiumReward = getRewardForLevel(level, true);

            html += `
                <div class="reward-level ${isUnlocked ? 'unlocked' : 'locked'} ${level === currentLevel ? 'current' : ''}">
                    <div class="level-marker">
                        <span class="level-num">${level}</span>
                    </div>

                    <!-- 무료 보상 -->
                    <div class="reward-box ${freeClaimed ? 'claimed' : ''} ${isUnlocked && !freeClaimed ? 'available' : ''}"
                         onclick="${isUnlocked && !freeClaimed ? `SeasonPass.claimAndUpdate(${level}, 'free')` : ''}">
                        <div class="reward-content">
                            ${freeReward.item
                                ? `<div class="reward-item ${ITEMS[freeReward.item]?.rare ? 'rare' : ''}">${ITEMS[freeReward.item]?.icon || '🎁'}</div>`
                                : `<div class="reward-chips">+${Utils.formatChips(freeReward.chips)}</div>`
                            }
                        </div>
                        ${freeClaimed ? '<div class="claimed-check">✓</div>' : ''}
                        <div class="reward-label">무료</div>
                    </div>

                    <!-- 프리미엄 보상 -->
                    <div class="reward-box premium ${!isPremium ? 'locked' : ''} ${premiumClaimed ? 'claimed' : ''} ${isPremium && isUnlocked && !premiumClaimed ? 'available' : ''}"
                         onclick="${isUnlocked && isPremium && !premiumClaimed ? `SeasonPass.claimAndUpdate(${level}, 'premium')` : ''}">
                        <div class="reward-content">
                            ${premiumReward.item
                                ? `<div class="reward-item ${ITEMS[premiumReward.item]?.rare ? 'rare' : ''}">${ITEMS[premiumReward.item]?.icon || '🎁'}</div>`
                                : `<div class="reward-chips">+${Utils.formatChips(premiumReward.chips)}</div>`
                            }
                        </div>
                        ${!isPremium ? '<div class="lock-icon">🔒</div>' : ''}
                        ${premiumClaimed ? '<div class="claimed-check">✓</div>' : ''}
                        <div class="reward-label premium-label">프리미엄</div>
                </div>
            `;
        }

        html += '</div>';

        container.innerHTML = html;
    }

    // 보상 수령 및 UI 업데이트
    function claimAndUpdate(level, type) {
        const result = claimReward(level, type);
        if (result.success) {
            let message = `+${Utils.formatChips(result.chips)}`;
            if (result.item) {
                message += ` & ${result.item.name}`;
            }
            UI.showToast(message, 'success');
            Renderer.updateChipsDisplay();
            render();

            if (typeof SoundManager !== 'undefined') {
                SoundManager.playSFX('reward');
            }
        } else {
            UI.showToast(result.error, 'error');
        }
    }

    // 모든 보상 수령 및 업데이트
    function claimAllAndUpdate() {
        const result = claimAllRewards();
        if (result.totalChips > 0 || result.newItems.length > 0) {
            let message = '';
            if (result.totalChips > 0) {
                message += `+${Utils.formatChips(result.totalChips)}`;
            }
            if (result.newItems.length > 0) {
                message += ` & 아이템 ${result.newItems.length}개`;
            }
            UI.showToast(message, 'success');
            Renderer.updateChipsDisplay();
            render();

            if (typeof SoundManager !== 'undefined') {
                SoundManager.playSFX('reward');
            }
        }
    }

    // 아이템 보유 확인
    function hasItem(itemId) {
        return unlockedItems.has(itemId);
    }

    // 보유 아이템 목록
    function getUnlockedItems() {
        return Array.from(unlockedItems).map(id => ({
            id,
            ...ITEMS[id]
        }));
    }

    // 현재 레벨 정보
    function getLevelInfo() {
        return {
            level: currentLevel,
            exp: currentExp,
            expNeeded: EXP_PER_LEVEL,
            maxLevel: CURRENT_SEASON.maxLevel,
            isPremium
        };
    }

    // 모달 열기
    function openModal() {
        const modal = document.getElementById('season-pass-modal');
        if (modal) {
            modal.classList.remove('hidden');
            render();
        }
    }

    // 모달 닫기
    function closeModal() {
        const modal = document.getElementById('season-pass-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    // Public API
    return {
        init,
        addExp,
        claimReward,
        claimAllRewards,
        claimAndUpdate,
        claimAllAndUpdate,
        purchasePremium,
        hasItem,
        getUnlockedItems,
        getLevelInfo,
        getUnclaimedCount,
        getTimeRemaining,
        openModal,
        closeModal,
        render,
        CURRENT_SEASON,
        ITEMS
    };
})();

window.SeasonPass = SeasonPass;
