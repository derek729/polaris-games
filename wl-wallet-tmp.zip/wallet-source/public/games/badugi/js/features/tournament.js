/* ==========================================
   토너먼트 시스템
   ========================================== */

const Tournament = {
  tournaments: [],
  myTournaments: [],
  currentTournament: null,
  selectedCategory: 'all',
  selectedType: 'all',

  // 로컬 모드 더미 데이터
  getLocalTournaments() {
    return [
      {
        id: 'local_1',
        name: '일일 프리롤',
        type: 'SINGLE_ELIMINATION',
        status: 'REGISTRATION',
        entryFee: 0,
        prizePool: 500000,
        minPlayers: 8,
        maxPlayers: 64,
        startingChips: 5000,
        currentPlayers: 42,
        remainingPlayers: 0,
        currentBlinds: { ante: 0, smallBlind: 25, bigBlind: 50 },
        blindLevel: 0,
        registrationEnd: new Date(Date.now() + 3600000),
        scheduledStart: new Date(Date.now() + 3600000),
        isPrivate: false
      },
      {
        id: 'local_2',
        name: 'VIP 바둑이 챔피언십',
        type: 'SINGLE_ELIMINATION',
        status: 'IN_PROGRESS',
        entryFee: 10000,
        prizePool: 2500000,
        minPlayers: 16,
        maxPlayers: 32,
        startingChips: 10000,
        currentPlayers: 32,
        remainingPlayers: 18,
        currentBlinds: { ante: 50, smallBlind: 100, bigBlind: 200 },
        blindLevel: 3,
        registrationEnd: new Date(Date.now() - 3600000),
        scheduledStart: new Date(Date.now() - 3600000),
        isPrivate: true
      },
      {
        id: 'local_3',
        name: '주말 스페셜',
        type: 'DOUBLE_ELIMINATION',
        status: 'REGISTRATION',
        entryFee: 5000,
        prizePool: 1000000,
        minPlayers: 8,
        maxPlayers: 128,
        startingChips: 10000,
        currentPlayers: 56,
        remainingPlayers: 0,
        currentBlinds: { ante: 0, smallBlind: 50, bigBlind: 100 },
        blindLevel: 0,
        registrationEnd: new Date(Date.now() + 7200000),
        scheduledStart: new Date(Date.now() + 7200000),
        isPrivate: false
      }
    ];
  },

  // 토너먼트 목록 로드
  async loadTournaments() {
    if (currentGameMode === 'local') {
      this.tournaments = this.getLocalTournaments();
    } else if (currentGameMode === 'network') {
      if (typeof SocketManager !== 'undefined') {
        SocketManager.getTournaments({ status: this.selectedCategory, type: this.selectedType });
      }
    }
    this.renderTournamentList();
  },

  // 토너먼트 목록 렌더링
  renderTournamentList() {
    const container = Utils.$('#tournaments-container');
    if (!container) return;

    // 필터링
    let filtered = this.tournaments;
    if (this.selectedCategory !== 'all') {
      filtered = filtered.filter(t => t.status === this.selectedCategory);
    }
    if (this.selectedType !== 'all') {
      filtered = filtered.filter(t => t.type === this.selectedType);
    }

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🏆</div>
          <p>토너먼트가 없습니다.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map(tournament => `
      <div class="tournament-card" data-tournament-id="${tournament.id}">
        <div class="tournament-header">
          <div class="tournament-title">
            <span class="tournament-name">${tournament.name}</span>
            ${tournament.isPrivate ? '<span class="badge-private">🔒 비공개</span>' : ''}
          </div>
          <span class="tournament-status ${tournament.status.toLowerCase()}">
            ${this.getStatusText(tournament.status)}
          </span>
        </div>

        <div class="tournament-info">
          <div class="tournament-type">
            <span class="icon">🎯</span>
            ${this.getTypeText(tournament.type)}
          </div>
          <div class="tournament-players">
            <span class="icon">👥</span>
            ${tournament.currentPlayers}/${tournament.maxPlayers}명
          </div>
          <div class="tournament-prize">
            <span class="icon">💰</span>
            ${Utils.formatChips(tournament.prizePool)}
          </div>
          <div class="tournament-entry">
            <span class="icon">🎫</span>
            ${tournament.entryFee === 0 ? '무료' : Utils.formatChips(tournament.entryFee)}
          </div>
        </div>

        <div class="tournament-timer">
          ${this.getTimerHTML(tournament)}
        </div>

        <div class="tournament-actions">
          ${this.getActionButtons(tournament)}
        </div>
      </div>
    `).join('');

    // 이벤트 리스너
    container.querySelectorAll('.tournament-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (!e.target.closest('.tournament-actions')) {
          const tournamentId = card.dataset.tournamentId;
          this.showTournamentDetail(tournamentId);
        }
      });
    });
  },

  // 상태 텍스트
  getStatusText(status) {
    const statusMap = {
      'REGISTRATION': '등록 중',
      'IN_PROGRESS': '진행 중',
      'COMPLETED': '완료',
      'CANCELLED': '취소'
    };
    return statusMap[status] || status;
  },

  // 타입 텍스트
  getTypeText(type) {
    const typeMap = {
      'SINGLE_ELIMINATION': '단일 탈락',
      'DOUBLE_ELIMINATION': '더블 탈락',
      'SWISS': '스위스'
    };
    return typeMap[type] || type;
  },

  // 타이머 HTML
  getTimerHTML(tournament) {
    if (tournament.status === 'REGISTRATION') {
      const timeLeft = tournament.registrationEnd - Date.now();
      if (timeLeft > 0) {
        return `<span class="timer registration">⏰ 등록 마감: ${Utils.formatTime(timeLeft)}</span>`;
      }
    } else if (tournament.status === 'IN_PROGRESS') {
      return `<span class="timer blind">Level ${tournament.blindLevel + 1} (${Utils.formatChips(tournament.currentBlinds.smallBlind)}/${Utils.formatChips(tournament.currentBlinds.bigBlind)})</span>`;
    }
    return '';
  },

  // 액션 버튼
  getActionButtons(tournament) {
    if (tournament.status === 'REGISTRATION') {
      const myTournament = this.myTournaments.find(t => t.id === tournament.id);
      if (myTournament) {
        return `<button class="btn btn-secondary" onclick="Tournament.leaveTournament('${tournament.id}')">참가 취소</button>`;
      }
      return `<button class="btn btn-primary" onclick="Tournament.joinTournament('${tournament.id}')">참가하기</button>`;
    }
    return `<button class="btn btn-secondary" onclick="Tournament.showTournamentDetail('${tournament.id}')">관전하기</button>`;
  },

  // 토너먼트 상세
  async showTournamentDetail(tournamentId) {
    const tournament = this.tournaments.find(t => t.id === tournamentId);
    if (!tournament) return;

    this.currentTournament = tournament;

    const modal = Utils.$('#tournament-detail-modal');
    if (!modal) return;

    modal.classList.remove('hidden');

    // 상세 정보 렌더링
    const container = Utils.$('#tournament-detail-content');
    if (container) {
      container.innerHTML = `
        <div class="tournament-detail-header">
          <h2>${tournament.name}</h2>
          <span class="tournament-status ${tournament.status.toLowerCase()}">
            ${this.getStatusText(tournament.status)}
          </span>
        </div>

        <div class="tournament-detail-grid">
          <div class="detail-section">
            <h3>기본 정보</h3>
            <div class="detail-info">
              <div class="info-row">
                <span class="label">타입</span>
                <span class="value">${this.getTypeText(tournament.type)}</span>
              </div>
              <div class="info-row">
                <span class="label">참가비</span>
                <span class="value">${tournament.entryFee === 0 ? '무료' : Utils.formatChips(tournament.entryFee)}</span>
              </div>
              <div class="info-row">
                <span class="label">시작 칩</span>
                <span class="value">${Utils.formatChips(tournament.startingChips)}</span>
              </div>
              <div class="info-row">
                <span class="label">참가자</span>
                <span class="value">${tournament.currentPlayers}/${tournament.maxPlayers}명</span>
              </div>
              <div class="info-row">
                <span class="label">상금</span>
                <span class="value">${Utils.formatChips(tournament.prizePool)}</span>
              </div>
            </div>
          </div>

          <div class="detail-section">
            <h3>상금 분배</h3>
            <div class="prize-distribution">
              ${this.renderPrizeDistribution(tournament)}
            </div>
          </div>
        </div>

        <div class="detail-section">
          <h3>참가자 순위</h3>
          <div class="participants-list">
            ${this.renderParticipants(tournament)}
          </div>
        </div>

        <div class="tournament-detail-actions">
          ${this.getDetailActionButtons(tournament)}
        </div>
      `;
    }
  },

  // 상금 분배 렌더링
  renderPrizeDistribution(tournament) {
    const distribution = [0.5, 0.3, 0.2];
    const prizes = distribution.map((percent, index) => ({
      rank: index + 1,
      percent: percent * 100,
      prize: Math.floor(tournament.prizePool * percent)
    }));

    return `
      <table class="prize-table">
        <thead>
          <tr>
            <th>순위</th>
            <th>비율</th>
            <th>상금</th>
          </tr>
        </thead>
        <tbody>
          ${prizes.map(p => `
            <tr>
              <td>${p.rank}등</td>
              <td>${p.percent}%</td>
              <td>${Utils.formatChips(p.prize)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  },

  // 참가자 렌더링
  renderParticipants(tournament) {
    if (!tournament.participants || tournament.participants.length === 0) {
      return '<p class="text-muted">참가자 정보가 없습니다.</p>';
    }

    return `
      <table class="participants-table">
        <thead>
          <tr>
            <th>순위</th>
            <th>이름</th>
            <th>칩</th>
            <th>상태</th>
          </tr>
        </thead>
        <tbody>
          ${tournament.participants.slice(0, 20).map(p => `
            <tr>
              <td>${p.eliminatedRank || '-'}</td>
              <td>${p.name}</td>
              <td>${Utils.formatChips(p.chips)}</td>
              <td class="status-${p.status.toLowerCase()}">${p.status}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  },

  // 상세 액션 버튼
  getDetailActionButtons(tournament) {
    if (tournament.status === 'REGISTRATION') {
      return `
        <button class="btn btn-primary" onclick="Tournament.joinTournament('${tournament.id}')">참가하기</button>
        <button class="btn btn-secondary" onclick="UI.closeModal('tournament-detail-modal')">닫기</button>
      `;
    }
    return `
      <button class="btn btn-secondary" onclick="UI.closeModal('tournament-detail-modal')">닫기</button>
    `;
  },

  // 토너먼트 참가
  async joinTournament(tournamentId) {
    const tournament = this.tournaments.find(t => t.id === tournamentId);
    if (!tournament) return;

    // VIP 레벨 체크 (특정 토너먼트)
    if (tournament.entryFee > 0 && State.myChips < tournament.entryFee) {
      UI.showToast('칩이 부족합니다.', 'error');
      return;
    }

    // 비공개 토너먼트 비밀번호
    let password = null;
    if (tournament.isPrivate) {
      password = prompt('비밀번호를 입력하세요:');
      if (!password) return;
    }

    if (currentGameMode === 'network' && typeof SocketManager !== 'undefined') {
      SocketManager.joinTournament(tournamentId, password);
    } else {
      // 로컬 모드
      UI.showToast('토너먼트에 참가했습니다! (로컬 모드)', 'success');
      this.loadMyTournaments();
      this.loadTournaments();
    }
  },

  // 토너먼트 참가 취소
  async leaveTournament(tournamentId) {
    if (!confirm('정말 참가를 취소하시겠습니까?')) return;

    if (currentGameMode === 'network' && typeof SocketManager !== 'undefined') {
      SocketManager.leaveTournament();
    } else {
      UI.showToast('참가가 취소되었습니다.', 'success');
      this.loadMyTournaments();
      this.loadTournaments();
    }
  },

  // 내 토너먼트 목록 로드
  async loadMyTournaments() {
    if (currentGameMode === 'network' && typeof SocketManager !== 'undefined') {
      SocketManager.getMyTournaments();
    }
  },

  // 탈락 모달
  showEliminatedModal(rank, prize) {
    const modal = Utils.$('#tournament-eliminated-modal');
    if (!modal) return;

    Utils.$('#eliminated-rank') && (Utils.$('#eliminated-rank').textContent = `${rank}등`);
    Utils.$('#eliminated-prize') && (Utils.$('#eliminated-prize').textContent = Utils.formatChips(prize));

    modal.classList.remove('hidden');
  },

  // 우승 모달
  showWinnerModal(rank, prize) {
    const modal = Utils.$('#tournament-winner-modal');
    if (!modal) return;

    Utils.$('#winner-rank') && (Utils.$('#winner-rank').textContent = `${rank}등`);
    Utils.$('#winner-prize') && (Utils.$('#winner-prize').textContent = Utils.formatChips(prize));

    modal.classList.remove('hidden');

    // 우승 애니메이션
    if (typeof AnimationManager !== 'undefined') {
      AnimationManager.playVictory();
    }
  },

  // 카테고리 필터
  setCategory(category) {
    this.selectedCategory = category;
    this.renderTournamentList();
  },

  // 타입 필터
  setType(type) {
    this.selectedType = type;
    this.renderTournamentList();
  },

  // 토너먼트 모달 열기
  openTournamentModal() {
    const modal = Utils.$('#tournament-modal');
    if (modal) {
      modal.classList.remove('hidden');
      this.loadTournaments();
    }
  }
};

// 소켓 이벤트 핸들러 (네트워크 모드)
if (typeof SocketManager !== 'undefined') {
  SocketManager.on('tournament_list', (data) => {
    Tournament.tournaments = data.tournaments || [];
    Tournament.renderTournamentList();
  });

  SocketManager.on('tournament_updated', (data) => {
    const { tournament } = data;
    const index = Tournament.tournaments.findIndex(t => t.id === tournament.id);
    if (index !== -1) {
      Tournament.tournaments[index] = tournament;
    }
    Tournament.renderTournamentList();
  });

  SocketManager.on('tournament_joined', (data) => {
    UI.showToast('토너먼트에 참가했습니다!', 'success');
    Tournament.loadMyTournaments();
  });

  SocketManager.on('tournament_left', (data) => {
    UI.showToast('토너먼트 참가가 취소되었습니다.', 'info');
    Tournament.loadMyTournaments();
  });

  SocketManager.on('tournament_started', (data) => {
    UI.showToast('토너먼트가 시작되었습니다!', 'success');
  });

  SocketManager.on('tournament_eliminated', (data) => {
    const { tournamentId, rank, prize } = data;
    Tournament.showEliminatedModal(rank, prize);
  });

  SocketManager.on('tournament_ended', (data) => {
    const { rank, prize } = data;
    Tournament.showWinnerModal(rank, prize);
  });

  SocketManager.on('my_tournaments', (data) => {
    Tournament.myTournaments = data.tournaments || [];
  });

  SocketManager.on('tournament_created', (data) => {
    UI.showToast('토너먼트가 생성되었습니다!', 'success');
    Tournament.loadTournaments();
  });

  SocketManager.on('tournament_cancelled', (data) => {
    UI.showToast('토너먼트가 취소되었습니다.', 'warning');
    Tournament.loadTournaments();
  });
}

// 전역 노출
window.Tournament = Tournament;
