/* =========================================
   핸드 히스토리 시스템
   ========================================= */

const HandHistory = (function() {
  // 핸드 히스토리 데이터
  let handHistory = [];

  // 통계 데이터
  let statistics = {
    totalHands: 0,
    handsWon: 0,
    handsLost: 0,
    showdowns: 0,
    showdownsWon: 0,
    badugisMade: 0,
    threeCardsMade: 0,
    biggestWin: 0,
    biggestLoss: 0,
    totalWinnings: 0,
    averageWin: 0,
    winRate: 0,
    showdownWinRate: 0,
    badugiRate: 0,
    threeCardRate: 0,
    vpip: 0, // Voluntarily Put Money In Pot
    pfr: 0,  // Pre-Flop Raise
    af: 0    // Aggression Factor
  };

  // 데이터 로드
  function loadHistory() {
    const saved = localStorage.getItem('badugi_hand_history');
    if (saved) {
      handHistory = JSON.parse(saved);
    }
    updateStatistics();
  }

  // 데이터 저장
  function saveHistory() {
    // 최대 1000개만 저장
    if (handHistory.length > 1000) {
      handHistory = handHistory.slice(-1000);
    }
    localStorage.setItem('badugi_hand_history', JSON.stringify(handHistory));
  }

  // 핸드 기록
  function recordHand(handData) {
    const record = {
      id: generateId(),
      timestamp: new Date().toISOString(),
      ...handData
    };

    handHistory.push(record);
    saveHistory();
    updateStatistics();
  }

  // ID 생성
  function generateId() {
    return `hand_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // 통계 업데이트
  function updateStatistics() {
    if (handHistory.length === 0) {
      resetStatistics();
      return;
    }

    statistics.totalHands = handHistory.length;
    statistics.handsWon = handHistory.filter(h => h.result === 'win').length;
    statistics.handsLost = handHistory.filter(h => h.result === 'loss').length;
    statistics.showdowns = handHistory.filter(h => h.reachedShowdown).length;
    statistics.showdownsWon = handHistory.filter(h => h.reachedShowdown && h.result === 'win').length;
    statistics.badugisMade = handHistory.filter(h => h.finalHand && h.finalHand.size === 4).length;
    statistics.threeCardsMade = handHistory.filter(h => h.finalHand && h.finalHand.size === 3).length;

    // 최대 승/패
    const wins = handHistory.filter(h => h.result === 'win').map(h => h.winnings || 0);
    const losses = handHistory.filter(h => h.result === 'loss').map(h => h.winnings || 0);
    statistics.biggestWin = wins.length > 0 ? Math.max(...wins) : 0;
    statistics.biggestLoss = losses.length > 0 ? Math.min(...losses) : 0;

    // 총 수익
    statistics.totalWinnings = handHistory.reduce((sum, h) => sum + (h.winnings || 0), 0);

    // 평균 수익
    const winCount = wins.length;
    statistics.averageWin = winCount > 0 ? wins.reduce((sum, w) => sum + w, 0) / winCount : 0;

    // 승률
    statistics.winRate = (statistics.handsWon / statistics.totalHands) * 100;

    // 쇼다운 승률
    statistics.showdownWinRate = statistics.showdowns > 0
      ? (statistics.showdownsWon / statistics.showdowns) * 100
      : 0;

    // 바둑이율
    statistics.badugiRate = (statistics.badugisMade / statistics.totalHands) * 100;

    // 쓰리카드율
    statistics.threeCardRate = (statistics.threeCardsMade / statistics.totalHands) * 100;

    // VPIP (베팅에 참여한 비율)
    const vpipCount = handHistory.filter(h => h.voluntarilyPutMoney).length;
    statistics.vpip = (vpipCount / statistics.totalHands) * 100;

    // PFR (프리롤 레이즈 비율)
    const pfrCount = handHistory.filter(h => h.preFlopRaise).length;
    statistics.pfr = (pfrCount / statistics.totalHands) * 100;

    // AF (어그레션 팩터)
    const aggressiveActions = handHistory.reduce((sum, h) =>
      sum + (h.bets || 0) + (h.raises || 0), 0);
    const passiveActions = handHistory.reduce((sum, h) => sum + (h.calls || 0), 0);
    statistics.af = passiveActions > 0 ? aggressiveActions / passiveActions : aggressiveActions;
  }

  // 통계 리셋
  function resetStatistics() {
    statistics = {
      totalHands: 0,
      handsWon: 0,
      handsLost: 0,
      showdowns: 0,
      showdownsWon: 0,
      badugisMade: 0,
      threeCardsMade: 0,
      biggestWin: 0,
      biggestLoss: 0,
      totalWinnings: 0,
      averageWin: 0,
      winRate: 0,
      showdownWinRate: 0,
      badugiRate: 0,
      threeCardRate: 0,
      vpip: 0,
      pfr: 0,
      af: 0
    };
  }

  // 핸드 상세 정보
  function getHandDetail(handId) {
    return handHistory.find(h => h.id === handId);
  }

  // 날짜 범위로 필터링
  function filterByDateRange(startDate, endDate) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    return handHistory.filter(h => {
      const date = new Date(h.timestamp);
      return date >= start && date <= end;
    });
  }

  // 결과로 필터링
  function filterByResult(result) {
    return handHistory.filter(h => h.result === result);
  }

  // 최근 핸드 가져오기
  function getRecentHands(count = 20) {
    return handHistory.slice(-count).reverse();
  }

  // 히스토리 렌더링
  function renderHistory() {
    const container = document.getElementById('hand-history-list');
    if (!container) return;

    loadHistory();

    if (handHistory.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📊</div>
          <p>아직 플레이한 핸드가 없습니다.</p>
        </div>
      `;
      return;
    }

    const recentHands = getRecentHands(50);
    container.innerHTML = recentHands.map(hand => {
      const date = new Date(hand.timestamp);
      const dateStr = `${date.getMonth() + 1}/${date.getDate()} ${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;
      const resultClass = hand.result === 'win' ? 'win' : hand.result === 'loss' ? 'loss' : 'tie';
      const resultText = hand.result === 'win' ? '승리' : hand.result === 'loss' ? '패배' : '무승부';

      return `
        <div class="hand-item ${resultClass}" data-hand-id="${hand.id}" onclick="HandHistory.showDetail('${hand.id}')">
          <div class="hand-header">
            <div class="hand-date">${dateStr}</div>
            <div class="hand-result result-${resultClass}">${resultText}</div>
          </div>
          <div class="hand-info">
            <div class="hand-cards">${hand.finalHand ? hand.finalHand.name || '-' : '-'}</div>
            <div class="hand-winnings ${hand.winnings >= 0 ? 'positive' : 'negative'}">
              ${hand.winnings >= 0 ? '+' : ''}${Utils.formatChips(hand.winnings || 0)}
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  // 통계 렌더링
  function renderStatistics() {
    const container = document.getElementById('hand-history-stats');
    if (!container) return;

    loadHistory();

    const stats = [
      { label: '총 핸드', value: statistics.totalHands, icon: '🃏' },
      { label: '승률', value: `${statistics.winRate.toFixed(1)}%`, icon: '📈' },
      { label: '쇼다운 승률', value: `${statistics.showdownWinRate.toFixed(1)}%`, icon: '🎯' },
      { label: '바둑이율', value: `${statistics.badugiRate.toFixed(1)}%`, icon: '🎴' },
      { label: '최대 승리', value: Utils.formatChips(statistics.biggestWin), icon: '💰' },
      { label: '최대 패배', value: Utils.formatChips(Math.abs(statistics.biggestLoss)), icon: '💸' },
      { label: '총 수익', value: Utils.formatChips(statistics.totalWinnings), icon: '📊', highlight: true }
    ];

    container.innerHTML = stats.map(stat => `
      <div class="stat-item ${stat.highlight ? 'highlight' : ''}">
        <div class="stat-icon">${stat.icon}</div>
        <div class="stat-info">
          <div class="stat-label">${stat.label}</div>
          <div class="stat-value">${stat.value}</div>
        </div>
      </div>
    `).join('');
  }

  // 상세 정보 표시
  function showDetail(handId) {
    const hand = getHandDetail(handId);
    if (!hand) return;

    const modal = document.getElementById('hand-detail-modal');
    if (!modal) return;

    const date = new Date(hand.timestamp);
    const dateStr = date.toLocaleString('ko-KR');

    // 핸드 상세 정보 렌더링
    const detailContent = modal.querySelector('.hand-detail-content');
    if (detailContent) {
      detailContent.innerHTML = `
        <div class="detail-section">
          <h4>기본 정보</h4>
          <div class="detail-grid">
            <div class="detail-item">
              <span class="detail-label">시간</span>
              <span class="detail-value">${dateStr}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">결과</span>
              <span class="detail-value result-${hand.result}">${hand.result === 'win' ? '승리' : hand.result === 'loss' ? '패배' : '무승부'}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">수익</span>
              <span class="detail-value ${hand.winnings >= 0 ? 'positive' : 'negative'}">${hand.winnings >= 0 ? '+' : ''}${Utils.formatChips(hand.winnings || 0)}</span>
            </div>
            <div class="detail-item">
              <span class="detail-label">쇼다운</span>
              <span class="detail-value">${hand.reachedShowdown ? '도달' : '미도달'}</span>
            </div>
          </div>
        </div>

        <div class="detail-section">
          <h4>핸드 정보</h4>
          <div class="hand-cards-display">
            ${hand.startingHand ? `
              <div class="hand-stage">
                <div class="stage-label">초기 핸드</div>
                <div class="stage-cards">${formatCards(hand.startingHand)}</div>
              </div>
            ` : ''}
            ${hand.finalHand ? `
              <div class="hand-stage">
                <div class="stage-label">최종 핸드</div>
                <div class="stage-cards">${formatCards(hand.finalHand.cards)}</div>
                <div class="stage-name">${hand.finalHand.name}</div>
              </div>
            ` : ''}
          </div>
        </div>

        <div class="detail-section">
          <h4>액션 내역</h4>
          <div class="action-history">
            ${hand.actions ? hand.actions.map(action => `
              <div class="action-item">
                <span class="action-round">${action.round}</span>
                <span class="action-type">${action.type}</span>
                <span class="action-amount">${action.amount ? Utils.formatChips(action.amount) : ''}</span>
              </div>
            `).join('') : '<p>기록된 액션이 없습니다.</p>'}
          </div>
        </div>
      `;
    }

    modal.classList.remove('hidden');
  }

  // 카드 포맷팅
  function formatCards(cards) {
    if (!cards || !Array.isArray(cards)) return '-';
    const suitIcons = { 'hearts': '♥', 'diamonds': '♦', 'clubs': '♣', 'spades': '♠' };
    const valueNames = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    return cards.map(card => {
      const icon = suitIcons[card.suit] || '?';
      const name = valueNames[card.value] || '?';
      return `<span class="card-badge ${card.suit}">${icon}${name}</span>`;
    }).join('');
  }

  // 모달 열기
  function openModal() {
    const modal = document.getElementById('hand-history-modal');
    if (modal) {
      modal.classList.remove('hidden');
      renderHistory();
      renderStatistics();
    }
  }

  // 모달 닫기
  function closeModal() {
    const modal = document.getElementById('hand-history-modal');
    if (modal) {
      modal.classList.add('hidden');
    }
  }

  // 상세 모달 닫기
  function closeDetailModal() {
    const modal = document.getElementById('hand-detail-modal');
    if (modal) {
      modal.classList.add('hidden');
    }
  }

  // 데이터 내보내기
  function exportData() {
    loadHistory();

    if (handHistory.length === 0) {
      if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
        UI.showToast('내보낼 데이터가 없습니다.', 'info');
      }
      return;
    }

    const dataStr = JSON.stringify(handHistory, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `badugi_hand_history_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);

    if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
      UI.showToast('success', '데이터 내보내기 완료!');
    }
  }

  // 데이터 삭제
  function clearHistory() {
    if (!confirm('정말로 모든 핸드 히스토리를 삭제하시겠습니까?')) {
      return;
    }

    handHistory = [];
    saveHistory();
    updateStatistics();

    if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
      UI.showToast('success', '히스토리가 삭제되었습니다.');
    }

    renderHistory();
    renderStatistics();
  }

  // 초기화
  function init() {
    loadHistory();
  }

  // 공개 API
  return {
    init,
    recordHand,
    getHandDetail,
    getRecentHands,
    filterByDateRange,
    filterByResult,
    openModal,
    closeModal,
    showDetail,
    closeDetailModal,
    exportData,
    clearHistory,
    renderHistory,
    renderStatistics,
    get statistics() { return statistics; }
  };
})();

// 전역 노출
window.HandHistory = HandHistory;
