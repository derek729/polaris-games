/* ==========================================
   업적 시스템 (확장版)
   ========================================== */

const Achievements = {
  // 업적 카테고리
  categories: {
    BEGINNER: { id: 'beginner', name: '초보자', icon: '🌱', color: '#4CAF50' },
    GAMES: { id: 'games', name: '게임 플레이', icon: '🎮', color: '#2196F3' },
    WINS: { id: 'wins', name: '승리', icon: '🏆', color: '#FFD700' },
    HANDS: { id: 'hands', name: '핸드', icon: '🃏', color: '#9C27B0' },
    CHIPS: { id: 'chips', name: '칩 획득', icon: '💰', color: '#FF9800' },
    SOCIAL: { id: 'social', name: '소셜', icon: '👥', color: '#E91E63' },
    SPECIAL: { id: 'special', name: '스페셜', icon: '⭐', color: '#FF5722' },
    TOURNAMENT: { id: 'tournament', name: '토너먼트', icon: '👑', color: '#795548' }
  },

  // 업적 정의
  achievements: [
    // BEGINNER - 초보자 (10개)
    {
      id: 'first_game',
      category: 'BEGINNER',
      name: '첫 게임',
      description: '첫 번째 게임 플레이',
      requirement: 1,
      reward: { chips: 1000, exp: 100 },
      rarity: 'common',
      icon: '🎯'
    },
    {
      id: 'first_win',
      category: 'BEGINNER',
      name: '첫 승리',
      description: '첫 번째 승리',
      requirement: 1,
      reward: { chips: 2000, exp: 200 },
      rarity: 'common',
      icon: '🎉'
    },
    {
      id: 'first_badugi',
      category: 'BEGINNER',
      name: '첫 바둑이',
      description: '바둑이 핸드 완성',
      requirement: 1,
      reward: { chips: 3000, exp: 300 },
      rarity: 'common',
      icon: '🃏'
    },
    {
      id: 'first_royal',
      category: 'BEGINNER',
      name: '첫 로열 바둑이',
      description: 'A-2-3-4 바둑이 완성',
      requirement: 1,
      reward: { chips: 10000, exp: 1000 },
      rarity: 'rare',
      icon: '👑'
    },
    {
      id: 'play_10_games',
      category: 'BEGINNER',
      name: '열 번째 게임',
      description: '10게임 플레이',
      requirement: 10,
      reward: { chips: 5000, exp: 500 },
      rarity: 'common',
      icon: '🔢'
    },
    {
      id: 'play_100_games',
      category: 'BEGINNER',
      name: '백 게임',
      description: '100게임 플레이',
      requirement: 100,
      reward: { chips: 50000, exp: 5000 },
      rarity: 'epic',
      icon: '💯'
    },
    {
      id: 'win_5_games',
      category: 'BEGINNER',
      name: '다섯 승리',
      description: '5게임 승리',
      requirement: 5,
      reward: { chips: 10000, exp: 1000 },
      rarity: 'uncommon',
      icon: '⭐'
    },
    {
      id: 'earn_100k',
      category: 'BEGINNER',
      name: '10만 칩',
      description: '총 100,000칩 획득',
      requirement: 100000,
      reward: { chips: 20000, exp: 2000 },
      rarity: 'uncommon',
      icon: '💰'
    },
    {
      id: 'vip_1',
      category: 'BEGINNER',
      name: 'VIP 레벨 1',
      description: 'VIP 레벨 1 달성',
      requirement: 1,
      reward: { chips: 5000, exp: 500 },
      rarity: 'common',
      icon: '🥉'
    },
    {
      id: 'friend_1',
      category: 'BEGINNER',
      name: '첫 친구',
      description: '첫 친구 추가',
      requirement: 1,
      reward: { chips: 3000, exp: 300 },
      rarity: 'common',
      icon: '🤝'
    },

    // GAMES - 게임 플레이 (8개)
    {
      id: 'games_50',
      category: 'GAMES',
      name: '반 세션',
      description: '50게임 플레이',
      requirement: 50,
      reward: { chips: 20000, exp: 2000 },
      rarity: 'uncommon',
      icon: '🎮'
    },
    {
      id: 'games_500',
      category: 'GAMES',
      name: '하드코어',
      description: '500게임 플레이',
      requirement: 500,
      reward: { chips: 200000, exp: 20000 },
      rarity: 'legendary',
      icon: '🔥'
    },
    {
      id: 'games_1000',
      category: 'GAMES',
      name: '전설의 플레이어',
      description: '1000게임 플레이',
      requirement: 1000,
      reward: { chips: 500000, exp: 50000, item: 'title_master' },
      rarity: 'mythic',
      icon: '👑'
    },
    {
      id: 'games_daily_7',
      category: 'GAMES',
      name: '주 7일',
      description: '7일 연속 게임 플레이',
      requirement: 7,
      reward: { chips: 30000, exp: 3000 },
      rarity: 'rare',
      icon: '📅'
    },
    {
      id: 'games_daily_30',
      category: 'GAMES',
      name: '한 달 스테이크',
      description: '30일 연속 게임 플레이',
      requirement: 30,
      reward: { chips: 100000, exp: 10000 },
      rarity: 'epic',
      icon: '📆'
    },
    {
      id: 'sitngo_10',
      category: 'GAMES',
      name: '앉고바닥',
      description: 'Sit & Go 10회 완주',
      requirement: 10,
      reward: { chips: 15000, exp: 1500 },
      rarity: 'uncommon',
      icon: '🪑'
    },
    {
      id: 'tournament_5',
      category: 'GAMES',
      name: '토너먼트 참가',
      description: '토너먼트 5회 참가',
      requirement: 5,
      reward: { chips: 25000, exp: 2500 },
      rarity: 'rare',
      icon: '🏆'
    },
    {
      id: 'all_tables',
      category: 'GAMES',
      name: '모든 테이블',
      description: '모든 레벨 테이블 플레이',
      requirement: 5,
      reward: { chips: 10000, exp: 1000 },
      rarity: 'uncommon',
      icon: '🎰'
    },

    // WINS - 승리 (8개)
    {
      id: 'wins_10',
      category: 'WINS',
      name: '첫 승리 열',
      description: '10게임 승리',
      requirement: 10,
      reward: { chips: 20000, exp: 2000 },
      rarity: 'uncommon',
      icon: '🎖️'
    },
    {
      id: 'wins_100',
      category: 'WINS',
      name: '승리의 왕',
      description: '100게임 승리',
      requirement: 100,
      reward: { chips: 200000, exp: 20000 },
      rarity: 'legendary',
      icon: '👑'
    },
    {
      id: 'wins_streak_5',
      category: 'WINS',
      name: '연승 5',
      description: '5연승 달성',
      requirement: 5,
      reward: { chips: 15000, exp: 1500 },
      rarity: 'rare',
      icon: '🔥'
    },
    {
      id: 'wins_streak_10',
      category: 'WINS',
      name: '무적의 10연승',
      description: '10연승 달성',
      requirement: 10,
      reward: { chips: 50000, exp: 5000 },
      rarity: 'epic',
      icon: '⚡'
    },
    {
      id: 'winrate_50',
      category: 'WINS',
      name: '반반 승률',
      description: '승률 50% 달성',
      requirement: 50,
      reward: { chips: 30000, exp: 3000 },
      rarity: 'rare',
      icon: '📊'
    },
    {
      id: 'winrate_60',
      category: 'WINS',
      name: '고수의 승률',
      description: '승률 60% 달성',
      requirement: 60,
      reward: { chips: 50000, exp: 5000 },
      rarity: 'epic',
      icon: '📈'
    },
    {
      id: 'wins_showdown',
      category: 'WINS',
      name: '쇼다운 마스터',
      description: '쇼다운 50회 승리',
      requirement: 50,
      reward: { chips: 25000, exp: 2500 },
      rarity: 'rare',
      icon: '🎯'
    },
    {
      id: 'wins_bluff',
      category: 'WINS',
      name: '블러프 왕',
      description: '블러프로 20회 승리',
      requirement: 20,
      reward: { chips: 20000, exp: 2000 },
      rarity: 'uncommon',
      icon: '🎭'
    },

    // HANDS - 핸드 (8개)
    {
      id: 'badugi_10',
      category: 'HANDS',
      name: '바둑이 헌터',
      description: '바둑이 10회 완성',
      requirement: 10,
      reward: { chips: 15000, exp: 1500 },
      rarity: 'uncommon',
      icon: '🃏'
    },
    {
      id: 'badugi_100',
      category: 'HANDS',
      name: '바둑이 마스터',
      description: '바둑이 100회 완성',
      requirement: 100,
      reward: { chips: 150000, exp: 15000 },
      rarity: 'legendary',
      icon: '👑'
    },
    {
      id: 'three_card_50',
      category: 'HANDS',
      name: '쓰리카드 전문가',
      description: '쓰리카드 50회 완성',
      requirement: 50,
      reward: { chips: 20000, exp: 2000 },
      rarity: 'rare',
      icon: '3️⃣'
    },
    {
      id: 'royal_5',
      category: 'HANDS',
      name: '로열 컬렉터',
      description: '로열 바둑이 5회 완성',
      requirement: 5,
      reward: { chips: 50000, exp: 5000 },
      rarity: 'epic',
      icon: '🌟'
    },
    {
      id: 'hands_folded',
      category: 'HANDS',
      name: '접는 것도 기술',
      description: '좋은 핸드로 폴드 50회',
      requirement: 50,
      reward: { chips: 10000, exp: 1000 },
      rarity: 'uncommon',
      icon: '🛡️'
    },
    {
      id: 'perfect_badugi',
      category: 'HANDS',
      name: '완벽한 바둑이',
      description: 'A-2-3-4 바둑이로 승리',
      requirement: 1,
      reward: { chips: 30000, exp: 3000 },
      rarity: 'rare',
      icon: '💎'
    },
    {
      id: 'draw_0',
      category: 'HANDS',
      name: '스탠드 패트',
      description: '교환 없이 승리 10회',
      requirement: 10,
      reward: { chips: 20000, exp: 2000 },
      rarity: 'rare',
      icon: '✋'
    },
    {
      id: 'draw_3',
      category: 'HANDS',
      name: '대각선의 기적',
      description: '3장 교환 후 바둑이 완성',
      requirement: 1,
      reward: { chips: 25000, exp: 2500 },
      rarity: 'rare',
      icon: '🎲'
    },

    // CHIPS - 칩 획득 (6개)
    {
      id: 'chips_1m',
      category: 'CHIPS',
      name: '백만장자',
      description: '총 1,000,000칩 획득',
      requirement: 1000000,
      reward: { chips: 100000, exp: 10000 },
      rarity: 'legendary',
      icon: '💰'
    },
    {
      id: 'chips_10m',
      category: 'CHIPS',
      name: '천만장자',
      description: '총 10,000,000칩 획득',
      requirement: 10000000,
      reward: { chips: 1000000, exp: 100000, item: 'title_millionaire' },
      rarity: 'mythic',
      icon: '👑'
    },
    {
      id: 'chips_single_100k',
      category: 'CHIPS',
      name: '빅 스페이크',
      description: '한 게임에서 100,000칩 획득',
      requirement: 100000,
      reward: { chips: 50000, exp: 5000 },
      rarity: 'epic',
      icon: '🎰'
    },
    {
      id: 'chips_balance_500k',
      category: 'CHIPS',
      name: '잔고의 왕',
      description: '잔고 500,000칩 달성',
      requirement: 500000,
      reward: { chips: 75000, exp: 7500 },
      rarity: 'epic',
      icon: '🏦'
    },
    {
      id: 'all_in_10',
      category: 'CHIPS',
      name: '올인의 영웅',
      description: '올인으로 10회 승리',
      requirement: 10,
      reward: { chips: 30000, exp: 3000 },
      rarity: 'rare',
      icon: '🎲'
    },
    {
      id: 'comeback',
      category: 'CHIPS',
      name: '컴백 킹',
      description: '1000칩 이하에서 50000칩 이상 회복',
      requirement: 1,
      reward: { chips: 40000, exp: 4000 },
      rarity: 'epic',
      icon: '🔥'
    },

    // SOCIAL - 소셜 (6개)
    {
      id: 'friends_10',
      category: 'SOCIAL',
      name: '인기인',
      description: '친구 10명 추가',
      requirement: 10,
      reward: { chips: 10000, exp: 1000 },
      rarity: 'uncommon',
      icon: '👥'
    },
    {
      id: 'friends_50',
      category: 'SOCIAL',
      name: '소셜 스타',
      description: '친구 50명 추가',
      requirement: 50,
      reward: { chips: 50000, exp: 5000 },
      rarity: 'legendary',
      icon: '⭐'
    },
    {
      id: 'invite_5',
      category: 'SOCIAL',
      name: '초대의 달인',
      description: '친구 초대 5회 승인',
      requirement: 5,
      reward: { chips: 15000, exp: 1500 },
      rarity: 'uncommon',
      icon: '✉️'
    },
    {
      id: 'gift_10',
      category: 'SOCIAL',
      name: '선물의 천사',
      description: '칩 선물 10회',
      requirement: 10,
      reward: { chips: 10000, exp: 1000 },
      rarity: 'uncommon',
      icon: '🎁'
    },
    {
      id: 'chat_100',
      category: 'SOCIAL',
      name: '수다쟁이',
      description: '채팅 100회',
      requirement: 100,
      reward: { chips: 5000, exp: 500 },
      rarity: 'common',
      icon: '💬'
    },
    {
      id: 'emoji_50',
      category: 'SOCIAL',
      name: '이모티콘러버',
      description: '이모티콘 50회 사용',
      requirement: 50,
      reward: { chips: 3000, exp: 300 },
      rarity: 'common',
      icon: '😀'
    },

    // SPECIAL - 스페셜 (6개)
    {
      id: 'lucky_wheel_100',
      category: 'SPECIAL',
      name: '행운의 100스핀',
      description: '럭키 휠 100회 스핀',
      requirement: 100,
      reward: { chips: 30000, exp: 3000 },
      rarity: 'rare',
      icon: '🎡'
    },
    {
      id: 'jackpot',
      category: 'SPECIAL',
      name: '잭팟의 주인공',
      description: '럭키 휠 잭팟 당첨',
      requirement: 1,
      reward: { chips: 100000, exp: 10000 },
      rarity: 'legendary',
      icon: '🎰'
    },
    {
      id: 'daily_reward_30',
      category: 'SPECIAL',
      name: '충성스러운 플레이어',
      description: '일일 보상 30일 연속 수령',
      requirement: 30,
      reward: { chips: 50000, exp: 5000 },
      rarity: 'epic',
      icon: '📅'
    },
    {
      id: 'vip_10',
      category: 'SPECIAL',
      name: 'VIP 10 달성',
      requirement: 10,
      reward: { chips: 100000, exp: 10000, item: 'cardback_vip' },
      rarity: 'legendary',
      icon: '👑'
    },
    {
      id: 'missions_50',
      category: 'SPECIAL',
      name: '미션 완료자',
      description: '일일 미션 50회 완료',
      requirement: 50,
      reward: { chips: 40000, exp: 4000 },
      rarity: 'epic',
      icon: '✅'
    },
    {
      id: 'season_pass_complete',
      category: 'SPECIAL',
      name: '시즌 패스 완료',
      description: '시즌 패스 레벨 50 달성',
      requirement: 50,
      reward: { chips: 200000, exp: 20000, item: 'title_season_champion' },
      rarity: 'mythic',
      icon: '🏆'
    },

    // TOURNAMENT - 토너먼트 (8개)
    {
      id: 'tournament_win',
      category: 'TOURNAMENT',
      name: '토너먼트 우승',
      description: '토너먼트 1위 달성',
      requirement: 1,
      reward: { chips: 100000, exp: 10000 },
      rarity: 'legendary',
      icon: '🥇'
    },
    {
      id: 'tournament_top3',
      category: 'TOURNAMENT',
      name: '시상식 단상',
      description: '토너먼트 3위 이내 5회',
      requirement: 5,
      reward: { chips: 75000, exp: 7500 },
      rarity: 'epic',
      icon: '🏅'
    },
    {
      id: 'tournament_10',
      category: 'TOURNAMENT',
      name: '토너먼트 헌터',
      description: '토너먼트 10회 참가',
      requirement: 10,
      reward: { chips: 30000, exp: 3000 },
      rarity: 'rare',
      icon: '🎯'
    },
    {
      id: 'tournament_survivor',
      category: 'TOURNAMENT',
      name: '서바이벌 킹',
      description: '100명 이상 토너먼트에서 TOP 10',
      requirement: 1,
      reward: { chips: 80000, exp: 8000 },
      rarity: 'epic',
      icon: '🛡️'
    },
    {
      id: 'freeroll_win',
      category: 'TOURNAMENT',
      name: '프리롤 스타',
      description: '프리롤 토너먼트 우승',
      requirement: 1,
      reward: { chips: 50000, exp: 5000 },
      rarity: 'rare',
      icon: '⭐'
    },
    {
      id: 'vip_tournament_win',
      category: 'TOURNAMENT',
      name: 'VIP 챔피언',
      description: 'VIP 토너먼트 우승',
      requirement: 1,
      reward: { chips: 200000, exp: 20000, item: 'title_vip_champion' },
      rarity: 'mythic',
      icon: '👑'
    },
    {
      id: 'tournament_streak',
      category: 'TOURNAMENT',
      name: '연속 우승',
      description: '토너먼트 3회 연속 우승',
      requirement: 3,
      reward: { chips: 300000, exp: 30000 },
      rarity: 'mythic',
      icon: '🔥'
    },
    {
      id: 'tournament_earn_1m',
      category: 'TOURNAMENT',
      name: '토너먼트 백만장자',
      description: '토너먼트 상금 총 100만칩',
      requirement: 1000000,
      reward: { chips: 150000, exp: 15000 },
      rarity: 'legendary',
      icon: '💰'
    }
  ],

  // 레어도 색상
  rarityColors: {
    common: '#9E9E9E',
    uncommon: '#4CAF50',
    rare: '#2196F3',
    epic: '#9C27B0',
    legendary: '#FF9800',
    mythic: '#F44336'
  },

  // 플레이어 업적 데이터
  playerAchievements: {},

  // 초기화
  init() {
    this.loadData();
    this.setupAutoSave();
  },

  // 데이터 로드
  loadData() {
    const saved = Storage.get('badugi_achievements_v2', {});
    this.playerAchievements = saved;
  },

  // 데이터 저장
  saveData() {
    Storage.set('badugi_achievements_v2', this.playerAchievements);
  },

  // 자동 저장
  setupAutoSave() {
    setInterval(() => {
      this.saveData();
    }, 30000);
  },

  // 업적 진행 업데이트
  updateProgress(achievementId, progress) {
    const achievement = this.achievements.find(a => a.id === achievementId);
    if (!achievement) return;

    if (!this.playerAchievements[achievementId]) {
      this.playerAchievements[achievementId] = {
        id: achievementId,
        progress: 0,
        completed: false,
        completedAt: null
      };
    }

    const playerAchievement = this.playerAchievements[achievementId];

    if (playerAchievement.completed) return;

    const oldProgress = playerAchievement.progress;
    playerAchievement.progress = Math.min(progress, achievement.requirement);

    // 완료 체크
    if (playerAchievement.progress >= achievement.requirement && !playerAchievement.completed) {
      this.completeAchievement(achievementId);
    }
    // 진행 알림
    else if (playerAchievement.progress > oldProgress) {
      this.showProgressNotification(achievement, playerAchievement.progress);
    }

    this.saveData();
  },

  // 업적 완료
  completeAchievement(achievementId) {
    const achievement = this.achievements.find(a => a.id === achievementId);
    if (!achievement) return;

    const playerAchievement = this.playerAchievements[achievementId];
    if (playerAchievement.completed) return;

    playerAchievement.completed = true;
    playerAchievement.completedAt = Date.now();

    // 보상 지급
    if (achievement.reward.chips) {
      State.addChips(achievement.reward.chips);
    }
    if (achievement.reward.exp && typeof VIPSystem !== 'undefined') {
      VIPSystem.addExp(achievement.reward.exp);
    }

    // 알림
    this.showCompletionNotification(achievement);

    // 이벤트
    this.triggerEvent('achievement_completed', { achievementId, achievement });

    this.saveData();
  },

  // 완료 알림
  showCompletionNotification(achievement) {
    const rarity = achievement.rarity;
    const color = this.rarityColors[rarity];

    UI.showToast(
      'success',
      '🏆 업적 달성!',
      `${achievement.icon} ${achievement.name}`,
      `${achievement.description}\n+${Utils.formatChips(achievement.reward.chips || 0)}칩`,
      5000
    );

    // 레어/에픽/전설/신화는 특별 효과
    if (['rare', 'epic', 'legendary', 'mythic'].includes(rarity)) {
      if (typeof AnimationManager !== 'undefined') {
        AnimationManager.playAchievementUnlock(rarity);
      }
    }
  },

  // 진행 알림
  showProgressNotification(achievement, progress) {
    // 25%, 50%, 75%에서 알림
    const percent = Math.floor((progress / achievement.requirement) * 100);
    if ([25, 50, 75].includes(percent)) {
      UI.showToast(
        'info',
        `${achievement.icon} ${achievement.name}`,
        `진행: ${progress}/${achievement.requirement} (${percent}%)`
      );
    }
  },

  // 업적 이벤트 트리거
  triggerEvent(event, data) {
    // 다른 시스템과 연동
  },

  // 완료된 업적 수
  getCompletedCount() {
    return Object.values(this.playerAchievements).filter(a => a.completed).length;
  },

  // 특정 카테고리 업적 필터링
  getByCategory(category) {
    return this.achievements.filter(a => a.category === category);
  },

  // 완료되지 않은 업적
  getIncomplete() {
    return this.achievements.filter(a => !this.playerAchievements[a.id]?.completed);
  },

  // 완료된 업적
  getCompleted() {
    return this.achievements.filter(a => this.playerAchievements[a.id]?.completed);
  },

  // 진행 중인 업적
  getInProgress() {
    return this.achievements.filter(a =>
      this.playerAchievements[a.id]?.progress > 0 &&
      !this.playerAchievements[a.id]?.completed
    );
  },

  // 카테고리별 완료 수
  getStatsByCategory() {
    const stats = {};

    Object.keys(this.categories).forEach(cat => {
      const achievements = this.getByCategory(cat);
      const completed = achievements.filter(a => this.playerAchievements[a.id]?.completed).length;

      stats[cat] = {
        total: achievements.length,
        completed,
        percent: Math.round((completed / achievements.length) * 100)
      };
    });

    return stats;
  }
};

// 전역 노출
window.Achievements = Achievements;
