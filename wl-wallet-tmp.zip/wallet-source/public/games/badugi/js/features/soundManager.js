// client/js/soundManager.js - 완전히 새로 작성

const SoundManager = (function() {
    'use strict';

    let bgmVolume = 0.5;
    let sfxVolume = 0.7;
    let isMuted = false;
    let currentBGM = null;
    let isInitialized = false;

    function init() {
        if (isInitialized) return;

        try {
            const saved = localStorage.getItem('badugi_sound_settings');
            if (saved) {
                const settings = JSON.parse(saved);
                bgmVolume = settings.bgmVolume ?? 0.5;
                sfxVolume = settings.sfxVolume ?? 0.7;
                isMuted = settings.isMuted ?? false;
            }
        } catch (e) {
            console.warn('사운드 설정 로드 실패:', e);
        }

        isInitialized = true;
        console.log('🔊 사운드 매니저 초기화 완료');
    }

    function saveSettings() {
        try {
            localStorage.setItem('badugi_sound_settings', JSON.stringify({
                bgmVolume,
                sfxVolume,
                isMuted
            }));
        } catch (e) {}
    }

    // BGM 관련
    function playGameBGM() {
        console.log('[Sound] 게임 BGM 재생');
    }

    function playLobbyBGM() {
        console.log('[Sound] 로비 BGM 재생');
    }

    function stopBGM() {
        if (currentBGM) {
            currentBGM.pause();
            currentBGM = null;
        }
    }

    // SFX 관련
    function playCardDeal() {
        console.log('[Sound] 카드 딜');
    }

    function playCardFlip() {
        console.log('[Sound] 카드 플립');
    }

    function playChip() {
        console.log('[Sound] 칩');
    }

    function playWin() {
        console.log('[Sound] 승리');
    }

    function playLose() {
        console.log('[Sound] 패배');
    }

    function playTurn() {
        console.log('[Sound] 턴');
    }

    function playClick() {
        console.log('[Sound] 클릭');
    }

    function playFold() {
        console.log('[Sound] 폴드');
    }

    function playCheck() {
        console.log('[Sound] 체크');
    }

    function playCall() {
        console.log('[Sound] 콜');
    }

    function playRaise() {
        console.log('[Sound] 레이즈');
    }

    function playAllIn() {
        console.log('[Sound] 올인');
    }

    function setBGMVolume(volume) {
        bgmVolume = Math.max(0, Math.min(1, volume));
        saveSettings();
    }

    function setSFXVolume(volume) {
        sfxVolume = Math.max(0, Math.min(1, volume));
        saveSettings();
    }

    function setMuted(muted) {
        isMuted = muted;
        saveSettings();
    }

    function toggleMute() {
        setMuted(!isMuted);
        return isMuted;
    }

    // Public API
    return {
        init: init,
        playGameBGM: playGameBGM,
        playLobbyBGM: playLobbyBGM,
        stopBGM: stopBGM,
        playCardDeal: playCardDeal,
        playCardFlip: playCardFlip,
        playChip: playChip,
        playWin: playWin,
        playLose: playLose,
        playTurn: playTurn,
        playClick: playClick,
        playFold: playFold,
        playCheck: playCheck,
        playCall: playCall,
        playRaise: playRaise,
        playAllIn: playAllIn,
        setBGMVolume: setBGMVolume,
        setSFXVolume: setSFXVolume,
        setMuted: setMuted,
        toggleMute: toggleMute,
        getBGMVolume: function() { return bgmVolume; },
        getSFXVolume: function() { return sfxVolume; },
        getIsMuted: function() { return isMuted; }
    };
})();

// 전역 등록
window.SoundManager = SoundManager;
