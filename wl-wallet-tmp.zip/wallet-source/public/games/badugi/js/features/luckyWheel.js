/* ==========================================
   럭키 휠 (고급 스핀)
   ========================================== */

const LuckyWheel = {

  // 휠 슬롯 설정
  SLOTS: [
    { id: 1, prize: 1000, label: '₩1,000', color: '#ef4444', probability: 25 },
    { id: 2, prize: 2000, label: '₩2,000', color: '#f97316', probability: 20 },
    { id: 3, prize: 3000, label: '₩3,000', color: '#eab308', probability: 18 },
    { id: 4, prize: 5000, label: '₩5,000', color: '#22c55e', probability: 15 },
    { id: 5, prize: 10000, label: '₩1만', color: '#3b82f6', probability: 10 },
    { id: 6, prize: 20000, label: '₩2만', color: '#8b5cf6', probability: 7 },
    { id: 7, prize: 50000, label: '₩5만', color: '#ec4899', probability: 4 },
    { id: 8, prize: 100000, label: '잭팟!', color: '#fbbf24', probability: 1 }
  ],

  STORAGE_KEY: 'badugi_wheel',
  FREE_SPINS_PER_DAY: 1,

  // 데이터 로드
  loadData() {
    return Storage.get(this.STORAGE_KEY, {
      lastFreeSpin: null,
      freeSpinsUsed: 0,
      totalSpins: 0,
      totalWon: 0,
      jackpotWins: 0
    });
  },

  // 데이터 저장
  saveData(data) {
    Storage.set(this.STORAGE_KEY, data);
  },

  // 오늘 날짜
  getTodayString() {
    return new Date().toISOString().split('T')[0];
  },

  // 무료 스핀 가능 여부
  canFreeSpin() {
    const data = this.loadData();
    const today = this.getTodayString();

    if (data.lastFreeSpin !== today) {
      return true;
    }

    return data.freeSpinsUsed < this.FREE_SPINS_PER_DAY;
  },

  // 스핀 결과 계산
  calculateResult() {
    const totalProbability = this.SLOTS.reduce((sum, slot) => sum + slot.probability, 0);
    let random = Math.random() * totalProbability;

    for (const slot of this.SLOTS) {
      random -= slot.probability;
      if (random <= 0) {
        return slot;
      }
    }

    return this.SLOTS[0];
  },

  // 스핀 실행
  spin(isFree = false) {
    const data = this.loadData();
    const today = this.getTodayString();

    // 무료 스핀 확인
    if (isFree) {
      if (data.lastFreeSpin !== today) {
        data.lastFreeSpin = today;
        data.freeSpinsUsed = 1;
      } else if (data.freeSpinsUsed >= this.FREE_SPINS_PER_DAY) {
        return { success: false, message: '오늘의 무료 스핀을 모두 사용했습니다.' };
      } else {
        data.freeSpinsUsed++;
      }
    }

    // 결과 계산
    const result = this.calculateResult();

    // VIP 보너스 적용
    const vipBonus = VIPSystem.getSpinBonus();
    const finalPrize = Math.floor(result.prize * (1 + vipBonus / 100));

    // 칩 지급
    Storage.addChips(finalPrize);

    // 통계 업데이트
    data.totalSpins++;
    data.totalWon += finalPrize;
    if (result.id === 8) data.jackpotWins++;

    this.saveData(data);

    // VIP 경험치
    VIPSystem.addExp('game_play');

    return {
      success: true,
      slot: result,
      prize: finalPrize,
      vipBonus: vipBonus > 0 ? `+${vipBonus}%` : null,
      isJackpot: result.id === 8
    };
  },

  // 상태 조회
  getStatus() {
    const data = this.loadData();
    const canFree = this.canFreeSpin();

    return {
      canFreeSpin: canFree,
      freeSpinsRemaining: canFree ? this.FREE_SPINS_PER_DAY - (data.lastFreeSpin === this.getTodayString() ? data.freeSpinsUsed : 0) : 0,
      totalSpins: data.totalSpins,
      totalWon: data.totalWon,
      jackpotWins: data.jackpotWins,
      slots: this.SLOTS
    };
  }
};
