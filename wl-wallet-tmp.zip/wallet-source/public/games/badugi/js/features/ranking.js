// client/js/features/ranking.js
// 랭킹 시스템 클라이언트

const Ranking = (function() {
    // 랭킹 타입
    const RANKING_TYPES = {
        CHIPS: { id: 'chips', name: '보유 칩', icon: '💰', format: 'chips' },
        WIN_RATE: { id: 'winRate', name: '승률', icon: '🏆', format: 'percent' },
        GAMES_PLAYED: { id: 'gamesPlayed', name: '게임 수', icon: '🎮', format: 'number' },
        BIGGEST_WIN: { id: 'biggestWin', name: '최대 승리', icon: '💎', format: 'chips' },
        LEVEL: { id: 'level', name: '레벨', icon: '⭐', format: 'level' }
    };

    let currentType = 'chips';
    let rankingData = [];
    let myRank = null;
    let seasonInfo = null;

    // 초기화
    function init() {
        setupEventListeners();
        console.log('[Ranking] 초기화 완료');
    }

    // 이벤트 리스너 설정
    function setupEventListeners() {
        // 소켓 이벤트
        if (typeof SocketManager !== 'undefined') {
            SocketManager.on && SocketManager.on('ranking_data', handleRankingData);
            SocketManager.on && SocketManager.on('nearby_ranks', handleNearbyRanks);
        }
    }

    // 랭킹 데이터 수신 처리
    function handleRankingData(data) {
        currentType = data.type;
        rankingData = data.ranking || [];
        myRank = data.myRank;
        seasonInfo = data.seasonInfo;

        renderRanking();
    }

    // 주변 순위 수신 처리
    function handleNearbyRanks(data) {
        renderNearbyRanks(data);
    }

    // 랭킹 요청
    function requestRanking(type = 'chips') {
        currentType = type;

        if (typeof SocketManager !== 'undefined' && SocketManager.checkConnection && SocketManager.checkConnection()) {
            SocketManager.emit('get_ranking', { type });
        } else {
            // 로컬 모드: 더미 데이터
            generateLocalRanking(type);
        }
    }

    // 로컬 랭킹 생성 (AI 포함)
    function generateLocalRanking(type) {
        const localData = [
            { rank: 1, id: 'bot1', name: '포커마스터', value: 5000000, level: 45, isOnline: true },
            { rank: 2, id: 'bot2', name: '바둑이킹', value: 3500000, level: 38, isOnline: true },
            { rank: 3, id: 'bot3', name: '칩부자', value: 2800000, level: 32, isOnline: false },
            { rank: 4, id: 'player', name: State.playerName || '플레이어', value: State.myChips, level: State.vipLevel || 1, isOnline: true, isMe: true },
            { rank: 5, id: 'bot4', name: '럭키가이', value: 1500000, level: 25, isOnline: true },
            { rank: 6, id: 'bot5', name: '초보자123', value: 800000, level: 15, isOnline: false },
            { rank: 7, id: 'bot6', name: '게임러버', value: 500000, level: 12, isOnline: true },
            { rank: 8, id: 'bot7', name: '카드의신', value: 350000, level: 10, isOnline: false },
            { rank: 9, id: 'bot8', name: '행운의손', value: 200000, level: 8, isOnline: true },
            { rank: 10, id: 'bot9', name: '뉴비플레이어', value: 100000, level: 5, isOnline: false }
        ];

        // 내 순위 찾기
        const myIndex = localData.findIndex(d => d.isMe);
        myRank = myIndex !== -1 ? localData[myIndex] : null;

        rankingData = localData.sort((a, b) => b.value - a.value).map((d, idx) => ({
            ...d,
            rank: idx + 1
        }));

        seasonInfo = {
            season: '2026년 1월',
            daysRemaining: 1
        };

        renderRanking();
    }

    // 랭킹 렌더링
    function renderRanking() {
        const content = Utils.$('#ranking-content');
        if (!content) return;

        const typeInfo = Object.values(RANKING_TYPES).find(t => t.id === currentType) || RANKING_TYPES.CHIPS;

        content.innerHTML = `
            <!-- 시즌 정보 -->
            <div class="ranking-season">
                <div class="season-title">${seasonInfo?.season || '시즌'} 랭킹</div>
                <div class="season-remaining">종료까지 ${seasonInfo?.daysRemaining || 0}일</div>
            </div>

            <!-- 타입 선택 탭 -->
            <div class="ranking-tabs">
                ${Object.values(RANKING_TYPES).map(type => `
                    <button class="ranking-tab ${type.id === currentType ? 'active' : ''}"
                            onclick="Ranking.requestRanking('${type.id}')">
                        <span class="tab-icon">${type.icon}</span>
                        <span class="tab-name">${type.name}</span>
                    </button>
                `).join('')}
            </div>

            <!-- 내 순위 -->
            ${myRank ? `
                <div class="my-rank-card">
                    <div class="my-rank-label">내 순위</div>
                    <div class="my-rank-info">
                        <span class="my-rank-position">${myRank.rank}위</span>
                        <span class="my-rank-value">${formatValue(myRank.value, typeInfo.format)}</span>
                    </div>
                </div>
            ` : ''}

            <!-- 랭킹 리스트 -->
            <div class="ranking-list">
                ${rankingData.length > 0 ? rankingData.map(item => renderRankingItem(item, typeInfo)).join('') : `
                    <div class="ranking-empty">
                        <div class="empty-icon">📊</div>
                        <div class="empty-text">랭킹 데이터가 없습니다.</div>
                    </div>
                `}
            </div>
        `;
    }

    // 랭킹 아이템 렌더링
    function renderRankingItem(item, typeInfo) {
        const rankClass = item.rank <= 3 ? `rank-${item.rank}` : '';
        const isMe = item.isMe;
        const medalIcons = { 1: '🥇', 2: '🥈', 3: '🥉' };

        return `
            <div class="ranking-item ${rankClass} ${isMe ? 'is-me' : ''}"
                 onclick="Ranking.showProfile('${item.id}')">
                <div class="rank-position">
                    ${item.rank <= 3 ? medalIcons[item.rank] : item.rank}
                </div>
                <div class="rank-player">
                    <div class="player-avatar">
                        <span class="avatar-level">${item.level}</span>
                    </div>
                    <div class="player-details">
                        <div class="player-name-row">
                            <span class="name">${item.name}</span>
                            ${item.isOnline ? '<span class="online-dot"></span>' : ''}
                        </div>
                        <div class="player-level">Lv.${item.level}</div>
                    </div>
                </div>
                <div class="rank-value">
                    ${formatValue(item.value, typeInfo.format)}
                </div>
            </div>
        `;
    }

    // 주변 순위 렌더링
    function renderNearbyRanks(data) {
        const container = Utils.$('#nearby-ranks');
        if (!container) return;

        container.innerHTML = `
            <div class="nearby-ranks-list">
                ${data.nearby.map(item => `
                    <div class="nearby-rank-item ${item.id === data.myRank?.id ? 'is-me' : ''}">
                        <span class="nearby-position">${item.rank}</span>
                        <span class="nearby-name">${item.name}</span>
                        <span class="nearby-value">${Utils.formatChips(item.value)}</span>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // 값 포맷팅
    function formatValue(value, format) {
        switch (format) {
            case 'chips':
                return Utils.formatChips(value);
            case 'percent':
                return `${value}%`;
            case 'number':
                return value.toLocaleString();
            case 'level':
                return `Lv.${value}`;
            default:
                return value;
        }
    }

    // 프로필 보기
    function showProfile(userId) {
        if (typeof Profile !== 'undefined') {
            Profile.openModal(userId);
        }
    }

    // 모달 열기
    function openModal() {
        const modal = Utils.$('#ranking-modal');
        if (modal) {
            Utils.show('#ranking-modal');
            requestRanking(currentType);
        }
    }

    // 모달 닫기
    function closeModal() {
        const modal = Utils.$('#ranking-modal');
        if (modal) {
            Utils.hide('#ranking-modal');
        }
    }

    // Public API
    return {
        init,
        requestRanking,
        openModal,
        closeModal,
        showProfile,
        RANKING_TYPES
    };
})();

window.Ranking = Ranking;
