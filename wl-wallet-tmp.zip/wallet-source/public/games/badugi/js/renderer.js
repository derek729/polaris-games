/* client/js/renderer.js - 카드 렌더링 완전 재작성 */

const Renderer = (function() {
    'use strict';

    // 카드 무늬 심볼
    var SUIT_SYMBOLS = {
        spade: '♠',
        heart: '♥',
        diamond: '♦',
        club: '♣'
    };

    // 카드 무늬 색상
    var SUIT_COLORS = {
        spade: '#1a202c',
        heart: '#dc2626',
        diamond: '#dc2626',
        club: '#1a202c'
    };

    // 카드 랭크 표시
    var RANK_DISPLAY = {
        1: 'A', 2: '2', 3: '3', 4: '4', 5: '5',
        6: '6', 7: '7', 8: '8', 9: '9', 10: '10',
        11: 'J', 12: 'Q', 13: 'K'
    };

    // 카드 앞면 생성
    function createCardFront(card, index, selectable) {
        var suit = card.suit;
        var rank = card.rank;
        var symbol = SUIT_SYMBOLS[suit] || '?';
        var color = SUIT_COLORS[suit] || '#000';
        var selectableClass = selectable ? 'selectable' : '';
        var clickHandler = selectable ? 'onclick="Renderer.toggleCardSelection(' + index + ')"' : '';

        return '<div class="card card-front ' + selectableClass + '" ' +
               'data-index="' + index + '" ' +
               'data-suit="' + suit + '" ' +
               clickHandler + '>' +
            '<div class="card-inner" style="color: ' + color + '">' +
                '<div class="card-corner card-corner-top">' +
                    '<span class="card-rank">' + rank + '</span>' +
                    '<span class="card-suit">' + symbol + '</span>' +
                '</div>' +
                '<div class="card-center">' +
                    '<span class="card-suit-large">' + symbol + '</span>' +
                '</div>' +
                '<div class="card-corner card-corner-bottom">' +
                    '<span class="card-rank">' + rank + '</span>' +
                    '<span class="card-suit">' + symbol + '</span>' +
                '</div>' +
            '</div>' +
        '</div>';
    }

    // 카드 뒷면 생성
    function createCardBack(index) {
        return '<div class="card card-back" data-index="' + index + '"></div>';
    }

    // 카드 HTML 생성
    function createCardHTML(card, index, isHidden, selectable) {
        if (isHidden || !card) {
            return createCardBack(index);
        }
        return createCardFront(card, index, selectable);
    }

    // 카드 렌더링
    function renderCards(containerId, cards, options) {
        options = options || {};
        var isMe = options.isMe || false;
        var isHidden = options.isHidden || false;
        var isSelectable = options.isSelectable || false;

        var container = document.getElementById(containerId);
        if (!container) {
            console.warn('[Renderer] 컨테이너 없음:', containerId);
            return;
        }

        if (!cards || cards.length === 0) {
            container.innerHTML = '';
            return;
        }

        var html = '';
        for (var i = 0; i < cards.length; i++) {
            html += createCardHTML(
                cards[i],
                i,
                isHidden,
                isMe && isSelectable && !isHidden
            );
        }

        container.innerHTML = html;
    }

    // 플레이어 카드 렌더링
    function renderPlayerCards(containerId, cards, isMe, isHidden) {
        renderCards(containerId, cards, {
            isMe: isMe,
            isHidden: isHidden,
            isSelectable: true
        });
    }

    // 상대방 카드 렌더링
    function renderOpponentCards(containerId, count) {
        var container = document.getElementById(containerId);
        if (!container) return;

        var html = '';
        for (var i = 0; i < count; i++) {
            html += createCardBack(i);
        }
        container.innerHTML = html;
    }

    // 카드 선택 토글
    function toggleCardSelection(index) {
        var cards = document.querySelectorAll('#my-cards .card');
        if (cards && cards[index]) {
            cards[index].classList.toggle('selected');
            updateExchangeButton();
        }
    }

    // 선택된 카드 인덱스 가져오기
    function getSelectedCardIndices() {
        var selectedCards = document.querySelectorAll('.card.selected');
        var indices = [];
        for (var i = 0; i < selectedCards.length; i++) {
            var index = parseInt(selectedCards[i].dataset.index);
            if (!isNaN(index)) {
                indices.push(index);
            }
        }
        return indices;
    }

    // 카드 선택 초기화
    function clearCardSelection() {
        var selectedCards = document.querySelectorAll('.card.selected');
        for (var i = 0; i < selectedCards.length; i++) {
            selectedCards[i].classList.remove('selected');
        }
    }

    // 교환 버튼 업데이트
    function updateExchangeButton() {
        var selectedCards = document.querySelectorAll('.card.selected');
        var exchangeBtn = document.getElementById('btn-exchange');

        if (exchangeBtn) {
            var count = selectedCards.length;
            exchangeBtn.textContent = count > 0 ? '교환 (' + count + '장)' : '교환 안함';
            exchangeBtn.disabled = false;
        }
    }

    // 방 목록 렌더링
    function renderRoomList(rooms) {
        var container = document.getElementById('room-list');
        if (!container) return;

        // 로컬 모드일 때 기본 방 목록 표시
        var mode = window.currentGameMode ? window.currentGameMode() : 'local';

        if (mode === 'local' && (!rooms || rooms.length === 0)) {
            rooms = [
                { id: 'local_1', name: '초급방', ante: 1000, players: 1 },
                { id: 'local_2', name: '중급방', ante: 5000, players: 2 },
                { id: 'local_3', name: '고급방', ante: 10000, players: 0 }
            ];
        }

        if (!rooms || rooms.length === 0) {
            container.innerHTML = '<div class="text-gray-400 text-center py-8">방이 없습니다<br><small>방 만들기 버튼을 눌러 새 방을 만드세요</small></div>';
            return;
        }

        var html = '';
        for (var i = 0; i < rooms.length; i++) {
            var room = rooms[i];
            var onclick = mode === 'local' 
                ? 'Game.startLocalGame(\'' + room.id + '\', \'' + room.name + '\')'
                : 'joinRoom(\'network\', \'' + room.id + '\')';
            html += '<div class="room-card" onclick="' + onclick + '">' +
                '<h3>' + room.name + '</h3>' +
                '<p>앤티: ₩' + (room.ante || room.minBet || 1000).toLocaleString() + '</p>' +
                '<p>플레이어: ' + (room.players || 0) + '/4</p>' +
            '</div>';
        }
        container.innerHTML = html;
    }

    // 팟 표시 업데이트
    function updatePotDisplay(pot) {
        var el = document.getElementById('pot-amount');
        if (el) {
            el.textContent = '₩' + (pot || 0).toLocaleString();
        }
    }

    // 칩 표시 업데이트
    function updateChipsDisplay(chips) {
        var el = document.getElementById('my-chips');
        if (el) {
            el.textContent = '₩' + (chips || 0).toLocaleString();
        }
    }

    // Public API
    return {
        createCardFront: createCardFront,
        createCardBack: createCardBack,
        createCardHTML: createCardHTML,
        renderCards: renderCards,
        renderPlayerCards: renderPlayerCards,
        renderOpponentCards: renderOpponentCards,
        toggleCardSelection: toggleCardSelection,
        getSelectedCardIndices: getSelectedCardIndices,
        clearCardSelection: clearCardSelection,
        updateExchangeButton: updateExchangeButton,
        renderRoomList: renderRoomList,
        updatePotDisplay: updatePotDisplay,
        updateChipsDisplay: updateChipsDisplay
    };
})();

// 전역 등록
window.Renderer = Renderer;
