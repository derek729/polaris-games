/* =========================================
   메인 진입점 및 초기화
   ========================================== */

// 바둑이 판정 로직
const BadugiEvaluator = {

  // 유효한 바둑이 조합인지 확인
  isValidBadugi(cards) {
    const suits = new Set();
    const values = new Set();

    for (const card of cards) {
      if (suits.has(card.suit) || values.has(card.value)) {
        return false;
      }
      suits.add(card.suit);
      values.add(card.value);
    }
    return true;
  },

  // 조합 생성
  getCombinations(arr, size) {
    if (size === 1) return arr.map(x => [x]);
    if (size === arr.length) return [arr];
    if (size > arr.length) return [];

    const result = [];
    for (let i = 0; i <= arr.length - size; i++) {
      const rest = this.getCombinations(arr.slice(i + 1), size - 1);
      for (const combo of rest) {
        result.push([arr[i], ...combo]);
      }
    }
    return result;
  },

  // 최적 핸드 찾기
  getBestHand(cards) {
    for (let size = Math.min(4, cards.length); size >= 1; size--) {
      const combos = this.getCombinations(cards, size);
      let bestCombo = null;
      let bestScore = Infinity;

      for (const combo of combos) {
        if (this.isValidBadugi(combo)) {
          const score = combo.reduce((sum, c) => sum + c.value, 0);
          if (score < bestScore) {
            bestScore = score;
            bestCombo = combo;
          }
        }
      }

      if (bestCombo) {
        return {
          cards: bestCombo.sort((a, b) => a.value - b.value),
          size,
          score: bestScore,
          name: this.getHandName(bestCombo, size)
        };
      }
    }

    const lowest = cards.reduce((min, c) => c.value < min.value ? c : min);
    return {
      cards: [lowest],
      size: 1,
      score: lowest.value,
      name: this.getHandName([lowest], 1)
    };
  },

  // 핸드 이름
  getHandName(cards, size) {
    const sizeNames = ['', '원카드', '투카드', '쓰리카드', '바둑이'];
    const topCard = Math.min(...cards.map(c => c.value));
    const topNames = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

    if (size === 4) {
      if (topCard <= 4) return `${topNames[topCard]} 바둑이 (로우)`;
      if (topCard <= 6) return `${topNames[topCard]} 바둑이 (미들)`;
      return `${topNames[topCard]} 바둑이 (하이)`;
    }

    return `${topNames[topCard]} ${sizeNames[size]}`;
  },

  // 핸드 비교 (-1: hand1 승, 0: 무승부, 1: hand2 승)
  compareHands(hand1, hand2) {
    if (hand1.size !== hand2.size) {
      return hand1.size > hand2.size ? -1 : 1;
    }

    if (hand1.score !== hand2.score) {
      return hand1.score < hand2.score ? -1 : 1;
    }

    const cards1 = [...hand1.cards].sort((a, b) => a.value - b.value);
    const cards2 = [...hand2.cards].sort((a, b) => a.value - b.value);

    for (let i = 0; i < cards1.length; i++) {
      if (cards1[i].value !== cards2[i].value) {
        return cards1[i].value < cards2[i].value ? -1 : 1;
      }
    }

    return 0;
  }
};

/* ==========================================
   앱 초기화
   ========================================== */

// 게임 모드: 'local' (싱글 플레이) 또는 'network' (멀티플레이)
let currentGameMode = 'local';

function initApp() {
  console.log('🎴 바둑이 포커 초기화 중...');

  // 1. 사운드 매니저 초기화
  if (typeof SoundManager !== 'undefined') {
    SoundManager.init();
  }

  // 2. 상점 초기화
  if (typeof Shop !== 'undefined') {
    Shop.init();
  }

  // 3. 업적 초기화
  if (typeof Achievements !== 'undefined') {
    Achievements.init();
  }

  // 4. 소켓 초기화
  if (typeof SocketManager !== 'undefined') {
    SocketManager.init();
  }

  // 5. 게임 초기화
  if (typeof Game !== 'undefined') {
    Game.init();
  }

  // 6. 저장된 데이터 로드
  Storage.loadGameData();

  // 7. 플레이어 이름 입력 처리
  UI.handlePlayerNameInput();

  // 8. 칩 표시 업데이트
  Renderer.updateChipsDisplay();

  // 9. 방 목록 렌더링
  Renderer.renderRoomList();

  // 10. 기타 모듈 초기화
  const modules = [
    { name: 'Tutorial', obj: Tutorial },
    { name: 'DailyChallenge', obj: DailyChallenge },
    { name: 'SeasonPass', obj: SeasonPass },
    { name: 'HandHistory', obj: HandHistory },
    { name: 'Ranking', obj: Ranking },
    { name: 'Friends', obj: Friends },
    { name: 'Tournament', obj: Tournament },
    { name: 'Missions', obj: Missions },
    { name: 'VIPSystem', obj: VIPSystem },
    { name: 'I18n', obj: I18n }
  ];

  modules.forEach(({ name, obj }) => {
    if (obj && typeof obj.init === 'function') {
      try {
        obj.init();
      } catch (e) {
        console.warn(`[${name}] 초기화 실패:`, e);
      }
    }
  });

  // 11. VIP 뱃지 업데이트
  if (typeof UI !== 'undefined' && typeof UI.updateVIPBadge === 'function') {
    UI.updateVIPBadge();
  }

  // 12. 알림 뱃지 업데이트
  if (typeof UI !== 'undefined' && typeof UI.updateNotificationBadges === 'function') {
    UI.updateNotificationBadges();
  }

  // 소켓 매니저 초기화 (네트워크 모드를 위해)
  if (typeof SocketManager !== 'undefined') {
    SocketManager.init().then(() => {
      console.log('✅ Socket.IO 연결 성공');
      // 로비 입장
      const playerName = Utils.$('#player-name')?.value || 'Player';
      SocketManager.joinLobby(playerName, State.myChips);
      // 방 목록 요청
      SocketManager.getRooms();
    }).catch((error) => {
      console.warn('⚠️ Socket.IO 연결 실패 (로컬 모드만 가능):', error);
      UI.showToast('네트워크 연결에 실패했습니다. 로컬 모드만 이용 가능합니다.', 'warning');
    });
  }

  // 일일 보상 체크 - 받을 수 있으면 자동 팝업
  if (typeof DailyReward !== 'undefined' && DailyReward.canClaim()) {
    setTimeout(() => {
      if (typeof UI !== 'undefined' && typeof UI.openDailyRewardModal === 'function') {
        UI.openDailyRewardModal();
      }
    }, 1000);
  }

  // 주기적 업데이트
  setInterval(() => {
    // 충전 모달 타이머
    const chargeModal = Utils.$('#charge-modal');
    if (chargeModal && !chargeModal.classList.contains('hidden')) {
      UI.updateFreeChargeTimer();
    }

    // 알림 뱃지 업데이트
    if (typeof UI !== 'undefined' && typeof UI.updateNotificationBadges === 'function') {
      UI.updateNotificationBadges();
    }

    // 일일 챌린지 타이머 업데이트
    if (typeof DailyChallenge !== 'undefined') {
      DailyChallenge.updateTimeRemaining();
    }
  }, 1000);

  // 레벨업 체크 (페이지 로드 시)
  if (typeof VIPSystem !== 'undefined') {
    checkLevelUpOnLoad();
  }

  // 첫 방문 체크 (튜토리얼)
  checkFirstVisit();

  console.log('✅ 초기화 완료!');
  console.log(`💰 보유 칩: ${Utils.formatChips(State.myChips)}`);

  if (typeof VIPSystem !== 'undefined') {
    const vipStatus = VIPSystem.getStatus();
    console.log(`👑 VIP 레벨: ${vipStatus.levelInfo.name}`);
  }
}

// 첫 방문 체크
function checkFirstVisit() {
  const visited = localStorage.getItem('badugi_visited');
  if (!visited) {
    localStorage.setItem('badugi_visited', 'true');

    // 튜토리얼 시작
    setTimeout(() => {
      if (typeof Tutorial !== 'undefined') {
        Tutorial.start('main');
      }
    }, 2000);
  }
}

// 게임 모드 설정
function setGameMode(mode) {
  currentGameMode = mode;
  console.log(`🎮 게임 모드: ${mode === 'local' ? '로컬' : '네트워크'}`);

  // UI 업데이트
  const modeBtns = document.querySelectorAll('.mode-btn');
  modeBtns.forEach(btn => {
    btn.classList.remove('active');
    if (btn.dataset.mode === mode) {
      btn.classList.add('active');
    }
  });

  // 로컬 모드: 방 목록을 로컬 방들로 표시
  if (mode === 'local') {
    Renderer.renderRoomList();
  }
  // 네트워크 모드: 방 목록 요청
  else if (mode === 'network') {
    if (typeof SocketManager !== 'undefined') {
      SocketManager.getRooms();
    }
  }
}

// 방 입장 처리 (모드에 따라)
function joinRoom(mode, roomId) {
  if (mode === 'local') {
    // 로컬 게임 시작
    Game.startLocalGame(roomId);
  } else if (mode === 'network') {
    // 네트워크 게임 시작
    if (typeof SocketManager !== 'undefined') {
      SocketManager.joinRoom(roomId);
    } else {
      UI.showToast('네트워크에 연결되지 않았습니다.', 'error');
    }
  }
}

// 레벨업 체크 (로드 시)
function checkLevelUpOnLoad() {
  if (typeof VIPSystem === 'undefined' || typeof UI === 'undefined') return;

  const vipStatus = VIPSystem.getStatus();
  const savedLevel = Storage.get('badugi_last_vip_level', 0);

  if (vipStatus.level > savedLevel) {
    Storage.set('badugi_last_vip_level', vipStatus.level);

    if (savedLevel > 0) {
      // 레벨업 알림
      if (typeof UI.showToast === 'function') {
        UI.showToast(
          'success',
          '🎉 VIP 레벨 업!',
          `${vipStatus.levelInfo.icon} ${vipStatus.levelInfo.name} 등급이 되었습니다!`
        );
      }
    }
  }
}

/* ==========================================
   전역 함수 노출 (HTML onclick 용)
   ========================================== */

window.Game = Game;
window.UI = UI;
window.Renderer = Renderer;
window.Storage = Storage;
window.Utils = Utils;
window.State = State;
window.BadugiEvaluator = BadugiEvaluator;

// 게임 모드 함수
window.setGameMode = setGameMode;
window.joinRoom = joinRoom;
window.currentGameMode = () => currentGameMode;

// 기능 모듈 노출
if (typeof DailyReward !== 'undefined') window.DailyReward = DailyReward;
if (typeof Achievements !== 'undefined') window.Achievements = Achievements;
if (typeof Missions !== 'undefined') window.Missions = Missions;
if (typeof VIPSystem !== 'undefined') window.VIPSystem = VIPSystem;
if (typeof LuckyWheel !== 'undefined') window.LuckyWheel = LuckyWheel;
if (typeof SoundManager !== 'undefined') window.SoundManager = SoundManager;
if (typeof SoundGenerator !== 'undefined') window.SoundGenerator = SoundGenerator;
if (typeof AnimationManager !== 'undefined') window.AnimationManager = AnimationManager;
if (typeof SocketManager !== 'undefined') window.SocketManager = SocketManager;
if (typeof NetworkGame !== 'undefined') window.NetworkGame = NetworkGame;
if (typeof Ranking !== 'undefined') window.Ranking = Ranking;
if (typeof Friends !== 'undefined') window.Friends = Friends;
if (typeof Profile !== 'undefined') window.Profile = Profile;
if (typeof Tournament !== 'undefined') window.Tournament = Tournament;
if (typeof DailyChallenge !== 'undefined') window.DailyChallenge = DailyChallenge;
if (typeof SeasonPass !== 'undefined') window.SeasonPass = SeasonPass;
if (typeof Shop !== 'undefined') window.Shop = Shop;
if (typeof Tutorial !== 'undefined') window.Tutorial = Tutorial;
if (typeof HandHistory !== 'undefined') window.HandHistory = HandHistory;
if (typeof I18n !== 'undefined') window.I18n = I18n;

// 설정 관련 전역 함수
window.openSettingsModal = function() {
  const modal = document.getElementById('settings-modal');
  if (modal) {
    modal.classList.remove('hidden');
  }
};

window.closeSettingsModal = function() {
  const modal = document.getElementById('settings-modal');
  if (modal) {
    modal.classList.add('hidden');
  }
};

window.setTheme = function(theme) {
  document.body.className = document.body.className.replace(/theme-\w+/g, '');
  if (theme !== 'default') {
    document.body.classList.add(`theme-${theme}`);
  }

  // 테마 버튼 활성화
  document.querySelectorAll('.theme-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === theme);
  });

  // 설정 저장
  const settings = JSON.parse(localStorage.getItem('badugi_settings') || '{}');
  settings.theme = theme;
  localStorage.setItem('badugi_settings', JSON.stringify(settings));
};

window.saveSettings = function() {
  // UI에서 값 가져오기
  const settings = {
    bgmVolume: parseInt(document.getElementById('bgm-volume')?.value || 50),
    sfxVolume: parseInt(document.getElementById('sfx-volume')?.value || 70),
    language: document.getElementById('language-select')?.value || 'ko',
    autoCheck: document.getElementById('auto-check')?.checked || false,
    cardAnimation: document.getElementById('card-animation')?.checked || true,
    turnNotification: document.getElementById('turn-notification')?.checked || true,
    theme: document.querySelector('.theme-btn.active')?.dataset.theme || 'default'
  };

  localStorage.setItem('badugi_settings', JSON.stringify(settings));

  // 적용
  if (typeof I18n !== 'undefined') {
    I18n.setLocale(settings.language);
  }

  window.UI.showToast('설정이 저장되었습니다', 'success');
  window.closeSettingsModal();
};

window.resetSettings = function() {
  const defaultSettings = {
    bgmVolume: 50,
    sfxVolume: 70,
    language: 'ko',
    autoCheck: false,
    cardAnimation: true,
    turnNotification: true,
    theme: 'default'
  };

  localStorage.setItem('badugi_settings', JSON.stringify(defaultSettings));

  // UI 업데이트
  document.getElementById('bgm-volume').value = defaultSettings.bgmVolume;
  document.getElementById('bgm-volume-value').textContent = defaultSettings.bgmVolume + '%';
  document.getElementById('sfx-volume').value = defaultSettings.sfxVolume;
  document.getElementById('sfx-volume-value').textContent = defaultSettings.sfxVolume + '%';
  document.getElementById('language-select').value = defaultSettings.language;
  document.getElementById('auto-check').checked = defaultSettings.autoCheck;
  document.getElementById('card-animation').checked = defaultSettings.cardAnimation;
  document.getElementById('turn-notification').checked = defaultSettings.turnNotification;

  window.setTheme(defaultSettings.theme);

  window.UI.showToast('설정이 초기화되었습니다', 'info');
};

/* ==========================================
   모든 기능 모듈 초기화 및 배지 업데이트
   ========================================== */

// 모든 배지 업데이트
function updateAllBadges() {
  // 일일 보상
  const dailyBadge = document.getElementById('daily-reward-badge');
  if (dailyBadge && typeof DailyReward !== 'undefined') {
    dailyBadge.style.display = DailyReward.canClaim() ? 'flex' : 'none';
  }

  // 챌린지
  const challengeBadge = document.getElementById('challenge-badge');
  if (challengeBadge && typeof DailyChallenge !== 'undefined') {
    const unclaimed = DailyChallenge.getClaimableCount();
    if (unclaimed > 0) {
      challengeBadge.textContent = unclaimed;
      challengeBadge.style.display = 'flex';
    } else {
      challengeBadge.style.display = 'none';
    }
  }

  // 시즌 패스
  const seasonBadge = document.getElementById('season-badge');
  if (seasonBadge && typeof SeasonPass !== 'undefined') {
    const unclaimed = SeasonPass.getUnclaimedCount();
    if (unclaimed > 0) {
      seasonBadge.textContent = unclaimed;
      seasonBadge.style.display = 'flex';
    } else {
      seasonBadge.style.display = 'none';
    }
  }

  // 미션
  const missionBadge = document.getElementById('missions-badge');
  if (missionBadge && typeof Missions !== 'undefined') {
    const completed = Missions.getCompletedCount();
    if (completed > 0) {
      missionBadge.textContent = completed;
      missionBadge.style.display = 'flex';
    } else {
      missionBadge.style.display = 'none';
    }
  }

  // 친구 요청
  if (typeof Friends !== 'undefined') {
    Friends.requestFriendsList();
  }
}

// 게임 이벤트 연동
function onGameEvent(eventType, data) {
  // 일일 챌린지 업데이트
  if (typeof DailyChallenge !== 'undefined') {
    const typeMap = {
      'gameCompleted': 'hands',
      'gameWon': 'wins',
      'badugiMade': 'badugi',
      'allIn': 'allin',
      'chipsWon': 'chips'
    };
    const mappedType = typeMap[eventType] || eventType;
    DailyChallenge.updateProgress(mappedType, data?.amount || 1);
  }

  // 업적 업데이트
  if (typeof Achievements !== 'undefined') {
    const stats = getPlayerStats();
    // 업적 카테고리별 진행 업데이트
    if (eventType === 'gameCompleted') {
      Achievements.updateProgress('play_' + (stats.gamesPlayed) + '_games', stats.gamesPlayed);
    }
    if (eventType === 'gameWon') {
      Achievements.updateProgress('wins_' + stats.gamesWon, stats.gamesWon);
    }
    if (eventType === 'badugiMade') {
      Achievements.updateProgress('badugi_' + data?.badugiCount, data?.badugiCount || 1);
    }
  }

  // 시즌 패스 경험치
  if (typeof SeasonPass !== 'undefined') {
    const expMap = {
      'gameCompleted': 50,
      'gameWon': 100,
      'badugiMade': 30,
      'allIn': 10
    };
    if (expMap[eventType]) {
      SeasonPass.addExp(expMap[eventType]);
    }
  }

  // 핸드 히스토리 기록
  if (typeof HandHistory !== 'undefined' && eventType === 'gameCompleted' && data?.handData) {
    HandHistory.recordHand(data.handData);
  }

  // 배지 업데이트
  updateAllBadges();
}

// 플레이어 통계 가져오기
function getPlayerStats() {
  return {
    gamesPlayed: State.stats?.gamesPlayed || 0,
    gamesWon: State.stats?.gamesWon || 0,
    badugiCount: State.stats?.badugiCount || 0,
    golfCount: State.stats?.golfCount || 0,
    chips: State.myChips,
    currentStreak: State.stats?.currentStreak || 0,
    biggestWin: State.stats?.biggestWin || 0,
    allInWins: State.stats?.allInWins || 0,
    friendsCount: (typeof Friends !== 'undefined') ? Friends.getFriendsCount() : 0,
    vipLevel: (typeof VIPSystem !== 'undefined') ? VIPSystem.getStatus().level : 0,
    loginStreak: State.loginStreak || 0
  };
}

// 전역 노출
window.updateAllBadges = updateAllBadges;
window.onGameEvent = onGameEvent;
window.getPlayerStats = getPlayerStats;

/* ==========================================
   DOM 로드 후 초기화
   ========================================== */

document.addEventListener('DOMContentLoaded', initApp);
