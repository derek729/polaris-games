/* ==========================================
   상수 정의
   ========================================== */

// 게임 상태
const GAME_STATES = {
  WAITING: 'WAITING',
  DEALING: 'DEALING',
  BETTING_MORNING: 'BETTING_MORNING',
  EXCHANGE_1: 'EXCHANGE_1',
  BETTING_NOON: 'BETTING_NOON',
  EXCHANGE_2: 'EXCHANGE_2',
  BETTING_EVENING: 'BETTING_EVENING',
  EXCHANGE_3: 'EXCHANGE_3',
  BETTING_FINAL: 'BETTING_FINAL',
  SHOWDOWN: 'SHOWDOWN',
  ROUND_END: 'ROUND_END'
};

// 베팅 라운드 순서
const BETTING_ROUNDS = [
  'BETTING_MORNING',
  'BETTING_NOON',
  'BETTING_EVENING',
  'BETTING_FINAL'
];

// 교환 라운드 순서
const EXCHANGE_ROUNDS = [
  'EXCHANGE_1',
  'EXCHANGE_2',
  'EXCHANGE_3'
];

// 라운드 이름 (한글)
const ROUND_NAMES = {
  WAITING: '대기',
  DEALING: '카드 배분',
  BETTING_MORNING: '아침',
  EXCHANGE_1: '아침 교환',
  BETTING_NOON: '점심',
  EXCHANGE_2: '점심 교환',
  BETTING_EVENING: '저녁',
  EXCHANGE_3: '저녁 교환',
  BETTING_FINAL: '최종',
  SHOWDOWN: '쇼다운',
  ROUND_END: '라운드 종료'
};

// 카드 무늬
const SUITS = ['♠', '♥', '♦', '♣'];

// 카드 숫자
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

// 카드 숫자 값
const RANK_VALUES = {
  'A': 1, '2': 2, '3': 3, '4': 4, '5': 5,
  '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
  'J': 11, 'Q': 12, 'K': 13
};

// 방 설정
const ROOMS = [
  {
    id: 'room_10k',
    name: '1만 방',
    tier: 'bronze',
    tierName: '브론즈',
    minChips: 10000,
    ante: 100,
    baseBet: 200,
    botChips: 10000
  },
  {
    id: 'room_50k',
    name: '5만 방',
    tier: 'silver',
    tierName: '실버',
    minChips: 50000,
    ante: 500,
    baseBet: 1000,
    botChips: 50000
  },
  {
    id: 'room_100k',
    name: '10만 방',
    tier: 'gold',
    tierName: '골드',
    minChips: 100000,
    ante: 1000,
    baseBet: 2000,
    botChips: 100000
  },
  {
    id: 'room_1m',
    name: '100만 방',
    tier: 'platinum',
    tierName: '플래티넘',
    minChips: 1000000,
    ante: 10000,
    baseBet: 20000,
    botChips: 1000000
  },
  {
    id: 'room_10m',
    name: '1000만 방',
    tier: 'diamond',
    tierName: '다이아',
    minChips: 10000000,
    ante: 100000,
    baseBet: 200000,
    botChips: 10000000
  },
  {
    id: 'room_100m',
    name: '1억 방',
    tier: 'master',
    tierName: '마스터',
    minChips: 100000000,
    ante: 1000000,
    baseBet: 2000000,
    botChips: 100000000
  },
  {
    id: 'room_vip',
    name: 'VIP 방',
    tier: 'vip',
    tierName: 'VIP',
    minChips: 500000000,
    ante: 5000000,
    baseBet: 10000000,
    botChips: 500000000
  }
];

// 충전 설정
const CHARGE_CONFIG = {
  FREE_AMOUNT: 5000,
  FREE_COOLDOWN: 60 * 60 * 1000, // 1시간
  EVENT_AMOUNT: 20000,
  AD_AMOUNT: 3000,
  AD_DURATION: 3000, // 3초
  SPIN_PRIZES: [1000, 2000, 3000, 5000, 10000, 20000, 50000],
  SPIN_WEIGHTS: [30, 25, 20, 12, 8, 4, 1]
};

// AI 설정
const AI_CONFIG = {
  THINK_DELAY: 800,      // AI 생각 시간 (ms)
  ACTION_DELAY: 1000,    // AI 액션 딜레이 (ms)
  NAMES: ['Shark Steve', 'Cool Cat', 'Lucky Luna']
};

// 타이머 설정
const TIMER_CONFIG = {
  ACTION_TIMEOUT: 30000,  // 액션 타임아웃 (30초)
  DEAL_DELAY: 1500,       // 딜링 딜레이
  ROUND_DELAY: 1000,      // 라운드 전환 딜레이
  SHOWDOWN_DELAY: 2000    // 쇼다운 딜레이
};

// 로컬 스토리지 키
const STORAGE_KEYS = {
  CHIPS: 'badugi_chips',
  LAST_FREE: 'badugi_lastFree',
  EVENT_USED: 'badugi_eventUsed',
  PLAYER_NAME: 'badugi_playerName'
};

// 초기 칩
const INITIAL_CHIPS = 10000;
