// client/js/networkGame.js
// 네트워크 게임 로직

const NetworkGame = (function() {
    let currentRoom = null;
    let myPlayerIndex = 0;
    let isGameReady = false;

    // 방 입장 성공 처리
    function onJoinRoomSuccess(data) {
        console.log('[NetworkGame] 방 입장 성공:', data);
        currentRoom = data.roomInfo;
        myPlayerIndex = data.seatIndex;

        // 게임 화면 전환
        Utils.hide('#lobby-screen');
        Utils.show('#game-screen');

        // 방 정보 업데이트
        updateRoomDisplay(data.roomInfo);

        // 게임 상태 초기화
        if (data.gameState === 'waiting') {
            showReadyControls();
        } else {
            hideReadyControls();
            updateGameControls(data.gameState);
        }

        UI.showToast(`${data.roomInfo.name}에 입장했습니다.`, 'success');
    }

    // 방 퇴장 성공 처리
    function onLeaveRoomSuccess(data) {
        console.log('[NetworkGame] 방 퇴장 성공:', data);

        // 칩 업데이트
        State.myChips = data.chips || State.myChips;
        Storage.saveGameData();

        // 로비로 복귀
        Utils.hide('#game-screen');
        Utils.show('#lobby-screen');

        Renderer.updateChipsDisplay();
        SocketManager.getRooms();

        currentRoom = null;
        isGameReady = false;

        UI.showToast('방에서 나왔습니다.', 'info');
    }

    // 준비 상태 변경 처리
    function onReadySuccess(data) {
        console.log('[NetworkGame] 준비 상태 변경:', data);

        const playerSlot = Utils.$(`#player-${myPlayerIndex}-area`);
        if (!playerSlot) return;

        if (data.isReady) {
            playerSlot.classList.add('ready');
            Utils.$('#btn-ready').textContent = '준비 완료';
            Utils.$('#btn-ready').classList.add('btn-success');
        } else {
            playerSlot.classList.remove('ready');
            Utils.$('#btn-ready').textContent = '준비';
            Utils.$('#btn-ready').classList.remove('btn-success');
        }
    }

    // 게임 상태 업데이트
    function onGameStateUpdate(gameState) {
        console.log('[NetworkGame] 게임 상태 업데이트:', gameState);

        State.gameState = gameState.gameState;
        State.pot = gameState.pot;
        State.currentBet = gameState.currentBet;
        State.roundIndex = 0;
        State.dealerIndex = gameState.dealerIndex;
        State.timerRemaining = gameState.timerRemaining;

        // 플레이어 정보 업데이트
        gameState.players.forEach((player, idx) => {
            if (player.id === socket.id && player.cards) {
                State.players[0].cards = player.cards;
                State.players[0].folded = player.folded;
                State.players[0].allIn = player.allIn;
                State.players[0].currentBet = player.currentBet;
            } else {
                // 상대방 정보 업데이트
                if (idx < State.players.length) {
                    State.players[idx] = {
                        ...State.players[idx],
                        name: player.name,
                        chips: player.chips,
                        folded: player.folded,
                        allIn: player.allIn,
                        currentBet: player.currentBet,
                        cardCount: player.cardCount || 0
                    };
                }
            }
        });

        // 내 턴 확인
        const isMyTurn = gameState.isMyTurn;
        Utils.$('#timer-display').textContent = State.timerRemaining;

        updateGameControls(gameState.gameState);
        updatePlayerDisplay();

        // 내 턴이면 액션 버튼 활성화
        if (isMyTurn) {
            enableActionButtons();
            if (typeof SoundManager !== 'undefined') {
                SoundManager.playTurnNotify();
            }
        }
    }

    // 내 턴 알림
    function onYourTurn(data) {
        console.log('[NetworkGame] 내 턴입니다:', data);

        State.timerRemaining = data.timeout;

        if (data.canCheck) {
            enableActionButtons();
        }

        // 타이머 시작
        UI.startActionTimer(data.timeout);

        // 턴 표시
        if (typeof AnimationManager !== 'undefined') {
            AnimationManager.showTurnIndicator(myPlayerIndex);
        }
    }

    // 카드 배분
    function onCardsDealt(data) {
        console.log('[NetworkGame] 카드 배분:', data);

        State.players[0].cards = data.cards;
        State.selectedCards.clear();

        // 카드 애니메이션
        if (typeof AnimationManager !== 'undefined') {
            AnimationManager.dealCards();
        } else {
            Renderer.renderMyCards();
        }

        Renderer.addLog('카드가 배분되었습니다.');
    }

    // 카드 교환 완료
    function onCardsExchanged(data) {
        console.log('[NetworkGame] 카드 교환 완료:', data);

        State.players[0].cards = data.cards;

        Renderer.renderMyCards();
        Renderer.addLog(`${data.exchanged}장 교환했습니다.`);
    }

    // 라운드 종료
    function onRoundEnd(data) {
    console.log('[NetworkGame] 라운드 종료:', data);

        UI.stopTimer();

        if (data.winners.some(w => w.id === socket.id)) {
            // 승리
            const winAmount = data.winAmount;
            if (typeof AnimationManager !== 'undefined') {
                AnimationManager.showWinCelebration(myPlayerIndex, winAmount);
            }
            showWinModal(winAmount, data.handName);
        } else {
            // 패배
            showLoseModal(data.winners[0].name, data.handName);
        }

        // 다음 핸드 자동 시작
        setTimeout(() => {
            Renderer.hideAllModals();
        }, 5000);
    }

    // ========== 액션 함수 ==========

    function doFold() {
        if (!canAct()) return;

        SocketManager.sendBetAction('fold');
        disableActionButtons();
    }

    function doCheck() {
        if (!canAct()) return;

        SocketManager.sendBetAction('check');
        disableActionButtons();
    }

    function doCall() {
        if (!canAct()) return;

        const player = State.players[0];
        const callAmount = State.currentBet - player.currentBet;

        if (callAmount <= 0) {
            doCheck();
            return;
        }

        SocketManager.sendBetAction('call', callAmount);
        disableActionButtons();
    }

    function doRaise(amount) {
        if (!canAct()) return;

        SocketManager.sendBetAction('raise', amount);
        disableActionButtons();
    }

    function doAllIn() {
        if (!canAct()) return;

        const player = State.players[0];
        const allInAmount = player.chips;
        SocketManager.sendBetAction('allin', allInAmount);
        disableActionButtons();
    }

    function doExchange(cardIndices) {
        if (!canAct()) return;

        SocketManager.sendExchange(cardIndices);
    }

    function doReady() {
        SocketManager.ready();
    }

    function doLeaveRoom() {
        if (confirm('정말 방을 나가시겠습니까?')) {
            SocketManager.leaveRoom();
        }
    }

    // ========== 유�리티 ==========

    function canAct() {
        return isGameReady &&
               State.gameState !== 'waiting' &&
               !State.players[0].folded &&
               !State.players[0].allIn;
    }

    function updateGameControls(gameState) {
        const bettingStates = ['betting_morning', 'betting_noon', 'betting_evening', 'betting_final'];
        const exchangeStates = ['exchange_1', 'exchange_2', 'exchange_3'];

        // 베팅 라운드
        if (bettingStates.includes(gameState)) {
            showBettingControls();
            hideExchangeControls();
            hideReadyControls();
        }
        // 교환 라운드
        else if (exchangeStates.includes(gameState)) {
            hideBettingControls();
            showExchangeControls();
            hideReadyControls();
        }
        // 대기 중
        else {
            hideBettingControls();
            hideExchangeControls();
            showReadyControls();
        }
    }

    function updateRoomDisplay(roomInfo) {
        Utils.$('#room-name-display').textContent = roomInfo.name;
        Utils.$('#room-status').textContent =
            roomInfo.gameState === 'waiting' ? '대기 중' : '게임 중';
    }

    function updatePlayerDisplay() {
        // 플레이어 영역 렌더링
        for (let i = 0; i < 4; i++) {
            renderPlayerArea(i);
        }
    }

    function renderPlayerArea(playerIndex) {
        const area = Utils.$(`#player-${playerIndex}-area`);
        if (!area) return;

        const player = State.players[playerIndex];
        if (!player) {
            area.innerHTML = '<div class="empty-seat"><span class="empty-seat">비어있음</span></div>';
            return;
        }

        const isMe = playerIndex === 0;
        const showCards = isMe || (playerIndex === myPlayerIndex && State.gameState === 'showdown');

        let cardsHTML = '';
        if (player.cards && player.cards.length > 0) {
            if (showCards) {
                cardsHTML = player.cards.map(card => `
                    <div class="card ${card.suit} playing-card">
                        <span class="card-rank">${card.rank}</span>
                        <span class="card-suit">${getSuitSymbol(card.suit)}</span>
                    </div>
                `).join('');
            } else {
                cardsHTML = Array(player.cardCount || 4).fill('<div class="card card-back playing-card"></div>').join('');
            }
        }

        area.innerHTML = `
            <div class="player-slot ${player.folded ? 'folded' : ''} ${player.allIn ? 'allin' : ''}">
                ${playerIndex === State.dealerIndex ? '<div class="dealer-button">D</div>' : ''}
                ${!isMe && player.isReady ? '<div class="ready-badge">READY</div>' : ''}
                ${!isMe && !player.isConnected ? '<div class="disconnected-badge">오프라인</div>' : ''}
                <div class="player-info">
                    <div class="player-name ${isMe ? 'is-me' : ''}">${player.name}</div>
                    <div class="player-chips">${Utils.formatChips(player.chips)}</div>
                </div>
                <div class="player-cards">
                    ${cardsHTML}
                </div>
                ${player.lastAction ? `<div class="action-bubble ${player.lastAction}">${formatActionName(player.lastAction)}</div>` : ''}
            </div>
        `;
    }

    function formatActionName(action) {
        const names = {
            'fold': '폴드',
            'check': '체크',
            'call': '콜',
            'raise': '레이즈',
            'allin': '올인',
            'all-in': '올인'
        };
        return names[action] || action;
    }

    function getSuitSymbol(suit) {
        const symbols = { 'spade': '♠', 'heart': '♥', 'diamond': '◆', 'club': '♣' };
        return symbols[suit] || suit;
    }

    // ========== 컨트롤 표시/숨김 ==========

    function showBettingControls() {
        Utils.show('#betting-controls');
        Utils.hide('#exchange-controls');
        Utils.hide('#ready-controls');
        Utils.hide('#raise-slider-container');

        // 콜/체크 버튼 상태
        const player = State.players[0];
        const canCheck = player.currentBet >= State.currentBet;

        updateActionButton('check', canCheck);
        updateActionButton('call', !canCheck);
    }

    function showExchangeControls() {
        Utils.hide('#betting-controls');
        Utils.show('#exchange-controls');
        Utils.hide('#ready-controls');

        // 선택한 카드 수에 따라 버튼 텍스트 변경
        updateExchangeButton();
    }

    function showReadyControls() {
        Utils.hide('#betting-controls');
        Utils.hide('#exchange-controls');
        Utils.show('#ready-controls');
    }

    function hideBettingControls() {
        Utils.hide('#betting-controls');
        Utils.hide('#raise-slider-container');
    }

    function hideExchangeControls() {
        Utils.hide('#exchange-controls');
    }

    function hideReadyControls() {
        Utils.hide('#ready-controls');
    }

    function updateActionButton(action, enabled) {
        const btn = Utils.$(`#btn-${action}`);
        if (btn) {
            btn.disabled = !enabled;
        }
    }

    function updateExchangeButton() {
        const count = State.selectedCards.size;
        const btn = Utils.$('#btn-exchange');
        if (btn) {
            btn.textContent = count === 0 ? '패스 (교환 안함)' : `${count}장 교환`;
        }
    }

    function enableActionButtons() {
        updateActionButton('fold', true);
        updateActionButton('check', State.currentBet <= State.players[0].currentBet);
        updateActionButton('call', State.currentBet > State.players[0].currentBet);
        updateActionButton('raise', State.players[0].chips > 0);
        updateActionButton('allin', State.players[0].chips > 0);
    }

    function disableActionButtons() {
        updateActionButton('fold', false);
        updateActionButton('check', false);
        updateActionButton('call', false);
        updateActionButton('raise', false);
        updateActionButton('allin', false);
    }

    // ========== 렌더러 ==========

    function getRaiseAmount() {
        const slider = Utils.$('#raise-slider');
        return slider ? parseInt(slider.value) : State.currentBet + State.baseBet;
    }

    // 칩 업데이트
    function updateMyChips(amount) {
        State.myChips = amount;
        Storage.saveGameData();
        Renderer.updateChipsDisplay();

        // UI에 반영
        const chipElements = document.querySelectorAll('.my-chips, .chips-value');
        chipElements.forEach(el => {
            el.textContent = Utils.formatChips(amount);
        });
    }

    // Public API
    return {
        onJoinRoomSuccess,
        onLeaveRoomSuccess,
        onReadySuccess,
        onGameStateUpdate,
        onYourTurn,
        onCardsDealt,
        onCardsExchanged,
        onRoundEnd,
        doFold,
        doCheck,
        doCall,
        doRaise,
        doAllIn,
        doExchange,
        doReady,
        doLeaveRoom,
        canAct,
        updateMyChips,
        getRaiseAmount
    };
})();

window.NetworkGame = NetworkGame;
