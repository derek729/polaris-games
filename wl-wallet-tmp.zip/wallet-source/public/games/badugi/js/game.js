// client/js/game.js - 완전히 새로 작성

const Game = (function() {
    'use strict';

    // 게임 상태
    let state = {
        roomId: null,
        roomName: '',
        players: [],
        myIndex: 0,
        myCards: [],
        pot: 0,
        currentBet: 0,
        myBet: 0,
        myChips: 10000,
        gamePhase: 'waiting',
        isMyTurn: false,
        canCheck: false,
        canRaise: true,
        minRaise: 0,
        maxRaise: 0,
        dealerIndex: 0,
        currentPlayerIndex: -1
    };

    let isInitialized = false;

    // 초기화
    function init() {
        if (isInitialized) return;

        console.log('[Game] 초기화');
        setupEventListeners();
        isInitialized = true;
    }

    // 이벤트 리스너 설정
    function setupEventListeners() {
        // 버튼들
        document.addEventListener('click', function(e) {
            const target = e.target;

            if (target.id === 'btn-fold' || target.closest('#btn-fold')) {
                e.preventDefault();
                doFold();
            } else if (target.id === 'btn-call' || target.closest('#btn-call')) {
                e.preventDefault();
                doCall();
            } else if (target.id === 'btn-half' || target.closest('#btn-half')) {
                e.preventDefault();
                doHalf();
            } else if (target.id === 'btn-raise' || target.closest('#btn-raise')) {
                e.preventDefault();
                doRaise();
            } else if (target.id === 'btn-allin' || target.closest('#btn-allin')) {
                e.preventDefault();
                doAllIn();
            } else if (target.id === 'btn-exchange' || target.closest('#btn-exchange')) {
                e.preventDefault();
                doExchange();
            }
        });

        console.log('[Game] 이벤트 리스너 설정 완료');
    }

    // 방 입장
    function enterRoom(roomId, roomName) {
        console.log('[Game] 방 입장:', roomId);
        state.roomId = roomId;
        state.roomName = roomName || roomId;

        // 사운드
        if (window.SoundManager && typeof SoundManager.playGameBGM === 'function') {
            SoundManager.playGameBGM();
        }

        // 소켓 이벤트
        if (window.SocketManager) {
            SocketManager.emit('join_room', { roomId: roomId });
        }

        // UI 업데이트
        showGameScreen();
    }

    // 방 퇴장
    function leaveRoom() {
        console.log('[Game] 방 퇴장');

        if (window.SoundManager && typeof SoundManager.playLobbyBGM === 'function') {
            SoundManager.playLobbyBGM();
        }

        if (window.SocketManager) {
            SocketManager.emit('leave_room');
        }

        state.roomId = null;
        showLobbyScreen();
    }

    // 게임 화면 표시
    function showGameScreen() {
        const lobbyScreen = document.getElementById('lobby-screen');
        const gameScreen = document.getElementById('game-screen');

        if (lobbyScreen) lobbyScreen.style.display = 'none';
        if (gameScreen) gameScreen.style.display = 'block';
    }

    // 로비 화면 표시
    function showLobbyScreen() {
        const lobbyScreen = document.getElementById('lobby-screen');
        const gameScreen = document.getElementById('game-screen');

        if (lobbyScreen) lobbyScreen.style.display = 'block';
        if (gameScreen) gameScreen.style.display = 'none';
    }

    // 폴드
    function doFold() {
        if (!state.isMyTurn) {
            console.log('[Game] 내 턴이 아님');
            return;
        }

        console.log('[Game] 폴드');

        if (window.SoundManager && typeof SoundManager.playFold === 'function') {
            SoundManager.playFold();
        }

        if (window.SocketManager) {
            SocketManager.emit('bet_action', { action: 'fold' });
        }

        state.isMyTurn = false;
        disableBettingButtons();
    }

    // 체크/콜
    function doCall() {
        if (!state.isMyTurn) {
            console.log('[Game] 내 턴이 아님');
            return;
        }

        const action = state.canCheck ? 'check' : 'call';
        console.log('[Game]', action);

        if (window.SoundManager) {
            if (action === 'check' && typeof SoundManager.playCheck === 'function') {
                SoundManager.playCheck();
            } else if (typeof SoundManager.playCall === 'function') {
                SoundManager.playCall();
            }
        }

        if (window.SocketManager) {
            SocketManager.emit('bet_action', { action: action });
        }

        state.isMyTurn = false;
        disableBettingButtons();
    }

    // 하프팟
    function doHalf() {
        if (!state.isMyTurn || !state.canRaise) {
            console.log('[Game] 레이즈 불가');
            return;
        }

        const halfPot = Math.floor(state.pot / 2);
        const amount = Math.max(halfPot, state.minRaise);

        console.log('[Game] 하프팟:', amount);

        if (window.SoundManager && typeof SoundManager.playRaise === 'function') {
            SoundManager.playRaise();
        }

        if (window.SocketManager) {
            SocketManager.emit('bet_action', { action: 'raise', amount: amount });
        }

        state.isMyTurn = false;
        disableBettingButtons();
    }

    // 레이즈
    function doRaise() {
        if (!state.isMyTurn || !state.canRaise) {
            console.log('[Game] 레이즈 불가');
            return;
        }

        const raiseInput = document.getElementById('raise-amount');
        let amount = state.minRaise;

        if (raiseInput && raiseInput.value) {
            amount = parseInt(raiseInput.value) || state.minRaise;
        }

        amount = Math.max(amount, state.minRaise);
        amount = Math.min(amount, state.maxRaise);

        console.log('[Game] 레이즈:', amount);

        if (window.SoundManager && typeof SoundManager.playRaise === 'function') {
            SoundManager.playRaise();
        }

        if (window.SocketManager) {
            SocketManager.emit('bet_action', { action: 'raise', amount: amount });
        }

        state.isMyTurn = false;
        disableBettingButtons();
    }

    // 올인
    function doAllIn() {
        if (!state.isMyTurn) {
            console.log('[Game] 내 턴이 아님');
            return;
        }

        console.log('[Game] 올인');

        if (window.SoundManager && typeof SoundManager.playAllIn === 'function') {
            SoundManager.playAllIn();
        }

        if (window.SocketManager) {
            SocketManager.emit('bet_action', { action: 'allin' });
        }

        state.isMyTurn = false;
        disableBettingButtons();
    }

    // 카드 교환
    function doExchange() {
        if (state.gamePhase !== 'exchange') {
            console.log('[Game] 교환 페이즈 아님');
            return;
        }

        const selectedCards = document.querySelectorAll('.card.selected');
        const indices = Array.from(selectedCards).map(function(card) {
            return parseInt(card.dataset.index);
        });

        console.log('[Game] 카드 교환:', indices.length, '장');

        if (window.SoundManager && typeof SoundManager.playCardDeal === 'function') {
            SoundManager.playCardDeal();
        }

        if (window.SocketManager) {
            SocketManager.emit('exchange_cards', { indices: indices });
        }

        // 선택 해제
        selectedCards.forEach(function(card) {
            card.classList.remove('selected');
        });

        disableExchangeButton();
    }

    // 버튼 활성화
    function enableBettingButtons(turnData) {
        state.isMyTurn = true;
        state.canCheck = turnData && turnData.canCheck;
        state.canRaise = turnData && turnData.canRaise !== false;
        state.minRaise = (turnData && turnData.minRaise) || state.currentBet * 2;
        state.maxRaise = (turnData && turnData.maxRaise) || state.myChips;

        const foldBtn = document.getElementById('btn-fold');
        const callBtn = document.getElementById('btn-call');
        const halfBtn = document.getElementById('btn-half');
        const raiseBtn = document.getElementById('btn-raise');
        const allinBtn = document.getElementById('btn-allin');

        if (foldBtn) foldBtn.disabled = false;
        if (callBtn) {
            callBtn.disabled = false;
            if (state.canCheck) {
                callBtn.textContent = '체크';
            } else {
                const toCall = state.currentBet - state.myBet;
                callBtn.textContent = '콜 ₩' + toCall.toLocaleString();
            }
        }
        if (halfBtn) halfBtn.disabled = !state.canRaise;
        if (raiseBtn) raiseBtn.disabled = !state.canRaise;
        if (allinBtn) allinBtn.disabled = false;

        console.log('[Game] 베팅 버튼 활성화');
    }

    // 버튼 비활성화
    function disableBettingButtons() {
        state.isMyTurn = false;

        ['btn-fold', 'btn-call', 'btn-half', 'btn-raise', 'btn-allin'].forEach(function(id) {
            const btn = document.getElementById(id);
            if (btn) btn.disabled = true;
        });

        console.log('[Game] 베팅 버튼 비활성화');
    }

    // 교환 버튼 활성화
    function enableExchangeButton() {
        state.gamePhase = 'exchange';
        const btn = document.getElementById('btn-exchange');
        if (btn) {
            btn.disabled = false;
            btn.style.display = 'block';
        }
    }

    // 교환 버튼 비활성화
    function disableExchangeButton() {
        const btn = document.getElementById('btn-exchange');
        if (btn) {
            btn.disabled = true;
        }
    }

    // 상태 업데이트
    function updateState(newState) {
        for (var key in newState) {
            if (state.hasOwnProperty(key)) {
                state[key] = newState[key];
            }
        }
        updateUI();
    }

    // UI 업데이트
    function updateUI() {
        const potEl = document.getElementById('pot-amount');
        if (potEl) {
            potEl.textContent = '₩' + state.pot.toLocaleString();
        }

        const myChipsEl = document.getElementById('my-chips');
        if (myChipsEl) {
            myChipsEl.textContent = '₩' + state.myChips.toLocaleString();
        }
    }

    // 게임 결과 기록
    function recordGameResult(result) {
        console.log('[Game] 게임 결과:', result);

        if (window.Achievements && typeof Achievements.recordGame === 'function') {
            Achievements.recordGame(result);
        }

        if (window.HandHistory && typeof HandHistory.recordHand === 'function') {
            HandHistory.recordHand(result);
        }
    }

    // Public API


    // 로컬 게임 시작
    function startLocalGame(roomId, roomName) {
        console.log('[Game] 로컬 게임 시작:', roomId, roomName);

        state.roomId = roomId || 'local_' + Date.now();
        state.roomName = roomName || '로컬 게임';
        state.players = [
            { id: 'player', name: Storage.get('userName', 'Player'), chips: state.myChips, isReady: true, isLocal: true },
            { id: 'ai1', name: 'AI 민수', chips: 10000, isReady: true, isAI: true },
            { id: 'ai2', name: 'AI 철수', chips: 10000, isReady: true, isAI: true },
            { id: 'ai3', name: 'AI 영희', chips: 10000, isReady: true, isAI: true }
        ];
        state.myIndex = 0;
        state.gamePhase = 'betting';
        state.pot = 0;
        state.currentBet = 1000; // 앤티

        // 게임 화면으로 전환
        showGameScreen();

        // 게임 시작
        setTimeout(() => {
            startNewRound();
        }, 500);
    }

    // 새 라운드 시작
    function startNewRound() {
        console.log('[Game] 새 라운드 시작');

        // 덱 생성 및 섞기
        state.deck = createDeck();
        shuffleDeck(state.deck);

        // 카드 배분 (4장씩)
        state.myCards = [];
        for (let i = 0; i < 4; i++) {
            state.myCards.push(state.deck.pop());
        }

        // UI 업데이트
        if (typeof Renderer !== 'undefined') {
            Renderer.renderCards(state.myCards);
        }

        // 내 턴 설정
        state.isMyTurn = true;
        state.canCheck = true;
        enableBettingButtons();

        console.log('[Game] 카드 배분 완료, 내 턴');
    }

    // 덱 생성
    function createDeck() {
        const suits = ['spades', 'hearts', 'diamonds', 'clubs'];
        const ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
        const deck = [];

        for (const suit of suits) {
            for (let i = 0; i < ranks.length; i++) {
                deck.push({
                    suit: suit,
                    rank: ranks[i],
                    value: i + 1
                });
            }
        }
        return deck;
    }

    // 덱 섞기
    function shuffleDeck(deck) {
        for (let i = deck.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [deck[i], deck[j]] = [deck[j], deck[i]];
        }
    }

    // 베팅 버튼 활성화
    function enableBettingButtons() {
        const buttons = ['btn-fold', 'btn-call', 'btn-raise', 'btn-exchange'];
        buttons.forEach(id => {
            const btn = document.getElementById(id);
            if (btn) btn.disabled = false;
        });
    }


    return {
        init: init,
        startLocalGame: startLocalGame,
        enterRoom: enterRoom,
        leaveRoom: leaveRoom,
        doFold: doFold,
        doCall: doCall,
        doHalf: doHalf,
        doRaise: doRaise,
        doAllIn: doAllIn,
        doExchange: doExchange,
        enableBettingButtons: enableBettingButtons,
        disableBettingButtons: disableBettingButtons,
        enableExchangeButton: enableExchangeButton,
        disableExchangeButton: disableExchangeButton,
        updateState: updateState,
        recordGameResult: recordGameResult,
        getState: function() { return Object.assign({}, state); }
    };
})();

// 전역 등록
window.Game = Game;
