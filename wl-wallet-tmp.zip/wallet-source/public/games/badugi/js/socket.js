// client/js/socket.js
// Socket.IO 클라이언트 연결 관리 - Wallet Server Version

const SocketManager = (function() {
    let socket = null;
    let isConnected = false;
    let reconnectAttempts = 0;
    const MAX_RECONNECT_ATTEMPTS = 5;

    // Wallet 서버 URL - 동일 오리진 사용
    const SERVER_URL = window.location.origin;

    // 쿠키 값을 읽는 헬퍼 함수
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }

    // 사용자 정보 가져오기 (쿠키 기반 인증)
    async function getUserId() {
        // 1. 쿠키에서 userId 확인
        const userIdFromCookie = getCookie('userId');
        if (userIdFromCookie) {
            return userIdFromCookie;
        }

        // 2. API로 현재 사용자 정보 가져오기
        try {
            const response = await fetch('/api/auth/me', {
                method: 'GET',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (response.ok) {
                const data = await response.json();
                if (data.ok && data.data && data.data.id) {
                    // 사용자 정보를 localStorage에 백업
                    localStorage.setItem('userId', data.data.id);
                    localStorage.setItem('userName', data.data.username || 'Player');
                    return data.data.id;
                }
            }
        } catch (err) {
            console.error('[Socket] Failed to fetch user info:', err);
        }

        // 3. 인증 실패 시 localStorage 확인 (백업)
        const userIdFromStorage = localStorage.getItem('userId');
        if (userIdFromStorage) {
            return userIdFromStorage;
        }

        // 4. 최후의 수단: 게스트 사용자
        return 'guest_' + Math.random().toString(36).substr(2, 9);
    }

    async function getUserName() {
        // 1. 입력 필드 값 확인
        const nameInput = document.getElementById('player-name');
        if (nameInput && nameInput.value) {
            return nameInput.value;
        }

        // 2. localStorage 확인
        const storedName = localStorage.getItem('userName');
        if (storedName) {
            return storedName;
        }

        // 3. API로 사용자 정보 가져오기
        try {
            const response = await fetch('/api/auth/me', {
                method: 'GET',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (response.ok) {
                const data = await response.json();
                if (data.ok && data.data && data.data.username) {
                    localStorage.setItem('userName', data.data.username);
                    return data.data.username;
                }
            }
        } catch (err) {
            console.error('[Socket] Failed to fetch username:', err);
        }

        return 'Player';
    }

    // 초기화
    async function init() {
        if (socket) {
            console.warn('[Socket] 이미 초기화됨');
            return;
        }

        // 로컬 모드에서는 소켓 연결 시도하지 않음
        const mode = window.currentGameMode ? window.currentGameMode() : 'local';
        if (mode === 'local') {
            console.log('[Socket] 로컬 모드 - 소켓 연결 건너뜀');
            updateConnectionStatus(false);
            return null;
        }

        console.log('[Socket] 초기화 시작...', SERVER_URL);

        // 비동기로 사용자 정보 가져오기
        const userId = await getUserId();
        const userName = await getUserName();

        console.log('[Socket] 사용자 정보:', { userId, userName });

        return new Promise((resolve, reject) => {
            try {
                socket = io(SERVER_URL, {
                    path: '/socket.io/',
                    transports: ['websocket', 'polling'],
                    reconnection: true,
                    reconnectionDelay: 1000,
                    reconnectionAttempts: MAX_RECONNECT_ATTEMPTS,
                    query: {
                        userId: userId,
                        userName: userName
                    }
                });

                setupSocketListeners();

                socket.on('connect', () => {
                    console.log('[Socket] 연결 성공');
                    isConnected = true;
                    reconnectAttempts = 0;
                    updateConnectionStatus(true);
                    resolve(socket);
                });

                socket.on('connect_error', (error) => {
                    console.warn('[Socket] 연결 실패 (서버 미실행?):', error.message);
                    isConnected = false;
                    updateConnectionStatus(false);
                    // 에러를 reject하지 않고 조용히 처리
                    resolve(null);
                });

            } catch (error) {
                console.error('[Socket] 초기화 실패:', error);
                updateConnectionStatus(false);
                resolve(null);
            }
        });
    }

    // 소켓 이벤트 리스너 설정
    function setupSocketListeners() {
        if (!socket) return;

        // 연결 상태 변경
        socket.on('disconnect', (reason) => {
            console.log('[Socket] 연결 해제:', reason);
            isConnected = false;
            updateConnectionStatus(false);

            if (reason === 'io server disconnect') {
                UI.showToast('서버와 연결이 끊어졌습니다.', 'error');
            }
        });

        socket.on('reconnect', (attemptNumber) => {
            console.log(`[Socket] 재연결 성공 (시도 ${attemptNumber})`);
            isConnected = true;
            updateConnectionStatus(true);
            UI.showToast('서버에 재연결되었습니다.', 'success');
        });

        socket.on('reconnect_attempt', (attemptNumber) => {
            console.log(`[Socket] 재연결 시도 ${attemptNumber}/${MAX_RECONNECT_ATTEMPTS}`);
        });

        socket.on('reconnect_failed', () => {
            console.error('[Socket] 재연결 실패');
            isConnected = false;
            updateConnectionStatus(false);
            UI.showToast('서버 재연결에 실패했습니다.', 'error');
        });

        // 에러 처리
        socket.on('error', (error) => {
            console.error('[Socket] 에러:', error);
        });

        // 로비 이벤트 - 다양한 이벤트명 지원
        socket.on('room_list', (data) => {
            console.log('[Socket] 방 목록 수신:', data);
            Renderer.renderRoomList(data.rooms || data);
        });

        socket.on('roomsList', (data) => {
            console.log('[Socket] roomsList 수신:', data);
            Renderer.renderRoomList(data);
        });

        socket.on('room_update', (roomInfo) => {
            console.log('[Socket] 방 업데이트:', roomInfo);
            Renderer.updateRoomInfo(roomInfo);
        });

        // 게임 상태 업데이트
        socket.on('game_state', (gameState) => {
            console.log('[Socket] 게임 상태 수신:', gameState);
            NetworkGame.onGameStateUpdate(gameState);
        });

        socket.on('gameState', (gameState) => {
            console.log('[Socket] gameState 수신:', gameState);
            NetworkGame.onGameStateUpdate(gameState);
        });

        // 내 턴 알림
        socket.on('your_turn', (data) => {
            console.log('[Socket] 내 턴:', data);
            NetworkGame.onYourTurn(data);
        });

        // 플레이어 액션
        socket.on('player_action', (data) => {
            console.log('[Socket] 플레이어 액션:', data);
            Renderer.showPlayerAction(data);
        });

        // 카드 배분
        socket.on('cards_dealt', (data) => {
            console.log('[Socket] 카드 배분:', data);
            NetworkGame.onCardsDealt(data);
        });

        // 카드 교환 완료
        socket.on('cards_exchanged', (data) => {
            console.log('[Socket] 카드 교환 완료:', data);
            NetworkGame.onCardsExchanged(data);
        });

        // 교환 정보 브로드캐스트
        socket.on('player_exchange', (data) => {
            console.log('[Socket] 플레이어 교환:', data);
            Renderer.showPlayerExchange(data);
        });

        // 타이머 업데이트
        socket.on('timer_update', (data) => {
            Renderer.updateTimer(data.remaining);
        });

        // 쇼다운 결과
        socket.on('showdown_result', (data) => {
            console.log('[Socket] 쇼다운 결과:', data);
            Renderer.showShowdownResult(data);
        });

        // 라운드 종료
        socket.on('round_end', (data) => {
            console.log('[Socket] 라운드 종료:', data);
            NetworkGame.onRoundEnd(data);
        });

        socket.on('roundEnd', (data) => {
            console.log('[Socket] roundEnd 수신:', data);
            NetworkGame.onRoundEnd(data);
        });

        // 게임 로그
        socket.on('game_log', (data) => {
            Renderer.addLog(data.message, data.timestamp);
        });

        // 채팅
        socket.on('chat_broadcast', (data) => {
            Renderer.addChatMessage(data);
        });

        socket.on('chatMessage', (data) => {
            Renderer.addChatMessage(data);
        });

        // 빠른 채팅
        socket.on('quick_chat_broadcast', (data) => {
            Renderer.showQuickChat(data);
        });

        // 에러
        socket.on('error', (data) => {
            console.error('[Socket] 서버 에러:', data);
            UI.showToast(data.message || '오류가 발생했습니다.', 'error');
        });

        // 입장 성공
        socket.on('join_room_success', (data) => {
            console.log('[Socket] 방 입장 성공:', data);
            NetworkGame.onJoinRoomSuccess(data);
        });

        socket.on('roomJoined', (data) => {
            console.log('[Socket] roomJoined 수신:', data);
            NetworkGame.onJoinRoomSuccess(data);
        });

        // 퇴장 성공
        socket.on('leave_room_success', (data) => {
            console.log('[Socket] 방 퇴장 성공:', data);
            NetworkGame.onLeaveRoomSuccess(data);
        });

        // 준비 상태 변경
        socket.on('ready_success', (data) => {
            console.log('[Socket] 준비 상태 변경:', data);
            NetworkGame.onReadySuccess(data);
        });

        // 플레이어 입장/퇴장
        socket.on('playerJoined', (data) => {
            console.log('[Socket] 플레이어 입장:', data);
            if (typeof Renderer !== 'undefined' && Renderer.addLog) {
                Renderer.addLog(`${data.userName}님이 입장했습니다.`);
            }
        });

        socket.on('playerLeft', (data) => {
            console.log('[Socket] 플레이어 퇴장:', data);
            if (typeof Renderer !== 'undefined' && Renderer.addLog) {
                Renderer.addLog(`${data.userName}님이 퇴장했습니다.`);
            }
        });

        // 게임 시작
        socket.on('gameStarted', (data) => {
            console.log('[Socket] 게임 시작:', data);
            if (typeof UI !== 'undefined' && UI.showToast) {
                UI.showToast('게임이 시작되었습니다!', 'success');
            }
        });
    }

    // 연결 상태 UI 업데이트
    function updateConnectionStatus(connected) {
        const indicator = Utils.$('#connection-status');
        if (indicator) {
            if (connected) {
                indicator.classList.remove('disconnected');
                indicator.classList.add('connected');
                indicator.title = '연결됨';
            } else {
                indicator.classList.remove('connected');
                indicator.classList.add('disconnected');
                indicator.title = '연결 안됨';
            }
        }
    }

    // 로비 입장
    function joinLobby(playerName, chips) {
        if (!socket || !isConnected) {
            UI.showToast('서버에 연결되지 않았습니다.', 'error');
            return;
        }

        console.log('[Socket] 로비 입장 요청:', { playerName, chips });
        socket.emit('join_lobby', { name: playerName, chips: chips });
    }

    // 방 목록 요청
    function getRooms() {
        if (!socket || !isConnected) return;

        console.log('[Socket] 방 목록 요청');
        socket.emit('get_rooms');
        socket.emit('getRooms', 'badugi'); // 다중 이벤트명 지원
    }

    // 방 입장
    function joinRoom(roomId) {
        if (!socket || !isConnected) {
            UI.showToast('서버에 연결되지 않았습니다.', 'error');
            return;
        }

        console.log('[Socket] 방 입장 요청:', roomId);
        socket.emit('join_room', { roomId });
        socket.emit('joinRoom', roomId); // 다중 이벤트명 지원
    }

    // 방 퇴장
    function leaveRoom() {
        if (!socket) return;

        console.log('[Socket] 방 퇴장 요청');
        socket.emit('leave_room');
        socket.emit('leaveRoom');
    }

    // 준비
    function ready() {
        if (!socket || !isConnected) return;

        console.log('[Socket] 준비 요청');
        socket.emit('ready');
        socket.emit('toggleReady');
    }

    // 준비 취소
    function unready() {
        if (!socket || !isConnected) return;

        console.log('[Socket] 준비 취소 요청');
        socket.emit('unready');
        socket.emit('toggleReady');
    }

    // 베팅 액션
    function sendBetAction(action, amount) {
        if (!socket || !isConnected) {
            UI.showToast('서버에 연결되지 않았습니다.', 'error');
            return;
        }

        console.log('[Socket] 베팅 액션:', { action, amount });
        socket.emit('bet_action', { action, amount });
        socket.emit('pokerAction', { action, amount });
    }

    // 카드 교환
    function sendExchange(cardIndices) {
        if (!socket || !isConnected) {
            UI.showToast('서버에 연결되지 않았습니다.', 'error');
            return;
        }

        console.log('[Socket] 카드 교환:', cardIndices);
        socket.emit('exchange_cards', { indices: cardIndices });
        socket.emit('exchangeCards', cardIndices);
    }

    // 채팅 메시지
    function sendChat(message) {
        if (!socket || !isConnected) return;

        console.log('[Socket] 채팅:', message);
        socket.emit('chat_message', { message });
        socket.emit('chatMessage', message);
    }

    // 빠른 채팅
    function sendQuickChat(index) {
        if (!socket || !isConnected) return;

        console.log('[Socket] 빠른 채팅:', index);
        socket.emit('quick_chat', { index });
    }

    // 연결 해제
    function disconnect() {
        if (socket) {
            console.log('[Socket] 연결 해제');
            socket.disconnect();
            socket = null;
            isConnected = false;
            updateConnectionStatus(false);
        }
    }

    // 연결 상태 확인
    function checkConnection() {
        return isConnected;
    }

    

    // 방 생성
    function createRoom(gameType, maxPlayers, minBet) {
        if (!socket || !isConnected) {
            UI.showToast('서버에 연결되지 않았습니다.', 'error');
            return;
        }

        const roomId = `${gameType}-${Date.now()}`;
        console.log('[Socket] 방 생성 요청:', { roomId, gameType, maxPlayers, minBet });

        socket.emit('createRoom', {
            gameType: gameType,
            maxPlayers: maxPlayers || 4,
            minBet: minBet || 1000
        });
    }

    // Public API
    return {
        init,
        disconnect,
        checkConnection,
        joinLobby,
        getRooms,
        joinRoom,
        leaveRoom,
        ready,
        unready,
        sendBetAction,
        sendExchange,
        sendChat,
        sendQuickChat,
        createRoom
    };
})();

// 전역 노출
window.SocketManager = SocketManager;
