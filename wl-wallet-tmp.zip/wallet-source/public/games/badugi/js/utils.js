/* ==========================================
   유틸리티 함수
   ========================================== */

const Utils = {

  /* ==========================================
     숫자/금액 포맷팅
     ========================================== */

  // 칩 금액 포맷팅
  formatChips(amount) {
    if (amount >= 100000000) {
      return `₩${(amount / 100000000).toFixed(1)}억`;
    }
    if (amount >= 10000) {
      return `₩${Math.floor(amount / 10000).toLocaleString()}만`;
    }
    return `₩${amount.toLocaleString()}`;
  },

  // 숫자에 콤마 추가
  formatNumber(num) {
    return num.toLocaleString();
  },

  // 시간 포맷팅 (mm:ss)
  formatTime(ms) {
    const seconds = Math.floor(ms / 1000);
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  },

  // 초 포맷팅
  formatSeconds(seconds) {
    return `${seconds}초`;
  },

  /* ==========================================
     배열/랜덤 유틸
     ========================================== */

  // 배열 셔플 (Fisher-Yates)
  shuffle(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  },

  // 가중치 기반 랜덤 선택
  weightedRandom(items, weights) {
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    let random = Math.random() * totalWeight;

    for (let i = 0; i < items.length; i++) {
      random -= weights[i];
      if (random <= 0) {
        return items[i];
      }
    }
    return items[items.length - 1];
  },

  // 범위 내 랜덤 정수
  randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  },

  /* ==========================================
     DOM 유틸
     ========================================== */

  // 요소 가져오기
  $(selector) {
    return document.querySelector(selector);
  },

  // 여러 요소 가져오기
  $$(selector) {
    return document.querySelectorAll(selector);
  },

  // 요소 생성
  createElement(tag, className = '', innerHTML = '') {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (innerHTML) el.innerHTML = innerHTML;
    return el;
  },

  // 클래스 토글
  toggleClass(element, className, force) {
    if (typeof element === 'string') {
      element = this.$(element);
    }
    if (element) {
      element.classList.toggle(className, force);
    }
  },

  // 요소 표시/숨김
  show(element) {
    if (typeof element === 'string') {
      element = this.$(element);
    }
    if (element) {
      element.classList.remove('hidden');
    }
  },

  hide(element) {
    if (typeof element === 'string') {
      element = this.$(element);
    }
    if (element) {
      element.classList.add('hidden');
    }
  },

  /* ==========================================
     딜레이/타이머
     ========================================== */

  // Promise 기반 딜레이
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  // 디바운스
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  /* ==========================================
     카드 관련
     ========================================== */

  // 카드가 빨간색인지 확인
  isRedSuit(suit) {
    return suit === '♥' || suit === '♦';
  },

  // 카드 문자열 생성
  cardToString(card) {
    return `${card.suit}${card.rank}`;
  },

  /* ==========================================
     검증
     ========================================== */

  // 비어있는지 확인
  isEmpty(value) {
    if (value === null || value === undefined) return true;
    if (Array.isArray(value)) return value.length === 0;
    if (typeof value === 'object') return Object.keys(value).length === 0;
    if (typeof value === 'string') return value.trim() === '';
    return false;
  },

  // 숫자인지 확인
  isNumber(value) {
    return typeof value === 'number' && !isNaN(value);
  }
};
