/* ==========================================
   전역 상태 관리
   ========================================== */

const State = {
  // 플레이어 정보
  myChips: INITIAL_CHIPS,
  playerName: 'Player',

  // 충전 관련
  lastFreeCharge: 0,
  eventUsed: false,

  // 현재 방 정보
  currentRoom: null,

  // 게임 상태
  gameState: GAME_STATES.WAITING,

  // 플레이어들
  players: [],

  // 덱
  deck: [],

  // 팟
  pot: 0,

  // 현재 베팅 금액
  currentBet: 0,

  // 딜러 인덱스
  dealerIndex: 0,

  // 현재 플레이어 인덱스
  currentPlayerIndex: 0,

  // 라운드 인덱스 (베팅/교환)
  roundIndex: 0,

  // 선택된 카드 인덱스
  selectedCards: new Set(),

  // 타이머 관련
  timerInterval: null,
  timerRemaining: 0,
  missionTimerInterval: null,

  // 게임 로그
  gameLog: [],

  // 게임 설정 (방에서 가져옴)
  ante: 100,
  baseBet: 200,
  botChips: 10000,

  // 게임 시작 시 칩 (승패 계산용)
  startingChips: 0,

  // 마지막 레이저 (폴드 유발 통계용)
  lastRaiser: -1
};

/* ==========================================
   상태 초기화 함수들
   ========================================== */

// 게임 상태 초기화
function resetGameState() {
  State.gameState = GAME_STATES.WAITING;
  State.players = [];
  State.deck = [];
  State.pot = 0;
  State.currentBet = 0;
  State.currentPlayerIndex = 0;
  State.roundIndex = 0;
  State.selectedCards.clear();
  State.gameLog = [];
  clearTimer();
}

// 새 핸드 초기화
function resetForNewHand() {
  State.pot = 0;
  State.currentBet = 0;
  State.roundIndex = 0;
  State.selectedCards.clear();
  State.lastRaiser = -1;

  // 플레이어 상태 초기화
  State.players.forEach(player => {
    player.cards = [];
    player.folded = false;
    player.allIn = false;
    player.currentBet = 0;
    player.hasActed = false;
    player.lastAction = null;
  });
}

// 방 설정 적용
function applyRoomConfig(room) {
  State.currentRoom = room;
  State.ante = room.ante;
  State.baseBet = room.baseBet;
  State.botChips = room.botChips;
}

// 타이머 클리어
function clearTimer() {
  if (State.timerInterval) {
    clearInterval(State.timerInterval);
    State.timerInterval = null;
  }
  State.timerRemaining = 0;
}

// 미션 타이머 클리어
function clearMissionTimer() {
  if (State.missionTimerInterval) {
    clearInterval(State.missionTimerInterval);
    State.missionTimerInterval = null;
  }
}
