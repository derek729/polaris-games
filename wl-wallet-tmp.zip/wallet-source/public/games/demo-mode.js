// 공통 데모 모드 유틸리티
(function() {
    'use strict';
    
    // 데모 모드 체크
    const urlParams = new URLSearchParams(window.location.search);
    window.isDemoMode = urlParams.get('demo') === 'true' || localStorage.getItem('demoMode') === 'true';
    window.DEMO_BALANCE = 1000; // 데모 모드 초기 잔액 (10판 기준)
    
    // 데모 모드 토글
    window.toggleDemoMode = function() {
        window.isDemoMode = !window.isDemoMode;
        localStorage.setItem('demoMode', window.isDemoMode.toString());
        updateDemoIndicator();
        
        // 게임별 리로드 함수 호출
        if (window.reloadGameForDemo) {
            window.reloadGameForDemo();
        } else {
            location.reload();
        }
    };
    
    // 데모 모드 표시 업데이트
    window.updateDemoIndicator = function() {
        const btn = document.getElementById('demo-toggle');
        const label = document.getElementById('demo-label');
        if (!btn || !label) return;
        
        if (window.isDemoMode) {
            btn.style.background = 'linear-gradient(135deg, #ffeb3b, #ffc107)';
            btn.style.borderColor = '#ffeb3b';
            btn.style.color = '#000';
            btn.style.boxShadow = '0 0 15px rgba(255, 235, 59, 0.5)';
            label.innerText = 'DEMO ON';
        } else {
            btn.style.background = 'rgba(255,255,255,0.1)';
            btn.style.borderColor = 'rgba(255,255,255,0.3)';
            btn.style.color = '#fff';
            btn.style.boxShadow = 'none';
            label.innerText = 'DEMO';
        }
    };
    
    // 데모 모드 버튼 HTML 생성
    window.createDemoButton = function() {
        return `
            <button id="demo-toggle" onclick="toggleDemoMode()" 
                class="px-3 py-1 rounded text-xs font-bold transition-colors" 
                style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.3); color: #fff; cursor: pointer;">
                <span id="demo-label">DEMO</span>
            </button>
        `;
    };
})();

