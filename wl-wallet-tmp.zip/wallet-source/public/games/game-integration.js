/**
 * 게임 결과 처리 공통 모듈
 *
 * 모든 게임에서 게임 결과를 서버에 전송하여
 * 잭팟/재단/노드 풀에 수익을 분배합니다.
 *
 * 사용법:
 * 1. <script src="game-integration.js"></script> 추가
 * 2. 게임 종료 시 reportGameResult(betAmount, winAmount) 호출
 */

(function(window) {
    'use strict';

    // API 기본 URL
    const API_BASE = window.location.origin;

    /**
     * 게임 결과 서버에 전송
     * @param {string} gameId - 게임 ID
     * @param {number} betAmount - 베팅 금액
     * @param {number} winAmount - 승리 금액
     * @param {string} playResult - 게임 결과 ('win', 'lose', 'tie', 'push')
     */
    async function reportGameResult(gameId, betAmount, winAmount, playResult) {
        // 데모 모드 체크
        const isDemo = localStorage.getItem('demoMode') === 'true' ||
                      new URLSearchParams(window.location.search).get('demo') === 'true';

        if (isDemo) {
            console.log('[Game Integration] Demo mode - skipping server report');
            return;
        }

        try {
            const response = await fetch(`${API_BASE}/api/game/result`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    gameId: gameId,
                    betAmount: betAmount,
                    winAmount: winAmount,
                    playResult: playResult || (winAmount > 0 ? 'win' : 'lose'),
                }),
            });

            if (response.ok) {
                const data = await response.json();
                console.log('[Game Integration] Result reported successfully:', data);
            } else {
                console.error('[Game Integration] Failed to report result:', response.status);
            }
        } catch (error) {
            console.error('[Game Integration] Error reporting result:', error);
        }
    }

    /**
     * 잭팟 금액 로드
     * @returns {Promise<number>} 잭팟 금액
     */
    async function loadJackpot() {
        try {
            const response = await fetch(`${API_BASE}/api/jackpot`);
            if (response.ok) {
                const data = await response.json();
                if (data.ok && data.data.globalJackpot) {
                    return data.data.globalJackpot.currentAmount;
                }
            }
            return null;
        } catch (error) {
            console.error('[Game Integration] Error loading jackpot:', error);
            return null;
        }
    }

    // 전역 함수 등록
    window.GameIntegration = {
        reportGameResult: reportGameResult,
        loadJackpot: loadJackpot,
    };

    console.log('[Game Integration] Module loaded');
})(window);
