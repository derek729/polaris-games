/**
 * Casino Sound Manager
 * Web Audio API를 사용하여 카지노 사운드 효과 생성
 * 저작권 없는 합성 사운드로 빠른 로딩
 */

class CasinoSoundManager {
  constructor() {
    this.enabled = true;
    this.volume = 0.3;
    this.audioContext = null;
    this.sounds = {};
    this.isInitialized = false;

    // 로컬 스토리지에서 설정 불러오기
    const savedEnabled = localStorage.getItem('casinoSoundEnabled');
    if (savedEnabled !== null) {
      this.enabled = savedEnabled === 'true';
    }

    const savedVolume = localStorage.getItem('casinoSoundVolume');
    if (savedVolume !== null) {
      this.volume = parseFloat(savedVolume);
    }
  }

  // AudioContext 초기화 (사용자 제스처 후)
  async init() {
    if (this.isInitialized) return;

    try {
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
      this.isInitialized = true;
    } catch (e) {
      console.warn('Web Audio API not supported:', e);
    }
  }

  // 기본 오실레이터 생성
  createOscillator(type, frequency, startTime, duration, volume = 1) {
    if (!this.enabled || !this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime + startTime);

    // 볼륨 엔벨로프 (공격 → 붕괴)
    const attackTime = 0.01;
    const decayTime = duration * 0.3;
    const sustainLevel = volume * 0.3;

    gainNode.gain.setValueAtTime(0, this.audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(volume * this.volume, this.audioContext.currentTime + startTime + attackTime);
    gainNode.gain.exponentialRampToValueAtTime(sustainLevel, this.audioContext.currentTime + startTime + attackTime + decayTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + startTime + duration);

    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    oscillator.start(this.audioContext.currentTime + startTime);
    oscillator.stop(this.audioContext.currentTime + startTime + duration);

    return { oscillator, gainNode };
  }

  // 노이즈 생성 (카드 소리용)
  createNoise(duration, volume = 1) {
    if (!this.enabled || !this.audioContext) return;

    const bufferSize = this.audioContext.sampleRate * duration;
    const buffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.audioContext.createBufferSource();
    noise.buffer = buffer;

    const gainNode = this.audioContext.createGain();
    const filter = this.audioContext.createBiquadFilter();

    filter.type = 'highpass';
    filter.frequency.setValueAtTime(1000, this.audioContext.currentTime);

    gainNode.gain.setValueAtTime(volume * this.volume, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration);

    noise.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    noise.start();
    noise.stop(this.audioContext.currentTime + duration);
  }

  // 칩 소리 (금속성 덜컹 소리)
  playChipSound(pitch = 1) {
    this.init();
    if (!this.enabled) return;

    const baseFreq = 800 * pitch;
    const duration = 0.15;

    // 금속성 소리 (여러 주파수)
    this.createOscillator('sine', baseFreq, 0, duration, 0.6);
    this.createOscillator('triangle', baseFreq * 2, 0.01, duration * 0.8, 0.4);
    this.createOscillator('sine', baseFreq * 3, 0.02, duration * 0.6, 0.2);

    // 고조파 추가 (금속 느낌)
    this.createOscillator('sine', baseFreq * 4.5, 0.03, duration * 0.4, 0.15);
  }

  // 카드 소리 (카드 넘기는 소리)
  playCardSound() {
    this.init();
    if (!this.enabled) return;

    // 짧은 스와이프 소리
    this.createNoise(0.05, 0.3);
    this.createOscillator('sawtooth', 150, 0, 0.08, 0.2);
  }

  // 카드 뒤집는 소리
  playCardFlipSound() {
    this.init();
    if (!this.enabled) return;

    this.createNoise(0.1, 0.4);
    this.createOscillator('triangle', 200, 0.02, 0.12, 0.3);
  }

  // 딜링 소리 (여러 카드)
  playDealSound() {
    this.init();
    if (!this.enabled) return;

    // 3번 연속 작은 카드 소리
    for (let i = 0; i < 3; i++) {
      setTimeout(() => this.playCardFlipSound(), i * 150);
    }
  }

  // 베팅 소리 (칩 놓기)
  async playPlaceBetSound() {
    this.init();
    if (!this.enabled) return;

    this.playChipSound(1.2);
  }

  // 룰렛 소리 (공 굴러가는 소리)
  playRouletteSpinSound() {
    this.init();
    if (!this.enabled) return;

    const duration = 0.3;
    // 떨리는 소리
    this.createOscillator('sawtooth', 150, 0, duration, 0.25);
    this.createOscillator('triangle', 100, 0.05, duration * 0.8, 0.2);
    this.createNoise(duration * 0.5, 0.15);
  }

  // 룰렛 멈춤 소리
  playRouletteStopSound() {
    this.init();
    if (!this.enabled) return;

    this.createOscillator('sine', 300, 0, 0.2, 0.5);
    this.createNoise(0.15, 0.2);
  }

  // 승리 사운드 (동전 떨어지는 소리 + 멜로디)
  playWinSound() {
    this.init();
    if (!this.enabled) return;

    // 승리 멜로디 (상승 음계)
    const melody = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    melody.forEach((freq, i) => {
      this.createOscillator('sine', freq, i * 0.08, 0.3, 0.4);
    });

    // 동전 떨어지는 소리
    for (let i = 0; i < 5; i++) {
      setTimeout(() => this.playChipSound(0.8 + Math.random() * 0.5), i * 100);
    }
  }

  // 패배 사운드
  playLoseSound() {
    this.init();
    if (!this.enabled) return;

    // 하강 음계
    const melody = [392, 349.23, 329.63, 293.66]; // G4, F4, E4, D4
    melody.forEach((freq, i) => {
      this.createOscillator('sine', freq, i * 0.1, 0.3, 0.3);
    });
  }

  // 배당금 소리 (대형 승리)
  async playPayoutSound() {
    this.init();
    if (!this.enabled) return;

    // 긴 승리 멜로디
    const melody = [
      523.25, 659.25, 783.99, 1046.50,
      783.99, 1046.50, 1318.51, 1568
    ];

    melody.forEach((freq, i) => {
      setTimeout(() => {
        this.createOscillator('sine', freq, 0, 0.4, 0.35);
      }, i * 80);
    });

    // 다수 동전 소리
    for (let i = 0; i < 15; i++) {
      setTimeout(() => this.playChipSound(0.6 + Math.random() * 1.2), i * 70);
    }
  }

  // 버튼 클릭 소리
  playButtonClickSound() {
    this.init();
    if (!this.enabled) return;

    this.createOscillator('sine', 600, 0, 0.05, 0.3);
  }

  // 슬롯머신 회전 시작 소리
  playSlotStartSound() {
    this.init();
    if (!this.enabled) return;

    for (let i = 0; i < 3; i++) {
      setTimeout(() => {
        this.createOscillator('sawtooth', 200 + i * 100, 0, 0.1, 0.25);
      }, i * 50);
    }
  }

  // 슬롯머신 멈춤 소리
  playSlotStopSound() {
    this.init();
    if (!this.enabled) return;

    this.createOscillator('triangle', 400, 0, 0.15, 0.4);
    this.createOscillator('sine', 600, 0.05, 0.1, 0.3);
  }

  // 음소거 토글
  toggleMute() {
    this.enabled = !this.enabled;
    localStorage.setItem('casinoSoundEnabled', this.enabled.toString());
    return this.enabled;
  }

  // 볼륨 설정
  setVolume(volume) {
    this.volume = Math.max(0, Math.min(1, volume));
    localStorage.setItem('casinoSoundVolume', this.volume.toString());
  }

  // 상태 확인
  isEnabled() {
    return this.enabled;
  }

  getVolume() {
    return this.volume;
  }
}

// 전역 인스턴스 생성
window.casinoSounds = new CasinoSoundManager();
