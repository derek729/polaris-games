// Service Worker를 완전히 비활성화하여 개발 환경 문제 방지
// 모든 요청을 네트워크로 직접 전달하여 캐싱 문제 해결

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  const isSameOrigin = url.origin === self.location.origin;
  
  // 모든 요청을 네트워크로 직접 전달
  const fetchOptions = {
    redirect: 'follow'
  };
  
  if (isSameOrigin) {
    fetchOptions.credentials = 'include';
  }
  
  event.respondWith(
    fetch(event.request, fetchOptions).catch(() => {
      return new Response('Service temporarily unavailable', { status: 503 });
    })
  );
});

// 설치 시 즉시 활성화
self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting());
});

// 활성화 시 모든 캐시 삭제
self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      self.clients.claim(),
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => caches.delete(cacheName))
        );
      })
    ])
  );
});