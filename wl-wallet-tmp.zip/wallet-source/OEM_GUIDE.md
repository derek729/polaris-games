# OEM 템플릿 가이드

## 📋 프로젝트 정보

- **상호명**: UOC
- **코인 심볼**: UPC
- **총 발행량**: 10,000,000,000개
- **프로젝트명**: upcwallet

## 🚀 시작하기

### 1. 의존성 설치

```bash
npm install
```

### 2. 환경 변수 설정

`.env` 파일을 생성하고 다음 변수들을 설정하세요:

```env
DATABASE_URL="postgresql://user:password@localhost:5432/dbname"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://localhost:3009"
```

### 3. 데이터베이스 설정

```bash
npx prisma db push
```

### 4. 개발 서버 실행

```bash
npm run dev
```

## 🎨 커스터마이징

### 로고 변경

`public/icons/logo.png` 파일을 교체하세요.

### 브랜딩 텍스트 변경

다음 파일들에서 브랜딩 텍스트를 수정할 수 있습니다:

- `src/components/CompanyBrand.tsx`
- `src/app/_components/WalletHeader.tsx`
- `src/app/_components/LandingPage.tsx`

### 색상 테마 변경

`tailwind.config.js` 또는 CSS 변수를 수정하세요.

## 📝 주요 기능

- ✅ 사용자 인증 및 회원가입
- ✅ 지갑 관리 (NKB 코인)
- ✅ 코인 전송 및 거래 내역
- ✅ 게임 통합
- ✅ 관리자 대시보드

## 🔧 추가 설정

### 슈퍼 관리자 생성

```bash
npm run create-super-admin
```

### 게임 주식 초기화

```bash
npm run init-game-shares
```

### 투자 상품 초기화

```bash
npm run init-investment-products
```

## 📞 지원

문제가 발생하면 OEM 제공업체에 문의하세요.

---
생성일: 2025. 12. 19. 오전 9:37:43
