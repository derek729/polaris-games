# APK 빌드 가이드

## 🚀 APK 빌드 단계별 가이드

### 1단계: 터미널에서 웹 프로젝트 빌드

**Windows PowerShell 또는 CMD를 직접 열어서 실행하세요:**

```powershell
cd D:\OEM\new\upcwallet
npm run build
```

또는 Prisma를 먼저 생성한 후 빌드:

```powershell
cd D:\OEM\new\upcwallet
npx prisma generate
npm run build
```

### 2단계: Capacitor 동기화

빌드가 완료되면:

```powershell
npx cap sync
```

### 3단계: Android Studio에서 APK 빌드

#### 방법 A: 디버그 APK (빠르고 간단)

1. Android Studio에서 프로젝트 열기
2. 상단 메뉴: `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
3. 빌드 완료 후 `locate` 클릭
4. APK 위치: `android/app/build/outputs/apk/debug/app-debug.apk`

#### 방법 B: Gradle 명령어로 빌드 (터미널)

Android Studio의 터미널에서:

```bash
cd android
.\gradlew assembleDebug
```

또는 릴리즈 버전:

```bash
.\gradlew assembleRelease
```

APK 위치:
- 디버그: `android/app/build/outputs/apk/debug/app-debug.apk`
- 릴리즈: `android/app/build/outputs/apk/release/app-release.apk`

### 4단계: APK 파일 확인

빌드된 APK 파일을 찾아서:
- `app-debug.apk` 또는 `app-release.apk` 파일 확인
- 파일 이름을 `upc.apk`로 변경 가능

## ⚙️ 설정 확인

### Capacitor 설정 (`capacitor.config.ts`)

**프로덕션 배포용:**
```typescript
server: {
  androidScheme: 'https',
  url: 'https://your-deployed-domain.com',
  // cleartext: true 제거 (HTTPS 사용)
}
```

**로컬 테스트용:**
```typescript
server: {
  androidScheme: 'https',
  url: 'http://10.0.2.2:3009',
  cleartext: true
}
```

### 앱 정보 수정

**앱 이름 변경:**
- `capacitor.config.ts`의 `appName` 수정
- 또는 `android/app/src/main/res/values/strings.xml` 수정

**버전 정보:**
- `android/app/build.gradle`에서 `versionCode`와 `versionName` 수정

## 🔧 문제 해결

### TypeScript 오류가 있어도 빌드는 가능합니다
- Next.js는 런타임에서 타입 체크를 하지 않으므로 빌드가 진행됩니다
- 타입 오류는 개발 시에만 경고로 표시됩니다

### Gradle 동기화 오류
- Android Studio에서 `File` → `Sync Project with Gradle Files` 실행
- 또는 `Build` → `Clean Project` 후 다시 빌드

### 빌드 실패 시
1. `android` 폴더 삭제
2. `npx cap add android` 실행
3. `npx cap sync` 실행
4. Android Studio에서 다시 빌드

## 📝 빠른 참조

```powershell
# 1. 빌드
npm run build

# 2. 동기화
npx cap sync

# 3. Android Studio 열기
npm run open:android

# 4. Gradle로 직접 빌드 (선택사항)
cd android
.\gradlew assembleDebug
```

