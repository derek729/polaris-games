'use client';

import GameManagement from '@/components/admin/GameManagement';

export default function AdminGamesPage() {
  return (
    <div className="min-h-screen bg-[#101922]">
      <div className="container mx-auto px-4 py-8">
        <GameManagement />
      </div>
    </div>
  );
}