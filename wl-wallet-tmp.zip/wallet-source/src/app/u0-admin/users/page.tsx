'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import UpdatePasswordModal from '@/components/admin/UpdatePasswordModal';
import UpdateEmailModal from '@/components/admin/UpdateEmailModal';
import ChargeCoinModal from '@/components/admin/ChargeCoinModal';
import VerifyPasswordModal from '@/components/admin/VerifyPasswordModal';
import CreateLockupModal from '@/components/admin/CreateLockupModal';

interface User {
  id: string;
  username: string;
  email: string;
  walletAddress?: string;
  rank: number;
  totalInvestment: number;
  personalCoin: number;
  status: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';
  isActive: boolean;
  createdAt: string;
  updatedAt?: string;
  referrer?: { username: string; referralCode?: string };
  sponsor?: { username: string; referralCode?: string };
  referralCount?: number;
  stakingCount?: number;
  rewardCount?: number;
}

interface UsersResponse {
  ok: boolean;
  data?: {
    users: User[];
    pagination: {
      currentPage: number;
      totalPages: number;
      totalCount: number;
      limit: number;
      hasNext: boolean;
      hasPrev: boolean;
    };
  };
}

export default function AdminUsersPage() {
  const router = useRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalCount: 0,
    limit: 20,
    hasNext: false,
    hasPrev: false,
  });

  // 필터링 상태
  const [filters, setFilters] = useState({
    status: '',
    rank: '',
    search: '',
  });

  // 모달 상태
  const [updatePasswordModal, setUpdatePasswordModal] = useState<{
    isOpen: boolean;
    userId: string;
    username: string;
  }>({ isOpen: false, userId: '', username: '' });

  const [verifyPasswordModal, setVerifyPasswordModal] = useState<{
    isOpen: boolean;
    userId: string;
    username: string;
  }>({ isOpen: false, userId: '', username: '' });

  const [updateEmailModal, setUpdateEmailModal] = useState<{
    isOpen: boolean;
    userId: string;
    currentEmail: string | null;
  }>({ isOpen: false, userId: '', currentEmail: null });

  const [chargeCoinModal, setChargeCoinModal] = useState<{
    isOpen: boolean;
    userId: string;
    username: string;
    currentBalance: number;
    type: 'charge' | 'withdraw';
  }>({ isOpen: false, userId: '', username: '', currentBalance: 0, type: 'charge' });

  const [createLockupModal, setCreateLockupModal] = useState<{
    isOpen: boolean;
    userId: string;
    username: string;
  }>({ isOpen: false, userId: '', username: '' });

  const [batchAirdropModal, setBatchAirdropModal] = useState(false);

  // 사용자 목록 조회
  const fetchUsers = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams({
        page: pagination.currentPage.toString(),
        limit: pagination.limit.toString(),
        ...(filters.status && { status: filters.status }),
        ...(filters.rank && { rank: filters.rank }),
        ...(filters.search && { search: filters.search }),
      });

      const response = await fetch(`/api/admin/users?${params}`, {
        credentials: 'include',
      });

      const data: UsersResponse = await response.json();

      if (data.ok && data.data) {
        setUsers(data.data.users);
        setPagination(data.data.pagination);
      }
    } catch (error) {
      console.error('사용자 목록 조회 실패:', error);
    } finally {
      setIsLoading(false);
    }
  }, [pagination.currentPage, pagination.limit, filters]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const formatNumber = (num: number) => {
    return num.toLocaleString('ko-KR');
  };

  const formatCurrency = (amount: number | undefined | null) => {
    if (amount === undefined || amount === null) return '0 MSUO';
    return `${formatNumber(amount)} MSUO`;
  };

  const formatDate = (dateString: string | undefined | null) => {
    if (!dateString) return '-';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return '-';
      return date.toLocaleDateString('ko-KR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return '-';
    }
  };

  const getStatusBadge = (status: string, isActive: boolean) => {
    if (!isActive) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-500/20 text-gray-400 border border-gray-500/50">
          비활성
        </span>
      );
    }

    const statusConfig: Record<string, { label: string; className: string }> = {
      ACTIVE: { label: '활성', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      INACTIVE: { label: '비활성', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' },
      SUSPENDED: { label: '정지', className: 'bg-red-500/20 text-red-400 border border-red-500/50' },
    };

    const config = statusConfig[status] || statusConfig.ACTIVE;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    );
  };

  const getRankBadge = (rank: number) => {
    const rankConfig: Record<number, { label: string; className: string }> = {
      1: { label: '브론즈', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' },
      2: { label: '실버', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      3: { label: '골드', className: 'bg-blue-500/20 text-blue-400 border border-blue-500/50' },
      4: { label: '플래티넘', className: 'bg-purple-500/20 text-purple-400 border border-purple-500/50' },
      5: { label: '다이아몬드', className: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' },
    };

    const config = rankConfig[rank] || rankConfig[1];

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    );
  };

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination(prev => ({ ...prev, currentPage: newPage }));
    }
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPagination(prev => ({ ...prev, currentPage: 1 }));
  };

  if (isLoading && users.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">회원 관리</h1>
          <p className="text-gray-400 mt-1">
            전체 사용자 {formatNumber(pagination.totalCount)}명
          </p>
        </div>
      </div>

      {/* 검색 및 필터 */}
      <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-300 mb-2">검색</label>
            <input
              type="text"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              placeholder="사용자명, 이메일, 지갑주소 검색"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">상태</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="">전체</option>
              <option value="ACTIVE">활성</option>
              <option value="INACTIVE">비활성</option>
              <option value="SUSPENDED">정지</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">랭크</label>
            <select
              value={filters.rank}
              onChange={(e) => handleFilterChange('rank', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="">전체</option>
              <option value="1">브론즈</option>
              <option value="2">실버</option>
              <option value="3">골드</option>
              <option value="4">플래티넘</option>
              <option value="5">다이아몬드</option>
            </select>
          </div>
        </div>
      </div>

      {/* 사용자 목록 테이블 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-white/10">
            <thead className="bg-white/5">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">사용자</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">상태</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">랭크</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">총 투자</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">코인 잔액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">가입일</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-300 uppercase tracking-wider">작업</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4">
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-white">{user.username}</div>
                      <div className="text-sm text-gray-400">{user.email}</div>
                      {user.walletAddress && (
                        <div className="text-xs text-gray-500 truncate max-w-[200px]">
                          {user.walletAddress}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">{getStatusBadge(user.status, user.isActive)}</td>
                  <td className="px-6 py-4">{getRankBadge(user.rank)}</td>
                  <td className="px-6 py-4 text-sm font-medium text-white">
                    {formatCurrency(user.totalInvestment)}
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-white">
                    {formatCurrency(user.personalCoin)}
                  </td>
                  <td className="px-6 py-4 text-sm text-white">
                    {formatDate(user.createdAt)}
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-medium">
                    <div className="flex items-center justify-end gap-2 flex-wrap">
                      <button
                        onClick={() => setVerifyPasswordModal({
                          isOpen: true,
                          userId: user.id,
                          username: user.username,
                        })}
                        className="text-purple-400 hover:text-purple-300 text-xs"
                        title="비밀번호 확인"
                      >
                        비밀번호 확인
                      </button>
                      <button
                        onClick={() => setUpdatePasswordModal({
                          isOpen: true,
                          userId: user.id,
                          username: user.username,
                        })}
                        className="text-blue-400 hover:text-blue-300 text-xs"
                        title="비밀번호 변경"
                      >
                        비밀번호 변경
                      </button>
                      <button
                        onClick={() => setUpdateEmailModal({
                          isOpen: true,
                          userId: user.id,
                          currentEmail: user.email,
                        })}
                        className="text-cyan-400 hover:text-cyan-300 text-xs"
                        title="이메일 변경"
                      >
                        이메일 변경
                      </button>
                      <button
                        onClick={() => setChargeCoinModal({
                          isOpen: true,
                          userId: user.id,
                          username: user.username,
                          currentBalance: user.personalCoin,
                          type: 'charge',
                        })}
                        className="text-green-400 hover:text-green-300 text-xs"
                        title="코인 지급"
                      >
                        코인 지급
                      </button>
                      <button
                        onClick={() => setChargeCoinModal({
                          isOpen: true,
                          userId: user.id,
                          username: user.username,
                          currentBalance: user.personalCoin,
                          type: 'withdraw',
                        })}
                        className="text-red-400 hover:text-red-300 text-xs"
                        title="코인 회수"
                      >
                        코인 회수
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {users.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-400">사용자가 없습니다.</p>
          </div>
        )}
      </div>

      {/* 페이지네이션 */}
      {pagination.totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-400">
            {pagination.currentPage} / {pagination.totalPages} 페이지
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => handlePageChange(pagination.currentPage - 1)}
              disabled={!pagination.hasPrev}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              이전
            </button>
            <button
              onClick={() => handlePageChange(pagination.currentPage + 1)}
              disabled={!pagination.hasNext}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              다음
            </button>
          </div>
        </div>
      )}

      {/* 모달들 */}
      <VerifyPasswordModal
        isOpen={verifyPasswordModal.isOpen}
        onClose={() => setVerifyPasswordModal({ isOpen: false, userId: '', username: '' })}
        userId={verifyPasswordModal.userId}
        username={verifyPasswordModal.username}
        onSuccess={() => {}}
      />

      <UpdatePasswordModal
        isOpen={updatePasswordModal.isOpen}
        onClose={() => setUpdatePasswordModal({ isOpen: false, userId: '', username: '' })}
        userId={updatePasswordModal.userId}
        username={updatePasswordModal.username}
        onSuccess={fetchUsers}
      />

      <UpdateEmailModal
        isOpen={updateEmailModal.isOpen}
        onClose={() => setUpdateEmailModal({ isOpen: false, userId: '', currentEmail: null })}
        userId={updateEmailModal.userId}
        currentEmail={updateEmailModal.currentEmail}
        onSuccess={fetchUsers}
      />

      <ChargeCoinModal
        isOpen={chargeCoinModal.isOpen}
        onClose={() => setChargeCoinModal({ isOpen: false, userId: '', username: '', currentBalance: 0, type: 'charge' })}
        userId={chargeCoinModal.userId}
        username={chargeCoinModal.username}
        currentBalance={chargeCoinModal.currentBalance}
        type={chargeCoinModal.type}
        onSuccess={fetchUsers}
      />

      <CreateLockupModal
        isOpen={createLockupModal.isOpen}
        onClose={() => setCreateLockupModal({ isOpen: false, userId: '', username: '' })}
        userId={createLockupModal.userId}
        username={createLockupModal.username}
        onSuccess={() => {}} 
      />
    </div>
  );
}
