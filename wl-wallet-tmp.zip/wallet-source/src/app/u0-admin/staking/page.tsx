'use client';

import StakingManagement from '@/components/admin/StakingManagement';

export default function AdminStakingPage() {
  return (
    <div className="min-h-screen bg-[#101922]">
      <div className="container mx-auto px-4 py-8">
        <StakingManagement />
      </div>
    </div>
  );
}