'use client';

import SystemSettings from '@/components/admin/SystemSettings';

export default function AdminSettingsPage() {
  return (
    <div className="min-h-screen bg-[#101922] p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            시스템 설정
          </h1>
          <p className="text-gray-400">
            시스템 전반의 설정을 관리합니다.
          </p>
        </div>

        <SystemSettings />
      </div>
    </div>
  );
}