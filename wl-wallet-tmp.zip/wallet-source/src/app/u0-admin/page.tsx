'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { checkAdminRole } from '@/lib/admin-auth';
import NewAdminDashboard from '@/legacy_app/app/a0-admin/NewAdminDashboard';

export default function AdminPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const verifyAccess = async () => {
      try {
        const hasAdminAccess = await checkAdminRole();

        if (!hasAdminAccess) {
          router.push('/u0-admin/login');
          return;
        }

        setHasAccess(true);
      } catch (error) {
        console.error('관리자 권한 확인 오류:', error);
        router.push('/u0-admin/login');
      } finally {
        setIsLoading(false);
      }
    };

    verifyAccess();
  }, [router]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
          <div className="text-white text-sm">관리자 권한 확인 중...</div>
        </div>
      </div>
    );
  }

  if (!hasAccess) {
    return null; // 리다이렉트되므로 아무것도 렌더링하지 않음
  }

  return <NewAdminDashboard />;
}