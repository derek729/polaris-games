'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';
import CreateLockupModal from '@/components/admin/CreateLockupModal';

interface LockupOverview {
  totalSettings: number;
  lockedTotal: number;
  releasedTotal: number;
  remainingTotal: number;
  activeSettings: number;
  completedSettings: number;
}

interface LockupSetting {
  id: string;
  userId: string;
  users: {
    username?: string;
    email?: string;
  };
  tokenSymbol: string;
  lockedAmount: number;
  releasedAmount: number;
  remainingAmount: number;
  releaseRatePercent: number;
  lockPeriodMonths: number;
  startDate: string;
  endDate: string;
  nextReleaseAt?: string | null;
  status: string;
  createdAt: string;
}

interface LockupManagementClientProps {
  initialOverview?: LockupOverview;
}

export default function LockupManagementClient({ initialOverview }: LockupManagementClientProps) {
  const { language } = useI18n();
  const [overview, setOverview] = useState<LockupOverview | null>(initialOverview || null);
  const [settings, setSettings] = useState<LockupSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const itemsPerPage = 10;

  useEffect(() => {
    fetchOverview();
    fetchSettings();
  }, [currentPage, searchTerm, statusFilter]);

  const fetchOverview = async () => {
    try {
      const response = await fetch('/api/admin/lockup/overview', {
        credentials: 'include',
      });
      if (response.ok) {
        const result = await response.json();
        if (result.ok && result.data?.overview) {
          setOverview(result.data.overview);
        }
      }
    } catch (error) {
      console.error('락업 개요 조회 실패:', error);
    }
  };

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/lockup/settings', {
        credentials: 'include',
      });
      
      if (response.ok) {
        const result = await response.json();
        let filteredData = result.data || [];
        
        // 검색 필터
        if (searchTerm) {
          filteredData = filteredData.filter((item: LockupSetting) =>
            item.users.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.users.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.tokenSymbol.toLowerCase().includes(searchTerm.toLowerCase())
          );
        }
        
        // 상태 필터
        if (statusFilter !== 'all') {
          filteredData = filteredData.filter((item: LockupSetting) => item.status === statusFilter);
        }
        
        // 페이지네이션
        const totalItems = filteredData.length;
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        const startIndex = (currentPage - 1) * itemsPerPage;
        const paginatedData = filteredData.slice(startIndex, startIndex + itemsPerPage);
        
        setSettings(paginatedData);
        setTotalPages(totalPages);
      }
    } catch (error) {
      console.error('락업 설정 조회 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleManualRelease = async (userId: string) => {
    if (!confirm(language === 'ko' ? '이 사용자의 월별 락업 해제를 진행하시겠습니까?' : 'Process monthly release for this user?')) {
      return;
    }

    try {
      const response = await fetch('/api/admin/lockup/release', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ userId }),
      });

      if (response.ok) {
        alert(language === 'ko' ? '락업 해제가 완료되었습니다.' : 'Lockup release completed successfully.');
        fetchOverview();
        fetchSettings();
      } else {
        const error = await response.json();
        alert(error.error || (language === 'ko' ? '실패했습니다.' : 'Failed to process release.'));
      }
    } catch (error) {
      console.error('락업 해제 실패:', error);
      alert(language === 'ko' ? '처리 중 오류가 발생했습니다.' : 'An error occurred while processing.');
    }
  };

  const handleBatchRelease = async () => {
    if (!confirm(language === 'ko' ? '전체 사용자의 월별 락업 해제를 진행하시겠습니까?' : 'Process monthly release for all users?')) {
      return;
    }

    try {
      const response = await fetch('/api/admin/lockup/release', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({}),
      });

      if (response.ok) {
        const result = await response.json();
        alert(
          language === 'ko' 
            ? `${result.data.processed}개 설정 중 ${result.data.releasedCount}개의 락업 해제가 완료되었습니다.`
            : `Completed ${result.data.releasedCount} releases out of ${result.data.processed} settings.`
        );
        fetchOverview();
        fetchSettings();
      } else {
        const error = await response.json();
        alert(error.error || (language === 'ko' ? '실패했습니다.' : 'Failed to process release.'));
      }
    } catch (error) {
      console.error('일괄 락업 해제 실패:', error);
      alert(language === 'ko' ? '처리 중 오류가 발생했습니다.' : 'An error occurred while processing.');
    }
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(num);
  };

  const formatDate = (dateString: string | Date | undefined | null) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '-';
    return date.toLocaleString('ko-KR');
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      LOCKED: { color: 'bg-blue-500/20 text-blue-300 border-blue-500/50', label: language === 'ko' ? '락업중' : 'Locked' },
      ACTIVE_RELEASE: { color: 'bg-green-500/20 text-green-300 border-green-500/50', label: language === 'ko' ? '해제중' : 'Releasing' },
      COMPLETED: { color: 'bg-gray-500/20 text-gray-300 border-gray-500/50', label: language === 'ko' ? '완료' : 'Completed' },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.LOCKED;
    return (
      <span className={`px-2 py-1 rounded-full text-xs border ${config.color}`}>
        {config.label}
      </span>
    );
  };

  if (loading && !overview) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="text-white">
          {language === 'ko' ? '락업 관리 데이터를 불러오는 중...' : 'Loading lockup management data...'}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 페이지 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">
            {language === 'ko' ? '락업 관리' : 'Lockup Management'}
          </h2>
          <p className="text-gray-400 mt-1">
            {language === 'ko' ? '사용자 락업 물량 관리 및 해제 처리' : 'Manage user lockup amounts and releases'}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors"
          >
            {language === 'ko' ? '락업 설정 추가' : 'Add Lockup'}
          </button>
          <button
            onClick={handleBatchRelease}
            className="px-4 py-2 bg-[#137fec] hover:bg-[#137fec]/90 text-white rounded-lg font-medium transition-colors"
          >
            {language === 'ko' ? '전체 월별 해제' : 'Batch Monthly Release'}
          </button>
        </div>
      </div>

      {/* 개요 카드 */}
      {overview && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="text-sm text-gray-400 mb-2">
              {language === 'ko' ? '총 락업 설정' : 'Total Lockup Settings'}
            </div>
            <div className="text-2xl font-bold text-white mb-1">
              {formatNumber(overview.totalSettings)}
            </div>
            <div className="text-xs text-gray-500">
              {language === 'ko' ? '활성: ' : 'Active: '} {formatNumber(overview.activeSettings)} / 
              {language === 'ko' ? ' 완료: ' : ' Completed: '} {formatNumber(overview.completedSettings)}
            </div>
          </div>

          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="text-sm text-gray-400 mb-2">
              {language === 'ko' ? '총 락업 물량' : 'Total Locked Amount'}
            </div>
            <div className="text-2xl font-bold text-white mb-1">
              {formatNumber(overview.lockedTotal)} MSUO
            </div>
            <div className="text-xs text-gray-500">
              {language === 'ko' ? '잔여: ' : 'Remaining: '} {formatNumber(overview.remainingTotal)} MSUO
            </div>
          </div>

          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="text-sm text-gray-400 mb-2">
              {language === 'ko' ? '총 해제 물량' : 'Total Released Amount'}
            </div>
            <div className="text-2xl font-bold text-white mb-1">
              {formatNumber(overview.releasedTotal)} MSUO
            </div>
            <div className="text-xs text-gray-500">
              {language === 'ko' ? '해제율: ' : 'Release Rate: '} 
              {overview.lockedTotal > 0 ? ((overview.releasedTotal / overview.lockedTotal) * 100).toFixed(2) : '0'}%
            </div>
          </div>
        </div>
      )}

      {/* 검색 및 필터 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '사용자 검색' : 'Search User'}
            </label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={language === 'ko' ? '사용자명, 이메일, 토큰' : 'Username, Email, Token'}
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '상태 필터' : 'Status Filter'}
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="all">{language === 'ko' ? '전체' : 'All'}</option>
              <option value="LOCKED">{language === 'ko' ? '락업중' : 'Locked'}</option>
              <option value="ACTIVE_RELEASE">{language === 'ko' ? '해제중' : 'Releasing'}</option>
              <option value="COMPLETED">{language === 'ko' ? '완료' : 'Completed'}</option>
            </select>
          </div>
          <div className="flex items-end">
            <button
              onClick={fetchSettings}
              className="w-full px-4 py-2 bg-[#137fec] hover:bg-[#137fec]/90 text-white rounded-lg font-medium transition-colors"
            >
              {language === 'ko' ? '검색' : 'Search'}
            </button>
          </div>
        </div>
      </div>

      {/* 락업 설정 목록 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-white/10">
          <h3 className="text-lg font-semibold text-white">
            {language === 'ko' ? '락업 설정 목록' : 'Lockup Settings List'}
          </h3>
        </div>

        {loading ? (
          <div className="p-8 text-center text-gray-400">
            {language === 'ko' ? '데이터를 불러오는 중...' : 'Loading data...'}
          </div>
        ) : settings.length === 0 ? (
          <div className="p-8 text-center text-gray-400">
            {language === 'ko' ? '락업 설정이 없습니다.' : 'No lockup settings found.'}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    {language === 'ko' ? '사용자' : 'User'}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    {language === 'ko' ? '토큰' : 'Token'}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    {language === 'ko' ? '락업/해제 물량' : 'Locked/Released'}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    {language === 'ko' ? '기간' : 'Period'}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    {language === 'ko' ? '상태' : 'Status'}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    {language === 'ko' ? '다음 해제일' : 'Next Release'}
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    {language === 'ko' ? '작업' : 'Actions'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {settings.map((setting) => (
                  <tr key={setting.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-white">
                          {setting.users.username || 'N/A'}
                        </div>
                        <div className="text-xs text-gray-400">
                          {setting.users.email || 'N/A'}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">{setting.tokenSymbol}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm text-white">
                          {formatNumber(setting.lockedAmount)} MSUO
                        </div>
                        <div className="text-xs text-gray-400">
                          {language === 'ko' ? '해제: ' : 'Released: '}{formatNumber(setting.releasedAmount)} MSUO
                        </div>
                        <div className="text-xs text-gray-400">
                          {language === 'ko' ? '잔여: ' : 'Remaining: '}{formatNumber(setting.remainingAmount)} MSUO
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm text-white">
                          {setting.lockPeriodMonths} {language === 'ko' ? '개월' : 'months'}
                        </div>
                        <div className="text-xs text-gray-400">
                          {setting.releaseRatePercent}%/{language === 'ko' ? '월' : 'month'}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getStatusBadge(setting.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {setting.nextReleaseAt ? formatDate(setting.nextReleaseAt) : '-'}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => handleManualRelease(setting.userId)}
                        disabled={setting.status === 'COMPLETED'}
                        className="px-3 py-1 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-600 text-white text-xs rounded-md transition-colors"
                      >
                        {language === 'ko' ? '수동 해제' : 'Manual Release'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* 페이지네이션 */}
        {totalPages > 1 && (
          <div className="px-6 py-4 border-t border-white/10">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-400">
                {language === 'ko' ? 
                  `총 ${settings.length}개 중 ${((currentPage - 1) * itemsPerPage) + 1}-${Math.min(currentPage * itemsPerPage, settings.length)}개 표시` :
                  `Showing ${((currentPage - 1) * itemsPerPage) + 1}-${Math.min(currentPage * itemsPerPage, settings.length)} of ${settings.length} items`
                }
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1 bg-white/10 hover:bg-white/20 disabled:bg-white/5 disabled:text-gray-500 text-white text-sm rounded-md transition-colors"
                >
                  {language === 'ko' ? '이전' : 'Previous'}
                </button>
                <span className="px-3 py-1 text-white text-sm">
                  {currentPage} / {totalPages}
                </span>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  className="px-3 py-1 bg-white/10 hover:bg-white/20 disabled:bg-white/5 disabled:text-gray-500 text-white text-sm rounded-md transition-colors"
                >
                  {language === 'ko' ? '다음' : 'Next'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <CreateLockupModal 
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSuccess={() => {
          fetchOverview();
          fetchSettings();
        }}
      />
    </div>
  );
}
