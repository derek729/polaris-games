export const dynamic = 'force-dynamic';

import LockupManagementClient from '@/app/u0-admin/lockup/LockupManagementClient';
import { LockupService } from '@/services/lockup/LockupService';

export default async function LockupManagementPage() {
  const overview = await LockupService.getOverview();
  return <LockupManagementClient initialOverview={overview} />;
}

export const metadata = {
  title: '락업 관리 | MSUO Foundation',
  description: '사용자 락업 물량 관리 및 해제 처리',
};
