import MiningManagementClient from './MiningManagementClient';

export default function MiningManagementPage() {
  return <MiningManagementClient />;
}

export const metadata = {
  title: '채굴 관리 | MSUO Foundation',
  description: '사용자 채굴 기록 관리 및 보상 처리',
};
