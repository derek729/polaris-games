'use client';

import RankingManagement from '@/components/admin/RankingManagement';

export default function AdminRankingPage() {
  return (
    <div className="min-h-screen bg-[#101922]">
      <div className="container mx-auto px-4 py-8">
        <RankingManagement />
      </div>
    </div>
  );
}