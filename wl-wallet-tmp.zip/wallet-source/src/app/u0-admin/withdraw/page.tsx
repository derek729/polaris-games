'use client';

import WithdrawalManagement from '@/components/admin/WithdrawalManagement';

export default function AdminWithdrawPage() {
  return (
    <div className="min-h-screen bg-[#101922] p-8">
      <div className="max-w-7xl mx-auto">
        <WithdrawalManagement />
      </div>
    </div>
  );
}