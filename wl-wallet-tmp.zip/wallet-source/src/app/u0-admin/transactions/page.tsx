'use client';

import TransactionManagement from '@/components/admin/TransactionManagement';

export default function AdminTransactionsPage() {
  return (
    <div className="min-h-screen bg-[#101922]">
      <div className="container mx-auto px-4 py-8">
        <TransactionManagement />
      </div>
    </div>
  );
}