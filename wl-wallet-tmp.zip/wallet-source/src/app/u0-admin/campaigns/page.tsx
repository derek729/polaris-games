'use client';

import CampaignManagement from '@/components/admin/CampaignManagement';

export default function AdminCampaignsPage() {
  return (
    <div className="min-h-screen bg-[#101922]">
      <div className="container mx-auto px-4 py-8">
        <CampaignManagement />
      </div>
    </div>
  );
}