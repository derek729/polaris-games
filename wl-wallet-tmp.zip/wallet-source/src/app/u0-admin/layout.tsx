'use client';

import { ReactNode, useEffect, useState, useMemo } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { checkAdminRole } from '@/lib/admin-auth'
import { useI18n } from '@/lib/i18n/context'
import { CompanyBrand } from '@/components/CompanyBrand'

interface AdminLayoutProps {
  children: ReactNode
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  console.log('[Admin Layout] 컴포넌트 렌더링 시작')
  const { t, language, setLanguage } = useI18n()
  const [isLoading, setIsLoading] = useState(true)
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [userInfo, setUserInfo] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const pathname = usePathname()
  const router = useRouter()

  console.log('[Admin Layout] 상태:', { isLoading, pathname })

  // 로그인 페이지는 레이아웃 없이 렌더링 (훽 호출 후에 체크)
  const isLoginPage = pathname === '/u0-admin/login'

  const menuItems = useMemo(() => {
    return [
      {
        href: '/u0-admin',
        label: language === 'ko' ? '대시보드' : 'Dashboard',
        icon: 'dashboard',
      },
      {
        href: '/u0-admin/users',
        label: language === 'ko' ? '회원 관리' : 'Member Management',
        icon: 'group',
      },
      {
        href: '/u0-admin/games',
        label: language === 'ko' ? '게임 관리' : 'Game Management',
        icon: 'casino',
      },
      {
        href: '/u0-admin/campaigns',
        label: language === 'ko' ? '캠페인 관리' : 'Campaign Management',
        icon: 'campaign',
      },
      {
        href: '/u0-admin/lockup',
        label: language === 'ko' ? '락업 관리' : 'Lockup Management',
        icon: 'lock_clock',
      },
      {
        href: '/u0-admin/staking',
        label: language === 'ko' ? '스테이킹 관리' : 'Staking Management',
        icon: 'lock',
      },
      {
        href: '/u0-admin/mining',
        label: language === 'ko' ? '채굴 관리' : 'Mining Management',
        icon: 'construction',
      },
      {
        href: '/u0-admin/ranking',
        label: language === 'ko' ? '랭킹 관리' : 'Ranking Management',
        icon: 'leaderboard',
      },
      {
        href: '/u0-admin/transactions',
        label: language === 'ko' ? '거래 내역' : 'Transactions',
        icon: 'swap_horiz',
      },
      {
        href: '/u0-admin/withdraw',
        label: language === 'ko' ? '출금 관리' : 'Withdrawals',
        icon: 'account_balance_wallet',
      },
      {
        href: '/u0-admin/settings',
        label: language === 'ko' ? '시스템 설정' : 'System Settings',
        icon: 'settings',
      },
    ]
  }, [language])

  useEffect(() => {
    console.log('[Admin Layout] useEffect 실행됨')
    let isMounted = true

    const checkAuth = async () => {
      try {
        console.log('[Admin Layout] 관리자 권한 확인 시작...')
        const hasAdminAccess = await checkAdminRole()
        console.log('[Admin Layout] 관리자 권한 확인 결과:', hasAdminAccess)

        if (!isMounted) return

        if (!hasAdminAccess) {
          console.log('[Admin Layout] 관리자 권한 없음, 관리자 로그인 페이지로 리다이렉트')
          setError('관리자 권한이 필요합니다. 관리자 계정으로 로그인해주세요.')
          // 에러 메시지를 보여주기 위해 즉시 리다이렉트하지 않음
          // 사용자가 에러를 볼 수 있도록 3초 대기
          setTimeout(() => {
            if (isMounted) {
              router.push('/u0-admin/login')
            }
          }, 3000)
          return
        }

        console.log('[Admin Layout] 관리자 권한 확인됨, 사용자 정보 가져오기...')
        // 관리자 전용 세션 API를 사용하여 사용자 정보 가져오기
        const sessionResponse = await fetch('/api/admin/auth/session', {
          credentials: 'include',
          cache: 'no-store',
        })

        if (!isMounted) return

        if (sessionResponse.ok) {
          const sessionResult = await sessionResponse.json()
          if (sessionResult.ok && sessionResult.data) {
            setUserInfo(sessionResult.data)
            console.log('[Admin Layout] 사용자 정보 로드 완료')
          } else {
            console.log('[Admin Layout] 세션 응답에 데이터 없음, 관리자 로그인 페이지로 리다이렉트')
            router.push('/u0-admin/login')
            return
          }
        } else if (sessionResponse.status === 401 || sessionResponse.status === 403) {
          console.log('[Admin Layout] 인증 실패, 관리자 로그인 페이지로 리다이렉트')
          router.push('/u0-admin/login')
          return
        }
      } catch (error) {
        console.error('[Admin Layout] 관리자 인증 확인 실패:', error)
        if (isMounted) {
          router.push('/u0-admin/login')
        }
      } finally {
        if (isMounted) {
          setIsLoading(false)
        }
      }
    }

    checkAuth()

    return () => {
      isMounted = false
    }
  }, [router])

  const handleLogout = async () => {
    try {
      await fetch('/api/admin/auth/logout', { method: 'POST' })
      router.push('/u0-admin/login')
    } catch (error) {
      console.error('관리자 로그아웃 실패:', error)
    }
  }

  console.log('[Admin Layout] 렌더링 상태:', { isLoading, error, hasUserInfo: !!userInfo, isLoginPage })

  // 로그인 페이지는 레이아웃 없이 렌더링
  if (isLoginPage) {
    return <>{children}</>
  }

  if (isLoading) {
    console.log('[Admin Layout] 로딩 화면 표시')
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
          <div className="text-white text-sm">관리자 권한 확인 중...</div>
          {error && (
            <div className="text-red-400 text-sm max-w-md text-center px-4">
              {error}
            </div>
          )}
        </div>
      </div>
    )
  }

  console.log('[Admin Layout] 메인 레이아웃 렌더링')

  return (
    <div className="flex h-screen bg-[#101922] font-display text-gray-200">
      {/* SideNavBar */}
      <aside className="flex h-full w-64 flex-col justify-between bg-[#111a22] p-4 border-r border-gray-800 flex-shrink-0">
        <div className="flex flex-col gap-8">
          <div className="flex items-center gap-3 px-2 overflow-hidden">
            <CompanyBrand
              wrapperClassName="gap-2 sm:gap-3 min-w-0"
              size={40}
              textClassName="text-white text-base sm:text-lg font-bold truncate"
              imageClassName="flex-shrink-0"
            />
          </div>
          <nav className="flex flex-col gap-2">
            {menuItems.map((item) => {
              const isActive =
                pathname === item.href ||
                (item.href !== '/u0-admin' && pathname.startsWith(item.href))

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${isActive
                    ? 'bg-[#137fec]/10 text-[#137fec]'
                    : 'text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5'
                    }`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <span className="material-symbols-outlined">{item.icon}</span>
                  <p className="text-sm font-medium">{item.label}</p>
                </Link>
              )
            })}
          </nav>
        </div>
        <div className="flex flex-col gap-1">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5"
          >
            <span className="material-symbols-outlined">logout</span>
            <p className="text-sm font-medium">{language === 'ko' ? '로그아웃' : 'Logout'}</p>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex flex-1 flex-col overflow-y-auto">
        {/* TopNavBar */}
        <header className="flex items-center justify-between sticky top-0 bg-[#101922]/80 backdrop-blur-sm z-10 whitespace-nowrap border-b border-gray-800 px-4 sm:px-6 lg:px-8 py-4 gap-4">
          <div className="flex-1 min-w-0 max-w-md">
            <label className="flex flex-col h-10 w-full">
              <div className="flex w-full flex-1 items-stretch rounded-lg h-full">
                <div className="text-gray-400 dark:text-gray-500 flex bg-gray-100 dark:bg-gray-900/50 items-center justify-center pl-3 rounded-l-lg border-y border-l border-gray-300 dark:border-gray-700 flex-shrink-0">
                  <span className="material-symbols-outlined text-xl">search</span>
                </div>
                <input
                  className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-r-lg text-gray-800 dark:text-gray-200 focus:outline-0 focus:ring-2 focus:ring-[#137fec]/50 border-y border-r border-gray-300 dark:border-gray-700 bg-gray-100 dark:bg-gray-900/50 h-full placeholder:text-gray-400 dark:placeholder:text-gray-600 px-4 text-sm font-normal leading-normal"
                  placeholder={language === 'ko' ? '검색...' : 'Search...'}
                />
              </div>
            </label>
          </div>
          <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
            {/* 언어 전환 버튼 */}
            <div className="flex items-center gap-0.5 sm:gap-1 bg-white/5 rounded-lg border border-white/10 overflow-hidden">
              <button
                onClick={() => setLanguage('ko')}
                className={`px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-medium transition-colors whitespace-nowrap ${
                  language === 'ko'
                    ? 'text-[#137fec] bg-[#137fec]/10'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                한국어
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-medium transition-colors whitespace-nowrap ${
                  language === 'en'
                    ? 'text-[#137fec] bg-[#137fec]/10'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
            <button className="flex cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 flex-shrink-0">
              <span className="material-symbols-outlined">notifications</span>
            </button>
            <button className="flex cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 flex-shrink-0">
              <span className="material-symbols-outlined">settings</span>
            </button>
            <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 flex items-center justify-center bg-black/20 overflow-hidden border border-white/10 flex-shrink-0">
              <img src="/icons/uoc.svg" alt="Admin Profile" className="w-full h-full object-cover" />
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-8">{children}</main>
      </div>
    </div>
  )
}
