'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import WalletHeader from '@/app/_components/WalletHeader';

export default function LandingPage() {
  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6">
              {/* Hero Section */}
              <section className="text-center py-12 md:py-20">
                <div className="mb-8">
                  <img
                    src="/icons/logo.jpg"
                    alt="MSUO"
                    width={120}
                    height={120}
                    className="mx-auto h-24 w-24 md:h-32 md:w-32 object-contain"
                  />
                </div>
                <h1 className="text-4xl md:text-6xl font-black text-white mb-6 leading-tight tracking-[-0.02em]">
                  MSUO
                </h1>
                <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto leading-relaxed">
                  차세대 블록체인 기반 디지털 자산 플랫폼
                </p>
                <p className="text-base md:text-lg text-gray-400 mb-12 max-w-3xl mx-auto leading-relaxed">
                  MSUO 코인은 안전하고 투명한 블록체인 기술을 기반으로 한 디지털 자산입니다.
                  재단의 비전과 함께 지속 가능한 성장을 추구합니다.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link
                    href="/"
                    className="rounded-xl bg-[#137fec] hover:bg-[#0f6fd0] px-8 py-4 font-bold text-white text-lg transition-colors"
                  >
                    지갑 시작하기
                  </Link>
                  <Link
                    href="/whitepaper"
                    className="rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-8 py-4 font-bold text-white text-lg transition-colors"
                  >
                    백서 보기
                  </Link>
                </div>
              </section>

              {/* Features Section */}
              <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <div className="text-4xl mb-4">🔐</div>
                  <h3 className="text-xl font-bold text-white mb-3">안전한 지갑</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    최신 보안 기술로 보호되는 안전한 디지털 지갑 서비스를 제공합니다.
                  </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <div className="text-4xl mb-4">⚡</div>
                  <h3 className="text-xl font-bold text-white mb-3">빠른 전송</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    빠르고 저렴한 수수료로 MSUO 코인을 전송할 수 있습니다.
                  </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <div className="text-4xl mb-4">📊</div>
                  <h3 className="text-xl font-bold text-white mb-3">투명한 거래</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    모든 거래 내역을 투명하게 확인하고 관리할 수 있습니다.
                  </p>
                </div>
              </section>

              {/* About Section */}
              <section className="mt-16 rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                <h2 className="text-2xl md:text-3xl font-black text-white mb-6">MSUO Coin Foundation 소개</h2>
                <div className="space-y-4 text-gray-300 leading-relaxed">
                  <p>
                    MSUO Coin Foundation은 블록체인 기술을 통해 디지털 자산의 새로운 가능성을 제시합니다.
                  </p>
                  <p>
                    우리는 사용자 중심의 서비스를 제공하며, 안전하고 투명한 플랫폼을 구축하기 위해 노력하고 있습니다.
                  </p>
                  <p>
                    MSUO 코인은 실용적이고 지속 가능한 토큰 경제학을 기반으로 설계되었습니다.
                  </p>
                </div>
                <div className="mt-6 flex flex-col sm:flex-row gap-4">
                  <Link
                    href="/about"
                    className="rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-6 py-3 font-semibold text-white text-center transition-colors"
                  >
                    재단 소개
                  </Link>
                  <Link
                    href="/contact"
                    className="rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-6 py-3 font-semibold text-white text-center transition-colors"
                  >
                    문의하기
                  </Link>
                </div>
              </section>

              {/* CTA Section */}
              <section className="mt-16 text-center">
                <div className="rounded-2xl border border-[#137fec]/30 bg-[#137fec]/10 p-8 md:p-12">
                  <h2 className="text-2xl md:text-3xl font-black text-white mb-4">
                    지금 시작하세요
                  </h2>
                  <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                    MSUO 코인 지갑을 통해 안전하고 편리한 디지털 자산 관리를 경험해보세요.
                  </p>
                  <Link
                    href="/"
                    className="inline-block rounded-xl bg-[#137fec] hover:bg-[#0f6fd0] px-8 py-4 font-bold text-white text-lg transition-colors"
                  >
                    지갑 열기
                  </Link>
                </div>
              </section>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
