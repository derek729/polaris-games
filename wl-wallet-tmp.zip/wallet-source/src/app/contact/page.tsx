'use client';

import WalletHeader from '@/app/_components/WalletHeader';
import Link from 'next/link';

export default function ContactPage() {
  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6">
              <div className="flex flex-wrap justify-between gap-4 items-center py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    문의하기
                  </p>
                  <p className="text-gray-400 text-base font-normal leading-normal">
                    MSUO Coin Foundation에 문의사항이 있으시면 아래 채널로 연락해주세요.
                  </p>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <div className="text-4xl mb-4">📧</div>
                  <h3 className="text-xl font-bold text-white mb-2">이메일</h3>
                  <p className="text-gray-300 text-sm mb-4 leading-relaxed">
                    일반 문의 및 제안사항은 이메일로 보내주세요.
                  </p>
                  <a
                    href="mailto:jaedo3636@gmail.com"
                    className="inline-block rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-2 font-semibold text-white transition-colors"
                  >
                    jaedo3636@gmail.com
                  </a>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <div className="text-4xl mb-4">💬</div>
                  <h3 className="text-xl font-bold text-white mb-2">텔레그램</h3>
                  <p className="text-gray-300 text-sm mb-4 leading-relaxed">
                    실시간 문의는 텔레그램으로 연락해주세요.
                  </p>
                  <a
                    href="https://t.me/upc_foundation"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-2 font-semibold text-white transition-colors"
                  >
                    @upc_foundation
                  </a>
                </div>
              </div>

              <div className="mt-6 rounded-xl border border-white/10 bg-black/20 p-4">
                <div className="text-sm text-gray-300 leading-relaxed">
                  <p className="font-semibold text-white mb-2">문의 시 참고사항</p>
                  <ul className="list-disc list-inside space-y-1 text-xs">
                    <li>이메일 응답은 영업일 기준 1-2일 소요됩니다.</li>
                    <li>긴급한 문의는 텔레그램을 이용해주세요.</li>
                    <li>기술 지원은 백서를 먼저 확인해주시기 바랍니다.</li>
                  </ul>
                </div>
              </div>

              <div className="mt-8">
                <Link
                  href="/"
                  className="inline-flex items-center justify-center rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-2 font-semibold text-white transition-colors"
                >
                  홈으로 돌아가기
                </Link>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
