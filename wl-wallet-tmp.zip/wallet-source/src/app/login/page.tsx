'use client';

import { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { CompanyBrand } from '@/components/CompanyBrand';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Card, CardContent, CardHeader } from '@/components/ui/Card';
import { Container } from '@/components/ui/Container';
import { SkeletonCard } from '@/components/ui/LoadingState';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { useI18n } from '@/lib/i18n/context';

// 로그인 폼 컴포넌트
function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { t } = useI18n();
  
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '로그인에 실패했습니다.');
      }

      // 로그인 성공
      const redirectTo = searchParams.get('redirect') || '/';
      router.push(redirectTo);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : '로그인에 실패했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      {/* 배경 효과 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-blue-500/10 to-transparent rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-purple-500/10 to-transparent rounded-full blur-3xl animate-pulse-slow" />
      </div>

      <Container size="sm" className="relative z-10">
        <div className="w-full max-w-md mx-auto space-y-8">
          {/* 로고 */}
          <div className="text-center">
            <Link href="/" className="inline-block">
              <CompanyBrand
                wrapperClassName="gap-4 justify-center"
                size={56}
                textClassName="text-white text-2xl font-bold"
              />
            </Link>
            <h1 className="mt-6 text-2xl font-bold text-white">
              {t.auth?.welcomeBack || '다시 오신 것을 환영합니다'}
            </h1>
            <p className="mt-2 text-gray-400">
              {t.auth?.loginSubtitle || '계정에 로그인하세요'}
            </p>
          </div>

          {/* 로그인 카드 */}
          <Card variant="glass" className="backdrop-blur-xl">
            <CardContent padding="lg">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* 에러 메시지 */}
                {error && (
                  <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm flex items-center gap-2 animate-shake">
                    <span className="material-symbols-outlined">error</span>
                    {error}
                  </div>
                )}

                {/* 사용자명 */}
                <Input
                  name="username"
                  label={t.auth?.username || '사용자명'}
                  type="text"
                  value={formData.username}
                  onChange={handleChange}
                  placeholder={t.auth?.usernamePlaceholder || '사용자명을 입력하세요'}
                  leftIcon={<span className="material-symbols-outlined">person</span>}
                  required
                  autoComplete="username"
                />

                {/* 비밀번호 */}
                <Input
                  name="password"
                  label={t.auth?.password || '비밀번호'}
                  type="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder={t.auth?.passwordPlaceholder || '비밀번호를 입력하세요'}
                  leftIcon={<span className="material-symbols-outlined">lock</span>}
                  required
                  autoComplete="current-password"
                />

                {/* 로그인 버튼 */}
                <Button
                  type="submit"
                  fullWidth
                  size="lg"
                  loading={isLoading}
                  className="mt-2"
                >
                  {isLoading ? (t.auth?.loggingIn || '로그인 중...') : (t.auth?.login || '로그인')}
                </Button>
              </form>

              {/* 구분선 */}
              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-white/10" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-transparent text-gray-500">
                    {t.auth?.or || '또는'}
                  </span>
                </div>
              </div>

              {/* 회원가입 링크 */}
              <div className="text-center">
                <p className="text-gray-400 text-sm">
                  {t.auth?.noAccount || '계정이 없으신가요?'}{' '}
                  <Link
                    href="/register"
                    className="text-blue-400 hover:text-blue-300 font-medium transition-colors"
                  >
                    {t.auth?.signUp || '회원가입'}
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* 하단 링크들 */}
          <div className="flex items-center justify-center gap-6 text-sm">
            <Link
              href="/about"
              className="text-gray-400 hover:text-white transition-colors"
            >
              {t.common?.about || '재단 소개'}
            </Link>
            <Link
              href="/contact"
              className="text-gray-400 hover:text-white transition-colors"
            >
              {t.common?.contact || '문의하기'}
            </Link>
            <LanguageSwitcher />
          </div>
        </div>
      </Container>
    </div>
  );
}

// 로딩 스켈레톤
function LoginSkeleton() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Container size="sm">
        <div className="w-full max-w-md mx-auto space-y-8">
          <div className="text-center space-y-4">
            <SkeletonCard className="h-16 w-48 mx-auto" />
            <div className="space-y-2">
              <div className="h-6 bg-slate-700/50 rounded-lg w-48 mx-auto animate-pulse" />
              <div className="h-4 bg-slate-700/50 rounded-lg w-36 mx-auto animate-pulse" />
            </div>
          </div>
          <SkeletonCard className="min-h-[300px]" />
        </div>
      </Container>
    </div>
  );
}

// 메인 페이지 컴포넌트
export default function LoginPage() {
  return (
    <Suspense fallback={<LoginSkeleton />}>
      <LoginForm />
    </Suspense>
  );
}
