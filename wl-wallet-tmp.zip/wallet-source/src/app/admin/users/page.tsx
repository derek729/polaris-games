'use client';

import { useState, useEffect } from 'react';

interface User {
  id: string;
  username: string | null;
  email: string | null;
  personalCoin: number;
  role: string;
  isActive: boolean;
  createdAt: string;
}

interface RecoveryModalProps {
  user: User | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  adminId: string;
}

// 코인 회수 모달 컴포넌트
function RecoveryModal({ user, isOpen, onClose, onSuccess, adminId }: RecoveryModalProps) {
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      setError('올바른 금액을 입력해주세요.');
      return;
    }

    if (!reason.trim()) {
      setError('회수 사유를 입력해주세요.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/admin/users/${user.id}/recover`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-id': adminId,
        },
        body: JSON.stringify({
          amount: amountNum,
          reason: reason.trim(),
          adminId,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || '코인 회수에 실패했습니다.');
      }

      alert(result.message || '코인이 성공적으로 회수되었습니다.');
      setAmount('');
      setReason('');
      onClose();
      onSuccess();
    } catch (err: any) {
      setError(err.message || '오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-[#1e2329] rounded-lg p-6 w-full max-w-md border border-[#2b3139]">
        <h3 className="text-xl font-bold text-white mb-4">코인 회수</h3>
        
        <div className="mb-4 p-3 bg-[#2b3139] rounded-lg">
          <p className="text-gray-400 text-sm">대상 사용자</p>
          <p className="text-white font-semibold">{user.username || user.id}</p>
          <p className="text-[#00d4aa] text-sm">
            현재 잔액: {Number(user.personalCoin).toFixed(8)} 코인
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-gray-400 text-sm mb-2">
              회수할 코인 수량
            </label>
            <input
              type="number"
              step="0.00000001"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00000000"
              className="w-full bg-[#0b0e11] border border-[#2b3139] rounded-lg px-4 py-3 text-white focus:border-[#00d4aa] focus:outline-none"
            />
          </div>

          <div className="mb-4">
            <label className="block text-gray-400 text-sm mb-2">
              회수 사유
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="회수 사유를 입력하세요..."
              rows={3}
              className="w-full bg-[#0b0e11] border border-[#2b3139] rounded-lg px-4 py-3 text-white focus:border-[#00d4aa] focus:outline-none resize-none"
            />
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 bg-[#2b3139] text-gray-400 rounded-lg font-semibold hover:bg-[#363c45] transition-colors"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-3 bg-[#f0b90b] text-black rounded-lg font-semibold hover:bg-[#f0b90b]/80 transition-colors disabled:opacity-50"
            >
              {loading ? '처리 중...' : '회수하기'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// 사용자 목록 페이지
export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [adminId, setAdminId] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [totalUsers, setTotalUsers] = useState(0);

  useEffect(() => {
    // 로컬 스토리지에서 관리자 ID 불러오기
    try {
      const storedAdminId = typeof window !== 'undefined' ? localStorage.getItem('adminId') || '' : '';
      setAdminId(storedAdminId);
      if (storedAdminId) {
        fetchUsers(storedAdminId);
      } else {
        setLoading(false);
      }
    } catch (error) {
      // localStorage 접근 불가능한 경우 (빌드 시)
      setLoading(false);
    }
  }, []);

  const fetchUsers = async (adminIdParam?: string) => {
    try {
      setLoading(true);
      const id = adminIdParam || adminId;
      
      const response = await fetch(`/api/admin/users?search=${encodeURIComponent(searchTerm)}&limit=100`, {
        headers: {
          'x-admin-id': id,
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || '사용자 목록 조회 실패');
      }

      const result = await response.json();
      setUsers(result.data || []);
      setTotalUsers(result.pagination?.total || 0);
    } catch (err: any) {
      console.error('사용자 목록 조회 오류:', err);
      setError(err.message || '사용자 목록을 불러오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const handleRecoverClick = (user: User) => {
    setSelectedUser(user);
    setModalOpen(true);
  };

  const handleModalClose = () => {
    setModalOpen(false);
    setSelectedUser(null);
  };

  const handleRecoverSuccess = () => {
    fetchUsers();
  };

  const handleAdminSubmit = () => {
    if (adminId.trim()) {
      if (typeof window !== 'undefined') {
        localStorage.setItem('adminId', adminId);
      }
      fetchUsers(adminId);
    }
  };

  // 관리자 ID 입력 컴포넌트
  const hasAdminId = typeof window !== 'undefined' ? localStorage.getItem('adminId') : null;
  if (!hasAdminId && !loading) {
    return (
      <div className="min-h-screen bg-[#0b0e11] flex items-center justify-center">
        <div className="bg-[#1e2329] rounded-lg p-6 w-full max-w-md border border-[#2b3139]">
          <h3 className="text-xl font-bold text-white mb-4">관리자 인증</h3>
          <p className="text-gray-400 text-sm mb-4">
            관리자 ID를 입력하세요.
          </p>
          <input
            type="text"
            value={adminId}
            onChange={(e) => setAdminId(e.target.value)}
            placeholder="관리자 ID"
            className="w-full bg-[#0b0e11] border border-[#2b3139] rounded-lg px-4 py-3 text-white focus:border-[#00d4aa] focus:outline-none mb-4"
          />
          <button
            onClick={handleAdminSubmit}
            className="w-full px-4 py-3 bg-[#00d4aa] text-black rounded-lg font-semibold hover:bg-[#00d4aa]/80 transition-colors"
          >
            확인
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0b0e11]">
      {/* Header */}
      <header className="bg-[#1e2329] border-b border-[#2b3139] p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold text-white">회원 관리</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-400 text-sm">
              총 {totalUsers}명
            </span>
            <span className="text-gray-400 text-sm">
              관리자: {adminId}
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Search */}
          <div className="mb-6 flex gap-4">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && fetchUsers()}
              placeholder="사용자 검색 (이름, 이메일, ID)..."
              className="flex-1 md:w-96 bg-[#1e2329] border border-[#2b3139] rounded-lg px-4 py-3 text-white focus:border-[#00d4aa] focus:outline-none"
            />
            <button
              onClick={() => fetchUsers()}
              className="px-6 py-3 bg-[#00d4aa] text-black rounded-lg font-semibold hover:bg-[#00d4aa]/80 transition-colors"
            >
              검색
            </button>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-12 h-12 border-4 border-[#00d4aa] border-t-transparent rounded-full animate-spin" />
            </div>
          ) : error ? (
            <div className="text-center py-12">
              <p className="text-red-400">{error}</p>
              <button
                onClick={() => fetchUsers()}
                className="mt-4 px-4 py-2 bg-[#00d4aa] text-black rounded-lg font-semibold"
              >
                다시 시도
              </button>
            </div>
          ) : (
            <div className="bg-[#1e2329] rounded-lg border border-[#2b3139] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-[#2b3139]">
                    <tr>
                      <th className="px-4 py-3 text-left text-gray-400 text-sm font-semibold">사용자</th>
                      <th className="px-4 py-3 text-left text-gray-400 text-sm font-semibold">이메일</th>
                      <th className="px-4 py-3 text-right text-gray-400 text-sm font-semibold">코인 잔액</th>
                      <th className="px-4 py-3 text-center text-gray-400 text-sm font-semibold">권한</th>
                      <th className="px-4 py-3 text-center text-gray-400 text-sm font-semibold">상태</th>
                      <th className="px-4 py-3 text-center text-gray-400 text-sm font-semibold">작업</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                          {searchTerm ? '검색 결과가 없습니다.' : '등록된 사용자가 없습니다.'}
                        </td>
                      </tr>
                    ) : (
                      users.map((user) => (
                        <tr key={user.id} className="border-t border-[#2b3139] hover:bg-[#2b3139]/50">
                          <td className="px-4 py-3">
                            <div className="text-white font-medium">{user.username || '-'}</div>
                            <div className="text-gray-500 text-xs">{user.id.slice(0, 8)}...</div>
                          </td>
                          <td className="px-4 py-3 text-gray-400">{user.email || '-'}</td>
                          <td className="px-4 py-3 text-right">
                            <span className="text-[#00d4aa] font-mono">
                              {Number(user.personalCoin).toFixed(8)}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className={`px-2 py-1 rounded text-xs font-semibold
                              ${user.role === 'SUPER_ADMIN' ? 'bg-purple-500/20 text-purple-400' :
                                user.role === 'ADMIN' ? 'bg-blue-500/20 text-blue-400' :
                                'bg-gray-500/20 text-gray-400'}`}>
                              {user.role}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className={`px-2 py-1 rounded text-xs font-semibold
                              ${user.isActive ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                              {user.isActive ? '활성' : '비활성'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button
                              onClick={() => handleRecoverClick(user)}
                              disabled={user.role === 'SUPER_ADMIN' || user.role === 'ADMIN'}
                              className="px-3 py-1 bg-[#f0b90b] text-black rounded text-sm font-semibold hover:bg-[#f0b90b]/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              코인 회수
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Recovery Modal */}
      <RecoveryModal
        user={selectedUser}
        isOpen={modalOpen}
        onClose={handleModalClose}
        onSuccess={handleRecoverSuccess}
        adminId={adminId}
      />
    </div>
  );
}
