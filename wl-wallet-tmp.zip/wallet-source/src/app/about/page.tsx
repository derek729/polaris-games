'use client';

import WalletHeader from '@/app/_components/WalletHeader';
import Link from 'next/link';

export default function AboutPage() {
  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6">
              <div className="flex flex-wrap justify-between gap-4 items-center py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    MSUO Coin Foundation 소개
                  </p>
                  <p className="text-gray-400 text-base font-normal leading-normal">
                    MSUO 코인 재단의 미션과 비전을 소개합니다.
                  </p>
                </div>
              </div>

              <div className="mt-6 space-y-6">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <h2 className="text-2xl font-bold text-white mb-4">미션</h2>
                  <p className="text-gray-300 leading-relaxed">
                    MSUO Coin Foundation은 블록체인 기술을 통해 디지털 자산의 새로운 가능성을 제시하고,
                    사용자 중심의 안전하고 투명한 플랫폼을 구축합니다.
                  </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <h2 className="text-2xl font-bold text-white mb-4">비전</h2>
                  <p className="text-gray-300 leading-relaxed">
                    글로벌 디지털 자산 생태계의 선도적인 재단으로 성장하여,
                    모든 사용자에게 신뢰할 수 있는 블록체인 서비스를 제공합니다.
                  </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <h2 className="text-2xl font-bold text-white mb-4">핵심 가치</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    <div className="rounded-xl border border-white/10 bg-black/20 p-4">
                      <div className="text-2xl mb-2">🔐</div>
                      <div className="font-semibold text-white mb-1">보안</div>
                      <div className="text-sm text-gray-300">최고 수준의 보안 기술</div>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-black/20 p-4">
                      <div className="text-2xl mb-2">⚡</div>
                      <div className="font-semibold text-white mb-1">속도</div>
                      <div className="text-sm text-gray-300">빠른 거래 처리</div>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-black/20 p-4">
                      <div className="text-2xl mb-2">🌐</div>
                      <div className="font-semibold text-white mb-1">투명성</div>
                      <div className="text-sm text-gray-300">완전한 거래 투명성</div>
                    </div>
                  </div>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <h2 className="text-2xl font-bold text-white mb-4">연락처</h2>
                  <div className="space-y-3">
                    <div className="rounded-xl border border-white/10 bg-black/20 p-4">
                      <div className="font-semibold text-white mb-1">이메일</div>
                      <div className="text-sm text-gray-300">contact@msuo.foundation</div>
                    </div>
                    <div className="rounded-xl border border-white/10 bg-black/20 p-4">
                      <div className="font-semibold text-white mb-1">텔레그램</div>
                      <div className="text-sm text-gray-300">@msuo_foundation</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <Link
                  href="/"
                  className="inline-flex items-center justify-center rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-2 font-semibold text-white transition-colors"
                >
                  홈으로 돌아가기
                </Link>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
