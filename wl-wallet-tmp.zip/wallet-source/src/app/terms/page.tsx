'use client';

import { useI18n } from '@/lib/i18n/context';
import WalletHeader from '@/app/_components/WalletHeader';

export default function TermsPage() {
  const { t } = useI18n();

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6 text-gray-300">
              <h1 className="text-3xl font-bold text-white mb-6">Terms of Service</h1>
              
              <section className="mb-8">
                <h2 className="text-xl font-bold text-white mb-4">1. Introduction</h2>
                <p className="mb-4">
                  Welcome to MSUO Wallet. By accessing or using our website and services, you agree to be bound by these Terms of Service.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-xl font-bold text-white mb-4">2. Digital Assets</h2>
                <p className="mb-4">
                  MSUO is a digital asset. The value of digital assets can be volatile. You acknowledge that you are fully responsible for your investment decisions.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-xl font-bold text-white mb-4">3. Security</h2>
                <p className="mb-4">
                  You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-xl font-bold text-white mb-4">4. Limitation of Liability</h2>
                <p className="mb-4">
                  MSUO Foundation shall not be liable for any indirect, incidental, special, consequential or punitive damages.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-bold text-white mb-4">5. Contact</h2>
                <p>
                  If you have any questions about these Terms, please contact us at support@msuo.io.
                </p>
              </section>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}