export const dynamic = 'force-dynamic';

import { getCurrentUser } from '@/lib/auth';
import LandingPage from '@/app/_components/LandingPage';
import WalletHomeClient from '@/app/_components/WalletHomeClient';

export default async function HomePage() {
  const user = await getCurrentUser();
  
  // 로그인된 사용자는 지갑 화면을 보여주고, 로그인되지 않은 사용자는 랜딩페이지를 보여줍니다
  if (user) {
    return <WalletHomeClient />;
  }
  
  return <LandingPage />;
}
