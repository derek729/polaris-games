'use client';

import { useState, useEffect, useRef, useMemo } from 'react';
import { TrendingUp, DollarSign, Clock, Award, Shield, Zap, Target, Activity, AlertCircle, Users, Droplets } from 'lucide-react';
import { 
  StakingSimulator, 
  STAKING_POOLS, 
  calculateStakingProfitability,
  type StakingPool,
  type StakingConfig
} from '@/lib/staking-physics';
import { useI18n } from '@/lib/i18n/context';

interface UserStakingPosition {
  id: string;
  userId: string;
  poolId: string;
  pool: StakingPool;
  amount: number;
  currentAmount: number;
  startTime: Date;
  endTime: Date;
  lockPeriod: number;
  compoundFrequency: string;
  autoCompound: boolean;
  currentApy: number;
  totalEarned: number;
  status: 'ACTIVE' | 'COMPLETED' | 'WITHDRAWN';
  createdAt: Date;
  updatedAt: Date;
}

export default function StakingPoolClient() {
  const { language } = useI18n();
  const [positions, setPositions] = useState<UserStakingPosition[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPool, setSelectedPool] = useState<StakingPool>(STAKING_POOLS[0]);
  const [stakingAmount, setStakingAmount] = useState<number>(10000);
  const [lockPeriod, setLockPeriod] = useState<number>(30);
  const [compoundFrequency, setCompoundFrequency] = useState<'continuous' | 'daily' | 'weekly' | 'monthly' | 'yearly'>('daily');
  const [autoCompound, setAutoCompound] = useState(true);
  const [isStaking, setIsStaking] = useState(false);
  const [simulator, setSimulator] = useState<StakingSimulator | null>(null);
  const [currentStats, setCurrentStats] = useState<{
    currentValue: number;
    totalEarned: number;
    currentApy: number;
    efficiency: number;
    timeElapsed: number;
    projectedDaily: number;
    projectedValue: number[];
  }>({
    currentValue: 0,
    totalEarned: 0,
    currentApy: 0,
    efficiency: 0,
    timeElapsed: 0,
    projectedDaily: 0,
    projectedValue: []
  });

  const [profitability, setProfitability] = useState(() =>
    calculateStakingProfitability({
      principalAmount: stakingAmount,
      apy: selectedPool.baseApy,
      compoundFrequency,
      lockPeriod,
      autoCompound,
      volatilityRate: selectedPool.riskLevel === 'LOW' ? 5 : selectedPool.riskLevel === 'MEDIUM' ? 15 : 30,
      marketCondition: 'sideways',
      bonusMultiplier: 1,
      stakingFee: 0.5,
      unstakingFee: 0.1,
      performanceFee: 0,
      referralBonus: 2,
      loyaltyBonus: Math.min(5, lockPeriod / 365 * 5),
      volumeBonus: stakingAmount > 10000 ? 3 : 0
    })
  );

  const animationRef = useRef<number | null>(null);
  const lastUpdateRef = useRef<number>(Date.now());

  // 사용자 스테이킹 포지션 조회
  const fetchStakingPositions = async () => {
    try {
      const response = await fetch('/api/user/staking/positions', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        if (data.ok) {
          setPositions(data.data.positions);
        }
      }
    } catch (error) {
      console.error('스테이킹 포지션 조회 실패:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // 스테이킹 시작
  const startStaking = async () => {
    try {
      const response = await fetch('/api/user/staking/stake', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          poolId: selectedPool.id,
          amount: stakingAmount,
          lockPeriod,
          compoundFrequency,
          autoCompound
        })
      });

      const data = await response.json();
      if (data.ok) {
        setIsStaking(true);
        fetchStakingPositions(); // 포지션 목록 새로고침
      } else {
        alert(data.error || '스테이킹 시작에 실패했습니다.');
      }
    } catch (error) {
      console.error('스테이킹 시작 실패:', error);
      alert('스테이킹 시작 중 오류가 발생했습니다.');
    }
  };

  // 스테이킹 해지
  const formatDateSafe = (date: string | Date | undefined | null) => {
    if (!date) return '-';
    const d = new Date(date);
    if (isNaN(d.getTime())) return '-';
    return d.toLocaleDateString();
  };

  const unstake = async (positionId: string) => {
    try {
      const response = await fetch('/api/user/staking/unstake', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ positionId })
      });

      const data = await response.json();
      if (data.ok) {
        fetchStakingPositions(); // 포지션 목록 새로고침
      } else {
        alert(data.error || '스테이킹 해지에 실패했습니다.');
      }
    } catch (error) {
      console.error('스테이킹 해지 실패:', error);
      alert('스테이킹 해지 중 오류가 발생했습니다.');
    }
  };

  useEffect(() => {
    fetchStakingPositions();
  }, []);

  // 스테이킹 설정 변경 시 재계산
  useEffect(() => {
    const config: StakingConfig = {
      principalAmount: stakingAmount,
      apy: calculateDynamicApy(),
      compoundFrequency,
      lockPeriod,
      autoCompound,
      volatilityRate: selectedPool.riskLevel === 'LOW' ? 5 : selectedPool.riskLevel === 'MEDIUM' ? 15 : 30,
      marketCondition: 'sideways',
      bonusMultiplier: 1,
      stakingFee: 0.5,
      unstakingFee: 0.1,
      performanceFee: selectedPool.performanceBonus ? 10 : 0,
      referralBonus: 2,
      loyaltyBonus: Math.min(5, lockPeriod / 365 * 5),
      volumeBonus: stakingAmount > 10000 ? 3 : 0
    };

    setProfitability(calculateStakingProfitability(config));
  }, [stakingAmount, selectedPool, lockPeriod, compoundFrequency, autoCompound]);

  // 동적 APY 계산
  const calculateDynamicApy = () => {
    let apy = selectedPool.baseApy;

    if (stakingAmount >= 10000) apy += 1.5;
    if (stakingAmount >= 50000) apy += 2.5;
    if (stakingAmount >= 100000) apy += 3.5;

    if (lockPeriod >= 90) apy += 1.0;
    if (lockPeriod >= 180) apy += 2.0;
    if (lockPeriod >= 365) apy += 3.5;

    if (compoundFrequency === 'continuous') apy += 0.8;
    if (compoundFrequency === 'daily') apy += 0.5;
    if (compoundFrequency === 'weekly') apy += 0.3;

    return Math.min(apy, selectedPool.maxApy);
  };

  // 초기화
  useEffect(() => {
    if (isStaking && !simulator) {
      const config: StakingConfig = {
        principalAmount: stakingAmount,
        apy: calculateDynamicApy(),
        compoundFrequency,
        lockPeriod,
        autoCompound,
        volatilityRate: selectedPool.riskLevel === 'LOW' ? 5 : selectedPool.riskLevel === 'MEDIUM' ? 15 : 30,
        marketCondition: 'sideways',
        bonusMultiplier: 1,
        stakingFee: 0.5,
        unstakingFee: 0.1,
        performanceFee: selectedPool.performanceBonus ? 10 : 0,
        referralBonus: 2,
        loyaltyBonus: Math.min(5, lockPeriod / 365 * 5),
        volumeBonus: stakingAmount > 10000 ? 3 : 0
      };
      setSimulator(new StakingSimulator(config));
    } else if (!isStaking && simulator) {
      setSimulator(null);
      setCurrentStats({
        currentValue: 0,
        totalEarned: 0,
        currentApy: 0,
        efficiency: 0,
        timeElapsed: 0,
        projectedDaily: 0,
        projectedValue: []
      });
    }
  }, [isStaking, stakingAmount, selectedPool, lockPeriod, compoundFrequency, autoCompound, simulator]);

  // 실시간 시뮬레이션
  useEffect(() => {
    if (!isStaking || !simulator) return;

    const animate = () => {
      const now = Date.now();
      const deltaTime = (now - lastUpdateRef.current) / 1000;
      lastUpdateRef.current = now;

      const marketConditions = {
        priceChange: (Math.random() - 0.5) * 0.001,
        apyChange: (Math.random() - 0.5) * 0.01,
        volatility: selectedPool.riskLevel === 'LOW' ? 2 : selectedPool.riskLevel === 'MEDIUM' ? 8 : 20
      };

      const result = simulator.update(deltaTime, marketConditions);

      setCurrentStats({
        currentValue: result.currentValue,
        totalEarned: result.totalEarned,
        currentApy: result.currentApy,
        efficiency: result.efficiency,
        timeElapsed: result.timeElapsed,
        projectedDaily: result.projectedDaily,
        projectedValue: profitability.projectedValue
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isStaking, simulator, profitability.projectedValue, selectedPool]);

  const formatCurrency = (amount: number) =>
    `${amount.toLocaleString('ko-KR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 8,
    })} MSUO`;

  const formatPercent = (value: number) => `${value.toFixed(2)}%`;
  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'LOW': return 'text-green-400 bg-green-500/20 border-green-500/50';
      case 'MEDIUM': return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/50';
      case 'HIGH': return 'text-red-400 bg-red-500/20 border-red-500/50';
      default: return 'text-gray-400 bg-gray-500/20 border-gray-500/50';
    }
  };

  const getApyColor = (apy: number) => {
    if (apy >= 20) return 'text-purple-400';
    if (apy >= 15) return 'text-blue-400';
    if (apy >= 10) return 'text-green-400';
    if (apy >= 5) return 'text-yellow-400';
    return 'text-gray-400';
  };

  const currentApy = calculateDynamicApy();

  return (
    <div className="space-y-8 p-6 bg-gradient-to-br from-gray-900 via-gray-900 to-black rounded-3xl border border-white/5 shadow-2xl relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-[100px] pointer-events-none" />

      {/* 헤더 */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-blue-100 to-blue-400 mb-2">
            {language === 'ko' ? '스테이킹 풀' : 'Staking Pools'}
          </h2>
          <p className="text-gray-400 text-lg flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-400" />
            {language === 'ko' ? '안전하고 투명한 수익 창출' : 'Safe and transparent yield generation'}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="px-4 py-2 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md">
            <span className="text-sm text-gray-400 block">{language === 'ko' ? '총 스테이킹' : 'Total Staked'}</span>
            <span className="text-xl font-bold text-white">12,450,000 MSUO</span>
          </div>
        </div>
      </div>

      {/* 현재 스테이킹 포지션 */}
      {!isLoading && positions.length > 0 && (
        <div className="relative z-10 bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md shadow-xl">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <Target className="w-6 h-6 text-green-400" />
            {language === 'ko' ? '나의 포지션' : 'My Positions'}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {positions.map((position) => (
              <div key={position.id} className="bg-black/40 rounded-xl p-5 border border-white/10 hover:border-blue-500/30 transition-all duration-300">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                      <Zap className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <div className="text-white font-bold text-lg">{position.pool.name}</div>
                      <div className="text-xs text-gray-400 flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${getRiskColor(position.pool.riskLevel)}`}>
                          {position.pool.riskLevel}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-green-400 font-bold text-lg">
                      +{formatCurrency(position.totalEarned)}
                    </div>
                    <div className="text-sm text-gray-400">
                      APY {formatPercent(position.currentApy)}
                    </div>
                  </div>
                </div>
                <div className="w-full bg-gray-800/50 h-2 rounded-full overflow-hidden mb-3">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                    style={{ width: `${Math.min(100, (Date.now() - new Date(position.startTime).getTime()) / (new Date(position.endTime).getTime() - new Date(position.startTime).getTime()) * 100)}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span>{formatDateSafe(position.startTime)}</span>
                  <span>{formatDateSafe(position.endTime)}</span>
                </div>
                
                {position.status === 'ACTIVE' && position.pool.earlyUnstake && (
                  <button
                    onClick={() => unstake(position.id)}
                    className="w-full mt-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg text-sm font-medium transition-colors"
                  >
                    {language === 'ko' ? '조기 해지' : 'Early Unstake'}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 메인 컨텐츠 그리드 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 relative z-10">
        {/* 왼쪽: 풀 선택 */}
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {STAKING_POOLS.map((pool) => (
              <button
                key={pool.id}
                onClick={() => setSelectedPool(pool)}
                className={`relative group p-6 rounded-2xl border transition-all duration-300 text-left overflow-hidden ${
                  selectedPool.id === pool.id
                    ? 'bg-blue-600/10 border-blue-500/50 shadow-[0_0_30px_rgba(59,130,246,0.15)]'
                    : 'bg-white/5 border-white/10 hover:border-white/20 hover:bg-white/[0.07]'
                }`}
              >
                <div className={`absolute top-0 right-0 p-3 rounded-bl-2xl text-xs font-bold border-l border-b ${
                  selectedPool.id === pool.id ? 'bg-blue-500/20 border-blue-500/30 text-blue-300' : 'bg-white/5 border-white/10 text-gray-400'
                }`}>
                  {pool.riskLevel}
                </div>

                <div className="flex items-start gap-4 mb-4">
                  <div className={`p-3 rounded-xl ${
                    selectedPool.id === pool.id ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-700/30 text-gray-400'
                  }`}>
                    {pool.id === 'standard' && <Shield className="w-6 h-6" />}
                    {pool.id === 'high-yield' && <TrendingUp className="w-6 h-6" />}
                    {pool.id === 'vip' && <Award className="w-6 h-6" />}
                  </div>
                  <div>
                    <h3 className={`text-lg font-bold ${selectedPool.id === pool.id ? 'text-white' : 'text-gray-300'}`}>
                      {pool.name}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1 line-clamp-2">{pool.description}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-sm">{language === 'ko' ? '기본 APY' : 'Base APY'}</span>
                    <span className="text-white font-bold">{formatPercent(pool.baseApy)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-sm">{language === 'ko' ? '최대 APY' : 'Max APY'}</span>
                    <span className={`font-bold ${getApyColor(pool.maxApy)}`}>{formatPercent(pool.maxApy)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-sm">{language === 'ko' ? '최소 기간' : 'Min Lock'}</span>
                    <span className="text-white">{Math.min(...pool.lockPeriods)}일</span>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* 설정 패널 */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-400" />
              {language === 'ko' ? '스테이킹 설정' : 'Staking Configuration'}
            </h3>
            
            <div className="space-y-6">
              {/* 금액 입력 */}
              <div>
                <label className="text-sm text-gray-400 mb-2 block">{language === 'ko' ? '스테이킹 수량' : 'Amount'}</label>
                <div className="relative">
                  <input
                    type="number"
                    value={stakingAmount}
                    onChange={(e) => setStakingAmount(Number(e.target.value))}
                    className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-white font-mono text-lg focus:outline-none focus:border-blue-500/50 transition-colors"
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 font-bold">MSUO</div>
                </div>
              </div>

              {/* 기간 설정 */}
              <div>
                <label className="text-sm text-gray-400 mb-2 block flex justify-between">
                  <span>{language === 'ko' ? '잠금 기간' : 'Lock Period'}</span>
                  <span className="text-blue-400 font-bold">{lockPeriod} {language === 'ko' ? '일' : 'Days'}</span>
                </label>
                <input
                  type="range"
                  min="30"
                  max="365"
                  step="30"
                  value={lockPeriod}
                  onChange={(e) => setLockPeriod(Number(e.target.value))}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
                <div className="flex justify-between text-xs text-gray-500 mt-2">
                  <span>30일</span>
                  <span>180일</span>
                  <span>365일</span>
                </div>
              </div>

              {/* 옵션 토글 */}
              <div className="flex flex-wrap gap-4">
                <label className="flex items-center gap-3 p-3 rounded-xl bg-black/20 border border-white/10 cursor-pointer hover:bg-black/30 transition-colors flex-1">
                  <input
                    type="checkbox"
                    checked={autoCompound}
                    onChange={(e) => setAutoCompound(e.target.checked)}
                    className="w-5 h-5 rounded border-gray-600 text-blue-600 focus:ring-blue-500 bg-gray-700"
                  />
                  <span className="text-gray-300 font-medium">{language === 'ko' ? '자동 재투자' : 'Auto Compound'}</span>
                </label>
                
                <div className="flex-1">
                  <select
                    value={compoundFrequency}
                    onChange={(e) => setCompoundFrequency(e.target.value as any)}
                    className="w-full p-3 rounded-xl bg-black/20 border border-white/10 text-gray-300 focus:outline-none focus:border-blue-500/50"
                  >
                    <option value="daily">{language === 'ko' ? '매일' : 'Daily'}</option>
                    <option value="weekly">{language === 'ko' ? '매주' : 'Weekly'}</option>
                    <option value="monthly">{language === 'ko' ? '매월' : 'Monthly'}</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 오른쪽: 결과 패널 */}
        <div className="space-y-6">
          <div className="bg-gradient-to-b from-blue-900/20 to-black/40 border border-blue-500/20 rounded-2xl p-6 backdrop-blur-md sticky top-6">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              {language === 'ko' ? '예상 수익' : 'Projected Returns'}
            </h3>

            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                <span className="text-blue-200">{language === 'ko' ? '적용 APY' : 'Applied APY'}</span>
                <span className="text-2xl font-black text-blue-400">{formatPercent(currentApy)}</span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">{language === 'ko' ? '예상 일일 수익' : 'Daily Return'}</span>
                  <span className="text-white font-medium">
                    {formatCurrency(profitability.dailyInterest)}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">{language === 'ko' ? '예상 총 수익' : 'Total Return'}</span>
                  <span className="text-green-400 font-bold">
                    +{formatCurrency(profitability.netProfit)}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={startStaking}
              disabled={isStaking || isLoading}
              className={`w-full py-4 rounded-xl font-bold text-lg transition-all duration-300 shadow-lg ${
                isStaking
                  ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white shadow-blue-500/25 hover:shadow-blue-500/40 hover:-translate-y-1'
              }`}
            >
              {isStaking 
                ? (language === 'ko' ? '스테이킹 중...' : 'Staking Active') 
                : (language === 'ko' ? '스테이킹 시작하기' : 'Start Staking')}
            </button>

            {isStaking && (
              <div className="mt-6 pt-6 border-t border-white/10">
                <div className="text-center">
                  <div className="text-gray-400 text-sm mb-1">{language === 'ko' ? '실시간 수익' : 'Real-time Earnings'}</div>
                  <div className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500 animate-pulse">
                    +{formatCurrency(currentStats.totalEarned)}
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    {formatTime(currentStats.timeElapsed)}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}