'use client';

import { useState, useEffect } from 'react';
import WalletHeader from '@/app/_components/WalletHeader';
import StakingPoolClient from './StakingPoolClient';

export default function StakingPage() {
  const [user, setUser] = useState({
    id: '',
    username: '',
    email: '',
    personalCoin: 0,
    walletAddress: '',
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchUserInfo();
  }, []);

  const fetchUserInfo = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.data?.users) {
          setUser({
            id: data.data.users.id || '',
            username: data.data.users.username || '',
            email: data.data.users.email || '',
            personalCoin: data.data.users.personalCoin || 0,
            walletAddress: data.data.users.walletAddress || '',
          });
        }
      }
    } catch (error) {
      console.error('사용자 정보 조회 실패:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6">
              <div className="flex flex-wrap justify-between gap-4 items-center py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    스테이킹
                  </p>
                  <p className="text-gray-400 text-base font-normal leading-normal">
                    MSUO 코인을 스테이킹하여 수익을 얻으세요.
                  </p>
                </div>
              </div>

              <div className="mt-6">
                <StakingPoolClient />
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}

