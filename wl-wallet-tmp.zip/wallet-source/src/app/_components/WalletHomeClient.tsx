'use client';

import { useEffect, useState, useRef } from 'react';
import Link from 'next/link';
import WalletHeader from '@/app/_components/WalletHeader';
import LockupStatusCard from '@/app/_components/LockupStatusCard';
import { Eye, EyeOff, Copy, CheckCircle, ArrowUpRight, ArrowDownLeft, Wallet, Send, Receipt, ExternalLink } from 'lucide-react';
import QRCode from 'qrcode';
import RecoveryPhraseModal from '@/components/ui/RecoveryPhraseModal';
import { useToast } from '@/components/ui/Toast';
import { useI18n } from '@/lib/i18n/context';
import { Card, CardContent, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Grid, Flex, Stack } from '@/components/ui/Grid';
import { Skeleton, SkeletonCard } from '@/components/ui/LoadingState';
import { cn } from '@/lib/utils';
import CoinSwapWidget from '@/components/wallet/CoinSwapWidget';

export default function WalletHomeClient() {
  const { t, language } = useI18n();
  const { addToast } = useToast();
  const [isReceiveOpen, setIsReceiveOpen] = useState(false);
  const [address, setAddress] = useState<string | null>(null);
  const [balance, setBalance] = useState<number>(0);
  const [ozBalance, setOzBalance] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [needsWalletCreation, setNeedsWalletCreation] = useState(false);
  const [showBalance, setShowBalance] = useState(true);
  const [qrCode, setQrCode] = useState<string | null>(null);
  const [recentActivity, setRecentActivity] = useState<Array<{ type: string; amount: number; message: string; date: string; status: string; fee: number }>>([]);
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  const [recoveryPhrase, setRecoveryPhrase] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    fetchUserWallet();
    fetchRecentActivity();
  }, []);

  const fetchRecentActivity = async () => {
    try {
      const response = await fetch('/api/user/transfer?type=all&limit=5', {
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.data) {
          const activities = data.data.map((tx: any) => ({
            type: tx.type,
            amount: tx.amount,
            message: tx.type === 'sent'
              ? `To: ${tx.receiver?.username || tx.receiver?.email || 'Unknown'}`
              : `From: ${tx.sender?.username || tx.sender?.email || 'Unknown'}`,
            date: tx.transferredAt,
            status: tx.status,
            fee: tx.fee
          }));
          setRecentActivity(activities.slice(0, 5));
        }
      }
    } catch (error) {
      console.error('최근 활동 조회 실패:', error);
    }
  };

  const fetchUserWallet = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.data?.users) {
          const user = data.data.users;
          setAddress(user.walletAddress || null);
          setBalance(user.personalCoin || 0);
          setOzBalance(user.ozCoin || 0);
          
          if (!user.walletAddress) {
            setNeedsWalletCreation(true);
          }
        }
      }
    } catch (error) {
      console.error('지갑 정보 조회 실패:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createWallet = async () => {
    try {
      const response = await fetch('/api/user/wallet/create', {
        method: 'POST',
        credentials: 'include'
      });

      const data = await response.json();
      if (data.ok && data.data?.address) {
        setAddress(data.data.address);
        setRecoveryPhrase(data.data.recoveryPhrase || []);
        setShowRecoveryModal(true);
        setNeedsWalletCreation(false);
        addToast({ type: 'success', title: t.wallet.walletCreateTitle, message: t.wallet.walletCreateMsg });
      } else {
        addToast({ type: 'error', title: t.common.error, message: data.error || t.wallet.walletCreateFailMsg });
      }
    } catch (error) {
      console.error('Wallet creation failed:', error);
      addToast({ type: 'error', title: t.common.error, message: t.wallet.walletCreateFailMsg });
    }
  };

  const copyAddress = async () => {
    if (!address) return;
    try {
      await navigator.clipboard.writeText(address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      addToast({ type: 'success', message: t.wallet.copySuccess });
    } catch {
      addToast({ type: 'error', message: t.wallet.copyFailed });
    }
  };

  const generateQRCode = async () => {
    if (!address) return;
    try {
      const qrDataUrl = await QRCode.toDataURL(address, {
        width: 256,
        margin: 2,
        color: { dark: '#000000', light: '#FFFFFF' },
      });
      setQrCode(qrDataUrl);
    } catch (error) {
      console.error('QR 코드 생성 실패:', error);
    }
  };

  useEffect(() => {
    if (isReceiveOpen && address) {
      generateQRCode();
    }
  }, [isReceiveOpen, address]);

  // 로딩 중일 때 스켈레톤
  if (isLoading) {
    return (
      <div className="min-h-screen p-4 sm:p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-16 w-full" />
          <Grid cols={1} lg={3} gap="lg">
            <div className="lg:col-span-2">
              <SkeletonCard className="min-h-[400px]" />
            </div>
            <SkeletonCard className="min-h-[400px]" />
          </Grid>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen">
      {/* 배경 장식 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/4 w-1/2 h-full bg-gradient-to-br from-blue-500/5 to-transparent rounded-full blur-3xl" />
        <div className="absolute -bottom-1/2 -right-1/4 w-1/2 h-full bg-gradient-to-tl from-purple-500/5 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <WalletHeader />

          <main className="space-y-6">
            <Grid cols={1} lg={3} gap="lg">
              {/* 메인 지갑 카드 */}
              <div className="lg:col-span-2">
                <Card variant="glass" className="h-full">
                  <CardContent padding="lg">
                    {/* 총 자산 섹션 */}
                    <div className="flex items-start justify-between gap-4 mb-6">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                          <span className="material-symbols-outlined text-lg">account_balance_wallet</span>
                          {t.common.totalAssets}
                          <button
                            onClick={() => setShowBalance(!showBalance)}
                            className="p-1 rounded-lg hover:bg-white/10 transition-colors"
                          >
                            {showBalance ? (
                              <Eye className="w-4 h-4 text-gray-400" />
                            ) : (
                              <EyeOff className="w-4 h-4 text-gray-400" />
                            )}
                          </button>
                        </div>
                        
                        <div className="flex items-baseline gap-2">
                          <span className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                            {showBalance ? balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '****'}
                          </span>
                          <span className="text-xl font-bold text-gray-400">MSUO</span>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                          {showBalance ? `≈ $${(balance * 1).toFixed(2)} USD` : '≈ $**** USD'}
                        </p>
                      </div>

                      {/* 지갑 상태 배지 */}
                      <div className={cn(
                        'px-4 py-2 rounded-xl border',
                        address
                          ? 'bg-green-500/10 border-green-500/20'
                          : 'bg-yellow-500/10 border-yellow-500/20'
                      )}>
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            'w-2 h-2 rounded-full animate-pulse',
                            address ? 'bg-green-400' : 'bg-yellow-400'
                          )} />
                          <span className={cn(
                            'text-sm font-medium',
                            address ? 'text-green-400' : 'text-yellow-400'
                          )}>
                            {address ? t.common.walletConnected : t.common.walletDisconnected}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* OZ 코인 섹션 */}
                    <div className="p-4 rounded-xl bg-white/5 border border-white/10 mb-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-400 mb-1">{t.common.ozCoin}</p>
                          <div className="flex items-baseline gap-2">
                            <span className="text-2xl font-bold text-white">
                              {showBalance ? ozBalance.toFixed(2) : '****'}
                            </span>
                            <span className="text-sm font-semibold text-gray-400">OZ</span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">
                            {showBalance ? `≈ $${(ozBalance * 0.85).toFixed(2)} (개당 $0.85)` : '≈ $****'}
                          </p>
                        </div>
                        <div className="p-3 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20">
                          <span className="material-symbols-outlined text-2xl text-amber-400">paid</span>
                        </div>
                      </div>
                    </div>

                    {/* 액션 버튼 */}
                    <div className="grid grid-cols-3 gap-3 mb-6">
                      <Link href="/transfer" className="group">
                        <div className="p-4 rounded-xl bg-gradient-to-br from-blue-500/10 to-blue-600/10 border border-blue-500/20 hover:border-blue-500/40 transition-all hover:scale-[1.02]">
                          <div className="flex flex-col items-center gap-2">
                            <div className="p-2 rounded-lg bg-blue-500/20 group-hover:bg-blue-500/30 transition-colors">
                              <Send className="w-5 h-5 text-blue-400" />
                            </div>
                            <span className="text-sm font-semibold text-white">{t.wallet.send}</span>
                          </div>
                        </div>
                      </Link>

                      <button
                        type="button"
                        onClick={() => setIsReceiveOpen(true)}
                        className="group"
                      >
                        <div className="p-4 rounded-xl bg-gradient-to-br from-green-500/10 to-green-600/10 border border-green-500/20 hover:border-green-500/40 transition-all hover:scale-[1.02] w-full">
                          <div className="flex flex-col items-center gap-2">
                            <div className="p-2 rounded-lg bg-green-500/20 group-hover:bg-green-500/30 transition-colors">
                              <ArrowDownLeft className="w-5 h-5 text-green-400" />
                            </div>
                            <span className="text-sm font-semibold text-white">{t.wallet.receive}</span>
                          </div>
                        </div>
                      </button>

                      <Link href="/transactions" className="group">
                        <div className="p-4 rounded-xl bg-gradient-to-br from-purple-500/10 to-purple-600/10 border border-purple-500/20 hover:border-purple-500/40 transition-all hover:scale-[1.02]">
                          <div className="flex flex-col items-center gap-2">
                            <div className="p-2 rounded-lg bg-purple-500/20 group-hover:bg-purple-500/30 transition-colors">
                              <Receipt className="w-5 h-5 text-purple-400" />
                            </div>
                            <span className="text-sm font-semibold text-white">{t.wallet.history}</span>
                          </div>
                        </div>
                      </Link>
                    </div>

                    {/* 지갑 주소 */}
                    <div className="p-4 rounded-xl bg-black/20 border border-white/10">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm font-semibold text-white">{t.wallet.myWalletAddress}</span>
                        {address && (
                          <span className="flex items-center gap-1.5 text-xs text-green-400">
                            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                            {t.wallet.active}
                          </span>
                        )}
                      </div>

                      {needsWalletCreation || !address ? (
                        <div className="space-y-3">
                          <p className="text-sm text-gray-400">{t.common.walletCreationNeeded}</p>
                          <Button onClick={createWallet} fullWidth>
                            <Wallet className="w-4 h-4" />
                            {t.common.createWallet}
                          </Button>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <code className="flex-1 text-xs text-gray-300 break-all font-mono bg-black/40 px-3 py-2 rounded-lg">
                              {address}
                            </code>
                            <Button
                              variant="glass"
                              size="icon"
                              onClick={copyAddress}
                              aria-label="주소 복사"
                            >
                              {copied ? (
                                <CheckCircle className="w-4 h-4 text-green-400" />
                              ) : (
                                <Copy className="w-4 h-4" />
                              )}
                            </Button>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span>{t.common.network}: MSUO Chain</span>
                            <span>•</span>
                            <span>{t.common.walletType}: {t.common.dashboard}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* 사이드바 */}
              <div className="space-y-6">
                {/* 최근 활동 */}
                <Card variant="glass">
                  <CardHeader>
                    <h3 className="text-lg font-bold text-white">{t.common.recentActivities}</h3>
                  </CardHeader>
                  <CardContent>
                    <Stack gap="sm">
                      {recentActivity.length > 0 ? (
                        recentActivity.map((activity, index) => (
                          <ActivityItem key={index} activity={activity} />
                        ))
                      ) : (
                        <div className="py-8 text-center">
                          <span className="material-symbols-outlined text-4xl text-gray-600 mb-2">receipt_long</span>
                          <p className="text-sm text-gray-500">{t.common.noRecentActivity}</p>
                        </div>
                      )}
                    </Stack>

                    <Link
                      href="/transactions"
                      className="mt-4 block"
                    >
                      <Button variant="outline" fullWidth>
                        {t.wallet.viewAll}
                        <ArrowUpRight className="w-4 h-4" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>

                {/* 빠른 액션 */}
                <Card variant="glass">
                  <CardHeader>
                    <h3 className="text-lg font-bold text-white">{t.wallet.quickActions}</h3>
                  </CardHeader>
                  <CardContent>
                    <Stack gap="sm">
                      <Link
                        href="/staking"
                        className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all"
                      >
                        <span className="material-symbols-outlined text-blue-400">account_balance</span>
                        <span className="text-sm font-medium text-white">{t.common.staking}</span>
                        <ArrowUpRight className="w-4 h-4 text-gray-500 ml-auto" />
                      </Link>
                      <Link
                        href="/games"
                        className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all"
                      >
                        <span className="material-symbols-outlined text-purple-400">sports_esports</span>
                        <span className="text-sm font-medium text-white">{t.common.games}</span>
                        <ArrowUpRight className="w-4 h-4 text-gray-500 ml-auto" />
                      </Link>
                      <Link
                        href="/whitepaper"
                        className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all"
                      >
                        <span className="material-symbols-outlined text-amber-400">description</span>
                        <span className="text-sm font-medium text-white">{t.wallet.viewWhitepaper}</span>
                        <ArrowUpRight className="w-4 h-4 text-gray-500 ml-auto" />
                      </Link>
                      <Link
                        href="/my-profile"
                        className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all"
                      >
                        <span className="material-symbols-outlined text-green-400">person_add</span>
                        <span className="text-sm font-medium text-white">{t.referral.title}</span>
                        <ArrowUpRight className="w-4 h-4 text-gray-500 ml-auto" />
                      </Link>
                    </Stack>
                  </CardContent>
                </Card>
              </div>
            </Grid>

            {/* MSUO ↔ MSUP 교환 */}
            <CoinSwapWidget
              msuoBalance={balance}
              onSwapSuccess={fetchUserWallet}
            />

            {/* 락업 상태 */}
            <LockupStatusCard />
          </main>
        </div>
      </div>

      {/* Receive Modal */}
      {isReceiveOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
          <Card variant="glass" className="w-full max-w-md animate-scale-in">
            <CardContent padding="lg">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white">{t.wallet.receive}</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsReceiveOpen(false)}
                  aria-label="닫기"
                >
                  <span className="material-symbols-outlined">close</span>
                </Button>
              </div>

              {address ? (
                <>
                  <p className="text-sm text-gray-400 mb-4">{t.wallet.receiveDesc}</p>
                  
                  <div className="p-4 rounded-xl bg-black/30 border border-white/10 mb-4">
                    <code className="text-xs text-gray-300 break-all font-mono">{address}</code>
                  </div>

                  {qrCode && (
                    <div className="flex justify-center mb-4">
                      <img
                        src={qrCode}
                        alt="QR Code"
                        className="rounded-xl border border-white/10 shadow-lg"
                        style={{ maxWidth: '200px' }}
                      />
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3">
                    <Button onClick={copyAddress}>
                      <Copy className="w-4 h-4" />
                      {t.wallet.copyAddress}
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() => qrCode && navigator.clipboard.writeText(qrCode)}
                      disabled={!qrCode}
                    >
                      {t.common.receiveQrCode}
                    </Button>
                  </div>
                </>
              ) : (
                <div className="py-4 text-center">
                  <span className="material-symbols-outlined text-4xl text-yellow-400 mb-2">warning</span>
                  <p className="text-sm text-yellow-400">{t.wallet.noAddress}</p>
                  <p className="text-xs text-gray-500 mt-1">{t.wallet.createWalletFirst}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Recovery Phrase Modal */}
      {showRecoveryModal && (
        <RecoveryPhraseModal
          isOpen={showRecoveryModal}
          onClose={() => setShowRecoveryModal(false)}
          recoveryPhrase={recoveryPhrase}
          address={address || ''}
        />
      )}
    </div>
  );
}

// 활동 아이템 컴포넌트
function ActivityItem({ activity }: { activity: { type: string; amount: number; message: string; date: string; status: string; fee: number } }) {
  const { t } = useI18n();
  const isSent = activity.type === 'sent';
  const isCompleted = activity.status === 'completed' || activity.status === 'COMPLETED';

  return (
    <div className="p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className={cn(
            'p-1.5 rounded-lg',
            isSent ? 'bg-red-500/20' : 'bg-green-500/20'
          )}>
            {isSent ? (
              <ArrowUpRight className="w-3.5 h-3.5 text-red-400" />
            ) : (
              <ArrowDownLeft className="w-3.5 h-3.5 text-green-400" />
            )}
          </div>
          <span className="text-sm font-medium text-white">
            {isSent ? t.wallet.sent : t.wallet.received}
          </span>
          <span className={cn(
            'text-xs px-2 py-0.5 rounded-full',
            isCompleted
              ? 'bg-green-500/20 text-green-300'
              : 'bg-yellow-500/20 text-yellow-300'
          )}>
            {isCompleted ? t.wallet.completed : t.wallet.processing}
          </span>
        </div>
        <span className={cn(
          'text-sm font-bold',
          isSent ? 'text-red-300' : 'text-green-300'
        )}>
          {isSent ? '-' : '+'}{activity.amount.toFixed(2)}
        </span>
      </div>
      <p className="text-xs text-gray-400 truncate">{activity.message}</p>
      <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
        <span>{t.wallet.fee}: {activity.fee > 0 ? activity.fee.toFixed(4) + ' OZ' : '-'}</span>
        <span>{new Date(activity.date).toLocaleString('ko-KR', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
      </div>
    </div>
  );
}
