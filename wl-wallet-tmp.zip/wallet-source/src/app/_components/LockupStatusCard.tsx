'use client';

import { useEffect, useState } from 'react';

interface LockupStatus {
  availableNKB: number;
  setting: {
    tokenSymbol: string;
    lockedAmount: number;
    releasedAmount: number;
    remainingAmount: number;
    releaseRatePercent: number;
    lockPeriodMonths: number;
    startDate: string;
    endDate: string;
    nextReleaseAt?: string | null;
    status: string;
  } | null;
  recentReleases: Array<{
    amount: number;
    releaseDate: string;
    status: string;
    description?: string;
  }>;
}

export default function LockupStatusCard() {
  const [data, setData] = useState<LockupStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await fetch('/api/user/lockup/status', { credentials: 'include' });
        const json = await res.json();
        if (json.ok) {
          setData(json.data);
        } else {
          setError(json.error || '락업 상태 조회 실패');
        }
      } catch (e: any) {
        setError(e?.message || '네트워크 오류');
      } finally {
        setLoading(false);
      }
    };
    fetchStatus();
  }, []);

  if (loading) {
    return (
      <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
        <div className="text-sm text-gray-400">락업 상태 조회 중...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-2xl border border-red-500/30 bg-red-500/10 p-6">
        <div className="text-sm text-red-300">{error}</div>
      </div>
    );
  }

  const setting = data?.setting;
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-lg font-bold text-white">락업 현황</div>
          <div className="mt-1 text-xs text-gray-400">사용 가능한 NKB 및 락업 정보</div>
        </div>
        <div className="rounded-xl bg-black/20 px-3 py-2">
          <div className="text-xs text-gray-400">사용 가능</div>
          <div className="text-base font-bold text-white">{(data?.availableNKB || 0).toLocaleString('ko-KR')} NKB</div>
        </div>
      </div>

      {setting ? (
        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="rounded-xl border border-white/10 bg-black/20 p-4">
            <div className="text-xs text-gray-400">락업 총액</div>
            <div className="mt-1 text-sm font-semibold text-white">{setting.lockedAmount.toLocaleString('ko-KR')} {setting.tokenSymbol}</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-4">
            <div className="text-xs text-gray-400">잔여 락업</div>
            <div className="mt-1 text-sm font-semibold text-white">{setting.remainingAmount.toLocaleString('ko-KR')} {setting.tokenSymbol}</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-4">
            <div className="text-xs text-gray-400">월별 해제율</div>
            <div className="mt-1 text-sm font-semibold text-white">{setting.releaseRatePercent}%</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-4">
            <div className="text-xs text-gray-400">락업 기간</div>
            <div className="mt-1 text-sm font-semibold text-white">{setting.lockPeriodMonths}개월</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-4">
            <div className="text-xs text-gray-400">종료일</div>
            <div className="mt-1 text-sm font-semibold text-white">{new Date(setting.endDate).toLocaleDateString('ko-KR')}</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-4">
            <div className="text-xs text-gray-400">다음 해제</div>
            <div className="mt-1 text-sm font-semibold text-white">{setting.nextReleaseAt ? new Date(setting.nextReleaseAt).toLocaleDateString('ko-KR') : '-'}</div>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-4">
            <div className="text-xs text-gray-400">상태</div>
            <div className="mt-1 text-sm font-semibold text-white">{setting.status}</div>
          </div>
        </div>
      ) : (
        <div className="mt-4 rounded-xl border border-white/10 bg-black/20 p-4">
          <div className="text-sm text-gray-300">설정된 락업이 없습니다.</div>
        </div>
      )}
    </div>
  );
}

