'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n/context';

export default function LandingPage() {
  const { language } = useI18n();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const t = (ko: string, en: string) => language === 'ko' ? ko : en;

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [mobileMenuOpen]);

  return (
    <div className="relative min-h-screen bg-msuo-black text-white overflow-x-hidden" style={{ fontFamily: "'Inter', sans-serif", zIndex: 20, position: 'relative' }}>

      {/* Texture overlay */}
      <div className="fixed inset-0 pointer-events-none z-0 opacity-[0.03]"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E")` }}
      />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 transition-all duration-300" style={{ background: 'rgba(10,10,10,0.85)', backdropFilter: 'blur(12px)' }}>
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="flex items-center justify-between h-16 md:h-20">
            <a href="#" className="flex items-center gap-3 group" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <img src="/icons/logo.jpg" alt="MSUO" className="w-10 h-10 object-contain" />
              <span className="font-heading font-bold text-xl tracking-wider text-white uppercase">MSUO</span>
            </a>

            <div className="hidden lg:flex items-center gap-8">
              {['ecosystem', 'token', 'community', 'contact'].map(section => (
                <a key={section} href={`#${section}`} className="relative text-xs font-semibold uppercase tracking-[0.2em] text-msuo-silver hover:text-white transition-colors after:content-[''] after:absolute after:bottom-[-2px] after:left-0 after:w-0 after:h-[2px] after:bg-msuo-orange after:transition-all hover:after:w-full">
                  {t(
                    { ecosystem: '생태계', token: '토큰', community: '커뮤니티', contact: '연락처' }[section]!,
                    section.charAt(0).toUpperCase() + section.slice(1)
                  )}
                </a>
              ))}
            </div>

            <div className="flex items-center gap-4">
              <button onClick={() => { setAuthMode('login'); setIsAuthModalOpen(true); }} className="hidden md:inline-flex items-center gap-2 bg-msuo-orange hover:bg-msuo-orangeLight text-msuo-black text-xs font-bold uppercase tracking-wider px-6 py-3 transition-all duration-200">
                <span>{t('시작하기', 'Get Started')}</span>
              </button>
              <button onClick={() => setMobileMenuOpen(true)} className="lg:hidden w-10 h-10 flex items-center justify-center text-white hover:text-msuo-orange transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <div className={`fixed top-0 right-0 w-80 max-w-full h-screen bg-msuo-black border-l border-white/5 z-50 transition-transform duration-400 ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`} style={{ transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)' }}>
          <div className="p-6">
            <div className="flex justify-end mb-10">
              <button onClick={() => setMobileMenuOpen(false)} className="w-10 h-10 flex items-center justify-center text-white hover:text-msuo-orange transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="flex flex-col gap-6">
              {[
                { id: 'ecosystem', ko: '생태계', en: 'Ecosystem' },
                { id: 'token', ko: '토큰 정보', en: 'Token' },
                { id: 'community', ko: '커뮤니티', en: 'Community' },
                { id: 'contact', ko: '연락처', en: 'Contact' },
              ].map(item => (
                <a key={item.id} href={`#${item.id}`} onClick={() => setMobileMenuOpen(false)} className="font-heading text-2xl font-bold uppercase tracking-wider text-white hover:text-msuo-orange transition-colors">
                  {t(item.ko, item.en)}
                </a>
              ))}
              <div className="mt-6 pt-6 border-t border-white/10">
                <button onClick={() => { setMobileMenuOpen(false); setAuthMode('register'); setIsAuthModalOpen(true); }} className="flex items-center justify-center gap-2 bg-msuo-orange text-msuo-black text-sm font-bold uppercase tracking-wider px-6 py-4 w-full hover:bg-msuo-orangeLight transition-colors">
                  <span>{t('무료 지갑 만들기', 'Create Free Wallet')}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        {mobileMenuOpen && <div className="fixed inset-0 bg-black/60 z-40" style={{ backdropFilter: 'blur(4px)' }} onClick={() => setMobileMenuOpen(false)} />}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img src="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=1920&q=80" alt="Blockchain" className="w-full h-full object-cover" style={{ filter: 'grayscale(100%) contrast(1.3) brightness(0.5)' }} />
          <div className="absolute inset-0 bg-gradient-to-r from-msuo-black via-msuo-black/90 to-msuo-black/50" />
          <div className="absolute inset-0 bg-gradient-to-t from-msuo-black via-transparent to-msuo-black/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6 pt-32 pb-20 md:pt-40 md:pb-28 w-full">
          <div className="grid lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-7">
              <div className="flex items-center gap-3 mb-6 animate-fade-in-up">
                <div className="w-[60px] h-[3px] bg-gradient-to-r from-msuo-orange to-msuo-orangeLight" />
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-msuo-orange">{t('차세대 디지털 자산 플랫폼 — Est. 2024', 'Next Gen Digital Asset Platform — Est. 2024')}</span>
              </div>

              <h1 className="font-heading text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold uppercase leading-[0.9] tracking-tight text-white mb-6 animate-fade-in-up" style={{ animationDelay: '100ms' }}>
                {t('미래의', 'The Future of')}<br />
                <span className="relative inline-block">
                  {t('자산', 'MSUO')}
                  <span className="absolute -bottom-1 left-0 w-full h-1 bg-msuo-orange" />
                </span><br />
                {t('코인', 'Coin')}
              </h1>

              <p className="text-sm md:text-base text-msuo-silver max-w-lg leading-relaxed mb-8 animate-fade-in-up" style={{ animationDelay: '200ms' }}>
                {t(
                  '게임, 채굴, 스테이킹이 결합된 혁신적인 블록체인 생태계. MSUO와 함께 디지털 자산의 새로운 가능성을 경험하세요.',
                  'Where innovation meets opportunity. MSUO is not just a coin — it\'s a complete digital ecosystem combining gaming, mining, staking, and secure wallet services.'
                )}
              </p>

              <div className="flex flex-wrap gap-8 mb-10 animate-fade-in-up" style={{ animationDelay: '300ms' }}>
                {[
                  { value: '50B', label: t('총 발행량', 'Total Supply') },
                  { value: '25B', label: t('채굴 할당', 'Mining Pool') },
                  { value: '10Y', label: t('채굴 기간', 'Mining Period') },
                ].map((stat, i) => (
                  <div key={i} className="flex items-center gap-8">
                    <div>
                      <div className="font-heading text-3xl md:text-4xl font-bold" style={{ background: 'linear-gradient(135deg, #FF5E00, #FF7A2E)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{stat.value}</div>
                      <div className="text-[10px] uppercase tracking-[0.2em] text-msuo-silverDark mt-1">{stat.label}</div>
                    </div>
                    {i < 2 && <div className="w-px bg-white/10" />}
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-4 animate-fade-in-up" style={{ animationDelay: '400ms' }}>
                <button onClick={() => { setAuthMode('register'); setIsAuthModalOpen(true); }} className="inline-flex items-center gap-2 bg-msuo-orange hover:bg-msuo-orangeLight text-msuo-black text-xs font-bold uppercase tracking-wider px-8 py-4 transition-all duration-200" style={{ animation: 'pulse-glow 2s ease-in-out infinite' }}>
                  <span>{t('지갑 만들기', 'Create Wallet')}</span>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                </button>
                <a href="#ecosystem" className="inline-flex items-center gap-2 border border-white/20 hover:border-msuo-orange/50 text-white text-xs font-bold uppercase tracking-wider px-8 py-4 transition-all duration-200 hover:bg-white/5">
                  <span>{t('생태계 탐색', 'Explore Ecosystem')}</span>
                </a>
              </div>
            </div>

            {/* Right: Feature Preview */}
            <div className="lg:col-span-5 animate-fade-in-up hidden lg:block" style={{ animationDelay: '300ms' }}>
              <div className="relative">
                <div className="relative overflow-hidden rounded-sm bg-msuo-gray border border-white/5">
                  <img src="https://images.unsplash.com/photo-1642104704074-907c0698cbd9?w=600&q=80" alt="Digital Asset" className="w-full h-[400px] md:h-[500px] object-cover object-top" style={{ filter: 'grayscale(100%) contrast(1.2) brightness(0.6)' }} />
                  <div className="absolute inset-0 bg-gradient-to-t from-msuo-black via-transparent to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-msuo-orange mb-1">{t('MSUO Foundation', 'MSUO Foundation')}</div>
                    <div className="font-heading text-xl font-bold text-white uppercase">{t('디지털 자산 생태계', 'Digital Asset Ecosystem')}</div>
                    <div className="text-xs text-msuo-silver mt-0.5">{t('게임 · 채굴 · 스테이킹 · 거래', 'Gaming · Mining · Staking · Trading')}</div>
                  </div>
                </div>
                <div className="flex gap-2 mt-2">
                  {[
                    { label: t('채굴', 'Mining'), icon: '\u26CF' },
                    { label: t('게임', 'Games'), icon: '\uD83C\uDFAE' },
                    { label: t('지갑', 'Wallet'), icon: '\uD83D\uDCB0' },
                    { label: '+4', icon: '' },
                  ].map((item, i) => (
                    <div key={i} className="relative flex-1 overflow-hidden rounded-sm h-24 bg-msuo-gray flex items-center justify-center border border-white/5 hover:border-msuo-orange/30 transition-all cursor-pointer">
                      <div className="text-center">
                        {item.icon && <div className="text-xl mb-0.5">{item.icon}</div>}
                        <div className="text-[9px] font-bold uppercase tracking-wider text-msuo-silver">{item.label}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 animate-bounce">
          <span className="text-[9px] uppercase tracking-[0.3em] text-msuo-silverDark">{t('스크롤', 'Scroll')}</span>
          <svg className="w-4 h-4 text-msuo-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
        </div>
      </section>

      {/* Marquee Banner */}
      <div className="relative bg-msuo-orange py-3 overflow-hidden z-10">
        <div className="flex whitespace-nowrap" style={{ animation: 'marquee 25s linear infinite' }}>
          {[...Array(2)].map((_, setIdx) => (
            <div key={setIdx} className="flex items-center gap-8 mr-8">
              {['Mining', 'Staking', 'Gaming', 'Exchange', 'Wallet', 'P2P Trading'].map((item, i) => (
                <span key={`${setIdx}-${i}`} className="font-heading text-sm font-bold uppercase tracking-wider text-msuo-black flex items-center gap-8">
                  {t(
                    { Mining: '채굴', Staking: '스테이킹', Gaming: '게임', Exchange: '거래소', Wallet: '지갑', 'P2P Trading': 'P2P 거래' }[item] || item,
                    item
                  )}
                  <span className="text-msuo-orangeDark">&#9670;</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Ecosystem Section (Programs) */}
      <section id="ecosystem" className="relative py-20 md:py-28 bg-msuo-black">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-[60px] h-[3px] bg-gradient-to-r from-msuo-orange to-msuo-orangeLight" />
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-msuo-orange">{t('MSUO 생태계', 'MSUO Ecosystem')}</span>
              </div>
              <h2 className="font-heading text-4xl md:text-5xl font-bold uppercase tracking-tight text-white">
                {t('강력한', 'Build With')}<br />{t('생태계', 'Purpose')}
              </h2>
            </div>
            <p className="text-sm text-msuo-silver max-w-md leading-relaxed">
              {t(
                '게임, 채굴, 스테이킹, 지갑이 하나로 연결된 완전한 디지털 자산 생태계입니다.',
                'Every feature is engineered for results. Gaming rewards, fair mining distribution, and secure wallet — all in one unified platform.'
              )}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                icon: '\u26CF\uFE0F', title: t('채굴 & 스테이킹', 'Mining & Staking'),
                desc: t('네트워크 참여로 MSUO를 획득하세요. 공정한 분배와 락업 보너스로 수익을 극대화합니다.', 'Earn MSUO through network participation. Fair distribution with lockup bonuses for maximum yield.'),
                tags: [t('공정 분배', 'Fair Mining'), t('락업 보너스', 'Lockup Bonus'), t('리퍼럴', 'Referral')],
                popular: false,
              },
              {
                icon: '\uD83C\uDFAE', title: t('게임', 'Gaming'),
                desc: t('블랙잭, 바카라, 슬롯, 로또 등 다양한 게임에서 MSUO를 획득하세요.', 'Blackjack, Baccarat, Slots, Lotto — play and earn MSUO with provably fair algorithms.'),
                tags: [t('블랙잭', 'Blackjack'), t('바카라', 'Baccarat'), t('슬롯', 'Slots')],
                popular: true,
              },
              {
                icon: '\uD83D\uDCB0', title: t('지갑 & 거래', 'Wallet & Exchange'),
                desc: t('안전한 다중서명 지갑과 빠른 P2P 거래소로 자산을 자유롭게 관리하세요.', 'Secure multi-signature wallet with instant P2P exchange. Your assets, your control.'),
                tags: [t('P2P 거래', 'P2P Trading'), t('즉시 전송', 'Instant Transfer'), t('다중서명', 'Multi-Sig')],
                popular: false,
              },
              {
                icon: '\uD83D\uDD25', title: t('초기 채굴', 'Early Mining'),
                desc: t('지금 참여하면 10년간 250억 MSUO 채굴 풀에서 공정하게 분배받습니다.', 'Join now and earn from the 25B MSUO mining pool over 10 years. Early adopters benefit most.'),
                tags: [t('40% 채굴자', '40% Miners'), t('60% 조합', '60% Pool'), t('10년 plan', '10-Year Plan')],
                popular: false,
              },
            ].map((card, i) => (
              <div key={i} className="relative bg-msuo-gray overflow-hidden group cursor-pointer border border-white/5 hover:border-msuo-orange/40 transition-all duration-300 hover:-translate-y-1" style={{ boxShadow: '0 20px 40px rgba(255, 94, 0, 0.05)' }}>
                {card.popular && (
                  <div className="absolute top-4 right-4 bg-msuo-orange px-3 py-1.5 z-10">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-msuo-black">{t('인기', 'Popular')}</span>
                  </div>
                )}
                <div className="p-6">
                  <div className="text-4xl mb-4">{card.icon}</div>
                  <h3 className="font-heading text-xl font-bold uppercase tracking-wide text-white mb-3 group-hover:text-msuo-orange transition-colors">{card.title}</h3>
                  <p className="text-xs text-msuo-silver leading-relaxed mb-4">{card.desc}</p>
                  <div className="flex flex-wrap gap-2 mb-5">
                    {card.tags.map((tag, j) => (
                      <span key={j} className="text-[9px] font-semibold uppercase tracking-wider bg-white/5 text-msuo-silver px-2.5 py-1">{tag}</span>
                    ))}
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <span className="text-[10px] text-msuo-silverDark">{t('바로 시작', 'Start Now')}</span>
                    <span className="inline-flex items-center gap-1.5 text-msuo-orange text-xs font-bold uppercase tracking-wider group-hover:gap-3 transition-all">
                      {t('자세히', 'Learn More')}
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Info Bar */}
          <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: '\uD83D\uDD12', title: t('다중서명 보안', 'Multi-Sig Security'), desc: t('콜드 스토리지', 'Cold Storage') },
              { icon: '\u26A1', title: t('즉시 전송', 'Instant Transfer'), desc: t('0.01 OZ 수수료', '0.01 OZ Fee') },
              { icon: '\uD83D\uDCC8', title: t('실시간 시세', 'Live Prices'), desc: t('Binance 연동', 'Binance API') },
              { icon: '\uD83C\uDF10', title: t('다국어 지원', 'Multi-Language'), desc: t('KO/EN/ZH/JA', '4 Languages') },
            ].map((info, i) => (
              <div key={i} className="bg-msuo-gray p-4 flex items-center gap-3 border border-white/5">
                <span className="text-xl">{info.icon}</span>
                <div>
                  <div className="text-xs font-bold text-white">{info.title}</div>
                  <div className="text-[10px] text-msuo-silverDark">{info.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Token Info Section */}
      <section id="token" className="relative py-20 md:py-28 bg-msuo-dark">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-[60px] h-[3px] bg-gradient-to-r from-msuo-orange to-msuo-orangeLight" />
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-msuo-orange">{t('토큰 정보', 'Token Information')}</span>
              </div>
              <h2 className="font-heading text-4xl md:text-5xl font-bold uppercase tracking-tight text-white">
                {t('MSUO', 'MSUO')}<br />{t('토큰 경제', 'Token Economy')}
              </h2>
            </div>
            <p className="text-sm text-msuo-silver max-w-md leading-relaxed">
              {t(
                '총 500억 MSUO가 발행되며, 채굴과 재단 발행으로 공정하게 분배됩니다.',
                'Total 50B MSUO supply allocated between mining rewards and foundation operations over 10 years.'
              )}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { value: '50,000,000,000', label: t('총 발행량', 'Total Supply'), sub: t('MSUO', 'MSUO') },
              { value: '25,000,000,000', label: t('채굴 할당량', 'Mining Allocation'), sub: t('10년간 분배 (50%)', '10-Year Distribution (50%)') },
              { value: '25,000,000,000', label: t('재단 발행량', 'Foundation Issue'), sub: t('생태계 운영 (50%)', 'Ecosystem Operations (50%)') },
            ].map((token, i) => (
              <div key={i} className="bg-msuo-gray p-6 border border-white/5 hover:border-msuo-orange/30 transition-all">
                <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-msuo-silverDark mb-2">{token.label}</div>
                <div className="font-heading text-2xl md:text-3xl font-bold text-white mb-1" style={{ background: 'linear-gradient(135deg, #FF5E00, #FF7A2E)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{token.value}</div>
                <div className="text-xs text-msuo-silverDark">{token.sub}</div>
              </div>
            ))}
          </div>

          {/* Mining Distribution */}
          <div className="mt-6 grid grid-cols-2 gap-4">
            <div className="bg-msuo-gray p-6 border border-white/5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-msuo-orange/20 flex items-center justify-center rounded-full">
                  <span className="text-msuo-orange font-bold text-sm">40%</span>
                </div>
                <div>
                  <div className="text-sm font-bold text-white">{t('채굴자 보상', 'Miner Reward')}</div>
                  <div className="text-[10px] text-msuo-silverDark">{t('실제 채굴 참여자', 'Active Mining Participants')}</div>
                </div>
              </div>
              <div className="w-full bg-msuo-mid rounded-full h-2">
                <div className="bg-msuo-orange h-2 rounded-full" style={{ width: '40%' }} />
              </div>
            </div>
            <div className="bg-msuo-gray p-6 border border-white/5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-msuo-orange/20 flex items-center justify-center rounded-full">
                  <span className="text-msuo-orange font-bold text-sm">60%</span>
                </div>
                <div>
                  <div className="text-sm font-bold text-white">{t('조합 풀', 'Mining Pool')}</div>
                  <div className="text-[10px] text-msuo-silverDark">{t('재단 + 추천인 보상', 'Foundation + Referral Rewards')}</div>
                </div>
              </div>
              <div className="w-full bg-msuo-mid rounded-full h-2">
                <div className="bg-msuo-orange h-2 rounded-full" style={{ width: '60%' }} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Community Section */}
      <section id="community" className="relative py-20 md:py-28 bg-msuo-black">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-[60px] h-[3px] bg-gradient-to-r from-msuo-orange to-msuo-orangeLight" />
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-msuo-orange">{t('신뢰 & 커뮤니티', 'Trust & Community')}</span>
              </div>
              <h2 className="font-heading text-4xl md:text-5xl font-bold uppercase tracking-tight text-white">
                {t('함께 성장하는', 'Growing')}<br />{t('생태계', 'Together')}
              </h2>
            </div>
            <p className="text-sm text-msuo-silver max-w-md leading-relaxed">
              {t(
                '수천 명의 사용자가 MSUO 생태계에서 함께 성장하고 있습니다. 투명하고 공정한 시스템을 경험하세요.',
                'Thousands of users are growing together in the MSUO ecosystem. Experience transparent and fair digital finance.'
              )}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            {[
              {
                name: t('김민수', 'Alex Kim'),
                role: t('소프트웨어 엔지니어 · 28세', 'Software Engineer · 28 yrs'),
                text: t(
                  '"MSUO의 채굴 시스템이 정말 공정해요. 리퍼럴 보너스도 좋고, 게임에서도 MSUO를 벌 수 있어서 매일 재밌게 참여하고 있습니다."',
                  '"MSUO\'s mining system is genuinely fair. The referral bonuses are great, and earning MSUO through games makes it fun to participate every day."'
                ),
                tags: [t('채굴', 'Mining'), t('게임', 'Gaming')],
              },
              {
                name: t('이하나', 'Sarah Lee'),
                role: t('마케팅 디렉터 · 32세', 'Marketing Director · 32 yrs'),
                text: t(
                  '"P2P 거래가 정말 빠르고 안전해요. 수수료도 0.01 OZ밖에 안 해서 다른 거래소보다 훨씬 경제적입니다."',
                  '"P2P trading is incredibly fast and secure. At only 0.01 OZ fee, it\'s far more economical than other exchanges."'
                ),
                tags: [t('거래', 'Trading'), t('지갑', 'Wallet')],
              },
              {
                name: t('박준혁', 'Ryan Park'),
                role: t('프리랜서 · 35세', 'Freelancer · 35 yrs'),
                text: t(
                  '"락업 스테이킹으로 추가 수익을 얻고 있어요. 10년 채굴 계획이라 장기적으로 안정적인 투자가 가능합니다."',
                  '"Earning additional income through lockup staking. The 10-year mining plan allows for stable long-term investment."'
                ),
                tags: [t('스테이킹', 'Staking'), t('락업', 'Lockup')],
              },
            ].map((story, i) => (
              <div key={i} className="bg-msuo-gray p-6 border border-white/5 hover:border-msuo-orange/30 transition-all group">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-msuo-orange/20 border border-msuo-orange/30 flex items-center justify-center rounded-full">
                    <span className="font-heading font-bold text-msuo-orange text-sm">{story.name.charAt(0)}</span>
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">{story.name}</div>
                    <div className="text-[10px] text-msuo-silverDark">{story.role}</div>
                  </div>
                </div>
                <p className="text-xs text-msuo-silver leading-relaxed italic mb-4">{story.text}</p>
                <div className="flex gap-2">
                  {story.tags.map((tag, j) => (
                    <span key={j} className="text-[9px] font-semibold uppercase tracking-wider bg-msuo-orange/10 text-msuo-orange px-2 py-0.5">{tag}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 md:py-28 bg-msuo-black overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-5">
          <img src="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=1000&q=80" alt="" className="w-full h-full object-cover" style={{ filter: 'grayscale(100%)' }} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-6">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-[60px] h-[3px] bg-gradient-to-r from-msuo-orange to-msuo-orangeLight" />
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-msuo-orange">{t('지금 시작', 'Start Today')}</span>
              </div>
              <h2 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold uppercase tracking-tight text-white mb-6">
                {t('무료로', 'Your First')}<br />
                <span className="text-msuo-orange">{t('시작하세요', 'Wallet Is Free')}</span>
              </h2>
              <p className="text-sm text-msuo-silver leading-relaxed mb-8 max-w-lg">
                {t(
                  '간단한 회원가입으로 MSUO 생태계에 참여하세요. 채굴, 게임, 거래 — 모든 기능을 무료로 이용할 수 있습니다.',
                  'Simple sign-up to join the MSUO ecosystem. Mining, gaming, trading — all features available for free. No credit card required.'
                )}
              </p>

              <div className="grid grid-cols-2 gap-3 mb-8">
                {[
                  t('무료 지갑 생성', 'Free Wallet Creation'),
                  t('즉시 채굴 시작', 'Start Mining Instantly'),
                  t('게임으로 보상 획득', 'Earn Through Games'),
                  t('P2P 거래소 이용', 'P2P Exchange Access'),
                ].map((benefit, i) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <div className="w-6 h-6 bg-msuo-orange/20 flex items-center justify-center flex-shrink-0">
                      <svg className="w-3 h-3 text-msuo-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                    </div>
                    <span className="text-xs text-msuo-silverLight">{benefit}</span>
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-4 pt-6 border-t border-white/5">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map(n => (
                    <div key={n} className="w-8 h-8 rounded-full border-2 border-msuo-black bg-msuo-gray flex items-center justify-center text-[8px] font-bold text-msuo-silver">
                      U{n}
                    </div>
                  ))}
                  <div className="w-8 h-8 rounded-full border-2 border-msuo-black bg-msuo-orange flex items-center justify-center">
                    <span className="text-[8px] font-bold text-msuo-black">2.4K</span>
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1 mb-0.5">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="w-3 h-3 text-msuo-orange" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
                    ))}
                    <span className="text-xs font-bold text-white ml-1">4.9</span>
                  </div>
                  <div className="text-[10px] text-msuo-silverDark">{t('사용자 만족도', 'User Satisfaction')}</div>
                </div>
              </div>
            </div>

            {/* CTA Card */}
            <div className="bg-msuo-gray p-6 md:p-8 border border-white/5">
              <h3 className="font-heading text-xl font-bold uppercase tracking-wide text-white mb-1">{t('무료 지갑 만들기', 'Create Free Wallet')}</h3>
              <p className="text-xs text-msuo-silverDark mb-6">{t('간단한 회원가입으로 바로 시작하세요.', 'Sign up now and start your MSUO journey.')}</p>

              <div className="space-y-4">
                <button onClick={() => { setAuthMode('register'); setIsAuthModalOpen(true); }} className="w-full bg-msuo-orange hover:bg-msuo-orangeLight text-msuo-black text-xs font-bold uppercase tracking-wider px-8 py-4 transition-all duration-200 flex items-center justify-center gap-2">
                  <span>{t('무료 회원가입', 'Create Free Account')}</span>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                </button>
                <Link href="/whitepaper" className="w-full border border-white/10 hover:border-msuo-orange/50 text-white text-xs font-bold uppercase tracking-wider px-8 py-4 transition-all duration-200 flex items-center justify-center gap-2 hover:bg-white/5">
                  <span>{t('백서 읽어보기', 'Read Whitepaper')}</span>
                </Link>
                <p className="text-[10px] text-msuo-silverDark text-center">{t('회원가입은 무료입니다. 신용카드 불필요.', 'Sign up is free. No credit card required.')}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="relative py-16 md:py-20 bg-msuo-dark border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-4 gap-6">
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <svg className="w-4 h-4 text-msuo-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-msuo-silver">{t('플랫폼', 'Platform')}</span>
              </div>
              <p className="text-sm text-white font-semibold mb-1">MSUO Coin Foundation</p>
              <p className="text-xs text-msuo-silver leading-relaxed">
                {t('디지털 자산 생태계 플랫폼', 'Digital Asset Ecosystem Platform')}
              </p>
            </div>
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <svg className="w-4 h-4 text-msuo-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-msuo-silver">{t('서비스', 'Services')}</span>
              </div>
              <div className="space-y-1.5">
                {[
                  t('채굴 & 스테이킹', 'Mining & Staking'),
                  t('P2P 거래소', 'P2P Exchange'),
                  t('게임 플랫폼', 'Gaming Platform'),
                ].map((item, i) => (
                  <div key={i} className="text-xs text-white">{item}</div>
                ))}
              </div>
            </div>
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <svg className="w-4 h-4 text-msuo-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-msuo-silver">{t('문서', 'Resources')}</span>
              </div>
              <div className="space-y-1.5">
                <Link href="/whitepaper" className="block text-xs text-msuo-orange hover:underline">{t('백서', 'Whitepaper')}</Link>
                <Link href="/about" className="block text-xs text-msuo-silver hover:text-white transition-colors">{t('소개', 'About')}</Link>
                <Link href="/contact" className="block text-xs text-msuo-silver hover:text-white transition-colors">{t('문의', 'Contact')}</Link>
              </div>
            </div>
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <svg className="w-4 h-4 text-msuo-orange" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" /></svg>
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-msuo-silver">{t('링크', 'Links')}</span>
              </div>
              <div className="flex gap-2">
                {[
                  { label: 'TW', href: '#' },
                  { label: 'TG', href: '#' },
                  { label: 'GH', href: '#' },
                  { label: 'DC', href: '#' },
                ].map((social, i) => (
                  <a key={i} href={social.href} className="w-10 h-10 border border-white/10 flex items-center justify-center hover:bg-msuo-orange hover:border-msuo-orange hover:text-msuo-black text-msuo-silver transition-all text-[10px] font-bold">
                    {social.label}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-8 bg-msuo-black border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <img src="/icons/logo.jpg" alt="MSUO" className="w-7 h-7 object-contain" />
              <span className="font-heading font-bold text-sm tracking-wider text-white uppercase">MSUO</span>
              <span className="text-[10px] text-msuo-silverDark ml-2">&copy; {new Date().getFullYear()} MSUO Foundation</span>
            </div>
            <div className="flex items-center gap-6">
              <Link href="/whitepaper" className="text-[10px] uppercase tracking-wider text-msuo-silverDark hover:text-white transition-colors">{t('백서', 'Whitepaper')}</Link>
              <Link href="/contact" className="text-[10px] uppercase tracking-wider text-msuo-silverDark hover:text-white transition-colors">{t('문의', 'Contact')}</Link>
              <Link href="/terms" className="text-[10px] uppercase tracking-wider text-msuo-silverDark hover:text-white transition-colors">{t('이용약관', 'Terms')}</Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Global Styles */}
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 20px rgba(255, 94, 0, 0.3); }
          50% { box-shadow: 0 0 40px rgba(255, 94, 0, 0.6); }
        }
        .animate-fade-in-up {
          opacity: 0;
          animation: fade-in-up 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        ::selection { background: #FF5E00; color: #0A0A0A; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #0A0A0A; }
        ::-webkit-scrollbar-thumb { background: #FF5E00; border-radius: 3px; }
      `}} />

      {/* Auth Modal */}
      {isAuthModalOpen && (
        <AuthModal
          mode={authMode}
          onClose={() => setIsAuthModalOpen(false)}
          onModeChange={setAuthMode}
        />
      )}
    </div>
  );
}

// Auth Modal 컴포넌트 (기존 재사용)
function AuthModal({
  mode,
  onClose,
  onModeChange
}: {
  mode: 'login' | 'register';
  onClose: () => void;
  onModeChange: (mode: 'login' | 'register') => void;
}) {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    if (mode === 'register' && formData.password !== formData.confirmPassword) {
      setError('비밀번호가 일치하지 않습니다.');
      setLoading(false);
      return;
    }

    try {
      const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
      let body;
      if (mode === 'login') {
        const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.username.trim());
        body = isEmail
          ? { email: formData.username.trim(), password: formData.password }
          : { username: formData.username.trim(), password: formData.password };
      } else {
        body = { username: formData.username.trim(), email: formData.email.trim(), password: formData.password };
      }

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (data.ok) {
        setSuccess(mode === 'login' ? '로그인 성공!' : '회원가입 성공!');
        setTimeout(() => {
          window.location.href = '/';
        }, 1500);
      } else {
        setError(data.error || '오류가 발생했습니다.');
      }
    } catch {
      setError('네트워크 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 animate-fade-in-up" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }} style={{ backdropFilter: 'blur(4px)' }}>
      <div className="w-full max-w-md rounded-xl bg-msuo-gray border border-white/10 shadow-2xl overflow-hidden relative">
        <div className="p-8 pb-0">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-heading text-3xl font-bold text-white uppercase">
              {mode === 'login' ? 'Login' : 'Sign Up'}
            </h2>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <div className="flex bg-black/20 rounded-lg p-1 mb-8">
            <button onClick={() => onModeChange('login')} className={`flex-1 py-2.5 rounded-md font-semibold text-xs uppercase tracking-wider transition-all duration-300 ${mode === 'login' ? 'bg-msuo-orange text-msuo-black shadow-lg' : 'text-gray-400 hover:text-white'}`}>
              {mode === 'login' ? '\uB85C\uADF8\uC778' : 'Login'}
            </button>
            <button onClick={() => onModeChange('register')} className={`flex-1 py-2.5 rounded-md font-semibold text-xs uppercase tracking-wider transition-all duration-300 ${mode === 'register' ? 'bg-msuo-orange text-msuo-black shadow-lg' : 'text-gray-400 hover:text-white'}`}>
              {mode === 'register' ? '\uD68C\uC6D0\uAC00\uC785' : 'Sign Up'}
            </button>
          </div>
        </div>

        <div className="p-8 pt-0">
          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm font-medium flex items-center gap-2">
                <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                {error}
              </div>
            )}

            {success && (
              <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400 text-sm font-medium flex items-center gap-2">
                <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                {success}
              </div>
            )}

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-msuo-silver mb-1.5 ml-1">
                {mode === 'login' ? 'Username or Email' : 'Username'}
              </label>
              <input type="text" value={formData.username} onChange={(e) => setFormData({...formData, username: e.target.value})} className="w-full px-4 py-3.5 bg-black/20 border border-white/10 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-msuo-orange/50 focus:border-msuo-orange transition-all" placeholder={mode === 'login' ? '\uC544\uC774\uB514 \uB610\uB294 \uC774\uBA54\uC77C' : '\uC544\uC774\uB514'} required />
            </div>

            {mode === 'register' && (
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-msuo-silver mb-1.5 ml-1">Email</label>
                <input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-3.5 bg-black/20 border border-white/10 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-msuo-orange/50 focus:border-msuo-orange transition-all" placeholder="example@email.com" required />
              </div>
            )}

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-msuo-silver mb-1.5 ml-1">Password</label>
              <div className="relative">
                <input type={showPassword ? 'text' : 'password'} value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} className="w-full px-4 py-3.5 bg-black/20 border border-white/10 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-msuo-orange/50 focus:border-msuo-orange transition-all" placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" required />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors text-sm font-medium">
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>

            {mode === 'register' && (
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-msuo-silver mb-1.5 ml-1">Confirm Password</label>
                <input type="password" value={formData.confirmPassword} onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})} className="w-full px-4 py-3.5 bg-black/20 border border-white/10 rounded-lg text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-msuo-orange/50 focus:border-msuo-orange transition-all" placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" required />
              </div>
            )}

            <button type="submit" disabled={loading} className="w-full py-4 bg-msuo-orange hover:bg-msuo-orangeLight text-msuo-black font-bold rounded-lg shadow-lg transform hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-xs uppercase tracking-wider">
              {loading ? (mode === 'login' ? '\uB85C\uADF8\uC778 \uC911...' : '\uACC4\uC815 \uC0DD\uC131 \uC911...') : (mode === 'login' ? '\uB85C\uADF8\uC778\uD558\uAE30' : '\uD68C\uC6D0\uAC00\uC785\uD558\uAE30')}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
