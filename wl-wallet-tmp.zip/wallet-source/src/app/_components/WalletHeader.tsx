'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { CompanyBrand } from '@/components/CompanyBrand';
import { cn } from '@/lib/utils';

type NavItem = {
  label: string;
  href: string;
  disabled?: boolean;
  icon?: string;
  section?: string;
};

export default function WalletHeader() {
  const pathname = usePathname() || '/';
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [username, setUsername] = useState('M');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userBalance, setUserBalance] = useState<number>(0);
  const profileMenuRef = useRef<HTMLDivElement>(null);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const fetchUserInfo = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.data?.users) {
          setUsername(data.data.users.username || 'M');
          setUserBalance(data.data.users.personalCoin || 0);
          setIsLoggedIn(true);
        }
      }
    } catch (error) {
      console.error('사용자 정보 조회 실패:', error);
    }
  };

  useEffect(() => {
    fetchUserInfo();
  }, []);

  const items: NavItem[] = [
    { label: '지갑', href: '/', icon: 'account_balance_wallet', section: 'main' },
    { label: '전송', href: '/transfer', icon: 'send', section: 'main' },
    { label: '거래내역', href: '/transactions', icon: 'receipt_long', section: 'main' },
    { label: '내 프로필', href: '/my-profile', icon: 'person', section: 'main' },
    { label: '게임', href: '/games', icon: 'sports_esports', section: 'services' },
    { label: '스테이킹', href: '/staking', icon: 'account_balance', section: 'services' },
    { label: '채굴', href: '/mining', icon: 'diamond', section: 'services' },
    { label: '재단', href: '/about', icon: 'business', section: 'info' },
    { label: '백서', href: '/whitepaper', icon: 'description', section: 'info' },
    { label: '문의', href: '/contact', icon: 'mail', section: 'info' },
  ];

  // 경로 변경 시 메뉴 닫기
  useEffect(() => {
    setIsProfileMenuOpen(false);
  }, [pathname]);

  // 외부 클릭 시 메뉴 닫기
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isProfileMenuOpen && profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) {
        setIsProfileMenuOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsProfileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isProfileMenuOpen]);

  // 섹션별로 그룹화
  const groupedItems = items.reduce((acc, item) => {
    const section = item.section || 'other';
    if (!acc[section]) acc[section] = [];
    acc[section].push(item);
    return acc;
  }, {} as Record<string, NavItem[]>);

  const sectionLabels: Record<string, string> = {
    main: '메인',
    services: '서비스',
    info: '정보',
  };

  return (
    <header className={cn(
      'relative z-40 flex items-center justify-between',
      'px-4 sm:px-6 py-3',
      'bg-slate-900/50 backdrop-blur-md',
      'border-b border-white/10',
      'sticky top-0'
    )}>
      {/* 로고 */}
      <Link 
        href="/" 
        className="flex items-center gap-3 text-white hover:opacity-80 transition-all duration-200 group"
      >
        <div className="relative">
          <img
            src="/icons/logo.jpg"
            alt="MSUO"
            width={40}
            height={40}
            className="h-10 w-10 object-contain rounded-full ring-2 ring-white/10 group-hover:ring-white/20 transition-all"
          />
          <div className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-md bg-blue-500/30" />
        </div>
        <span className="text-white text-lg font-bold leading-tight tracking-tight hidden sm:block">
          MSUO
        </span>
      </Link>

      {/* 우측 컨트롤 */}
      <div className="flex items-center gap-3">
        <LanguageSwitcher />
        
        {/* 프로필 드롭다운 */}
        <div className="relative" ref={profileMenuRef}>
          <button
            onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
            className={cn(
              'relative flex items-center justify-center',
              'w-10 h-10 rounded-full',
              'bg-gradient-to-br from-blue-500 to-purple-600',
              'border-2 border-white/10',
              'hover:ring-2 hover:ring-blue-400/50 hover:ring-offset-2 hover:ring-offset-slate-900',
              'transition-all duration-200',
              'cursor-pointer',
              isProfileMenuOpen && 'ring-2 ring-blue-400/50 ring-offset-2 ring-offset-slate-900'
            )}
            aria-label="메뉴 열기"
            aria-expanded={isProfileMenuOpen}
          >
            <span className="text-white font-bold text-sm">
              {username ? username.charAt(0).toUpperCase() : 'M'}
            </span>
            {/* 온라인 상태 표시 */}
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-500 border-2 border-slate-900 animate-pulse" />
          </button>

          {/* 드롭다운 메뉴 */}
          {isProfileMenuOpen && (
            <div className="absolute right-0 top-14 w-72 animate-scale-in origin-top-right">
              <div className={cn(
                'bg-slate-800/95 backdrop-blur-xl',
                'border border-white/10 rounded-2xl',
                'shadow-dropdown overflow-hidden'
              )}>
                {/* 사용자 정보 헤더 */}
                <div className="p-4 border-b border-white/10 bg-gradient-to-r from-blue-500/10 to-purple-500/10">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                      {username ? username.charAt(0).toUpperCase() : 'M'}
                    </div>
                    <div className="flex-1 min-w-0">\n                      <p className="text-white font-semibold truncate">{isLoggedIn ? username : '게스트'}</p>
                      <div className="flex items-center gap-1">
                        <span className="material-symbols-outlined text-xs text-blue-400">paid</span>
                        <p className="text-blue-400 text-xs font-medium">
                          {userBalance.toFixed(2)} MSUO
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-green-500/20">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                      <span className="text-xs text-green-400">온라인</span>
                    </div>
                  </div>
                </div>

                {/* 네비게이션 메뉴 */}
                <nav className="max-h-[50vh] overflow-y-auto py-2">
                  {Object.entries(groupedItems).map(([section, sectionItems]) => (
                    <div key={section}>
                      {section !== 'main' && (
                        <div className="px-4 py-2">
                          <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">
                            {sectionLabels[section] || section}
                          </span>
                        </div>
                      )}
                      {sectionItems.map((item) => {
                        const isActive = item.href === '/' ? pathname === '/' : pathname.startsWith(item.href);
                        return (
                          <Link
                            key={item.href}
                            href={item.href}
                            className={cn(
                              'flex items-center gap-3 px-4 py-2.5 text-sm transition-colors',
                              isActive
                                ? 'text-blue-400 bg-blue-500/10'
                                : 'text-gray-300 hover:text-white hover:bg-white/5'
                            )}
                          >
                            <span className="material-symbols-outlined text-lg">
                              {item.icon || 'circle'}
                            </span>
                            {item.label}
                            {isActive && (
                              <span className="ml-auto">
                                <span className="material-symbols-outlined text-sm">check</span>
                              </span>
                            )}
                          </Link>
                        );
                      })}
                      {section !== 'info' && (
                        <div className="my-1 mx-4 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                      )}
                    </div>
                  ))}
                </nav>

                {/* 로그아웃 */}
                <div className="border-t border-white/10 p-2">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-xl transition-colors"
                  >
                    <span className="material-symbols-outlined text-lg">logout</span>
                    로그아웃
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
