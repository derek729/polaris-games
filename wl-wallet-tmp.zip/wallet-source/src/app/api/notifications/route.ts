import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    const notifications = await prisma.reward_logs.findMany({
      where: {
        ...(userId && { userId }),
        description: { contains: 'ALERT' },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    const formattedNotifications = notifications.map((log) => ({
      id: log.id,
      title: log.description?.split(' | ')[1] || '알림',
      message: log.description || '',
      date: log.createdAt.toISOString(),
      read: log.isPaid,
    }));

    return NextResponse.json({
      ok: true,
      notifications: formattedNotifications,
    });
  } catch (error) {
    console.error('알림 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: '알림 조회에 실패했습니다.' },
      { status: 500 }
    );
  }
}
