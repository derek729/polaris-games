import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.reward_logs.update({
      where: { id: params.id },
      data: { isPaid: true },
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('알림 읽음 처리 실패:', error);
    return NextResponse.json(
      { ok: false, error: '읽음 처리에 실패했습니다.' },
      { status: 500 }
    );
  }
}
