import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-dynamic';

/**
 * GET /api/health
 * 시스템 헬스 체크 (모니터링용)
 */
export async function GET() {
  const startTime = Date.now();
  const checks = {
    status: 'healthy' as 'healthy' | 'unhealthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    checks: {
      database: 'unknown' as 'ok' | 'error',
      memory: 'unknown' as 'ok' | 'warning',
    },
    version: process.env.npm_package_version || '1.0.0',
    environment: process.env.NODE_ENV || 'development',
  };

  // 데이터베이스 연결 체크
  try {
    await prisma.$queryRaw`SELECT 1`;
    checks.checks.database = 'ok';
  } catch (error) {
    checks.checks.database = 'error';
    checks.status = 'unhealthy';
  }

  // 메모리 사용량 체크
  const memoryUsage = process.memoryUsage();
  const heapUsedMB = memoryUsage.heapUsed / 1024 / 1024;
  const heapTotalMB = memoryUsage.heapTotal / 1024 / 1024;

  if (heapUsedMB / heapTotalMB > 0.9) {
    checks.checks.memory = 'warning';
  } else {
    checks.checks.memory = 'ok';
  }

  const responseTime = Date.now() - startTime;

  return NextResponse.json({
    ...checks,
    responseTime: `${responseTime}ms`,
    memory: {
      heapUsed: `${heapUsedMB.toFixed(2)}MB`,
      heapTotal: `${heapTotalMB.toFixed(2)}MB`,
      rss: `${(memoryUsage.rss / 1024 / 1024).toFixed(2)}MB`,
    },
  }, {
    status: checks.status === 'healthy' ? 200 : 503,
  });
}
