import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Decimal } from '@prisma/client/runtime/library';

export const dynamic = 'force-dynamic';

/**
 * POST /api/game/result
 * 게임 결과 처리 및 수익 분배
 *
 * 분배 구조:
 * - 잃은 금액의 50% → 잭팟
 * - 잃은 금액의 25% → 재단 (SUPER_ADMIN)
 * - 잃은 금액의 25% → 노드 수익 풀
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return Response.json({
        ok: false,
        error: { code: 'UNAUTHORIZED', message: 'Authentication required' }
      }, { status: 401 });
    }

    const body = await request.json();
    const { gameId, betAmount, winAmount, playResult } = body;

    if (!gameId || betAmount === undefined) {
      return Response.json({
        ok: false,
        error: { code: 'MISSING_PARAMS', message: 'Missing required parameters' }
      }, { status: 400 });
    }

    // MSUP → MSUO 변환 (1:10 비율)
    // 게임에서 MSUP 단위로 받지만, 실제 코인 계산은 MSUO로
    const betAmountMsup = new Decimal(betAmount);
    const winAmountMsup = new Decimal(winAmount || 0);

    const betAmountDecimal = betAmountMsup.div(10);
    const winAmountDecimal = winAmountMsup.div(10);

    // 손익 계산
    const profitOrLoss = winAmountDecimal.sub(betAmountDecimal);

    console.log(`[Game Result] Bet: ${betAmountMsup} MSUP (${betAmountDecimal} MSUO) | Win: ${winAmountMsup} MSUP (${winAmountDecimal} MSUO)`);

    // 승리 또는 무승부인 경우 분배 없음
    if (profitOrLoss.gte(0)) {
      return Response.json({
        ok: true,
        data: {
          profitOrLoss: profitOrLoss.toString(),
          message: 'Win or break-even - no distribution needed',
        },
        message: 'Game result processed'
      });
    }

    // 손실 금액 (절대값)
    const lossAmount = profitOrLoss.abs();

    // 분배 금액 계산
    const jackpotAmount = lossAmount.mul(0.5);      // 50% → 잭팟
    const foundationAmount = lossAmount.mul(0.25);   // 25% → 재단
    const nodePoolAmount = lossAmount.mul(0.25);     // 25% → 노드 풀

    // 트랜잭션으로 분배 처리
    await prisma.$transaction(async (tx) => {
      // 1. 게임 손실 분배 기록 생성
      await tx.game_loss_distributions.create({
        data: {
          userId: user.id,
          gameId,
          lossAmount,
          jackpotAmount,
          foundationAmount,
          nodePoolAmount,
          playedAt: new Date(),
          metadata: {
            betAmount: betAmountDecimal.toString(),
            winAmount: winAmountDecimal.toString(),
            playResult,
          },
        },
      });

      // 2. 잭팟 적립
      const jackpot = await tx.jackpots.findFirst({
        where: {
          type: 'GLOBAL',
          isActive: true,
        },
      });

      if (jackpot) {
        await tx.jackpots.update({
          where: { id: jackpot.id },
          data: {
            currentAmount: { increment: jackpotAmount },
            updatedAt: new Date(),
          },
        });
      } else {
        await tx.jackpots.create({
          data: {
            type: 'GLOBAL',
            currentAmount: jackpotAmount,
            seedAmount: new Decimal(0),
            contributionRate: new Decimal(0.5),
            isActive: true,
          },
        });
      }

      // 3. 재단 지갑에 25% 지급 (personalCoin)
      const foundationWallet = await tx.users.findFirst({
        where: { role: 'SUPER_ADMIN' },
      });

      if (foundationWallet) {
        await tx.users.update({
          where: { id: foundationWallet.id },
          data: {
            personalCoin: { increment: foundationAmount },
          },
        });
      }

      // 4. 노드 수익 풀에 25% 적립
      let nodePool = await tx.node_revenue_pools.findFirst({
        where: { isActive: true },
      });

      if (!nodePool) {
        nodePool = await tx.node_revenue_pools.create({
          data: {
            totalAmount: nodePoolAmount,
            distributedAmount: new Decimal(0),
            pendingAmount: nodePoolAmount,
            isActive: true,
            periodStart: new Date(),
          },
        });
      } else {
        nodePool = await tx.node_revenue_pools.update({
          where: { id: nodePool.id },
          data: {
            totalAmount: { increment: nodePoolAmount },
            pendingAmount: { increment: nodePoolAmount },
            updatedAt: new Date(),
          },
        });
      }
    });

    return Response.json({
      ok: true,
      data: {
        lossAmount: lossAmount.toString(),
        distributions: {
          jackpot: jackpotAmount.toString(),
          foundation: foundationAmount.toString(),
          nodePool: nodePoolAmount.toString(),
        },
        message: 'Game loss distributed successfully',
      },
      message: 'Game result processed and distributed'
    });
  } catch (error) {
    console.error('[Game Result] Error:', error);
    return Response.json({
      ok: false,
      error: {
        code: 'GAME_RESULT_FAILED',
        message: error instanceof Error ? error.message : 'Failed to process game result'
      }
    }, { status: 500 });
  }
}

/**
 * GET /api/game/result
 * 사용자의 게임 결과 내역 조회
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return Response.json({
        ok: false,
        error: { code: 'UNAUTHORIZED', message: 'Authentication required' }
      }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50', 10);
    const offset = parseInt(searchParams.get('offset') || '0', 10);

    const distributions = await prisma.game_loss_distributions.findMany({
      where: { userId: user.id },
      orderBy: { playedAt: 'desc' },
      take: limit,
      skip: offset,
    });

    const total = await prisma.game_loss_distributions.count({
      where: { userId: user.id },
    });

    // 총 손실 및 분배 합계
    const stats = await prisma.game_loss_distributions.aggregate({
      where: { userId: user.id },
      _sum: {
        lossAmount: true,
        jackpotAmount: true,
        foundationAmount: true,
        nodePoolAmount: true,
      },
    });

    return Response.json({
      ok: true,
      data: {
        distributions: distributions.map((d) => ({
          id: d.id,
          gameId: d.gameId,
          lossAmount: d.lossAmount.toString(),
          jackpotAmount: d.jackpotAmount.toString(),
          foundationAmount: d.foundationAmount.toString(),
          nodePoolAmount: d.nodePoolAmount.toString(),
          playedAt: d.playedAt,
        })),
        stats: {
          totalLoss: stats._sum.lossAmount?.toString() || '0',
          totalJackpot: stats._sum.jackpotAmount?.toString() || '0',
          totalFoundation: stats._sum.foundationAmount?.toString() || '0',
          totalNodePool: stats._sum.nodePoolAmount?.toString() || '0',
        },
        pagination: {
          total,
          limit,
          offset,
        },
      },
      message: 'Game result history fetched'
    });
  } catch (error) {
    console.error('[Game Result] Error:', error);
    return Response.json({
      ok: false,
      error: {
        code: 'FETCH_FAILED',
        message: error instanceof Error ? error.message : 'Failed to fetch game results'
      }
    }, { status: 500 });
  }
}
