import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { Decimal } from '@prisma/client/runtime/library';

export const dynamic = 'force-dynamic';

/**
 * POST /api/jackpot/claim
 * 잭팟 당첨 금액 전체 지급 (100%)
 *
 * 올 7이 나온 사용자가 잭팟 풀의 100% 전체를 가져감
 * (게임 질 때 손실의 50%만 적립되므로, 당첨 시 전체 지급)
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({
        ok: false,
        error: { code: 'UNAUTHORIZED', message: '로그인이 필요합니다.' }
      }, { status: 401 });
    }

    // 잭팟 조회
    const jackpot = await prisma.jackpots.findFirst({
      where: {
        type: 'GLOBAL',
        isActive: true,
      },
    });

    if (!jackpot || jackpot.currentAmount.lessThanOrEqualTo(0)) {
      return NextResponse.json({
        ok: false,
        error: { code: 'NO_JACKPOT', message: '잭팟 금액이 없습니다.' }
      }, { status: 400 });
    }

    const currentAmount = jackpot.currentAmount;
    // 100% 전체 지급
    const payoutAmount = currentAmount;
    const remainingAmount = new Decimal(0);

    // 트랜잭션으로 지급 처리
    const result = await prisma.$transaction(async (tx) => {
      // 1. 사용자 잔액에 50% 지급
      const updatedUser = await tx.users.update({
        where: { id: user.id },
        data: {
          personalCoin: { increment: payoutAmount },
        },
        select: {
          personalCoin: true,
        },
      });

      // 2. 잭팟 업데이트 (50% 남기기)
      const updatedJackpot = await tx.jackpots.update({
        where: { id: jackpot.id },
        data: {
          currentAmount: remainingAmount,
          lastWonAt: new Date(),
          lastWonAmount: payoutAmount,
          lastWonBy: user.id,
          updatedAt: new Date(),
        },
      });

      // 3. 잭팟 당첨 기록
      await tx.jackpot_wins.create({
        data: {
          jackpotId: jackpot.id,
          userId: user.id,
          amount: payoutAmount,
          metadata: {
            payoutPercentage: 100, // 100% 전체 지급
            note: '게임 질 때 손실의 50%만 적립되므로 전체 지급',
          },
        },
      });

      return { updatedUser, updatedJackpot };
    });

    return NextResponse.json({
      ok: true,
      data: {
        jackpotAmount: payoutAmount.toString(),
        newBalance: result.updatedUser.personalCoin.toString(),
        message: `잭팟 ${payoutAmount.toString()} 전체 지급 완료! 🎰`,
      },
    });
  } catch (error) {
    console.error('[Jackpot Claim] Error:', error);
    return NextResponse.json({
      ok: false,
      error: {
        code: 'JACKPOT_CLAIM_FAILED',
        message: error instanceof Error ? error.message : '잭팟 지급 실패',
      }
    }, { status: 500 });
  }
}

/**
 * GET /api/jackpot
 * 현재 잭팟 금액 조회 (공개용)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'GLOBAL';

    const jackpot = await prisma.jackpots.findFirst({
      where: {
        type: type as any,
        isActive: true,
      },
      orderBy: {
        updatedAt: 'desc',
      },
    });

    if (!jackpot) {
      return NextResponse.json({
        ok: true,
        data: {
          globalJackpot: {
            id: null,
            currentAmount: '0',
            seedAmount: '0',
            lastWonAt: null,
            lastWonAmount: null,
          },
        },
      });
    }

    return NextResponse.json({
      ok: true,
      data: {
        globalJackpot: {
          id: jackpot.id,
          currentAmount: jackpot.currentAmount.toString(),
          seedAmount: jackpot.seedAmount.toString(),
          lastWonAt: jackpot.lastWonAt,
          lastWonAmount: jackpot.lastWonAmount?.toString() || null,
          lastWonBy: jackpot.lastWonBy,
        },
      },
    });
  } catch (error) {
    console.error('[Jackpot API] Error:', error);
    return NextResponse.json({
      ok: false,
      error: {
        code: 'JACKPOT_FETCH_FAILED',
        message: error instanceof Error ? error.message : 'Failed to fetch jackpot',
      }
    }, { status: 500 });
  }
}
