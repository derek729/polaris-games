import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole, Prisma } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    console.log('[API] 게임 목록 조회 요청');

    const { searchParams } = new URL(request.url);
    const includeInactive = searchParams.get('includeInactive') === 'true';

    // 게임 목록 조회
    const games = await prisma.games.findMany({
      include: {
        _count: {
          select: {
            game_shares: true,
            game_share_purchases: true
          }
        },
        game_shares: {
          select: {
            id: true,
            sharePercentage: true,
            price: true,
            totalShares: true,
            availableShares: true,
            soldShares: true,
            isActive: true
          }
        },
        game_share_purchases: {
          select: {
            id: true,
            userId: true,
            shareCount: true,
            purchasePrice: true,
            status: true,
            paymentPeriod: true
          },
          take: 5,
          orderBy: {
            purchasedAt: 'desc'
          }
        }
      },
      where: includeInactive ? {} : { isActive: true },
      orderBy: {
        createdAt: 'desc'
      }
    });

    // 각 게임에 대한 추가 통계 계산
    const gamesWithStats = await Promise.all(
      games.map(async (game) => {
        const [
          totalRevenue,
          totalSharesSold,
          totalPurchaseAmount,
          activePurchases
        ] = await Promise.all([
          // 총 수익
          prisma.game_revenues.aggregate({
            where: { gameId: game.id },
            _sum: { totalRevenue: true }
          }),

          // 판매된 총 주식 수
          prisma.game_share_purchases.aggregate({
            where: {
              gameId: game.id,
              status: 'ACTIVE'
            },
            _sum: { shareCount: true }
          }),

          // 총 구매 금액
          prisma.game_share_purchases.aggregate({
            where: {
              gameId: game.id,
              status: 'ACTIVE'
            },
            _sum: { purchasePrice: true }
          }),

          // 활성 구매 수
          prisma.game_share_purchases.count({
            where: {
              gameId: game.id,
              status: 'ACTIVE'
            }
          })
        ]);

        // 미분배 수익 계산
        const unpaidRevenue = await prisma.game_revenues.aggregate({
          where: {
            gameId: game.id,
            isDistributed: false
          },
          _sum: { totalRevenue: true }
        });

        return {
          ...game,
          statistics: {
            totalRevenue: Number(totalRevenue._sum.totalRevenue || 0),
            unpaidRevenue: Number(unpaidRevenue._sum.totalRevenue || 0),
            totalSharesSold: Number(totalSharesSold._sum.shareCount || 0),
            totalPurchaseAmount: Number(totalPurchaseAmount._sum.purchasePrice || 0),
            activePurchases,
            averageSharePrice: totalPurchaseAmount._sum.purchasePrice ?
              Number(totalPurchaseAmount._sum.purchasePrice) / Number(totalSharesSold._sum.shareCount || 1) : 0
          },
          winRate: game.winRate ? Number(game.winRate) : null,
          prizeAmounts: game.prizeAmounts
        };
      })
    );

    return NextResponse.json({
      ok: true,
      message: '게임 목록 조회 완료',
      data: {
        games: gamesWithStats,
        summary: {
          totalGames: gamesWithStats.length,
          activeGames: gamesWithStats.filter(g => g.isActive).length,
          totalRevenue: gamesWithStats.reduce((sum, g) => sum + g.statistics.totalRevenue, 0),
          totalActivePurchases: gamesWithStats.reduce((sum, g) => sum + g.statistics.activePurchases, 0)
        }
      }
    });

  } catch (error) {
    console.error('[API] 게임 목록 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '게임 목록 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const body = await request.json();
    const { name, description, imageUrl, winRate, prizeAmounts, defaultPaymentPeriod } = body;

    // 필수 필드 검증
    if (!name) {
      return NextResponse.json(
        { ok: false, error: { code: 'MISSING_REQUIRED_FIELD', message: '게임 이름은 필수입니다.' } }, { status: 400 });
    }

    console.log('[API] 신규 게임 생성 요청:', name);

    // 신규 게임 생성
    const newGame = await prisma.games.create({
        data: {
        name,
        description,
        imageUrl,
        winRate: winRate ? new Prisma.Decimal(winRate) : null,
        prizeAmounts,
        defaultPaymentPeriod: defaultPaymentPeriod || 'DAILY',
        isActive: true,
        id: crypto.randomUUID(),
        updatedAt: new Date(),
        }
    });

    return NextResponse.json({
      ok: true,
      message: '게임 생성 완료',
      data: {
        games: {
          id: newGame.id,
          name: newGame.name,
          description: newGame.description,
          imageUrl: newGame.imageUrl,
          winRate: newGame.winRate ? Number(newGame.winRate) : null,
          prizeAmounts: newGame.prizeAmounts,
          isActive: newGame.isActive,
          defaultPaymentPeriod: newGame.defaultPaymentPeriod,
          createdAt: newGame.createdAt
        }
      }
    });

  } catch (error) {
    console.error('[API] 게임 생성 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '게임 생성 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}