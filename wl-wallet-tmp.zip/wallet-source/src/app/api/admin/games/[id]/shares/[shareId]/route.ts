import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole, Prisma } from '@prisma/client';

/**
 * 게임 주식 수정
 * PUT /api/admin/games/[id]/game_shares/[shareId]
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string; shareId: string } }
) {
  try {
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { shareId } = params;
    const body = await request.json();
    const { sharePercentage, price, totalShares, isActive } = body;

    // 기존 주식 확인
    const existingShare = await prisma.game_shares.findUnique({
      where: { id: shareId },
      include: {
        games: {
          include: {
            game_shares: {
              where: { isActive: true },
            },
          },
        },
      },
    });

    if (!existingShare) {
      return NextResponse.json(
        {
          ok: false,
          error: '게임 주식을 찾을 수 없습니다.',
        },
        { status: 404 }
      );
    }

    // 업데이트할 데이터 구성
    const updateData: any = {};

    if (sharePercentage !== undefined) {
      if (sharePercentage <= 0 || sharePercentage > 100) {
        return NextResponse.json(
          {
            ok: false,
            error: '지분 비율은 0보다 크고 100 이하여야 합니다.',
          },
          { status: 400 }
        );
      }

      const sharePercentageDecimal = new Prisma.Decimal(sharePercentage).div(100);

      // 기존 지분 총합 확인 (현재 주식 제외)
      const existingTotalPercentage = existingShare.games.game_shares
        .filter(s => s.id !== shareId)
        .reduce((sum, share) => sum.add(share.sharePercentage), new Prisma.Decimal(0));

      const newTotalPercentage = existingTotalPercentage.add(sharePercentageDecimal);
      if (newTotalPercentage.gt(1)) {
        return NextResponse.json(
          {
            ok: false,
            error: `지분 비율이 100%를 초과합니다. (현재: ${existingTotalPercentage.mul(100).toFixed(2)}%, 변경: ${sharePercentage}%)`,
          },
          { status: 400 }
        );
      }

      updateData.sharePercentage = sharePercentageDecimal;
    }

    if (price !== undefined) {
      if (price <= 0) {
        return NextResponse.json(
          {
            ok: false,
            error: '가격은 0보다 커야 합니다.',
          },
          { status: 400 }
        );
      }
      updateData.price = new Prisma.Decimal(price);
    }

    if (totalShares !== undefined) {
      if (totalShares <= 0) {
        return NextResponse.json(
          {
            ok: false,
            error: '총 지분 수는 0보다 커야 합니다.',
          },
          { status: 400 }
        );
      }

      // 판매된 주식 수보다 작을 수 없음
      if (totalShares < existingShare.soldShares) {
        return NextResponse.json(
          {
            ok: false,
            error: `총 지분 수는 판매된 주식 수(${existingShare.soldShares})보다 작을 수 없습니다.`,
          },
          { status: 400 }
        );
      }

      // availableShares 재계산
      updateData.totalShares = totalShares;
      updateData.availableShares = totalShares - existingShare.soldShares;
    }

    if (isActive !== undefined) {
      updateData.isActive = isActive;
    }

    // 주식 업데이트
    const updatedShare = await prisma.game_shares.update({
      where: { id: shareId },
      data: updateData,
    });

    return NextResponse.json({
      ok: true,
      message: '게임 주식이 수정되었습니다.',
      data: {
        share: {
          id: updatedShare.id,
          sharePercentage: Number(updatedShare.sharePercentage) * 100,
          price: Number(updatedShare.price),
          totalShares: updatedShare.totalShares,
          availableShares: updatedShare.availableShares,
          soldShares: updatedShare.soldShares,
          isActive: updatedShare.isActive,
        },
      },
    });
  } catch (error) {
    console.error('[API] 게임 주식 수정 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '게임 주식 수정 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error as Error).message : undefined, } }, { status: 500 });
  }
}

/**
 * 게임 주식 삭제
 * DELETE /api/admin/games/[id]/game_shares/[shareId]
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string; shareId: string } }
) {
  try {
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { shareId } = params;

    // 기존 주식 확인
    const existingShare = await prisma.game_shares.findUnique({
      where: { id: shareId },
      include: {
        game_share_purchases: {
          where: { status: 'ACTIVE' },
        },
      },
    });

    if (!existingShare) {
      return NextResponse.json(
        {
          ok: false,
          error: '게임 주식을 찾을 수 없습니다.',
        },
        { status: 404 }
      );
    }

    // 활성 구매가 있으면 삭제 불가
    if (existingShare.game_share_purchases.length > 0) {
      return NextResponse.json(
        {
          ok: false,
          error: '활성 구매가 있는 주식은 삭제할 수 없습니다. 먼저 비활성화하세요.',
        },
        { status: 400 }
      );
    }

    // 주식 삭제
    await prisma.game_shares.delete({
      where: { id: shareId },
    });

    return NextResponse.json({
      ok: true,
      message: '게임 주식이 삭제되었습니다.',
    });
  } catch (error) {
    console.error('[API] 게임 주식 삭제 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '게임 주식 삭제 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error as Error).message : undefined, } }, { status: 500 });
  }
}

