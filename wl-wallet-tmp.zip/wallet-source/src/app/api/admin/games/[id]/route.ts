import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole, Prisma } from '@prisma/client';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    console.log(`[API] 게임 상세 정보 조회: ${params.id}`);

    // 게임 상세 정보 조회
    const game = await prisma.games.findUnique({
      where: { id: params.id },
      include: {
        game_shares: {
          orderBy: {
            sharePercentage: 'desc'
          }
        },
        game_share_purchases: {
          take: 10,
          orderBy: {
            purchasedAt: 'desc'
          },
          include: {
            users: {
              select: {
                id: true,
                username: true,
                email: true
              }
            }
          }
        },
        game_revenues: {
          take: 5,
          orderBy: {
            periodStart: 'desc'
          }
        },
        _count: {
          select: {
            game_shares: true,
            game_share_purchases: true
          }
        }
      }
    });

    if (!game) {
      return NextResponse.json(
        { ok: false, error: { code: 'NOT_FOUND', message: '게임을 찾을 수 없습니다.' } }, { status: 404 });
    }

    // 추가 통계 계산
    const [
      totalRevenue,
      totalSharesSold,
      activePurchases,
      recentRevenue
    ] = await Promise.all([
      // 총 수익
      prisma.game_revenues.aggregate({
        where: { gameId: game.id },
        _sum: { totalRevenue: true }
      }),

      // 판매된 총 주식 수
      prisma.game_share_purchases.aggregate({
        where: {
          gameId: game.id,
          status: 'ACTIVE'
        },
        _sum: { shareCount: true }
      }),

      // 활성 구매 수
      prisma.game_share_purchases.count({
        where: {
          gameId: game.id,
          status: 'ACTIVE'
        }
      }),

      // 최근 수익 (지난 7일)
      prisma.game_revenues.aggregate({
        where: {
          gameId: game.id,
          periodStart: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        },
        _sum: { totalRevenue: true },
        _count: { id: true }
      })
    ]);

    return NextResponse.json({
      ok: true,
      message: '게임 상세 정보 조회 완료',
      data: {
        games: {
          ...game,
          winRate: game.winRate ? Number(game.winRate) : null,
          game_shares: game.game_shares.map(share => ({
            id: share.id,
            sharePercentage: Number(share.sharePercentage) * 100, // 퍼센트로 변환
            price: Number(share.price),
            totalShares: share.totalShares,
            availableShares: share.availableShares,
            soldShares: share.soldShares,
            isActive: share.isActive,
          })),
          game_share_purchases: game.game_share_purchases.map(purchase => ({
            id: purchase.id,
            userId: purchase.userId,
            shareCount: purchase.shareCount,
            purchasePrice: Number(purchase.purchasePrice),
            status: purchase.status,
            paymentPeriod: purchase.paymentPeriod,
            purchasedAt: purchase.purchasedAt,
            users: purchase.users,
          })),
          statistics: {
            totalRevenue: Number(totalRevenue._sum.totalRevenue || 0),
            totalSharesSold: Number(totalSharesSold._sum.shareCount || 0),
            activePurchases,
            recentRevenue: Number(recentRevenue._sum.totalRevenue || 0),
            recentRevenuePeriods: recentRevenue._count.id
          }
        }
      }
    });

  } catch (error) {
    console.error('[API] 게임 상세 정보 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '게임 정보 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const body = await request.json();
    const { name, description, imageUrl, winRate, prizeAmounts, isActive, defaultPaymentPeriod } = body;

    console.log(`[API] 게임 수정 요청: ${params.id}`);

    // 기존 게임 확인
    const existingGame = await prisma.games.findUnique({
      where: { id: params.id }
    });

    if (!existingGame) {
      return NextResponse.json(
        { ok: false, error: { code: 'NOT_FOUND', message: '게임을 찾을 수 없습니다.' } }, { status: 404 });
    }

    // 게임 정보 업데이트
    const updatedGame = await prisma.games.update({
      where: { id: params.id },
      data: {
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(imageUrl !== undefined && { imageUrl }),
        ...(winRate !== undefined && { winRate: winRate ? new Prisma.Decimal(winRate) : null }),
        ...(prizeAmounts !== undefined && { prizeAmounts }),
        ...(isActive !== undefined && { isActive }),
        ...(defaultPaymentPeriod && { defaultPaymentPeriod })
      }
    });

    return NextResponse.json({
      ok: true,
      message: '게임 정보 수정 완료',
      data: {
        games: {
          ...updatedGame,
          winRate: updatedGame.winRate ? Number(updatedGame.winRate) : null
        }
      }
    });

  } catch (error) {
    console.error('[API] 게임 정보 수정 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '게임 정보 수정 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    console.log(`[API] 게임 삭제 요청: ${params.id}`);

    // 기존 게임 확인
    const existingGame = await prisma.games.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: {
            game_share_purchases: {
              where: { status: 'ACTIVE' }
            }
          }
        }
      }
    });

    if (!existingGame) {
      return NextResponse.json(
        { ok: false, error: { code: 'NOT_FOUND', message: '게임을 찾을 수 없습니다.' } }, { status: 404 });
    }

    // 활성 구매가 있는 경우 삭제 불가
    if (existingGame._count.game_share_purchases > 0) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '활성 구매가 있는 게임은 삭제할 수 없습니다. 먼저 비활성화해주세요.' } }, { status: 400 });
    }

    // 게임 삭제 (cascade로 관련 데이터도 삭제됨)
    await prisma.games.delete({
      where: { id: params.id }
    });

    return NextResponse.json({
      ok: true,
      message: '게임 삭제 완료'
    });

  } catch (error) {
    console.error('[API] 게임 삭제 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '게임 삭제 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}