import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole, Prisma } from '@prisma/client';

/**
 * 게임 주식 목록 조회
 * GET /api/admin/games/[id]/game_shares
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { id: gameId } = params;

    const game_shares = await prisma.game_shares.findMany({
      where: { gameId },
      orderBy: { sharePercentage: 'desc' },
    });

    return successResponse({
      game_shares: game_shares.map(share => ({
        id: share.id,
        gameId: share.gameId,
        sharePercentage: Number(share.sharePercentage) * 100, // 퍼센트로 변환
        price: Number(share.price),
        totalShares: share.totalShares,
        availableShares: share.availableShares,
        soldShares: share.soldShares,
        isActive: share.isActive,
        createdAt: share.createdAt,
        updatedAt: share.updatedAt,
      }))
    });
  } catch (error) {
    console.error('[API] 게임 주식 목록 조회 실패:', error);
    return errorResponse('게임 주식 목록 조회 중 오류가 발생했습니다.', 'SERVER_ERROR');
  }
}

/**
 * 게임 주식 생성
 * POST /api/admin/games/[id]/game_shares
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { id: gameId } = params;
    const body = await request.json();
    const { sharePercentage, price, totalShares } = body;

    // 게임 존재 확인
    const game = await prisma.games.findUnique({
      where: { id: gameId },
      include: {
        game_shares: {
          where: { isActive: true },
        },
      },
    });

    if (!game) {
      return NextResponse.json(
        {
          ok: false,
          error: '게임을 찾을 수 없습니다.',
        },
        { status: 404 }
      );
    }

    // 입력 검증
    if (!sharePercentage || sharePercentage <= 0 || sharePercentage > 100) {
      return NextResponse.json(
        {
          ok: false,
          error: '지분 비율은 0보다 크고 100 이하여야 합니다.',
        },
        { status: 400 }
      );
    }

    if (!price || price <= 0) {
      return NextResponse.json(
        {
          ok: false,
          error: '가격은 0보다 커야 합니다.',
        },
        { status: 400 }
      );
    }

    if (!totalShares || totalShares <= 0) {
      return NextResponse.json(
        {
          ok: false,
          error: '총 지분 수는 0보다 커야 합니다.',
        },
        { status: 400 }
      );
    }

    const sharePercentageDecimal = new Prisma.Decimal(sharePercentage).div(100); // 퍼센트를 소수로 변환

    // 기존 지분 총합 확인 (100% 초과 방지)
    const existingTotalPercentage = game.game_shares.reduce(
      (sum, share) => sum.add(share.sharePercentage),
      new Prisma.Decimal(0)
    );

    const newTotalPercentage = existingTotalPercentage.add(sharePercentageDecimal);
    if (newTotalPercentage.gt(1)) {
      return NextResponse.json(
        {
          ok: false,
          error: `지분 비율이 100%를 초과합니다. (현재: ${existingTotalPercentage.mul(100).toFixed(2)}%, 추가: ${sharePercentage}%)`,
        },
        { status: 400 }
      );
    }

    // 지분 상품 생성
    const gameShare = await prisma.game_shares.create({
        data: {
        gameId,
        sharePercentage: sharePercentageDecimal,
        price: new Prisma.Decimal(price),
        totalShares,
        availableShares: totalShares,
        soldShares: 0,
        isActive: true,
        id: crypto.randomUUID(),
        updatedAt: new Date(),
        }
    });

    return NextResponse.json({
      ok: true,
      message: '게임 주식이 생성되었습니다.',
      data: {
        share: {
          id: gameShare.id,
          sharePercentage: Number(gameShare.sharePercentage) * 100,
          price: Number(gameShare.price),
          totalShares: gameShare.totalShares,
          availableShares: gameShare.availableShares,
          soldShares: gameShare.soldShares,
          isActive: gameShare.isActive,
        },
      },
    });
  } catch (error) {
    console.error('[API] 게임 주식 생성 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '게임 주식 생성 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error as Error).message : undefined, } }, { status: 500 });
  }
}

