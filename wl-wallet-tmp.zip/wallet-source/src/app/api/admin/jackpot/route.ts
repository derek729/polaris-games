import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Decimal } from '@prisma/client/runtime/library';

export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/jackpot
 * 잭팟 현황 조회
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
      return Response.json({
        ok: false,
        error: { code: 'FORBIDDEN', message: 'Admin access required' }
      }, { status: 403 });
    }

    const jackpots = await prisma.jackpots.findMany({
      where: { isActive: true },
      orderBy: { createdAt: 'desc' },
      include: {
        jackpot_wins: {
          orderBy: { wonAt: 'desc' },
          take: 10,
          include: {
            users: {
              select: {
                id: true,
                username: true,
              },
            },
          },
        },
      },
    });

    // 전체 통계
    const stats = await prisma.jackpots.aggregate({
      where: { isActive: true },
      _sum: {
        currentAmount: true,
        seedAmount: true,
      },
      _count: {
        id: true,
      },
    });

    const totalWins = await prisma.jackpot_wins.count();

    return Response.json({
      ok: true,
      data: {
        jackpots: jackpots.map((j) => ({
          id: j.id,
          type: j.type,
          currentAmount: j.currentAmount.toString(),
          seedAmount: j.seedAmount.toString(),
          contributionRate: j.contributionRate.toString(),
          lastWonAt: j.lastWonAt,
          lastWonAmount: j.lastWonAmount?.toString(),
          autoWinEnabled: j.autoWinEnabled,
          cumulativePlays: j.cumulativePlays.toString(),
          wins: j.jackpot_wins.map((w) => ({
            id: w.id,
            amount: w.amount.toString(),
            wonAt: w.wonAt,
            user: w.users,
          })),
        })),
        stats: {
          totalAmount: stats._sum.currentAmount?.toString() || '0',
          totalSeed: stats._sum.seedAmount?.toString() || '0',
          activeCount: stats._count.id,
          totalWins,
        },
      },
      message: 'Jackpot status fetched'
    });
  } catch (error) {
    console.error('[Jackpot] Error:', error);
    return Response.json({
      ok: false,
      error: {
        code: 'FETCH_FAILED',
        message: error instanceof Error ? error.message : 'Failed to fetch jackpot status'
      }
    }, { status: 500 });
  }
}

/**
 * POST /api/admin/jackpot
 * 잭팟 수동 적립
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'SUPER_ADMIN') {
      return Response.json({
        ok: false,
        error: { code: 'FORBIDDEN', message: 'Super admin access required' }
      }, { status: 403 });
    }

    const body = await request.json();
    const { type = 'GLOBAL', amount, seedAmount } = body;

    if (!amount) {
      return Response.json({
        ok: false,
        error: { code: 'MISSING_PARAMS', message: 'Amount is required' }
      }, { status: 400 });
    }

    const jackpot = await prisma.jackpots.upsert({
      where: {
        id: '', // Will always create new
      },
      create: {
        type,
        currentAmount: new Decimal(amount),
        seedAmount: new Decimal(seedAmount || 0),
        isActive: true,
      },
      update: {
        currentAmount: { increment: new Decimal(amount) },
      },
    });

    return Response.json({
      ok: true,
      data: {
        id: jackpot.id,
        currentAmount: jackpot.currentAmount.toString(),
        message: 'Jackpot updated successfully',
      },
      message: 'Jackpot created'
    });
  } catch (error) {
    console.error('[Jackpot] Error:', error);
    return Response.json({
      ok: false,
      error: {
        code: 'CREATE_FAILED',
        message: error instanceof Error ? error.message : 'Failed to create jackpot'
      }
    }, { status: 500 });
  }
}

/**
 * PUT /api/admin/jackpot
 * 잭팟 설정 업데이트
 */
export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'SUPER_ADMIN') {
      return Response.json({
        ok: false,
        error: { code: 'FORBIDDEN', message: 'Super admin access required' }
      }, { status: 403 });
    }

    const body = await request.json();
    const { id, contributionRate, autoWinEnabled, baseWinProbability } = body;

    if (!id) {
      return Response.json({
        ok: false,
        error: { code: 'MISSING_PARAMS', message: 'Jackpot ID is required' }
      }, { status: 400 });
    }

    const updateData: any = {};
    if (contributionRate !== undefined) {
      updateData.contributionRate = new Decimal(contributionRate);
    }
    if (autoWinEnabled !== undefined) {
      updateData.autoWinEnabled = autoWinEnabled;
    }
    if (baseWinProbability !== undefined) {
      updateData.baseWinProbability = new Decimal(baseWinProbability);
    }

    const jackpot = await prisma.jackpots.update({
      where: { id },
      data: updateData,
    });

    return Response.json({
      ok: true,
      data: {
        id: jackpot.id,
        contributionRate: jackpot.contributionRate.toString(),
        autoWinEnabled: jackpot.autoWinEnabled,
        baseWinProbability: jackpot.baseWinProbability.toString(),
        message: 'Jackpot settings updated',
      },
      message: 'Jackpot updated'
    });
  } catch (error) {
    console.error('[Jackpot] Error:', error);
    return Response.json({
      ok: false,
      error: {
        code: 'UPDATE_FAILED',
        message: error instanceof Error ? error.message : 'Failed to update jackpot'
      }
    }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/jackpot
 * 잭팟 초기화
 */
export async function DELETE(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== 'SUPER_ADMIN') {
      return Response.json({
        ok: false,
        error: { code: 'FORBIDDEN', message: 'Super admin access required' }
      }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return Response.json({
        ok: false,
        error: { code: 'MISSING_PARAMS', message: 'Jackpot ID is required' }
      }, { status: 400 });
    }

    await prisma.jackpots.update({
      where: { id },
      data: {
        currentAmount: new Decimal(0),
        lastWonAt: null,
        lastWonAmount: null,
        lastWonBy: null,
        cumulativePlays: BigInt(0),
      },
    });

    return Response.json({
      ok: true,
      data: { message: 'Jackpot reset successfully' },
      message: 'Jackpot reset'
    });
  } catch (error) {
    console.error('[Jackpot] Error:', error);
    return Response.json({
      ok: false,
      error: {
        code: 'DELETE_FAILED',
        message: error instanceof Error ? error.message : 'Failed to reset jackpot'
      }
    }, { status: 500 });
  }
}
