import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1'));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20')));
    const period = parseInt(searchParams.get('period') || '30');
    const userId = searchParams.get('userId');
    const status = searchParams.get('status');

    const skip = (page - 1) * limit;

    const dateThreshold = new Date();
    dateThreshold.setDate(dateThreshold.getDate() - period);

    const whereClause: Record<string, unknown> = {
      createdAt: { gte: dateThreshold },
    };
    if (userId) whereClause.userId = userId;
    if (status) whereClause.status = status;

    const [miningRecords, totalCount, totalRewardsResult] = await Promise.all([
      prisma.mining_claims.findMany({
        where: whereClause,
        select: {
          id: true,
          userId: true,
          sessionId: true,
          claimAmount: true,
          powReward: true,
          posReward: true,
          epochNumber: true,
          status: true,
          claimedAt: true,
          metadata: true,
          users: {
            select: { id: true, username: true, email: true },
          },
        },
        orderBy: { claimedAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.mining_claims.count({ where: whereClause }),
      prisma.mining_claims.aggregate({
        where: whereClause,
        _sum: { claimAmount: true },
      }),
    ]);

    const sessionIds = [...new Set(miningRecords.map(r => r.sessionId))];
    const sessions = sessionIds.length > 0
      ? await prisma.mining_sessions.findMany({
          where: { sessionId: { in: sessionIds } },
          select: { sessionId: true, hashrate: true, difficulty: true },
        })
      : [];
    const sessionMap = new Map(sessions.map(s => [s.sessionId, s]));

    const totalPages = Math.ceil(totalCount / limit);

    return successResponse({
      mining_records: miningRecords.map((r) => {
        const session = sessionMap.get(r.sessionId);
        return {
          id: r.id,
          userId: r.userId,
          user: r.users,
          sessionId: r.sessionId,
          rewardAmount: Number(r.claimAmount?.toString() || 0),
          difficulty: session?.difficulty ? Number(session.difficulty.toString()) : undefined,
          hashrate: session?.hashrate ? Number(session.hashrate.toString()) : undefined,
          miningDuration: r.metadata ? Number((r.metadata as Record<string, unknown>).miningDuration || 0) : undefined,
          status: r.status,
          minedAt: r.claimedAt,
          createdAt: r.claimedAt,
          updatedAt: r.claimedAt,
        };
      }),
      pagination: {
        currentPage: page,
        totalPages,
        totalCount,
        limit,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      },
      stats: {
        total: totalCount,
        totalRewards: Number(totalRewardsResult._sum.claimAmount?.toString() || 0),
      },
    });
  } catch (error: unknown) {
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('채굴 기록 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
