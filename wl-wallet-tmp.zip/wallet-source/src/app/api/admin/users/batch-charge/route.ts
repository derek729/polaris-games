import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth';
import { prisma } from '@/lib/prisma';
import { withErrorHandler, successResponse, errorResponse } from '@/lib/api-response';
import { Prisma } from '@prisma/client';

export async function POST(request: NextRequest) {
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  return withErrorHandler(async () => {
    const body = await request.json();
    const { amount, reason, targetType } = body;

    if (!amount || amount <= 0) {
      return errorResponse('유효한 수량을 입력하세요.', 400);
    }

    const airdropAmount = new Prisma.Decimal(amount);

    if (targetType === 'ALL') {
      // 전체 활성 사용자 조회
      const users = await prisma.users.findMany({
        where: { 
          status: 'ACTIVE',
          role: 'USER' // 관리자 제외
        },
        select: { id: true }
      });

      if (users.length === 0) {
        return successResponse({ count: 0, message: '대상 사용자가 없습니다.' });
      }

      // 트랜잭션으로 일괄 처리 (사용자가 많으면 청크로 나눠야 하지만, 일단 단순하게)
      const result = await prisma.$transaction(async (tx) => {
        // 1. 모든 사용자 잔액 증가
        await tx.users.updateMany({
          where: { 
            status: 'ACTIVE',
            role: 'USER'
          },
          data: {
            personalCoin: { increment: airdropAmount }
          }
        });

        // 2. 로그 기록 (개별 로그는 너무 많을 수 있으니 생략하거나, 대표 로그 하나만?)
        // 여기서는 생략하고 결과만 반환
        return users.length;
      });

      return successResponse({
        count: result,
        message: '일괄 지급이 완료되었습니다.'
      });
    }

    return errorResponse('지원하지 않는 대상 타입입니다.', 400);
  });
}

