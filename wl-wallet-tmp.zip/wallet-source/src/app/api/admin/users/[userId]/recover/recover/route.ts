import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function POST(req: NextRequest, { params }: RouteParams) {
  try {
    const { id: targetUserId } = await params;
    const body = await req.json();
    const { amount, reason, adminId } = body;

    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return NextResponse.json({ success: false, error: '회수할 코인 수량을 올바르게 입력해주세요.' }, { status: 400 });
    }

    if (!reason || typeof reason !== 'string' || reason.trim().length === 0) {
      return NextResponse.json({ success: false, error: '회수 사유를 입력해주세요.' }, { status: 400 });
    }

    const requestingAdminId = adminId || req.headers.get('x-admin-id');
    if (!requestingAdminId) {
      return NextResponse.json({ success: false, error: '관리자 정보가 없습니다.' }, { status: 401 });
    }

    const admin = await prisma.users.findUnique({
      where: { id: requestingAdminId },
      select: { id: true, role: true, username: true }
    });

    if (!admin || (admin.role !== 'ADMIN' && admin.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ success: false, error: '관리자 권한이 없습니다.' }, { status: 403 });
    }

    const targetUser = await prisma.users.findUnique({
      where: { id: targetUserId },
      select: { id: true, username: true, personalCoin: true, isActive: true }
    });

    if (!targetUser) {
      return NextResponse.json({ success: false, error: '대상 사용자를 찾을 수 없습니다.' }, { status: 404 });
    }

    const currentBalance = Number(targetUser.personalCoin);
    if (currentBalance < amount) {
      return NextResponse.json({ success: false, error: `코인 잔액이 부족합니다. 현재 잔액: ${currentBalance.toFixed(8)}` }, { status: 400 });
    }

    const result = await prisma.$transaction(async (tx) => {
      const updatedUser = await tx.users.update({
        where: { id: targetUserId },
        data: { personalCoin: { decrement: amount } },
        select: { personalCoin: true }
      });

      await tx.users.update({
        where: { id: requestingAdminId },
        data: { personalCoin: { increment: amount } }
      });

      const rewardLog = await tx.reward_logs.create({
        data: {
          userId: targetUserId,
          type: 'ADMIN_RECOVER',
          amount: -amount,
          description: `[관리자 회수] ${reason} (관리자: ${admin.username || admin.id})`,
          isPaid: true,
          paidAt: new Date()
        }
      });

      const transfer = await tx.transfers.create({
        data: {
          senderId: targetUserId,
          receiverId: requestingAdminId,
          amount: amount,
          fee: 0,
          networkType: 'ADMIN_RECOVER',
          description: `[관리자 회수] ${reason}`,
          transferredAt: new Date()
        }
      });

      return {
        rewardLogId: rewardLog.id,
        transferId: transfer.id,
        previousBalance: currentBalance,
        newBalance: Number(updatedUser.personalCoin),
        recoveredAmount: amount
      };
    });

    return NextResponse.json({
      success: true,
      message: `${amount} 코인이 성공적으로 회수되었습니다.`,
      data: { targetUserId, targetUsername: targetUser.username, adminId: requestingAdminId, adminUsername: admin.username, ...result }
    });
  } catch (error: unknown) {
    console.error('코인 회수 오류:', error);
    const errorMessage = error instanceof Error ? error.message : '코인 회수 중 오류가 발생했습니다.';
    return NextResponse.json({ success: false, error: errorMessage }, { status: 500 });
  }
}
