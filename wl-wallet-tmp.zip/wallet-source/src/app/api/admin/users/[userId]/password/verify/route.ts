import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse } from '@/lib/api-response';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authResult = await requireAdmin(request as any);
    if (authResult) return authResult;

    const { userId } = await params;
    const body = await request.json();
    const { password } = body;

    if (!password) {
      return validationErrorResponse('비밀번호를 입력해주세요.');
    }

    // 사용자 조회
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        password: true,
      },
    });

    if (!user) {
      return notFoundResponse('사용자를 찾을 수 없습니다.');
    }

    if (!user.password) {
      return errorResponse('비밀번호가 설정되지 않은 사용자입니다.', 400, 'NO_PASSWORD');
    }

    // 비밀번호 확인
    const isValid = await bcrypt.compare(password, user.password);

    if (!isValid) {
      return errorResponse('비밀번호가 일치하지 않습니다.', 401, 'INVALID_PASSWORD');
    }

    return successResponse(
      { verified: true },
      '비밀번호가 확인되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin] 비밀번호 확인 실패:', error);
    return errorResponse(
      (error instanceof Error ? error.message : String(error)) || '비밀번호 확인 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

