import { NextResponse } from 'next/server'
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma'
import { requireAdmin } from '@/lib/admin-auth'
import { distributeCenterIncentive } from '@/services/centerFee'

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ userId: string }> }
) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any)
  if (authResult) return authResult

  try {
    const { userId } = await params
    const body = await request.json()
    const { centerCode } = body

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
      include: {
        other_users_users_centerIdTousers: {
          select: {
            id: true,
            username: true,
            email: true,
            referralCode: true,
          },
        },
      },
    })

    if (!user) {
      return NextResponse.json(
        { ok: false, error: { code: 'USER_NOT_FOUND', message: '사용자를 찾을 수 없습니다.' } }, { status: 404 })
    }

    // 센터 변경
    let centerId: string | null = null
    let isNewCenter = false

    if (centerCode !== undefined) {
      if (centerCode === '' || centerCode === null) {
        // 센터 제거
        centerId = null
      } else {
        // 센터 찾기 (사용자명 또는 추천인 코드로)
        const center = await prisma.users.findFirst({
          where: {
            OR: [
              { referralCode: centerCode.trim().toUpperCase() },
              { username: centerCode.trim() },
            ],
          },
          select: { id: true, isActive: true, status: true },
        })

        if (!center) {
          return NextResponse.json(
            { ok: false, error: `센터 코드 "${centerCode}"에 해당하는 사용자를 찾을 수 없습니다.` },
            { status: 400 }
          )
        }

        if (!center.isActive || center.status !== 'ACTIVE') {
          return NextResponse.json(
            { ok: false, error: { code: 'INVALID_INPUT', message: '활성 상태가 아닌 센터입니다.' } }, { status: 400 })
        }

        // 자기 자신을 센터로 설정할 수 없음
        if (center.id === userId) {
          return NextResponse.json(
            { ok: false, error: { code: 'INVALID_INPUT', message: '자기 자신을 센터로 설정할 수 없습니다.' } }, { status: 400 })
        }

        centerId = center.id

        // 새 센터인지 확인 (기존 센터가 없었거나 변경된 경우)
        if (!user.centerId || user.centerId !== centerId) {
          isNewCenter = true
        }
      }
    }

    // 사용자 정보 업데이트
    const updatedUser = await prisma.users.update({
      where: { id: userId },
      data: { centerId },
      include: {
        other_users_users_centerIdTousers: {
          select: {
            id: true,
            username: true,
            email: true,
            referralCode: true,
          },
        },
      },
    })

    // 새 센터가 개설된 경우, 상위 센터에게 인센티브 지급
    if (isNewCenter && centerId) {
      const memberCount = updatedUser.other_users_users_centerIdTousers?.length || 0
      // 비동기로 인센티브 지급 수행 (응답을 블로킹하지 않음)
      distributeCenterIncentive(userId, memberCount + 1) // +1은 자기 자신
        .then((result) => {
          console.log(`[Admin] 센터 지정 후 인센티브 지급 완료: ${userId}`, result)
        })
        .catch((error) => {
          console.error(`[Admin] 센터 지정 후 인센티브 지급 실패: ${userId}`, error)
        })
    }

    return NextResponse.json({
      ok: true,
      message: '센터 정보가 성공적으로 변경되었습니다.' + (isNewCenter && centerId ? ' 센터 개설 인센티브 지급이 진행 중입니다.' : ''),
      data: {
        users: {
          id: updatedUser.id,
          centerId: updatedUser.centerId,
          other_users_users_centerIdTousers: updatedUser.other_users_users_centerIdTousers,
        },
      },
    })
  } catch (error: any) {
    console.error('[Admin] 센터 변경 실패:', error)
    return NextResponse.json(
      { ok: false, error: (error instanceof Error ? error.message : String(error)) || '센터 변경 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}

