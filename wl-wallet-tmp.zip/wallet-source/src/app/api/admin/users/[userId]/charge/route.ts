import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin, getCurrentAdminUser } from '@/lib/admin-auth';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse, unauthorizedResponse } from '@/lib/api-response';
import { Prisma } from '@prisma/client';

/**
 * 관리자용 코인 지급 API
 * POST /api/admin/users/[userId]/charge
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 확인
    const authResult = await requireAdmin(request as any);
    if (authResult) return authResult;

    // 관리자 사용자 정보 가져오기
    const admin = await getCurrentAdminUser();
    if (!admin) {
      return unauthorizedResponse('관리자 권한이 필요합니다.');
    }

    const { userId } = await params;
    const body = await request.json();
    const { amount, memo } = body;

    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      return validationErrorResponse('올바른 금액을 입력해주세요.');
    }

    const chargeAmount = new Prisma.Decimal(amount);

    // 사용자 조회
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        personalCoin: true,
      },
    });

    if (!user) {
      return notFoundResponse('사용자를 찾을 수 없습니다.');
    }

    // MSUO 잔액 증가
    const previousBalance = new Prisma.Decimal(user.personalCoin || 0);
    const newBalance = previousBalance.plus(chargeAmount);

    await prisma.$transaction(
      async (tx) => {
        // 사용자 잔액 업데이트
        await tx.users.update({
          where: { id: userId },
          data: {
            personalCoin: newBalance,
          },
        });

        // 충전 내역 로그 (RewardLog에 기록)
        await tx.reward_logs.create({
          data: {
            userId,
            type: 'TEAM', // 관리자 지급 타입
            amount: chargeAmount,
            isPaid: true,
            paidAt: new Date(),
            description: memo
              ? `[관리자 MSUO 지급] ${memo} | 관리자: ${admin.username || admin.email} | 이전: ${previousBalance.toString()} | 이후: ${newBalance.toString()}`
              : `[관리자 MSUO 지급] 관리자: ${admin.username || admin.email} | 이전: ${previousBalance.toString()} | 이후: ${newBalance.toString()}`,
          },
        });
      },
      {
        maxWait: 30000,
        timeout: 30000,
      }
    );

    console.log(`[Admin] MSUO 지급 완료: ${user.username} | ${chargeAmount.toString()} MSUO | 관리자: ${admin.username}`);

    return successResponse({
      userId: user.id,
      username: user.username,
      chargeAmount: chargeAmount.toString(),
      previousBalance: previousBalance.toString(),
      newBalance: newBalance.toString(),
    }, 'MSUO가 성공적으로 지급되었습니다.');
  } catch (error: any) {
    console.error('[Admin] MSUO 지급 실패:', error);
    return errorResponse(
      (error instanceof Error ? error.message : String(error)) || 'MSUO 지급 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

