import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { isValidPassword } from '@/lib/validation';
import bcrypt from 'bcryptjs';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse } from '@/lib/api-response';

/**
 * 관리자용 사용자 비밀번호 변경 API
 * PUT /api/admin/users/[userId]/password
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authResult = await requireAdmin(request as any);
    if (authResult) return authResult;

    const { userId } = await params;
    const body = await request.json();
    const { password } = body;

    // 필수 필드 검증
    if (!password || typeof password !== 'string') {
      return validationErrorResponse('비밀번호를 입력해주세요.');
    }

    // 비밀번호 유효성 검사
    const passwordCheck = isValidPassword(password);
    if (!passwordCheck.valid) {
      return validationErrorResponse(passwordCheck.message || '비밀번호가 유효하지 않습니다.');
    }

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
      },
    });

    if (!user) {
      return notFoundResponse('사용자를 찾을 수 없습니다.');
    }

    // 비밀번호 해싱
    const hashedPassword = await bcrypt.hash(password, 10);

    // 비밀번호 업데이트
    await prisma.users.update({
      where: { id: userId },
      data: { password: hashedPassword },
    });

    console.log(`[Admin] 비밀번호 변경 완료: ${user.username} (userId: ${userId})`);

    return successResponse(
      { userId: user.id, username: user.username },
      '비밀번호가 성공적으로 변경되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin] 비밀번호 변경 실패:', error);
    return errorResponse(
      (error instanceof Error ? error.message : String(error)) || '비밀번호 변경 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

