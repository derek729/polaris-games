import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100);
    const status = searchParams.get('status');
    const userId = searchParams.get('userId');
    const search = searchParams.get('search');

    const skip = (page - 1) * limit;

    console.log(`[API] 스테이킹 레코드 조회 요청 (page: ${page}, limit: ${limit})`);

    // 필터 조건 구성
    const whereCondition: any = {};

    if (status && status !== 'all') {
      whereCondition.status = status;
    }

    if (userId) {
      whereCondition.userId = userId;
    }

    if (search) {
      whereCondition.users = {
        OR: [
          { username: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } }
        ]
      };
    }

    // 스테이킹 레코드와 사용자 정보 함께 조회
    const [records, totalCount] = await Promise.all([
      prisma.staking_records.findMany({
        where: whereCondition,
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
              rank: true
            }
          }
        },
        orderBy: [
          { createdAt: 'desc' },
          { stakedAt: 'desc' }
        ],
        skip,
        take: limit
      }),
      prisma.staking_records.count({ where: whereCondition })
    ]);

    // 통계 정보 계산
    const stats = await prisma.staking_records.groupBy({
      by: ['status'],
      _sum: {
        stakedAmount: true,
        rewardAmount: true
      },
      _count: {
        id: true
      },
      where: whereCondition
    });

    const totalStaked = stats.reduce((sum, stat) => sum + Number(stat._sum.stakedAmount || 0), 0);
    const totalRewards = stats.reduce((sum, stat) => sum + Number(stat._sum.rewardAmount || 0), 0);

    const response = {
      ok: true,
      message: '스테이킹 레코드 조회 완료',
      data: {
        records: records.map(record => ({
          id: record.id,
          userId: record.userId,
          username: record.users?.username,
          email: record.users?.email,
          userRank: record.users?.rank,
          mainnetAddress: record.mainnetAddress,
          validatorAddress: record.validatorAddress,
          txHash: record.txHash,
          unstakeTxHash: record.unstakeTxHash,
          stakedAmount: Number(record.stakedAmount),
          rewardAmount: Number(record.rewardAmount),
          apy: record.apy ? Number(record.apy) : null,
          angelLockAmount: Number(record.angelLockAmount),
          startDate: record.startDate,
          endDate: record.endDate,
          lockPeriod: record.lockPeriod,
          status: record.status,
          confirmations: record.confirmations,
          stakedAt: record.stakedAt,
          unstakedAt: record.unstakedAt,
          confirmedAt: record.confirmedAt,
          createdAt: record.createdAt,
          updatedAt: record.updatedAt
        })),
        pagination: {
          page,
          limit,
          total: totalCount,
          totalPages: Math.ceil(totalCount / limit),
          hasNext: page * limit < totalCount,
          hasPrev: page > 1
        },
        statistics: {
          totalRecords: totalCount,
          totalStaked,
          totalRewards,
          statusDistribution: stats.map(stat => ({
            status: stat.status,
            count: stat._count.id,
            stakedAmount: Number(stat._sum.stakedAmount || 0),
            rewardAmount: Number(stat._sum.rewardAmount || 0)
          }))
        }
      }
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('[API] 스테이킹 레코드 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '스테이킹 레코드 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}