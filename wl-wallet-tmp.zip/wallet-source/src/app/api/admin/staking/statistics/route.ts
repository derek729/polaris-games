import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    console.log('[API] 스테이킹 통계 조회 요청');

    // 전체 스테이킹 통계
    const [
      totalStats,
      statusStats,
      recentStats,
      apyStats,
      monthlyStats
    ] = await Promise.all([
      // 전체 통계
      prisma.staking_records.aggregate({
        _sum: {
          stakedAmount: true,
          rewardAmount: true
        },
        _count: {
          id: true
        }
      }),

      // 상태별 통계
      prisma.staking_records.groupBy({
        by: ['status'],
        _sum: {
          stakedAmount: true,
          rewardAmount: true
        },
        _count: {
          id: true
        }
      }),

      // 최근 7일 통계
      prisma.staking_records.aggregate({
        where: {
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
          }
        },
        _sum: {
          stakedAmount: true
        },
        _count: {
          id: true
        }
      }),

      // APY 분포
      prisma.staking_records.groupBy({
        by: ['apy'],
        where: {
          apy: { not: null }
        },
        _sum: {
          stakedAmount: true
        },
        _count: {
          id: true
        }
      }),

      // 월별 신규 스테이킹 통계 (최근 6개월)
      prisma.$queryRaw`
        SELECT
          DATE_TRUNC('month', staked_at) as month,
          COUNT(*) as count,
          SUM(staked_amount) as total_amount
        FROM "staking_records"
        WHERE staked_at >= NOW() - INTERVAL '6 months'
        GROUP BY DATE_TRUNC('month', staked_at)
        ORDER BY month DESC
      `
    ]);

    // 활성 스테이킹 상위 10명
    const topStakers = await prisma.staking_records.findMany({
      where: {
        status: 'ACTIVE'
      },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
            rank: true
          }
        }
      },
      orderBy: {
        stakedAmount: 'desc'
      },
      take: 10,
      distinct: ['userId']
    });

    // 잠금 기간별 통계
    const lockPeriodStats = await prisma.staking_records.groupBy({
      by: ['lockPeriod'],
      where: {
        lockPeriod: { not: null }
      },
      _count: {
        id: true
      },
      _sum: {
        stakedAmount: true
      }
    });

    // Angel Lock 통계
    const angelLockStats = await prisma.staking_records.aggregate({
      where: {
        angelLockAmount: {
          gt: 0
        }
      },
      _sum: {
        stakedAmount: true,
        angelLockAmount: true
      },
      _count: {
        id: true
      }
    });

    const response = {
      ok: true,
      message: '스테이킹 통계 조회 완료',
      data: {
        overview: {
          totalStaked: Number(totalStats._sum.stakedAmount || 0),
          totalRewards: Number(totalStats._sum.rewardAmount || 0),
          totalRecords: totalStats._count.id,
          recentStaked: Number(recentStats._sum.stakedAmount || 0),
          recentRecords: recentStats._count.id
        },
        statusDistribution: statusStats.map(stat => ({
          status: stat.status,
          count: stat._count.id,
          stakedAmount: Number(stat._sum.stakedAmount || 0),
          rewardAmount: Number(stat._sum.rewardAmount || 0),
          percentage: totalStats._count.id > 0 ? (stat._count.id / totalStats._count.id) * 100 : 0
        })),
        apyDistribution: apyStats.map(stat => ({
          apy: Number(stat.apy),
          count: stat._count.id,
          stakedAmount: Number(stat._sum.stakedAmount || 0),
          percentage: totalStats._sum.stakedAmount ? (Number(stat._sum.stakedAmount || 0) / Number(totalStats._sum.stakedAmount)) * 100 : 0
        })),
        monthlyTrends: (monthlyStats as any[]).map(stat => ({
          month: stat.month,
          count: parseInt(stat.count),
          totalAmount: Number(stat.total_amount)
        })),
        lockPeriodDistribution: lockPeriodStats.map(stat => ({
          lockPeriod: stat.lockPeriod,
          count: stat._count.id,
          stakedAmount: Number(stat._sum.stakedAmount || 0)
        })),
        angelLockStats: {
          totalRecords: angelLockStats._count.id,
          totalStaked: Number(angelLockStats._sum.stakedAmount || 0),
          totalAngelLock: Number(angelLockStats._sum.angelLockAmount || 0)
        },
        topStakers: topStakers.map(record => ({
          userId: record.userId,
          username: record.users?.username,
          email: record.users?.email,
          rank: record.users?.rank,
          stakedAmount: Number(record.stakedAmount),
          apy: record.apy ? Number(record.apy) : null,
          lockPeriod: record.lockPeriod,
          status: record.status
        })),
        averageMetrics: {
          averageStakePerUser: totalStats._count.id > 0 ? Number(totalStats._sum.stakedAmount || 0) / totalStats._count.id : 0,
          averageApy: apyStats.length > 0 ? apyStats.reduce((sum, stat) => sum + Number(stat.apy || 0), 0) / apyStats.length : 0,
          averageLockPeriod: lockPeriodStats.length > 0 ? lockPeriodStats.reduce((sum, stat) => sum + (stat.lockPeriod || 0), 0) / lockPeriodStats.length : 0
        }
      },
      lastUpdated: new Date().toISOString()
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('[API] 스테이킹 통계 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '스테이킹 통계 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}