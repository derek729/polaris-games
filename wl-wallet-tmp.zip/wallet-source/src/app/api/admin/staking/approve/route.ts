import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';

export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { recordIds, action, notes } = await request.json();

    if (!recordIds || !Array.isArray(recordIds) || recordIds.length === 0) {
      return NextResponse.json(
        { ok: false, error: { code: 'MISSING_REQUIRED_FIELD', message: '유효한 레코드 ID를 입력해주세요.' } }, { status: 400 });
    }

    if (!action || !['APPROVE', 'REJECT'].includes(action)) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '유효한 액션을 선택해주세요. (APPROVE, REJECT)' } }, { status: 400 });
    }

    console.log(`[API] 스테이킹 레코드 ${action} 요청 (${recordIds.length}개)`);

    const results = [];

    for (const recordId of recordIds) {
      try {
        const record = await prisma.staking_records.findUnique({
          where: { id: recordId },
          include: {
            users: {
              select: {
                id: true,
                username: true,
                email: true
              }
            }
          }
        });

        if (!record) {
          results.push({
            recordId,
            success: false,
            error: '레코드를 찾을 수 없습니다.'
          });
          continue;
        }

        if (record.status !== 'PENDING') {
          results.push({
            recordId,
            success: false,
            error: `이미 ${record.status} 상태입니다.`
          });
          continue;
        }

        // 상태 업데이트
        const updateData: any = {
          status: action === 'APPROVE' ? 'ACTIVE' : 'REJECTED',
          updatedAt: new Date()
        };

        if (action === 'APPROVE') {
          updateData.confirmedAt = new Date();
          updateData.confirmations = 1;
        }

        // 메타데이터에 노트 추가
        const metadata = record.metadata ? JSON.parse(JSON.stringify(record.metadata)) : {};
        if (notes) {
          metadata.adminNotes = notes;
        }
        metadata.adminAction = action;
        metadata.adminActionAt = new Date().toISOString();
        updateData.metadata = metadata;

        const updatedRecord = await prisma.staking_records.update({
          where: { id: recordId },
          data: updateData
        });

        results.push({
          recordId,
          success: true,
          record: {
            id: updatedRecord.id,
            status: updatedRecord.status,
            stakedAmount: Number(updatedRecord.stakedAmount),
            username: record.users?.username,
            email: record.users?.email
          }
        });

      } catch (error) {
        console.error(`[API] 레코드 ${recordId} 처리 실패:`, error);
        results.push({
          recordId,
          success: false,
          error: (error instanceof Error ? error.message : String(error)) || '처리 중 오류 발생'
        });
      }
    }

    const successCount = results.filter(r => r.success).length;
    const failureCount = results.length - successCount;

    console.log(`[API] 스테이킹 레코드 처리 완료: 성공 ${successCount}, 실패 ${failureCount}`);

    return NextResponse.json({
      ok: true,
      message: `${action} 처리 완료: 성공 ${successCount}개, 실패 ${failureCount}개`,
      data: {
        action,
        totalProcessed: results.length,
        successCount,
        failureCount,
        results
      }
    });

  } catch (error) {
    console.error('[API] 스테이킹 레코드 처리 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '스테이킹 레코드 처리 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}