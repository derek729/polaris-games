import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole, Prisma } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 200);
    const userId = searchParams.get('userId');
    const type = searchParams.get('type');
    const status = searchParams.get('status');
    const fromCoin = searchParams.get('fromCoin');
    const toCoin = searchParams.get('toCoin');
    const search = searchParams.get('search');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    const skip = (page - 1) * limit;

    console.log(`[API] 거래 내역 목록 조회 (page: ${page}, limit: ${limit})`);

    // 필터 조건 구성
    const whereCondition: any = {};

    if (userId) {
      whereCondition.userId = userId;
    }

    if (type && type !== 'all') {
      whereCondition.type = type;
    }

    if (status && status !== 'all') {
      whereCondition.status = status;
    }

    if (fromCoin && fromCoin !== 'all') {
      whereCondition.fromCoin = fromCoin;
    }

    if (toCoin && toCoin !== 'all') {
      whereCondition.toCoin = toCoin;
    }

    if (search) {
      whereCondition.users = {
        OR: [
          { username: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { walletAddress: { contains: search, mode: 'insensitive' } }
        ]
      };
    }

    if (startDate || endDate) {
      whereCondition.createdAt = {};
      if (startDate) {
        whereCondition.createdAt.gte = new Date(startDate);
      }
      if (endDate) {
        whereCondition.createdAt.lte = new Date(endDate);
      }
    }

    // 거래 내역 목록과 사용자 정보 함께 조회
    const [transactions, totalCount] = await Promise.all([
      prisma.orders.findMany({
        where: whereCondition,
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
              walletAddress: true,
              rank: true,
              personalCoin: true
            }
          }
        },
        orderBy: [
          { createdAt: 'desc' }
        ],
        skip,
        take: limit
      }),
      prisma.orders.count({ where: whereCondition })
    ]);

    // 통계 정보 계산
    const stats = await prisma.orders.groupBy({
      by: ['type', 'status'],
      _sum: {
        amount: true,
        price: true
      },
      _count: {
        id: true
      },
      where: whereCondition
    });

    // 유형별 통계
    const typeStats = await prisma.orders.groupBy({
      by: ['type'],
      _sum: {
        amount: true,
        price: true
      },
      _count: {
        id: true
      },
      where: whereCondition
    });

    // 상태별 통계
    const statusStats = await prisma.orders.groupBy({
      by: ['status'],
      _sum: {
        amount: true,
        price: true
      },
      _count: {
        id: true
      },
      where: whereCondition
    });

    // 일별 거래량 (최근 7일)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const dailyStats = await prisma.$queryRaw`
      SELECT
        DATE("createdAt") as date,
        COUNT(*) as count,
        COALESCE(SUM(amount), 0) as totalAmount
      FROM "orders"
      WHERE "createdAt" >= ${sevenDaysAgo}
      ${whereCondition.users ? Prisma.sql`AND "userId" = ${whereCondition.userId}` : Prisma.empty}
      GROUP BY DATE("createdAt")
      ORDER BY date DESC
    ` as Array<{ date: string; count: number; totalAmount: bigint }>;

    // 최근 대용량 거래
    const topTransactions = await prisma.orders.findMany({
      where: whereCondition,
      include: {
        users: {
          select: {
            id: true,
            username: true,
            rank: true
          }
        }
      },
      orderBy: {
        amount: 'desc'
      },
      take: 10
    });

    const totalAmount = stats.reduce((sum, stat) => sum + Number(stat._sum.amount || 0), 0);
    const totalPrice = stats.reduce((sum, stat) => sum + Number(stat._sum.price || 0), 0);

    const response = {
      ok: true,
      message: '거래 내역 목록 조회 완료',
      data: {
        transactions: transactions.map(transaction => ({
          id: transaction.id,
          userId: transaction.userId,
          username: transaction.users?.username,
          email: transaction.users?.email,
          walletAddress: transaction.users?.walletAddress,
          userRank: transaction.users?.rank,
          userBalance: transaction.users?.personalCoin ? Number(transaction.users.personalCoin) : 0,
          type: transaction.type,
          price: Number(transaction.price),
          amount: Number(transaction.amount),
          filledAmount: Number(transaction.filledAmount),
          remainingAmount: Number(transaction.remainingAmount),
          status: transaction.status,
          orderType: transaction.orderType,
          txHash: transaction.txHash,
          metadata: transaction.metadata,
          createdAt: transaction.createdAt,
          updatedAt: transaction.updatedAt,
          filledAt: transaction.filledAt,
          cancelledAt: transaction.cancelledAt
        })),
        pagination: {
          page,
          limit,
          total: totalCount,
          totalPages: Math.ceil(totalCount / limit),
          hasNext: page * limit < totalCount,
          hasPrev: page > 1
        },
        statistics: {
          totalTransactions: totalCount,
          totalAmount,
          totalPrice,
          typeDistribution: typeStats.map(stat => ({
            type: stat.type,
            count: stat._count.id,
            amount: Number(stat._sum.amount || 0),
            price: Number(stat._sum.price || 0),
            percentage: totalAmount > 0 ? (Number(stat._sum.amount || 0) / totalAmount) * 100 : 0
          })),
          statusDistribution: statusStats.map(stat => ({
            status: stat.status,
            count: stat._count.id,
            amount: Number(stat._sum.amount || 0),
            price: Number(stat._sum.price || 0),
            percentage: totalAmount > 0 ? (Number(stat._sum.amount || 0) / totalAmount) * 100 : 0
          })),
          dailyStats: dailyStats.map(stat => ({
            date: stat.date,
            count: stat.count,
            totalAmount: Number(stat.totalAmount)
          })),
          topTransactions: topTransactions.map(tx => ({
            ...tx,
            amount: Number(tx.amount)
          })),
          averageAmount: totalCount > 0 ? totalAmount / totalCount : 0
        }
      }
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('[API] 거래 내역 목록 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '거래 내역 목록 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}

// 거래 내역 상세 조회
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { transactionId } = await request.json();

    if (!transactionId) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '거래 ID가 필요합니다.' } }, { status: 400 });
    }

    console.log(`[API] 거래 상세 정보 조회: ${transactionId}`);

    // 거래 상세 정보 조회
    const transaction = await prisma.orders.findUnique({
      where: { id: transactionId },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
            walletAddress: true,
            rank: true,
            personalCoin: true,
            createdAt: true
          }
        }
      }
    });

    if (!transaction) {
      return NextResponse.json(
        { ok: false, error: { code: 'NOT_FOUND', message: '거래 내역을 찾을 수 없습니다.' } }, { status: 404 });
    }

    // 관련 거래 내역 조회 (동일 사용자의 최근 거래)
    const relatedTransactions = await prisma.orders.findMany({
      where: {
        userId: transaction.userId,
        id: { not: transactionId }
      },
      take: 10,
      orderBy: {
        createdAt: 'desc'
      }
    });

    return NextResponse.json({
      ok: true,
      message: '거래 상세 정보 조회 완료',
      data: {
        transaction: {
          ...transaction,
          price: Number(transaction.price),
          amount: Number(transaction.amount),
          filledAmount: Number(transaction.filledAmount),
          remainingAmount: Number(transaction.remainingAmount),
          users: {
            ...transaction.users,
            personalCoin: transaction.users.personalCoin ? Number(transaction.users.personalCoin) : 0
          }
        },
        relatedTransactions: relatedTransactions.map(tx => ({
          ...tx,
          price: Number(tx.price),
          amount: Number(tx.amount),
          filledAmount: Number(tx.filledAmount),
          remainingAmount: Number(tx.remainingAmount)
        }))
      }
    });

  } catch (error) {
    console.error('[API] 거래 상세 정보 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '거래 정보 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}