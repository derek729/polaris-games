import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    // 데이터베이스 연결 테스트
    await prisma.$connect();

    // 관리자 계정 확인
    const adminCount = await prisma.users.count({
      where: {
        role: {
          in: ['ADMIN', 'SUPER_ADMIN']
        },
        isActive: true,
        status: 'ACTIVE'
      }
    });

    // 기본 관리자 계정 확인
    const defaultAdmin = await prisma.users.findFirst({
      where: {
        OR: [
          { username: 'admin' },
          { email: 'admin@upc.co.kr' }
        ]
      },
      select: {
        id: true,
        username: true,
        email: true,
        role: true,
        isActive: true,
        status: true,
        createdAt: true
      }
    });

    // 전체 사용자 수
    const totalUsers = await prisma.users.count();

    // 데이터베이스 테이블 존재 확인
    let tablesExist = false;
    try {
      await prisma.users.findFirst();
      tablesExist = true;
    } catch (error) {
      tablesExist = false;
    }

    const setupStatus = {
      databaseConnected: true,
      tablesExist,
      totalUsers,
      adminUsers: adminCount,
      defaultAdminExists: !!defaultAdmin,
      defaultAdmin: defaultAdmin ? {
        id: defaultAdmin.id,
        username: defaultAdmin.username,
        email: defaultAdmin.email,
        role: defaultAdmin.role,
        isActive: defaultAdmin.isActive,
        status: defaultAdmin.status,
        createdAt: defaultAdmin.createdAt
      } : null,
      needsSetup: adminCount === 0 || !defaultAdmin
    };

    return successResponse(setupStatus);

  } catch (error) {
    console.error('Setup check error:', error);

    return NextResponse.json({
      ok: false,
      error: error instanceof Error ? error.message : String(error),
      data: {
        databaseConnected: false,
        tablesExist: false,
        needsSetup: true
      }
    }, { status: 500 });
  } finally {
    await prisma.$disconnect();
  }
}