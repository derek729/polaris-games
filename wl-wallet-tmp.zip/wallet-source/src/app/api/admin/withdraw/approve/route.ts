import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';
import { Prisma } from '@prisma/client';

export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const body = await request.json();
    const { requestId, action, reason } = body;

    if (!requestId || !action || !['APPROVE', 'REJECT'].includes(action)) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '유효하지 않은 요청입니다.' } }, { status: 400 });
    }

    console.log(`[API] 출금 요청 ${action} 처리: ${requestId}`);

    // 기존 요청 확인
    const existingRequest = await prisma.withdrawal_requests.findUnique({
      where: { id: requestId },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
            personalCoin: true
          }
        }
      }
    });

    if (!existingRequest) {
      return NextResponse.json(
        { ok: false, error: { code: 'NOT_FOUND', message: '요청을 찾을 수 없습니다.' } }, { status: 404 });
    }

    if (existingRequest.status !== 'PENDING') {
      return NextResponse.json(
        { ok: false, error: { code: 'ALREADY_PROCESSED', message: '이미 처리된 요청입니다.' } }, { status: 400 });
    }

    // 트랜잭션으로 처리 (원자적 처리)
    const result = await prisma.$transaction(async (tx) => {
      const now = new Date();
      const requestedAmount = new Prisma.Decimal(existingRequest.amount);
      const currentBalance = new Prisma.Decimal(existingRequest.users.personalCoin || 0);

      if (action === 'APPROVE') {
        // 승인: 잔액 확인 및 차감
        if (currentBalance.lt(requestedAmount)) {
          throw new Error('잔액이 부족합니다.');
        }

        // 원자적 업데이트 (PENDING 상태인 경우만)
        const updated = await tx.withdrawal_requests.updateMany({
          where: { 
            id: requestId, 
            status: 'PENDING' 
          },
          data: { 
            status: 'APPROVED', 
            processedAt: now 
          },
        });

        if (updated.count === 0) {
          throw new Error('이미 처리된 요청이거나 상태가 변경되었습니다.');
        }

        // 사용자 코인 차감
        await tx.users.update({
          where: { id: existingRequest.userId },
          data: {
            personalCoin: {
              decrement: requestedAmount
            }
          }
        });

        // 출금 기록은 WithdrawalRequest의 processedAt으로 관리
      } else {
        // 거절: 원자적 업데이트만 (이미 차감되지 않았으므로 환불 불필요)
        const updated = await tx.withdrawal_requests.updateMany({
          where: { 
            id: requestId, 
            status: 'PENDING' 
          },
          data: { 
            status: 'REJECTED', 
            processedAt: now 
          },
        });

        if (updated.count === 0) {
          throw new Error('이미 처리된 요청이거나 상태가 변경되었습니다.');
        }
      }

      // 업데이트된 요청 반환
      const updatedRequest = await tx.withdrawal_requests.findUnique({
        where: { id: requestId },
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
              personalCoin: true
            }
          }
        }
      });

      return updatedRequest!;
    }, {
      maxWait: 30000,
      timeout: 30000,
    });

    // 알림은 선택적 (Notification 모델이 있는 경우에만)

    return NextResponse.json({
      ok: true,
      message: `출금 요청이 ${action === 'APPROVE' ? '승인' : '거절'}되었습니다.`,
      data: {
        request: {
          id: result.id,
          status: result.status,
          processedAt: result.processedAt,
          userBalance: result.users.personalCoin ? Number(result.users.personalCoin) : 0
        }
      }
    });

  } catch (error) {
    console.error(`[API] 캠페인 요청 처리 실패:`, error);

    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '요청 처리 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}

// 일괄 처리 API
export async function PUT(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const body = await request.json();
    const { requestIds, action, reason } = body;

    if (!requestIds || !Array.isArray(requestIds) || requestIds.length === 0) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '처리할 요청 ID 목록이 필요합니다.' } }, { status: 400 });
    }

    if (!action || !['APPROVE', 'REJECT'].includes(action)) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '유효하지 않은 액션입니다.' } }, { status: 400 });
    }

    console.log(`[API] 출금 요청 일괄 ${action} 처리: ${requestIds.length}개`);

    const results = [];
    const errors = [];

    // 각 요청 개별 처리
    for (const requestId of requestIds) {
      try {
        // 기존 요청 확인
        const existingRequest = await prisma.withdrawal_requests.findUnique({
          where: { id: requestId },
          include: {
            users: {
              select: {
                id: true,
                username: true,
                email: true,
                personalCoin: true
              }
            }
          }
        });

        if (!existingRequest) {
          errors.push({ requestId, error: '요청을 찾을 수 없습니다.' });
          continue;
        }

        if (existingRequest.status !== 'PENDING') {
          errors.push({ requestId, error: '이미 처리된 요청입니다.' });
          continue;
        }

        // 트랜잭션으로 처리 (원자적 처리)
        const result = await prisma.$transaction(async (tx) => {
          const now = new Date();
          const requestedAmount = new Prisma.Decimal(existingRequest.amount);
          const currentBalance = new Prisma.Decimal(existingRequest.users.personalCoin || 0);

          if (action === 'APPROVE') {
            // 승인: 잔액 확인 및 차감
            if (currentBalance.lt(requestedAmount)) {
              throw new Error('잔액이 부족합니다.');
            }

            // 원자적 업데이트
            const updated = await tx.withdrawal_requests.updateMany({
              where: { 
                id: requestId, 
                status: 'PENDING' 
              },
              data: { 
                status: 'APPROVED', 
                processedAt: now 
              },
            });

            if (updated.count === 0) {
              throw new Error('이미 처리된 요청이거나 상태가 변경되었습니다.');
            }

            // 사용자 코인 차감
            await tx.users.update({
              where: { id: existingRequest.userId },
              data: {
                personalCoin: {
                  decrement: requestedAmount
                }
              }
            });

            // 출금 기록은 WithdrawalRequest의 processedAt으로 관리
          } else {
            // 거절: 원자적 업데이트만
            const updated = await tx.withdrawal_requests.updateMany({
              where: { 
                id: requestId, 
                status: 'PENDING' 
              },
              data: { 
                status: 'REJECTED', 
                processedAt: now 
              },
            });

            if (updated.count === 0) {
              throw new Error('이미 처리된 요청이거나 상태가 변경되었습니다.');
            }
          }

          // 업데이트된 요청 반환
          const updatedRequest = await tx.withdrawal_requests.findUnique({
            where: { id: requestId },
            include: {
              users: {
                select: {
                  id: true,
                  username: true,
                  email: true,
                  personalCoin: true
                }
              }
            }
          });

          return updatedRequest!;
        }, {
          maxWait: 30000,
          timeout: 30000,
        });

        // 알림은 선택적 (Notification 모델이 있는 경우에만)

        results.push({
          requestId,
          success: true,
          amount: Number(existingRequest.amount),
          status: action === 'APPROVE' ? 'APPROVED' : 'REJECTED'
        });

      } catch (error) {
        console.error(`[API] 출금 요청 ${requestId} 처리 실패:`, error);
        errors.push({
          requestId,
          error: error instanceof Error ? error.message : '처리 실패'
        });
      }
    }

    return NextResponse.json({
      ok: true,
      message: `${results.length}개 출금 요청이 ${action === 'APPROVE' ? '승인' : '거절'}되었습니다.`,
      data: {
        processed: results,
        errors,
        summary: {
          total: requestIds.length,
          success: results.length,
          failed: errors.length,
          totalAmount: results.reduce((sum, r) => sum + r.amount, 0)
        }
      }
    });

  } catch (error) {
    console.error('[API] 출금 요청 일괄 처리 실패:', error);

    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '일괄 처리 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}
