import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100);
    const status = searchParams.get('status');
    const userId = searchParams.get('userId');
    const search = searchParams.get('search');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    const skip = (page - 1) * limit;

    console.log(`[API] 출금 요청 목록 조회 (page: ${page}, limit: ${limit})`);

    // 필터 조건 구성
    const whereCondition: any = {};

    if (status && status !== 'all') {
      whereCondition.status = status;
    }

    if (userId) {
      whereCondition.userId = userId;
    }

    if (search) {
      whereCondition.users = {
        OR: [
          { username: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { walletAddress: { contains: search, mode: 'insensitive' } }
        ]
      };
    }

    if (startDate || endDate) {
      whereCondition.requestedAt = {};
      if (startDate) {
        whereCondition.requestedAt.gte = new Date(startDate);
      }
      if (endDate) {
        whereCondition.requestedAt.lte = new Date(endDate);
      }
    }

    // 캠펈인 요청 목록과 사용자 정보 함께 조회
    const [requests, totalCount] = await Promise.all([
      prisma.withdrawal_requests.findMany({
        where: whereCondition,
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
              walletAddress: true,
              rank: true,
              personalCoin: true
            }
          }
        },
        orderBy: [
          { requestedAt: 'desc' },
          { status: 'asc' }
        ],
        skip,
        take: limit
      }),
      prisma.withdrawal_requests.count({ where: whereCondition })
    ]);

    // 통계 정보 계산
    const stats = await prisma.withdrawal_requests.groupBy({
      by: ['status'],
      _sum: {
        amount: true
      },
      _count: {
        id: true
      },
      where: whereCondition
    });

    const totalRequested = stats.reduce((sum, stat) => sum + Number(stat._sum.amount || 0), 0);
    const statusDistribution = stats.map(stat => ({
      status: stat.status,
      count: stat._count.id,
      amount: Number(stat._sum.amount || 0),
      percentage: totalRequested > 0 ? (Number(stat._sum.amount || 0) / totalRequested) * 100 : 0
    }));

    // 금액대기 정렬된 상위 캠펱인 요청
    const topAmountRequests = await prisma.withdrawal_requests.findMany({
      where: whereCondition,
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
            rank: true,
            walletAddress: true
          }
        }
      },
      orderBy: {
        amount: 'desc'
      },
      take: 10
    });

    const response = {
      ok: true,
      message: '캠펈인 요청 목록 조회 완료',
      data: {
        requests: requests.map(request => ({
          id: request.id,
          userId: request.userId,
          username: request.users?.username,
          email: request.users?.email,
          walletAddress: request.users?.walletAddress,
          userRank: request.users?.rank,
          userBalance: request.users?.personalCoin ? Number(request.users.personalCoin) : 0,
          amount: Number(request.amount),
          address: request.address,
          status: request.status,
          requestedAt: request.requestedAt,
          processedAt: request.processedAt
        })),
        pagination: {
          page,
          limit,
          total: totalCount,
          totalPages: Math.ceil(totalCount / limit),
          hasNext: page * limit < totalCount,
          hasPrev: page > 1
        },
        statistics: {
          totalRequests: totalCount,
          totalRequested,
          statusDistribution,
          topAmountRequests: topAmountRequests.map(req => ({
            ...req,
            amount: Number(req.amount)
          })),
          averageAmount: totalCount > 0 ? totalRequested / totalCount : 0
        }
      }
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('[API] 캠펈인 요청 목록 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '캠펈인 요청 목록 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}