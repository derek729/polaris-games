import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { updateAllUserRanks } from '@/services/ranking-service';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';

export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    console.log('[API] 랭크 업데이트 요청 시작');

    // 모든 사용자 랭크 업데이트 실행
    const result = await updateAllUserRanks();

    return NextResponse.json({
      ok: true,
      message: '사용자 랭크 업데이트 완료',
      data: {
        summary: {
          totalUsers: result.totalUsers,
          rankChanges: result.rankChanges,
          errors: result.errors.length
        },
        details: {
          upgraded: result.users.filter(u => u.rankChange === 'upgraded'),
          downgraded: result.users.filter(u => u.rankChange === 'downgraded'),
          errors: result.errors
        }
      }
    });

  } catch (error) {
    console.error('[API] 랭크 업데이트 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '랭크 업데이트 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    return NextResponse.json({
      ok: true,
      message: '랭크 업데이트 API',
      description: 'POST 요청으로 모든 사용자의 랭크를 스테이킹 양에 따라 업데이트합니다.'
    });

  } catch (error) {
    console.error('[API] 랭크 업데이트 정보 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '정보 조회 중 오류가 발생했습니다.' } }, { status: 500 });
  }
}