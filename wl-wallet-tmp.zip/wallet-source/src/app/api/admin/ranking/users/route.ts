import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { getUsersByRank } from '@/services/ranking-service';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    const { searchParams } = new URL(request.url);
    const rankLevel = parseInt(searchParams.get('rank') || '1');
    const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 100); // 최대 100개 제한

    if (rankLevel < 1 || rankLevel > 10) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '유효하지 않은 랭크 레벨입니다. 1-10 사이의 값을 입력해주세요.' } }, { status: 400 });
    }

    console.log(`[API] 랭크 ${rankLevel} 사용자 조회 요청 (limit: ${limit})`);

    const users = await getUsersByRank(rankLevel, limit);

    return NextResponse.json({
      ok: true,
      message: `랭크 ${rankLevel} 사용자 조회 완료`,
      data: {
        rankLevel,
        users,
        count: users.length,
        limit
      }
    });

  } catch (error) {
    console.error('[API] 랭크 사용자 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '랭크 사용자 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}