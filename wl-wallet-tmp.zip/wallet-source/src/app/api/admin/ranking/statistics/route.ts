import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { getRankStatistics, getStakingPoolStatus } from '@/services/ranking-service';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    console.log('[API] 랭크 통계 조회 요청');

    // 랭크 통계와 스테이킹 풀 현황 병렬 조회
    const [rankStats, stakingPoolStatus] = await Promise.all([
      getRankStatistics(),
      getStakingPoolStatus()
    ]);

    return NextResponse.json({
      ok: true,
      message: '랭크 통계 조회 완료',
      data: {
        rankStatistics: rankStats,
        stakingPoolStatus: stakingPoolStatus,
        lastUpdated: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('[API] 랭크 통계 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '랭크 통계 조회 중 오류가 발생했습니다.', details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined } }, { status: 500 });
  }
}