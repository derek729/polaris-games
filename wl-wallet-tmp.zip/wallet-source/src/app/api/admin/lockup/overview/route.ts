import { NextRequest } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth';
import { withErrorHandler, successResponse } from '@/lib/api-response';
import { LockupService } from '@/services/lockup/LockupService';

export async function GET(request: NextRequest) {
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  return withErrorHandler(async () => {
    const overview = await LockupService.getOverview();
    return successResponse({
      message: '락업 현황 조회',
      overview,
    });
  });
}

