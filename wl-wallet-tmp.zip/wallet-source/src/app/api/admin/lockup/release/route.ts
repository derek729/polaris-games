import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { LockupService } from '@/services/lockup/LockupService';

export async function POST(req: NextRequest) {
  try {
    // 관리자 권한 확인
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return errorResponse('인증이 필요합니다.', 'UNAUTHORIZED');
    }

    const body = await req.json();
    const { userId } = body;

    // 월별 락업 해제 처리
    const result = await LockupService.processMonthlyRelease(userId);

    return successResponse(result);
  } catch (error) {
    console.error('락업 해제 처리 실패:', error);
    return errorResponse(error instanceof Error ? error.message : '락업 해제 처리 중 오류가 발생했습니다.', 'SERVER_ERROR');
  }
}