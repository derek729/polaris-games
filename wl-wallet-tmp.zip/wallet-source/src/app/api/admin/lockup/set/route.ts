import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth';
import { withErrorHandler, successResponse, validationErrorResponse } from '@/lib/api-response';
import { LockupService } from '@/services/lockup/LockupService';

export async function POST(request: NextRequest) {
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  return withErrorHandler(async () => {
    const body = await request.json();
    const { userId, lockedAmount, lockPeriodMonths, releaseRatePercent, tokenSymbol, startDate } = body || {};

    if (!userId) {
      return validationErrorResponse('userId가 필요합니다.');
    }
    if (!lockedAmount || isNaN(parseFloat(lockedAmount))) {
      return validationErrorResponse('lockedAmount를 올바르게 입력하세요.');
    }
    if (![3, 6, 12].includes(Number(lockPeriodMonths))) {
      return validationErrorResponse('lockPeriodMonths는 3, 6, 12 중 하나여야 합니다.');
    }
    if (releaseRatePercent < 1 || releaseRatePercent > 100) {
      return validationErrorResponse('releaseRatePercent는 1~100 범위여야 합니다.');
    }

    const setting = await LockupService.setUserLockup({
      userId,
      tokenSymbol,
      lockedAmount,
      releaseRatePercent,
      lockPeriodMonths,
      startDate: startDate ? new Date(startDate) : undefined,
    });

    return successResponse({
      message: '락업 설정이 저장되었습니다.',
      setting,
    });
  });
}

