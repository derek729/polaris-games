import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return errorResponse('인증이 필요합니다.', 'UNAUTHORIZED');
    }

    // 락업 설정 목록 조회
    const settings = await prisma.lockup_settings.findMany({
      include: {
        users: {
          select: {
            username: true,
            email: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return successResponse(settings);
  } catch (error) {
    console.error('락업 설정 조회 실패:', error);
    return errorResponse('락업 설정 조회 중 오류가 발생했습니다.', 'SERVER_ERROR');
  }
}

export async function POST(req: NextRequest) {
  try {
    // 관리자 권한 확인
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return errorResponse('인증이 필요합니다.', 'UNAUTHORIZED');
    }

    const body = await req.json();
    const { userId, tokenSymbol, lockedAmount, releaseRatePercent, lockPeriodMonths } = body;

    // 락업 설정 생성
    const setting = await prisma.lockup_settings.create({
        data: {
        userId,
        tokenSymbol: tokenSymbol || 'MSUO',
        lockedAmount: parseFloat(lockedAmount),
        releaseRatePercent: parseInt(releaseRatePercent),
        lockPeriodMonths: parseInt(lockPeriodMonths),
        endDate: new Date(Date.now() + parseInt(lockPeriodMonths) * 30 * 24 * 60 * 60 * 1000),
        releasedAmount: 0,
        remainingAmount: parseFloat(lockedAmount),
        status: 'LOCKED',
        id: crypto.randomUUID(),
        updatedAt: new Date(),
        }
    });

    return NextResponse.json({
      ok: true,
      data: setting,
    });
  } catch (error) {
    console.error('락업 설정 생성 실패:', error);
    return NextResponse.json(
      { error: 'Failed to create lockup setting' },
      { status: 500 }
    );
  }
}
