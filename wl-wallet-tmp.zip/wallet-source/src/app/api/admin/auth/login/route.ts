import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, email, password } = body;

    // 입력 타입 검증
    if (typeof password !== 'string' || password.trim().length === 0) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_CREDENTIALS', message: '비밀번호를 입력해주세요.' } }, { status: 400 });
    }

    if (username && typeof username !== 'string') {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '잘못된 사용자명 형식입니다.' } }, { status: 400 });
    }

    if (email && typeof email !== 'string') {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_INPUT', message: '잘못된 이메일 형식입니다.' } }, { status: 400 });
    }

    // 사용자 조회 - 필요한 컬럼만 선택
    const user = await prisma.users.findFirst({
      where: {
        OR: [
          username ? { username } : {},
          email ? { email } : {},
        ].filter(condition => Object.keys(condition).length > 0),
      },
      select: {
        id: true,
        username: true,
        email: true,
        password: true,
        role: true,
        rank: true,
        isActive: true,
        status: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        { ok: false, error: { code: 'USER_NOT_FOUND', message: '존재하지 않는 사용자입니다.' } }, { status: 401 });
    }

    // 비밀번호 검증
    if (!user.password) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_CREDENTIALS', message: '소셜 로그인 사용자입니다. 일반 로그인을 사용할 수 없습니다.' } }, { status: 401 });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return NextResponse.json(
        { ok: false, error: { code: 'INVALID_CREDENTIALS', message: '비밀번호가 올바르지 않습니다.' } }, { status: 401 });
    }

    // 관리자 권한 확인
    if (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { ok: false, error: { code: 'ADMIN_ONLY', message: '관리자 권한이 없습니다.' } }, { status: 403 });
    }

    // 계정 상태 확인
    if (!user.isActive || user.status !== 'ACTIVE') {
      return NextResponse.json(
        { ok: false, error: { code: 'FORBIDDEN', message: '비활성화된 계정입니다.' } }, { status: 403 });
    }

    // 관리자 전용 쿠키 설정 (adminUserId)
    const cookieStore = await cookies();
    cookieStore.set('adminUserId', user.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24, // 24시간
      path: '/',
    });

    return NextResponse.json({
      ok: true,
      message: '관리자 로그인 성공',
      data: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        rank: user.rank,
      },
    });
  } catch (error) {
    console.error('Admin login error:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '로그인 중 오류가 발생했습니다.' } }, { status: 500 });
  }
}
