import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { cookies } from 'next/headers';

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies();

    // 관리자 쿠키 삭제
    cookieStore.delete('adminUserId');

    return NextResponse.json({
      ok: true,
      message: '관리자 로그아웃 성공',
    });
  } catch (error) {
    console.error('Admin logout error:', error);
    return errorResponse('로그아웃 중 오류가 발생했습니다.', 'SERVER_ERROR');
  }
}