import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { getCurrentAdminUser } from '@/lib/admin-auth';

export async function GET(request: NextRequest) {
  try {
    const adminUser = await getCurrentAdminUser();

    if (!adminUser) {
      return NextResponse.json(
        { ok: false, error: { code: 'UNAUTHORIZED', message: '관리자 인증이 필요합니다.' } }, { status: 401 });
    }

    return NextResponse.json({
      ok: true,
      data: {
        id: adminUser.id,
        username: adminUser.username,
        email: adminUser.email,
        role: adminUser.role,
        rank: adminUser.rank,
        status: adminUser.status,
        isActive: adminUser.isActive,
      },
    });
  } catch (error) {
    console.error('Admin session check error:', error);
    return NextResponse.json(
      { ok: false, error: { code: 'SERVER_ERROR', message: '서버 오류가 발생했습니다.' } }, { status: 500 });
  }
}