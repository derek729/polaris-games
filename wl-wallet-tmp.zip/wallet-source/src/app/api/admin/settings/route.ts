import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, serverErrorResponse } from '@/lib/api-response';

/**
 * 시스템 설정 조회
 * GET /api/admin/settings
 */
export async function GET(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const settings = await prisma.system_settings.findMany({
      orderBy: { key: 'asc' },
    });

    const settingsMap = settings.reduce((acc: Record<string, string>, curr: { key: string; value: string }) => {
      acc[curr.key] = curr.value;
      return acc;
    }, {} as Record<string, string>);

    return successResponse(settingsMap);
  } catch (error) {
    if (process.env.NODE_ENV === 'development') {
      console.error('[Admin Settings] 설정 조회 실패:', error);
    }
    return serverErrorResponse('설정 조회 실패');
  }
}

/**
 * 시스템 설정 저장
 * PUT /api/admin/settings
 */
export async function PUT(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const updates: Array<{ key: string; value: string; description?: string }> = [];

    // 코인 설정
    if (body.upcTotalSupply !== undefined) {
      updates.push({
        key: 'upcTotalSupply',
        value: String(body.upcTotalSupply),
        description: 'MSUO 총 발행량 (100억개)',
      });
    }

    if (body.upcInitialPrice !== undefined) {
      updates.push({
        key: 'upcInitialPrice',
        value: String(body.upcInitialPrice),
        description: 'MSUO 초기 가격 (USDT)',
      });
    }

    if (body.upcCurrentPrice !== undefined) {
      updates.push({
        key: 'upcCurrentPrice',
        value: String(body.upcCurrentPrice),
        description: 'MSUO 현재 가격 (USDT)',
      });
    }

    // 스테이킹 설정
    if (body.stakingApy !== undefined) {
      updates.push({
        key: 'stakingApy',
        value: String(body.stakingApy),
        description: '스테이킹 연이율 (%)',
      });
    }

    if (body.stakingMinAmount !== undefined) {
      updates.push({
        key: 'stakingMinAmount',
        value: String(body.stakingMinAmount),
        description: '스테이킹 최소 금액 (MSUO)',
      });
    }

    if (body.stakingMaxAmount !== undefined) {
      updates.push({
        key: 'stakingMaxAmount',
        value: String(body.stakingMaxAmount),
        description: '스테이킹 최대 금액 (MSUO)',
      });
    }

    if (body.stakingLockPeriod !== undefined) {
      updates.push({
        key: 'stakingLockPeriod',
        value: String(body.stakingLockPeriod),
        description: '스테이킹 락업 기간 (일)',
      });
    }

    // 전송 수수료 설정
    if (body.transferFeeOzCoin !== undefined) {
      updates.push({
        key: 'transferFeeOzCoin',
        value: String(body.transferFeeOzCoin),
        description: '전송 수수료 (OZCOIN)',
      });
    }

    // 거래소 설정
    if (body.exchangeBotEnabled !== undefined) {
      updates.push({
        key: 'exchangeBotEnabled',
        value: String(body.exchangeBotEnabled),
        description: '거래 봇 활성화 여부',
      });
    }

    if (body.exchangeBotMinPrice !== undefined) {
      updates.push({
        key: 'exchangeBotMinPrice',
        value: String(body.exchangeBotMinPrice),
        description: '거래 봇 최저가 (USDT)',
      });
    }

    if (body.exchangeBotMaxPrice !== undefined) {
      updates.push({
        key: 'exchangeBotMaxPrice',
        value: String(body.exchangeBotMaxPrice),
        description: '거래 봇 최고가 (USDT)',
      });
    }

    if (body.exchangeBotSpread !== undefined) {
      updates.push({
        key: 'exchangeBotSpread',
        value: String(body.exchangeBotSpread),
        description: '거래 봇 스프레드 (USDT)',
      });
    }

    if (body.exchangeBotOrderAmount !== undefined) {
      updates.push({
        key: 'exchangeBotOrderAmount',
        value: String(body.exchangeBotOrderAmount),
        description: '거래 봇 주문 수량 (MSUO)',
      });
    }

    // 전체 오더 체결 시 나가기 허용 설정
    if (body.allowExitOnFullOrder !== undefined) {
      updates.push({
        key: 'allowExitOnFullOrder',
        value: String(body.allowExitOnFullOrder),
        description: '전체 오더 체결 시 나가기 허용 여부',
      });
    }

    // USDT 입금 주소
    if (body.usdtAddress !== undefined) {
      updates.push({
        key: 'usdtAddress',
        value: String(body.usdtAddress),
        description: 'USDT 입금 주소',
      });
    }

    // 모든 설정 업데이트
    await Promise.all(
      updates.map((update) =>
        prisma.system_settings.upsert({
          where: { key: update.key },
          update: { value: update.value, description: update.description },
          create: {
            key: update.key,
            value: update.value,
            description: update.description,
          },
        })
      )
    );

    return successResponse(undefined, '설정이 저장되었습니다.');
  } catch (error: any) {
    if (process.env.NODE_ENV === 'development') {
      console.error('[Admin Settings] 설정 저장 실패:', error);
    }
    return errorResponse(
      (error instanceof Error ? error.message : String(error)) || '설정 저장 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

