import { NextRequest, NextResponse } from 'next/server';
import { errorResponse, successResponse } from '@/lib/api-response';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { UserRole } from '@prisma/client';

export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    // 오늘 날짜 (UTC)
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000);

    // 이번 달 시작
    const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);

    // 기본 개요 데이터
    const [
      totalUsers,
      activeUsers,
      todayUsers,
      totalInvestmentData,
      totalWithdrawalData,
      totalRewardsData,
      recentUsers,
      recentWithdrawals,
      rankDistribution,
      topInvestors
    ] = await Promise.all([
      // 총 사용자 수
      prisma.users.count({
        where: {
          isActive: true,
          status: 'ACTIVE'
        }
      }),

      // 활성 사용자 수 (최근 30일 내 로그인)
      prisma.users.count({
        where: {
          isActive: true,
          status: 'ACTIVE',
          updatedAt: {
            gte: new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)
          }
        }
      }),

      // 오늘 가입한 사용자 수
      prisma.users.count({
        where: {
          isActive: true,
          status: 'ACTIVE',
          createdAt: {
            gte: todayStart,
            lt: todayEnd
          }
        }
      }),

      // 총 투자 금액 = 스테이킹 총액
      prisma.staking_records.aggregate({
        where: {
          status: 'ACTIVE'
        },
        _sum: {
          stakedAmount: true
        },
        _count: true
      }),

      // 총 출금 금액 = 스테이킹 이자 출금 + 게임 수익 출금
      prisma.withdrawal_requests.aggregate({
        where: {
          status: 'APPROVED'
        },
        _sum: {
          amount: true
        },
        _count: true
      }),

      // 총 리워드 금액 = 스테이킹 이자 수익 지급
      prisma.staking_records.aggregate({
        _sum: {
          rewardAmount: true
        },
        _count: true
      }),

      // 최근 가입자
      prisma.users.findMany({
        where: {
          isActive: true,
          status: 'ACTIVE'
        },
        select: {
          id: true,
          username: true,
          email: true,
          rank: true,
          totalInvestment: true,
          createdAt: true,
          other_users_users_referrerIdTousers: {
            select: {
              username: true
            }
          }
        },
        orderBy: {
          createdAt: 'desc'
        },
        take: 5
      }),

      // 최근 출금 요청
      prisma.withdrawal_requests.findMany({
        select: {
          id: true,
          amount: true,
          status: true,
          requestedAt: true,
          users: {
            select: {
              username: true,
              email: true
            }
          }
        },
        orderBy: {
          requestedAt: 'desc'
        },
        take: 5
      }),

      // 랭크 분포
      prisma.users.groupBy({
        by: ['rank'],
        where: {
          isActive: true,
          status: 'ACTIVE'
        },
        _count: {
          id: true
        }
      }),

      // 상위 투자자 (스테이킹 기준)
      prisma.users.findMany({
        where: {
          isActive: true,
          status: 'ACTIVE'
        },
        select: {
          id: true,
          username: true,
          email: true,
          rank: true,
          totalInvestment: true,
          createdAt: true,
          staking_records: {
            where: {
              status: 'ACTIVE'
            },
            select: {
              id: true,
              stakedAmount: true
            }
          },
          other_users_users_referrerIdTousers: {
            select: {
              id: true
            }
          }
        },
        take: 5
      })
    ]);

    // 오늘 투자/출금/리워드 계산
    const [todayInvestment, todayWithdrawal, todayRewards] = await Promise.all([
      // 오늘 스테이킹 총액
      prisma.staking_records.aggregate({
        where: {
          stakedAt: {
            gte: todayStart,
            lt: todayEnd
          }
        },
        _sum: {
          stakedAmount: true
        }
      }),

      // 오늘 출금 (스테이킹 이자 + 게임 수익)
      prisma.withdrawal_requests.aggregate({
        where: {
          requestedAt: {
            gte: todayStart,
            lt: todayEnd
          }
        },
        _sum: {
          amount: true
        }
      }),

      // 오늘 스테이킹 이자 지급
      prisma.staking_records.aggregate({
        where: {
          updatedAt: {
            gte: todayStart,
            lt: todayEnd
          },
          rewardAmount: {
            gt: 0
          }
        },
        _sum: {
          rewardAmount: true
        }
      })
    ]);

    // 이번 달 투자/리워드 계산
    const [monthlyInvestment, monthlyRewards] = await Promise.all([
      // 이번 달 스테이킹 총액
      prisma.staking_records.aggregate({
        where: {
          stakedAt: {
            gte: thisMonthStart
          }
        },
        _sum: {
          stakedAmount: true
        }
      }),

      // 이번 달 스테이킹 이자 지급
      prisma.staking_records.aggregate({
        where: {
          updatedAt: {
            gte: thisMonthStart
          },
          rewardAmount: {
            gt: 0
          }
        },
        _sum: {
          rewardAmount: true
        }
      })
    ]);

    // 출금 상태별 개수
    const withdrawalStatusCounts = await prisma.withdrawal_requests.groupBy({
      by: ['status'],
      _count: true
    });

    const pendingWithdrawals = withdrawalStatusCounts.find(w => w.status === 'PENDING')?._count || 0;
    const approvedWithdrawals = withdrawalStatusCounts.find(w => w.status === 'APPROVED')?._count || 0;
    const rejectedWithdrawals = withdrawalStatusCounts.find(w => w.status === 'REJECTED')?._count || 0;

    // 활성 스테이킹 수
    const activeInvestments = await prisma.staking_records.count({
      where: {
        status: 'ACTIVE'
      }
    });

    // 투자 성장률 계산 (지난 달 대비)
    const lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 1);

    const lastMonthInvestment = await prisma.staking_records.aggregate({
      where: {
        stakedAt: {
          gte: lastMonthStart,
          lt: lastMonthEnd
        }
      },
      _sum: {
        stakedAmount: true
      }
    });

    const investmentGrowthRate = lastMonthInvestment._sum.stakedAmount
      ? ((Number(monthlyInvestment._sum.stakedAmount || 0) - Number(lastMonthInvestment._sum.stakedAmount)) / Number(lastMonthInvestment._sum.stakedAmount)) * 100
      : 0;

    // 시스템 지표
    const firstInvestment = await prisma.staking_records.findFirst({
      orderBy: {
        stakedAt: 'asc'
      },
      select: {
        stakedAt: true
      }
    });

    const firstWithdrawal = await prisma.withdrawal_requests.findFirst({
      orderBy: {
        requestedAt: 'asc'
      },
      select: {
        requestedAt: true
      }
    });

    const firstReward = await prisma.staking_records.findFirst({
      where: {
        rewardAmount: {
          gt: 0
        }
      },
      orderBy: {
        updatedAt: 'asc'
      },
      select: {
        updatedAt: true
      }
    });

    const firstUser = await prisma.users.findFirst({
      orderBy: {
        createdAt: 'asc'
      },
      select: {
        createdAt: true
      }
    });

    const daysSinceLaunch = firstUser
      ? Math.floor((today.getTime() - firstUser.createdAt.getTime()) / (1000 * 60 * 60 * 24))
      : 0;

    // 응답 데이터 구성
    const dashboardData = {
      overview: {
        totalUsers,
        activeUsers,
        todayUsers,
        totalInvestment: Number(totalInvestmentData._sum.stakedAmount || 0),
        totalInvestmentCount: totalInvestmentData._count,
        activeInvestments,
        monthlyInvestment: Number(monthlyInvestment._sum.stakedAmount || 0),
        investmentGrowthRate,
        todayInvestment: Number(todayInvestment._sum.stakedAmount || 0),
        totalWithdrawal: Number(totalWithdrawalData._sum.amount || 0),
        pendingWithdrawals,
        approvedWithdrawals,
        rejectedWithdrawals,
        todayWithdrawal: Number(todayWithdrawal._sum.amount || 0),
        totalRewards: Number(totalRewardsData._sum.rewardAmount || 0),
        monthlyRewards: Number(monthlyRewards._sum.rewardAmount || 0),
        todayRewards: Number(todayRewards._sum.rewardAmount || 0),
      },
      rankDistribution: rankDistribution.map(rank => ({
        rank: rank.rank,
        count: rank._count.id
      })),
      recentActivities: {
        newUsers: recentUsers.map(user => ({
          id: user.id,
          username: user.username,
          email: user.email,
          rank: user.rank,
          totalInvestment: Number(user.totalInvestment),
          createdAt: user.createdAt.toISOString(),
          other_users_users_referrerIdTousers: user.other_users_users_referrerIdTousers && user.other_users_users_referrerIdTousers[0] ? { username: user.other_users_users_referrerIdTousers[0].username } : undefined
        })),
        withdrawals: recentWithdrawals.map(withdrawal => ({
          id: withdrawal.id,
          amount: Number(withdrawal.amount),
          status: withdrawal.status,
          requestedAt: withdrawal.requestedAt.toISOString(),
          users: withdrawal.users
        }))
      },
      topInvestors: topInvestors.map(investor => {
        const totalStaked = investor.staking_records.reduce((sum, record) => sum + Number(record.stakedAmount), 0);
        return {
          id: investor.id,
          username: investor.username,
          email: investor.email,
          rank: investor.rank,
          totalInvestment: totalStaked,
          createdAt: investor.createdAt.toISOString(),
          _count: {
            other_users_users_referrerIdTousers: investor.other_users_users_referrerIdTousers.length,
            investments: investor.staking_records.length
          }
        };
      }).sort((a, b) => b.totalInvestment - a.totalInvestment),
      systemMetrics: {
        daysSinceLaunch,
        firstInvestmentDate: firstInvestment?.stakedAt.toISOString(),
        firstWithdrawalDate: firstWithdrawal?.requestedAt.toISOString(),
        firstRewardDate: firstReward?.updatedAt.toISOString(),
      }
    };

    return NextResponse.json({
      ok: true,
      data: dashboardData,
    });

  } catch (error) {
    console.error('Admin dashboard error:', error);
    return errorResponse('대시보드 데이터를 불러오는 중 오류가 발생했습니다.', 'SERVER_ERROR');
  }
}