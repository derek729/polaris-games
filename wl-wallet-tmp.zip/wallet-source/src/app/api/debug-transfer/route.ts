import { NextRequest } from 'next/server';

export async function POST(_request: NextRequest) {
  if (process.env.NODE_ENV === 'production') {
    return Response.json({ ok: false, error: 'This endpoint is not available in production.' }, { status: 403 });
  }
  return Response.json({ ok: false, error: 'This endpoint is not available in production.' }, { status: 403 });
}
