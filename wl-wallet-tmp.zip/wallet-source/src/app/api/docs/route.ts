/**
 * Swagger API 문서 엔드포인트
 * GET /api/docs - OpenAPI JSON 스펙 반환
 */

import { NextResponse } from 'next/server'
import { getApiDocs } from '@/lib/swagger'

/**
 * @swagger
 * /api/docs:
 *   get:
 *     summary: API 문서 (OpenAPI 스펙)
 *     description: OpenAPI 3.0 형식의 API 문서를 반환합니다.
 *     tags:
 *       - Documentation
 *     responses:
 *       200:
 *         description: OpenAPI JSON 스펙
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 */
export async function GET() {
  try {
    const spec = await getApiDocs()
    return NextResponse.json(spec)
  } catch (error) {
    console.error('Error generating API docs:', error)
    return NextResponse.json(
      { success: false, message: 'API 문서 생성 실패' },
      { status: 500 }
    )
  }
}
