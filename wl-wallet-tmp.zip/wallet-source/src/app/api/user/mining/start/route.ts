import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import { HARDWARE_PRESETS } from '@/lib/mining-physics';
import * as miningService from '@/services/miningService';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    let body: Record<string, unknown>;
    try {
      body = await request.json();
    } catch {
      return validationErrorResponse('유효하지 않은 JSON 요청입니다.');
    }

    const { hardwareId, miningUnits = 1 } = body;

    const hardwareIdStr = String(hardwareId ?? '');
    const presetIndex = parseInt(hardwareIdStr.replace('preset_', '') || '-1', 10);
    const hardware = HARDWARE_PRESETS[presetIndex];
    if (!hardware) return validationErrorResponse('유효하지 않은 채굴 장비입니다.');

    const units = Math.max(1, Math.min(Number(miningUnits) || 1, 100));

    const hardwareHashrate = hardware.hashrate * units;

    let slotBonusPercent = 0;
    try {
      const { getTotalSlotHashrate } = await import('@/services/referralSlotService');
      slotBonusPercent = await getTotalSlotHashrate(user.id);
    } catch { /* slots not initialized yet */ }

    const totalHashrate = hardwareHashrate * (1 + slotBonusPercent / 100);

    const hardwareInfo = {
      hardwareName: hardware.name,
      rawHashrate: hardwareHashrate,
      slotBonusPercent,
      totalHashrate,
      unitCount: units,
      powerConsumption: hardware.powerConsumption * units,
      algorithm: hardware.algorithm,
    };

    const ipAddress = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const userAgent = request.headers.get('user-agent') || 'unknown';

    const session = await miningService.startMiningSession(user.id, hardwareInfo, ipAddress, userAgent);

    return successResponse({
      sessionId: session?.sessionId,
      startedAt: session?.startTime,
      hashrate: session?.hashrate?.toString(),
      slotBonusPercent,
      hardwareHashrate: hardwareHashrate.toString(),
      totalHashrate: totalHashrate.toString(),
      message: '채굴이 시작되었습니다.',
    });
  } catch (error: unknown) {
    console.error('[Start Mining] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    const msg = error instanceof Error ? error.message : '채굴 시작 중 오류가 발생했습니다.';
    return errorResponse(msg, ErrorCode.SERVER_ERROR);
  }
}
