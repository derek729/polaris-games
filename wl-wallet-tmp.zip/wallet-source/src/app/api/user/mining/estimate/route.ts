import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as miningService from '@/services/miningService';
import { Decimal } from '@prisma/client/runtime/library';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const { searchParams } = new URL(request.url);
    const hashrateParam = searchParams.get('hashrate') || '0';
    const stakeAmountParam = searchParams.get('stakeAmount') || '0';

    const hashrateNum = parseFloat(hashrateParam);
    const stakeNum = parseFloat(stakeAmountParam);
    if (isNaN(hashrateNum) || hashrateNum < 0) return validationErrorResponse('유효하지 않은 해시레이트입니다.');
    if (isNaN(stakeNum) || stakeNum < 0) return validationErrorResponse('유효하지 않은 스테이킹 금액입니다.');

    // 슬롯 보너스 적용
    let slotBonusPercent = 0;
    try {
      const { getTotalSlotHashrate } = await import('@/services/referralSlotService');
      slotBonusPercent = await getTotalSlotHashrate(user.id);
    } catch { /* slots not initialized yet */ }

    const totalHashrate = new Decimal(hashrateNum * (1 + slotBonusPercent / 100));
    const stakeAmount = new Decimal(stakeNum);

    const result = await miningService.calculateMiningReward(user.id, totalHashrate, stakeAmount, 3600);

    if (!result.success) {
      return errorResponse(result.error || '수익 계산 실패', ErrorCode.SERVER_ERROR);
    }

    const hourly = result.rewardAmount;
    const daily = hourly.mul(24);
    const weekly = hourly.mul(168);

    return successResponse({
      estimatedHourly: hourly.toString(),
      estimatedDaily: daily.toString(),
      estimatedWeekly: weekly.toString(),
      epoch: result.epoch,
      halvingMultiplier: result.halvingMultiplier.toString(),
      bonusMultiplier: result.bonusMultiplier.toString(),
      difficulty: result.difficulty.toString(),
      slotBonusPercent,
    });
  } catch (error: unknown) {
    console.error('[Mining Estimate] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    const msg = error instanceof Error ? error.message : '수익 예측 중 오류가 발생했습니다.';
    return errorResponse(msg, ErrorCode.SERVER_ERROR);
  }
}
