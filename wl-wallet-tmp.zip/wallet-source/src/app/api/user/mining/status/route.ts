import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as miningService from '@/services/miningService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const config = await miningService.getMiningSettings();

    const activeSession = await prisma.mining_sessions.findFirst({
      where: { userId: user.id, status: 'ACTIVE' },
      orderBy: { startTime: 'desc' },
    });

    if (!activeSession) {
      return successResponse({ activeSession: null, totalMined: '0', miningCap: config.totalSupplyCap.toString() });
    }

    const metadata = activeSession.metadata as Record<string, unknown> || {};
    const rawHashrate = (metadata.rawHashrate as number) ?? Number(activeSession.hashrate || 0);

    const totalMinedAgg = await prisma.mining_claims.aggregate({
      where: { userId: user.id, status: 'COMPLETED' },
      _sum: { claimAmount: true },
    });

    return successResponse({
      activeSession: {
        id: activeSession.id,
        sessionId: activeSession.sessionId,
        hashrate: rawHashrate,
        startTime: activeSession.startTime,
        difficulty: Number(activeSession.difficulty),
        hardwareName: metadata.hardwareName as string ?? null,
      },
      totalMined: totalMinedAgg._sum.claimAmount?.toString() || '0',
      miningCap: config.totalSupplyCap.toString(),
    });
  } catch (error: unknown) {
    console.error('[Mining Status] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('채굴 상태 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
