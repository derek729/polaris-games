import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as miningService from '@/services/miningService';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const body = await request.json();
    const { sessionId } = body;

    if (!sessionId) return validationErrorResponse('sessionId가 필요합니다.');

    const session = await miningService.stopMiningSession(sessionId, user.id);

    return successResponse({
      sessionId: session?.sessionId,
      status: session?.status,
      endTime: session?.endTime,
      message: '채굴이 중지되었습니다.',
    });
  } catch (error: unknown) {
    console.error('[Stop Mining] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    const msg = error instanceof Error ? error.message : '채굴 중지 중 오류가 발생했습니다.';
    return errorResponse(msg, ErrorCode.SERVER_ERROR);
  }
}
