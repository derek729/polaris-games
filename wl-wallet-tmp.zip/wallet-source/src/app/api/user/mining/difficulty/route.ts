import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as miningService from '@/services/miningService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const config = await miningService.getMiningSettings();
    const stats = await prisma.mining_stats.findFirst();

    return successResponse({
      difficulty: config.difficulty.toString(),
      networkDifficulty: stats?.networkDifficulty?.toString() || '1',
      totalHashrate: stats?.totalHashrate?.toString() || '0',
    });
  } catch (error: unknown) {
    console.error('[Difficulty GET] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('난이도 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');
    if (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN') {
      return errorResponse('관리자만 난이도를 변경할 수 있습니다.', 403, 'FORBIDDEN');
    }

    const body = await request.json();
    const { difficulty } = body;
    if (!difficulty || isNaN(Number(difficulty)) || Number(difficulty) <= 0) {
      return validationErrorResponse('유효한 난이도 값을 입력해주세요.');
    }

    await prisma.mining_settings.upsert({
      where: { key: 'difficulty' },
      update: { value: JSON.stringify(difficulty.toString()) },
      create: { key: 'difficulty', value: JSON.stringify(difficulty.toString()), description: 'Current mining difficulty', category: 'difficulty' },
    });

    await prisma.mining_stats.upsert({
      where: { id: 'default' },
      update: { networkDifficulty: difficulty },
      create: { id: 'default', networkDifficulty: difficulty, lastHalvingDate: new Date() },
    });

    return successResponse({ difficulty: difficulty.toString(), message: '난이도가 업데이트되었습니다.' });
  } catch (error: unknown) {
    console.error('[Difficulty POST] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('난이도 변경 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
