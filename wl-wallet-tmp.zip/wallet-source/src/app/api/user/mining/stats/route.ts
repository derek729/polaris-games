import { successResponse, errorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as miningService from '@/services/miningService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const stats = await miningService.getNetworkStats();
    return successResponse(stats);
  } catch (error: unknown) {
    console.error('[Mining Stats] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('네트워크 통계 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
