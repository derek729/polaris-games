import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as miningService from '@/services/miningService';
import { Decimal } from '@prisma/client/runtime/library';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const body = await request.json();
    const { sessionId, stakeAmount } = body;
    if (!sessionId) return validationErrorResponse('sessionId가 필요합니다.');

    const sa = new Decimal(stakeAmount || '0');

    const result = await miningService.claimPartialReward(sessionId, user.id, sa);

    return successResponse({
      minerReward: result.minerReward.toString(),
      referrerReward: result.referrerReward?.toString() || '0',
      foundationReward: result.foundationReward?.toString() || '0',
      totalReward: result.poolReward.add(result.minerReward).toString(),
      miningDuration: result.miningDuration,
      serverHashrate: result.serverHashrate.toString(),
      slotBonusPercent: result.slotBonusPercent,
      message: `부분 청구 완료. ${result.minerReward.toFixed(8)} MSUO 지급. 세션 계속 진행 중.`,
    });
  } catch (error: unknown) {
    console.error('[Claim Partial] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    const msg = error instanceof Error ? error.message : '부분 청구 중 오류가 발생했습니다.';
    return errorResponse(msg, ErrorCode.SERVER_ERROR);
  }
}
