import { getCurrentUser } from '@/lib/auth';
import { successResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import * as referralSlotService from '@/services/referralSlotService';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const { slotId, referralCode } = await request.json();
    if (!slotId || !referralCode) return validationErrorResponse('slotId와 referralCode가 필요합니다.');

    const result = await referralSlotService.addReferral(user.id, Number(slotId), referralCode);
    return successResponse(result);
  } catch (error: unknown) {
    console.error('[Add Referral] Error:', error);
    const msg = error instanceof Error ? error.message : '추천인 추가 중 오류가 발생했습니다.';
    return Response.json({ ok: false, error: msg }, { status: 400 });
  }
}
