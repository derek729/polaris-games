import { getCurrentUser } from '@/lib/auth';
import { successResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import * as referralSlotService from '@/services/referralSlotService';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const body = await request.json();
    const slotId = Number(body.slotId);

    if (!slotId || isNaN(slotId)) return validationErrorResponse('유효하지 않은 slotId입니다.');

    const result = await referralSlotService.registerAvatar(user.id, slotId);
    return successResponse(result);
  } catch (error: unknown) {
    console.error('[Register Avatar] Error:', error);
    const msg = error instanceof Error ? error.message : '아바타 등록 중 오류가 발생했습니다.';
    return Response.json({ ok: false, error: msg }, { status: 400 });
  }
}
