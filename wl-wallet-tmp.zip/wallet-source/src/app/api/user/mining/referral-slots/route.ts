import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as referralSlotService from '@/services/referralSlotService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const slots = await referralSlotService.getSlotsWithMeta(user.id);
    return successResponse(slots);
  } catch (error: unknown) {
    console.error('[Referral Slots] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('슬롯 조회 중 오류가 발생했습니다.', 500);
  }
}
