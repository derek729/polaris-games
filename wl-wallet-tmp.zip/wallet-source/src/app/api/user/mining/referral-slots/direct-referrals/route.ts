import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const directReferrals = await prisma.users.findMany({
      where: { referrerId: user.id },
      select: { id: true, username: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    });

    return successResponse({ referrals: directReferrals, count: directReferrals.length });
  } catch (error: unknown) {
    console.error('[Direct Referrals] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('직접 추천인 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
