import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as referralSlotService from '@/services/referralSlotService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const totalHashrate = await referralSlotService.getTotalSlotHashrate(user.id);
    return successResponse({ totalSlotHashrate: totalHashrate });
  } catch (error: unknown) {
    console.error('[Hashrate Bonus] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('해시레이트 보너스 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
