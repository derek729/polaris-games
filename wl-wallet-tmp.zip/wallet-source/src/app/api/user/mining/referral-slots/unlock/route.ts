import { getCurrentUser } from '@/lib/auth';
import { successResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import * as referralSlotService from '@/services/referralSlotService';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const { slotId } = await request.json();
    if (!slotId) return validationErrorResponse('slotId가 필요합니다.');

    const result = await referralSlotService.unlockSlot(user.id, Number(slotId));
    return successResponse(result);
  } catch (error: unknown) {
    console.error('[Unlock Slot] Error:', error);
    const msg = error instanceof Error ? error.message : '슬롯 잠금해제 중 오류가 발생했습니다.';
    return Response.json({ ok: false, error: msg }, { status: 400 });
  }
}
