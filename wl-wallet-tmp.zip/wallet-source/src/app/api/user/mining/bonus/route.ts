import { getCurrentUser } from '@/lib/auth';
import { successResponse, unauthorizedResponse, errorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as miningService from '@/services/miningService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const [halving, config] = await Promise.all([
      miningService.calculateHalvingMultiplier(),
      miningService.getMiningSettings(),
    ]);

    let slotBonus = 0;
    try {
      const { getTotalSlotHashrate } = await import('@/services/referralSlotService');
      slotBonus = await getTotalSlotHashrate(user.id);
    } catch { /* slots not initialized yet */ }

    return successResponse({
      halvingMultiplier: halving.multiplier.toString(),
      epoch: halving.epoch,
      nextHalvingDate: halving.nextHalvingDate,
      difficultyBonus: config.difficulty.gt(1) ? config.difficulty.sub(1).mul(0.1).toString() : '0',
      powWeight: config.powWeight,
      posWeight: config.posWeight,
      slotHashrateBonus: slotBonus,
      minerRewardRatio: 0.4,
      poolRewardRatio: 0.6,
    });
  } catch (error: unknown) {
    console.error('[Mining Bonus] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('보너스 정보 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
