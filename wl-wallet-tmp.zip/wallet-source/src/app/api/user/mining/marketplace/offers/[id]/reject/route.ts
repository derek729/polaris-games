import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as marketplaceService from '@/services/slotMarketplaceService';

export const dynamic = 'force-dynamic';

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const { id } = await params;
    const result = await marketplaceService.rejectOffer(id, user.id);
    if (!result.ok) return errorResponse(result.error || '거절 실패', 400, ErrorCode.VALIDATION_ERROR);

    return successResponse({ message: '오퍼가 거절되었습니다.' });
  } catch (error: unknown) {
    console.error('[Reject Offer] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('오퍼 거절 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
