import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as marketplaceService from '@/services/slotMarketplaceService';

export const dynamic = 'force-dynamic';

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const { id } = await params;
    const result = await marketplaceService.acceptOffer(id, user.id);
    if (!result.ok) return errorResponse(result.error || '수락 실패', 400, ErrorCode.VALIDATION_ERROR);

    return successResponse(result.data);
  } catch (error: unknown) {
    console.error('[Accept Offer] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('오퍼 수락 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
