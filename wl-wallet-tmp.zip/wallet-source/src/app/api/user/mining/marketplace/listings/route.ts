import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as marketplaceService from '@/services/slotMarketplaceService';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const filter = {
      minLevel: searchParams.get('minLevel') ? Number(searchParams.get('minLevel')) : undefined,
      maxLevel: searchParams.get('maxLevel') ? Number(searchParams.get('maxLevel')) : undefined,
      minPrice: searchParams.get('minPrice') ? Number(searchParams.get('minPrice')) : undefined,
      maxPrice: searchParams.get('maxPrice') ? Number(searchParams.get('maxPrice')) : undefined,
    };

    const listings = await marketplaceService.getListings(filter);
    return successResponse(listings);
  } catch (error: unknown) {
    console.error('[Marketplace Listings GET] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('마켓플레이스 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const { slotId, price } = await request.json();
    if (!slotId || !price) return validationErrorResponse('slotId와 price가 필요합니다.');

    const result = await marketplaceService.createListing(user.id, Number(slotId), Number(price));
    if (!result.ok) return errorResponse(result.error || '리스트 등록 실패', 400, ErrorCode.VALIDATION_ERROR);

    return successResponse(result.data);
  } catch (error: unknown) {
    console.error('[Marketplace Listings POST] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('리스트 등록 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
