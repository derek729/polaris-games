import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import * as marketplaceService from '@/services/slotMarketplaceService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const offers = await marketplaceService.getMyOffers(user.id);
    return successResponse(offers);
  } catch (error: unknown) {
    console.error('[My Offers GET] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('내 오퍼 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return unauthorizedResponse('로그인이 필요합니다.');

    const { listingId, offerPrice } = await request.json();
    if (!listingId || !offerPrice) return validationErrorResponse('listingId와 offerPrice가 필요합니다.');

    const result = await marketplaceService.createOffer(listingId, user.id, Number(offerPrice));
    if (!result.ok) return errorResponse(result.error || '오퍼 생성 실패', 400, ErrorCode.VALIDATION_ERROR);

    return successResponse(result.data);
  } catch (error: unknown) {
    console.error('[Create Offer] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('오퍼 생성 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
