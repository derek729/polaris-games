import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const topMiners = await prisma.$queryRaw<Array<{
      userId: string; username: string | null; totalHashrate: string; sessions: bigint;
    }>>`
      SELECT u.id as "userId", u.username, SUM(s.hashrate) as "totalHashrate", COUNT(s.id) as sessions
      FROM mining_sessions s
      JOIN users u ON s."user_id" = u.id
      WHERE s.status = 'ACTIVE'
      GROUP BY u.id, u.username
      ORDER BY SUM(s.hashrate) DESC
      LIMIT 20
    `;

    const leaderboard = topMiners.map((m, i) => ({
      rank: i + 1,
      userId: m.userId,
      username: m.username || 'Anonymous',
      hashrate: Number(m.totalHashrate),
      sessions: Number(m.sessions),
    }));

    let currentUserRank = null;
    const userRankResult = await prisma.$queryRaw<Array<{ rank: number; totalHashrate: string }>>`
      SELECT rank, "totalHashrate" FROM (
        SELECT u.id as "userId", SUM(s.hashrate) as "totalHashrate",
               RANK() OVER (ORDER BY SUM(s.hashrate) DESC) as rank
        FROM mining_sessions s
        JOIN users u ON s."user_id" = u.id
        WHERE s.status = 'ACTIVE'
        GROUP BY u.id
      ) ranked WHERE "userId" = ${user.id}
    `;
    if (userRankResult.length > 0) {
      currentUserRank = {
        rank: userRankResult[0].rank,
        hashrate: Number(userRankResult[0].totalHashrate),
      };
    }

    return successResponse({ leaderboard, currentUserRank });
  } catch (error: unknown) {
    console.error('[Hashrate Leaderboard] Error:', error);
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    return errorResponse('리더보드 조회 중 오류가 발생했습니다.', ErrorCode.SERVER_ERROR);
  }
}
