import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import bcrypt from 'bcryptjs';
import {
  successResponse,
  errorResponse,
  validationErrorResponse,
  unauthorizedResponse,
  notFoundResponse
} from '@/lib/api-response';
import { isValidAmount } from '@/lib/validation';
import { checkRateLimit, rateLimitConfigs } from '@/lib/rate-limit';
import { cache } from '@/lib/cache';

const TRANSFER_GAS_FEE = 0.01;
const MIN_TRANSFER_AMOUNT = 1;
const MAX_MEMO_LENGTH = 100;

const decimalToNumber = (value: Prisma.Decimal | number | null | undefined): number => {
  return Number(value?.toString() ?? 0);
};

export async function POST(request: NextRequest) {
  const appMode = (process.env.APP_MODE || 'foundation').toLowerCase();
  if (appMode !== 'foundation') {
    const rateLimitResult = await checkRateLimit(request, rateLimitConfigs.transfers);
    if (!rateLimitResult.success) {
      return rateLimitResult.response;
    }
  }

  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return validationErrorResponse('요청 형식이 올바르지 않습니다.');
    }

    const { receiverIdentifier, amount, memo, password } = body || {};

    if (!receiverIdentifier || receiverIdentifier === '') {
      return validationErrorResponse('받는 사람 이메일을 입력해주세요.');
    }
    if (!amount || amount === '') {
      return validationErrorResponse('이체 금액을 입력해주세요.');
    }
    if (!password) {
      return validationErrorResponse('비밀번호를 입력해주세요.');
    }

    // 비밀번호 검증
    const userWithPassword = await prisma.users.findUnique({
      where: { id: currentUser.id },
      select: { password: true },
    });
    if (!userWithPassword?.password) {
      return validationErrorResponse('비밀번호를 설정한 후 이체가 가능합니다.');
    }
    const passwordValid = await bcrypt.compare(password, userWithPassword.password);
    if (!passwordValid) {
      return errorResponse('비밀번호가 일치하지 않습니다.', 401, 'UNAUTHORIZED');
    }

    const amountCheck = isValidAmount(amount);
    if (!amountCheck.valid) {
      return validationErrorResponse(amountCheck.message || '이체 금액이 유효하지 않습니다.');
    }

    const transferAmount = new Prisma.Decimal(amount);
    const gasFeeOzCoin = TRANSFER_GAS_FEE;

    if (transferAmount.lt(MIN_TRANSFER_AMOUNT)) {
      return validationErrorResponse(`최소 이체 금액은 ${MIN_TRANSFER_AMOUNT} MSUO입니다.`);
    }

    if (memo && memo.length > MAX_MEMO_LENGTH) {
      return validationErrorResponse(`메모는 최대 ${MAX_MEMO_LENGTH}자까지 입력 가능합니다.`);
    }

    // 받는 사람 확인
    const receiver = await prisma.users.findFirst({
      where: {
        OR: [
          { email: receiverIdentifier.trim() },
          { username: receiverIdentifier.trim() },
          { walletAddress: receiverIdentifier.trim() }
        ]
      },
      select: {
        id: true,
        username: true,
        email: true,
        walletAddress: true,
        isActive: true,
        status: true,
      }
    });

    if (!receiver) {
      return notFoundResponse('받는 사람을 찾을 수 없습니다.');
    }
    if (receiver.id === currentUser.id) {
      return validationErrorResponse('본인에게는 이체할 수 없습니다.');
    }
    if (!receiver.isActive || receiver.status !== 'ACTIVE') {
      return errorResponse('받는 사람의 계정이 비활성화 상태입니다.', 403, 'FORBIDDEN');
    }

    // 트랜잭션 내에서 잔액 체크 + 이체 (더블스펜드 방지)
    const result = await prisma.$transaction(async (tx) => {
      // FOR UPDATE: 동시 전송 차단
      const sender = await tx.$queryRaw<Array<{
        id: string;
        personalCoin: string;
        ozCoin: string;
        isActive: boolean;
        status: string;
      }>>`
        SELECT id, "personalCoin", "ozCoin", "isActive", status FROM users WHERE id = ${currentUser.id} FOR UPDATE
      `;

      if (!sender.length) throw new Error('보내는 사람 정보를 찾을 수 없습니다.');
      const s = sender[0];
      if (!s.isActive || s.status !== 'ACTIVE') throw new Error('보내는 사람의 계정이 비활성화 상태입니다.');

      // 스테이킹 차감
      const stakingAgg = await tx.staking_records.aggregate({
        where: { userId: currentUser.id, status: 'ACTIVE' },
        _sum: { stakedAmount: true },
      });
      const stakedAmount = new Prisma.Decimal(stakingAgg._sum.stakedAmount?.toString() || '0');

      // Lockup 차감
      let lockupAmount = new Prisma.Decimal(0);
      try {
        const lockups = await tx.lockup_settings.findMany({
          where: { userId: currentUser.id, status: 'LOCKED' },
          select: { lockedAmount: true },
        });
        lockupAmount = lockups.reduce((sum, l) => sum.add(new Prisma.Decimal(l.lockedAmount?.toString() || '0')), new Prisma.Decimal(0));
      } catch { /* lockup table may not exist */ }

      const totalBalance = new Prisma.Decimal(s.personalCoin);
      const availableBalance = totalBalance.minus(stakedAmount).minus(lockupAmount);
      const ozBalance = new Prisma.Decimal(s.ozCoin);

      if (availableBalance.lt(transferAmount)) {
        throw new Error(
          `전송 가능한 MSUO 잔고가 부족합니다. (전체: ${totalBalance.toFixed(2)}, 스테이킹: ${stakedAmount.toFixed(2)}, 전송가능: ${availableBalance.toFixed(2)} MSUO)`
        );
      }
      if (ozBalance.lt(gasFeeOzCoin)) {
        throw new Error(`가스비(OZ Coin)가 부족합니다. (보유: ${ozBalance.toFixed(2)} OZ)`);
      }

      // 1. 보내는 사람 MSUO 차감
      await tx.users.update({
        where: { id: currentUser.id },
        data: { personalCoin: { decrement: transferAmount } },
      });

      // 2. 보내는 사람 OZ 가스비 차감
      await tx.users.update({
        where: { id: currentUser.id },
        data: { ozCoin: { decrement: gasFeeOzCoin } },
      });

      // 3. 받는 사람 잔액 증가
      await tx.users.update({
        where: { id: receiver.id },
        data: { personalCoin: { increment: transferAmount } },
      });

      // 4. 이체 기록 생성
      const transfer = await tx.transfers.create({
        data: {
          senderId: currentUser.id,
          receiverId: receiver.id,
          amount: transferAmount,
          fee: new Prisma.Decimal(gasFeeOzCoin),
          status: 'COMPLETED',
          networkType: 'OFF_CHAIN',
          description: memo || 'personalCoin',
          receiveAmount: transferAmount,
          receiveCurrency: 'MSUO',
          direction: 'OUT',
        }
      });

      return transfer;
    }, {
      maxWait: 30000,
      timeout: 30000,
    });

    // 캐시 삭제
    try {
      cache.del(cache.userKey(currentUser.id, 'balance'), 'user');
      cache.del(cache.userKey(receiver.id, 'balance'), 'user');
      cache.del(cache.userKey(currentUser.id), 'user');
      cache.del(cache.userKey(receiver.id), 'user');
    } catch { /* non-critical */ }

    return successResponse(
      {
        id: result.id,
        receiver: {
          username: receiver.username,
          email: receiver.email,
        },
        amount: decimalToNumber(transferAmount),
        fee: gasFeeOzCoin,
        transferredAt: result.transferredAt,
      },
      '이체가 완료되었습니다.'
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : '이체 중 오류가 발생했습니다.';
    const isClientError = errorMessage.includes('부족') || errorMessage.includes('없습니다') || errorMessage.includes('비활성화');
    return errorResponse(errorMessage, isClientError ? 400 : 500, isClientError ? 'BAD_REQUEST' : 'SERVER_ERROR');
  }
}

export async function GET(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');

    let whereClause: Record<string, unknown> = {};
    if (type === 'sent') {
      whereClause = { senderId: currentUser.id };
    } else if (type === 'received') {
      whereClause = { receiverId: currentUser.id };
    } else {
      whereClause = {
        OR: [
          { senderId: currentUser.id },
          { receiverId: currentUser.id }
        ]
      };
    }

    const transfers = await prisma.transfers.findMany({
      where: whereClause,
      select: {
        id: true,
        senderId: true,
        receiverId: true,
        amount: true,
        fee: true,
        description: true,
        networkType: true,
        txHash: true,
        blockNumber: true,
        confirmations: true,
        transferredAt: true,
        users_transfers_senderIdTousers: {
          select: { id: true, username: true, email: true, walletAddress: true },
        },
        users_transfers_receiverIdTousers: {
          select: { id: true, username: true, email: true, walletAddress: true },
        }
      },
      orderBy: { transferredAt: 'desc' },
      take: 50,
    });

    return successResponse(
      transfers.map((t) => ({
        id: t.id,
        type: t.senderId === currentUser.id ? 'sent' : 'received',
        sender: {
          id: t.users_transfers_senderIdTousers.id,
          username: t.users_transfers_senderIdTousers.username,
          email: t.users_transfers_senderIdTousers.email,
          walletAddress: t.users_transfers_senderIdTousers.walletAddress,
        },
        receiver: {
          id: t.users_transfers_receiverIdTousers.id,
          username: t.users_transfers_receiverIdTousers.username,
          email: t.users_transfers_receiverIdTousers.email,
          walletAddress: t.users_transfers_receiverIdTousers.walletAddress,
        },
        amount: decimalToNumber(t.amount),
        fee: decimalToNumber(t.fee),
        memo: t.description || '',
        status: 'completed',
        networkType: t.networkType || 'OFF_CHAIN',
        txHash: t.txHash,
        blockNumber: t.blockNumber,
        confirmations: t.confirmations,
        transferredAt: t.transferredAt,
      }))
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : '이체 내역 조회 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, 500, 'SERVER_ERROR');
  }
}
