import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';

export async function GET(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const query = searchParams.get('query');

    if (!query || query.trim().length < 1) {
      return successResponse([]);
    }

    const users = await prisma.users.findMany({
      where: {
        AND: [
          { isActive: true },
          { status: 'ACTIVE' },
          {
            OR: [
              {
                email: {
                  contains: query.trim(),
                  mode: 'insensitive'
                }
              },
              {
                username: {
                  contains: query.trim(),
                  mode: 'insensitive'
                }
              },
              {
                walletAddress: {
                  contains: query.trim(),
                  mode: 'insensitive'
                }
              }
            ]
          }
        ]
      },
      select: {
        id: true,
        username: true,
        email: true,
        walletAddress: true,
        personalCoin: true,
      },
      orderBy: [
        { username: 'asc' },
        { email: 'asc' }
      ],
      take: 10
    });

    const filteredUsers = users.filter(user => user.id !== currentUser.id);
    
    return successResponse(filteredUsers);

  } catch (error: unknown) {
    console.error('[User Search API] Error:', error);
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '사용자 검색 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
