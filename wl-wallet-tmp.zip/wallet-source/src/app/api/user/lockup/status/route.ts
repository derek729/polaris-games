import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { withErrorHandler, unauthorizedResponse, successResponse } from '@/lib/api-response';
import { LockupService } from '@/services/lockup/LockupService';

export async function GET(request: NextRequest) {
  return withErrorHandler(async () => {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }
    const status = await LockupService.getUserStatus(user.id);
    return successResponse({
      message: '락업 상태 조회',
      data: status,
    });
  });
}

