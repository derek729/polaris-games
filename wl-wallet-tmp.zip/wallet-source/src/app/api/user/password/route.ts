import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { isValidPassword } from '@/lib/validation';
import bcrypt from 'bcryptjs';
import { successResponse, errorResponse, validationErrorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';

/**
 * 사용자 본인 비밀번호 변경 API
 * POST /api/user/password
 */
export async function POST(request: NextRequest) {
  try {
    // 현재 로그인한 사용자 확인
    const currentUser = await getCurrentUser();
    
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { currentPassword, newPassword } = body;

    // 필수 필드 검증
    if (!currentPassword || typeof currentPassword !== 'string') {
      return validationErrorResponse('현재 비밀번호를 입력해주세요.');
    }

    if (!newPassword || typeof newPassword !== 'string') {
      return validationErrorResponse('새 비밀번호를 입력해주세요.');
    }

    // 새 비밀번호 유효성 검사
    const passwordCheck = isValidPassword(newPassword);
    if (!passwordCheck.valid) {
      return validationErrorResponse(passwordCheck.message ?? '비밀번호가 유효하지 않습니다.');
    }

    // 현재 비밀번호와 새 비밀번호가 동일한지 확인
    if (currentPassword === newPassword) {
      return validationErrorResponse('현재 비밀번호와 새 비밀번호가 동일합니다.');
    }

    // 사용자 정보 조회 (비밀번호 포함)
    const user = await prisma.users.findUnique({
      where: { id: currentUser.id },
      select: {
        id: true,
        username: true,
        email: true,
        password: true,
      },
    });

    if (!user) {
      return errorResponse('사용자를 찾을 수 없습니다.', ErrorCode.USER_NOT_FOUND);
    }

    // 비밀번호가 설정되어 있는지 확인
    if (!user.password) {
      return validationErrorResponse('비밀번호가 설정되지 않은 계정입니다. 비밀번호 찾기 기능을 이용해주세요.');
    }

    // 현재 비밀번호 확인
    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isCurrentPasswordValid) {
      return unauthorizedResponse('현재 비밀번호가 일치하지 않습니다.');
    }

    // 새 비밀번호 해싱
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // 비밀번호 업데이트
    await prisma.users.update({
      where: { id: currentUser.id },
      data: { password: hashedPassword },
    });

    if (process.env.NODE_ENV === 'development') {
      console.log(`[User] 비밀번호 변경 완료: ${user.username} (userId: ${currentUser.id})`);
    }

    return successResponse(null, '비밀번호가 성공적으로 변경되었습니다.');
  } catch (error: unknown) {
    if (process.env.NODE_ENV === 'development') {
      console.error('[User] 비밀번호 변경 실패:', error);
    }
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '비밀번호 변경 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
