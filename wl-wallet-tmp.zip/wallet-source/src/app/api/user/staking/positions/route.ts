import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import { STAKING_POOLS } from '@/lib/staking-physics';

export async function GET(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 활성 상태인 스테이킹 포지션 조회
    const records = await prisma.staking_records.findMany({
      where: {
        userId: user.id,
        status: 'ACTIVE',
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    const positions = records.map((record) => {
      const metadata = record.metadata as Record<string, unknown> || {};
      const poolId = (metadata.poolId as string) || 'stable-upc'; // 기본값
      const pool = STAKING_POOLS.find((p) => p.id === poolId) ?? STAKING_POOLS[0];
      
      const stakedAmount = Number(record.stakedAmount);
      const apy = Number(record.apy ?? pool.baseApy);
      
      // 현재 가치 계산 (단순 경과 시간 비례 이자 계산)
      const now = new Date();
      const start = new Date(record.startDate);
      const elapsedDays = (now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24);
      
      // 일일 이자율
      const dailyRate = (apy / 100) / 365;
      const totalEarned = stakedAmount * dailyRate * elapsedDays;
      
      return {
        id: record.id,
        userId: record.userId,
        poolId: poolId,
        pool: pool,
        amount: stakedAmount,
        currentAmount: stakedAmount + totalEarned,
        startTime: record.startDate,
        endTime: record.endDate ?? new Date(),
        lockPeriod: record.lockPeriod ?? 0,
        compoundFrequency: (metadata.compoundFrequency as string) ?? 'daily',
        autoCompound: (metadata.autoCompound as boolean) ?? false,
        currentApy: apy,
        totalEarned: totalEarned,
        status: record.status,
        createdAt: record.createdAt,
        updatedAt: record.updatedAt,
      };
    });

    return successResponse({
      positions,
    });

  } catch (error: unknown) {
    console.error('[Staking Positions] Error:', error);
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '스테이킹 정보를 불러오는 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
