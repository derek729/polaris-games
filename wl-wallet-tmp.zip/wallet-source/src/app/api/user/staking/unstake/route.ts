import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import { STAKING_POOLS } from '@/lib/staking-physics';
import { Prisma } from '@prisma/client';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { positionId } = body;

    if (!positionId) {
      return validationErrorResponse('포지션 ID가 필요합니다.');
    }

    // 포지션 조회
    const record = await prisma.staking_records.findUnique({
      where: { id: positionId },
    });

    if (!record || record.userId !== user.id) {
      return validationErrorResponse('유효하지 않은 스테이킹 포지션입니다.');
    }

    if (record.status !== 'ACTIVE') {
      return validationErrorResponse('이미 종료된 스테이킹입니다.');
    }

    // 메타데이터에서 풀 정보 확인
    const metadata = record.metadata as Record<string, unknown> || {};
    const poolId = metadata.poolId as string | undefined;
    const pool = STAKING_POOLS.find((p) => p.id === poolId);

    // 조기 해지 가능 여부 확인
    const now = new Date();
    const endDate = record.endDate ? new Date(record.endDate) : new Date();
    const isEarly = now < endDate;

    if (isEarly && pool && !pool.earlyUnstake) {
      return errorResponse('이 상품은 조기 해지가 불가능합니다.', 400, 'EARLY_UNSTAKE_NOT_ALLOWED');
    }

    // 수익 계산
    const stakedAmount = Number(record.stakedAmount);
    const apy = Number(record.apy ?? 0);
    const start = new Date(record.startDate);
    const elapsedDays = (now.getTime() - start.getTime()) / (1000 * 60 * 60 * 24);
    
    // 일일 이자율
    const dailyRate = (apy / 100) / 365;
    let interest = stakedAmount * dailyRate * elapsedDays;

    // 조기 해지 페널티 (예: 이자 전액 몰수 또는 원금 일부 손실)
    // 여기서는 간단하게 이자 50% 차감으로 구현
    if (isEarly) {
      interest = interest * 0.5;
    }

    const totalReturn = new Prisma.Decimal(stakedAmount + interest);
    const interestDecimal = new Prisma.Decimal(interest);

    // 트랜잭션 처리
    await prisma.$transaction(async (tx) => {
      // 사용자 잔액 증가 (원금 + 이자)
      await tx.users.update({
        where: { id: user.id },
        data: {
          personalCoin: { increment: totalReturn },
        },
      });

      // 스테이킹 레코드 업데이트
      await tx.staking_records.update({
        where: { id: positionId },
        data: {
          status: isEarly ? 'WITHDRAWN' : 'COMPLETED',
          unstakedAt: now,
          rewardAmount: interestDecimal,
        },
      });
    });

    return successResponse({
      returnAmount: Number(totalReturn),
      interest: Number(interest),
      isEarly,
      message: isEarly
        ? '조기 해지가 완료되었습니다. (페널티 적용)'
        : '스테이킹 해지가 완료되었습니다.',
    });

  } catch (error: unknown) {
    console.error('[Unstake] Error:', error);
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '스테이킹 해지 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
