import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import { STAKING_POOLS } from '@/lib/staking-physics';
import { Prisma } from '@prisma/client';

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { poolId, amount, lockPeriod, compoundFrequency, autoCompound } = body;

    // 1. 기본 검증
    if (!poolId || !amount || !lockPeriod) {
      return validationErrorResponse('필수 정보가 누락되었습니다.');
    }

    // 2. 풀 정보 확인
    const pool = STAKING_POOLS.find((p) => p.id === poolId);
    if (!pool) {
      return validationErrorResponse('유효하지 않은 스테이킹 풀입니다.');
    }

    // 3. 금액 검증
    if (amount < pool.minAmount || amount > pool.maxAmount) {
      return validationErrorResponse(
        `스테이킹 금액은 ${pool.minAmount.toLocaleString()} ~ ${pool.maxAmount.toLocaleString()} MSUO 사이여야 합니다.`
      );
    }

    // 4. 락업 기간 검증
    if (!pool.lockPeriods.includes(lockPeriod)) {
      return validationErrorResponse('유효하지 않은 락업 기간입니다.');
    }

    // 5. 복리 옵션 검증
    if (!pool.compoundOptions.includes(compoundFrequency)) {
      return validationErrorResponse('유효하지 않은 복리 옵션입니다.');
    }

    // 6. 사용자 잔액 확인
    const dbUser = await prisma.users.findUnique({
      where: { id: user.id },
      select: { personalCoin: true },
    });

    if (!dbUser || new Prisma.Decimal(dbUser.personalCoin).lessThan(amount)) {
      return errorResponse('잔액이 부족합니다.', 400, 'INSUFFICIENT_BALANCE');
    }

    // 7. 트랜잭션 처리
    const stakeAmount = new Prisma.Decimal(amount);
    
    // 종료일 계산
    const startDate = new Date();
    const endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + lockPeriod);

    // APY 계산 (기본 APY + 보너스 로직은 여기서는 단순화하여 풀의 baseApy 저장, 실제로는 동적 계산 필요할 수 있음)
    // 클라이언트와 동일한 로직을 적용하거나, 클라이언트가 보낸 값을 검증해야 함.
    // 여기서는 안전하게 pool.baseApy를 기본으로 하고, 락업 기간에 따른 보너스만 간단히 추가
    let finalApy = pool.baseApy;
    if (lockPeriod >= 365) finalApy += 2.0;
    else if (lockPeriod >= 180) finalApy += 1.0;
    
    // 최대 APY 제한
    finalApy = Math.min(finalApy, pool.maxApy);

    const result = await prisma.$transaction(async (tx) => {
      // 잔액 차감
      await tx.users.update({
        where: { id: user.id },
        data: {
          personalCoin: { decrement: stakeAmount },
        },
      });

      // 스테이킹 기록 생성
      const stakingRecord = await tx.staking_records.create({
        data: {
          userId: user.id,
          stakedAmount: stakeAmount,
          apy: new Prisma.Decimal(finalApy),
          startDate: startDate,
          endDate: endDate,
          lockPeriod: lockPeriod,
          status: 'ACTIVE',
          metadata: {
            poolId,
            poolName: pool.name,
            compoundFrequency,
            autoCompound,
            riskLevel: pool.riskLevel
          },
        },
      });

      return stakingRecord;
    });

    return successResponse({
      id: result.id,
      amount: Number(result.stakedAmount),
      startDate: result.startDate,
      endDate: result.endDate,
      message: '스테이킹이 성공적으로 시작되었습니다.',
    });

  } catch (error: unknown) {
    console.error('[Staking] Error:', error);
    const errorMessage = error instanceof Error ? error.message : '스테이킹 처리 중 오류가 발생했습니다.';
    return errorResponse(
      errorMessage,
      500,
      'SERVER_ERROR'
    );
  }
}

