import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { generateWalletAddress } from '@/lib/wallet-utils';
import { generateRecoveryPhrase } from '@/lib/recovery-phrase';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';

/**
 * 지갑 생성 (로컬 지갑 주소 생성 + 복구 구문 생성)
 * 메인넷 연동 없이 로컬에서 지갑 주소와 복구 구문을 생성합니다.
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 이미 지갑이 있는지 확인
    if (user.walletAddress) {
      return validationErrorResponse('이미 지갑이 생성되어 있습니다.');
    }

    // 복구 구문 생성 (20개 단어)
    const recoveryPhrase = generateRecoveryPhrase();
    const recoveryPhraseString = recoveryPhrase.join(' ');

    // 복구 구문으로 지갑 주소 생성
    const address = generateWalletAddress();

    // 사용자 데이터베이스에 지갑 주소 저장
    await prisma.users.update({
      where: { id: user.id },
      data: { 
        walletAddress: address,
      },
    });

    console.log(`✅ [Create Wallet] ${user.username}: ${address}`);
    console.log(`   Recovery Phrase: ${recoveryPhraseString.substring(0, 20)}...`);

    return successResponse({
      address,
      recoveryPhrase: recoveryPhraseString,
      message: '지갑이 성공적으로 생성되었습니다. 복구 구문을 반드시 안전하게 보관하세요.',
    });
  } catch (error: unknown) {
    console.error('[Create Wallet] Error:', error);
    const errorMessage = error instanceof Error ? error.message : '지갑 생성 중 오류가 발생했습니다.';
    return errorResponse(
      errorMessage,
      500,
      'SERVER_ERROR'
    );
  }
}


