import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';
import { Prisma } from '@prisma/client';

/**
 * 게임에서 재화 획득 (증가)
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { gameId, amount, currencyType } = body; // currencyType: 'MSUP' (게임 포인트)

    const requiredCheck = validateRequired(body, ['gameId', 'amount', 'currencyType']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message ?? '필수 필드가 누락되었습니다.');
    }

    // MSUP → MSUO 변환 (1:10 비율)
    // 게임에서 100 MSUP 획득 시, 실제 코인은 10 MSUO 지급
    const amountMsuo = new Prisma.Decimal(Math.floor(amount / 10));
    if (amountMsuo.lessThanOrEqualTo(0)) {
      return validationErrorResponse('획득할 금액은 0보다 커야 합니다.');
    }

    console.log(`[Add Balance] ${amount} MSUP → ${amountMsuo} MSUO 지급`);

    // 잔액 증가
    const updatedUser = await prisma.users.update({
      where: { id: user.id },
      data: {
        personalCoin: { increment: amountMsuo },
      },
      select: {
        personalCoin: true,
      },
    });

    // 응답은 MSUP 단위로 반환 (게임 호환성)
    const newBalanceMsup = Number(updatedUser.personalCoin) * 10;

    return successResponse({
      newBalance: newBalanceMsup,
      message: '재화가 추가되었습니다.',
    });
  } catch (error: unknown) {
    console.error('[Add Game Balance] Error:', error);
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '재화 추가 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
