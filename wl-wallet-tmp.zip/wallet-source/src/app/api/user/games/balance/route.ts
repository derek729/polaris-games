import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';

const decimalToNumber = (value: unknown): number => {
  if (value === null || value === undefined) return 0;
  return Number(value.toString());
};

/**
 * 게임에서 사용할 사용자 잔액 조회
 */
export async function GET(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 최신 사용자 정보 조회
    const currentUser = await prisma.users.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        personalCoin: true,
      },
    });

    if (!currentUser) {
      return errorResponse('사용자를 찾을 수 없습니다.', ErrorCode.USER_NOT_FOUND);
    }

    const personalCoin = decimalToNumber(currentUser.personalCoin);
    const msupBalance = personalCoin * 10; // 1 MSUO = 10 MSUP

    return successResponse({
      upccoin: personalCoin,
      msupBalance: msupBalance, // MSUP 포인트 (게임용, 1:10 비율)
      aocoin: personalCoin, // 하위 호환성
      coin: personalCoin, // 오셀로/마작용 코인 (현재는 personalCoin과 동일)
    });
  } catch (error: unknown) {
    console.error('[Get Game Balance] Error:', error);
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '잔액 조회 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
