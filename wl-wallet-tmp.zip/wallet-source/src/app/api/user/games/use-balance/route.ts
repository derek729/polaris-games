import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';
import { Prisma } from '@prisma/client';

/**
 * 게임에서 재화 사용 (차감)
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { gameId, amount, currencyType } = body; // currencyType: 'MSUP' (게임 포인트)

    const requiredCheck = validateRequired(body, ['gameId', 'amount', 'currencyType']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message ?? '필수 필드가 누락되었습니다.');
    }

    // MSUP → MSUO 변환 (1:10 비율)
    // 게임에서 100 MSUP 베팅 시, 실제 코인은 10 MSUO 차감
    const amountMsuo = new Prisma.Decimal(Math.ceil(amount / 10));
    if (amountMsuo.lessThanOrEqualTo(0)) {
      return validationErrorResponse('사용할 금액은 0보다 커야 합니다.');
    }

    console.log(`[Use Balance] ${amount} MSUP → ${amountMsuo} MSUO 차감`);

    // 현재 사용자 잔액 확인
    const currentUser = await prisma.users.findUnique({
      where: { id: user.id },
      select: { personalCoin: true },
    });

    if (!currentUser) {
      return errorResponse('사용자를 찾을 수 없습니다.', ErrorCode.USER_NOT_FOUND);
    }

    const currentBalance = new Prisma.Decimal(currentUser.personalCoin ?? 0);
    if (currentBalance.lessThan(amountMsuo)) {
      return errorResponse('잔액이 부족합니다.', ErrorCode.INSUFFICIENT_BALANCE);
    }

    // 잔액 차감
    const updatedUser = await prisma.users.update({
      where: { id: user.id },
      data: {
        personalCoin: { decrement: amountMsuo },
      },
      select: {
        personalCoin: true,
      },
    });

    // 응답은 MSUP 단위로 반환 (게임 호환성)
    const newBalanceMsup = Number(updatedUser.personalCoin) * 10;

    return successResponse({
      newBalance: newBalanceMsup,
      message: '재화가 차감되었습니다.',
    });
  } catch (error: unknown) {
    console.error('[Use Game Balance] Error:', error);
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '재화 사용 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
