import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse, handlePrismaError, ErrorCode } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { generateTransactionHash } from '@/services/mainnet-api';
import { OrderMatchingEngine } from '@/services/exchange/OrderMatchingEngine';
import { OrderService } from '@/services/exchange/OrderService';
import { OrderType, OrderPriceType } from '@/services/exchange/OrderService';

const decimalToNumber = (value: unknown): number => {
  if (value === null || value === undefined) return 0;
  return Number(value.toString());
};

/**
 * 매수/매도 주문 생성
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { type, price, amount, orderType } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['type', 'amount']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message ?? '필수 필드가 누락되었습니다.');
    }

    // 주문 타입 검증
    if (type !== 'BUY' && type !== 'SELL') {
      return validationErrorResponse('주문 타입은 BUY 또는 SELL이어야 합니다.');
    }

    // 주문 유형 검증
    if (orderType && orderType !== 'LIMIT' && orderType !== 'MARKET') {
      return validationErrorResponse('주문 유형은 LIMIT 또는 MARKET이어야 합니다.');
    }

    // 수량 검증
    const orderAmount = parseFloat(amount);
    if (isNaN(orderAmount) || orderAmount <= 0) {
      return validationErrorResponse('수량은 0보다 큰 숫자여야 합니다.');
    }

    // 지정가 주문의 경우 가격 검증
    let orderPrice: number | undefined;
    if (orderType === 'LIMIT') {
      if (!price) {
        return validationErrorResponse('지정가 주문은 가격을 입력해야 합니다.');
      }
      orderPrice = parseFloat(price);
      if (isNaN(orderPrice) || orderPrice <= 0) {
        return validationErrorResponse('가격은 0보다 큰 숫자여야 합니다.');
      }
    }

    // 주문 매칭 엔진을 통한 주문 생성 및 매칭
    const matchResult = await OrderMatchingEngine.matchOrder({
      userId: user.id,
      type: type as OrderType,
      price: orderPrice,
      amount: orderAmount,
      orderType: (orderType ?? 'LIMIT') as OrderPriceType
    });

    if (!matchResult.success) {
      return errorResponse(
        matchResult.error ?? '주문 생성 실패',
        ErrorCode.OPERATION_NOT_ALLOWED
      );
    }

    const result = matchResult.buyOrder || matchResult.sellOrder;
    if (!result) {
      return errorResponse('주문 정보를 찾을 수 없습니다', ErrorCode.SERVER_ERROR);
    }

    return successResponse({
      message: `${type === 'BUY' ? '매수' : '매도'} 주문이 생성되었습니다.`,
      orders: {
        id: result.id,
        type: result.type,
        price: decimalToNumber(result.price),
        amount: decimalToNumber(result.amount),
        filledAmount: decimalToNumber(result.filledAmount),
        remainingAmount: decimalToNumber(result.remainingAmount),
        status: result.status,
        orderType: result.orderType,
        txHash: result.txHash,
        createdAt: result.createdAt,
      },
      trades: matchResult.trades?.map(trade => ({
        id: trade.id,
        price: decimalToNumber(trade.price),
        amount: decimalToNumber(trade.amount),
        totalValue: decimalToNumber(trade.totalValue),
        tradedAt: trade.tradedAt
      }))
    });
  } catch (error: unknown) {
    console.error('[Exchange Order] Error:', error);
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '주문 생성 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}

/**
 * 주문 내역 조회
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type'); // BUY, SELL, all
    const status = searchParams.get('status'); // PENDING, PARTIAL, FILLED, CANCELLED, all
    const page = parseInt(searchParams.get('page') ?? '1', 10);
    const limit = parseInt(searchParams.get('limit') ?? '20', 10);
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {
      userId: user.id,
      ...(type && type !== 'all' && { type }),
      ...(status && status !== 'all' && { status }),
    };

    const [orders, totalCount] = await Promise.all([
      prisma.orders.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.orders.count({ where }),
    ]);

    const totalPages = Math.ceil(totalCount / limit);

    return successResponse({
      orders: orders.map((order) => ({
        id: order.id,
        type: order.type,
        price: decimalToNumber(order.price),
        amount: decimalToNumber(order.amount),
        filledAmount: decimalToNumber(order.filledAmount),
        remainingAmount: decimalToNumber(order.remainingAmount),
        status: order.status,
        orderType: order.orderType,
        txHash: order.txHash,
        createdAt: order.createdAt,
        updatedAt: order.updatedAt,
        filledAt: order.filledAt,
        cancelledAt: order.cancelledAt,
      })),
      pagination: {
        currentPage: page,
        totalPages,
        totalCount,
        limit,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      },
    });
  } catch (error: unknown) {
    console.error('[Exchange Order] 조회 실패:', error);
    
    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    const errorMessage = error instanceof Error ? error.message : '주문 조회 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
