import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Decimal } from '@prisma/client/runtime/library';

export const dynamic = 'force-dynamic';

// MSUP 10 = MSUO 1 (게임 코인 변환 비율)
const MSUP_PER_MSUO = 10;

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
    }

    const body = await request.json();
    const { from, to, amount } = body;

    if (!from || !to || !amount || !['MSUO', 'MSUP'].includes(from) || !['MSUO', 'MSUP'].includes(to)) {
      return NextResponse.json({ ok: false, error: 'Invalid swap parameters' }, { status: 400 });
    }

    if (from === to) {
      return NextResponse.json({ ok: false, error: 'Cannot swap same coin' }, { status: 400 });
    }

    const swapAmount = new Decimal(amount);
    if (swapAmount.lte(0)) {
      return NextResponse.json({ ok: false, error: 'Amount must be greater than 0' }, { status: 400 });
    }

    // MSUP→MSUO는 최소 10 MSUP부터 (10 미만은 0 MSUO가 됨)
    if (from === 'MSUP' && swapAmount.lt(MSUP_PER_MSUO)) {
      return NextResponse.json({ ok: false, error: `MSUP→MSUO requires minimum ${MSUP_PER_MSUO} MSUP` }, { status: 400 });
    }

    // 비율 계산: MSUO→MSUP은 x10, MSUP→MSUO는 /10 (소수점 8자리 절사)
    const receiveAmount = from === 'MSUO'
      ? swapAmount.mul(MSUP_PER_MSUO)
      : swapAmount.div(MSUP_PER_MSUO).toDecimalPlaces(8, Decimal.ROUND_DOWN);

    const dbUser = await prisma.users.findUnique({
      where: { id: user.id },
      select: { personalCoin: true },
    });

    if (!dbUser) {
      return NextResponse.json({ ok: false, error: 'User not found' }, { status: 404 });
    }

    const msuoBalance = new Decimal(dbUser.personalCoin || 0);

    // 잔액 확인
    if (msuoBalance.lt(swapAmount)) {
      return NextResponse.json({ ok: false, error: 'Insufficient balance' }, { status: 400 });
    }

    // 트랜잭션으로 교환 처리
    const result = await prisma.$transaction(async (tx) => {
      const updated = await tx.users.update({
        where: { id: user.id },
        data: {
          personalCoin: from === 'MSUO'
            ? { decrement: swapAmount }
            : { increment: receiveAmount },
        },
        select: { personalCoin: true },
      });

      await tx.transfers.create({
        data: {
          senderId: user.id,
          receiverId: user.id,
          amount: swapAmount,
          fee: new Decimal(0),
          status: 'COMPLETED',
          networkType: 'OFF_CHAIN',
          description: `${from} → ${to} swap: ${swapAmount} ${from} → ${receiveAmount} ${to}`,
          receiveAmount: receiveAmount,
          receiveCurrency: to,
          direction: from === 'MSUO' ? 'OUT' : 'IN',
        },
      });

      return updated;
    });

    return NextResponse.json({
      ok: true,
      data: {
        from,
        to,
        amount: Number(swapAmount),
        receiveAmount: Number(receiveAmount),
        newBalance: Number(result.personalCoin),
      },
    });
  } catch (error) {
    console.error('[Exchange/Swap] Error:', error);
    return NextResponse.json({ ok: false, error: 'Swap failed' }, { status: 500 });
  }
}
