import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import { generateWalletAddress } from '@/lib/wallet-utils';
import {
  successResponse,
  errorResponse,
  validationErrorResponse,
  handlePrismaError,
  ErrorCode,
} from '@/lib/api-response';

/**
 * @swagger
 * /api/auth/register:
 *   post:
 *     summary: 사용자 회원가입
 *     description: 새로운 사용자 계정을 생성합니다. 자동으로 지갑 주소와 추천인 코드가 생성됩니다.
 *     tags:
 *       - Authentication
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/AuthRegisterRequest'
 *     responses:
 *       200:
 *         description: 회원가입 성공
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 ok:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: 회원가입이 완료되었습니다.
 *                 data:
 *                   $ref: '#/components/schemas/User'
 *       400:
 *         description: 잘못된 요청 (필드 누락, 이메일 형식 오류, 비밀번호 길이 부족)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       409:
 *         description: 중복된 사용자명 또는 이메일
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { username, email, password } = body;

    // 기본 검증
    if (!username || !email || !password) {
      return validationErrorResponse('모든 필드를 입력해주세요.');
    }

    // 사용자명 형식 검증
    const trimmedUsername = username.trim();
    if (trimmedUsername.length < 2 || trimmedUsername.length > 20) {
      return validationErrorResponse('사용자명은 2~20자 사이여야 합니다.');
    }

    // 이메일 형식 검증
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const trimmedEmail = email.trim().toLowerCase();
    if (!emailRegex.test(trimmedEmail)) {
      return validationErrorResponse('올바른 이메일 형식이 아닙니다.');
    }

    // 비밀번호 검증 (최소 6자)
    if (!password || password.length < 6) {
      return validationErrorResponse('비밀번호는 최소 6자 이상이어야 합니다.');
    }

    // 중복 확인
    const existingUser = await prisma.users.findFirst({
      where: {
        OR: [{ username: trimmedUsername }, { email: trimmedEmail }],
      },
      select: {
        id: true,
        username: true,
        email: true,
      },
    });

    if (existingUser) {
      const field = existingUser.username === trimmedUsername ? '사용자명' : '이메일';
      return errorResponse(
        `이미 사용 중인 ${field}입니다.`,
        ErrorCode.ALREADY_EXISTS
      );
    }

    // 기본 추천인 (시스템 관리자)
    let referrerId: string | null = null;
    let sponsorId: string | null = null;

    // 기본 추천인으로 시스템 관리자 찾기
    const systemAdmin = await prisma.users.findFirst({
      where: { role: 'SUPER_ADMIN' },
      select: { id: true },
    });

    if (systemAdmin) {
      referrerId = systemAdmin.id;
      sponsorId = systemAdmin.id;
    }

    // 비밀번호 해싱
    const hashedPassword = await bcrypt.hash(password, 10);

    // 고유한 추천인 코드 생성 (중복 시 재시도)
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let referralCode = '';
    let isReferralCodeUnique = false;
    let attempts = 0;
    const maxAttempts = 10;

    while (!isReferralCodeUnique && attempts < maxAttempts) {
      referralCode = '';
      for (let i = 0; i < 8; i++) {
        referralCode += chars.charAt(Math.floor(Math.random() * chars.length));
      }

      const existing = await prisma.users.findUnique({
        where: { referralCode },
      });
      if (!existing) {
        isReferralCodeUnique = true;
      }
      attempts++;
    }

    if (!isReferralCodeUnique) {
      return errorResponse(
        '추천인 코드 생성에 실패했습니다. 다시 시도해주세요.',
        ErrorCode.SERVER_ERROR
      );
    }

    // 지갑 주소 자동 생성 (중복 시 재시도)
    let walletAddress = '';
    let isWalletAddressUnique = false;
    attempts = 0;

    while (!isWalletAddressUnique && attempts < maxAttempts) {
      walletAddress = generateWalletAddress();
      const existing = await prisma.users.findUnique({
        where: { walletAddress },
      });
      if (!existing) {
        isWalletAddressUnique = true;
      }
      attempts++;
    }

    if (!isWalletAddressUnique) {
      return errorResponse(
        '지갑 주소 생성에 실패했습니다. 다시 시도해주세요.',
        ErrorCode.SERVER_ERROR
      );
    }

    // 유저 생성
    const user = await prisma.users.create({
      data: {
        username: trimmedUsername,
        email: trimmedEmail,
        password: hashedPassword,
        referralCode,
        referrerId,
        sponsorId,
        walletAddress,
        status: 'ACTIVE',
        isActive: true,
        role: 'USER',
        id: crypto.randomUUID(),
        updatedAt: new Date(),
      },
      select: {
        id: true,
        username: true,
        email: true,
        createdAt: true,
      },
    });

    // 세션 쿠키 설정 (회원가입 후 자동 로그인)
    const cookieStore = await cookies();
    
    const isProduction = process.env.NODE_ENV === 'production';
    const forwardedProto = request.headers.get('x-forwarded-proto');
    const isHttps = forwardedProto === 'https' || request.url.startsWith('https://');
    
    cookieStore.set('userId', user.id, {
      httpOnly: true,
      secure: isProduction && isHttps,
      sameSite: isProduction && isHttps ? 'none' : 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7일
      path: '/',
    });

    return successResponse(user, '회원가입이 완료되었습니다.');
  } catch (error: unknown) {
    console.error('회원가입 실패:', error);

    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const prismaError = handlePrismaError(error);
      return errorResponse(prismaError.message, prismaError.status, prismaError.code);
    }

    // 일반 에러
    const errorMessage = error instanceof Error ? error.message : '회원가입 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
