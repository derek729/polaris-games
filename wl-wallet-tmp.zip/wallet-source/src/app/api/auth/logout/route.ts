import { cookies } from 'next/headers';
import { successResponse, errorResponse, ErrorCode } from '@/lib/api-response';

/**
 * @swagger
 * /api/auth/logout:
 *   post:
 *     summary: 사용자 로그아웃
 *     description: 현재 세션을 종료하고 쿠키를 삭제합니다.
 *     tags:
 *       - Authentication
 *     responses:
 *       200:
 *         description: 로그아웃 성공
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 ok:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: 로그아웃 성공
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
export async function POST() {
  try {
    const cookieStore = await cookies();

    // userId 쿠키 삭제
    cookieStore.delete('userId');

    return successResponse(null, '로그아웃 성공');

  } catch (error) {
    console.error('로그아웃 실패:', error);
    const errorMessage = error instanceof Error ? error.message : '로그아웃 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
