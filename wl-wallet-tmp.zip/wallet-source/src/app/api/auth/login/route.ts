import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import {
  successResponse,
  errorResponse,
  validationErrorResponse,
  unauthorizedResponse,
  handlePrismaError,
  ErrorCode,
} from '@/lib/api-response';
import { checkRateLimit, rateLimitConfigs } from '@/lib/rate-limit';

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     summary: 사용자 로그인
 *     description: 사용자명 또는 이메일과 비밀번호로 로그인합니다.
 *     tags:
 *       - Authentication
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - password
 *             properties:
 *               username:
 *                 type: string
 *                 description: 사용자명
 *                 example: testuser
 *               email:
 *                 type: string
 *                 format: email
 *                 description: 이메일
 *                 example: test@example.com
 *               password:
 *                 type: string
 *                 format: password
 *                 description: 비밀번호
 *                 example: password123
 *     responses:
 *       200:
 *         description: 로그인 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthLoginResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: 접근 거부 (비활성화 계정 또는 관리자 계정)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       429:
 *         description: 요청 한도 초과
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
export async function POST(request: Request) {
  // Rate Limiting 체크
  const rateLimitResult = await checkRateLimit(request, rateLimitConfigs.auth);
  if (!rateLimitResult.success) {
    return rateLimitResult.response;
  }

  try {
    const body = await request.json();
    let { username, email, password } = body;

    // username 필드에 이메일 형식이 입력된 경우 자동으로 email로 처리
    if (username && !email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username.trim())) {
      email = username.trim();
      username = undefined;
      console.log('[Login] 이메일 형식 감지, email 필드로 변환:', email);
    }

    // username 또는 email 중 하나는 필수
    const identifier = username || email;
    if (!identifier || !password) {
      return validationErrorResponse('사용자명(또는 이메일)과 비밀번호를 입력해주세요.');
    }

    // 유저 조회 (username 또는 email로 검색)
    const whereConditions: { username?: string }[] | { email?: string }[] = [];
    if (username) {
      whereConditions.push({ username: username.trim() });
    }
    if (email) {
      whereConditions.push({ email: email.trim().toLowerCase() });
    }

    if (whereConditions.length === 0) {
      return validationErrorResponse('사용자명 또는 이메일을 입력해주세요.');
    }

    const user = await prisma.users.findFirst({
      where: {
        OR: whereConditions,
      },
      select: {
        id: true,
        username: true,
        email: true,
        password: true,
        status: true,
        isActive: true,
        role: true,
      },
    });

    if (!user) {
      console.log('[Login] 사용자를 찾을 수 없음:', { username, email, whereConditions });
      return unauthorizedResponse('사용자명 또는 비밀번호가 올바르지 않습니다.');
    }

    // role이 null이거나 undefined인 경우 USER로 설정
    const userRole = user.role ?? 'USER';

    // role이 null인 사용자는 USER로 업데이트 (다음 요청부터는 정상 작동)
    if (!user.role) {
      try {
        await prisma.users.update({
          where: { id: user.id },
          data: { role: 'USER' },
        });
        console.log('[Login] role이 null인 사용자를 USER로 업데이트:', user.id);
      } catch (updateError) {
        console.error('[Login] role 업데이트 실패:', updateError);
        // 업데이트 실패해도 로그인은 계속 진행
      }
    }

    console.log('[Login] 사용자 조회 성공:', {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      normalizedRole: userRole,
      isActive: user.isActive,
      status: user.status,
      hasPassword: !!user.password,
    });

    if (!user.isActive || user.status !== 'ACTIVE') {
      return errorResponse('비활성화된 계정입니다.', ErrorCode.FORBIDDEN);
    }

    // 일반 로그인에서는 관리자 계정 차단
    if (userRole === 'ADMIN' || userRole === 'SUPER_ADMIN') {
      return errorResponse(
        '관리자 계정은 관리자 전용 로그인 페이지를 사용해주세요.',
        ErrorCode.FORBIDDEN
      );
    }

    // 비밀번호 확인
    if (!user.password) {
      console.log('[Login] 비밀번호가 설정되지 않은 계정:', user.id);
      return unauthorizedResponse('비밀번호가 설정되지 않은 계정입니다.');
    }

    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      console.log('[Login] 비밀번호 불일치:', {
        userId: user.id,
        username: user.username,
        passwordLength: password?.length ?? 0,
      });
      return unauthorizedResponse('사용자명 또는 비밀번호가 올바르지 않습니다.');
    }

    console.log('[Login] 로그인 성공:', { userId: user.id, username: user.username });

    // 세션 쿠키 설정
    const cookieStore = await cookies();

    const isProduction = process.env.NODE_ENV === 'production';
    const forwardedProto = request.headers.get('x-forwarded-proto');
    const isHttps = forwardedProto === 'https' || request.url.startsWith('https://');

    const finalCookieOptions = {
      httpOnly: true,
      maxAge: 60 * 60 * 24 * 7, // 7일
      path: '/',
      secure: isProduction && isHttps,
      sameSite: (isProduction && isHttps ? 'none' : 'lax') as 'lax' | 'none',
    };

    cookieStore.set('userId', user.id, finalCookieOptions);
    console.log('[Login] 쿠키 설정 완료:', {
      userId: user.id,
      cookieOptions: finalCookieOptions,
      isProduction,
      isHttps,
    });

    // 성공한 로그인은 Rate Limit 카운트에서 제외 (설정에 따라)
    const response = successResponse(
      {
        id: user.id,
        username: user.username,
        email: user.email,
        role: userRole,
      },
      '로그인 성공'
    );

    // Rate Limit 헤더 추가
    if (rateLimitResult.remaining !== undefined && rateLimitResult.resetTime) {
      response.headers.set('X-RateLimit-Remaining', rateLimitResult.remaining.toString());
      response.headers.set('X-RateLimit-Reset', new Date(rateLimitResult.resetTime).toISOString());
    }

    return response;
  } catch (error: unknown) {
    console.error('로그인 실패:', error);

    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const prismaError = handlePrismaError(error);
      return errorResponse(prismaError.message, prismaError.status, prismaError.code);
    }

    // 일반 에러
    const errorMessage = error instanceof Error ? error.message : '로그인 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
