import { prisma } from '@/lib/prisma';
import { cookies } from 'next/headers';
import {
  successResponse,
  errorResponse,
  unauthorizedResponse,
  handlePrismaError,
  ErrorCode,
} from '@/lib/api-response';

/**
 * @swagger
 * /api/auth/me:
 *   get:
 *     summary: 현재 로그인된 사용자 정보 조회
 *     description: 세션 쿠키를 기반으로 현재 로그인된 사용자의 정보를 반환합니다.
 *     tags:
 *       - Authentication
 *     responses:
 *       200:
 *         description: 사용자 정보 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 ok:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/User'
 *       401:
 *         description: 인증 필요
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       403:
 *         description: 비활성화된 계정
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
export async function GET(request: Request) {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get('userId')?.value;

    if (!userId) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 사용자 정보 조회
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        walletAddress: true,
        rank: true,
        personalCoin: true,
        ozCoin: true,
        totalInvestment: true,
        status: true,
        isActive: true,
        createdAt: true,
        role: true,
        referralCode: true,
      },
    });

    if (!user) {
      // 사용자가 없으면 쿠키 삭제
      cookieStore.delete('userId');
      return unauthorizedResponse('사용자를 찾을 수 없습니다.');
    }

    if (!user.isActive || user.status !== 'ACTIVE') {
      return errorResponse('비활성화된 계정입니다.', ErrorCode.FORBIDDEN);
    }

    // null/undefined 필드 안전 처리
    return successResponse(
      {
        users: {
          ...user,
          personalCoin: Number(user.personalCoin ?? 0),
          ozCoin: Number(user.ozCoin ?? 0),
          totalInvestment: Number(user.totalInvestment ?? 0),
          rank: user.rank ?? 1,
          role: user.role ?? 'USER',
          referralCode: user.referralCode ?? '',
          walletAddress: user.walletAddress ?? '',
        },
      },
      '사용자 정보 조회 성공'
    );
  } catch (error: unknown) {
    console.error('사용자 정보 조회 실패:', error);

    // Prisma 에러 처리
    if (typeof error === 'object' && error !== null && 'code' in error) {
      const prismaError = handlePrismaError(error);
      return errorResponse(prismaError.message, prismaError.status, prismaError.code);
    }

    // 일반 에러
    const errorMessage = error instanceof Error ? error.message : '사용자 정보 조회 중 오류가 발생했습니다.';
    return errorResponse(errorMessage, ErrorCode.SERVER_ERROR);
  }
}
