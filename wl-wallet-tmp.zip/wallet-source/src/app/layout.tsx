import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { I18nProvider } from "@/lib/i18n/context";
import { ToastProvider } from "@/components/ui/Toast";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
  preload: false, // preload 경고 방지를 위해 비활성화
  adjustFontFallback: true,
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3009'),
  title: "MSUO Coin Foundation",
  description: "MSUO Coin Foundation 공식 웹사이트",
  manifest: "/manifest.json",
  icons: {
    icon: [
      { url: "/icons/logo.jpg", sizes: "any", type: "image/jpeg" },
      { url: "/icons/logo.jpg", sizes: "192x192", type: "image/jpeg" },
      { url: "/icons/logo.jpg", sizes: "512x512", type: "image/jpeg" },
    ],
    apple: [
      { url: "/icons/logo.jpg", sizes: "180x180", type: "image/jpeg" },
    ],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "MSUO Foundation",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    type: "website",
    siteName: "MSUO Coin Foundation",
    title: "MSUO Coin Foundation",
    description: "MSUO Coin Foundation 공식 웹사이트",
    images: [
      {
        url: "/icons/logo.jpg",
        width: 512,
        height: 512,
        alt: "MSUO Foundation Logo",
      },
    ],
  },
  twitter: {
    card: "summary",
    title: "MSUO Foundation",
    description: "MSUO Coin Foundation 공식 웹사이트",
    images: ["/icons/logo.jpg"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko" data-scroll-behavior="smooth">
      <head>
        {/* 모바일 최적화 뷰포트 설정 */}
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=5.0, viewport-fit=cover" />
        <meta name="theme-color" content="#101922" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />

        {/* Favicon 및 아이콘 설정 */}
        <link rel="icon" type="image/jpeg" sizes="32x32" href="/icons/logo.jpg" />
        <link rel="icon" type="image/jpeg" sizes="16x16" href="/icons/logo.jpg" />
        <link rel="apple-touch-icon" href="/icons/logo.jpg" />
        <link rel="manifest" href="/manifest.json" />

        {/* Google Fonts - Material Icons */}
        <link
          rel="preconnect"
          href="https://fonts.googleapis.com"
        />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&family=Oswald:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />

        {/* 폰트 및 아이콘 최적화 스타일 */}
        <style dangerouslySetInnerHTML={{
          __html: `
            .material-symbols-outlined {
              font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
              user-select: none;
              -webkit-user-select: none;
            }
            
            /* 모바일 폰트 최적화 */
            @media (max-width: 640px) {
              html {
                font-size: 14px;
              }
              
              /* 모바일에서 텍스트 줄바꿈 허용 */
              * {
                word-break: keep-all;
                overflow-wrap: break-word;
              }
            }
            
            /* 이미지 최적화 */
            img {
              max-width: 100%;
              height: auto;
              display: block;
              object-fit: contain;
            }
            
            /* 모바일에서 컨테이너 오버플로우 방지 */
            @media (max-width: 640px) {
              body {
                overflow-x: hidden;
              }
              
              .container, .container-fluid {
                max-width: 100%;
                padding-left: 0.5rem;
                padding-right: 0.5rem;
              }
            }
          `
        }} />
      </head>
      <body
        className={`${inter.variable} font-sans antialiased text-white`}
      >
        {/* 전체 페이지 배경 이미지 - 증권/금융 테마 */}
        <div 
          className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat pointer-events-none"
          style={{
            backgroundImage: 'url(https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80)',
          }}
        >
          {/* 어두운 오버레이 */}
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900/95 via-slate-800/90 to-slate-900/95 pointer-events-none"></div>
        </div>
        {/* 콘텐츠가 배경 위에 표시되도록 */}
        <div className="relative z-10 min-h-screen">
          <I18nProvider>
            <ToastProvider>
              {children}
            </ToastProvider>
          </I18nProvider>
        </div>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                if ('serviceWorker' in navigator) {
                  // 모든 환경에서 Service Worker 제거 및 캐시 삭제
                  Promise.all([
                    navigator.serviceWorker.getRegistrations().then(function(registrations) {
                      return Promise.all(
                        registrations.map(function(registration) {
                          return registration.unregister();
                        })
                      );
                    }),
                    'caches' in window ? caches.keys().then(function(cacheNames) {
                      return Promise.all(
                        cacheNames.map(function(cacheName) {
                          return caches.delete(cacheName);
                        })
                      );
                    }) : Promise.resolve()
                  ]).then(function() {
                    console.log('Service Worker and caches cleared');
                  });
                }
              })();
            `,
          }}
        />
      </body>
    </html>
  );
}
