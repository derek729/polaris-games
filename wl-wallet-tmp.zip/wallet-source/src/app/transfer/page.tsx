'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import WalletHeader from '@/app/_components/WalletHeader';
import { CheckCircle, AlertCircle } from 'lucide-react';

export default function TransferPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    receiver: '',
    amount: '',
    memo: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const amountNum = useMemo(() => parseFloat(formData.amount) || 0, [formData.amount]);
  const ozCoinFee = 0.01; 

  const handleConfirm = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/user/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          receiverIdentifier: formData.receiver,
          amount: amountNum,
          memo: formData.memo,
          password: formData.password
        }),
      });

      const data = await response.json();
      if (data.ok) {
        alert('전송이 완료되었습니다.');
        router.push('/');
      } else {
        alert(data.error || '전송 실패');
      }
    } catch (error) {
      console.error(error);
      alert('오류가 발생했습니다.');
    } finally {
      setLoading(false);
      setShowConfirmModal(false);
    }
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 animate-fade-in">
          <div className="w-full max-w-md bg-[#1e293b] rounded-2xl border border-white/10 p-6 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <AlertCircle className="text-yellow-400" />
              전송 확인
            </h3>
            <div className="space-y-4 mb-6">
              <div className="bg-black/30 p-4 rounded-xl">
                <div className="text-sm text-gray-400 mb-1">받는 사람</div>
                <div className="text-lg text-white font-medium break-all">{formData.receiver}</div>
              </div>
              <div className="bg-black/30 p-4 rounded-xl">
                <div className="text-sm text-gray-400 mb-1">전송 수량</div>
                <div className="text-2xl text-green-400 font-bold">{amountNum} MSUO</div>
              </div>
              <div className="text-sm text-gray-400 text-center">
                위 정보가 정확한지 확인해주세요.<br/>전송 후에는 취소할 수 없습니다.
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-3 rounded-xl bg-gray-700 hover:bg-gray-600 text-white font-bold transition-colors"
              >
                취소
              </button>
              <button
                onClick={handleConfirm}
                disabled={loading}
                className="flex-1 py-3 rounded-xl bg-[#137fec] hover:bg-[#0f6fd0] text-white font-bold transition-colors disabled:opacity-50"
              >
                {loading ? '처리 중...' : '확인 및 전송'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6">
              <div className="flex flex-wrap justify-between gap-4 items-center py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    코인 전송
                  </p>
                  <p className="text-gray-400 text-base font-normal leading-normal">
                    MSUO 네트워크 내부 전송 (즉시 처리)
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); setShowConfirmModal(true); }}>
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          받는 사람 (주소, 이메일, 아이디)
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.receiver}
                          onChange={(e) => setFormData((p) => ({ ...p, receiver: e.target.value }))}
                          className="w-full px-4 py-4 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent text-lg"
                          placeholder="0x... 또는 user@email.com"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          전송 수량 (MSUO)
                        </label>
                        <input
                          type="number"
                          required
                          min="0.00000001"
                          step="0.00000001"
                          value={formData.amount}
                          onChange={(e) => setFormData((p) => ({ ...p, amount: e.target.value }))}
                          className="w-full px-4 py-4 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent text-lg"
                          placeholder="0.00"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          메모 (선택)
                        </label>
                        <input
                          type="text"
                          value={formData.memo}
                          onChange={(e) => setFormData((p) => ({ ...p, memo: e.target.value }))}
                          className="w-full px-4 py-4 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent text-lg"
                          placeholder="거래 메모"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          비밀번호
                        </label>
                        <input
                          type="password"
                          value={formData.password}
                          onChange={(e) => setFormData((p) => ({ ...p, password: e.target.value }))}
                          className="w-full px-4 py-4 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent text-lg"
                          placeholder="비밀번호를 입력하세요"
                          required
                        />
                      </div>

                      <div className="rounded-xl border border-white/10 bg-black/20 p-4 text-sm text-gray-300">
                        <div className="flex items-center justify-between">
                          <span>전송 수수료 (OZ)</span>
                          <span className="font-semibold text-white">0.01 OZ</span>
                        </div>
                        <div className="mt-2 flex items-center justify-between">
                          <span>총 전송 금액</span>
                          <span className="font-semibold text-white">{amountNum.toFixed(2)} MSUO</span>
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={!formData.receiver || !formData.amount || parseFloat(formData.amount) <= 0 || !formData.password}
                        className="w-full px-4 py-4 rounded-lg bg-[#137fec] hover:bg-[#0f6fd0] disabled:bg-gray-700 disabled:text-gray-500 text-white font-bold text-lg transition-colors"
                      >
                        전송하기
                      </button>
                    </form>
                  </div>
                </div>

                <aside className="bg-white/5 border border-white/10 rounded-xl p-6">
                  <div className="text-white font-bold text-lg">전송 안내</div>
                  <div className="mt-3 text-sm text-gray-300 leading-relaxed space-y-2">
                    <p>• <b>내부 전송:</b> MSUO 네트워크 내 사용자 간 전송은 즉시 처리됩니다.</p>
                    <p>• <b>수수료:</b> 건당 0.01 OZ가 차감됩니다.</p>
                    <p>• <b>주의:</b> 잘못된 주소로 전송 시 복구가 불가능할 수 있으니 주소를 반드시 확인하세요.</p>
                  </div>
                </aside>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}


