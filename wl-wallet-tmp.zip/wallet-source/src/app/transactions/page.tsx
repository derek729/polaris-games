'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import WalletHeader from '@/app/_components/WalletHeader';
import { Card, CardContent, CardHeader } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Grid, Stack } from '@/components/ui/Grid';
import { Skeleton, SkeletonTable } from '@/components/ui/LoadingState';
import { cn } from '@/lib/utils';

type Transfer = {
  id: string;
  type: 'sent' | 'received';
  status: string;
  sender: {
    id: string;
    username: string | null;
    email: string | null;
    walletAddress?: string | null;
  };
  receiver: {
    id: string;
    username: string | null;
    email: string | null;
    walletAddress?: string | null;
  };
  amount: number;
  fee: number;
  memo?: string;
  transferredAt: string;
  confirmations?: number;
  txHash?: string | null;
  networkType?: string;
};

export default function TransactionsPage() {
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'sent' | 'received'>('all');

  useEffect(() => {
    fetchTransfers();
  }, [filter]);

  const fetchTransfers = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (filter !== 'all') {
        params.append('type', filter);
      }

      const response = await fetch(`/api/user/transfer?${params}`, {
        credentials: 'include',
      });

      const data = await response.json();

      if (data.ok && data.data) {
        setTransfers(data.data);
      }
    } catch (error) {
      console.error('전송 내역 조회 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string | Date | undefined | null) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '-';
    return date.toLocaleString('ko-KR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const truncateAddress = (address: string | null | undefined) => {
    if (!address) return '-';
    return `${address.slice(0, 8)}...${address.slice(-6)}`;
  };

  return (
    <div className="relative min-h-screen">
      {/* 배경 장식 */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/4 w-1/2 h-full bg-gradient-to-br from-blue-500/5 to-transparent rounded-full blur-3xl" />
        <div className="absolute -bottom-1/2 -right-1/4 w-1/2 h-full bg-gradient-to-tl from-purple-500/5 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <WalletHeader />

          <main className="space-y-6">
            {/* 페이지 타이틀 */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/20">
                  <span className="material-symbols-outlined text-xl text-blue-400">receipt_long</span>
                </div>
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold text-white">거래내역</h1>
                  <p className="text-sm text-gray-400">코인 전송 내역을 확인하세요.</p>
                </div>
              </div>
              <Link href="/transfer">
                <Button>
                  <span className="material-symbols-outlined text-lg">send</span>
                  새 전송
                </Button>
              </Link>
            </div>

            {/* 필터 버튼 */}
            <div className="flex items-center gap-2">
              <Button
                variant={filter === 'all' ? 'primary' : 'secondary'}
                size="sm"
                onClick={() => setFilter('all')}
              >
                전체
              </Button>
              <Button
                variant={filter === 'sent' ? 'primary' : 'secondary'}
                size="sm"
                onClick={() => setFilter('sent')}
              >
                <span className="material-symbols-outlined text-sm">arrow_upward</span>
                보낸 내역
              </Button>
              <Button
                variant={filter === 'received' ? 'primary' : 'secondary'}
                size="sm"
                onClick={() => setFilter('received')}
              >
                <span className="material-symbols-outlined text-sm">arrow_downward</span>
                받은 내역
              </Button>
            </div>

            {/* 거래 내역 카드 */}
            <Card variant="glass">
              <CardContent padding="none">
                {loading ? (
                  <div className="p-6">
                    <SkeletonTable rows={5} columns={6} />
                  </div>
                ) : transfers.length === 0 ? (
                  <div className="py-16 text-center">
                    <span className="material-symbols-outlined text-5xl text-gray-600 mb-4">receipt_long</span>
                    <p className="text-gray-400 text-lg mb-2">거래 내역이 없습니다.</p>
                    <p className="text-gray-500 text-sm">새로운 거래가 발생하면 여기에 표시됩니다.</p>
                    <Link href="/transfer" className="mt-4 inline-block">
                        <Button variant="outline">
                          첫 거래 시작하기
                        </Button>
                    </Link>
                  </div>
                ) : (
                  <>
                    {/* 데스크탑: 테이블 뷰 */}
                    <div className="hidden lg:block overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="text-left text-sm text-gray-400 border-b border-white/10 bg-white/5">
                            <th className="py-4 px-6 font-medium">유형</th>
                            <th className="py-4 px-6 font-medium">상태</th>
                            <th className="py-4 px-6 font-medium">상대방</th>
                            <th className="py-4 px-6 font-medium">금액</th>
                            <th className="py-4 px-6 font-medium">수수료</th>
                            <th className="py-4 px-6 font-medium">네트워크</th>
                            <th className="py-4 px-6 font-medium">메모</th>
                            <th className="py-4 px-6 font-medium">일시</th>
                          </tr>
                        </thead>
                        <tbody>
                          {transfers.map((tx) => (
                            <TransactionRow key={tx.id} tx={tx} formatDate={formatDate} truncateAddress={truncateAddress} />
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* 모바일/태블릿: 카드 뷰 */}
                    <div className="lg:hidden divide-y divide-white/10">
                      {transfers.map((tx) => (
                        <TransactionCard key={tx.id} tx={tx} formatDate={formatDate} truncateAddress={truncateAddress} />
                      ))}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </main>
        </div>
      </div>
    </div>
  );
}

// 테이블 행 컴포넌트
function TransactionRow({ tx, formatDate, truncateAddress }: { 
  tx: Transfer; 
  formatDate: (d: string) => string;
  truncateAddress: (a: string | null | undefined) => string;
}) {
  const isSent = tx.type === 'sent';
  const isCompleted = tx.status === 'COMPLETED' || tx.status === 'completed';
  const counterparty = isSent ? tx.receiver : tx.sender;

  return (
    <tr className="border-b border-white/5 text-gray-200 hover:bg-white/5 transition-colors">
      <td className="py-4 px-6">
        <div className="flex items-center gap-2">
          <div className={cn(
            'p-1.5 rounded-lg',
            isSent ? 'bg-red-500/20' : 'bg-green-500/20'
          )}>
            <span className="material-symbols-outlined text-sm">
              {isSent ? 'arrow_upward' : 'arrow_downward'}
            </span>
          </div>
          <span className={cn(
            'font-medium',
            isSent ? 'text-red-400' : 'text-green-400'
          )}>
            {isSent ? '전송' : '수신'}
          </span>
        </div>
      </td>
      <td className="py-4 px-6">
        <span className={cn(
          'px-2.5 py-1 rounded-full text-xs font-medium',
          isCompleted
            ? 'bg-green-500/20 text-green-300'
            : 'bg-yellow-500/20 text-yellow-300'
        )}>
          {isCompleted ? '완료' : '처리중'}
        </span>
      </td>
      <td className="py-4 px-6">
        <div className="flex flex-col">
          <span className="text-white font-medium">
            {counterparty.username || counterparty.email}
          </span>
          <span className="text-xs text-gray-500 font-mono">
            {truncateAddress(counterparty.walletAddress)}
          </span>
        </div>
      </td>
      <td className="py-4 px-6">
        <span className={cn(
          'text-lg font-bold',
          isSent ? 'text-red-400' : 'text-green-400'
        )}>
          {isSent ? '-' : '+'}{tx.amount.toFixed(2)} MSUO
        </span>
      </td>
      <td className="py-4 px-6 text-gray-400">
        {tx.fee > 0 ? `${tx.fee.toFixed(4)} OZ` : '-'}
      </td>
      <td className="py-4 px-6">
        <span className="text-xs text-gray-400 bg-white/5 px-2 py-1 rounded">
          {tx.networkType || 'OFF_CHAIN'}
        </span>
      </td>
      <td className="py-4 px-6 text-gray-300 text-sm max-w-[200px] truncate" title={tx.memo || ''}>
        {tx.memo || '-'}
      </td>
      <td className="py-4 px-6 text-gray-400 text-sm">
        {formatDate(tx.transferredAt)}
      </td>
    </tr>
  );
}

// 모바일 카드 컴포넌트
function TransactionCard({ tx, formatDate, truncateAddress }: { 
  tx: Transfer; 
  formatDate: (d: string) => string;
  truncateAddress: (a: string | null | undefined) => string;
}) {
  const isSent = tx.type === 'sent';
  const isCompleted = tx.status === 'COMPLETED' || tx.status === 'completed';
  const counterparty = isSent ? tx.receiver : tx.sender;

  return (
    <div className="p-4 hover:bg-white/5 transition-colors">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className={cn(
            'p-2.5 rounded-xl',
            isSent ? 'bg-red-500/20' : 'bg-green-500/20'
          )}>
            <span className="material-symbols-outlined text-lg">
              {isSent ? 'arrow_upward' : 'arrow_downward'}
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className={cn(
                'font-semibold',
                isSent ? 'text-red-400' : 'text-green-400'
              )}>
                {isSent ? '전송' : '수신'}
              </span>
              <span className={cn(
                'px-2 py-0.5 rounded-full text-xs font-medium',
                isCompleted
                  ? 'bg-green-500/20 text-green-300'
                  : 'bg-yellow-500/20 text-yellow-300'
              )}>
                {isCompleted ? '완료' : '처리중'}
              </span>
            </div>
            <p className="text-sm text-gray-400 mt-0.5">
              {counterparty.username || counterparty.email}
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className={cn(
            'text-lg font-bold',
            isSent ? 'text-red-400' : 'text-green-400'
          )}>
            {isSent ? '-' : '+'}{tx.amount.toFixed(2)}
          </p>
          <p className="text-xs text-gray-500">MSUO</p>
        </div>
      </div>
      <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-gray-500">
        <span>{formatDate(tx.transferredAt)}</span>
        <div className="flex items-center gap-3">
          {tx.memo && <span className="text-gray-400 max-w-[100px] truncate" title={tx.memo}>{tx.memo}</span>}
          <span>수수료: {tx.fee > 0 ? tx.fee.toFixed(4) + ' OZ' : '-'}</span>
          <span className="bg-white/5 px-2 py-0.5 rounded">
            {tx.networkType || 'OFF_CHAIN'}
          </span>
        </div>
      </div>
    </div>
  );
}
