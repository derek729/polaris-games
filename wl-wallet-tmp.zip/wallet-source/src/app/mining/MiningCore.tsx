'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { HARDWARE_PRESETS } from '@/lib/mining-physics';
import { Zap, Server, TrendingUp, DollarSign, BarChart3, Play, Pause, Plus, Minus, RotateCcw } from 'lucide-react';

interface UserInfo {
  id: string;
  username: string | null;
  personalCoin?: unknown;
  [key: string]: unknown;
}

interface NetworkStats {
  totalMinedSupply: string;
  activeMiners: number;
  totalMiningSessions: number;
  networkDifficulty: string;
  currentHalvingEpoch: number;
  nextHalvingDate: string | null;
  halvingMultiplier: string;
  recent24h: { totalClaimed: string; claimCount: number; uniqueMiners: number };
}

interface UserMiningStats {
  activeSession: { sessionId: string; startTime: string; hashrate: string; hardwareHashrate?: string; slotBonusPercent?: number; difficulty: string } | null;
  slotBonusPercent?: number;
  totalMined: string;
  totalSessions: number;
  completedClaims: number;
  msuoBalance: string;
  recent24h: { totalClaimed: string; claimCount: number };
}

export default function MiningCore({ user }: { user: UserInfo }) {
  const { language } = useI18n();
  const L = (ko: string, en: string) => language === 'ko' ? ko : en;

  const [miningActive, setMiningActive] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [currentHashrate, setCurrentHashrate] = useState(0);
  const [currentReward, setCurrentReward] = useState(0);

  const [selectedHardware, setSelectedHardware] = useState('preset_0');
  const [miningUnits, setMiningUnits] = useState(1);
  const [networkStats, setNetworkStats] = useState<NetworkStats | null>(null);
  const [userStats, setUserStats] = useState<UserMiningStats | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const statsRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pollRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const consecutiveFailures = useRef(0);

  useEffect(() => {
    if (toast) { const t = setTimeout(() => setToast(null), 4000); return () => clearTimeout(t); }
  }, [toast]);

  const showToast = (msg: string) => setToast(msg);

  const fetchNetworkStats = useCallback(async () => {
    try {
      const res = await fetch('/api/user/mining/stats');
      if (res.ok) { const json = await res.json(); if (json.ok) setNetworkStats(json.data); }
    } catch { /* silent */ }
  }, []);

  const fetchUserStats = useCallback(async () => {
    try {
      const res = await fetch('/api/user/mining/user-stats');
      if (res.ok) {
        const json = await res.json();
        if (json.ok) {
          const data = json.data as UserMiningStats;
          setUserStats(data);
          if (data.activeSession) {
            setMiningActive(true);
            setSessionId(data.activeSession.sessionId);
            setStartTime(new Date(data.activeSession.startTime));
            setCurrentHashrate(parseFloat(data.activeSession.hashrate) || 0);
          } else {
            setMiningActive(false);
            setSessionId(null);
            setStartTime(null);
          }
          consecutiveFailures.current = 0;
        }
      }
    } catch { consecutiveFailures.current++; }
  }, []);

  useEffect(() => {
    fetchNetworkStats();
    fetchUserStats();
    statsRef.current = setInterval(fetchNetworkStats, 30000);
    return () => { if (statsRef.current) clearInterval(statsRef.current); };
  }, [fetchNetworkStats, fetchUserStats]);

  useEffect(() => {
    if (miningActive && startTime) {
      timerRef.current = setInterval(() => {
        setElapsedSeconds(Math.floor((Date.now() - startTime.getTime()) / 1000));
      }, 1000);
    } else {
      if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [miningActive, startTime]);

  useEffect(() => {
    if (!miningActive) {
      if (pollRef.current) { clearTimeout(pollRef.current); pollRef.current = null; }
      consecutiveFailures.current = 0;
      return;
    }
    let aborted = false;
    const poll = async () => {
      try {
        const controller = new AbortController();
        const tid = setTimeout(() => controller.abort(), 8000);
        const res = await fetch('/api/user/mining/user-stats', { signal: controller.signal });
        clearTimeout(tid);
        if (aborted || !res.ok) return;
        const json = await res.json();
        if (json.ok) {
          const data = json.data as UserMiningStats;
          setUserStats(data);
          if (data.activeSession) {
            setStartTime(new Date(data.activeSession.startTime));
            setCurrentHashrate(parseFloat(data.activeSession.hashrate) || 0);
          }
          consecutiveFailures.current = 0;
        }
      } catch { consecutiveFailures.current++; }
    };
    const getDelay = () => {
      const f = consecutiveFailures.current;
      if (f === 0) return 5000;
      if (f < 3) return 10000;
      if (f < 6) return 30000;
      return 60000;
    };
    const schedule = () => {
      if (!aborted) pollRef.current = setTimeout(() => { if (!aborted) poll().then(schedule); }, getDelay());
    };
    poll().then(schedule);
    return () => { aborted = true; if (pollRef.current) { clearTimeout(pollRef.current); pollRef.current = null; } };
  }, [miningActive, fetchUserStats]);

  const startMining = async () => {
    setActionLoading(true);
    try {
      const res = await fetch('/api/user/mining/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hardwareId: selectedHardware, miningUnits }),
      });
      const json = await res.json();
      if (json.ok) {
        setMiningActive(true);
        setSessionId(json.data?.sessionId || null);
        setStartTime(new Date());
        setElapsedSeconds(0);
        setCurrentReward(0);
        if (json.data?.totalHashrate) {
          setCurrentHashrate(parseFloat(json.data.totalHashrate) || 0);
        }
        showToast(L('채굴이 시작되었습니다.', 'Mining started.'));
        fetchUserStats();
      } else {
        const errMsg = typeof json.error === 'object' ? json.error.message : json.error;
        showToast(errMsg || L('채굴 시작 실패', 'Failed to start mining'));
      }
    } catch { showToast(L('오류가 발생했습니다.', 'An error occurred.')); }
    setActionLoading(false);
  };

  const stopMining = async () => {
    setActionLoading(true);
    try {
      const res = await fetch('/api/user/mining/stop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId }),
      });
      const json = await res.json();
      if (json.ok) {
        setMiningActive(false);
        showToast(L('채굴이 중지되었습니다.', 'Mining stopped.'));
      } else {
        const errMsg = typeof json.error === 'object' ? json.error.message : json.error;
        showToast(errMsg || L('중지 실패', 'Failed to stop'));
      }
    } catch { showToast(L('오류가 발생했습니다.', 'An error occurred.')); }
    setActionLoading(false);
  };

  const claimReward = async () => {
    setActionLoading(true);
    try {
      const res = await fetch('/api/user/mining/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId, hashrate: currentHashrate, stakeAmount: 0 }),
      });
      const json = await res.json();
      if (json.ok) {
        setMiningActive(false);
        showToast(`${L('보상 청구 완료:', 'Reward claimed:')} ${json.data.minerReward} MSUO`);
        fetchUserStats();
        fetchNetworkStats();
      } else {
        const errMsg = typeof json.error === 'object' ? json.error.message : json.error;
        showToast(errMsg || L('청구 실패', 'Failed to claim'));
      }
    } catch { showToast(L('오류가 발생했습니다.', 'An error occurred.')); }
    setActionLoading(false);
  };

  const partialClaim = async () => {
    setActionLoading(true);
    try {
      const res = await fetch('/api/user/mining/claim-partial', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId, hashrate: currentHashrate, stakeAmount: 0 }),
      });
      const json = await res.json();
      if (json.ok) {
        showToast(`${L('부분 청구 완료:', 'Partial claim:')} ${json.data.minerReward} MSUO`);
        fetchUserStats();
      } else {
        const errMsg = typeof json.error === 'object' ? json.error.message : json.error;
        showToast(errMsg || L('부분 청구 실패', 'Failed to partial claim'));
      }
    } catch { showToast(L('오류가 발생했습니다.', 'An error occurred.')); }
    setActionLoading(false);
  };

  const formatHashrate = (hr: number) => {
    if (hr >= 1e12) return `${(hr / 1e12).toFixed(2)} TH/s`;
    if (hr >= 1e9) return `${(hr / 1e9).toFixed(2)} GH/s`;
    if (hr >= 1e6) return `${(hr / 1e6).toFixed(2)} MH/s`;
    if (hr >= 1e3) return `${(hr / 1e3).toFixed(2)} KH/s`;
    return `${hr.toFixed(2)} H/s`;
  };

  const formatElapsed = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}h ${m}m ${sec}s`;
    if (m > 0) return `${m}m ${sec}s`;
    return `${sec}s`;
  };

  const hardwareList = HARDWARE_PRESETS.map((p, i) => ({
    id: `preset_${i}`, name: p.name, hashrate: p.hashrate, power: p.powerConsumption,
    algorithm: p.algorithm, efficiency: p.efficiency,
  }));

  const selectedHw = hardwareList.find(h => h.id === selectedHardware) || hardwareList[0];
  const totalHashrate = selectedHw.hashrate * miningUnits;

  return (
    <div className="space-y-8">
      {/* Toast */}
      {toast && (
        <div className="fixed top-4 right-4 z-50 bg-gray-800 border border-amber-500/50 text-white px-5 py-3 rounded-xl shadow-xl animate-in fade-in slide-in-from-top-2">
          {toast}
        </div>
      )}

      {/* Network Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={<Zap className="h-5 w-5 text-yellow-500" />} label={L('총 채굴량', 'Total Mined')}
          value={networkStats ? `${(parseFloat(networkStats.totalMinedSupply) || 0).toLocaleString()} MSUO` : '-'} />
        <StatCard icon={<Server className="h-5 w-5 text-blue-500" />} label={L('활성 채굴자', 'Active Miners')}
          value={networkStats ? String(networkStats.activeMiners) : '-'} />
        <StatCard icon={<DollarSign className="h-5 w-5 text-green-500" />} label={L('24h 채굴', '24h Mining')}
          value={networkStats ? `${(parseFloat(networkStats.recent24h?.totalClaimed) || 0).toFixed(4)} MSUO` : '-'} />
        <StatCard icon={<BarChart3 className="h-5 w-5 text-purple-500" />} label={L('난이도', 'Difficulty')}
          value={networkStats ? networkStats.networkDifficulty : '-'} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {/* Hardware Selection */}
        <div className="bg-gray-900/60 backdrop-blur-md rounded-2xl p-6 border border-white/5 shadow-xl">
          <h2 className="text-2xl font-bold mb-6 text-white flex items-center gap-3">
            <span className="w-1 h-8 bg-gradient-to-b from-orange-400 to-red-600 rounded-full" />
            {L('채굴 장비 선택', 'Mining Equipment')}
          </h2>
          <div className="space-y-3 mb-6">
            {hardwareList.slice(0, 4).map((hw) => (
              <div
                key={hw.id}
                onClick={() => setSelectedHardware(hw.id)}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  selectedHardware === hw.id
                    ? 'bg-gradient-to-r from-orange-950/60 to-gray-900 border-orange-500/70'
                    : 'bg-black/40 border-gray-800 hover:border-gray-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className={`font-bold ${selectedHardware === hw.id ? 'text-white' : 'text-gray-300'}`}>{hw.name}</div>
                    <div className="text-xs text-gray-500">{hw.algorithm} - {hw.efficiency} J/TH</div>
                  </div>
                  <div className="text-right">
                    <div className={`font-bold font-mono ${selectedHardware === hw.id ? 'text-orange-400' : 'text-gray-300'}`}>
                      {formatHashrate(hw.hashrate)}
                    </div>
                    <div className="text-xs text-gray-500 font-mono">{hw.power}W</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="bg-black/40 rounded-xl p-4 border border-white/5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-gray-300">{L('장비 수량', 'Units')}</span>
              <div className="flex items-center gap-3 bg-gray-900 rounded-lg p-1 border border-gray-700">
                <button onClick={() => setMiningUnits(u => Math.max(u - 1, 1))} disabled={miningUnits <= 1}
                  className="p-1.5 rounded-md hover:bg-gray-700 text-gray-400 hover:text-white disabled:opacity-30">
                  <Minus className="h-4 w-4" />
                </button>
                <span className="text-white font-bold text-lg min-w-[2rem] text-center">{miningUnits}</span>
                <button onClick={() => setMiningUnits(u => Math.min(u + 1, 100))} disabled={miningUnits >= 100}
                  className="p-1.5 rounded-md hover:bg-gray-700 text-gray-400 hover:text-white disabled:opacity-30">
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="text-xs text-gray-500">{L('총 해시레이트:', 'Total hashrate:')} <span className="text-amber-400 font-mono">{formatHashrate(totalHashrate)}</span></div>
          </div>
        </div>

        {/* Mining Status & Controls */}
        <div className="bg-gray-900/60 backdrop-blur-md rounded-2xl p-6 border border-white/5 shadow-xl">
          <h2 className="text-2xl font-bold mb-6 text-white flex items-center gap-3">
            <span className="w-1 h-8 bg-gradient-to-b from-green-400 to-emerald-600 rounded-full" />
            {L('내 채굴 현황', 'My Mining Status')}
          </h2>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-black/30 rounded-xl p-4 border border-white/5">
              <div className="text-xs text-gray-400 mb-1">{L('해시레이트', 'Hashrate')}</div>
              <div className="text-xl font-bold text-yellow-400 font-mono">{formatHashrate(currentHashrate)}</div>
              {(userStats?.activeSession?.slotBonusPercent ?? userStats?.slotBonusPercent ?? 0) > 0 && (
                <div className="text-xs text-emerald-400 mt-1">+{(userStats?.activeSession?.slotBonusPercent ?? userStats?.slotBonusPercent ?? 0).toFixed(0)}% {L('슬롯 보너스', 'Slot Bonus')}</div>
              )}
            </div>
            <div className="bg-black/30 rounded-xl p-4 border border-white/5">
              <div className="text-xs text-gray-400 mb-1">{L('운영 시간', 'Duration')}</div>
              <div className="text-xl font-bold text-blue-400 font-mono">{formatElapsed(elapsedSeconds)}</div>
            </div>
            <div className="bg-black/30 rounded-xl p-4 border border-white/5">
              <div className="text-xs text-gray-400 mb-1">{L('총 채굴량', 'Total Mined')}</div>
              <div className="text-xl font-bold text-green-400 font-mono">{userStats ? parseFloat(userStats.totalMined).toFixed(4) : '0'} MSUO</div>
            </div>
            <div className="bg-black/30 rounded-xl p-4 border border-white/5">
              <div className="text-xs text-gray-400 mb-1">{L('MSUO 잔고', 'MSUO Balance')}</div>
              <div className="text-xl font-bold text-purple-400 font-mono">{userStats ? parseFloat(userStats.msuoBalance).toFixed(4) : '0'} MSUO</div>
            </div>
          </div>

          {userStats?.recent24h && (
            <div className="bg-black/20 rounded-lg p-3 mb-6 border border-white/5">
              <span className="text-xs text-gray-400">{L('최근 24h:', 'Last 24h:')}</span>
              <span className="text-sm text-green-400 ml-2 font-mono">{parseFloat(userStats.recent24h.totalClaimed).toFixed(4)} MSUO</span>
              <span className="text-xs text-gray-500 ml-2">({userStats.recent24h.claimCount} {L('건', 'claims')})</span>
            </div>
          )}

          {networkStats && (
            <div className="bg-black/20 rounded-lg p-3 mb-6 border border-white/5 flex items-center gap-4">
              <span className="text-xs text-gray-400">{L('에포크:', 'Epoch:')}</span>
              <span className="text-sm text-amber-400 font-mono">{networkStats.currentHalvingEpoch}</span>
              <span className="text-xs text-gray-400">{L('반감기 배율:', 'Halving:')}</span>
              <span className="text-sm text-amber-400 font-mono">x{networkStats.halvingMultiplier}</span>
              <span className="text-xs text-gray-400">40/5/55</span>
            </div>
          )}

          <div className="flex gap-3">
            {!miningActive ? (
              <button onClick={startMining} disabled={actionLoading}
                className="flex-1 py-4 rounded-xl font-bold text-lg bg-gradient-to-r from-green-600 to-emerald-700 hover:from-green-500 hover:to-emerald-600 text-white shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                <Play className="h-6 w-6" />
                {L('채굴 시작', 'Start Mining')}
              </button>
            ) : (
              <>
                <button onClick={claimReward} disabled={actionLoading}
                  className="flex-1 py-4 rounded-xl font-bold text-lg bg-gradient-to-r from-green-600 to-emerald-700 hover:from-green-500 hover:to-emerald-600 text-white shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                  <DollarSign className="h-5 w-5" />
                  {L('보상 청구', 'Claim Reward')}
                </button>
                <button onClick={partialClaim} disabled={actionLoading}
                  className="px-4 py-4 rounded-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 text-white shadow-lg transition-all disabled:opacity-50">
                  <TrendingUp className="h-5 w-5" />
                </button>
                <button onClick={stopMining} disabled={actionLoading}
                  className="px-4 py-4 rounded-xl font-bold bg-gradient-to-r from-red-600 to-pink-700 hover:from-red-500 hover:to-pink-600 text-white shadow-lg transition-all disabled:opacity-50">
                  <Pause className="h-5 w-5" />
                </button>
              </>
            )}
          </div>

          <p className="text-xs text-gray-500 mt-3 text-center">
            {L('보상 비율: 채굴자 40% / 소개자 5% / 재단 55%', 'Reward ratio: Miner 40% / Referrer 5% / Foundation 55%')}
          </p>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-gray-900/40 backdrop-blur-md rounded-2xl p-5 border border-white/5 hover:border-amber-500/20 transition-all group">
      <div className="flex items-center justify-between mb-3">
        <span className="text-gray-400 text-xs font-medium tracking-wider">{label}</span>
        <div className="p-2 bg-yellow-500/10 rounded-lg">{icon}</div>
      </div>
      <div className="text-lg font-bold text-white font-mono group-hover:text-yellow-400 transition-colors truncate">{value}</div>
    </div>
  );
}
