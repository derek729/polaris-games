'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n/context';
import MiningCore from './MiningCore';
import ReferralSlotPanel from './ReferralSlotPanel';
import SlotMarketplace from './SlotMarketplace';
import HashRateLeaderboard from './HashRateLeaderboard';

interface UserInfo {
  id: string;
  username: string | null;
  personalCoin?: unknown;
  [key: string]: unknown;
}

type TabKey = 'core' | 'slots' | 'marketplace' | 'leaderboard';

export default function MiningPoolClient({ user }: { user: UserInfo }) {
  const { language } = useI18n();
  const [activeTab, setActiveTab] = useState<TabKey>('core');

  const tabs: { key: TabKey; labelKo: string; labelEn: string }[] = [
    { key: 'core', labelKo: '채굴', labelEn: 'Mining' },
    { key: 'slots', labelKo: '리퍼럴 슬롯', labelEn: 'Referral Slots' },
    { key: 'marketplace', labelKo: '마켓플레이스', labelEn: 'Marketplace' },
    { key: 'leaderboard', labelKo: '리더보드', labelEn: 'Leaderboard' },
  ];

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-[#0a0a0a] to-black text-white p-4 font-sans selection:bg-amber-500/30">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-5xl md:text-6xl font-extrabold mb-4 bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-600 bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(245,158,11,0.3)]">
            {language === 'ko' ? 'MSUO 채굴 풀' : 'MSUO Mining Pool'}
          </h1>
          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
            {language === 'ko'
              ? 'MSUO 네트워크에 참여하여 프리미엄 채굴 보상을 획득하세요.'
              : 'Join the MSUO network and earn premium mining rewards.'}
          </p>
        </div>

        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-5 py-2.5 rounded-xl font-bold text-sm whitespace-nowrap transition-all ${
                activeTab === tab.key
                  ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-900/30'
                  : 'bg-gray-800/60 text-gray-400 hover:text-white hover:bg-gray-700/60'
              }`}
            >
              {language === 'ko' ? tab.labelKo : tab.labelEn}
            </button>
          ))}
        </div>

        {activeTab === 'core' && <MiningCore user={user} />}
        {activeTab === 'slots' && <ReferralSlotPanel />}
        {activeTab === 'marketplace' && <SlotMarketplace />}
        {activeTab === 'leaderboard' && <HashRateLeaderboard />}
      </div>
    </div>
  );
}
