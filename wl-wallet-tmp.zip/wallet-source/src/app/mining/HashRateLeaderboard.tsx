'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { Trophy, Zap } from 'lucide-react';

interface LeaderboardEntry {
  rank: number;
  userId: string;
  username: string;
  hashrate: number;
  sessions: number;
}

export default function HashRateLeaderboard() {
  const { language } = useI18n();
  const L = (ko: string, en: string) => language === 'ko' ? ko : en;

  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [myRank, setMyRank] = useState<{ rank: number; hashrate: number } | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch('/api/user/mining/hashrate-leaderboard');
      if (res.ok) {
        const json = await res.json();
        if (json.ok) {
          setLeaderboard(json.data.leaderboard);
          setMyRank(json.data.currentUserRank);
        }
      }
    } catch { /* silent */ }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const getMedal = (rank: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return `#${rank}`;
  };

  const formatHashrate = (hr: number) => {
    if (hr >= 1e12) return `${(hr / 1e12).toFixed(1)} TH/s`;
    if (hr >= 1e9) return `${(hr / 1e9).toFixed(1)} GH/s`;
    if (hr >= 1e6) return `${(hr / 1e6).toFixed(1)} MH/s`;
    return `${(hr / 1e3).toFixed(1)} KH/s`;
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white flex items-center gap-3">
        <Trophy className="h-7 w-7 text-amber-400" />
        {L('해시레이트 리더보드', 'Hashrate Leaderboard')}
      </h2>

      {myRank && (
        <div className="bg-gradient-to-r from-amber-900/30 to-gray-900/60 backdrop-blur-md rounded-xl p-4 border border-amber-500/30">
          <div className="flex items-center justify-between">
            <span className="text-gray-300 font-medium">{L('나의 순위', 'My Rank')}</span>
            <div className="flex items-center gap-3">
              <span className="text-2xl font-bold text-amber-400">{getMedal(myRank.rank)}</span>
              <span className="text-sm text-gray-400 font-mono">{formatHashrate(myRank.hashrate)}</span>
            </div>
          </div>
        </div>
      )}

      <div className="bg-gray-900/60 backdrop-blur-md rounded-2xl border border-white/5 overflow-hidden">
        <div className="grid grid-cols-[3fr_3fr_1.5fr] px-4 py-3 bg-gray-800/50 text-xs text-gray-400 font-bold uppercase tracking-wider">
          <span>{L('순위', 'Rank')}</span>
          <span>{L('채굴자', 'Miner')}</span>
          <span>{L('해시레이트', 'Hashrate')}</span>
        </div>
        <div className="divide-y divide-gray-800/30">
          {leaderboard.map((entry) => (
            <div key={entry.userId} className="grid grid-cols-[3fr_3fr_1.5fr] px-4 py-3 hover:bg-gray-800/30 transition-colors">
              <span className="text-lg">{getMedal(entry.rank)}</span>
              <span className="text-white font-medium truncate">{entry.username}</span>
              <span className="text-amber-400 font-mono text-sm flex items-center gap-1">
                <Zap className="h-3 w-3" /> {formatHashrate(entry.hashrate)}
              </span>
            </div>
          ))}
        </div>
        {leaderboard.length === 0 && (
          <div className="text-center text-gray-500 py-12">{L('아직 데이터가 없습니다.', 'No data yet.')}</div>
        )}
      </div>
    </div>
  );
}
