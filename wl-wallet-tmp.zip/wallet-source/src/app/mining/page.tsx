import { getCurrentUser } from '@/lib/auth';
import WalletHeader from '@/app/_components/WalletHeader';
import MiningPoolClient from './MiningPoolClient';

export const dynamic = 'force-dynamic';

export default async function MiningPage() {
  const user = await getCurrentUser();

  if (!user) {
    return (
      <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
        <div className="layout-container flex h-full grow flex-col">
          <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
            <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
              <div className="flex items-center justify-center min-h-[60vh]">
                <div className="text-center">
                  <p className="text-white text-xl mb-4">채굴을 이용하려면 로그인이 필요합니다.</p>
                  <a
                    href="/"
                    className="inline-block rounded-xl bg-[#137fec] hover:bg-[#0f6fd0] px-6 py-3 font-bold text-white transition-colors"
                  >
                    홈으로 돌아가기
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 mt-6">
              <MiningPoolClient user={user} />
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
