'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { Lock, Unlock, Plus, Minus, Users, Zap, RotateCcw, Bot } from 'lucide-react';

interface Slot {
  id: string;
  slotId: number;
  status: string;
  level: number;
  baseHashRate: number;
  currentHashRate: number;
  referralCode: string | null;
  referredUserId: string | null;
  referredUser: { id: string; username: string | null } | null;
  enhanceAttemptCount: number;
}

export default function ReferralSlotPanel() {
  const { language } = useI18n();
  const L = (ko: string, en: string) => language === 'ko' ? ko : en;

  const [slots, setSlots] = useState<Slot[]>([]);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (toast) { const t = setTimeout(() => setToast(null), 4000); return () => clearTimeout(t); }
  }, [toast]);

  const fetchSlots = useCallback(async () => {
    try {
      const res = await fetch('/api/user/mining/referral-slots');
      if (res.ok) { const json = await res.json(); if (json.ok) setSlots(json.data); }
    } catch { /* silent */ }
  }, []);

  useEffect(() => { fetchSlots(); }, [fetchSlots]);

  const unlockSlot = async (slotId: number) => {
    setLoading(true);
    try {
      const res = await fetch('/api/user/mining/referral-slots/unlock', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slotId }),
      });
      const json = await res.json();
      if (json.ok) {
        setToast(json.data.success ? L(`슬롯 #${slotId} 잠금해제 성공!`, `Slot #${slotId} unlocked!`) : L(`실패! 다시 시도하세요.`, `Failed! Try again.`));
        fetchSlots();
      } else {
        setToast(json.error || 'Error');
      }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const enhanceSlot = async (slotId: number) => {
    setLoading(true);
    try {
      const res = await fetch('/api/user/mining/referral-slots/enhance', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slotId }),
      });
      const json = await res.json();
      if (json.ok) {
        setToast(json.data.success
          ? L(`슬롯 #${slotId} Lv.${json.data.newLevel} 달성! (${(json.data.successRate * 100).toFixed(0)}%)`, `Slot #${slotId} Lv.${json.data.newLevel}! (${(json.data.successRate * 100).toFixed(0)}%)`)
          : L(`강화 실패. 성공률: ${(json.data.successRate * 100).toFixed(0)}%`, `Enhance failed. Rate: ${(json.data.successRate * 100).toFixed(0)}%`));
        fetchSlots();
      } else {
        setToast(json.error || 'Error');
      }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const addReferral = async (slotId: number) => {
    const code = prompt(L('추천 코드를 입력하세요:', 'Enter referral code:'));
    if (!code) return;
    setLoading(true);
    try {
      const res = await fetch('/api/user/mining/referral-slots/add-referral', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slotId, referralCode: code }),
      });
      const json = await res.json();
      if (json.ok) { setToast(L('추천인이 추가되었습니다.', 'Referral added.')); fetchSlots(); }
      else { setToast(json.error || 'Error'); }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const removeReferral = async (slotId: number) => {
    if (!confirm(L('추천인을 제거하시겠습니까?', 'Remove referral?'))) return;
    setLoading(true);
    try {
      const res = await fetch('/api/user/mining/referral-slots/remove-referral', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slotId }),
      });
      const json = await res.json();
      if (json.ok) { setToast(L('추천인이 제거되었습니다.', 'Referral removed.')); fetchSlots(); }
      else { setToast(json.error || 'Error'); }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const registerAvatar = async (slotId: number) => {
    setLoading(true);
    try {
      const res = await fetch('/api/user/mining/referral-slots/register-avatar', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slotId }),
      });
      const json = await res.json();
      if (json.ok) {
        if (json.data.success && json.data.referral) {
          setToast(L(
            `아바타 등록 성공! 추천인: ${json.data.referral.username} (Lv.${json.data.newLevel})`,
            `Avatar registered! Referral: ${json.data.referral.username} (Lv.${json.data.newLevel})`
          ));
        } else {
          setToast(json.data.message || L('아바타 등록 실패. 다시 시도하세요.', 'Avatar registration failed. Try again.'));
        }
        fetchSlots();
      } else {
        setToast(json.error || 'Error');
      }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const statusColor = (status: string) => {
    switch (status) {
      case 'LOCKED': return 'bg-gray-700 text-gray-400';
      case 'AVAILABLE': return 'bg-blue-900/40 text-blue-400';
      case 'ACTIVE': return 'bg-green-900/40 text-green-400';
      case 'ENHANCED': return 'bg-amber-900/40 text-amber-400';
      case 'AVATAR': return 'bg-purple-900/40 text-purple-400';
      default: return 'bg-gray-700 text-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {toast && (
        <div className="fixed top-4 right-4 z-50 bg-gray-800 border border-amber-500/50 text-white px-5 py-3 rounded-xl shadow-xl">
          {toast}
        </div>
      )}

      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-bold text-white">{L('리퍼럴 슬롯', 'Referral Slots')}</h2>
        <button onClick={fetchSlots} className="p-2 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors">
          <RotateCcw className="h-4 w-4 text-gray-400" />
        </button>
      </div>

      <p className="text-gray-400 text-sm mb-6">
        {L('슬롯을 잠금해제하고 추천인을 추가하여 해시레이트 보너스를 받으세요. (무료 슬롯 2개)', 'Unlock slots and add referrals for hashrate bonuses. (2 free slots)')}
      </p>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {slots.map((slot) => (
          <div key={slot.id} className="bg-gray-900/60 backdrop-blur-md rounded-xl p-4 border border-white/5 hover:border-amber-500/20 transition-all">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-gray-500"># {slot.slotId}</span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${statusColor(slot.status)}`}>
                {slot.status}
              </span>
            </div>

            {slot.status === 'LOCKED' ? (
              <button onClick={() => unlockSlot(slot.slotId)} disabled={loading}
                className="w-full py-3 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-bold text-sm hover:from-blue-500 transition-all disabled:opacity-50 flex items-center justify-center gap-1">
                <Unlock className="h-4 w-4" /> {L('잠금해제', 'Unlock')}
              </button>
            ) : (
              <>
                <div className="text-center mb-3">
                  <div className="text-lg font-bold text-white">Lv.{slot.level}</div>
                  <div className="text-xs text-gray-400 flex items-center justify-center gap-1">
                    <Zap className="h-3 w-3" /> {Number(slot.currentHashRate).toFixed(0)} H/s
                  </div>
                </div>

                {/* 추천인 정보 표시 */}
                {slot.referredUser && slot.status !== 'AVATAR' ? (
                  <div className="bg-green-900/20 rounded-lg p-2 mb-2">
                    <div className="text-xs text-green-400 truncate">{slot.referredUser.username || slot.referredUser.id}</div>
                    <button onClick={() => removeReferral(slot.slotId)} disabled={loading}
                      className="text-xs text-red-400 hover:text-red-300 mt-1">{L('제거', 'Remove')}</button>
                  </div>
                ) : null}

                {/* 아바타 등록 완료 표시 */}
                {slot.status === 'AVATAR' && (
                  <div className="bg-purple-900/20 rounded-lg p-2 mb-2 border border-purple-500/30">
                    <div className="text-xs text-purple-400 flex items-center gap-1">
                      <Bot className="h-3 w-3" />{L('아바타 등록 완료', 'Avatar Registered')}
                    </div>
                    {slot.referredUser && (
                      <div className="text-xs text-green-300 mt-1 truncate">{slot.referredUser.username}</div>
                    )}
                  </div>
                )}

                {/* 추천인 추가 (AVATAR 상태 또는 이미 추천인 있으면 숨김) */}
                {!slot.referredUser && slot.status !== 'AVATAR' && (
                  <button onClick={() => addReferral(slot.slotId)} disabled={loading}
                    className="w-full py-2 rounded-lg bg-gray-800 text-gray-300 text-xs font-bold hover:bg-gray-700 transition-all disabled:opacity-50 mb-2">
                    <Users className="h-3 w-3 inline mr-1" />{L('추천인 추가', 'Add Referral')}
                  </button>
                )}

                <button onClick={() => enhanceSlot(slot.slotId)} disabled={loading || slot.level >= 20}
                  className="w-full py-2 rounded-lg bg-gradient-to-r from-amber-700 to-orange-800 text-white text-xs font-bold hover:from-amber-600 transition-all disabled:opacity-50 mb-2">
                  <Plus className="h-3 w-3 inline mr-1" />{L('강화', 'Enhance')}
                </button>

                {/* 아바타 등록 (AVATAR 상태 또는 이미 추천인 있으면 숨김) */}
                {!slot.referredUser && slot.status !== 'AVATAR' && (
                  <button onClick={() => registerAvatar(slot.slotId)} disabled={loading}
                    className="w-full py-2 rounded-lg bg-gradient-to-r from-purple-700 to-indigo-800 text-white text-xs font-bold hover:from-purple-600 transition-all disabled:opacity-50">
                    <Bot className="h-3 w-3 inline mr-1" />{L('아바타 등록 (20 MSUO)', 'Register Avatar (20 MSUO)')}
                  </button>
                )}
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
