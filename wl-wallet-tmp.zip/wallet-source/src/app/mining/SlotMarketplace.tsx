'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { ShoppingBag, DollarSign, X, Check, Clock, Tag } from 'lucide-react';

interface Listing {
  id: string; slotId: number; level: number; currentHashRate: number;
  price: number; sellerId: string; sellerUsername: string | null;
  offerCount: number; expiresAt: string; createdAt: string;
}

interface MyListing extends Listing {
  status: string;
}

interface Offer {
  id: string; listingId: string; slotId: number; slotLevel: number;
  listingStatus: string; sellerId: string; sellerUsername: string | null;
  offerPrice: number; status: string; createdAt: string;
}

export default function SlotMarketplace() {
  const { language } = useI18n();
  const L = (ko: string, en: string) => language === 'ko' ? ko : en;

  const [activeTab, setActiveTab] = useState<'browse' | 'my-listings' | 'my-offers'>('browse');
  const [listings, setListings] = useState<Listing[]>([]);
  const [myListings, setMyListings] = useState<MyListing[]>([]);
  const [myOffers, setMyOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(false);
  const [newListing, setNewListing] = useState<{ slotId: string; price: string }>({ slotId: '5', price: '' });
  const [newOffer, setNewOffer] = useState<{ listingId: string; price: string }>({ listingId: '', price: '' });
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => { if (toast) { const t = setTimeout(() => setToast(null), 4000); return () => clearTimeout(t); } }, [toast]);

  const fetchListings = useCallback(async () => {
    try {
      const res = await fetch('/api/user/mining/marketplace/listings');
      if (res.ok) { const json = await res.json(); if (json.ok) setListings(json.data); }
    } catch { /* silent */ }
  }, []);

  const fetchMyListings = useCallback(async () => {
    try {
      const res = await fetch('/api/user/mining/marketplace/my');
      if (res.ok) { const json = await res.json(); if (json.ok) setMyListings(json.data); }
    } catch { /* silent */ }
  }, []);

  const fetchMyOffers = useCallback(async () => {
    try {
      const res = await fetch('/api/user/mining/marketplace/offers');
      if (res.ok) { const json = await res.json(); if (json.ok) setMyOffers(json.data); }
    } catch { /* silent */ }
  }, []);

  useEffect(() => {
    if (activeTab === 'browse') fetchListings();
    else if (activeTab === 'my-listings') fetchMyListings();
    else fetchMyOffers();
  }, [activeTab, fetchListings, fetchMyListings, fetchMyOffers]);

  const createListing = async () => {
    if (!newListing.slotId || !newListing.price) { setToast(L('모든 필드를 입력하세요.', 'Fill all fields.')); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/user/mining/marketplace/listings', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slotId: Number(newListing.slotId), price: Number(newListing.price) }),
      });
      const json = await res.json();
      if (json.ok) { setToast(L('리스트가 등록되었습니다.', 'Listing created.')); fetchMyListings(); }
      else { setToast(json.error || 'Error'); }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const cancelListing = async (id: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/user/mining/marketplace/listings/${id}/cancel`, { method: 'POST' });
      const json = await res.json();
      if (json.ok) { setToast(L('리스트가 취소되었습니다.', 'Listing cancelled.')); fetchMyListings(); }
      else { setToast(json.error || 'Error'); }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const makeOffer = async () => {
    if (!newOffer.listingId || !newOffer.price) { setToast(L('모든 필드를 입력하세요.', 'Fill all fields.')); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/user/mining/marketplace/offers', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ listingId: newOffer.listingId, offerPrice: Number(newOffer.price) }),
      });
      const json = await res.json();
      if (json.ok) { setToast(L('오퍼가 생성되었습니다.', 'Offer created.')); fetchMyOffers(); }
      else { setToast(json.error || 'Error'); }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const acceptOffer = async (offerId: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/user/mining/marketplace/offers/${offerId}/accept`, { method: 'POST' });
      const json = await res.json();
      if (json.ok) { setToast(L('거래가 완료되었습니다!', 'Trade completed!')); fetchMyListings(); fetchListings(); }
      else { setToast(json.error || 'Error'); }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const rejectOffer = async (offerId: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/user/mining/marketplace/offers/${offerId}/reject`, { method: 'POST' });
      const json = await res.json();
      if (json.ok) { setToast(L('오퍼가 거절되었습니다.', 'Offer rejected.')); fetchMyListings(); }
      else { setToast(json.error || 'Error'); }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const cancelOffer = async (offerId: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/user/mining/marketplace/offers/${offerId}/cancel`, { method: 'POST' });
      const json = await res.json();
      if (json.ok) { setToast(L('오퍼가 취소되었습니다.', 'Offer cancelled.')); fetchMyOffers(); }
      else { setToast(json.error || 'Error'); }
    } catch { setToast('Error'); }
    setLoading(false);
  };

  const statusBadge = (status: string) => {
    const map: Record<string, string> = {
      PENDING: 'bg-yellow-900/40 text-yellow-400', ACCEPTED: 'bg-green-900/40 text-green-400',
      REJECTED: 'bg-red-900/40 text-red-400', CANCELLED: 'bg-gray-700 text-gray-400', COMPLETED: 'bg-blue-900/40 text-blue-400',
    };
    return map[status] || map.PENDING;
  };

  return (
    <div className="space-y-6">
      {toast && <div className="fixed top-4 right-4 z-50 bg-gray-800 border border-amber-500/50 text-white px-5 py-3 rounded-xl shadow-xl">{toast}</div>}

      <h2 className="text-2xl font-bold text-white flex items-center gap-3">
        <ShoppingBag className="h-7 w-7 text-amber-400" />
        {L('슬롯 마켓플레이스', 'Slot Marketplace')}
      </h2>

      <div className="flex gap-2 mb-4">
        {[
          { key: 'browse', ko: '탐색', en: 'Browse' },
          { key: 'my-listings', ko: '내 리스트', en: 'My Listings' },
          { key: 'my-offers', ko: '내 오퍼', en: 'My Offers' },
        ].map(tab => (
          <button key={tab.key} onClick={() => setActiveTab(tab.key as typeof activeTab)}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === tab.key ? 'bg-amber-600 text-white' : 'bg-gray-800 text-gray-400 hover:text-white'}`}>
            {language === 'ko' ? tab.ko : tab.en}
          </button>
        ))}
      </div>

      {activeTab === 'browse' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {listings.map(l => (
            <div key={l.id} className="bg-gray-900/60 rounded-xl p-4 border border-white/5 hover:border-amber-500/20 transition-all">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-white">#{l.slotId} - Lv.{l.level}</span>
                <span className="text-xs text-gray-500 flex items-center gap-1"><Clock className="h-3 w-3" />{l.offerCount}</span>
              </div>
              <div className="text-xs text-gray-400 mb-1">{L('판매자', 'Seller')}: {l.sellerUsername || '---'}</div>
              <div className="text-xs text-gray-400 mb-3">{L('해시레이트', 'Hashrate')}: {l.currentHashRate} H/s</div>
              <div className="text-lg font-bold text-amber-400 mb-3">{l.price.toLocaleString()} MSUO</div>
              <button onClick={() => { setNewOffer({ listingId: l.id, price: String(Math.floor(l.price * 0.95)) }); setActiveTab('my-offers'); }}
                className="w-full py-2 rounded-lg bg-gradient-to-r from-amber-600 to-orange-700 text-white text-sm font-bold hover:from-amber-500 transition-all">
                {L('오퍼하기', 'Make Offer')}
              </button>
            </div>
          ))}
          {listings.length === 0 && <div className="text-center text-gray-500 py-12">{L('등록된 리스트가 없습니다.', 'No listings available.')}</div>}
        </div>
      )}

      {activeTab === 'my-listings' && (
        <>
          <div className="bg-gray-900/60 rounded-xl p-4 border border-white/5 mb-4 flex gap-3 items-end">
            <div>
              <label className="text-xs text-gray-400 block mb-1">{L('슬롯 #', 'Slot #')}</label>
              <select value={newListing.slotId} onChange={e => setNewListing({ ...newListing, slotId: e.target.value })}
                className="bg-gray-800 text-white rounded-lg px-3 py-2 text-sm border border-gray-700 w-24">
                {[5, 10, 15, 20].map(l => <option key={l} value={l}>#{l}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-1">{L('가격 (MSUO)', 'Price (MSUO)')}</label>
              <input type="number" value={newListing.price} onChange={e => setNewListing({ ...newListing, price: e.target.value })}
                placeholder="100" className="bg-gray-800 text-white rounded-lg px-3 py-2 text-sm border border-gray-700 w-32" />
            </div>
            <button onClick={createListing} disabled={loading}
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-green-600 to-emerald-700 text-white text-sm font-bold hover:from-green-500 disabled:opacity-50">
              {L('등록', 'List')}
            </button>
          </div>
          <div className="space-y-3">
            {myListings.map(l => (
              <div key={l.id} className="bg-gray-900/60 rounded-xl p-4 border border-white/5 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">#{l.slotId} - Lv.{l.level} <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${statusBadge(l.status)}`}>{l.status}</span></div>
                  <div className="text-sm text-amber-400 font-mono">{l.price} MSUO</div>
                  {l.offerCount > 0 && (
                    <div className="text-xs text-gray-500 mt-1">{L(`${l.offerCount}개의 오퍼 대기중`, `${l.offerCount} offer(s) pending`)}</div>
                  )}
                </div>
                {l.status === 'ACTIVE' && (
                  <div className="flex gap-1">
                    <button onClick={() => { setActiveTab('my-offers'); }} disabled={loading}
                      className="p-2 bg-gray-800 rounded-lg hover:bg-green-900/50 text-gray-400 hover:text-green-400 transition-colors" title={L('오퍼 보기', 'View offers')}>
                      <ShoppingBag className="h-4 w-4" />
                    </button>
                    <button onClick={() => cancelListing(l.id)} disabled={loading}
                      className="p-2 bg-gray-800 rounded-lg hover:bg-red-900/50 text-gray-400 hover:text-red-400 transition-colors">
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>
            ))}
            {myListings.length === 0 && <div className="text-center text-gray-500 py-12">{L('등록한 리스트가 없습니다.', 'No listings.')}</div>}
          </div>
        </>
      )}

      {activeTab === 'my-offers' && (
        <>
          <div className="bg-gray-900/60 rounded-xl p-4 border border-white/5 mb-4 flex gap-3 items-end">
            <div className="flex-1">
              <label className="text-xs text-gray-400 block mb-1">{L('리스트 ID', 'Listing ID')}</label>
              <input type="text" value={newOffer.listingId} onChange={e => setNewOffer({ ...newOffer, listingId: e.target.value })}
                placeholder="..." className="bg-gray-800 text-white rounded-lg px-3 py-2 text-sm border border-gray-700 w-full" />
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-1">{L('가격 (MSUO)', 'Price')}</label>
              <input type="number" value={newOffer.price} onChange={e => setNewOffer({ ...newOffer, price: e.target.value })}
                placeholder="100" className="bg-gray-800 text-white rounded-lg px-3 py-2 text-sm border border-gray-700 w-32" />
            </div>
            <button onClick={makeOffer} disabled={loading}
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-700 text-white text-sm font-bold disabled:opacity-50">
              {L('오퍼', 'Offer')}
            </button>
          </div>
          <div className="space-y-3">
            {myOffers.map(o => (
              <div key={o.id} className="bg-gray-900/60 rounded-xl p-4 border border-white/5 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">#{o.slotId} Lv.{o.slotLevel} - {L('판매자', 'Seller')}: {o.sellerUsername || '---'}</div>
                  <div className="text-sm text-blue-400 font-mono">{o.offerPrice} MSUO <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${statusBadge(o.status)}`}>{o.status}</span></div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => cancelOffer(o.id)} disabled={loading}
                    className="p-2 bg-gray-800 rounded-lg hover:bg-red-900/50 text-gray-400 hover:text-red-400">
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
            {myOffers.length === 0 && <div className="text-center text-gray-500 py-12">{L('오퍼가 없습니다.', 'No offers.')}</div>}
          </div>
        </>
      )}
    </div>
  );
}
