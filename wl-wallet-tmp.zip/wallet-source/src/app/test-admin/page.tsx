'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function TestAdminPage() {
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const checkSetup = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/check-setup');
      const data = await response.json();
      setResult(data);
    } catch (error) {
      setResult({ error: error instanceof Error ? error.message : String(error) });
    } finally {
      setLoading(false);
    }
  };

  const testLogin = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: 'admin',
          password: 'Admin@123456',
        }),
      });
      const data = await response.json();
      setResult(data);
    } catch (error) {
      setResult({ error: error instanceof Error ? error.message : String(error) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">관리자 설정 테스트 페이지</h1>

        <div className="space-y-4">
          <div className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">설정 상태 확인</h2>
            <button
              onClick={checkSetup}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded disabled:opacity-50"
            >
              {loading ? '확인 중...' : '설정 상태 확인'}
            </button>
          </div>

          <div className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">로그인 테스트</h2>
            <p className="text-sm text-gray-400 mb-4">
              사용자명: admin, 비밀번호: Admin@123456
            </p>
            <button
              onClick={testLogin}
              disabled={loading}
              className="bg-green-600 hover:bg-green-700 px-4 py-2 rounded disabled:opacity-50 mr-4"
            >
              {loading ? '테스트 중...' : '로그인 테스트'}
            </button>
            <button
              onClick={() => router.push('/u0-admin/login')}
              className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded"
            >
              관리자 로그인 페이지
            </button>
          </div>

          {result && (
            <div className="bg-gray-800 p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-4">결과</h2>
              <pre className="bg-gray-900 p-4 rounded overflow-auto text-sm">
                {JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}

          <div className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">Railway Console 명령어</h2>
            <div className="bg-gray-900 p-4 rounded font-mono text-sm">
              <p>관리자 계정 생성:</p>
              <p className="text-green-400">npm run setup:admin</p>
              <p className="mt-2">또는:</p>
              <p className="text-green-400">node scripts/create-admin-with-db.js</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}