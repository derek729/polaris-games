'use client';

import WalletHeader from '@/app/_components/WalletHeader';
import Link from 'next/link';

export default function WhitepaperPage() {
  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6">
              <div className="flex flex-wrap justify-between gap-4 items-center py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    MSUO 코인 백서
                  </p>
                  <p className="text-gray-400 text-base font-normal leading-normal">
                    MSUO의 기술 백서를 확인하세요.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                {/* 한글 백서 */}
                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-2xl">🇰🇷</span>
                    <h2 className="text-xl font-bold text-white">한글 백서</h2>
                  </div>
                  <p className="text-gray-300 text-sm mb-6 leading-relaxed">
                    MSUO 코인의 기술적 세부사항과 재단의 비전을 한글로 확인하세요.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <a
                      href="/whitepaper/MSUO-Coin-TecKOWhitepaper.pdf"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 rounded-xl bg-[#137fec] hover:bg-[#0f6fd0] px-4 py-3 font-bold text-white text-center transition-colors"
                    >
                      미리보기
                    </a>
                    <a
                      href="/whitepaper/MSUO-Coin-TecKOWhitepaper.pdf"
                      download="MSUO-Coin-TecKOWhitepaper.pdf"
                      className="flex-1 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-3 font-bold text-white text-center transition-colors"
                    >
                      다운로드
                    </a>
                  </div>
                </div>

                {/* 영문 백서 */}
                <div className="rounded-2xl border border-white/10 bg-white/5 p-6 md:p-8">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-2xl">🇺🇸</span>
                    <h2 className="text-xl font-bold text-white">Technical Whitepaper</h2>
                  </div>
                  <p className="text-gray-300 text-sm mb-6 leading-relaxed">
                    Review the technical details and vision of MSUO in English.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <a
                      href="/whitepaper/MSUO-Coin-Technical-Whitepaper.pdf"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 rounded-xl bg-[#137fec] hover:bg-[#0f6fd0] px-4 py-3 font-bold text-white text-center transition-colors"
                    >
                      Preview
                    </a>
                    <a
                      href="/whitepaper/MSUO-Coin-Technical-Whitepaper.pdf"
                      download="MSUO-Coin-Technical-Whitepaper.pdf"
                      className="flex-1 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-3 font-bold text-white text-center transition-colors"
                    >
                      Download
                    </a>
                  </div>
                </div>
              </div>

              <div className="mt-6 rounded-xl border border-white/10 bg-black/20 p-4">
                <div className="text-sm text-gray-300 leading-relaxed">
                  <p className="font-semibold text-white mb-2">토큰 정보 (Token Information)</p>
                  <ul className="list-disc list-inside space-y-1 text-xs">
                    <li><strong>토큰명 (Token Name):</strong> MSUO</li>
                    <li><strong>총 발행량 (Total Supply):</strong> 50,000,000,000 (500억)</li>
                    <li><strong>채굴 (Mining):</strong> 25,000,000,000 (250억)</li>
                    <li><strong>발행 (Issuance):</strong> 25,000,000,000 (250억)</li>
                    <li><strong>주요 기능 (Features):</strong> 락업 기능 지원 (Lock Function)</li>
                  </ul>
                </div>
              </div>

              <div className="mt-6">
                <Link
                  href="/"
                  className="inline-flex items-center justify-center rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 px-4 py-2 font-semibold text-white transition-colors"
                >
                  홈으로 돌아가기
                </Link>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
