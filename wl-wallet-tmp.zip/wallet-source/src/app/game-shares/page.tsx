'use client';

import { useI18n } from '@/lib/i18n/context';
import WalletHeader from '@/app/_components/WalletHeader';

export default function GameSharesPage() {
  const { t } = useI18n();

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6 text-center py-20">
              <div className="text-6xl mb-6">🎮</div>
              <h1 className="text-3xl font-bold text-white mb-4">
                {t.common.gameShareInvestment || 'Game Share Investment'}
              </h1>
              <p className="text-gray-400 text-lg mb-8">
                게임 지분 투자 상품이 준비 중입니다.<br/>
                게임 수익을 공유받을 수 있는 기회를 놓치지 마세요!
              </p>
              <div className="inline-block px-6 py-3 bg-white/5 rounded-lg border border-white/10 text-gray-300">
                Coming Soon
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}