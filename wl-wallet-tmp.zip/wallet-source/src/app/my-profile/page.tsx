'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n/context';
import { Lock, Copy, Check, Link2, Users } from 'lucide-react';
import WalletHeader from '@/app/_components/WalletHeader';

interface LockupInfo {
  availableNKB: number;
  setting: {
    tokenSymbol: string;
    lockedAmount: number;
    releasedAmount: number;
    remainingAmount: number;
    releaseRatePercent: number;
    lockPeriodMonths: number;
    startDate: string;
    endDate: string;
    nextReleaseAt: string;
    status: string;
  } | null;
  recentReleases: any[];
}

interface UserInfo {
  id: string;
  username: string;
  email: string;
  walletAddress?: string;
  rank: number;
  personalCoin: number;
  totalInvestment: number;
  status: string;
  isActive: boolean;
  createdAt: string;
  referralCode?: string;
}

export default function MyProfilePage() {
  const { t, language } = useI18n();
  const router = useRouter();
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [lockupInfo, setLockupInfo] = useState<LockupInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const referralLink = userInfo?.referralCode
    ? `${typeof window !== 'undefined' ? window.location.origin : ''}/register?ref=${userInfo.referralCode}`
    : '';

  useEffect(() => {
    fetchUserInfo();
    fetchLockupInfo();
  }, []);

  const fetchLockupInfo = async () => {
    try {
      const response = await fetch('/api/user/lockup/status', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.data) {
          setLockupInfo(data.data);
        }
      }
    } catch (error) {
      console.error('Failed to fetch lockup info:', error);
    }
  };

  const fetchUserInfo = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include'
      });

      if (!response.ok) {
        router.push('/login');
        return;
      }

      const data = await response.json();
      if (data.ok && data.data) {
        setUserInfo(data.data.users);
      }
    } catch (error) {
      if (process.env.NODE_ENV === 'development') {
        console.error('Failed to fetch user info:', error);
      }
      router.push('/login');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      router.push('/');
      router.refresh();
    } catch (error) {
      if (process.env.NODE_ENV === 'development') {
        console.error('Logout failed:', error);
      }
    }
  };

  const copyToClipboard = async (text: string, type: 'code' | 'link') => {
    try {
      await navigator.clipboard.writeText(text);
      if (type === 'code') {
        setCopiedCode(true);
        setTimeout(() => setCopiedCode(false), 2000);
      } else {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2000);
      }
    } catch {
      // clipboard failed
    }
  };

  const formatNumber = (num: number) => {
    return num.toLocaleString('ko-KR');
  };

  const formatCurrency = (amount: number) => {
    return `${formatNumber(amount)} MSUO`;
  };

  const formatDate = (dateString: string | Date | undefined | null) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '-';
    return date.toLocaleDateString('ko-KR');
  };

  const getRankBadge = (rank: number) => {
    const rankConfig: Record<number, { label: string; className: string }> = {
      1: { label: 'Bronze', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' },
      2: { label: 'Silver', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      3: { label: 'Gold', className: 'bg-blue-500/20 text-blue-400 border border-blue-500/50' },
      4: { label: 'Platinum', className: 'bg-purple-500/20 text-purple-400 border border-purple-500/50' },
      5: { label: 'Diamond', className: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' },
    };

    const config = rankConfig[rank] || rankConfig[1];

    return (
      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${config.className}`}>
        {config.label}
      </span>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
      </div>
    );
  }

  if (!userInfo) {
    return null;
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1">
            <WalletHeader />

            <main className="flex-1 p-2 sm:p-4 md:p-6">
              <div className="flex flex-wrap justify-between gap-4 items-center py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    {t.profile.title}
                  </p>
                  <p className="text-gray-400 text-base font-normal leading-normal">
                    {t.profile.subtitle}
                  </p>
                </div>

                <div className="flex gap-2">
                  <Link
                    href="/transactions"
                    className="px-4 py-2 bg-white/10 border border-white/20 text-white rounded-lg hover:bg-white/20 transition-colors"
                  >
                    {t.profile.transactionHistory}
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="px-4 py-2 bg-red-500/20 border border-red-500/50 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                  >
                    {t.profile.logout}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  {/* Basic Info */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <h3 className="text-xl font-semibold text-white mb-4">{t.profile.basicInfo}</h3>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-gray-400">{t.profile.username}</label>
                          <p className="text-white font-medium">{userInfo.username}</p>
                        </div>
                        <div>
                          <label className="text-sm text-gray-400">{t.profile.email}</label>
                          <p className="text-white font-medium">{userInfo.email}</p>
                        </div>
                        <div>
                          <label className="text-sm text-gray-400">{t.profile.rank}</label>
                          <div className="mt-1">{getRankBadge(userInfo.rank)}</div>
                        </div>
                        <div>
                          <label className="text-sm text-gray-400">{t.profile.joinDate}</label>
                          <p className="text-white font-medium">{formatDate(userInfo.createdAt)}</p>
                        </div>
                      </div>

                      {userInfo.walletAddress && (
                        <div>
                          <label className="text-sm text-gray-400">{t.profile.walletAddr}</label>
                          <p className="text-white font-mono text-sm bg-black/30 p-2 rounded mt-1 break-all">
                            {userInfo.walletAddress}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Referral Link */}
                  <div className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-xl p-6">
                    <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                      <Users className="w-5 h-5 text-blue-400" />
                      {t.referral.title}
                    </h3>

                    {userInfo.referralCode ? (
                      <div className="space-y-4">
                        {/* Referral Code */}
                        <div className="bg-black/20 rounded-lg p-4">
                          <label className="text-sm text-gray-400 mb-2 block">{t.referral.myCode}</label>
                          <div className="flex items-center gap-3">
                            <code className="flex-1 text-xl font-bold text-blue-400 bg-black/40 px-4 py-2 rounded-lg tracking-widest">
                              {userInfo.referralCode}
                            </code>
                            <button
                              onClick={() => copyToClipboard(userInfo.referralCode!, 'code')}
                              className="p-3 rounded-lg bg-blue-500/20 border border-blue-500/30 hover:bg-blue-500/30 transition-colors"
                            >
                              {copiedCode ? (
                                <Check className="w-5 h-5 text-green-400" />
                              ) : (
                                <Copy className="w-5 h-5 text-blue-400" />
                              )}
                            </button>
                          </div>
                        </div>

                        {/* Referral Link */}
                        <div className="bg-black/20 rounded-lg p-4">
                          <label className="text-sm text-gray-400 mb-2 block">{t.referral.myLink}</label>
                          <div className="flex items-center gap-3">
                            <code className="flex-1 text-sm text-gray-300 bg-black/40 px-4 py-2 rounded-lg break-all">
                              {referralLink}
                            </code>
                            <button
                              onClick={() => copyToClipboard(referralLink, 'link')}
                              className="p-3 rounded-lg bg-purple-500/20 border border-purple-500/30 hover:bg-purple-500/30 transition-colors flex-shrink-0"
                            >
                              {copiedLink ? (
                                <Check className="w-5 h-5 text-green-400" />
                              ) : (
                                <Link2 className="w-5 h-5 text-purple-400" />
                              )}
                            </button>
                          </div>
                        </div>

                        <p className="text-sm text-gray-400">{t.referral.shareDesc}</p>
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500">{t.referral.noCode}</p>
                    )}
                  </div>

                  {/* Assets */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <h3 className="text-xl font-semibold text-white mb-4">{t.profile.assets}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-black/20 p-4 rounded-lg">
                        <label className="text-sm text-gray-400">{t.profile.msuoBalance}</label>
                        <p className="text-2xl font-bold text-white mt-1">
                          {formatCurrency(userInfo.personalCoin)}
                        </p>
                      </div>
                      <div className="bg-black/20 p-4 rounded-lg">
                        <label className="text-sm text-gray-400">{t.profile.totalInvestment}</label>
                        <p className="text-2xl font-bold text-white mt-1">
                          {formatCurrency(userInfo.totalInvestment)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Lockup */}
                  {lockupInfo?.setting && (
                    <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                      <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                        <Lock className="w-5 h-5 text-yellow-500" />
                        {lockupInfo.setting.tokenSymbol}
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-black/20 p-4 rounded-lg">
                          <p className="text-2xl font-bold text-white mt-1">
                            {formatNumber(lockupInfo.setting.lockedAmount)} {lockupInfo.setting.tokenSymbol}
                          </p>
                        </div>
                        <div className="bg-black/20 p-4 rounded-lg">
                          <p className="text-2xl font-bold text-green-400 mt-1">
                            {formatNumber(lockupInfo.setting.releasedAmount)} {lockupInfo.setting.tokenSymbol}
                          </p>
                        </div>
                        <div className="bg-black/20 p-4 rounded-lg">
                          <p className="text-2xl font-bold text-yellow-400 mt-1">
                            {formatNumber(lockupInfo.setting.remainingAmount)} {lockupInfo.setting.tokenSymbol}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Shortcuts */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <h3 className="text-xl font-semibold text-white mb-4">{t.profile.shortcuts}</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <Link
                        href="/transactions"
                        className="bg-blue-500/20 border border-blue-500/50 text-blue-300 rounded-lg p-4 text-center hover:bg-blue-500/30 transition-colors"
                      >
                        <div className="text-2xl mb-2">📊</div>
                        <div className="text-sm">{t.profile.transactionHistory}</div>
                      </Link>
                      <Link
                        href="/staking"
                        className="bg-green-500/20 border border-green-500/50 text-green-300 rounded-lg p-4 text-center hover:bg-green-500/30 transition-colors"
                      >
                        <div className="text-2xl mb-2">💎</div>
                        <div className="text-sm">{t.common.staking}</div>
                      </Link>
                      <Link
                        href="/games"
                        className="bg-purple-500/20 border border-purple-500/50 text-purple-300 rounded-lg p-4 text-center hover:bg-purple-500/30 transition-colors"
                      >
                        <div className="text-2xl mb-2">🎮</div>
                        <div className="text-sm">{t.common.games}</div>
                      </Link>
                      <Link
                        href="/transfer"
                        className="bg-orange-500/20 border border-orange-500/50 text-orange-300 rounded-lg p-4 text-center hover:bg-orange-500/30 transition-colors"
                      >
                        <div className="text-2xl mb-2">💸</div>
                        <div className="text-sm">{t.wallet.send}</div>
                      </Link>
                    </div>
                  </div>
                </div>

                {/* Sidebar */}
                <aside className="space-y-6">
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-white mb-4">{t.profile.accountStatus}</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">{t.profile.status}</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          userInfo.isActive
                            ? 'bg-green-500/20 text-green-400 border border-green-500/50'
                            : 'bg-red-500/20 text-red-400 border border-red-500/50'
                        }`}>
                          {userInfo.isActive ? t.profile.activeStatus : t.profile.inactiveStatus}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-400">{t.profile.statusDetail}</span>
                        <span className="text-white text-sm">{userInfo.status}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-xl p-6">
                    <h4 className="text-lg font-semibold text-white mb-2">MSUO Coin Foundation</h4>
                    <p className="text-sm text-gray-300 leading-relaxed">
                      {t.referral.shareDesc}
                    </p>
                  </div>
                </aside>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
