'use client';

export default function TestTransferPage() {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-8">
      <div className="text-center text-slate-400">
        <p className="text-xl mb-2">이 페이지는 사용할 수 없습니다.</p>
        <p className="text-sm">테스트는 /transfer 페이지에서 진행해주세요.</p>
      </div>
    </div>
  );
}
