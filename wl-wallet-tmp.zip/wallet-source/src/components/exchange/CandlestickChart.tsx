'use client';

import { useMemo } from 'react';
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

interface CandlestickData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface CandlestickChartProps {
  data: CandlestickData[];
  period: '1m' | '5m' | '15m' | '30m' | '1h' | '4h' | '1d';
  showIndicators?: boolean;
}

interface TooltipPayload {
  payload: {
    time: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    sma5: number;
    sma20: number;
    rsi: number;
  };
}

interface TooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
}

// CustomTooltip을 컴포넌트 외부로 이동하여 렌더링 중 생성 방지
const CustomTooltip = ({ active, payload, showIndicators }: TooltipProps & { showIndicators?: boolean }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-[#1f2937] border border-white/10 rounded-lg p-3 text-white text-xs">
        <p className="font-semibold mb-2">{data.time}</p>
        <div className="space-y-1">
          <p><span className="text-gray-400">시가:</span> <span className="text-white">${data.open.toFixed(8)}</span></p>
          <p><span className="text-gray-400">고가:</span> <span className="text-green-400">${data.high.toFixed(8)}</span></p>
          <p><span className="text-gray-400">저가:</span> <span className="text-red-400">${data.low.toFixed(8)}</span></p>
          <p><span className="text-gray-400">종가:</span> <span className="text-white">${data.close.toFixed(8)}</span></p>
          <p><span className="text-gray-400">거래량:</span> <span className="text-white">{data.volume.toFixed(2)} MSUO</span></p>
          {showIndicators && (
            <>
              <p><span className="text-gray-400">SMA5:</span> <span className="text-blue-400">${data.sma5.toFixed(8)}</span></p>
              <p><span className="text-gray-400">SMA20:</span> <span className="text-yellow-400">${data.sma20.toFixed(8)}</span></p>
              <p><span className="text-gray-400">RSI:</span> <span className={data.rsi > 70 ? 'text-red-400' : data.rsi < 30 ? 'text-green-400' : 'text-white'}>{data.rsi.toFixed(2)}</span></p>
            </>
          )}
        </div>
      </div>
    );
  }
  return null;
};

export default function CandlestickChart({ data, showIndicators = true }: CandlestickChartProps) {
  // 캔들스틱 차트 데이터 변환
  const chartData = useMemo(() => {
    if (!data || data.length === 0) {
      return [];
    }

    return data.map((item, index) => {
      const isUp = item.close >= item.open;
      const bodyTop = Math.max(item.open, item.close);
      const bodyBottom = Math.min(item.open, item.close);
      
      // 이동평균 계산 (SMA 5, 20)
      const sma5 = index >= 4
        ? data.slice(index - 4, index + 1).reduce((sum, d) => sum + d.close, 0) / 5
        : item.close;
      const sma20 = index >= 19
        ? data.slice(index - 19, index + 1).reduce((sum, d) => sum + d.close, 0) / 20
        : item.close;
      
      // RSI 계산 (14기간)
      const rsiPeriod = 14;
      let rsi = 50;
      if (index >= rsiPeriod) {
        const rsiData = data.slice(index - rsiPeriod, index + 1);
        const gains = rsiData.slice(1).map((d, i) => Math.max(0, d.close - rsiData[i].close));
        const losses = rsiData.slice(1).map((d, i) => Math.max(0, rsiData[i].close - d.close));
        const avgGain = gains.reduce((a, b) => a + b, 0) / gains.length;
        const avgLoss = losses.reduce((a, b) => a + b, 0) / losses.length;
        if (avgLoss !== 0) {
          const rs = avgGain / avgLoss;
          rsi = 100 - (100 / (1 + rs));
        }
      }
      
      return {
        time: item.time,
        open: item.open,
        high: item.high,
        low: item.low,
        close: item.close,
        volume: item.volume,
        bodyTop,
        bodyBottom,
        bodyHeight: Math.abs(item.close - item.open),
        isUp,
        sma5,
        sma20,
        rsi,
      };
    });
  }, [data]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-[#1f2937] border border-white/10 rounded-lg p-3 text-white text-xs">
          <p className="font-semibold mb-2">{data.time}</p>
          <div className="space-y-1">
            <p><span className="text-gray-400">시가:</span> <span className="text-white">${data.open.toFixed(8)}</span></p>
            <p><span className="text-gray-400">고가:</span> <span className="text-green-400">${data.high.toFixed(8)}</span></p>
            <p><span className="text-gray-400">저가:</span> <span className="text-red-400">${data.low.toFixed(8)}</span></p>
            <p><span className="text-gray-400">종가:</span> <span className="text-white">${data.close.toFixed(8)}</span></p>
            <p><span className="text-gray-400">거래량:</span> <span className="text-white">{data.volume.toFixed(2)} AO</span></p>
            {showIndicators && (
              <>
                <p><span className="text-gray-400">SMA5:</span> <span className="text-blue-400">${data.sma5.toFixed(8)}</span></p>
                <p><span className="text-gray-400">SMA20:</span> <span className="text-yellow-400">${data.sma20.toFixed(8)}</span></p>
                <p><span className="text-gray-400">RSI:</span> <span className={data.rsi > 70 ? 'text-red-400' : data.rsi < 30 ? 'text-green-400' : 'text-white'}>{data.rsi.toFixed(2)}</span></p>
              </>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  if (!chartData || chartData.length === 0) {
    return (
      <div className="w-full h-full flex items-center justify-center text-gray-400">
        차트 데이터가 없습니다.
      </div>
    );
  }

  return (
    <div className="w-full h-full">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
          <XAxis 
            dataKey="time" 
            stroke="#9CA3AF" 
            tick={{ fill: '#9CA3AF', fontSize: 10 }}
            interval="preserveStartEnd"
          />
          <YAxis 
            yAxisId="price"
            orientation="left"
            stroke="#9CA3AF" 
            tick={{ fill: '#9CA3AF', fontSize: 10 }}
            domain={['auto', 'auto']}
            tickFormatter={(value) => `$${value.toFixed(6)}`}
          />
          <YAxis 
            yAxisId="volume"
            orientation="right"
            stroke="#6B7280" 
            tick={{ fill: '#6B7280', fontSize: 10 }}
            tickFormatter={(value) => `${(value / 1000).toFixed(1)}K`}
          />
          <Tooltip content={(props) => <CustomTooltip {...props} showIndicators={showIndicators} />} />
          
          {/* 캔들스틱 바디 (시가-종가) - Bar로 표시 */}
          <Bar
            yAxisId="price"
            dataKey="bodyTop"
            fill="#10B981"
            opacity={0.8}
          >
            {chartData.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={entry.isUp ? '#10B981' : '#EF4444'}
              />
            ))}
          </Bar>
          
          {/* 고가-저가 범위를 Line으로 표시 */}
          <Line
            yAxisId="price"
            type="monotone"
            dataKey="high"
            stroke="#6B7280"
            strokeWidth={1}
            dot={false}
            activeDot={false}
            connectNulls
          />
          <Line
            yAxisId="price"
            type="monotone"
            dataKey="low"
            stroke="#6B7280"
            strokeWidth={1}
            dot={false}
            activeDot={false}
            connectNulls
          />
          
          {/* 이동평균선 */}
          {showIndicators && (
            <>
              <Line
                yAxisId="price"
                type="monotone"
                dataKey="sma5"
                stroke="#3B82F6"
                strokeWidth={1.5}
                dot={false}
                name="SMA5"
                connectNulls
              />
              <Line
                yAxisId="price"
                type="monotone"
                dataKey="sma20"
                stroke="#F59E0B"
                strokeWidth={1.5}
                dot={false}
                name="SMA20"
                connectNulls
              />
            </>
          )}
          
          {/* 거래량 바 */}
          <Bar
            yAxisId="volume"
            dataKey="volume"
            fill="#374151"
            opacity={0.3}
            name="Volume"
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
