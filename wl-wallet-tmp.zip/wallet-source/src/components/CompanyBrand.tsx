import type { ImgHTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

interface CompanyBrandProps extends ImgHTMLAttributes<HTMLImageElement> {
  size?: number;
  text?: string;
  showText?: boolean;
  wrapperClassName?: string;
  textClassName?: string;
  imageClassName?: string;
}

export function CompanyBrand({
  size = 48,
  text = 'MSUO',
  showText = true,
  wrapperClassName,
  textClassName = 'text-base font-bold tracking-tight text-white',
  imageClassName,
  ...imageProps
}: CompanyBrandProps) {
  const {
    className: imgClassName,
    style: imgStyle,
    src: customSrc,
    alt: customAlt,
    ...restImageProps
  } = imageProps;

  return (
    <div className={cn('flex items-center gap-2', wrapperClassName)}>
      <img
        {...restImageProps}
        src={customSrc ?? '/icons/logo.jpg'}
        alt={customAlt ?? `${text} Logo`}
        width={size}
        height={size}
        className={cn('object-cover shrink-0 rounded-full', imageClassName, imgClassName)}
        style={{
          width: size,
          height: size,
          ...(imgStyle || {}),
        }}
      />
      {showText && (
        <span className={cn('font-bold tracking-tight text-white whitespace-nowrap', textClassName)}>
          {text}
        </span>
      )}
    </div>
  );
}

export default CompanyBrand;

