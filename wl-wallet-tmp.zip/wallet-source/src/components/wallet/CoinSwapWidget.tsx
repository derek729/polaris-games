'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { ArrowLeftRight, RefreshCw, AlertCircle } from 'lucide-react';

const MSUP_PER_MSUO = 10;

interface CoinSwapWidgetProps {
  msuoBalance: number;
  onSwapSuccess?: () => void;
}

export default function CoinSwapWidget({ msuoBalance, onSwapSuccess }: CoinSwapWidgetProps) {
  const { t } = useI18n();
  const [swapFrom, setSwapFrom] = useState<'MSUO' | 'MSUP'>('MSUO');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const swapTo = swapFrom === 'MSUO' ? 'MSUP' : 'MSUO';

  const msupBalance = msuoBalance * MSUP_PER_MSUO;
  const currentBalance = swapFrom === 'MSUO' ? msuoBalance : msupBalance;

  const calculateReceived = () => {
    if (!amount) return null;
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) return null;
    return swapFrom === 'MSUO'
      ? num * MSUP_PER_MSUO
      : num / MSUP_PER_MSUO;
  };

  const handleSwap = async () => {
    const num = parseFloat(amount);
    if (!num || num <= 0) { setError(t.wallet.invalidAmount || 'Enter a valid amount'); return; }
    if (num > currentBalance) { setError(t.wallet.insufficientBalance || 'Insufficient balance'); return; }
    if (swapFrom === 'MSUP' && num < MSUP_PER_MSUO) {
      setError(`MSUP→MSUO ${t.wallet.minAmount || 'minimum'}: ${MSUP_PER_MSUO} MSUP`);
      return;
    }

    setLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await fetch('/api/user/exchange/swap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ from: swapFrom, to: swapTo, amount: num }),
      });
      const data = await res.json();
      if (data.ok) {
        setSuccessMsg(`${num.toLocaleString()} ${swapFrom} → ${data.data.receiveAmount.toLocaleString()} ${swapTo}`);
        setAmount('');
        if (onSwapSuccess) onSwapSuccess();
      } else {
        setError(data.error || 'Swap failed');
      }
    } catch {
      setError(t.errors.networkError);
    } finally {
      setLoading(false);
    }
  };

  const receivedAmount = calculateReceived();

  const handleFlip = () => {
    setSwapFrom(prev => prev === 'MSUO' ? 'MSUP' : 'MSUO');
    setAmount('');
    setError(null);
    setSuccessMsg(null);
  };

  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-white">{t.wallet.coinSwap || 'MSUO ↔ MSUP Swap'}</h2>
        <button
          onClick={handleFlip}
          className="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center transition-colors"
        >
          <ArrowLeftRight className="w-5 h-5" />
        </button>
      </div>

      {/* Rate */}
      <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 mb-4 text-center">
        <div className="text-xs text-gray-400">{t.wallet.swapRate || 'Exchange Rate'}</div>
        <div className="text-blue-400 font-bold">1 MSUO = {MSUP_PER_MSUO} MSUP</div>
      </div>

      <div className="space-y-4">
        {/* From */}
        <div>
          <label className="block text-sm text-gray-400 mb-1">
            {swapFrom === 'MSUO'
              ? (t.wallet.sendMsuo || 'MSUO to swap')
              : (t.wallet.sendMsup || 'MSUP to swap')}
          </label>
          <div className="relative">
            <input
              type="number"
              value={amount}
              onChange={(e) => { setAmount(e.target.value); setError(null); setSuccessMsg(null); }}
              placeholder="0"
              step={swapFrom === 'MSUO' ? '0.00000001' : '1'}
              min="0"
              className="w-full px-4 py-3 rounded-lg bg-black/30 border border-white/10 text-white text-lg focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder-gray-600"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-medium text-gray-400">
              {swapFrom}
            </div>
          </div>
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>{t.wallet.balance || 'Balance'}: {currentBalance.toLocaleString()} {swapFrom}</span>
          </div>
        </div>

        {/* To */}
        <div>
          <label className="block text-sm text-gray-400 mb-1">{t.wallet.willReceive || 'You will receive'}</label>
          <div className="px-4 py-3 rounded-lg bg-black/30 border border-white/10">
            {receivedAmount !== null ? (
              <span className="text-lg font-semibold text-white">
                {swapTo === 'MSUP'
                  ? Math.floor(receivedAmount).toLocaleString()
                  : receivedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 8 })}{' '}
                {swapTo}
              </span>
            ) : (
              <span className="text-gray-500">0</span>
            )}
          </div>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-300 text-sm">
            <AlertCircle className="h-4 w-4" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-green-300 text-sm">
            {successMsg}
          </div>
        )}

        <button
          onClick={handleSwap}
          disabled={loading || !amount || !receivedAmount}
          className="w-full px-6 py-3 bg-gradient-to-r from-[#137fec] to-[#3A4DFF] text-white rounded-lg font-semibold hover:from-[#137fec]/90 hover:to-[#3A4DFF]/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <RefreshCw className="h-5 w-5 animate-spin" />
              {t.common.loading || 'Loading'}...
            </span>
          ) : (
            t.wallet.swapNow || 'Swap Now'
          )}
        </button>
      </div>
    </div>
  );
}
