'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';

interface CreateLockupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  userId?: string;
  username?: string; // If provided, pre-fills the user
}

export default function CreateLockupModal({
  isOpen,
  onClose,
  onSuccess,
  userId: initialUserId,
  username: initialUsername,
}: CreateLockupModalProps) {
  const { language } = useI18n();
  const [loading, setLoading] = useState(false);
  const [searchEmail, setSearchEmail] = useState('');
  const [foundUser, setFoundUser] = useState<{ id: string; username: string; email: string } | null>(
    initialUserId ? { id: initialUserId, username: initialUsername || '', email: '' } : null
  );

  const [formData, setFormData] = useState({
    lockedAmount: '',
    lockPeriodMonths: '12',
    releaseRatePercent: '10',
    tokenSymbol: 'MSUO',
  });

  useEffect(() => {
    if (initialUserId) {
      setFoundUser({ id: initialUserId, username: initialUsername || '', email: '' });
    } else {
      setFoundUser(null);
      setSearchEmail('');
    }
    setFormData({
        lockedAmount: '',
        lockPeriodMonths: '12',
        releaseRatePercent: '10',
        tokenSymbol: 'MSUO',
    });
  }, [isOpen, initialUserId, initialUsername]);

  const handleSearchUser = async () => {
    if (!searchEmail) return;
    try {
      setLoading(true);
      const response = await fetch(`/api/admin/users/search?q=${encodeURIComponent(searchEmail)}`);
      const data = await response.json();
      if (data.ok && data.data && data.data.length > 0) {
        setFoundUser(data.data[0]);
      } else {
        alert(language === 'ko' ? '사용자를 찾을 수 없습니다.' : 'User not found.');
        setFoundUser(null);
      }
    } catch (error) {
      console.error(error);
      alert('Search failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!foundUser) {
        alert(language === 'ko' ? '사용자를 선택해주세요.' : 'Please select a user.');
        return;
    }

    try {
      setLoading(true);
      const response = await fetch('/api/admin/lockup/set', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: foundUser.id,
          lockedAmount: formData.lockedAmount,
          lockPeriodMonths: Number(formData.lockPeriodMonths),
          releaseRatePercent: Number(formData.releaseRatePercent),
          tokenSymbol: formData.tokenSymbol,
        }),
      });

      const data = await response.json();
      if (data.ok) {
        alert(language === 'ko' ? '락업 설정이 완료되었습니다.' : 'Lockup setting saved.');
        onSuccess();
        onClose();
      } else {
        alert(data.error || 'Failed');
      }
    } catch (error) {
      console.error(error);
      alert('Error occurred');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="w-full max-w-md rounded-2xl border border-white/10 bg-[#1e293b] p-6 shadow-xl">
        <h3 className="text-xl font-bold text-white mb-4">
          {language === 'ko' ? '락업 설정 추가' : 'Add Lockup Setting'}
        </h3>

        {!initialUserId && !foundUser && (
           <div className="mb-4">
             <label className="block text-sm text-gray-400 mb-1">
               {language === 'ko' ? '사용자 검색 (이메일)' : 'Search User (Email)'}
             </label>
             <div className="flex gap-2">
               <input
                 type="email"
                 value={searchEmail}
                 onChange={(e) => setSearchEmail(e.target.value)}
                 className="flex-1 px-3 py-2 bg-black/20 border border-white/10 rounded-lg text-white"
                 placeholder="user@example.com"
               />
               <button
                 type="button"
                 onClick={handleSearchUser}
                 disabled={loading}
                 className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
               >
                 {language === 'ko' ? '검색' : 'Search'}
               </button>
             </div>
           </div>
        )}

        {foundUser && (
            <div className="mb-4 p-3 bg-blue-900/30 border border-blue-500/30 rounded-lg">
                <div className="text-sm text-gray-300">{language === 'ko' ? '대상 사용자' : 'Selected User'}</div>
                <div className="font-bold text-white">{foundUser.username}</div>
                <div className="text-xs text-gray-400">{foundUser.email}</div>
                {!initialUserId && (
                    <button 
                        onClick={() => setFoundUser(null)}
                        className="text-xs text-red-400 underline mt-1"
                    >
                        {language === 'ko' ? '취소' : 'Cancel'}
                    </button>
                )}
            </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">
              {language === 'ko' ? '락업 수량 (MSUO)' : 'Lockup Amount (MSUO)'}
            </label>
            <input
              type="number"
              required
              value={formData.lockedAmount}
              onChange={(e) => setFormData({ ...formData, lockedAmount: e.target.value })}
              className="w-full px-3 py-2 bg-black/20 border border-white/10 rounded-lg text-white"
              placeholder="0.00"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-1">
                {language === 'ko' ? '락업 기간 (개월)' : 'Lock Period (Months)'}
              </label>
              <select
                value={formData.lockPeriodMonths}
                onChange={(e) => setFormData({ ...formData, lockPeriodMonths: e.target.value })}
                className="w-full px-3 py-2 bg-black/20 border border-white/10 rounded-lg text-white"
              >
                <option value="3">3 {language === 'ko' ? '개월' : 'Months'}</option>
                <option value="6">6 {language === 'ko' ? '개월' : 'Months'}</option>
                <option value="12">12 {language === 'ko' ? '개월' : 'Months'}</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">
                {language === 'ko' ? '월 해제율 (%)' : 'Monthly Release (%)'}
              </label>
              <input
                type="number"
                required
                min="1"
                max="100"
                value={formData.releaseRatePercent}
                onChange={(e) => setFormData({ ...formData, releaseRatePercent: e.target.value })}
                className="w-full px-3 py-2 bg-black/20 border border-white/10 rounded-lg text-white"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
            >
              {language === 'ko' ? '취소' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={loading || !foundUser}
              className="flex-1 px-4 py-2 bg-[#137fec] hover:bg-[#0f6fd0] text-white rounded-lg font-bold transition-colors disabled:opacity-50"
            >
              {loading ? '...' : (language === 'ko' ? '설정 저장' : 'Save Setting')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}