'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n/context';

interface ChargeUSDTModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  username: string;
  currentBalance?: number;
  onSuccess: () => void;
}

export default function ChargeUSDTModal({
  isOpen,
  onClose,
  userId,
  username,
  currentBalance = 0,
  onSuccess,
}: ChargeUSDTModalProps) {
  const { language } = useI18n();
  const [amount, setAmount] = useState('');
  const [memo, setMemo] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const chargeAmount = parseFloat(amount);
    if (isNaN(chargeAmount) || chargeAmount <= 0) {
      setError(language === 'ko' ? '올바른 금액을 입력해주세요.' : 'Please enter a valid amount.');
      return;
    }

    try {
      setLoading(true);
      const response = await fetch(`/api/admin/users/${userId}/charge-usdt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          amount: chargeAmount,
          memo: memo.trim() || undefined,
        }),
      });

      const result = await response.json();
      if (result.ok) {
        onSuccess();
        onClose();
        setAmount('');
        setMemo('');
      } else {
        setError(result.error || (language === 'ko' ? '충전에 실패했습니다.' : 'Failed to charge.'));
      }
    } catch (err) {
      console.error('MSUO 충전 실패:', err);
      setError(language === 'ko' ? '충전 중 오류가 발생했습니다.' : 'Error occurred while charging.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-[#1e293b] rounded-xl border border-white/10 p-6 w-full max-w-md mx-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-white">
            {language === 'ko' ? 'MSUO 충전' : 'Charge MSUO'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="mb-4 p-3 bg-white/5 rounded-lg border border-white/10">
          <div className="text-sm text-gray-400 mb-1">
            {language === 'ko' ? '회원' : 'User'}
          </div>
          <div className="text-white font-medium">{username}</div>
          {currentBalance !== undefined && (
            <>
              <div className="text-sm text-gray-400 mt-2 mb-1">
                {language === 'ko' ? '현재 잔액' : 'Current Balance'}
              </div>
              <div className="text-white font-medium">
                {currentBalance.toLocaleString('ko-KR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} MSUO
              </div>
            </>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '충전 금액 (MSUO)' : 'Charge Amount (MSUO)'}
            </label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              required
              className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '메모 (선택사항)' : 'Memo (Optional)'}
            </label>
            <textarea
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              placeholder={language === 'ko' ? '충전 사유를 입력하세요...' : 'Enter charge reason...'}
              rows={3}
              className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent resize-none"
            />
          </div>

          {error && (
            <div className="p-3 bg-red-900/20 text-red-200 rounded-lg border border-red-800 text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-700 rounded-lg text-gray-300 hover:bg-white/5 transition-colors"
            >
              {language === 'ko' ? '취소' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-2 bg-[#137fec] text-white rounded-lg font-medium hover:bg-[#0f6bc7] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading
                ? (language === 'ko' ? '충전 중...' : 'Charging...')
                : (language === 'ko' ? '충전하기' : 'Charge')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

