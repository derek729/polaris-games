'use client';

import { useState, useEffect, useRef } from 'react';
import { X, UserPlus, Loader2, Search, Check } from 'lucide-react';

interface CreateUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface Referrer {
  id: string;
  username: string;
  email: string | null;
  rank: number;
}

export default function CreateUserModal({ isOpen, onClose, onSuccess }: CreateUserModalProps) {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    walletAddress: '',
    referrerId: '',
    initialCoins: '',
    rank: '0',
    investmentAmount: '', // 투자 금액
    investment_tiers: '', // 투자 등급
  });
  const [referrers, setReferrers] = useState<Referrer[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingReferrers, setIsLoadingReferrers] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [referrerSearch, setReferrerSearch] = useState('');
  const [showReferrerDropdown, setShowReferrerDropdown] = useState(false);
  const [filteredReferrers, setFilteredReferrers] = useState<Referrer[]>([]);
  const referrerInputRef = useRef<HTMLDivElement>(null);
  const [investmentTiers, setInvestmentTiers] = useState<Array<{
    tier: number;
    minAmount: number;
    maxAmount: number | null;
    dailyRate: number;
    matchingDepth: number;
    label: string;
    description: string;
  }>>([]);
  const [isLoadingTiers, setIsLoadingTiers] = useState(false);

  // 추천인 목록 로드
  useEffect(() => {
    if (isOpen) {
      loadReferrers();
      loadInvestmentTiers();
    }
  }, [isOpen]);

  // 투자 상품 목록 로드
  const loadInvestmentTiers = async () => {
    setIsLoadingTiers(true);
    try {
      const response = await fetch('/api/admin/investment/tiers', {
        credentials: 'include',
      });
      const result = await response.json();
      if (result.ok && result.data) {
        setInvestmentTiers(result.data);
      }
    } catch (error) {
      console.error('투자 상품 목록 로드 실패:', error);
    } finally {
      setIsLoadingTiers(false);
    }
  };

  // 추천인 검색 필터링
  useEffect(() => {
    if (!referrerSearch.trim()) {
      setFilteredReferrers(referrers);
      return;
    }

    const searchLower = referrerSearch.toLowerCase();
    const filtered = referrers.filter((referrer) => {
      const usernameMatch = referrer.username.toLowerCase().includes(searchLower);
      const emailMatch = referrer.email?.toLowerCase().includes(searchLower);
      return usernameMatch || emailMatch;
    });
    setFilteredReferrers(filtered);
  }, [referrerSearch, referrers]);

  // 외부 클릭 시 드롭다운 닫기
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (referrerInputRef.current && !referrerInputRef.current.contains(event.target as Node)) {
        setShowReferrerDropdown(false);
      }
    };

    if (showReferrerDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showReferrerDropdown]);

  const loadReferrers = async () => {
    setIsLoadingReferrers(true);
    try {
      const response = await fetch('/api/admin/users/register', {
        method: 'GET',
        credentials: 'include',
      });
      const result = await response.json();
      if (result.ok && result.data) {
        setReferrers(result.data);
      }
    } catch (error) {
      console.error('추천인 목록 로드 실패:', error);
    } finally {
      setIsLoadingReferrers(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // 유효성 검사
    if (!formData.username || !formData.password) {
      setError('사용자명과 비밀번호는 필수입니다.');
      return;
    }

    if (formData.password.length < 6) {
      setError('비밀번호는 최소 6자 이상이어야 합니다.');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('비밀번호가 일치하지 않습니다.');
      return;
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setError('올바른 이메일 형식이 아닙니다.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/admin/users/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          username: formData.username.trim(),
          email: formData.email.trim() || null,
          password: formData.password,
          walletAddress: formData.walletAddress.trim() || null,
          referrerId: formData.referrerId || null,
          initialCoins: formData.initialCoins ? parseFloat(formData.initialCoins) : 0,
          rank: parseInt(formData.rank),
          investmentAmount: formData.investmentAmount ? parseFloat(formData.investmentAmount) : null,
          investment_tiers: formData.investmentTier ? parseInt(formData.investmentTier) : null,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setError(result.error || '회원 가입에 실패했습니다.');
        return;
      }

      // 성공
      alert('회원이 성공적으로 추가되었습니다.');
      onSuccess();
      handleClose();
    } catch (error: any) {
      console.error('회원 가입 실패:', error);
      setError('회원 가입 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectReferrer = (other_users_users_referrerIdTousers: Referrer) => {
    setFormData({ ...formData, referrerId: referrer.id });
    setReferrerSearch(`${referrer.username}${referrer.email ? ` (${referrer.email})` : ''} - 랭크 ${referrer.rank}`);
    setShowReferrerDropdown(false);
  };

  const handleReferrerSearchChange = (value: string) => {
    setReferrerSearch(value);
    setShowReferrerDropdown(true);
    if (!value) {
      setFormData({ ...formData, referrerId: '' });
    }
  };

  const handleClose = () => {
    setFormData({
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      walletAddress: '',
      referrerId: '',
      initialCoins: '',
      rank: '0',
      investmentAmount: '',
      investment_tiers: '',
    });
    setReferrerSearch('');
    setShowReferrerDropdown(false);
    setError(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
        {/* 헤더 */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-green-500/20 to-blue-500/20 p-2">
              <UserPlus className="h-5 w-5 text-green-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">회원 추가</h2>
              <p className="text-sm text-slate-400">새로운 회원 계정을 생성합니다</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* 에러 메시지 */}
        {error && (
          <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* 폼 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {/* 사용자명 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                사용자명 <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                placeholder="사용자명 입력"
                required
              />
            </div>

            {/* 이메일 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">이메일</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                placeholder="email@example.com (선택사항)"
              />
            </div>

            {/* 비밀번호 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                비밀번호 <span className="text-red-400">*</span>
              </label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                placeholder="최소 6자 이상"
                required
                minLength={6}
              />
            </div>

            {/* 비밀번호 확인 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                비밀번호 확인 <span className="text-red-400">*</span>
              </label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                placeholder="비밀번호 재입력"
                required
                minLength={6}
              />
            </div>

            {/* 지갑 주소 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">지갑 주소</label>
              <input
                type="text"
                value={formData.walletAddress}
                onChange={(e) => setFormData({ ...formData, walletAddress: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                placeholder="지갑 주소 (선택사항)"
              />
            </div>

            {/* 추천인 - 검색 가능한 입력창 */}
            <div ref={referrerInputRef} className="relative">
              <label className="mb-2 block text-sm font-medium text-slate-300">추천인</label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                  <Search className="h-4 w-4" />
                </div>
                <input
                  type="text"
                  value={referrerSearch}
                  onChange={(e) => handleReferrerSearchChange(e.target.value)}
                  onFocus={() => setShowReferrerDropdown(true)}
                  placeholder="사용자명 또는 이메일로 검색..."
                  className="w-full rounded-lg border border-white/10 bg-slate-800/50 pl-10 pr-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                  disabled={isLoadingReferrers}
                />
                {formData.referrerId && (
                  <button
                    type="button"
                    onClick={() => {
                      setFormData({ ...formData, referrerId: '' });
                      setReferrerSearch('');
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-red-400 transition-colors"
                    title="선택 해제"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              
              {/* 드롭다운 리스트 */}
              {showReferrerDropdown && (
                <div className="absolute z-50 mt-1 w-full max-h-60 overflow-auto rounded-lg border border-white/10 bg-slate-800 shadow-xl">
                  {isLoadingReferrers ? (
                    <div className="p-4 text-center text-slate-400">
                      <Loader2 className="h-4 w-4 animate-spin mx-auto mb-2" />
                      <p className="text-sm">로딩 중...</p>
                    </div>
                  ) : filteredReferrers.length === 0 ? (
                    <div className="p-4 text-center text-slate-400 text-sm">
                      {referrerSearch ? '검색 결과가 없습니다.' : '추천인 없음'}
                    </div>
                  ) : (
                    <>
                      {!referrerSearch && (
                        <button
                          type="button"
                          onClick={() => {
                            setFormData({ ...formData, referrerId: '' });
                            setReferrerSearch('');
                            setShowReferrerDropdown(false);
                          }}
                          className={`w-full px-4 py-2.5 text-left text-sm transition-colors ${
                            !formData.referrerId
                              ? 'bg-green-500/20 text-green-400'
                              : 'text-slate-300 hover:bg-slate-700/50'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {!formData.referrerId && <Check className="h-4 w-4" />}
                            <span>추천인 없음</span>
                          </div>
                        </button>
                      )}
                      {filteredReferrers.map((referrer) => (
                        <button
                          key={referrer.id}
                          type="button"
                          onClick={() => handleSelectReferrer(referrer)}
                          className={`w-full px-4 py-2.5 text-left text-sm transition-colors border-t border-white/5 ${
                            formData.referrerId === referrer.id
                              ? 'bg-green-500/20 text-green-400'
                              : 'text-slate-300 hover:bg-slate-700/50'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {formData.referrerId === referrer.id && <Check className="h-4 w-4" />}
                            <div className="flex-1">
                              <div className="font-medium">{referrer.username}</div>
                              {referrer.email && (
                                <div className="text-xs text-slate-400">{referrer.email}</div>
                              )}
                              <div className="text-xs text-slate-500">랭크 {referrer.rank}</div>
                            </div>
                          </div>
                        </button>
                      ))}
                    </>
                  )}
                </div>
              )}
            </div>

            {/* 초기 코인 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">초기 코인 (AO)</label>
              <input
                type="number"
                value={formData.initialCoins}
                onChange={(e) => setFormData({ ...formData, initialCoins: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                placeholder="0"
                min="0"
                step="0.01"
              />
            </div>

            {/* 랭크 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">랭크</label>
              <select
                value={formData.rank}
                onChange={(e) => setFormData({ ...formData, rank: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
              >
                <option value="0">0 - 신입</option>
                <option value="1">1 - 브론즈</option>
                <option value="2">2 - 실버</option>
                <option value="3">3 - 골드</option>
                <option value="4">4 - 플래티넘</option>
                <option value="5">5 - 다이아몬드</option>
              </select>
            </div>
          </div>

          {/* 투자 상품 섹션 */}
          <div className="mt-4 rounded-lg border border-blue-500/30 bg-blue-500/5 p-4">
            <h3 className="mb-3 text-sm font-semibold text-blue-400">투자 상품 (선택사항)</h3>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {/* 투자 등급 선택 */}
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">투자 등급</label>
                <select
                  value={formData.investmentTier}
                  onChange={(e) => {
                    const selectedTier = e.target.value;
                    setFormData({ ...formData, investment_tiers: selectedTier });
                    // 등급 선택 시 최소 금액 자동 입력
                    if (selectedTier) {
                      const tier = investmentTiers.find(t => t.tier === parseInt(selectedTier));
                      if (tier) {
                        setFormData(prev => ({ ...prev, investmentAmount: tier.minAmount.toString() }));
                      }
                    }
                  }}
                  className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                  disabled={isLoadingTiers}
                >
                  <option value="">투자 등급 선택 안함</option>
                  {investmentTiers.map((tier) => (
                    <option key={tier.tier} value={tier.tier.toString()}>
                      {tier.label} - {tier.description}
                    </option>
                  ))}
                </select>
                {formData.investmentTier && (
                  <p className="mt-1 text-xs text-slate-400">
                    {(() => {
                      const tier = investmentTiers.find(t => t.tier === parseInt(formData.investmentTier));
                      return tier ? `일일 수익률: ${(tier.dailyRate * 100).toFixed(2)}%, 매칭 깊이: ${tier.matchingDepth}대` : '';
                    })()}
                  </p>
                )}
              </div>

              {/* 투자 금액 */}
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">투자 금액 ($)</label>
                <input
                  type="number"
                  value={formData.investmentAmount}
                  onChange={(e) => {
                    const amount = e.target.value;
                    setFormData({ ...formData, investmentAmount: amount });
                    // 금액 입력 시 자동으로 등급 계산
                    if (amount) {
                      const amountNum = parseFloat(amount);
                      const tier = investmentTiers.find(t => 
                        amountNum >= t.minAmount && (t.maxAmount === null || amountNum <= t.maxAmount)
                      );
                      if (tier) {
                        setFormData(prev => ({ ...prev, investment_tiers: tier.tier.toString() }));
                      }
                    }
                  }}
                  className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                  placeholder="최소 $50"
                  min="50"
                  step="1"
                  disabled={isLoadingTiers}
                />
                {formData.investmentTier && formData.investmentAmount && (
                  <p className="mt-1 text-xs text-slate-400">
                    {(() => {
                      const tier = investmentTiers.find(t => t.tier === parseInt(formData.investmentTier));
                      const amount = parseFloat(formData.investmentAmount);
                      if (tier && amount) {
                        const dailyEarning = amount * tier.dailyRate;
                        return `예상 일일 수익: $${dailyEarning.toFixed(2)}`;
                      }
                      return '';
                    })()}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* 버튼 */}
          <div className="mt-6 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="rounded-lg border border-white/10 bg-slate-800/50 px-5 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-green-500 to-blue-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-green-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-green-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  생성 중...
                </>
              ) : (
                <>
                  <UserPlus className="h-4 w-4" />
                  회원 추가
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

