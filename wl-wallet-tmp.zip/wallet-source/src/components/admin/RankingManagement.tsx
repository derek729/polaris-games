'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { RANK_TIERS, formatRankInfo } from '@/lib/ranking-system';

interface RankStatistics {
  totalUsers: number;
  rankDistribution: Array<{
    rank: number;
    name: string;
    count: number;
    percentage: number;
    color: string;
    minStaking: number;
    maxStaking: number;
    minStakingFormatted: string;
    maxStakingFormatted: string;
    benefits: string[];
  }>;
}

interface StakingPoolStatus {
  totalStaking: number;
  activeStakingCount: number;
  targetPoolSize: number;
  utilizationRate: number;
  remainingCapacity: number;
  averageStakingPerUser: number;
}

export default function RankingManagement() {
  const { t, language } = useI18n();
  const [statistics, setStatistics] = useState<RankStatistics | null>(null);
  const [stakingPoolStatus, setStakingPoolStatus] = useState<StakingPoolStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateResult, setUpdateResult] = useState<any>(null);
  const [selectedRank, setSelectedRank] = useState<number | null>(null);
  const [rankUsers, setRankUsers] = useState<any[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);

  // 랭크 통계 조회
  const fetchRankStatistics = async () => {
    try {
      const response = await fetch('/api/admin/ranking/statistics');
      const result = await response.json();

      if (result.ok) {
        setStatistics(result.data.rankStatistics);
        setStakingPoolStatus(result.data.stakingPoolStatus);
      } else {
        console.error('랭크 통계 조회 실패:', result.error);
      }
    } catch (error) {
      console.error('랭크 통계 조회 오류:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // 랭크 업데이트 실행
  const handleRankUpdate = async () => {
    if (!confirm('모든 사용자의 랭크를 스테이킹 양에 따라 업데이트하시겠습니까?')) {
      return;
    }

    setIsUpdating(true);
    try {
      const response = await fetch('/api/admin/ranking/update', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const result = await response.json();

      if (result.ok) {
        setUpdateResult(result.data);
        // 업데이트 후 통계 다시 조회
        await fetchRankStatistics();
      } else {
        alert(`랭크 업데이트 실패: ${result.error}`);
      }
    } catch (error) {
      console.error('랭크 업데이트 오류:', error);
      alert('랭크 업데이트 중 오류가 발생했습니다.');
    } finally {
      setIsUpdating(false);
    }
  };

  // 특정 랭크 사용자 조회
  const fetchRankUsers = async (rankLevel: number) => {
    setIsLoadingUsers(true);
    try {
      const response = await fetch(`/api/admin/ranking/users?rank=${rankLevel}&limit=20`);
      const result = await response.json();

      if (result.ok) {
        setRankUsers(result.data.users);
        setSelectedRank(rankLevel);
      } else {
        console.error('랭크 사용자 조회 실패:', result.error);
        alert('랭크 사용자 조회에 실패했습니다.');
      }
    } catch (error) {
      console.error('랭크 사용자 조회 오류:', error);
      alert('랭크 사용자 조회 중 오류가 발생했습니다.');
    } finally {
      setIsLoadingUsers(false);
    }
  };

  useEffect(() => {
    fetchRankStatistics();
  }, []);

  // 숫자 포맷팅
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(Math.floor(num));
  };

  // 억 단위 포맷팅
  const formatBillion = (num: number) => {
    const billions = num / 100000000;
    return `${billions.toFixed(1)}억`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
        <span className="ml-3 text-white">랭킹 데이터를 불러오는 중...</span>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* 페이지 헤더 */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">
            {language === 'ko' ? '랭킹 관리' : 'Ranking Management'}
          </h2>
          <p className="text-gray-400 text-sm">
            {language === 'ko'
              ? '스테이킹 양에 따른 1성-10성 랭크 시스템 관리'
              : 'Manage 1-10 star ranking system based on staking amount'}
          </p>
        </div>
        <button
          onClick={handleRankUpdate}
          disabled={isUpdating}
          className="px-6 py-3 bg-[#137fec] hover:bg-[#137fec]/90 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
        >
          {isUpdating ? (
            <>
              <span className="material-symbols-outlined animate-spin">refresh</span>
              <span>{language === 'ko' ? '업데이트 중...' : 'Updating...'}</span>
            </>
          ) : (
            <>
              <span className="material-symbols-outlined">update</span>
              <span>{language === 'ko' ? '랭크 업데이트' : 'Update Ranks'}</span>
            </>
          )}
        </button>
      </div>

      {/* 스테이킹 풀 현황 */}
      {stakingPoolStatus && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">
                {language === 'ko' ? '총 스테이킹' : 'Total Staking'}
              </span>
              <span className="material-symbols-outlined text-blue-400">account_balance</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {formatBillion(stakingPoolStatus.totalStaking)} MSUO
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {stakingPoolStatus.activeStakingCount.toLocaleString()} {language === 'ko' ? '건' : 'records'}
            </div>
          </div>

          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">
                {language === 'ko' ? '목표 크기' : 'Target Size'}
              </span>
              <span className="material-symbols-outlined text-green-400">trending_up</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {formatBillion(stakingPoolStatus.targetPoolSize)} MSUO
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {language === 'ko' ? '전체 풀' : 'Full Pool'}
            </div>
          </div>

          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">
                {language === 'ko' ? '이용률' : 'Utilization Rate'}
              </span>
              <span className="material-symbols-outlined text-purple-400">pie_chart</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {stakingPoolStatus.utilizationRate.toFixed(1)}%
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {language === 'ko' ? '풀 점유율' : 'Pool Occupancy'}
            </div>
          </div>

          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">
                {language === 'ko' ? '평균 스테이킹' : 'Average Staking'}
              </span>
              <span className="material-symbols-outlined text-orange-400">bar_chart</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {formatBillion(stakingPoolStatus.averageStakingPerUser)} MSUO
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {language === 'ko' ? '사용자당 평균' : 'Per User'}
            </div>
          </div>
        </div>
      )}

      {/* 랭크 분포 */}
      {statistics && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-6">
            {language === 'ko' ? '랭크별 분포' : 'Rank Distribution'}
          </h3>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 그래프 영역 */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-gray-400 mb-4">
                {language === 'ko' ? '사용자 수' : 'User Count'}
              </h4>
              {statistics.rankDistribution
                .filter(rank => rank.count > 0)
                .sort((a, b) => b.count - a.count)
                .map(rank => (
                  <div key={rank.rank} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-4 h-4 rounded"
                          style={{ backgroundColor: rank.color }}
                        />
                        <span className="text-sm font-medium text-white">
                          {rank.name}
                        </span>
                        <span className="text-xs text-gray-400">
                          ({rank.minStakingFormatted}~{rank.maxStakingFormatted})
                        </span>
                      </div>
                      <span className="text-sm text-white font-bold">
                        {rank.count.toLocaleString()} ({rank.percentage.toFixed(1)}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all duration-500"
                        style={{
                          backgroundColor: rank.color,
                          width: `${(rank.count / statistics.totalUsers) * 100}%`
                        }}
                      />
                    </div>
                  </div>
                ))
              }
            </div>

            {/* 랭크 상세 정보 */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-gray-400 mb-4">
                {language === 'ko' ? '랭크 상세 정보' : 'Rank Details'}
              </h4>
              {statistics.rankDistribution.map(rank => (
                <div
                  key={rank.rank}
                  className="flex justify-between items-center p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                  onClick={() => fetchRankUsers(rank.rank)}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: rank.color }}
                    />
                    <div>
                      <span className="text-sm font-medium text-white">{rank.name}</span>
                      <div className="text-xs text-gray-400">
                        {rank.minStakingFormatted}~{rank.maxStakingFormatted}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-white">
                      {rank.count.toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-400">
                      {rank.percentage.toFixed(1)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 특정 랭크 사용자 목록 */}
      {selectedRank && rankUsers.length > 0 && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-semibold text-white">
              {language === 'ko' ? `${selectedRank}성 사용자` : `${selectedRank} Star Users`}
            </h3>
            <button
              onClick={() => setSelectedRank(null)}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <span className="material-symbols-outlined">close</span>
            </button>
          </div>

          {isLoadingUsers ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#137fec]"></div>
              <span className="ml-3 text-white">
                {language === 'ko' ? '사용자 목록을 불러오는 중...' : 'Loading users...'}
              </span>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-gray-300">
                <thead className="text-xs text-gray-400 uppercase bg-gray-800">
                  <tr>
                    <th className="px-4 py-3">
                      {language === 'ko' ? '사용자명' : 'Username'}
                    </th>
                    <th className="px-4 py-3">
                      {language === 'ko' ? '스테이킹 양' : 'Staking Amount'}
                    </th>
                    <th className="px-4 py-3">
                      {language === 'ko' ? '활성 스테이킹' : 'Active Staking'}
                    </th>
                    <th className="px-4 py-3">
                      {language === 'ko' ? '가입일' : 'Joined Date'}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rankUsers.map((user) => (
                    <tr key={user.id} className="border-b border-gray-700 hover:bg-white/5">
                      <td className="px-4 py-3 font-medium text-white">
                        {user.username || user.email || 'Unknown'}
                      </td>
                      <td className="px-4 py-3">
                        {formatBillion(user.totalStaking)} MSUO
                      </td>
                      <td className="px-4 py-3">
                        {user.activeStakingCount}
                      </td>
                      <td className="px-4 py-3">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* 업데이트 결과 */}
      {updateResult && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">
            {language === 'ko' ? '최신 업데이트 결과' : 'Latest Update Results'}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-green-900/20 border border-green-500/30 rounded-lg">
              <div className="text-2xl font-bold text-green-400">
                {updateResult.summary.rankChanges.upgraded}
              </div>
              <div className="text-sm text-green-300">
                {language === 'ko' ? '승급' : 'Upgraded'}
              </div>
            </div>

            <div className="text-center p-4 bg-red-900/20 border border-red-500/30 rounded-lg">
              <div className="text-2xl font-bold text-red-400">
                {updateResult.summary.rankChanges.downgraded}
              </div>
              <div className="text-sm text-red-300">
                {language === 'ko' ? '하락' : 'Downgraded'}
              </div>
            </div>

            <div className="text-center p-4 bg-blue-900/20 border border-blue-500/30 rounded-lg">
              <div className="text-2xl font-bold text-blue-400">
                {updateResult.summary.rankChanges.same}
              </div>
              <div className="text-sm text-blue-300">
                {language === 'ko' ? '유지' : 'Same'}
              </div>
            </div>
          </div>

          <button
            onClick={() => setUpdateResult(null)}
            className="text-gray-400 hover:text-white transition-colors text-sm"
          >
            {language === 'ko' ? '결과 닫기' : 'Close Results'}
          </button>
        </div>
      )}
    </div>
  );
}