'use client';

import { useState, useEffect, useCallback } from 'react';

interface WithdrawalRequest {
  id: string;
  userId: string;
  username: string;
  email: string;
  walletAddress?: string;
  userRank: number;
  userBalance: number;
  amount: number;
  address: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  requestedAt: string;
  processedAt?: string;
}

interface Statistics {
  totalRequests: number;
  totalRequested: number;
  statusDistribution: Array<{
    status: string;
    count: number;
    amount: number;
    percentage: number;
  }>;
  topAmountRequests: Array<{
    id: string;
    amount: number;
    username: string;
    userRank: number;
  }>;
  averageAmount: number;
}

interface CampaignData {
  requests: WithdrawalRequest[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
  statistics: Statistics;
}

export default function CampaignManagement() {
  const [campaignData, setCampaignData] = useState<CampaignData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedRequests, setSelectedRequests] = useState<string[]>([]);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [showBatchApprove, setShowBatchApprove] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  // 필터링 상태
  const [filters, setFilters] = useState({
    status: 'all',
    search: '',
    startDate: '',
    endDate: '',
    page: 1,
    limit: 20
  });

  // 캠페인 데이터 조회
  const fetchCampaignData = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value && value !== 'all') {
          params.append(key, value.toString());
        }
      });

      const response = await fetch(`/api/admin/withdraw/requests?${params}`, {
        credentials: 'include',
      });

      const data = await response.json();

      if (data.ok && data.data) {
        setCampaignData(data.data);
      }
    } catch (error) {
      console.error('캠페인 데이터 조회 실패:', error);
    } finally {
      setIsLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchCampaignData();
  }, [fetchCampaignData]);

  // 포맷 함수들
  const formatNumber = (num: number) => {
    return num.toLocaleString('ko-KR');
  };

  const formatCurrency = (amount: number) => {
    return `${formatNumber(amount)} MSUO`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ko-KR');
  };

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { label: string; className: string }> = {
      PENDING: { label: '대기중', className: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' },
      APPROVED: { label: '승인됨', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      REJECTED: { label: '거절됨', className: 'bg-red-500/20 text-red-400 border border-red-500/50' },
      PROCESSING: { label: '처리중', className: 'bg-blue-500/20 text-blue-400 border border-blue-500/50' },
      COMPLETED: { label: '완료됨', className: 'bg-purple-500/20 text-purple-400 border border-purple-500/50' },
      FAILED: { label: '실패', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' },
    };

    const config = statusConfig[status] || statusConfig.PENDING;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    );
  };

  const getRankBadge = (rank: number) => {
    const rankConfig: Record<number, { label: string; className: string }> = {
      1: { label: '브론즈', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' },
      2: { label: '실버', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      3: { label: '골드', className: 'bg-blue-500/20 text-blue-400 border border-blue-500/50' },
      4: { label: '플래티넘', className: 'bg-purple-500/20 text-purple-400 border border-purple-500/50' },
      5: { label: '다이아몬드', className: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' },
    };

    const config = rankConfig[rank] || rankConfig[1];

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    );
  };

  // 요청 처리 함수
  const handleRequestAction = async (requestId: string, action: 'APPROVE' | 'REJECT', reason?: string) => {
    setProcessingId(requestId);
    try {
      const response = await fetch('/api/admin/withdraw/approve', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          requestId,
          action,
          reason
        }),
      });

      const data = await response.json();

      if (data.ok) {
        alert(`요청이 ${action === 'APPROVE' ? '승인' : '거절'}되었습니다.`);
        fetchCampaignData();
        setSelectedRequests(prev => prev.filter(id => id !== requestId));
      } else {
        alert(`처리 실패: ${data.error}`);
      }
    } catch (error) {
      console.error('요청 처리 실패:', error);
      alert('처리 중 오류가 발생했습니다.');
    } finally {
      setProcessingId(null);
      setRejectionReason('');
    }
  };

  // 일괄 처리 함수
  const handleBatchAction = async (action: 'APPROVE' | 'REJECT') => {
    if (selectedRequests.length === 0) {
      alert('처리할 요청을 선택해주세요.');
      return;
    }

    setBatchProcessing(true);
    try {
      const response = await fetch('/api/admin/withdraw/approve', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          requestIds: selectedRequests,
          action,
          reason: rejectionReason || undefined
        }),
      });

      const data = await response.json();

      if (data.ok) {
        alert(`${data.data.summary.success}개 요청이 ${action === 'APPROVE' ? '승인' : '거절'}되었습니다.`);
        fetchCampaignData();
        setSelectedRequests([]);
        setShowBatchApprove(false);
        setRejectionReason('');
      } else {
        alert(`처리 실패: ${data.error}`);
      }
    } catch (error) {
      console.error('일괄 처리 실패:', error);
      alert('처리 중 오류가 발생했습니다.');
    } finally {
      setBatchProcessing(false);
    }
  };

  // 선택 관리
  const toggleRequestSelection = (requestId: string) => {
    setSelectedRequests(prev =>
      prev.includes(requestId)
        ? prev.filter(id => id !== requestId)
        : [...prev, requestId]
    );
  };

  const selectAllPending = () => {
    if (campaignData) {
      const pendingIds = campaignData.requests
        .filter(req => req.status === 'PENDING')
        .map(req => req.id);
      setSelectedRequests(pendingIds);
    }
  };

  // 필터 변경 핸들러
  const handleFilterChange = (key: string, value: string | number) => {
    setFilters(prev => ({
      ...prev,
      [key]: value,
      ...(key !== 'page' && { page: 1 })
    }));
  };

  if (isLoading && !campaignData) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">캠페인 관리</h1>
          <p className="text-gray-400 mt-1">
            캠페인 출금 요청 관리 및 통계
          </p>
        </div>
      </div>

      {/* 통계 카드 */}
      {campaignData?.statistics && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">총 요청 수</p>
                <p className="text-2xl font-bold text-white">
                  {formatNumber(campaignData.statistics.totalRequests)}
                </p>
              </div>
              <div className="bg-blue-500/20 p-3 rounded-lg">
                <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">총 요청 금액</p>
                <p className="text-2xl font-bold text-white">
                  {formatCurrency(campaignData.statistics.totalRequested)}
                </p>
              </div>
              <div className="bg-green-500/20 p-3 rounded-lg">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">평균 요청액</p>
                <p className="text-2xl font-bold text-white">
                  {formatCurrency(campaignData.statistics.averageAmount)}
                </p>
              </div>
              <div className="bg-purple-500/20 p-3 rounded-lg">
                <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">대기중 요청</p>
                <p className="text-2xl font-bold text-white">
                  {formatNumber(
                    campaignData.statistics.statusDistribution.find(s => s.status === 'PENDING')?.count || 0
                  )}
                </p>
              </div>
              <div className="bg-yellow-500/20 p-3 rounded-lg">
                <svg className="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 검색 및 필터 */}
      <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-300 mb-2">검색</label>
            <input
              type="text"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              placeholder="사용자명, 이메일, 지갑주소 검색"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">상태</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="all">전체</option>
              <option value="PENDING">대기중</option>
              <option value="APPROVED">승인됨</option>
              <option value="REJECTED">거절됨</option>
              <option value="PROCESSING">처리중</option>
              <option value="COMPLETED">완료됨</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">시작일</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => handleFilterChange('startDate', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">종료일</label>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => handleFilterChange('endDate', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* 일괄 처리 버튼 */}
      {selectedRequests.length > 0 && (
        <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
          <div className="flex items-center justify-between">
            <div className="text-white">
              {selectedRequests.length}개 요청 선택됨
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowBatchApprove(true)}
                className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
              >
                일괄 승인
              </button>
              <button
                onClick={() => setShowBatchApprove(false)}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
              >
                일괄 거절
              </button>
              <button
                onClick={() => setSelectedRequests([])}
                className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
              >
                선택 해제
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 일괄 처리 확인 */}
      {showBatchApprove && selectedRequests.length > 0 && (
        <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
          <h3 className="text-lg font-semibold text-white mb-4">일괄 처리 확인</h3>
          <div className="space-y-4">
            <div className="text-gray-300">
              {showBatchApprove ? '승인' : '거절'}할 요청 {selectedRequests.length}개
            </div>
            <textarea
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="거절 사유 (선택사항)"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              rows={3}
            />
            <div className="flex gap-2">
              <button
                onClick={() => handleBatchAction(showBatchApprove ? 'APPROVE' : 'REJECT')}
                disabled={batchProcessing}
                className={`px-4 py-2 rounded-lg text-white transition-colors disabled:opacity-50 ${
                  showBatchApprove
                    ? 'bg-green-500 hover:bg-green-600'
                    : 'bg-red-500 hover:bg-red-600'
                }`}
              >
                {batchProcessing ? '처리중...' : `${showBatchApprove ? '승인' : '거절'} 실행`}
              </button>
              <button
                onClick={() => {
                  setShowBatchApprove(false);
                  setRejectionReason('');
                }}
                className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
              >
                취소
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 출금 요청 목록 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-white">출금 요청 목록</h3>
            <button
              onClick={selectAllPending}
              className="text-sm text-blue-400 hover:text-blue-300"
            >
              대기중 요청 전체 선택
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-white/10">
            <thead className="bg-white/5">
              <tr>
                <th className="px-4 py-3">
                  <input
                    type="checkbox"
                    onChange={(e) => {
                      if (e.target.checked) {
                        selectAllPending();
                      } else {
                        setSelectedRequests([]);
                      }
                    }}
                    className="rounded bg-white/10 border-white/20 text-[#137fec] focus:ring-[#137fec]"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">사용자</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">랭크</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">잔액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">요청액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">지갑주소</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">상태</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">요청일</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-300 uppercase tracking-wider">작업</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {campaignData?.requests.map((request) => (
                <tr key={request.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-4 py-4">
                    {request.status === 'PENDING' && (
                      <input
                        type="checkbox"
                        checked={selectedRequests.includes(request.id)}
                        onChange={() => toggleRequestSelection(request.id)}
                        className="rounded bg-white/10 border-white/20 text-[#137fec] focus:ring-[#137fec]"
                      />
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-white">{request.username}</div>
                      <div className="text-sm text-gray-400">{request.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">{getRankBadge(request.userRank)}</td>
                  <td className="px-6 py-4 text-sm font-medium text-white">
                    {formatCurrency(request.userBalance)}
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-white">
                    {formatCurrency(request.amount)}
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-xs text-gray-400 truncate max-w-[150px]">
                      {request.address}
                    </div>
                  </td>
                  <td className="px-6 py-4">{getStatusBadge(request.status)}</td>
                  <td className="px-6 py-4 text-sm text-white">
                    {formatDate(request.requestedAt)}
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-medium">
                    {request.status === 'PENDING' && (
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleRequestAction(request.id, 'APPROVE')}
                          disabled={processingId === request.id}
                          className="text-green-400 hover:text-green-300 disabled:opacity-50"
                          title="승인"
                        >
                          {processingId === request.id ? '처리중...' : '승인'}
                        </button>
                        <button
                          onClick={() => {
                            const reason = prompt('거절 사유를 입력하세요:');
                            if (reason !== null) {
                              handleRequestAction(request.id, 'REJECT', reason);
                            }
                          }}
                          disabled={processingId === request.id}
                          className="text-red-400 hover:text-red-300 disabled:opacity-50"
                          title="거절"
                        >
                          거절
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {campaignData?.requests.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-400">요청이 없습니다.</p>
          </div>
        )}
      </div>

      {/* 페이지네이션 */}
      {campaignData?.pagination && campaignData.pagination.totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-400">
            {campaignData.pagination.page} / {campaignData.pagination.totalPages} 페이지
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => handleFilterChange('page', campaignData.pagination.page - 1)}
              disabled={!campaignData.pagination.hasPrev}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              이전
            </button>
            <button
              onClick={() => handleFilterChange('page', campaignData.pagination.page + 1)}
              disabled={!campaignData.pagination.hasNext}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              다음
            </button>
          </div>
        </div>
      )}
    </div>
  );
}