'use client';

import { useState, useEffect } from 'react';
import { X, Mail, Loader2 } from 'lucide-react';

interface UpdateEmailModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  currentEmail: string | null;
  onSuccess: () => void;
}

export default function UpdateEmailModal({
  isOpen,
  onClose,
  userId,
  currentEmail,
  onSuccess,
}: UpdateEmailModalProps) {
  const [newEmail, setNewEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setNewEmail('');
      setError(null);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // 유효성 검사
    if (!newEmail || newEmail.trim().length === 0) {
      setError('이메일을 입력해주세요.');
      return;
    }

    // 이메일 형식 검증
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newEmail.trim())) {
      setError('올바른 이메일 형식이 아닙니다.');
      return;
    }

    if (currentEmail && newEmail.trim().toLowerCase() === currentEmail.toLowerCase()) {
      setError('현재 이메일과 동일합니다.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(`/api/admin/users/${userId}/email`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          email: newEmail.trim(),
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setError(result.error || '이메일 변경에 실패했습니다.');
        return;
      }

      // 성공
      onSuccess();
      handleClose();
    } catch (error: any) {
      console.error('이메일 변경 실패:', error);
      setError('이메일 변경 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setNewEmail('');
    setError(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
        {/* 헤더 */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 p-2">
              <Mail className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">이메일 변경</h2>
              <p className="text-sm text-slate-400">새로운 이메일을 입력해주세요</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* 에러 메시지 */}
        {error && (
          <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* 폼 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium text-slate-300">
              현재 이메일
            </label>
            <input
              type="text"
              value={currentEmail || '(등록되지 않음)'}
              disabled
              className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-slate-400 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-300">
              새 이메일 <span className="text-red-400">*</span>
            </label>
            <input
              type="email"
              value={newEmail}
              onChange={(e) => {
                setNewEmail(e.target.value);
                setError(null);
              }}
              className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              placeholder="example@email.com"
              required
            />
            <p className="mt-2 text-xs text-slate-400">
              • 올바른 이메일 형식을 입력해주세요
            </p>
          </div>

          {/* 버튼 */}
          <div className="mt-6 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="rounded-lg border border-white/10 bg-slate-800/50 px-5 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-blue-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  변경 중...
                </>
              ) : (
                <>
                  <Mail className="h-4 w-4" />
                  변경하기
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

