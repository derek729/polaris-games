'use client';

import { useState } from 'react';
import { X, UserPlus, Loader2 } from 'lucide-react';

interface CreateAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

type UserRole = 'USER' | 'ADMIN' | 'SUPER_ADMIN';

export default function CreateAdminModal({ isOpen, onClose, onSuccess }: CreateAdminModalProps) {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'ADMIN' as UserRole,
    rank: '1',
    initialCoin: '',
    initialInvestment: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // 유효성 검사
    if (!formData.username || !formData.email || !formData.password) {
      setError('사용자명, 이메일, 비밀번호는 필수입니다.');
      return;
    }

    if (formData.password.length < 6) {
      setError('비밀번호는 최소 6자 이상이어야 합니다.');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('비밀번호가 일치하지 않습니다.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/admin/users/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          username: formData.username,
          email: formData.email,
          password: formData.password,
          role: formData.role,
          rank: parseInt(formData.rank),
          initialCoin: formData.initialCoin ? parseFloat(formData.initialCoin) : 0,
          initialInvestment: formData.initialInvestment ? parseFloat(formData.initialInvestment) : 0,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setError(result.error || '관리자 계정 생성에 실패했습니다.');
        return;
      }

      // 성공
      alert('관리자 계정이 성공적으로 생성되었습니다.');
      onSuccess();
      handleClose();
    } catch (error: any) {
      console.error('관리자 계정 생성 실패:', error);
      setError('관리자 계정 생성 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setFormData({
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      role: 'ADMIN',
      rank: '1',
      initialCoin: '',
      initialInvestment: '',
    });
    setError(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
        {/* 헤더 */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 p-2">
              <UserPlus className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">관리자 계정 생성</h2>
              <p className="text-sm text-slate-400">새로운 관리자 계정을 생성합니다</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* 에러 메시지 */}
        {error && (
          <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* 폼 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {/* 사용자명 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">사용자명 *</label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                placeholder="사용자명 입력"
                required
              />
            </div>

            {/* 이메일 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">이메일 *</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                placeholder="email@example.com"
                required
              />
            </div>

            {/* 비밀번호 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">비밀번호 *</label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                placeholder="최소 6자 이상"
                required
                minLength={6}
              />
            </div>

            {/* 비밀번호 확인 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">비밀번호 확인 *</label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                placeholder="비밀번호 재입력"
                required
                minLength={6}
              />
            </div>

            {/* 권한 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">권한 *</label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                required
              >
                <option value="USER">일반 사용자</option>
                <option value="ADMIN">관리자</option>
                <option value="SUPER_ADMIN">슈퍼관리자</option>
              </select>
            </div>

            {/* 랭크 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">랭크</label>
              <select
                value={formData.rank}
                onChange={(e) => setFormData({ ...formData, rank: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              >
                <option value="1">1 - 브론즈</option>
                <option value="2">2 - 실버</option>
                <option value="3">3 - 골드</option>
                <option value="4">4 - 플래티넘</option>
                <option value="5">5 - 다이아몬드</option>
              </select>
            </div>

            {/* 초기 코인 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">초기 코인 (AO)</label>
              <input
                type="number"
                value={formData.initialCoin}
                onChange={(e) => setFormData({ ...formData, initialCoin: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                placeholder="0"
                min="0"
                step="0.01"
              />
            </div>

            {/* 초기 투자 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">초기 투자금 ($)</label>
              <input
                type="number"
                value={formData.initialInvestment}
                onChange={(e) => setFormData({ ...formData, initialInvestment: e.target.value })}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                placeholder="0"
                min="0"
                step="0.01"
              />
            </div>
          </div>

          {/* 버튼 */}
          <div className="mt-6 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="rounded-lg border border-white/10 bg-slate-800/50 px-5 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-blue-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  생성 중...
                </>
              ) : (
                <>
                  <UserPlus className="h-4 w-4" />
                  계정 생성
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

