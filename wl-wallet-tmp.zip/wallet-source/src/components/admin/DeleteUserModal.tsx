'use client';

import { useState } from 'react';
import { X, Trash2, Loader2, AlertTriangle } from 'lucide-react';

interface DeleteUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  username: string;
  onSuccess: () => void;
}

export default function DeleteUserModal({
  isOpen,
  onClose,
  userId,
  username,
  onSuccess,
}: DeleteUserModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmText, setConfirmText] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // 확인 텍스트 검증
    if (confirmText !== '삭제') {
      setError('확인을 위해 "삭제"를 정확히 입력해주세요.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(`/api/admin/users/${userId}/delete`, {
        method: 'DELETE',
        credentials: 'include',
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setError(result.error || '사용자 삭제에 실패했습니다.');
        return;
      }

      // 성공
      onSuccess();
      handleClose();
    } catch (error: any) {
      console.error('사용자 삭제 실패:', error);
      setError('사용자 삭제 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setConfirmText('');
    setError(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-2xl border border-red-500/30 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
        {/* 헤더 */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-red-500/20 to-orange-500/20 p-2">
              <AlertTriangle className="h-5 w-5 text-red-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">사용자 삭제</h2>
              <p className="text-sm text-slate-400">이 작업은 되돌릴 수 없습니다</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* 경고 메시지 */}
        <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-medium text-red-400 mb-2">
                다음 사용자를 삭제하시겠습니까?
              </p>
              <p className="text-sm text-white font-semibold">{username}</p>
              <p className="text-xs text-slate-400 mt-2">
                • 사용자의 모든 데이터가 영구적으로 삭제됩니다<br />
                • 관련된 투자, 보상, 이체 내역 등이 모두 삭제됩니다<br />
                • 추천인/후원인 관계가 해제됩니다
              </p>
            </div>
          </div>
        </div>

        {/* 에러 메시지 */}
        {error && (
          <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* 확인 입력 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium text-slate-300">
              확인을 위해 <span className="text-red-400 font-bold">&quot;삭제&quot;</span>를 입력하세요
            </label>
            <input
              type="text"
              value={confirmText}
              onChange={(e) => {
                setConfirmText(e.target.value);
                setError(null);
              }}
              className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-red-500/50 focus:outline-none focus:ring-2 focus:ring-red-500/20"
              placeholder="삭제"
              required
            />
          </div>

          {/* 버튼 */}
          <div className="mt-6 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="rounded-lg border border-white/10 bg-slate-800/50 px-5 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={isLoading || confirmText !== '삭제'}
              className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-red-500 to-orange-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-red-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-red-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  삭제 중...
                </>
              ) : (
                <>
                  <Trash2 className="h-4 w-4" />
                  삭제하기
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

