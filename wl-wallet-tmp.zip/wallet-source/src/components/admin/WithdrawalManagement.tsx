'use client';

import { useState, useEffect, useCallback } from 'react';
import { CheckCircle, XCircle, Loader2, Search, Filter, RefreshCw } from 'lucide-react';
import { useI18n } from '@/lib/i18n/context';

interface WithdrawalRequest {
  id: string;
  userId: string;
  username: string | null;
  email: string | null;
  walletAddress: string | null;
  userRank: number;
  userBalance: number;
  amount: number;
  address: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  requestedAt: string;
  processedAt: string | null;
}

interface WithdrawalStatistics {
  totalRequests: number;
  totalRequested: number;
  statusDistribution: Array<{
    status: string;
    count: number;
    amount: number;
    percentage: number;
  }>;
  averageAmount: number;
}

interface WithdrawalResponse {
  ok: boolean;
  data?: {
    requests: WithdrawalRequest[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      totalPages: number;
      hasNext: boolean;
      hasPrev: boolean;
    };
    statistics: WithdrawalStatistics;
  };
  error?: string;
}

export default function WithdrawalManagement() {
  const { language } = useI18n();
  const [requests, setRequests] = useState<WithdrawalRequest[]>([]);
  const [statistics, setStatistics] = useState<WithdrawalStatistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [selectedRequests, setSelectedRequests] = useState<Set<string>>(new Set());
  
  // 필터 상태
  const [filter, setFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    totalPages: 1,
    hasNext: false,
    hasPrev: false,
  });

  // 출금 요청 목록 불러오기
  const fetchWithdrawals = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.append('page', page.toString());
      params.append('limit', '20');
      if (filter !== 'ALL') {
        params.append('status', filter);
      }
      if (search) {
        params.append('search', search);
      }

      const response = await fetch(`/api/admin/withdraw/requests?${params.toString()}`, {
        credentials: 'include',
      });

      const result: WithdrawalResponse = await response.json();

      if (result.ok && result.data) {
        setRequests(result.data.requests);
        setStatistics(result.data.statistics);
        setPagination(result.data.pagination);
      } else {
        console.error('출금 내역 조회 실패:', result.error);
        setRequests([]);
      }
    } catch (error) {
      console.error('출금 내역 조회 실패:', error);
      setRequests([]);
    } finally {
      setLoading(false);
    }
  }, [filter, search, page]);

  useEffect(() => {
    fetchWithdrawals();
  }, [fetchWithdrawals]);

  // 승인/거절 처리
  const handleAction = async (requestId: string, action: 'APPROVE' | 'REJECT', reason?: string) => {
    if (processingId) return;

    const confirmed = window.confirm(
      action === 'APPROVE'
        ? (language === 'ko' ? '이 출금 요청을 승인하시겠습니까?' : 'Do you want to approve this withdrawal request?')
        : (language === 'ko' ? '이 출금 요청을 거절하시겠습니까?' : 'Do you want to reject this withdrawal request?')
    );

    if (!confirmed) return;

    setProcessingId(requestId);
    try {
      const response = await fetch('/api/admin/withdraw/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ requestId, action, reason }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        throw new Error(result.error || (language === 'ko' ? '처리 중 오류가 발생했습니다.' : 'An error occurred during processing.'));
      }

      alert(result.message || (language === 'ko' ? '처리되었습니다.' : 'Processed.'));
      fetchWithdrawals(); // 목록 새로고침
      setSelectedRequests(new Set()); // 선택 초기화
    } catch (error: any) {
      console.error('출금 처리 실패:', error);
      alert(error.message || (language === 'ko' ? '처리 중 오류가 발생했습니다.' : 'An error occurred during processing.'));
    } finally {
      setProcessingId(null);
    }
  };

  // 일괄 처리
  const handleBatchAction = async (action: 'APPROVE' | 'REJECT', reason?: string) => {
    if (selectedRequests.size === 0) {
      alert(language === 'ko' ? '처리할 요청을 선택해주세요.' : 'Please select requests to process.');
      return;
    }

    const confirmed = window.confirm(
      action === 'APPROVE'
        ? (language === 'ko' ? `${selectedRequests.size}개의 출금 요청을 승인하시겠습니까?` : `Do you want to approve ${selectedRequests.size} withdrawal requests?`)
        : (language === 'ko' ? `${selectedRequests.size}개의 출금 요청을 거절하시겠습니까?` : `Do you want to reject ${selectedRequests.size} withdrawal requests?`)
    );

    if (!confirmed) return;

    setProcessingId('BATCH');
    try {
      const response = await fetch('/api/admin/withdraw/approve', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ 
          requestIds: Array.from(selectedRequests), 
          action, 
          reason 
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        throw new Error(result.error || (language === 'ko' ? '일괄 처리 중 오류가 발생했습니다.' : 'An error occurred during batch processing.'));
      }

      alert(result.message || (language === 'ko' ? '처리되었습니다.' : 'Processed.'));
      fetchWithdrawals(); // 목록 새로고침
      setSelectedRequests(new Set()); // 선택 초기화
    } catch (error: any) {
      console.error('일괄 처리 실패:', error);
      alert(error.message || (language === 'ko' ? '일괄 처리 중 오류가 발생했습니다.' : 'An error occurred during batch processing.'));
    } finally {
      setProcessingId(null);
    }
  };

  // 선택 토글
  const toggleSelect = (requestId: string) => {
    const newSelected = new Set(selectedRequests);
    if (newSelected.has(requestId)) {
      newSelected.delete(requestId);
    } else {
      newSelected.add(requestId);
    }
    setSelectedRequests(newSelected);
  };

  // 전체 선택/해제
  const toggleSelectAll = () => {
    const pendingRequests = requests.filter(r => r.status === 'PENDING');
    if (selectedRequests.size === pendingRequests.length) {
      setSelectedRequests(new Set());
    } else {
      setSelectedRequests(new Set(pendingRequests.map(r => r.id)));
    }
  };

  const statusColors = {
    PENDING: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    APPROVED: 'bg-green-500/20 text-green-400 border-green-500/30',
    REJECTED: 'bg-red-500/20 text-red-400 border-red-500/30',
  };

  const statusLabels = {
    PENDING: language === 'ko' ? '대기중' : 'Pending',
    APPROVED: language === 'ko' ? '승인됨' : 'Approved',
    REJECTED: language === 'ko' ? '거절됨' : 'Rejected',
  };

  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString('ko-KR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 8,
    })} MSUO`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ko-KR');
  };

  const pendingCount = requests.filter((r) => r.status === 'PENDING').length;
  const pendingAmount = requests
    .filter((r) => r.status === 'PENDING')
    .reduce((sum, r) => sum + r.amount, 0);

  return (
    <div className="space-y-6">
      {/* 헤더 및 통계 */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">
            {language === 'ko' ? '출금 관리' : 'Withdrawal Management'}
          </h2>
          <p className="text-gray-400 text-sm mt-1">
            {language === 'ko' ? '모든 출금 요청을 관리하고 처리합니다.' : 'Manage and process all withdrawal requests.'}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg px-4 py-2">
            <p className="text-xs text-yellow-400">
              {language === 'ko' ? '대기중' : 'Pending'}
            </p>
            <p className="text-2xl font-bold text-yellow-300">{pendingCount}</p>
            <p className="text-xs text-yellow-400">
              {formatCurrency(pendingAmount)}
            </p>
          </div>
        </div>
      </div>

      {/* 통계 카드 */}
      {statistics && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-4">
            <div className="text-sm text-gray-400 mb-1">
              {language === 'ko' ? '전체 요청' : 'Total Requests'}
            </div>
            <div className="text-2xl font-bold text-white">
              {statistics.totalRequests.toLocaleString()}
            </div>
          </div>
          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-4">
            <div className="text-sm text-gray-400 mb-1">
              {language === 'ko' ? '총 요청 금액' : 'Total Amount'}
            </div>
            <div className="text-2xl font-bold text-white">
              {formatCurrency(statistics.totalRequested)}
            </div>
          </div>
          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-4">
            <div className="text-sm text-gray-400 mb-1">
              {language === 'ko' ? '평균 금액' : 'Average Amount'}
            </div>
            <div className="text-2xl font-bold text-white">
              {formatCurrency(statistics.averageAmount)}
            </div>
          </div>
          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-4">
            <div className="text-sm text-gray-400 mb-1">
              {language === 'ko' ? '승인률' : 'Approval Rate'}
            </div>
            <div className="text-2xl font-bold text-white">
              {statistics.statusDistribution.find(s => s.status === 'APPROVED')?.percentage.toFixed(1) || '0'}%
            </div>
          </div>
        </div>
      )}

      {/* 필터 및 검색 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '검색' : 'Search'}
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                placeholder={language === 'ko' ? '사용자명, 이메일, 지갑주소 검색' : 'Search by username, email, wallet address'}
                className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '상태 필터' : 'Status Filter'}
            </label>
            <select
              value={filter}
              onChange={(e) => {
                setFilter(e.target.value as typeof filter);
                setPage(1);
              }}
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="ALL">{language === 'ko' ? '전체' : 'All'}</option>
              <option value="PENDING">{statusLabels.PENDING}</option>
              <option value="APPROVED">{statusLabels.APPROVED}</option>
              <option value="REJECTED">{statusLabels.REJECTED}</option>
            </select>
          </div>
        </div>
      </div>

      {/* 일괄 처리 버튼 */}
      {selectedRequests.size > 0 && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-4 flex items-center justify-between">
          <span className="text-white">
            {language === 'ko' 
              ? `${selectedRequests.size}개 요청 선택됨` 
              : `${selectedRequests.size} requests selected`}
          </span>
          <div className="flex gap-2">
            <button
              onClick={() => handleBatchAction('APPROVE')}
              disabled={processingId !== null}
              className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              {processingId === 'BATCH' ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CheckCircle className="h-4 w-4" />
              )}
              {language === 'ko' ? '일괄 승인' : 'Batch Approve'}
            </button>
            <button
              onClick={() => handleBatchAction('REJECT')}
              disabled={processingId !== null}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
            >
              {processingId === 'BATCH' ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <XCircle className="h-4 w-4" />
              )}
              {language === 'ko' ? '일괄 거절' : 'Batch Reject'}
            </button>
          </div>
        </div>
      )}

      {/* 출금 요청 목록 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-[#137fec]" />
            <span className="ml-3 text-white">
              {language === 'ko' ? '로딩 중...' : 'Loading...'}
            </span>
          </div>
        ) : requests.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-white/10">
              <thead className="bg-white/5">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                    <input
                      type="checkbox"
                      checked={selectedRequests.size === requests.filter(r => r.status === 'PENDING').length && requests.filter(r => r.status === 'PENDING').length > 0}
                      onChange={toggleSelectAll}
                      className="w-4 h-4 text-[#137fec] bg-white/5 border-white/10 rounded focus:ring-[#137fec]"
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                    {language === 'ko' ? '요청일시' : 'Requested Date'}
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                    {language === 'ko' ? '사용자' : 'User'}
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                    {language === 'ko' ? '금액' : 'Amount'}
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                    {language === 'ko' ? '출금 주소' : 'Withdrawal Address'}
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                    {language === 'ko' ? '상태' : 'Status'}
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                    {language === 'ko' ? '처리일시' : 'Processed Date'}
                  </th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-gray-300 uppercase">
                    {language === 'ko' ? '작업' : 'Actions'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {requests.map((request) => (
                  <tr key={request.id} className="hover:bg-white/5 transition-colors">
                    <td className="px-4 py-4">
                      {request.status === 'PENDING' ? (
                        <input
                          type="checkbox"
                          checked={selectedRequests.has(request.id)}
                          onChange={() => toggleSelect(request.id)}
                          className="w-4 h-4 text-[#137fec] bg-white/5 border-white/10 rounded focus:ring-[#137fec]"
                        />
                      ) : null}
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-300">
                      {formatDate(request.requestedAt)}
                    </td>
                    <td className="px-4 py-4">
                      <div>
                        <div className="font-medium text-white">
                          {request.username || 'Unknown'}
                        </div>
                        <div className="text-xs text-gray-400">
                          {request.email || '-'}
                        </div>
                        {request.userRank > 0 && (
                          <div className="text-xs text-purple-400">
                            {request.userRank}성
                          </div>
                        )}
                        <div className="text-xs text-gray-500">
                          {language === 'ko' ? '잔액' : 'Balance'}: {formatCurrency(request.userBalance)}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-sm font-semibold text-white">
                      {formatCurrency(request.amount)}
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-400">
                      <span className="font-mono text-xs break-all">
                        {request.address}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <span
                        className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-semibold ${
                          statusColors[request.status] || statusColors.PENDING
                        }`}
                      >
                        {statusLabels[request.status] || request.status}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm text-gray-400">
                      {request.processedAt ? formatDate(request.processedAt) : '-'}
                    </td>
                    <td className="px-4 py-4 text-right">
                      {request.status === 'PENDING' ? (
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => handleAction(request.id, 'APPROVE')}
                            disabled={processingId === request.id}
                            className="px-3 py-1.5 bg-green-600/20 border border-green-500/30 text-green-300 rounded-lg text-xs font-semibold hover:bg-green-600/30 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                          >
                            {processingId === request.id ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <CheckCircle className="h-3 w-3" />
                            )}
                            {language === 'ko' ? '승인' : 'Approve'}
                          </button>
                          <button
                            onClick={() => handleAction(request.id, 'REJECT')}
                            disabled={processingId === request.id}
                            className="px-3 py-1.5 bg-red-600/20 border border-red-500/30 text-red-300 rounded-lg text-xs font-semibold hover:bg-red-600/30 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                          >
                            {processingId === request.id ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <XCircle className="h-3 w-3" />
                            )}
                            {language === 'ko' ? '거절' : 'Reject'}
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs text-gray-500">
                          {language === 'ko' ? '처리 완료' : 'Completed'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12">
            <svg
              className="mx-auto h-12 w-12 text-gray-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
            <p className="mt-4 text-sm text-gray-500">
              {filter === 'ALL'
                ? (language === 'ko' ? '출금 요청이 없습니다.' : 'No withdrawal requests.')
                : (language === 'ko' ? '해당 상태의 출금 요청이 없습니다.' : 'No withdrawal requests with this status.')}
            </p>
          </div>
        )}

        {/* 페이지네이션 */}
        {pagination.totalPages > 1 && (
          <div className="bg-white/5 px-6 py-4 flex items-center justify-between border-t border-white/10">
            <div className="text-sm text-gray-300">
              {language === 'ko' 
                ? `페이지 ${pagination.page} / ${pagination.totalPages} (전체 ${pagination.total.toLocaleString()}개)`
                : `Page ${pagination.page} / ${pagination.totalPages} (Total ${pagination.total.toLocaleString()})`}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={!pagination.hasPrev || loading}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                {language === 'ko' ? '이전' : 'Prev'}
              </button>
              <button
                onClick={() => setPage(p => Math.min(pagination.totalPages, p + 1))}
                disabled={!pagination.hasNext || loading}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                {language === 'ko' ? '다음' : 'Next'}
              </button>
              <button
                onClick={fetchWithdrawals}
                disabled={loading}
                className="px-4 py-2 bg-[#137fec] hover:bg-[#137fec]/90 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition flex items-center gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                {language === 'ko' ? '새로고침' : 'Refresh'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

