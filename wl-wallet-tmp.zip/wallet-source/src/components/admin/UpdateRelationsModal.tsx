'use client'

import { useState, useEffect } from 'react'
import { useI18n } from '@/lib/i18n/context'

interface UpdateRelationsModalProps {
  isOpen: boolean
  onClose: () => void
  userId: string
  currentReferrer?: {
    username: string
    referralCode?: string
  } | null
  currentSponsor?: {
    username: string
    referralCode?: string
  } | null
  onSuccess: () => void
}

export default function UpdateRelationsModal({
  isOpen,
  onClose,
  userId,
  currentReferrer,
  currentSponsor,
  onSuccess,
}: UpdateRelationsModalProps) {
  const { t, language } = useI18n()
  const [referrerCode, setReferrerCode] = useState('')
  const [sponsorCode, setSponsorCode] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (isOpen) {
      setReferrerCode(currentReferrer?.referralCode || currentReferrer?.username || '')
      setSponsorCode(currentSponsor?.referralCode || currentSponsor?.username || '')
      setError('')
    }
  }, [isOpen, currentReferrer, currentSponsor])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      const response = await fetch(`/api/admin/users/${userId}/update-relations`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          referrerCode: referrerCode.trim() || null,
          sponsorCode: sponsorCode.trim() || null,
        }),
      })

      const data = await response.json()

      if (response.ok && data.ok) {
        onSuccess()
        onClose()
      } else {
        setError(data.error || (language === 'ko' ? '변경에 실패했습니다.' : 'Failed to update.'))
      }
    } catch (err) {
      console.error('추천인/후원인 변경 실패:', err)
      setError(language === 'ko' ? '네트워크 오류가 발생했습니다.' : 'Network error occurred.')
    } finally {
      setIsLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-[#1e293b] rounded-lg border border-white/10 shadow-2xl w-full max-w-md mx-4">
        <div className="px-6 py-4 border-b border-white/10">
          <h2 className="text-xl font-bold text-white">
            {language === 'ko' ? '추천인/후원인 변경' : 'Update Referrer/Sponsor'}
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="px-6 py-4 space-y-4">
          {error && (
            <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-300 text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '추천인 코드 또는 사용자명' : 'Referrer Code or Username'}
            </label>
            <input
              type="text"
              value={referrerCode}
              onChange={(e) => setReferrerCode(e.target.value)}
              placeholder={language === 'ko' ? '추천인 코드 또는 사용자명 (비워두면 제거)' : 'Referrer code or username (leave empty to remove)'}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
            {currentReferrer && (
              <p className="mt-1 text-xs text-gray-400">
                {language === 'ko' ? '현재 추천인: ' : 'Current other_users_users_referrerIdTousers: '}
                {currentReferrer.username}
                {currentReferrer.referralCode && ` (${currentReferrer.referralCode})`}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '후원인 코드 또는 사용자명' : 'Sponsor Code or Username'}
            </label>
            <input
              type="text"
              value={sponsorCode}
              onChange={(e) => setSponsorCode(e.target.value)}
              placeholder={language === 'ko' ? '후원인 코드 또는 사용자명 (비워두면 제거)' : 'Sponsor code or username (leave empty to remove)'}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
            {currentSponsor && (
              <p className="mt-1 text-xs text-gray-400">
                {language === 'ko' ? '현재 후원인: ' : 'Current other_users_users_sponsorIdTousers: '}
                {currentSponsor.username}
                {currentSponsor.referralCode && ` (${currentSponsor.referralCode})`}
              </p>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2 text-sm font-medium text-gray-300 hover:text-white transition-colors disabled:opacity-50"
            >
              {language === 'ko' ? '취소' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-4 py-2 text-sm font-medium bg-[#137fec] text-white rounded-lg hover:bg-[#137fec]/90 transition-colors disabled:opacity-50"
            >
              {isLoading
                ? (language === 'ko' ? '처리 중...' : 'Processing...')
                : (language === 'ko' ? '변경' : 'Update')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

