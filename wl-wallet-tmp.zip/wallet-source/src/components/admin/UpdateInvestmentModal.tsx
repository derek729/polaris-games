'use client';

import { useState, useEffect } from 'react';
import { X, Edit, Loader2 } from 'lucide-react';

interface UpdateInvestmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  userId: string;
  username: string;
  investments: {
    id: string;
    amount: number;
    investment_tiers: number;
    dailyRate: number;
    matchingDepth: number;
    isActive: boolean;
  };
}

interface InvestmentTier {
  tier: number;
  minAmount: number;
  maxAmount: number | null;
  dailyRate: number;
  matchingDepth: number;
  label: string;
  description: string;
}

export default function UpdateInvestmentModal({ 
  isOpen, 
  onClose, 
  onSuccess, 
  userId,
  username,
  investment
}: UpdateInvestmentModalProps) {
  const [formData, setFormData] = useState({
    investmentAmount: investment.amount.toString(),
    investment_tiers: investment.investment_tiers.toString(),
  });
  const [investmentTiers, setInvestmentTiers] = useState<InvestmentTier[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingTiers, setIsLoadingTiers] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadInvestmentTiers();
      setFormData({
        investmentAmount: investment.amount.toString(),
        investment_tiers: investment.investment_tiers.toString(),
      });
    }
  }, [isOpen, investment]);

  const loadInvestmentTiers = async () => {
    setIsLoadingTiers(true);
    try {
      const response = await fetch('/api/admin/investment/tiers', {
        credentials: 'include',
      });
      const result = await response.json();
      if (result.ok && result.data) {
        setInvestmentTiers(result.data);
      }
    } catch (error) {
      console.error('투자 상품 목록 로드 실패:', error);
    } finally {
      setIsLoadingTiers(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.investmentAmount || !formData.investmentTier) {
      setError('투자 금액과 등급을 모두 선택해주세요.');
      return;
    }

    const amount = parseFloat(formData.investmentAmount);
    if (isNaN(amount) || amount < 50) {
      setError('투자 금액은 최소 $50 이상이어야 합니다.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(`/api/admin/users/${userId}/investment/${investment.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          amount: amount,
          tier: parseInt(formData.investmentTier),
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setError(result.error || '투자 수정에 실패했습니다.');
        return;
      }

      alert('투자 상품이 성공적으로 수정되었습니다.');
      onSuccess();
      handleClose();
    } catch (error: any) {
      console.error('투자 수정 실패:', error);
      setError('투자 수정 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setFormData({
      investmentAmount: investment.amount.toString(),
      investment_tiers: investment.investment_tiers.toString(),
    });
    setError(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
        {/* 헤더 */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-yellow-500/20 to-orange-500/20 p-2">
              <Edit className="h-5 w-5 text-yellow-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">투자 상품 수정</h2>
              <p className="text-sm text-slate-400">사용자: {username}</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* 에러 메시지 */}
        {error && (
          <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* 폼 */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {/* 투자 등급 선택 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                투자 등급 <span className="text-red-400">*</span>
              </label>
              <select
                value={formData.investmentTier}
                onChange={(e) => {
                  const selectedTier = e.target.value;
                  setFormData({ ...formData, investment_tiers: selectedTier });
                  // 등급 선택 시 최소 금액 자동 입력
                  if (selectedTier) {
                    const tier = investmentTiers.find(t => t.tier === parseInt(selectedTier));
                    if (tier && parseFloat(formData.investmentAmount) < tier.minAmount) {
                      setFormData(prev => ({ ...prev, investmentAmount: tier.minAmount.toString() }));
                    }
                  }
                }}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                disabled={isLoadingTiers}
                required
              >
                {investmentTiers.map((tier) => (
                  <option key={tier.tier} value={tier.tier.toString()}>
                    {tier.label} - {tier.description}
                  </option>
                ))}
              </select>
              {formData.investmentTier && (
                <p className="mt-1 text-xs text-slate-400">
                  {(() => {
                    const tier = investmentTiers.find(t => t.tier === parseInt(formData.investmentTier));
                    return tier ? `일일 수익률: ${(tier.dailyRate * 100).toFixed(2)}%, 매칭 깊이: ${tier.matchingDepth}대` : '';
                  })()}
                </p>
              )}
            </div>

            {/* 투자 금액 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                투자 금액 ($) <span className="text-red-400">*</span>
              </label>
              <input
                type="number"
                value={formData.investmentAmount}
                onChange={(e) => {
                  const amount = e.target.value;
                  setFormData({ ...formData, investmentAmount: amount });
                  // 금액 입력 시 자동으로 등급 계산
                  if (amount) {
                    const amountNum = parseFloat(amount);
                    const tier = investmentTiers.find(t => 
                      amountNum >= t.minAmount && (t.maxAmount === null || amountNum <= t.maxAmount)
                    );
                    if (tier) {
                      setFormData(prev => ({ ...prev, investment_tiers: tier.tier.toString() }));
                    }
                  }
                }}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-green-500/50 focus:outline-none focus:ring-2 focus:ring-green-500/20"
                placeholder="최소 $50"
                min="50"
                step="1"
                disabled={isLoadingTiers}
                required
              />
              {formData.investmentTier && formData.investmentAmount && (
                <p className="mt-1 text-xs text-slate-400">
                  {(() => {
                    const tier = investmentTiers.find(t => t.tier === parseInt(formData.investmentTier));
                    const amount = parseFloat(formData.investmentAmount);
                    if (tier && amount) {
                      const dailyEarning = amount * tier.dailyRate;
                      return `예상 일일 수익: $${dailyEarning.toFixed(2)}`;
                    }
                    return '';
                  })()}
                </p>
              )}
            </div>
          </div>

          {/* 현재 투자 정보 */}
          <div className="rounded-lg border border-blue-500/30 bg-blue-500/5 p-4">
            <p className="text-sm font-medium text-blue-400 mb-2">현재 투자 정보</p>
            <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
              <div>금액: ${investment.amount.toLocaleString()}</div>
              <div>등급: Tier {investment.investmentTier}</div>
              <div>일일 수익률: {(investment.dailyRate * 100).toFixed(2)}%</div>
              <div>매칭 깊이: {investment.matchingDepth}대</div>
            </div>
          </div>

          {/* 버튼 */}
          <div className="mt-6 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="rounded-lg border border-white/10 bg-slate-800/50 px-5 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-yellow-500 to-orange-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-yellow-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-yellow-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  수정 중...
                </>
              ) : (
                <>
                  <Edit className="h-4 w-4" />
                  투자 수정
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

