'use client';

import { useState, useEffect } from 'react';
import { Save, Loader2, AlertCircle, CheckCircle } from 'lucide-react';
import { useI18n } from '@/lib/i18n/context';

interface SystemSettings {
  // 코인 설정
  upcTotalSupply: string;
  upcInitialPrice: string;
  upcCurrentPrice: string;

  // 스테이킹 설정
  stakingApy: string;
  stakingMinAmount: string;
  stakingMaxAmount: string;
  stakingLockPeriod: string;

  // 전송 수수료 설정
  transferFeeOzCoin: string;

  // 거래소 설정
  exchangeBotEnabled: boolean;
  exchangeBotMinPrice: string;
  exchangeBotMaxPrice: string;
  exchangeBotSpread: string;
  exchangeBotOrderAmount: string;

  // USDT 입금 주소
  usdtAddress: string;
}

export default function SystemSettings() {
  const { language } = useI18n();
  const [settings, setSettings] = useState<SystemSettings>({
    upcTotalSupply: '10000000000', // 100억개
    upcInitialPrice: '0.00010',
    upcCurrentPrice: '',
    stakingApy: '10', // 10%
    stakingMinAmount: '1000', // 최소 1,000 MSUO
    stakingMaxAmount: '',
    stakingLockPeriod: '30', // 30일
    transferFeeOzCoin: '0.01', // OZCOIN 0.01개
    exchangeBotEnabled: false,
    exchangeBotMinPrice: '0.00005',
    exchangeBotMaxPrice: '0.00015',
    exchangeBotSpread: '0.00001',
    exchangeBotOrderAmount: '1000',
    usdtAddress: '',
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/settings', {
        credentials: 'include',
      });

      const result = await response.json();

      if (result.ok && result.data) {
        const data = result.data;
        setSettings({
          upcTotalSupply: data.upcTotalSupply || '10000000000',
          upcInitialPrice: data.upcInitialPrice || '0.00010',
          upcCurrentPrice: data.upcCurrentPrice || '',
          stakingApy: data.stakingApy || '10',
          stakingMinAmount: data.stakingMinAmount || '1000',
          stakingMaxAmount: data.stakingMaxAmount || '',
          stakingLockPeriod: data.stakingLockPeriod || '30',
          transferFeeOzCoin: data.transferFeeOzCoin || '0.01',
          exchangeBotEnabled: data.exchangeBotEnabled === 'true' || data.exchangeBotEnabled === true,
          exchangeBotMinPrice: data.exchangeBotMinPrice || '0.00005',
          exchangeBotMaxPrice: data.exchangeBotMaxPrice || '0.00015',
          exchangeBotSpread: data.exchangeBotSpread || '0.00001',
          exchangeBotOrderAmount: data.exchangeBotOrderAmount || '1000',
          usdtAddress: data.usdtAddress || '',
        });
      }
    } catch (error) {
      console.error('설정 조회 실패:', error);
      setMessage({
        type: 'error',
        text: language === 'ko' ? '설정을 불러오는데 실패했습니다.' : 'Failed to load settings.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setMessage(null);

      const response = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(settings),
      });

      const result = await response.json();

      if (result.ok) {
        setMessage({
          type: 'success',
          text: language === 'ko' ? '설정이 저장되었습니다.' : 'Settings saved successfully.',
        });
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage({
          type: 'error',
          text: result.error || (language === 'ko' ? '설정 저장에 실패했습니다.' : 'Failed to save settings.'),
        });
      }
    } catch (error) {
      console.error('설정 저장 실패:', error);
      setMessage({
        type: 'error',
        text: language === 'ko' ? '네트워크 오류가 발생했습니다.' : 'Network error occurred.',
      });
    } finally {
      setSaving(false);
    }
  };

  const formatNumber = (num: string) => {
    if (!num) return '';
    return Number(num).toLocaleString('ko-KR');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <Loader2 className="h-8 w-8 animate-spin text-[#137fec]" />
        <span className="ml-3 text-white">
          {language === 'ko' ? '설정을 불러오는 중...' : 'Loading settings...'}
        </span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 메시지 */}
      {message && (
        <div
          className={`p-4 rounded-lg border flex items-center gap-2 ${
            message.type === 'success'
              ? 'bg-green-500/20 border-green-500/50 text-green-300'
              : 'bg-red-500/20 border-red-500/50 text-red-300'
          }`}
        >
          {message.type === 'success' ? (
            <CheckCircle className="h-5 w-5" />
          ) : (
            <AlertCircle className="h-5 w-5" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* 코인 설정 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-6">
          {language === 'ko' ? '코인 설정' : 'Coin Settings'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? 'MSUO 총 발행량' : 'MSUO Total Supply'}
            </label>
            <input
              type="text"
              value={formatNumber(settings.upcTotalSupply)}
              onChange={(e) => {
                const value = e.target.value.replace(/,/g, '');
                if (/^\d*$/.test(value)) {
                  setSettings({ ...settings, upcTotalSupply: value });
                }
              }}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="10000000000"
            />
            <p className="text-xs text-gray-400 mt-1">
              {language === 'ko' ? '현재: 100억개 (5,000,000,000)' : 'Current: 5,000,000,000'}
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? 'MSUO 초기 가격 (USDT)' : 'MSUO Initial Price (USDT)'}
            </label>
            <input
              type="number"
              step="0.00001"
              value={settings.upcInitialPrice}
              onChange={(e) => setSettings({ ...settings, upcInitialPrice: e.target.value })}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="0.00010"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? 'MSUO 현재 가격 (USDT)' : 'MSUO Current Price (USDT)'}
            </label>
            <input
              type="number"
              step="0.00001"
              value={settings.upcCurrentPrice}
              onChange={(e) => setSettings({ ...settings, upcCurrentPrice: e.target.value })}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="0.00010"
            />
            <p className="text-xs text-gray-400 mt-1">
              {language === 'ko' ? '비워두면 자동 계산됩니다.' : 'Leave empty for auto calculation.'}
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? 'USDT 입금 주소' : 'USDT Deposit Address'}
            </label>
            <input
              type="text"
              value={settings.usdtAddress}
              onChange={(e) => setSettings({ ...settings, usdtAddress: e.target.value })}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="0x..."
            />
          </div>
        </div>
      </div>

      {/* 스테이킹 설정 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-6">
          {language === 'ko' ? '스테이킹 설정' : 'Staking Settings'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '연이율 (APY, %)' : 'Annual Percentage Yield (APY, %)'}
            </label>
            <input
              type="number"
              step="0.1"
              value={settings.stakingApy}
              onChange={(e) => setSettings({ ...settings, stakingApy: e.target.value })}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="10"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '최소 스테이킹 금액 (MSUO)' : 'Min Staking Amount (MSUO)'}
            </label>
            <input
              type="text"
              value={formatNumber(settings.stakingMinAmount)}
              onChange={(e) => {
                const value = e.target.value.replace(/,/g, '');
                if (/^\d*$/.test(value)) {
                  setSettings({ ...settings, stakingMinAmount: value });
                }
              }}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="1000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '최대 스테이킹 금액 (MSUO)' : 'Max Staking Amount (MSUO)'}
            </label>
            <input
              type="text"
              value={formatNumber(settings.stakingMaxAmount)}
              onChange={(e) => {
                const value = e.target.value.replace(/,/g, '');
                if (/^\d*$/.test(value)) {
                  setSettings({ ...settings, stakingMaxAmount: value });
                }
              }}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder={language === 'ko' ? '비워두면 제한 없음' : 'Leave empty for unlimited'}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '락업 기간 (일)' : 'Lock Period (Days)'}
            </label>
            <input
              type="number"
              value={settings.stakingLockPeriod}
              onChange={(e) => setSettings({ ...settings, stakingLockPeriod: e.target.value })}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="30"
            />
          </div>
        </div>
      </div>

      {/* 전송 수수료 설정 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-6">
          {language === 'ko' ? '전송 수수료 설정' : 'Transfer Fee Settings'}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '전송 수수료 (OZCOIN)' : 'Transfer Fee (OZCOIN)'}
            </label>
            <input
              type="number"
              step="0.01"
              value={settings.transferFeeOzCoin}
              onChange={(e) => setSettings({ ...settings, transferFeeOzCoin: e.target.value })}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="0.01"
            />
            <p className="text-xs text-gray-400 mt-1">
              {language === 'ko' ? '현재: 0.01 OZCOIN' : 'Current: 0.01 OZCOIN'}
            </p>
          </div>
        </div>
      </div>

      {/* 거래소 설정 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-white mb-6">
          {language === 'ko' ? '거래소 설정' : 'Exchange Settings'}
        </h3>

        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="exchangeBotEnabled"
              checked={settings.exchangeBotEnabled}
              onChange={(e) => setSettings({ ...settings, exchangeBotEnabled: e.target.checked })}
              className="w-5 h-5 text-[#137fec] bg-white/5 border-white/10 rounded focus:ring-[#137fec]"
            />
            <label htmlFor="exchangeBotEnabled" className="text-white font-medium">
              {language === 'ko' ? '거래 봇 활성화' : 'Enable Exchange Bot'}
            </label>
          </div>

          {settings.exchangeBotEnabled && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pl-8 border-l-2 border-white/10">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {language === 'ko' ? '최저가 (USDT)' : 'Min Price (USDT)'}
                </label>
                <input
                  type="number"
                  step="0.00001"
                  value={settings.exchangeBotMinPrice}
                  onChange={(e) => setSettings({ ...settings, exchangeBotMinPrice: e.target.value })}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {language === 'ko' ? '최고가 (USDT)' : 'Max Price (USDT)'}
                </label>
                <input
                  type="number"
                  step="0.00001"
                  value={settings.exchangeBotMaxPrice}
                  onChange={(e) => setSettings({ ...settings, exchangeBotMaxPrice: e.target.value })}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {language === 'ko' ? '스프레드 (USDT)' : 'Spread (USDT)'}
                </label>
                <input
                  type="number"
                  step="0.00001"
                  value={settings.exchangeBotSpread}
                  onChange={(e) => setSettings({ ...settings, exchangeBotSpread: e.target.value })}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {language === 'ko' ? '주문 수량 (MSUO)' : 'Order Amount (MSUO)'}
                </label>
                <input
                  type="text"
                  value={formatNumber(settings.exchangeBotOrderAmount)}
                  onChange={(e) => {
                    const value = e.target.value.replace(/,/g, '');
                    if (/^\d*$/.test(value)) {
                      setSettings({ ...settings, exchangeBotOrderAmount: value });
                    }
                  }}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 저장 버튼 */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-6 py-3 bg-[#137fec] hover:bg-[#137fec]/90 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
        >
          {saving ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>{language === 'ko' ? '저장 중...' : 'Saving...'}</span>
            </>
          ) : (
            <>
              <Save className="h-5 w-5" />
              <span>{language === 'ko' ? '설정 저장' : 'Save Settings'}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}

