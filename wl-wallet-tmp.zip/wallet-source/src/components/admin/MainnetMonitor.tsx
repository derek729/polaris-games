/**
 * 메인넷 상태 모니터링 컴포넌트
 */
'use client';

import React, { useState, useEffect } from 'react';
import { Activity, CheckCircle, AlertCircle, XCircle, RefreshCw, TrendingUp, Users, Clock } from 'lucide-react';

interface MainnetStatus {
  connected: boolean;
  height: number;
  difficulty: number;
  blockReward: number;
  totalSupply: number;
  lastBlockHash: string | null;
  errorMessage: string | null;
  lastChecked: string;
}

interface DatabaseStatus {
  totalUsers: number;
  usersWithWallets: number;
  walletCreationRate: number;
  totalSupply: number;
  recentTransfers24h: number;
}

interface SyncStatus {
  total: number;
  pending: number;
  synced: number;
  failed: number;
  rate: number;
  rate24h: number;
}

interface HealthStatus {
  overall: 'HEALTHY' | 'WARNING' | 'CRITICAL';
  mainnetConnection: 'CONNECTED' | 'DISCONNECTED';
  syncRate: number;
  failureRate: number;
  pendingCount: number;
  recommendations: string[];
}

interface MonitoringData {
  timestamp: string;
  mainnet: MainnetStatus;
  database: DatabaseStatus;
  sync: SyncStatus;
  health: HealthStatus;
}

export default function MainnetMonitor() {
  const [data, setData] = useState<MonitoringData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(false);

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/monitoring/mainnet');
      const result = await response.json();

      if (result.ok) {
        setData(result.data);
        setError(null);
      } else {
        setError(result.error || '데이터 조회 실패');
      }
    } catch (err) {
      setError('서버 연결 오류');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();

    if (autoRefresh) {
      const interval = setInterval(fetchData, 30000); // 30초마다 새로고침
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const handleAutoSync = async () => {
    try {
      const response = await fetch('/api/admin/monitoring/mainnet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ autoSync: true, maxTransfers: 10 })
      });

      const result = await response.json();
      if (result.ok) {
        alert(`자동 동기화 준비 완료: ${result.data.pending}개 대기 중`);
        fetchData(); // 데이터 새로고침
      } else {
        alert(`자동 동기화 실패: ${result.error}`);
      }
    } catch (err) {
      alert('자동 동기화 중 오류 발생');
    }
  };

  const getHealthColor = (status: string) => {
    switch (status) {
      case 'HEALTHY': return 'text-green-600';
      case 'WARNING': return 'text-yellow-600';
      case 'CRITICAL': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getHealthIcon = (status: string) => {
    switch (status) {
      case 'HEALTHY': return <CheckCircle className="w-5 h-5" />;
      case 'WARNING': return <AlertCircle className="w-5 h-5" />;
      case 'CRITICAL': return <XCircle className="w-5 h-5" />;
      default: return <Activity className="w-5 h-5" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <div className="flex items-center text-red-800">
          <XCircle className="w-5 h-5 mr-2" />
          {error}
        </div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">메인넷 상태 모니터링</h2>
          <p className="text-gray-600 mt-1">
            마지막 업데이트: {new Date(data.timestamp).toLocaleString('ko-KR')}
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              autoRefresh
                ? 'bg-green-100 text-green-700 hover:bg-green-200'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {autoRefresh ? '자동 새로고침 중' : '자동 새로고침'}
          </button>
          <button
            onClick={fetchData}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            새로고침
          </button>
          <button
            onClick={handleAutoSync}
            disabled={data.sync.pending === 0}
            className="px-4 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            자동 동기화
          </button>
        </div>
      </div>

      {/* 건강 상태 요약 */}
      <div className={`bg-white border rounded-lg p-6 ${getHealthColor(data.health.overall).replace('text', 'border')}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {getHealthIcon(data.health.overall)}
            <div className="ml-3">
              <h3 className="text-lg font-semibold">전체 상태: {data.health.overall}</h3>
              <p className="text-sm opacity-75">동기화율: {data.health.syncRate}% | 실패율: {data.health.failureRate}%</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm">대기 중인 이체</div>
            <div className="text-2xl font-bold">{data.health.pendingCount}</div>
          </div>
        </div>
      </div>

      {/* 상태 카드들 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 메인넷 상태 */}
        <div className="bg-white border rounded-lg p-6">
          <div className="flex items-center mb-4">
            <Activity className="w-6 h-6 text-blue-600 mr-2" />
            <h3 className="text-lg font-semibold">메인넷 상태</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">연결 상태</span>
              <span className={`font-medium ${data.mainnet.connected ? 'text-green-600' : 'text-red-600'}`}>
                {data.mainnet.connected ? '연결됨' : '연결 안됨'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">블록 높이</span>
              <span className="font-medium">{data.mainnet.height.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">난이도</span>
              <span className="font-medium">{data.mainnet.difficulty}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">총 공급량</span>
              <span className="font-medium">{data.mainnet.totalSupply.toLocaleString()} MSUO</span>
            </div>
          </div>
        </div>

        {/* 데이터베이스 상태 */}
        <div className="bg-white border rounded-lg p-6">
          <div className="flex items-center mb-4">
            <Users className="w-6 h-6 text-green-600 mr-2" />
            <h3 className="text-lg font-semibold">데이터베이스</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">전체 사용자</span>
              <span className="font-medium">{data.database.totalUsers.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">지갑 보유자</span>
              <span className="font-medium">{data.database.usersWithWallets.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">지갑 생성률</span>
              <span className="font-medium">{data.database.walletCreationRate.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">24시간 이체</span>
              <span className="font-medium">{data.database.recentTransfers24h}</span>
            </div>
          </div>
        </div>

        {/* 동기화 상태 */}
        <div className="bg-white border rounded-lg p-6">
          <div className="flex items-center mb-4">
            <TrendingUp className="w-6 h-6 text-purple-600 mr-2" />
            <h3 className="text-lg font-semibold">동기화 상태</h3>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">총 이체</span>
              <span className="font-medium">{data.sync.total}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">대기 중</span>
              <span className="font-medium text-yellow-600">{data.sync.pending}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">동기화됨</span>
              <span className="font-medium text-green-600">{data.sync.synced}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">실패</span>
              <span className="font-medium text-red-600">{data.sync.failed}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 추천 사항 */}
      {data.health.recommendations.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-900 mb-3">추천 사항</h3>
          <ul className="space-y-2">
            {data.health.recommendations.map((recommendation, index) => (
              <li key={index} className="flex items-start text-blue-800">
                <span className="text-blue-600 mr-2">•</span>
                {recommendation}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}