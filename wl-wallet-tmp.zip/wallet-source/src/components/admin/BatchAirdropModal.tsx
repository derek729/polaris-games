'use client';

import { useState } from 'react';
import { useI18n } from '@/lib/i18n/context';

interface BatchAirdropModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function BatchAirdropModal({
  isOpen,
  onClose,
  onSuccess,
}: BatchAirdropModalProps) {
  const { language } = useI18n();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    reason: '',
    targetType: 'ALL', // ALL: 전체, SELECTED: 선택(미구현)
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirm(language === 'ko' ? '전체 사용자에게 코인을 지급하시겠습니까?' : 'Airdrop to ALL users?')) {
      return;
    }

    try {
      setLoading(true);
      const response = await fetch('/api/admin/users/batch-charge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseFloat(formData.amount),
          reason: formData.reason,
          targetType: formData.targetType,
        }),
      });

      const data = await response.json();
      if (data.ok) {
        alert(language === 'ko' 
          ? `${data.data.count}명에게 지급 완료되었습니다.` 
          : `Airdropped to ${data.data.count} users successfully.`);
        onSuccess();
        onClose();
      } else {
        alert(data.error || 'Failed');
      }
    } catch (error) {
      console.error(error);
      alert('Error occurred');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="w-full max-w-md rounded-2xl border border-white/10 bg-[#1e293b] p-6 shadow-xl">
        <h3 className="text-xl font-bold text-white mb-4">
          {language === 'ko' ? '일괄 코인 지급 (에어드랍)' : 'Batch Coin Airdrop'}
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="p-3 bg-yellow-900/30 border border-yellow-500/30 rounded-lg text-sm text-yellow-200">
            {language === 'ko' 
              ? '주의: 현재 등록된 모든 활성 사용자에게 코인이 지급됩니다.' 
              : 'Warning: Coins will be distributed to ALL active users.'}
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-1">
              {language === 'ko' ? '지급 대상' : 'Target'}
            </label>
            <select
              disabled
              className="w-full px-3 py-2 bg-black/20 border border-white/10 rounded-lg text-white opacity-70"
            >
              <option value="ALL">{language === 'ko' ? '전체 사용자' : 'All Users'}</option>
            </select>
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-1">
              {language === 'ko' ? '지급 수량 (MSUO)' : 'Amount (MSUO)'}
            </label>
            <input
              type="number"
              required
              min="0.00000001"
              step="0.00000001"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              className="w-full px-3 py-2 bg-black/20 border border-white/10 rounded-lg text-white"
              placeholder="0.00"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-1">
              {language === 'ko' ? '사유 (로그용)' : 'Reason'}
            </label>
            <input
              type="text"
              required
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              className="w-full px-3 py-2 bg-black/20 border border-white/10 rounded-lg text-white"
              placeholder={language === 'ko' ? '이벤트 보상 등' : 'Event Reward, etc.'}
            />
          </div>

          <div className="flex gap-3 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
            >
              {language === 'ko' ? '취소' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold transition-colors disabled:opacity-50"
            >
              {loading ? '...' : (language === 'ko' ? '일괄 지급' : 'Airdrop')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
