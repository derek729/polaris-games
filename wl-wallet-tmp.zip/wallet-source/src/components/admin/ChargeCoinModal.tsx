'use client';

import { useState, useEffect } from 'react';
import { X, Coins, Loader2 } from 'lucide-react';

interface ChargeCoinModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  username: string;
  currentBalance?: number;
  onSuccess: () => void;
  type: 'charge' | 'withdraw';
}

export default function ChargeCoinModal({
  isOpen,
  onClose,
  userId,
  username,
  currentBalance = 0,
  onSuccess,
  type,
}: ChargeCoinModalProps) {
  const [amount, setAmount] = useState('');
  const [memo, setMemo] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setAmount('');
      setMemo('');
      setError(null);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const coinAmount = parseFloat(amount);
    if (isNaN(coinAmount) || coinAmount <= 0) {
      setError('올바른 금액을 입력해주세요.');
      return;
    }

    if (type === 'withdraw' && coinAmount > currentBalance) {
      setError(`잔액이 부족합니다. (보유: ${currentBalance.toLocaleString('ko-KR')} MSUO)`);
      return;
    }

    try {
      setLoading(true);
      const endpoint = type === 'charge' 
        ? `/api/admin/users/${userId}/charge`
        : `/api/admin/users/${userId}/withdraw`;
      
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          amount: coinAmount,
          memo: memo.trim() || undefined,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setError(result.error || `${type === 'charge' ? '지급' : '회수'}에 실패했습니다.`);
        return;
      }

      alert(type === 'charge' ? 'MSUO가 성공적으로 지급되었습니다.' : 'MSUO가 성공적으로 회수되었습니다.');
      onSuccess();
      handleClose();
    } catch (error: any) {
      console.error('코인 처리 실패:', error);
      setError(`${type === 'charge' ? '지급' : '회수'} 중 오류가 발생했습니다.`);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setAmount('');
    setMemo('');
    setError(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-[#1e293b] border border-white/10 rounded-xl shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${type === 'charge' ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
              <Coins className={`h-5 w-5 ${type === 'charge' ? 'text-green-400' : 'text-red-400'}`} />
            </div>
            <h2 className="text-xl font-bold text-white">
              {type === 'charge' ? 'MSUO 지급' : 'MSUO 회수'}
            </h2>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-white transition-colors"
            disabled={loading}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              사용자
            </label>
            <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white">
              {username}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              현재 잔액
            </label>
            <div className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white font-medium">
              {currentBalance.toLocaleString('ko-KR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} MSUO
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {type === 'charge' ? '지급 금액 (MSUO)' : '회수 금액 (MSUO)'}
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full px-4 py-2 bg-white/5 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              placeholder="0.00"
              required
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              메모 (선택)
            </label>
            <textarea
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              className="w-full px-4 py-2 bg-white/5 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent resize-none"
              placeholder="메모를 입력하세요"
              rows={3}
              disabled={loading}
            />
          </div>

          {error && (
            <div className="p-3 bg-red-500/20 border border-red-500/50 rounded-lg text-red-300 text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={handleClose}
              disabled={loading}
              className="flex-1 px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 transition-colors disabled:opacity-50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={loading}
              className={`flex-1 px-4 py-2 rounded-lg text-white font-semibold transition-colors disabled:opacity-50 flex items-center justify-center gap-2 ${
                type === 'charge'
                  ? 'bg-green-600 hover:bg-green-700'
                  : 'bg-red-600 hover:bg-red-700'
              }`}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  처리 중...
                </>
              ) : (
                type === 'charge' ? '지급하기' : '회수하기'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

