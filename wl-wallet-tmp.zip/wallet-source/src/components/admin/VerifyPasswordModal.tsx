'use client';

import { useState, useEffect } from 'react';
import { X, Lock, Loader2, Eye, EyeOff, CheckCircle2, XCircle } from 'lucide-react';

interface VerifyPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  username: string;
  onSuccess?: () => void;
}

export default function VerifyPasswordModal({
  isOpen,
  onClose,
  userId,
  username,
  onSuccess,
}: VerifyPasswordModalProps) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isVerified, setIsVerified] = useState<boolean | null>(null);

  useEffect(() => {
    if (isOpen) {
      setPassword('');
      setShowPassword(false);
      setError(null);
      setIsVerified(null);
    }
  }, [isOpen]);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsVerified(null);

    if (!password || password.trim().length === 0) {
      setError('비밀번호를 입력해주세요.');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(`/api/admin/users/${userId}/password/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          password: password,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setError(result.error || '비밀번호가 일치하지 않습니다.');
        setIsVerified(false);
      } else {
        setIsVerified(true);
        if (onSuccess) {
          onSuccess();
        }
      }
    } catch (error: any) {
      console.error('비밀번호 확인 실패:', error);
      setError('비밀번호 확인 중 오류가 발생했습니다.');
      setIsVerified(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setPassword('');
    setShowPassword(false);
    setError(null);
    setIsVerified(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
        {/* 헤더 */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 p-2">
              <Lock className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">비밀번호 확인</h2>
              <p className="text-sm text-slate-400">{username}의 비밀번호를 확인합니다</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* 성공 메시지 */}
        {isVerified === true && (
          <div className="mb-4 rounded-lg border border-green-500/30 bg-green-500/10 p-4">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-sm font-medium text-green-400">비밀번호가 일치합니다</p>
                <p className="text-xs text-green-300 mt-1">입력하신 비밀번호가 현재 비밀번호와 일치합니다.</p>
              </div>
            </div>
          </div>
        )}

        {/* 실패 메시지 */}
        {isVerified === false && (
          <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-4">
            <div className="flex items-center gap-3">
              <XCircle className="h-5 w-5 text-red-400" />
              <div>
                <p className="text-sm font-medium text-red-400">비밀번호가 일치하지 않습니다</p>
                <p className="text-xs text-red-300 mt-1">입력하신 비밀번호가 현재 비밀번호와 일치하지 않습니다.</p>
              </div>
            </div>
          </div>
        )}

        {/* 에러 메시지 */}
        {error && isVerified === null && (
          <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* 폼 */}
        <form onSubmit={handleVerify} className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium text-slate-300">
              비밀번호 <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError(null);
                  setIsVerified(null);
                }}
                className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 pr-12 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                placeholder="확인할 비밀번호를 입력하세요"
                required
                disabled={isLoading || isVerified === true}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-300 transition"
                disabled={isLoading || isVerified === true}
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
            <p className="mt-2 text-xs text-slate-400">
              • 사용자의 현재 비밀번호를 입력하여 확인합니다
            </p>
          </div>

          {/* 버튼 */}
          <div className="mt-6 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={handleClose}
              className="rounded-lg border border-white/10 bg-slate-800/50 px-5 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
            >
              {isVerified === true ? '닫기' : '취소'}
            </button>
            {isVerified !== true && (
              <button
                type="submit"
                disabled={isLoading}
                className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-500 to-cyan-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-blue-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    확인 중...
                  </>
                ) : (
                  <>
                    <Lock className="h-4 w-4" />
                    확인하기
                  </>
                )}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

