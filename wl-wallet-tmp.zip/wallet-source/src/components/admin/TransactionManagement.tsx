'use client';

import { useState, useEffect, useCallback } from 'react';

interface Transaction {
  id: string;
  userId: string;
  username: string;
  email: string;
  walletAddress?: string;
  userRank: number;
  userBalance: number;
  type: 'STAKE' | 'UNSTAKE' | 'PURCHASE' | 'SELL' | 'WITHDRAW' | 'DEPOSIT' | 'REWARD' | 'REFUND';
  amount: number;
  fromCoin: string;
  toCoin: string;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  hash: string;
  gameId?: string;
  gameName?: string;
  gameImage?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

interface Statistics {
  totalTransactions: number;
  totalAmount: number;
  typeDistribution: Array<{
    type: string;
    count: number;
    amount: number;
    percentage: number;
  }>;
  statusDistribution: Array<{
    status: string;
    count: number;
    amount: number;
    percentage: number;
  }>;
  dailyStats: Array<{
    date: string;
    count: number;
    totalAmount: number;
  }>;
  topTransactions: Array<{
    id: string;
    amount: number;
    username: string;
    userRank: number;
    type: string;
  }>;
  averageAmount: number;
}

interface TransactionData {
  transactions: Transaction[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
  statistics: Statistics;
}

export default function TransactionManagement() {
  const [transactionData, setTransactionData] = useState<TransactionData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  // 필터링 상태
  const [filters, setFilters] = useState({
    type: 'all',
    status: 'all',
    fromCoin: 'all',
    toCoin: 'all',
    search: '',
    startDate: '',
    endDate: '',
    page: 1,
    limit: 50
  });

  // 거래 내역 조회
  const fetchTransactionData = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value && value !== 'all') {
          params.append(key, value.toString());
        }
      });

      const response = await fetch(`/api/admin/transactions?${params}`, {
        credentials: 'include',
      });

      const data = await response.json();

      if (data.ok && data.data) {
        setTransactionData(data.data);
      }
    } catch (error) {
      console.error('거래 내역 조회 실패:', error);
    } finally {
      setIsLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    fetchTransactionData();
  }, [fetchTransactionData]);

  // 거래 상세 정보 조회
  const fetchTransactionDetail = async (transactionId: string) => {
    try {
      const response = await fetch('/api/admin/transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          transactionId
        }),
      });

      const data = await response.json();

      if (data.ok && data.data) {
        const transaction = data.data.transaction;
        setSelectedTransaction({
          ...transaction,
          userBalance: transaction.users?.personalCoin || 0,
          userRank: transaction.users?.rank || 1,
          username: transaction.users?.username || '',
          email: transaction.users?.email || '',
          walletAddress: transaction.users?.walletAddress || ''
        });
        setShowDetailModal(true);
      }
    } catch (error) {
      console.error('거래 상세 정보 조회 실패:', error);
    }
  };

  // 포맷 함수들
  const formatNumber = (num: number) => {
    return num.toLocaleString('ko-KR');
  };

  const formatCurrency = (amount: number) => {
    return `${formatNumber(amount)} MSUO`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ko-KR');
  };

  const getTypeLabel = (type: string) => {
    const typeConfig: Record<string, string> = {
      STAKE: '스테이킹',
      UNSTAKE: '스테이킹 해제',
      PURCHASE: '게임 주식 구매',
      SELL: '게임 주식 판매',
      WITHDRAW: '출금',
      DEPOSIT: '입금',
      REWARD: '보상',
      REFUND: '환불'
    };

    return typeConfig[type] || type;
  };

  const getTypeBadge = (type: string) => {
    const typeConfig: Record<string, string> = {
      STAKE: 'bg-blue-500/20 text-blue-400 border border-blue-500/50',
      UNSTAKE: 'bg-orange-500/20 text-orange-400 border border-orange-500/50',
      PURCHASE: 'bg-green-500/20 text-green-400 border border-green-500/50',
      SELL: 'bg-purple-500/20 text-purple-400 border border-purple-500/50',
      WITHDRAW: 'bg-red-500/20 text-red-400 border border-red-500/50',
      DEPOSIT: 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50',
      REWARD: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50',
      REFUND: 'bg-gray-500/20 text-gray-400 border border-gray-500/50'
    };

    const className = typeConfig[type] || 'bg-gray-500/20 text-gray-400 border border-gray-500/50';

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${className}`}>
        {getTypeLabel(type)}
      </span>
    );
  };

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { label: string; className: string }> = {
      PENDING: { label: '대기중', className: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' },
      PROCESSING: { label: '처리중', className: 'bg-blue-500/20 text-blue-400 border border-blue-500/50' },
      COMPLETED: { label: '완료', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      FAILED: { label: '실패', className: 'bg-red-500/20 text-red-400 border border-red-500/50' },
      CANCELLED: { label: '취소', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' }
    };

    const config = statusConfig[status] || statusConfig.PENDING;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    );
  };

  const getRankBadge = (rank: number) => {
    const rankConfig: Record<number, { label: string; className: string }> = {
      1: { label: '브론즈', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' },
      2: { label: '실버', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      3: { label: '골드', className: 'bg-blue-500/20 text-blue-400 border border-blue-500/50' },
      4: { label: '플래티넘', className: 'bg-purple-500/20 text-purple-400 border border-purple-500/50' },
      5: { label: '다이아몬드', className: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' },
    };

    const config = rankConfig[rank] || rankConfig[1];

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    );
  };

  // 필터 변경 핸들러
  const handleFilterChange = (key: string, value: string | number) => {
    setFilters(prev => ({
      ...prev,
      [key]: value,
      ...(key !== 'page' && { page: 1 })
    }));
  };

  // 트랜잭션 해시 복사
  const copyHash = async (hash: string) => {
    try {
      await navigator.clipboard.writeText(hash);
      alert('트랜잭션 해시가 복사되었습니다.');
    } catch (error) {
      console.error('복사 실패:', error);
    }
  };

  if (isLoading && !transactionData) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">거래 내역 관리</h1>
          <p className="text-gray-400 mt-1">
            모든 거래 내역 조회 및 분석
          </p>
        </div>
      </div>

      {/* 통계 카드 */}
      {transactionData?.statistics && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">총 거래 수</p>
                <p className="text-2xl font-bold text-white">
                  {formatNumber(transactionData.statistics.totalTransactions)}
                </p>
              </div>
              <div className="bg-blue-500/20 p-3 rounded-lg">
                <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">총 거래 금액</p>
                <p className="text-2xl font-bold text-white">
                  {formatCurrency(transactionData.statistics.totalAmount)}
                </p>
              </div>
              <div className="bg-green-500/20 p-3 rounded-lg">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">평균 거래액</p>
                <p className="text-2xl font-bold text-white">
                  {formatCurrency(transactionData.statistics.averageAmount)}
                </p>
              </div>
              <div className="bg-purple-500/20 p-3 rounded-lg">
                <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
                </svg>
              </div>
            </div>
          </div>

          <div className="bg-[#1e293b] p-4 rounded-lg border border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">완료된 거래</p>
                <p className="text-2xl font-bold text-white">
                  {formatNumber(
                    transactionData.statistics.statusDistribution.find(s => s.status === 'COMPLETED')?.count || 0
                  )}
                </p>
              </div>
              <div className="bg-green-500/20 p-3 rounded-lg">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 검색 및 필터 */}
      <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-300 mb-2">검색</label>
            <input
              type="text"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              placeholder="사용자명, 이메일, 지갑주소 검색"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">거래 유형</label>
            <select
              value={filters.type}
              onChange={(e) => handleFilterChange('type', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="all">전체</option>
              <option value="STAKE">스테이킹</option>
              <option value="UNSTAKE">스테이킹 해제</option>
              <option value="PURCHASE">게임 주식 구매</option>
              <option value="SELL">게임 주식 판매</option>
              <option value="WITHDRAW">출금</option>
              <option value="DEPOSIT">입금</option>
              <option value="REWARD">보상</option>
              <option value="REFUND">환불</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">상태</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="all">전체</option>
              <option value="PENDING">대기중</option>
              <option value="PROCESSING">처리중</option>
              <option value="COMPLETED">완료</option>
              <option value="FAILED">실패</option>
              <option value="CANCELLED">취소</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">시작일</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => handleFilterChange('startDate', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">종료일</label>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => handleFilterChange('endDate', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* 거래 내역 목록 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-white/10">
          <h3 className="text-lg font-semibold text-white">거래 내역 목록</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-white/10">
            <thead className="bg-white/5">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">거래 ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">사용자</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">유형</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">금액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">경로</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">상태</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">거래일</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-300 uppercase tracking-wider">작업</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {transactionData?.transactions.map((transaction) => (
                <tr key={transaction.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-300 truncate max-w-[100px] cursor-pointer hover:text-white"
                         onClick={() => copyHash(transaction.hash)}
                         title="클릭하여 해시 복사">
                      {transaction.hash.substring(0, 8)}...
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-white">{transaction.username}</div>
                      <div className="text-sm text-gray-400">{getRankBadge(transaction.userRank)}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">{getTypeBadge(transaction.type)}</td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-white">
                      {formatCurrency(transaction.amount)}
                    </div>
                    <div className="text-xs text-gray-400">
                      {transaction.fromCoin} → {transaction.toCoin}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-300">
                      {transaction.gameName || '시스템'}
                    </div>
                  </td>
                  <td className="px-6 py-4">{getStatusBadge(transaction.status)}</td>
                  <td className="px-6 py-4 text-sm text-white">
                    {formatDate(transaction.createdAt)}
                  </td>
                  <td className="px-6 py-4 text-right text-sm font-medium">
                    <button
                      onClick={() => fetchTransactionDetail(transaction.id)}
                      className="text-blue-400 hover:text-blue-300"
                      title="상세 보기"
                    >
                      상세
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {transactionData?.transactions.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-400">거래 내역이 없습니다.</p>
          </div>
        )}
      </div>

      {/* 페이지네이션 */}
      {transactionData?.pagination && transactionData.pagination.totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-400">
            {transactionData.pagination.page} / {transactionData.pagination.totalPages} 페이지
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => handleFilterChange('page', transactionData.pagination.page - 1)}
              disabled={!transactionData.pagination.hasPrev}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              이전
            </button>
            <button
              onClick={() => handleFilterChange('page', transactionData.pagination.page + 1)}
              disabled={!transactionData.pagination.hasNext}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              다음
            </button>
          </div>
        </div>
      )}

      {/* 거래 상세 정보 모달 */}
      {showDetailModal && selectedTransaction && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-[#1e293b] rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-white">거래 상세 정보</h3>
              <button
                onClick={() => setShowDetailModal(false)}
                className="text-gray-400 hover:text-white"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="space-y-4">
              {/* 기본 정보 */}
              <div className="bg-white/5 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-300 mb-3">기본 정보</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">거래 ID:</span>
                    <span className="text-white ml-2">{selectedTransaction.hash.substring(0, 16)}...</span>
                  </div>
                  <div>
                    <span className="text-gray-400">거래 유형:</span>
                    <span className="ml-2">{getTypeBadge(selectedTransaction.type)}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">상태:</span>
                    <span className="ml-2">{getStatusBadge(selectedTransaction.status)}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">생성일:</span>
                    <span className="text-white ml-2">{formatDate(selectedTransaction.createdAt)}</span>
                  </div>
                </div>
              </div>

              {/* 금액 정보 */}
              <div className="bg-white/5 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-300 mb-3">금액 정보</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">거래 금액:</span>
                    <span className="text-white ml-2">{formatCurrency(selectedTransaction.amount)}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">경로:</span>
                    <span className="text-white ml-2">{selectedTransaction.fromCoin} → {selectedTransaction.toCoin}</span>
                  </div>
                </div>
              </div>

              {/* 사용자 정보 */}
              <div className="bg-white/5 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-gray-300 mb-3">사용자 정보</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">사용자명:</span>
                    <span className="text-white ml-2">{selectedTransaction.username}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">이메일:</span>
                    <span className="text-white ml-2">{selectedTransaction.email}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">랭크:</span>
                    <span className="ml-2">{getRankBadge(selectedTransaction.userRank)}</span>
                  </div>
                  <div>
                    <span className="text-gray-400">잔액:</span>
                    <span className="text-white ml-2">{formatCurrency(selectedTransaction.userBalance)}</span>
                  </div>
                  {selectedTransaction.walletAddress && (
                    <div className="col-span-2">
                      <span className="text-gray-400">지갑주소:</span>
                      <span className="text-white ml-2 text-xs">{selectedTransaction.walletAddress}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* 메모 */}
              {selectedTransaction.notes && (
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-300 mb-3">메모</h4>
                  <p className="text-sm text-white">{selectedTransaction.notes}</p>
                </div>
              )}

              {/* 게임 정보 */}
              {selectedTransaction.gameName && (
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-300 mb-3">연결된 게임</h4>
                  <div className="flex items-center gap-3">
                    {selectedTransaction.gameImage && (
                      <img src={selectedTransaction.gameImage} alt={selectedTransaction.gameName}
                           className="w-10 h-10 rounded-lg object-cover" />
                    )}
                    <div>
                      <div className="text-white">{selectedTransaction.gameName}</div>
                      <div className="text-xs text-gray-400">Game ID: {selectedTransaction.gameId}</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 mt-6">
              <button
                onClick={() => copyHash(selectedTransaction.hash)}
                className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
              >
                해시 복사
              </button>
              <button
                onClick={() => setShowDetailModal(false)}
                className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}