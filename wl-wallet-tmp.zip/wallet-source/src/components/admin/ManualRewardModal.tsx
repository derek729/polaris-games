'use client';

import { useState, useEffect } from 'react';
import { X, Gift, Loader2 } from 'lucide-react';
import { useI18n } from '@/lib/i18n/context';
import { RewardType } from '@prisma/client';

interface ManualRewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  username: string;
  currentBalance?: number;
  onSuccess: () => void;
}

const REWARD_TYPE_LABELS: Record<RewardType, { ko: string; en: string; zh?: string }> = {
  DAILY: { ko: '일일 수익', en: 'Daily Reward', zh: '每日收益' },
  REFERRAL: { ko: '추천 보너스', en: 'Referral Bonus', zh: '推荐奖金' },
  MATCHING: { ko: '매칭 보너스', en: 'Matching Bonus', zh: '匹配奖金' },
  RANK: { ko: '랭크 보상', en: 'Rank Reward', zh: '等级奖励' },
  TEAM: { ko: '팀 보상', en: 'Team Reward', zh: '团队奖励' },
  CENTER_FEE: { ko: '센터비', en: 'Center Fee', zh: '中心费用' },
  CENTER_INCENTIVE: { ko: '센터 개설 인센티브', en: 'Center Incentive', zh: '中心设立激励' },
};

export default function ManualRewardModal({
  isOpen,
  onClose,
  userId,
  username,
  currentBalance = 0,
  onSuccess,
}: ManualRewardModalProps) {
  const { language } = useI18n();
  const [rewardType, setRewardType] = useState<RewardType>(RewardType.DAILY);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setRewardType(RewardType.DAILY);
      setAmount('');
      setDescription('');
      setError(null);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const rewardAmount = parseFloat(amount);
    if (isNaN(rewardAmount) || rewardAmount <= 0) {
      setError(language === 'ko' ? '올바른 MSUO 코인 수량을 입력해주세요.' : 'Please enter a valid MSUO Coin amount.');
      return;
    }

    try {
      setLoading(true);
      const response = await fetch(`/api/admin/users/${userId}/reward`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          type: rewardType,
          amount: rewardAmount,
          description: description.trim() || undefined,
        }),
      });

      const result = await response.json();
      if (result.ok) {
        alert(language === 'ko' ? 'MSUO 코인이 성공적으로 지급되었습니다.' : 'MSUO Coin has been successfully paid.');
        onSuccess();
        onClose();
        setAmount('');
        setDescription('');
      } else {
        setError(result.error || (language === 'ko' ? '보상 지급에 실패했습니다.' : 'Failed to pay reward.'));
      }
    } catch (err) {
      console.error('보상 지급 실패:', err);
      setError(language === 'ko' ? '보상 지급 중 오류가 발생했습니다.' : 'Error occurred while paying reward.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-[#1e293b] rounded-xl border border-white/10 p-6 w-full max-w-md mx-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 p-2">
              <Gift className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">
                {language === 'ko' ? '수동 보상 지급' : 'Manual Reward Payment'}
              </h2>
              <p className="text-sm text-slate-400">{username}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="mb-4 p-3 bg-white/5 rounded-lg border border-white/10">
          <div className="text-sm text-gray-400 mb-1">
            {language === 'ko' ? '회원' : 'User'}
          </div>
          <div className="text-white font-medium">{username}</div>
          {currentBalance !== undefined && (
            <>
              <div className="text-sm text-gray-400 mt-2 mb-1">
                {language === 'ko' ? '현재 MSUO 코인 잔액' : 'Current MSUO Coin Balance'}
              </div>
              <div className="text-white font-medium">
                {currentBalance.toLocaleString('ko-KR', { minimumFractionDigits: 2, maximumFractionDigits: 8 })} MSUO
              </div>
            </>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '보상 타입' : 'Reward Type'} <span className="text-red-400">*</span>
            </label>
            <select
              value={rewardType}
              onChange={(e) => setRewardType(e.target.value as RewardType)}
              required
              className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              {Object.values(RewardType).map((type) => {
                const labels = REWARD_TYPE_LABELS[type];
                const label = labels[language as keyof typeof labels] || labels.en;
                return (
                  <option key={type} value={type}>
                    {label}
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? 'MSUO 코인 수량' : 'MSUO Coin Amount'} <span className="text-red-400">*</span>
            </label>
            <input
              type="number"
              step="0.00000001"
              min="0.00000001"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00000000"
              required
              className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
            <p className="mt-1 text-xs text-gray-400">
              {language === 'ko' ? '지급할 MSUO 코인 수량을 입력하세요' : 'Enter the amount of MSUO Coin to pay'}
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '설명 (선택사항)' : 'Description (Optional)'}
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={language === 'ko' ? '보상 지급 사유를 입력하세요 (예: 9일 일일 수익 재지급, 10일 일일 수익 재지급 등)...' : 'Enter reward payment reason (e.g., Re-payment for 9th daily reward, Re-payment for 10th daily reward, etc.)...'}
              rows={3}
              className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent resize-none"
            />
          </div>

          {error && (
            <div className="p-3 bg-red-900/20 text-red-200 rounded-lg border border-red-800 text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-700 rounded-lg text-gray-300 hover:bg-white/5 transition-colors"
            >
              {language === 'ko' ? '취소' : 'Cancel'}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg font-medium hover:from-blue-600 hover:to-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  {language === 'ko' ? '지급 중...' : 'Paying...'}
                </>
              ) : (
                <>
                  <Gift className="w-4 h-4" />
                  {language === 'ko' ? '지급하기' : 'Pay Reward'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

