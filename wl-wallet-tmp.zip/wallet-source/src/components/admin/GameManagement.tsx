'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';

interface Game {
  id: string;
  name: string;
  description?: string;
  imageUrl?: string;
  isActive: boolean;
  defaultPaymentPeriod: string;
  winRate?: number;
  prizeAmounts?: any;
  createdAt: string;
  updatedAt: string;
  statistics: {
    totalRevenue: number;
    unpaidRevenue: number;
    totalSharesSold: number;
    totalPurchaseAmount: number;
    activePurchases: number;
    averageSharePrice: number;
  };
  game_shares: Array<{
    id: string;
    sharePercentage: number;
    price: number;
    totalShares: number;
    availableShares: number;
    soldShares: number;
    isActive: boolean;
  }>;
  game_share_purchases: Array<{
    id: string;
    userId: string;
    shareCount: number;
    purchasePrice: number;
    status: string;
    paymentPeriod: string;
    purchasedAt: string;
    user?: {
      id: string;
      username: string;
      email: string;
    };
  }>;
}

export default function GameManagement() {
  const { t, language } = useI18n();
  const [games, setGames] = useState<Game[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [showShareForm, setShowShareForm] = useState(false);
  const [editingShare, setEditingShare] = useState<any | null>(null);
  const [shareFormData, setShareFormData] = useState({
    sharePercentage: '',
    price: '',
    totalShares: '',
  });

  // 폼 데이터 상태
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    imageUrl: '',
    winRate: '',
    prizeAmounts: '',
    defaultPaymentPeriod: 'DAILY'
  });

  // 게임 목록 조회
  const fetchGames = async () => {
    try {
      const response = await fetch('/api/admin/games?includeInactive=false');
      const result = await response.json();

      if (result.ok) {
        setGames(result.data.games);
      } else {
        console.error('게임 목록 조회 실패:', result.error);
      }
    } catch (error) {
      console.error('게임 목록 조회 오류:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // 신규 게임 생성
  const handleCreateGame = async () => {
    if (!formData.name.trim()) {
      alert('게임 이름을 입력해주세요.');
      return;
    }

    setIsCreating(true);
    try {
      const payload: any = {
        name: formData.name.trim(),
        defaultPaymentPeriod: formData.defaultPaymentPeriod
      };

      if (formData.description.trim()) {
        payload.description = formData.description.trim();
      }

      if (formData.imageUrl.trim()) {
        payload.imageUrl = formData.imageUrl.trim();
      }

      if (formData.winRate.trim()) {
        const winRate = parseFloat(formData.winRate);
        if (winRate >= 0 && winRate <= 1) {
          payload.winRate = winRate;
        } else {
          alert('승률은 0에서 1 사이의 값으로 입력해주세요.');
          return;
        }
      }

      if (formData.prizeAmounts.trim()) {
        try {
          payload.prizeAmounts = JSON.parse(formData.prizeAmounts);
        } catch (e) {
          alert('상금 정보는 유효한 JSON 형식으로 입력해주세요.');
          return;
        }
      }

      const response = await fetch('/api/admin/games', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (result.ok) {
        alert('게임 생성 완료!');
        setShowCreateForm(false);
        resetForm();
        await fetchGames();
      } else {
        alert(`게임 생성 실패: ${result.error}`);
      }
    } catch (error) {
      console.error('게임 생성 오류:', error);
      alert('게임 생성 중 오류가 발생했습니다.');
    } finally {
      setIsCreating(false);
    }
  };

  // 게임 정보 업데이트
  const handleUpdateGame = async () => {
    if (!editingGame || !formData.name.trim()) {
      alert('게임 이름을 입력해주세요.');
      return;
    }

    setIsUpdating(true);
    try {
      const payload: any = {
        name: formData.name.trim(),
        defaultPaymentPeriod: formData.defaultPaymentPeriod
      };

      if (formData.description !== editingGame.description) {
        payload.description = formData.description.trim() || null;
      }

      if (formData.imageUrl !== editingGame.imageUrl) {
        payload.imageUrl = formData.imageUrl.trim() || null;
      }

      const winRateValue = parseFloat(formData.winRate);
      if (!isNaN(winRateValue) && winRateValue >= 0 && winRateValue <= 1) {
        if (winRateValue !== editingGame.winRate) {
          payload.winRate = winRateValue;
        }
      }

      if (formData.prizeAmounts.trim()) {
        try {
          const prizeAmounts = JSON.parse(formData.prizeAmounts);
          payload.prizeAmounts = prizeAmounts;
        } catch (e) {
          alert('상금 정보는 유효한 JSON 형식으로 입력해주세요.');
          return;
        }
      }

      if (typeof payload.isActive === 'boolean' && payload.isActive !== editingGame.isActive) {
        payload.isActive = payload.isActive;
      }

      const response = await fetch(`/api/admin/games/${editingGame.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (result.ok) {
        alert('게임 정보 수정 완료!');
        setEditingGame(null);
        resetForm();
        await fetchGames();
      } else {
        alert(`게임 정보 수정 실패: ${result.error}`);
      }
    } catch (error) {
      console.error('게임 정보 수정 오류:', error);
      alert('게임 정보 수정 중 오류가 발생했습니다.');
    } finally {
      setIsUpdating(false);
    }
  };

  // 게임 상태 토글
  const handleToggleGameStatus = async (gameId: string, currentStatus: boolean) => {
    if (!confirm(`게임을 ${currentStatus ? '비활성화' : '활성화'}하시겠습니까?`)) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/games/${gameId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive: !currentStatus }),
      });

      const result = await response.json();

      if (result.ok) {
        await fetchGames();
      } else {
        alert(`상태 변경 실패: ${result.error}`);
      }
    } catch (error) {
      console.error('게임 상태 변경 오류:', error);
      alert('상태 변경 중 오류가 발생했습니다.');
    }
  };

  // 게임 삭제
  const handleDeleteGame = async (gameId: string, gameName: string) => {
    if (!confirm(`"${gameName}" 게임을 삭제하시겠습니까?\n\n활성 구매가 있는 경우 삭제할 수 없습니다.`)) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/games/${gameId}`, {
        method: 'DELETE',
      });

      const result = await response.json();

      if (result.ok) {
        alert('게임 삭제 완료!');
        await fetchGames();
      } else {
        alert(`게임 삭제 실패: ${result.error}`);
      }
    } catch (error) {
      console.error('게임 삭제 오류:', error);
      alert('게임 삭제 중 오류가 발생했습니다.');
    }
  };

  // 폼 초기화
  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      imageUrl: '',
      winRate: '',
      prizeAmounts: '',
      defaultPaymentPeriod: 'DAILY'
    });
  };

  // 폼 데이터 설정 (수정용)
  const setFormDataForEdit = (game: Game) => {
    setFormData({
      name: game.name,
      description: game.description || '',
      imageUrl: game.imageUrl || '',
      winRate: game.winRate?.toString() || '',
      prizeAmounts: game.prizeAmounts ? JSON.stringify(game.prizeAmounts, null, 2) : '',
      defaultPaymentPeriod: game.defaultPaymentPeriod
    });
  };

  // 수정 모드 시작
  const startEditGame = (game: Game) => {
    setEditingGame(game);
    setFormDataForEdit(game);
    setShowCreateForm(true);
  };

  // 폼 취소
  const cancelForm = () => {
    setShowCreateForm(false);
    setEditingGame(null);
    resetForm();
  };

  useEffect(() => {
    fetchGames();
  }, []);

  // 숫자 포맷팅
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(Math.floor(num));
  };

  // 백분율 포맷팅
  const formatPercentage = (num: number) => {
    return `${(num * 100).toFixed(2)}%`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
        <span className="ml-3 text-white">게임 데이터를 불러오는 중...</span>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* 페이지 헤더 */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">
            {language === 'ko' ? '게임 관리' : 'Game Management'}
          </h2>
          <p className="text-gray-400 text-sm">
            {language === 'ko' ? '모든 게임 설정과 승률 관리' : 'Manage all game settings and win rates'}
          </p>
        </div>
        <button
          onClick={() => setShowCreateForm(true)}
          className="px-6 py-3 bg-[#137fec] hover:bg-[#137fec]/90 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
        >
          <span className="material-symbols-outlined">add</span>
          <span>{language === 'ko' ? '게임 추가' : 'Add Game'}</span>
        </button>
      </div>

      {/* 생성/수정 폼 */}
      {showCreateForm && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-6">
            {editingGame ? (language === 'ko' ? '게임 정보 수정' : 'Edit Game') : (language === 'ko' ? '신규 게임 생성' : 'Create New Game')}
          </h3>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {language === 'ko' ? '게임 이름' : 'Game Name'} *
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder={language === 'ko' ? '게임 이름을 입력하세요' : 'Enter game name'}
                  className="w-full px-4 py-2 bg-[#101922] border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {language === 'ko' ? '승률 (0-1)' : 'Win Rate (0-1)'}
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="1"
                  value={formData.winRate}
                  onChange={(e) => setFormData({ ...formData, winRate: e.target.value })}
                  placeholder={language === 'ko' ? '예: 0.45 (45%)' : 'e.g., 0.45 (45%)'}
                  className="w-full px-4 py-2 bg-[#101922] border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {language === 'ko' ? '게임 이미지 URL' : 'Game Image URL'}
                </label>
                <input
                  type="url"
                  value={formData.imageUrl}
                  onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                  placeholder={language === 'ko' ? 'https://example.com/image.jpg' : 'https://example.com/image.jpg'}
                  className="w-full px-4 py-2 bg-[#101922] border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {language === 'ko' ? '지급주기' : 'Payment Period'}
                </label>
                <select
                  value={formData.defaultPaymentPeriod}
                  onChange={(e) => setFormData({ ...formData, defaultPaymentPeriod: e.target.value })}
                  className="w-full px-4 py-2 bg-[#101922] border border-gray-700 rounded-lg text-white focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
                >
                  <option value="DAILY">{language === 'ko' ? '일일' : 'Daily'}</option>
                  <option value="WEEKLY">{language === 'ko' ? '주간' : 'Weekly'}</option>
                  <option value="MONTHLY">{language === 'ko' ? '월간' : 'Monthly'}</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '게임 설명' : 'Game Description'}
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                placeholder={language === 'ko' ? '게임에 대한 설명을 입력하세요' : 'Enter game description'}
                className="w-full px-4 py-2 bg-[#101922] border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '상금 정보 (JSON)' : 'Prize Amounts (JSON)'}
              </label>
              <textarea
                value={formData.prizeAmounts}
                onChange={(e) => setFormData({ ...formData, prizeAmounts: e.target.value })}
                rows={4}
                placeholder={language === 'ko' ? '예: {"1등": 1000000, "2등": 500000}' : 'e.g., {"1st": 1000000, "2nd": 500000}'}
                className="w-full px-4 py-2 bg-[#101922] border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20 font-mono text-sm"
              />
              <p className="text-xs text-gray-500 mt-1">
                {language === 'ko' ? '유효한 JSON 형식으로 입력하세요' : 'Enter valid JSON format'}
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={editingGame ? handleUpdateGame : handleCreateGame}
              disabled={isCreating || isUpdating}
              className="px-6 py-2 bg-[#137fec] hover:bg-[#137fec]/90 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors"
            >
              {isCreating || isUpdating ? (
                <>
                  <span className="material-symbols-outlined animate-spin">refresh</span>
                  <span>{language === 'ko' ? '처리 중...' : 'Processing...'}</span>
                </>
              ) : (
                <>
                  <span className="material-symbols-outlined">
                    {editingGame ? 'save' : 'add'}
                  </span>
                  <span>{editingGame ? (language === 'ko' ? '수정 완료' : 'Update') : (language === 'ko' ? '생성 완료' : 'Create')}</span>
                </>
              )}
            </button>
            <button
              onClick={cancelForm}
              className="px-6 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors"
            >
              {language === 'ko' ? '취소' : 'Cancel'}
            </button>
          </div>
        </div>
      )}

      {/* 게임 목록 */}
      <div className="space-y-4">
        {games.map((game) => (
          <div key={game.id} className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
              <div className="flex-1">
                <div className="flex items-start gap-4">
                  {game.imageUrl ? (
                    <img
                      src={game.imageUrl}
                      alt={game.name}
                      className="w-16 h-16 rounded-lg object-cover bg-gray-700"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-lg bg-gray-700 flex items-center justify-center">
                      <span className="material-symbols-outlined text-gray-400">casino</span>
                    </div>
                  )}

                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-semibold text-white">{game.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        game.isActive
                          ? 'bg-green-900/20 text-green-400 border border-green-500/30'
                          : 'bg-gray-900/20 text-gray-400 border border-gray-500/30'
                      }`}>
                        {game.isActive ? (language === 'ko' ? '활성' : 'Active') : (language === 'ko' ? '비활성' : 'Inactive')}
                      </span>
                    </div>

                    {game.description && (
                      <p className="text-gray-400 text-sm mb-3">{game.description}</p>
                    )}

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-gray-500">{language === 'ko' ? '승률' : 'Win Rate'}:</span>
                        <span className="text-white font-medium ml-2">
                          {game.winRate ? formatPercentage(game.winRate) : '-'}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500">{language === 'ko' ? '지급주기' : 'Payment'}:</span>
                        <span className="text-white font-medium ml-2">
                          {game.defaultPaymentPeriod}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500">{language === 'ko' ? '총 수익' : 'Revenue'}:</span>
                        <span className="text-white font-medium ml-2">
                          {formatNumber(game.statistics.totalRevenue)} MSUO
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-500">{language === 'ko' ? '활성 구매' : 'Active'}:</span>
                        <span className="text-white font-medium ml-2">
                          {game.statistics.activePurchases}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => handleToggleGameStatus(game.id, game.isActive)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    game.isActive
                      ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
                      : 'bg-green-600 hover:bg-green-700 text-white'
                  }`}
                >
                  {game.isActive ? (language === 'ko' ? '비활성화' : 'Deactivate') : (language === 'ko' ? '활성화' : 'Activate')}
                </button>
                <button
                  onClick={() => startEditGame(game)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
                >
                  {language === 'ko' ? '수정' : 'Edit'}
                </button>
                <button
                  onClick={() => setSelectedGame(game)}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors"
                >
                  {language === 'ko' ? '상세' : 'Details'}
                </button>
                <button
                  onClick={() => handleDeleteGame(game.id, game.name)}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
                >
                  {language === 'ko' ? '삭제' : 'Delete'}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {games.length === 0 && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-12 text-center">
          <span className="material-symbols-outlined text-6xl text-gray-400 mb-4">
            casino
          </span>
          <p className="text-gray-400">
            {language === 'ko' ? '등록된 게임이 없습니다.' : 'No games registered.'}
          </p>
          <button
            onClick={() => setShowCreateForm(true)}
            className="mt-4 px-6 py-2 bg-[#137fec] hover:bg-[#137fec]/90 text-white rounded-lg font-medium transition-colors"
          >
            {language === 'ko' ? '첫 번째 게임 추가하기' : 'Add First Game'}
          </button>
        </div>
      )}

      {/* 게임 상세 정보 모달 */}
      {selectedGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-[#1e293b] border border-white/10 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between items-start mb-6">
              <h3 className="text-2xl font-bold text-white">{selectedGame.name}</h3>
              <button
                onClick={() => setSelectedGame(null)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {selectedGame.imageUrl && (
              <div className="mb-6">
                <img
                  src={selectedGame.imageUrl}
                  alt={selectedGame.name}
                  className="w-full h-64 object-cover rounded-lg bg-gray-700"
                />
              </div>
            )}

            <div className="space-y-6">
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">{language === 'ko' ? '기본 정보' : 'Basic Information'}</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">{language === 'ko' ? '승률' : 'Win Rate'}:</span>
                    <span className="text-white font-medium ml-2">
                      {selectedGame.winRate ? formatPercentage(selectedGame.winRate) : '-'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">{language === 'ko' ? '지급주기' : 'Payment Period'}:</span>
                    <span className="text-white font-medium ml-2">
                      {selectedGame.defaultPaymentPeriod}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">{language === 'ko' ? '상태' : 'Status'}:</span>
                    <span className="text-white font-medium ml-2">
                      {selectedGame.isActive ? (language === 'ko' ? '활성' : 'Active') : (language === 'ko' ? '비활성' : 'Inactive')}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">{language === 'ko' ? '생성일' : 'Created'}:</span>
                    <span className="text-white font-medium ml-2">
                      {new Date(selectedGame.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>

              {selectedGame.description && (
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">{language === 'ko' ? '설명' : 'Description'}</h4>
                  <p className="text-gray-300">{selectedGame.description}</p>
                </div>
              )}

              <div>
                <h4 className="text-lg font-semibold text-white mb-2">{language === 'ko' ? '통계 정보' : 'Statistics'}</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">{language === 'ko' ? '총 수익' : 'Total Revenue'}:</span>
                    <span className="text-white font-medium ml-2">
                      {formatNumber(selectedGame.statistics.totalRevenue)} MSUO
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">{language === 'ko' ? '미지급 수익' : 'Unpaid'}:</span>
                    <span className="text-white font-medium ml-2">
                      {formatNumber(selectedGame.statistics.unpaidRevenue)} MSUO
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">{language === 'ko' ? '활성 구매' : 'Active Purchases'}:</span>
                    <span className="text-white font-medium ml-2">
                      {selectedGame.statistics.activePurchases}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">{language === 'ko' ? '판매된 주식' : 'Shares Sold'}:</span>
                    <span className="text-white font-medium ml-2">
                      {formatNumber(selectedGame.statistics.totalSharesSold)}
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-lg font-semibold text-white">{language === 'ko' ? '게임 주식' : 'Game Shares'}</h4>
                  <button
                    onClick={() => {
                      setEditingShare(null);
                      setShareFormData({ sharePercentage: '', price: '', totalShares: '' });
                      setShowShareForm(true);
                    }}
                    className="px-3 py-1 bg-[#137fec] hover:bg-[#137fec]/90 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-1"
                  >
                    <span className="material-symbols-outlined text-sm">add</span>
                    {language === 'ko' ? '주식 추가' : 'Add Share'}
                  </button>
                </div>

                {showShareForm && (
                  <div className="mb-4 p-4 bg-white/5 rounded-lg border border-white/10">
                    <h5 className="text-sm font-semibold text-white mb-3">
                      {editingShare ? (language === 'ko' ? '주식 수정' : 'Edit Share') : (language === 'ko' ? '주식 추가' : 'Add Share')}
                    </h5>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">{language === 'ko' ? '지분율 (%)' : 'Share %'}</label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          max="100"
                          value={shareFormData.sharePercentage}
                          onChange={(e) => setShareFormData({ ...shareFormData, sharePercentage: e.target.value })}
                          className="w-full px-3 py-2 bg-[#101922] border border-gray-700 rounded text-white text-sm focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
                          placeholder="1.0"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">{language === 'ko' ? '가격 (MSUO)' : 'Price (MSUO)'}</label>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={shareFormData.price}
                          onChange={(e) => setShareFormData({ ...shareFormData, price: e.target.value })}
                          className="w-full px-3 py-2 bg-[#101922] border border-gray-700 rounded text-white text-sm focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
                          placeholder="1000"
                        />
                      </div>
                      <div>
                        <label className="block text-xs text-gray-400 mb-1">{language === 'ko' ? '총 주식 수' : 'Total Shares'}</label>
                        <input
                          type="number"
                          min="1"
                          value={shareFormData.totalShares}
                          onChange={(e) => setShareFormData({ ...shareFormData, totalShares: e.target.value })}
                          className="w-full px-3 py-2 bg-[#101922] border border-gray-700 rounded text-white text-sm focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
                          placeholder="100"
                        />
                      </div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <button
                        onClick={async () => {
                          if (!shareFormData.sharePercentage || !shareFormData.price || !shareFormData.totalShares) {
                            alert(language === 'ko' ? '모든 필드를 입력해주세요.' : 'Please fill in all fields.');
                            return;
                          }

                          try {
                            const url = editingShare
                              ? `/api/admin/games/${selectedGame!.id}/game_shares/${editingShare.id}`
                              : `/api/admin/games/${selectedGame!.id}/game_shares`;

                            const response = await fetch(url, {
                              method: editingShare ? 'PUT' : 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({
                                sharePercentage: parseFloat(shareFormData.sharePercentage),
                                price: parseFloat(shareFormData.price),
                                totalShares: parseInt(shareFormData.totalShares),
                              }),
                            });

                            const result = await response.json();

                            if (result.ok) {
                              alert(result.message || (language === 'ko' ? '주식이 저장되었습니다.' : 'Share saved.'));
                              setShowShareForm(false);
                              setEditingShare(null);
                              setShareFormData({ sharePercentage: '', price: '', totalShares: '' });
                              await fetchGames();
                              // 상세 정보 새로고침
                              const detailResponse = await fetch(`/api/admin/games/${selectedGame!.id}`);
                              const detailResult = await detailResponse.json();
                              if (detailResult.ok) {
                                setSelectedGame(detailResult.data.game);
                              }
                            } else {
                              alert(result.error || (language === 'ko' ? '저장 실패' : 'Save failed'));
                            }
                          } catch (error) {
                            console.error('주식 저장 오류:', error);
                            alert(language === 'ko' ? '저장 중 오류가 발생했습니다.' : 'An error occurred while saving.');
                          }
                        }}
                        className="px-3 py-1 bg-[#137fec] hover:bg-[#137fec]/90 text-white rounded text-sm font-medium transition-colors"
                      >
                        {language === 'ko' ? '저장' : 'Save'}
                      </button>
                      <button
                        onClick={() => {
                          setShowShareForm(false);
                          setEditingShare(null);
                          setShareFormData({ sharePercentage: '', price: '', totalShares: '' });
                        }}
                        className="px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white rounded text-sm font-medium transition-colors"
                      >
                        {language === 'ko' ? '취소' : 'Cancel'}
                      </button>
                    </div>
                  </div>
                )}

                {selectedGame.game_shares.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                      <thead className="bg-gray-800">
                        <tr>
                          <th className="px-4 py-2">{language === 'ko' ? '지분율' : 'Share %'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '가격' : 'Price'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '전체' : 'Total'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '판매됨' : 'Sold'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '남은' : 'Available'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '상태' : 'Status'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '작업' : 'Actions'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {selectedGame.game_shares.map((share) => (
                          <tr key={share.id} className="border-b border-gray-700">
                            <td className="px-4 py-2">{share.sharePercentage}%</td>
                            <td className="px-4 py-2">{formatNumber(share.price)} MSUO</td>
                            <td className="px-4 py-2">{share.totalShares}</td>
                            <td className="px-4 py-2">{share.soldShares}</td>
                            <td className="px-4 py-2">{share.availableShares}</td>
                            <td className="px-4 py-2">
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                share.isActive
                                  ? 'bg-green-900/20 text-green-400'
                                  : 'bg-gray-900/20 text-gray-400'
                              }`}>
                                {share.isActive ? (language === 'ko' ? '활성' : 'Active') : (language === 'ko' ? '비활성' : 'Inactive')}
                              </span>
                            </td>
                            <td className="px-4 py-2">
                              <div className="flex gap-1">
                                <button
                                  onClick={() => {
                                    setEditingShare(share);
                                    setShareFormData({
                                      sharePercentage: share.sharePercentage.toString(),
                                      price: share.price.toString(),
                                      totalShares: share.totalShares.toString(),
                                    });
                                    setShowShareForm(true);
                                  }}
                                  className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs transition-colors"
                                >
                                  {language === 'ko' ? '수정' : 'Edit'}
                                </button>
                                <button
                                  onClick={async () => {
                                    if (!confirm(language === 'ko' ? '이 주식을 삭제하시겠습니까?' : 'Delete this share?')) {
                                      return;
                                    }

                                    try {
                                      const response = await fetch(`/api/admin/games/${selectedGame!.id}/game_shares/${share.id}`, {
                                        method: 'DELETE',
                                      });

                                      const result = await response.json();

                                      if (result.ok) {
                                        alert(result.message || (language === 'ko' ? '주식이 삭제되었습니다.' : 'Share deleted.'));
                                        await fetchGames();
                                        // 상세 정보 새로고침
                                        const detailResponse = await fetch(`/api/admin/games/${selectedGame!.id}`);
                                        const detailResult = await detailResponse.json();
                                        if (detailResult.ok) {
                                          setSelectedGame(detailResult.data.game);
                                        }
                                      } else {
                                        alert(result.error || (language === 'ko' ? '삭제 실패' : 'Delete failed'));
                                      }
                                    } catch (error) {
                                      console.error('주식 삭제 오류:', error);
                                      alert(language === 'ko' ? '삭제 중 오류가 발생했습니다.' : 'An error occurred while deleting.');
                                    }
                                  }}
                                  className="px-2 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs transition-colors"
                                >
                                  {language === 'ko' ? '삭제' : 'Delete'}
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-gray-400 text-sm">{language === 'ko' ? '등록된 주식이 없습니다.' : 'No game_shares registered.'}</p>
                )}
              </div>

              {selectedGame.game_share_purchases.length > 0 && (
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">{language === 'ko' ? '최근 구매' : 'Recent Purchases'}</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                      <thead className="bg-gray-800">
                        <tr>
                          <th className="px-4 py-2">{language === 'ko' ? '사용자' : 'User'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '수량' : 'Quantity'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '가격' : 'Price'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '상태' : 'Status'}</th>
                          <th className="px-4 py-2">{language === 'ko' ? '구매일' : 'Date'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {selectedGame.game_share_purchases.map((purchase) => (
                          <tr key={purchase.id} className="border-b border-gray-700">
                            <td className="px-4 py-2">
                              <div className="text-white">
                                {purchase.user?.username || purchase.user?.email || 'Unknown'}
                              </div>
                            </td>
                            <td className="px-4 py-2">{purchase.shareCount}</td>
                            <td className="px-4 py-2">{formatNumber(purchase.purchasePrice)} MSUO</td>
                            <td className="px-4 py-2">
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                purchase.status === 'ACTIVE'
                                  ? 'bg-green-900/20 text-green-400'
                                  : 'bg-gray-900/20 text-gray-400'
                              }`}>
                                {purchase.status}
                              </span>
                            </td>
                            <td className="px-4 py-2">
                              {purchase.purchasedAt ? new Date(purchase.purchasedAt).toLocaleDateString() : '-'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}