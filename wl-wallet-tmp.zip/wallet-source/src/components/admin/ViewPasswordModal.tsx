'use client';

import { useState, useEffect } from 'react';
import { X, Lock, Loader2, Eye, EyeOff, RefreshCw, AlertCircle } from 'lucide-react';
import UpdatePasswordModal from './UpdatePasswordModal';

interface ViewPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  username: string;
  onSuccess?: () => void;
}

interface PasswordInfo {
  hasPassword: boolean;
  passwordHash: string | null;
  passwordLength: number;
}

export default function ViewPasswordModal({
  isOpen,
  onClose,
  userId,
  username,
  onSuccess,
}: ViewPasswordModalProps) {
  const [passwordInfo, setPasswordInfo] = useState<PasswordInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showHash, setShowHash] = useState(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchPasswordInfo();
    } else {
      setPasswordInfo(null);
      setShowHash(false);
      setError(null);
    }
  }, [isOpen, userId]);

  const fetchPasswordInfo = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/admin/users/${userId}/password/info`, {
        method: 'GET',
        credentials: 'include',
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setError(result.error || '비밀번호 정보를 불러올 수 없습니다.');
        return;
      }

      setPasswordInfo(result.data);
    } catch (error: any) {
      console.error('비밀번호 정보 조회 실패:', error);
      setError('비밀번호 정보 조회 중 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setPasswordInfo(null);
    setShowHash(false);
    setError(null);
    onClose();
  };

  const handleUpdateSuccess = () => {
    fetchPasswordInfo();
    setIsUpdateModalOpen(false);
    if (onSuccess) {
      onSuccess();
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
        <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
          {/* 헤더 */}
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 p-2">
                <Lock className="h-5 w-5 text-purple-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">비밀번호 정보</h2>
                <p className="text-sm text-slate-400">{username}의 비밀번호 정보</p>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* 에러 메시지 */}
          {error && (
            <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                {error}
              </div>
            </div>
          )}

          {/* 로딩 */}
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-purple-400" />
            </div>
          )}

          {/* 비밀번호 정보 */}
          {!isLoading && passwordInfo && (
            <div className="space-y-4">
              {/* 비밀번호 상태 */}
              <div className="rounded-lg border border-white/10 bg-slate-800/50 p-4">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-slate-300">비밀번호 상태</label>
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      passwordInfo.hasPassword
                        ? 'bg-green-500/20 text-green-400 border border-green-500/50'
                        : 'bg-gray-500/20 text-gray-400 border border-gray-500/50'
                    }`}
                  >
                    {passwordInfo.hasPassword ? '설정됨' : '미설정'}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {passwordInfo.hasPassword
                    ? '비밀번호가 설정되어 있습니다.'
                    : '비밀번호가 설정되지 않았습니다.'}
                </p>
              </div>

              {/* 비밀번호 해시 */}
              {passwordInfo.hasPassword && (
                <div className="rounded-lg border border-white/10 bg-slate-800/50 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm font-medium text-slate-300">비밀번호 해시</label>
                    <button
                      type="button"
                      onClick={() => setShowHash(!showHash)}
                      className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1"
                    >
                      {showHash ? (
                        <>
                          <EyeOff className="h-3 w-3" />
                          숨기기
                        </>
                      ) : (
                        <>
                          <Eye className="h-3 w-3" />
                          보기
                        </>
                      )}
                    </button>
                  </div>
                  {showHash ? (
                    <div className="mt-2 p-3 bg-slate-900/50 rounded-lg border border-white/5">
                      <p className="text-xs font-mono text-slate-300 break-all">
                        {passwordInfo.passwordHash}
                      </p>
                      <p className="text-xs text-slate-500 mt-2">
                        해시 길이: {passwordInfo.passwordLength}자
                      </p>
                    </div>
                  ) : (
                    <div className="mt-2 p-3 bg-slate-900/50 rounded-lg border border-white/5">
                      <p className="text-xs text-slate-500">••••••••</p>
                    </div>
                  )}
                  <p className="text-xs text-slate-400 mt-2">
                    ⚠️ 비밀번호는 해시로 저장되어 원본을 복원할 수 없습니다.
                  </p>
                </div>
              )}

              {/* 안내 메시지 */}
              <div className="rounded-lg border border-yellow-500/30 bg-yellow-500/10 p-3">
                <p className="text-xs text-yellow-400">
                  💡 비밀번호를 변경하거나 재설정하려면 아래 버튼을 사용하세요.
                </p>
              </div>

              {/* 버튼 */}
              <div className="mt-6 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={fetchPasswordInfo}
                  className="flex items-center gap-2 rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
                >
                  <RefreshCw className="h-4 w-4" />
                  새로고침
                </button>
                <button
                  type="button"
                  onClick={() => setIsUpdateModalOpen(true)}
                  className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-purple-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-purple-500/50"
                >
                  <Lock className="h-4 w-4" />
                  비밀번호 변경
                </button>
              </div>
            </div>
          )}

          {/* 비밀번호 정보가 없을 때 */}
          {!isLoading && !passwordInfo && !error && (
            <div className="text-center py-8 text-slate-400">
              <p>비밀번호 정보를 불러올 수 없습니다.</p>
            </div>
          )}
        </div>
      </div>

      {/* 비밀번호 변경 모달 */}
      <UpdatePasswordModal
        isOpen={isUpdateModalOpen}
        onClose={() => setIsUpdateModalOpen(false)}
        userId={userId}
        username={username}
        onSuccess={handleUpdateSuccess}
      />
    </>
  );
}

