'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';

interface StakingRecord {
  id: string;
  userId: string;
  username?: string;
  email?: string;
  userRank?: number;
  mainnetAddress?: string;
  validatorAddress?: string;
  txHash?: string;
  stakedAmount: number;
  rewardAmount: number;
  apy?: number;
  angelLockAmount: number;
  startDate: string;
  endDate?: string;
  lockPeriod?: number;
  status: string;
  confirmations: number;
  stakedAt: string;
  unstakedAt?: string;
  confirmedAt?: string;
  createdAt: string;
  updatedAt: string;
}

interface StakingStatistics {
  overview: {
    totalStaked: number;
    totalRewards: number;
    totalRecords: number;
    recentStaked: number;
    recentRecords: number;
  };
  statusDistribution: Array<{
    status: string;
    count: number;
    stakedAmount: number;
    rewardAmount: number;
    percentage: number;
  }>;
  topStakers: Array<{
    userId: string;
    username?: string;
    email?: string;
    rank?: number;
    stakedAmount: number;
    apy?: number;
    lockPeriod?: number;
    status: string;
  }>;
  averageMetrics: {
    averageStakePerUser: number;
    averageApy: number;
    averageLockPeriod: number;
  };
}

export default function StakingManagement() {
  const { t, language } = useI18n();
  const [records, setRecords] = useState<StakingRecord[]>([]);
  const [statistics, setStatistics] = useState<StakingStatistics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);
  const [selectedRecords, setSelectedRecords] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // 스테이킹 레코드 조회
  const fetchStakingRecords = async (page = 1) => {
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '20',
        ...(statusFilter !== 'all' && { status: statusFilter }),
        ...(searchTerm && { search: searchTerm })
      });

      const response = await fetch(`/api/admin/staking/records?${params}`);
      const result = await response.json();

      if (result.ok) {
        setRecords(result.data.records);
        setTotalPages(result.data.pagination.totalPages);
        setTotalRecords(result.data.pagination.total);
        setCurrentPage(result.data.pagination.page);
      } else {
        console.error('스테이킹 레코드 조회 실패:', result.error);
      }
    } catch (error) {
      console.error('스테이킹 레코드 조회 오류:', error);
    }
  };

  // 스테이킹 통계 조회
  const fetchStatistics = async () => {
    try {
      const response = await fetch('/api/admin/staking/statistics');
      const result = await response.json();

      if (result.ok) {
        setStatistics(result.data);
      } else {
        console.error('스테이킹 통계 조회 실패:', result.error);
      }
    } catch (error) {
      console.error('스테이킹 통계 조회 오류:', error);
    }
  };

  // 레코드 승인/거절 처리
  const handleApprove = async (action: 'APPROVE' | 'REJECT') => {
    if (selectedRecords.length === 0) {
      alert(`처리할 레코드를 선택해주세요.`);
      return;
    }

    if (!confirm(`${action === 'APPROVE' ? '승인' : '거절'}하시겠습니까? (${selectedRecords.length}개)`)) {
      return;
    }

    setIsUpdating(true);
    try {
      const response = await fetch('/api/admin/staking/approve', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recordIds: selectedRecords,
          action
        }),
      });

      const result = await response.json();

      if (result.ok) {
        alert(`${action === 'APPROVE' ? '승인' : '거절'} 완료: ${result.data.successCount}개 성공, ${result.data.failureCount}개 실패`);
        setSelectedRecords([]);
        await fetchStakingRecords(currentPage);
        await fetchStatistics();
      } else {
        alert(`처리 실패: ${result.error}`);
      }
    } catch (error) {
      console.error('레코드 처리 오류:', error);
      alert('처리 중 오류가 발생했습니다.');
    } finally {
      setIsUpdating(false);
    }
  };

  // 페이지 변경
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    fetchStakingRecords(page);
  };

  // 필터 변경
  const handleFilterChange = (filter: string, value: string) => {
    if (filter === 'status') {
      setStatusFilter(value);
    } else if (filter === 'search') {
      setSearchTerm(value);
    }
    setCurrentPage(1);
  };

  // 검색 실행
  const handleSearch = () => {
    setCurrentPage(1);
    fetchStakingRecords(1);
  };

  // 레코드 선택/해제
  const handleRecordSelect = (recordId: string) => {
    setSelectedRecords(prev =>
      prev.includes(recordId)
        ? prev.filter(id => id !== recordId)
        : [...prev, recordId]
    );
  };

  // 전체 선택/해제
  const handleSelectAll = () => {
    if (selectedRecords.length === records.length) {
      setSelectedRecords([]);
    } else {
      setSelectedRecords(records.map(record => record.id));
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await Promise.all([
        fetchStakingRecords(1),
        fetchStatistics()
      ]);
      setIsLoading(false);
    };

    loadData();
  }, []);

  // 숫자 포맷팅
  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(Math.floor(num));
  };

  // 억 단위 포맷팅
  const formatBillion = (num: number) => {
    const billions = num / 100000000;
    return `${billions.toFixed(1)}억`;
  };

  // 상태 색상
  const getStatusColor = (status: string) => {
    const colors: { [key: string]: string } = {
      'PENDING': 'text-yellow-400 bg-yellow-900/20 border-yellow-500/30',
      'ACTIVE': 'text-green-400 bg-green-900/20 border-green-500/30',
      'UNSTAKING': 'text-blue-400 bg-blue-900/20 border-blue-500/30',
      'COMPLETED': 'text-gray-400 bg-gray-900/20 border-gray-500/30',
      'REJECTED': 'text-red-400 bg-red-900/20 border-red-500/30'
    };
    return colors[status] || 'text-gray-400 bg-gray-900/20 border-gray-500/30';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
        <span className="ml-3 text-white">스테이킹 데이터를 불러오는 중...</span>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* 페이지 헤더 */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">
            {language === 'ko' ? '스테이킹 관리' : 'Staking Management'}
          </h2>
          <p className="text-gray-400 text-sm">
            {language === 'ko' ? '모든 스테이킹 레코드를 관리하고 승인/거절 처리' : 'Manage all staking records and approve/reject requests'}
          </p>
        </div>
      </div>

      {/* 통계 카드 */}
      {statistics && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">
                {language === 'ko' ? '총 스테이킹' : 'Total Staked'}
              </span>
              <span className="material-symbols-outlined text-blue-400">account_balance</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {formatBillion(statistics.overview.totalStaked)} MSUO
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {statistics.overview.totalRecords.toLocaleString()} {language === 'ko' ? '건' : 'records'}
            </div>
          </div>

          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">
                {language === 'ko' ? '총 리워드' : 'Total Rewards'}
              </span>
              <span className="material-symbols-outlined text-green-400">moving</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {formatBillion(statistics.overview.totalRewards)} MSUO
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {language === 'ko' ? '지급된 보상' : 'Distributed rewards'}
            </div>
          </div>

          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">
                {language === 'ko' ? '평균 스테이킹' : 'Average Stake'}
              </span>
              <span className="material-symbols-outlined text-purple-400">bar_chart</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {formatBillion(statistics.averageMetrics.averageStakePerUser)} MSUO
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {language === 'ko' ? '사용자당 평균' : 'Per user average'}
            </div>
          </div>

          <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-400 text-sm">
                {language === 'ko' ? '평균 APY' : 'Average APY'}
              </span>
              <span className="material-symbols-outlined text-orange-400">percent</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {statistics.averageMetrics.averageApy.toFixed(1)}%
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {language === 'ko' ? '연 이율' : 'Annual percentage'}
            </div>
          </div>
        </div>
      )}

      {/* 상태별 분포 */}
      {statistics && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">
            {language === 'ko' ? '상태별 분포' : 'Status Distribution'}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {statistics.statusDistribution.map(status => (
              <div key={status.status} className="text-center">
                <div className={`px-3 py-1 rounded-lg border text-sm font-medium ${getStatusColor(status.status)}`}>
                  {status.status}
                </div>
                <div className="mt-2 text-white font-bold">
                  {status.count.toLocaleString()}
                </div>
                <div className="text-xs text-gray-400">
                  {status.percentage.toFixed(1)}%
                </div>
                <div className="text-xs text-gray-500">
                  {formatBillion(status.stakedAmount)} MSUO
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 필터 및 검색 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-400 mb-2">
              {language === 'ko' ? '상태 필터' : 'Status Filter'}
            </label>
            <select
              value={statusFilter}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="w-full px-4 py-2 bg-[#101922] border border-gray-700 rounded-lg text-white focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
            >
              <option value="all">{language === 'ko' ? '전체' : 'All'}</option>
              <option value="PENDING">{language === 'ko' ? '대기중' : 'Pending'}</option>
              <option value="ACTIVE">{language === 'ko' ? '활성' : 'Active'}</option>
              <option value="UNSTAKING">{language === 'ko' ? '해제중' : 'Unstaking'}</option>
              <option value="COMPLETED">{language === 'ko' ? '완료' : 'Completed'}</option>
              <option value="REJECTED">{language === 'ko' ? '거절' : 'Rejected'}</option>
            </select>
          </div>

          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-400 mb-2">
              {language === 'ko' ? '사용자 검색' : 'Search Users'}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder={language === 'ko' ? '사용자명 또는 이메일' : 'Username or email'}
                className="flex-1 px-4 py-2 bg-[#101922] border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-[#137fec] focus:ring-2 focus:ring-[#137fec]/20"
              />
              <button
                onClick={handleSearch}
                className="px-4 py-2 bg-[#137fec] hover:bg-[#137fec]/90 text-white rounded-lg font-medium transition-colors"
              >
                {language === 'ko' ? '검색' : 'Search'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 작업 버튼 */}
      {selectedRecords.length > 0 && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <span className="text-white">
              {selectedRecords.length}개 {language === 'ko' ? '레코드 선택됨' : 'records selected'}
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => handleApprove('APPROVE')}
                disabled={isUpdating}
                className="px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
              >
                {isUpdating ? (
                  <>
                    <span className="material-symbols-outlined animate-spin">refresh</span>
                    <span>{language === 'ko' ? '처리 중...' : 'Processing...'}</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined">check_circle</span>
                    <span>{language === 'ko' ? '승인' : 'Approve'}</span>
                  </>
                )}
              </button>
              <button
                onClick={() => handleApprove('REJECT')}
                disabled={isUpdating}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors flex items-center gap-2"
              >
                <span className="material-symbols-outlined">cancel</span>
                <span>{language === 'ko' ? '거절' : 'Reject'}</span>
              </button>
              <button
                onClick={() => setSelectedRecords([])}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors"
              >
                {language === 'ko' ? '선택 해제' : 'Clear'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 스테이킹 레코드 목록 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-300">
            <thead className="text-xs text-gray-400 uppercase bg-gray-800">
              <tr>
                <th className="px-4 py-3">
                  <input
                    type="checkbox"
                    checked={selectedRecords.length === records.length && records.length > 0}
                    onChange={handleSelectAll}
                    className="w-4 h-4 text-[#137fec] bg-gray-700 border-gray-600 rounded focus:ring-[#137fec] focus:ring-2"
                  />
                </th>
                <th className="px-4 py-3">
                  {language === 'ko' ? '사용자' : 'User'}
                </th>
                <th className="px-4 py-3">
                  {language === 'ko' ? '스테이킹 양' : 'Amount'}
                </th>
                <th className="px-4 py-3">
                  {language === 'ko' ? 'APY' : 'APY'}
                </th>
                <th className="px-4 py-3">
                  {language === 'ko' ? '기간' : 'Period'}
                </th>
                <th className="px-4 py-3">
                  {language === 'ko' ? '상태' : 'Status'}
                </th>
                <th className="px-4 py-3">
                  {language === 'ko' ? '시작일' : 'Start Date'}
                </th>
                <th className="px-4 py-3">
                  {language === 'ko' ? 'TX Hash' : 'Transaction'}
                </th>
              </tr>
            </thead>
            <tbody>
              {records.map((record) => (
                <tr key={record.id} className="border-b border-gray-700 hover:bg-white/5">
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      checked={selectedRecords.includes(record.id)}
                      onChange={() => handleRecordSelect(record.id)}
                      className="w-4 h-4 text-[#137fec] bg-gray-700 border-gray-600 rounded focus:ring-[#137fec] focus:ring-2"
                    />
                  </td>
                  <td className="px-4 py-3">
                    <div>
                      <div className="text-white font-medium">
                        {record.username || 'Unknown'}
                      </div>
                      <div className="text-xs text-gray-400">
                        {record.email}
                      </div>
                      {record.userRank && (
                        <div className="text-xs text-purple-400">
                          {record.userRank}성
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-white font-medium">
                      {formatBillion(record.stakedAmount)} MSUO
                    </div>
                    {record.angelLockAmount > 0 && (
                      <div className="text-xs text-orange-400">
                        Angel Lock: {formatBillion(record.angelLockAmount)}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {record.apy ? (
                      <span className="text-green-400">{record.apy.toFixed(1)}%</span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {record.lockPeriod ? (
                      <span>{record.lockPeriod}일</span>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-lg border text-xs font-medium ${getStatusColor(record.status)}`}>
                      {record.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {new Date(record.stakedAt).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3">
                    {record.txHash ? (
                      <a
                        href={`https://etherscan.io/tx/${record.txHash}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-400 hover:text-blue-300 text-xs font-mono"
                      >
                        {record.txHash.slice(0, 8)}...
                      </a>
                    ) : (
                      <span className="text-gray-400">-</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {records.length === 0 && (
          <div className="text-center py-12">
            <span className="material-symbols-outlined text-6xl text-gray-400">
              account_balance_wallet
            </span>
            <p className="text-gray-400 mt-4">
              {language === 'ko' ? '스테이킹 레코드가 없습니다.' : 'No staking records found.'}
            </p>
          </div>
        )}

        {/* 페이지네이션 */}
        {totalPages > 1 && (
          <div className="flex justify-between items-center p-4 border-t border-gray-700">
            <div className="text-sm text-gray-400">
              {language === 'ko' ? '총' : 'Total'} {totalRecords} {language === 'ko' ? '개' : 'records'}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="px-3 py-1 bg-[#101922] border border-gray-700 rounded-lg text-white disabled:opacity-50 disabled:cursor-not-allowed hover:border-[#137fec]"
              >
                {language === 'ko' ? '이전' : 'Previous'}
              </button>
              <span className="px-4 py-1 text-white">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="px-3 py-1 bg-[#101922] border border-gray-700 rounded-lg text-white disabled:opacity-50 disabled:cursor-not-allowed hover:border-[#137fec]"
              >
                {language === 'ko' ? '다음' : 'Next'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 상위 스테이커 */}
      {statistics && statistics.topStakers.length > 0 && (
        <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">
            {language === 'ko' ? '상위 스테이커' : 'Top Stakers'}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {statistics.topStakers.slice(0, 9).map((staker, index) => (
              <div key={staker.userId} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                <div className="w-8 h-8 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {index + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white font-medium truncate">
                    {staker.username || staker.email || 'Unknown'}
                  </div>
                  <div className="text-xs text-gray-400">
                    {formatBillion(staker.stakedAmount)} MSUO
                  </div>
                  {staker.apy && (
                    <div className="text-xs text-green-400">
                      {staker.apy.toFixed(1)}% APY
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}