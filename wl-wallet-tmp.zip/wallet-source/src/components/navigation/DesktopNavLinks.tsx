'use client';

import { useState, useRef, useEffect, ReactNode } from 'react';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n/context';
import { cn } from '@/lib/utils';

interface DesktopNavLinksProps {
  currentPath: string;
}

const isActivePath = (currentPath: string, href: string) => {
  if (href === '/') {
    return currentPath === '/';
  }
  return currentPath === href || currentPath.startsWith(`${href}/`);
};

// ============================================
// 네비게이션 아이템 타입
// ============================================
interface NavItem {
  href: string;
  label: string;
  icon?: string;
  badge?: string | number;
  children?: NavItem[];
}

// ============================================
// 메인 네비게이션 컴포넌트
// ============================================
export default function DesktopNavLinks({ currentPath }: DesktopNavLinksProps) {
  const { t } = useI18n();

  const navItems: NavItem[] = [
    { href: '/', label: '지갑', icon: 'account_balance_wallet' },
    { href: '/my-profile', label: '내 프로필', icon: 'person' },
    { href: '/transfer', label: '전송', icon: 'send_money' },
    { href: '/transactions', label: '거래내역', icon: 'receipt_long' },
    { href: '/games', label: t.common.games || 'Games', icon: 'sports_esports' },
    { href: '/staking', label: '스테이킹', icon: 'account_balance' },
    { href: '/about', label: '재단', icon: 'business' },
    { href: '/whitepaper', label: '백서', icon: 'description' },
    { href: '/contact', label: '문의', icon: 'mail' },
  ];

  return (
    <nav className="hidden md:flex items-center gap-1 lg:gap-2 min-w-0">
      {navItems.map((item) => {
        const active = isActivePath(currentPath, item.href);
        
        if (item.children && item.children.length > 0) {
          return (
            <NavDropdown
              key={item.href}
              item={item}
              currentPath={currentPath}
            />
          );
        }

        return (
          <NavLink
            key={item.href}
            href={item.href}
            label={item.label}
            icon={item.icon}
            badge={item.badge}
            active={active}
          />
        );
      })}
    </nav>
  );
}

// ============================================
// 개별 네비게이션 링크
// ============================================
interface NavLinkProps {
  href: string;
  label: string;
  icon?: string;
  badge?: string | number;
  active?: boolean;
}

function NavLink({ href, label, icon, badge, active }: NavLinkProps) {
  return (
    <Link
      href={href}
      className={cn(
        'relative flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg',
        'transition-all duration-200 ease-out',
        'hover:bg-white/5',
        active
          ? 'text-blue-400 bg-blue-500/10'
          : 'text-gray-300 hover:text-white'
      )}
    >
      {icon && (
        <span className="material-symbols-outlined text-lg">
          {icon}
        </span>
      )}
      <span className="hidden lg:inline">{label}</span>
      
      {/* 활성 인디케이터 */}
      {active && (
        <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-blue-400" />
      )}
      
      {/* 배지 */}
      {badge && (
        <span className="ml-1 px-1.5 py-0.5 text-xs font-medium rounded-full bg-blue-500/20 text-blue-400">
          {badge}
        </span>
      )}
    </Link>
  );
}

// ============================================
// 드롭다운 네비게이션
// ============================================
interface NavDropdownProps {
  item: NavItem;
  currentPath: string;
}

function NavDropdown({ item, currentPath }: NavDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const isActive = item.children?.some((child) => isActivePath(currentPath, child.href)) ?? false;

  // 외부 클릭 감지
  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        onMouseEnter={() => setIsOpen(true)}
        className={cn(
          'flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg',
          'transition-all duration-200 ease-out',
          'hover:bg-white/5',
          isOpen ? 'text-blue-400' : isActive
            ? 'text-blue-400 bg-blue-500/10'
            : 'text-gray-300 hover:text-white'
        )}
        aria-haspopup="menu"
        aria-expanded={isOpen}
      >
        {item.icon && (
          <span className="material-symbols-outlined text-lg">
            {item.icon}
          </span>
        )}
        <span className="hidden lg:inline">{item.label}</span>
        <span className={cn(
          'material-symbols-outlined text-sm transition-transform duration-200',
          isOpen && 'rotate-180'
        )}>
          expand_more
        </span>
      </button>

      {/* 드롭다운 메뉴 */}
      {isOpen && (
        <div
          className="absolute top-full left-0 mt-2 min-w-[200px] animate-scale-in origin-top-left"
          onMouseLeave={() => setIsOpen(false)}
        >
          <div className="bg-slate-800/95 backdrop-blur-xl border border-white/10 rounded-xl shadow-dropdown overflow-hidden">
            <div className="py-2">
              {item.children?.map((child) => {
                const childActive = isActivePath(currentPath, child.href);
                
                return (
                  <Link
                    key={child.href}
                    href={child.href}
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      'flex items-center gap-3 px-4 py-2.5 text-sm transition-colors',
                      childActive
                        ? 'text-blue-400 bg-blue-500/10'
                        : 'text-gray-300 hover:bg-white/5 hover:text-white'
                    )}
                  >
                    {child.icon && (
                      <span className="material-symbols-outlined text-lg">
                        {child.icon}
                      </span>
                    )}
                    {child.label}
                    {childActive && (
                      <span className="ml-auto">
                        <span className="material-symbols-outlined text-sm">check</span>
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// 투자 드롭다운 (기존 호환성 유지)
// ============================================
function InvestDropdown({ currentPath }: { currentPath: string }) {
  const { t } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const links = [
    { href: '/products', label: t.common.rewardPlanInvestment || 'Reward Plan Investment', icon: 'stars' },
    { href: '/game-shares', label: t.common.gameShareInvestment || 'Game Share Investment', icon: 'sports_esports' },
  ];

  const isActive = links.some((link) => isActivePath(currentPath, link.href));

  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  return (
    <div className="relative flex items-center" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className={cn(
          'flex items-center gap-1 text-sm font-medium transition-colors',
          isActive ? 'text-blue-400' : 'text-gray-300 hover:text-white'
        )}
        aria-haspopup="menu"
        aria-expanded={isOpen}
      >
        {t.common.invest || 'Invest'}
        <span className={cn(
          'material-symbols-outlined text-sm transition-transform',
          isOpen && 'rotate-180'
        )}>
          expand_more
        </span>
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-3 min-w-[220px] animate-scale-in origin-top-left">
          <div className="bg-slate-800/95 backdrop-blur-xl border border-white/10 rounded-xl shadow-dropdown py-2">
            {links.map((link) => {
              const active = isActivePath(currentPath, link.href);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    'flex items-center gap-3 px-4 py-2.5 text-sm transition-colors',
                    active
                      ? 'text-blue-400 bg-blue-500/10'
                      : 'text-gray-300 hover:bg-white/5 hover:text-white'
                  )}
                >
                  {link.icon && (
                    <span className="material-symbols-outlined text-lg">{link.icon}</span>
                  )}
                  {link.label}
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export { InvestDropdown };
