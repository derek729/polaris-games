'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { CompanyBrand } from '@/components/CompanyBrand';
import { cn } from '@/lib/utils';

interface MobileNavigationProps {
  user: {
    username: string;
    personalCoin: number;
  };
  currentPath: string;
}

// ============================================
// 메뉴 아이템 타입
// ============================================
interface MenuItem {
  href: string;
  label: string;
  icon: string;
  section?: string;
  badge?: string | number;
  divider?: boolean;
}

export default function MobileNavigation({ user, currentPath }: MobileNavigationProps) {
  const { t, language } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const [closing, setClosing] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  // 메뉴 닫기 애니메이션
  const closeMenu = () => {
    setClosing(true);
    setTimeout(() => {
      setIsOpen(false);
      setClosing(false);
    }, 300);
  };

  // 외부 클릭 감지
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (isOpen && !closing && menuRef.current && !menuRef.current.contains(target) && 
          buttonRef.current && !buttonRef.current.contains(target)) {
        closeMenu();
      }
    };

    if (isOpen) {
      document.addEventListener('click', handleClickOutside);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('click', handleClickOutside);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, closing]);

  // 경로 변경 시 메뉴 닫기
  useEffect(() => {
    if (isOpen) {
      closeMenu();
    }
  }, [currentPath]);

  // ESC 키로 닫기
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        closeMenu();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen]);

  const menuItems: MenuItem[] = [
    // 지갑 섹션
    { href: '/', label: '지갑', icon: 'account_balance_wallet', section: 'wallet' },
    { href: '/transfer', label: '코인 전송', icon: 'send_money', section: 'wallet' },
    { href: '/transactions', label: '거래내역', icon: 'receipt_long', section: 'wallet' },
    { divider: true },
    
    // 계정 섹션
    { href: '/my-profile', label: '내 프로필', icon: 'person', section: 'account' },
    { href: '/staking', label: '스테이킹', icon: 'account_balance', section: 'account' },
    { href: '/games', label: t.common.games || 'Games', icon: 'sports_esports', section: 'account' },
    { divider: true },
    
    // 정보 섹션
    { href: '/about', label: '재단', icon: 'business', section: 'info' },
    { href: '/whitepaper', label: '백서', icon: 'description', section: 'info' },
    { href: '/contact', label: '문의', icon: 'mail', section: 'info' },
  ];

  const sectionLabels: Record<string, string> = {
    wallet: '지갑',
    account: '계정',
    info: '정보',
  };

  return (
    <>
      {/* 메뉴 버튼 */}
      <button
        ref={buttonRef}
        onClick={() => isOpen ? closeMenu() : setIsOpen(true)}
        className={cn(
          'md:hidden flex items-center justify-center p-2.5 rounded-xl',
          'bg-white/5 hover:bg-white/10 active:bg-white/15',
          'text-gray-300 hover:text-white',
          'transition-all duration-200 ease-out',
          'backdrop-blur-sm border border-white/10',
          isOpen && 'bg-white/10 text-white'
        )}
        aria-label={isOpen ? t.mobileNav?.closeMenu || '메뉴 닫기' : t.mobileNav?.openMenu || '메뉴 열기'}
        aria-expanded={isOpen}
      >
        <span className="material-symbols-outlined text-2xl">
          {isOpen ? 'close' : 'menu'}
        </span>
      </button>

      {/* 오버레이 */}
      {isOpen && (
        <div
          className={cn(
            'md:hidden fixed inset-0 z-50',
            'bg-black/80 backdrop-blur-sm',
            closing ? 'animate-fade-out' : 'animate-fade-in'
          )}
          onClick={closeMenu}
        />
      )}

      {/* 사이드바 메뉴 */}
      <div
        ref={menuRef}
        className={cn(
          'md:hidden fixed left-0 top-0 h-full w-80 max-w-[85vw]',
          'bg-gradient-to-b from-slate-900/98 to-slate-800/98',
          'backdrop-blur-xl border-r border-white/10',
          'shadow-2xl z-[60]',
          'transform transition-transform duration-300 ease-out',
          isOpen && !closing ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex flex-col h-full">
          {/* 헤더 */}
          <div className="flex items-center justify-between p-4 border-b border-white/10">
            <CompanyBrand
              wrapperClassName="gap-3"
              size={40}
              textClassName="text-white text-lg font-bold"
            />
            <button
              onClick={closeMenu}
              className="p-2 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
              aria-label={language === 'ko' ? '메뉴 닫기' : 'Close menu'}
            >
              <span className="material-symbols-outlined text-xl">close</span>
            </button>
          </div>

          {/* 사용자 프로필 카드 */}
          <div className="p-4 border-b border-white/10">
            <div className="flex items-center gap-4 p-3 rounded-xl bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-white/5">
              <div className="relative">
                <div className="bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-xl rounded-full w-12 h-12 shadow-lg shadow-blue-500/20">
                  {user.username?.[0]?.toUpperCase() || 'U'}
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-green-500 border-2 border-slate-900" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-semibold truncate">{user.username}</p>
                <div className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm text-blue-400">paid</span>
                  <p className="text-blue-400 text-sm font-medium">
                    {typeof user.personalCoin === 'number' 
                      ? user.personalCoin.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
                      : '0.00'} MSUO
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 네비게이션 메뉴 */}
          <nav className="flex-1 overflow-y-auto p-3 scrollbar-thin scrollbar-thumb-white/10">
            <ul className="space-y-1">
              {menuItems.map((item, index) => {
                if (item.divider) {
                  return (
                    <li key={`divider-${index}`} className="my-3">
                      <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                    </li>
                  );
                }

                const active = currentPath === item.href || 
                  (item.href !== '/' && currentPath.startsWith(`${item.href}/`));

                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={() => closeMenu()}
                      className={cn(
                        'flex items-center gap-3 px-4 py-3 rounded-xl',
                        'transition-all duration-200 ease-out',
                        'touch-manipulation',
                        active
                          ? 'bg-gradient-to-r from-blue-500/20 to-blue-600/10 text-blue-400 border border-blue-500/20'
                          : 'text-gray-300 hover:bg-white/5 hover:text-white'
                      )}
                    >
                      <span className={cn(
                        'material-symbols-outlined text-xl',
                        active && 'text-blue-400'
                      )}>
                        {item.icon}
                      </span>
                      <span className="font-medium flex-1">{item.label}</span>
                      {item.badge && (
                        <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-blue-500/20 text-blue-400">
                          {item.badge}
                        </span>
                      )}
                      {active && (
                        <span className="material-symbols-outlined text-lg text-blue-400">
                          chevron_right
                        </span>
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* 푸터 */}
          <div className="p-4 border-t border-white/10 space-y-4">
            {/* 언어 스위처 */}
            <div className="flex items-center justify-center">
              <LanguageSwitcher />
            </div>
            
            {/* 버전 정보 */}
            <div className="text-center">
              <p className="text-gray-500 text-xs">
                {t.mobileNav?.copyright || '© 2024 MSUO Foundation'}
              </p>
              <p className="text-gray-600 text-xs mt-1">
                v1.0.0
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
