'use client';

import { useState, useEffect, useRef } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { getChatbotResponse, getQuickQuestions, type ChatMessage } from '@/services/chatbot';

export default function ChatbotWidget() {
  const { language, t } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const widgetRef = useRef<HTMLDivElement>(null);
  const quickQuestions = getQuickQuestions(language);
  const welcomeMessageRef = useRef<string>(t.chatbot.welcome);

  // 초기 환영 메시지 설정 및 언어 변경 시 업데이트
  useEffect(() => {
    if (welcomeMessageRef.current !== t.chatbot.welcome) {
      welcomeMessageRef.current = t.chatbot.welcome;
      if (messages.length === 0 || (messages.length === 1 && messages[0].role === 'assistant')) {
        setMessages([{
          role: 'assistant',
          content: t.chatbot.welcome,
          timestamp: new Date()
        }]);
      }
    } else if (messages.length === 0) {
      // 초기 로드 시에만 환영 메시지 설정
      setMessages([{
        role: 'assistant',
        content: t.chatbot.welcome,
        timestamp: new Date()
      }]);
    }
  }, [language, t.chatbot.welcome]); // messages 의존성 제거로 무한 루프 방지

  // 메시지가 추가될 때마다 스크롤
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 챗봇이 열릴 때 입력창 포커스
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // 외부 클릭 시 닫기
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (widgetRef.current && !widgetRef.current.contains(event.target as Node)) {
        // 말풍선 버튼 클릭은 제외
        const target = event.target as HTMLElement;
        if (!target.closest('.chatbot-toggle-button')) {
          setIsOpen(false);
        }
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // 챗봇 응답 생성
    setTimeout(() => {
      const response = getChatbotResponse(userMessage.content, language);
      
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response.answer,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 500);
  };

  const handleQuickQuestion = (question: string) => {
    setInputValue(question);
    setTimeout(() => {
      handleSendMessage();
    }, 100);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50" ref={widgetRef}>
      {/* 챗봇 패널 */}
      {isOpen && (
        <div className="mb-4 w-[380px] max-w-[calc(100vw-2rem)] h-[600px] max-h-[calc(100vh-8rem)] bg-[#1a2332] rounded-2xl shadow-2xl border border-gray-700/50 flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 fade-in duration-300">
          {/* 헤더 */}
          <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[#137fec] to-[#3A4DFF] border-b border-gray-700/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <span className="material-symbols-outlined text-white text-xl">smart_toy</span>
              </div>
              <div>
                <h3 className="text-white font-semibold text-sm">{t.chatbot.title}</h3>
                <p className="text-white/80 text-xs">{t.chatbot.subtitle}</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors flex items-center justify-center"
            >
              <span className="material-symbols-outlined text-lg">close</span>
            </button>
          </div>

          {/* 메시지 영역 */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#0f1620]">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                    message.role === 'user'
                      ? 'bg-gradient-to-r from-[#137fec] to-[#3A4DFF] text-white'
                      : 'bg-[#1a2332] text-gray-200 border border-gray-700/50'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
                  {message.timestamp && (
                    <p className="text-xs opacity-60 mt-1">
                      {message.timestamp.toLocaleTimeString('ko-KR', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  )}
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-[#1a2332] border border-gray-700/50 rounded-2xl px-4 py-2.5">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* 빠른 질문 */}
          {messages.length <= 1 && (
            <div className="px-4 py-3 bg-[#1a2332] border-t border-gray-700/50">
              <p className="text-xs text-gray-400 mb-2">{t.chatbot.quickQuestions}</p>
              <div className="flex flex-wrap gap-2">
                {quickQuestions.slice(0, 3).map((question, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickQuestion(question)}
                    className="px-3 py-1.5 text-xs bg-[#0f1620] hover:bg-[#137fec]/20 text-gray-300 rounded-lg border border-gray-700/50 hover:border-[#137fec]/50 transition-colors"
                  >
                    {question}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 입력 영역 */}
          <div className="p-4 bg-[#1a2332] border-t border-gray-700/50">
            <div className="flex gap-2">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={t.chatbot.placeholder}
                className="flex-1 px-4 py-2.5 bg-[#0f1620] border border-gray-700/50 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent text-sm"
                disabled={isLoading}
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputValue.trim() || isLoading}
                className="px-4 py-2.5 bg-gradient-to-r from-[#137fec] to-[#3A4DFF] text-white rounded-lg hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity flex items-center justify-center"
              >
                <span className="material-symbols-outlined text-lg">send</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 말풍선 버튼 */}
      <button
        onClick={toggleChatbot}
        className="chatbot-toggle-button w-14 h-14 rounded-full bg-gradient-to-r from-[#137fec] to-[#3A4DFF] shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-200 flex items-center justify-center text-white relative group"
        aria-label="고객지원 챗봇"
      >
        {!isOpen ? (
          <>
            <span className="material-symbols-outlined text-2xl">chat</span>
            {/* 알림 뱃지 (선택사항) */}
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-[#1a2332] animate-pulse"></span>
          </>
        ) : (
          <span className="material-symbols-outlined text-2xl">close</span>
        )}
        
        {/* 툴팁 */}
        <div className="absolute bottom-full right-0 mb-2 px-3 py-1.5 bg-gray-900 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
          {t.chatbot.title}
          <div className="absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
        </div>
      </button>
    </div>
  );
}

