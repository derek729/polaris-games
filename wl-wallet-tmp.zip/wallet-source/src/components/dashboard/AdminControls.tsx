'use client';

import { useState } from 'react';

type ActionType = 'daily' | 'rank' | 'leadership';
type ManagementType = 'tiers' | 'users' | 'reports';

const SYSTEM_ACTIONS: Record<
  ActionType,
  {
    label: string;
    description: string;
    endpoint: string;
    color: string;
    icon: string;
  }
> = {
  daily: {
    label: '📅 일일 리워드 지급',
    description: '모든 활성 투자자에게 오늘의 수익을 지급합니다.',
    endpoint: '/api/admin/run-daily',
    color: 'from-sky-500/20 via-blue-500/20 to-purple-500/20',
    icon: '📅',
  },
  rank: {
    label: '🏆 랭크 심사 실행',
    description: '전 사원의 승급 조건을 재검토하고 등급을 반영합니다.',
    endpoint: '/api/admin/calc-rank',
    color: 'from-amber-500/20 via-orange-500/20 to-rose-500/20',
    icon: '🏆',
  },
  leadership: {
    label: '👑 리더십 보너스 실행',
    description: 'Rank 1 이상 유저에게 팀 리더십 보너스를 지급합니다.',
    endpoint: '/api/admin/run-leadership',
    color: 'from-purple-500/20 via-pink-500/20 to-rose-500/20',
    icon: '👑',
  },
};

const MANAGEMENT_FEATURES: Record<
  ManagementType,
  {
    label: string;
    description: string;
    color: string;
    icon: string;
    modalTitle: string;
  }
> = {
  tiers: {
    label: '⚙️ 투자 등급 관리',
    description: '투자 등급별 금액, 수익률, 세대 수를 설정합니다.',
    color: 'from-emerald-500/20 via-teal-500/20 to-cyan-500/20',
    icon: '⚙️',
    modalTitle: '투자 등급 설정'
  },
  users: {
    label: '👥 사용자 관리',
    description: '사용자 목록 조회 및 계정 상태를 관리합니다.',
    color: 'from-blue-500/20 via-indigo-500/20 to-violet-500/20',
    icon: '👥',
    modalTitle: '사용자 관리'
  },
  reports: {
    label: '📊 금융 리포트',
    description: '시스템 금융 현황 및 투자/수당 통계를 확인합니다.',
    color: 'from-rose-500/20 via-pink-500/20 to-fuchsia-500/20',
    icon: '📊',
    modalTitle: '금융 리포트'
  },
};

export default function AdminControls() {
  const [loadingAction, setLoadingAction] = useState<ActionType | null>(null);
  const [loadingFeature, setLoadingFeature] = useState<ManagementType | null>(null);
  const [openModal, setOpenModal] = useState<ManagementType | null>(null);
  const [modalData, setModalData] = useState<any>(null);

  const handleSystemAction = async (type: ActionType) => {
    if (loadingAction) return;

    setLoadingAction(type);
    try {
      const res = await fetch(SYSTEM_ACTIONS[type].endpoint, {
        method: 'POST',
      });

      if (!res.ok) {
        throw new Error('요청에 실패했습니다.');
      }

      const result = await res.json();
      alert(`✅ 성공적으로 처리되었습니다.\n처리된 건수: ${result.processedCount || 'N/A'}`);
      window.location.reload();
    } catch (error) {
      console.error(`[AdminControls] ${type} 실행 실패`, error);
      alert('❌ 실행 중 오류가 발생했습니다.');
    } finally {
      setLoadingAction(null);
    }
  };

  const openFeatureModal = async (type: ManagementType) => {
    if (loadingFeature) return;

    setLoadingFeature(type);
    try {
      let data = null;

      switch (type) {
        case 'tiers':
          const tiersRes = await fetch('/api/admin/investment/tiers');
          const tiersResult = await tiersRes.json();
          if (tiersResult.ok) data = tiersResult.data;
          break;

        case 'reports':
          const reportsRes = await fetch('/api/admin/reports/financial?period=30d');
          const reportsResult = await reportsRes.json();
          if (reportsResult.ok) data = reportsResult.data;
          break;

        case 'users':
          const usersRes = await fetch('/api/admin/users?page=1&limit=20');
          const usersResult = await usersRes.json();
          if (usersResult.ok) data = usersResult.data;
          break;
      }

      setModalData(data);
      setOpenModal(type);
    } catch (error) {
      console.error(`[AdminControls] ${type} 데이터 조회 실패`, error);
      alert('❌ 데이터를 불러오는 중 오류가 발생했습니다.');
    } finally {
      setLoadingFeature(null);
    }
  };

  const handleUserAction = async (userId: string, action: 'suspend' | 'activate', reason: string) => {
    try {
      const endpoint = `/api/admin/users/${userId}/${action}`;
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });

      const result = await res.json();
      if (result.ok) {
        alert(`✅ ${action === 'suspend' ? '정지' : '활성화'} 완료`);
        openFeatureModal('users'); // 목록 새로고침
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      alert(`❌ 실패: ${error.message}`);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR').format(amount);
  };

  return (
    <section className="rounded-2xl border border-white/5 bg-slate-900/40 p-4 shadow-xl backdrop-blur-sm sm:p-6">
      <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs uppercase tracking-widest text-slate-400">
            관리자 제어 패널
          </p>
          <h2 className="text-2xl font-bold text-white">시스템 관리</h2>
          <p className="text-sm text-slate-500">
            시스템 운영 및 관리 기능을 실행합니다.
          </p>
        </div>
      </div>

      {/* 시스템 실행 기능 */}
      <div className="mb-6">
        <h3 className="mb-3 text-lg font-semibold text-white">시스템 실행</h3>
        <div className="grid gap-4 lg:grid-cols-3">
          {(Object.entries(SYSTEM_ACTIONS) as [ActionType, typeof SYSTEM_ACTIONS.daily][]).map(
            ([type, action]) => (
              <div
                key={type}
                className={`rounded-2xl border border-white/5 bg-gradient-to-br ${action.color} p-4 shadow-inner`}
              >
                <div className="flex items-center gap-3">
                  <div className="text-2xl" aria-hidden>
                    {action.icon}
                  </div>
                  <div>
                    <h4 className="text-base font-semibold text-white">
                      {action.label}
                    </h4>
                    <p className="text-xs text-slate-200/70">{action.description}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSystemAction(type)}
                  disabled={!!loadingAction}
                  className="mt-3 w-full rounded-lg bg-white/10 px-3 py-2 text-xs font-semibold text-white shadow-lg shadow-black/20 transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {loadingAction === type ? '실행 중...' : '실행'}
                </button>
              </div>
            )
          )}
        </div>
      </div>

      {/* 관리 기능 */}
      <div>
        <h3 className="mb-3 text-lg font-semibold text-white">시스템 관리</h3>
        <div className="grid gap-4 lg:grid-cols-3">
          {(Object.entries(MANAGEMENT_FEATURES) as [ManagementType, typeof MANAGEMENT_FEATURES.tiers][]).map(
            ([type, feature]) => (
              <div
                key={type}
                className={`rounded-2xl border border-white/5 bg-gradient-to-br ${feature.color} p-4 shadow-inner`}
              >
                <div className="flex items-center gap-3">
                  <div className="text-2xl" aria-hidden>
                    {feature.icon}
                  </div>
                  <div>
                    <h4 className="text-base font-semibold text-white">
                      {feature.label}
                    </h4>
                    <p className="text-xs text-slate-200/70">{feature.description}</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => openFeatureModal(type)}
                  disabled={!!loadingFeature}
                  className="mt-3 w-full rounded-lg bg-white/10 px-3 py-2 text-xs font-semibold text-white shadow-lg shadow-black/20 transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {loadingFeature === type ? '로딩 중...' : '열기'}
                </button>
              </div>
            )
          )}
        </div>
      </div>

      {/* 모달들 */}
      {openModal && modalData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl border border-white/10 bg-slate-900 p-6 shadow-2xl">
            <button
              onClick={() => setOpenModal(null)}
              className="absolute right-4 top-4 text-slate-400 hover:text-white"
            >
              ✕
            </button>

            <h2 className="mb-4 text-2xl font-bold text-white">
              {MANAGEMENT_FEATURES[openModal].modalTitle}
            </h2>

            {/* 투자 등급 관리 모달 */}
            {openModal === 'tiers' && (
              <div className="space-y-4">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="pb-2 text-left text-slate-400">등급</th>
                        <th className="pb-2 text-left text-slate-400">금액 구간</th>
                        <th className="pb-2 text-left text-slate-400">일일 수익률</th>
                        <th className="pb-2 text-left text-slate-400">매칭 세대</th>
                        <th className="pb-2 text-left text-slate-400">설명</th>
                      </tr>
                    </thead>
                    <tbody>
                      {modalData.map((tier: any) => (
                        <tr key={tier.tier} className="border-b border-slate-800">
                          <td className="py-2 text-white font-semibold">{tier.label}</td>
                          <td className="py-2 text-slate-300">
                            ${tier.minAmount.toLocaleString()} - {tier.maxAmount ? `$${tier.maxAmount.toLocaleString()}` : '∞'}
                          </td>
                          <td className="py-2 text-emerald-400">{(tier.rate * 100).toFixed(1)}%</td>
                          <td className="py-2 text-purple-400">{tier.depth}대</td>
                          <td className="py-2 text-slate-400 text-xs">{tier.description}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-4 p-3 rounded-lg bg-amber-500/20 border border-amber-500/30">
                  <p className="text-amber-300 text-sm">
                    ⚠️ 현재는 조회만 가능합니다. 투자 등급 수정 기능은 곧 추가될 예정입니다.
                  </p>
                </div>
              </div>
            )}

            {/* 사용자 관리 모달 */}
            {openModal === 'users' && (
              <div className="space-y-4">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="pb-2 text-left text-slate-400">사용자</th>
                        <th className="pb-2 text-left text-slate-400">랭크</th>
                        <th className="pb-2 text-left text-slate-400">보유 코인</th>
                        <th className="pb-2 text-left text-slate-400">총 투자</th>
                        <th className="pb-2 text-left text-slate-400">상태</th>
                        <th className="pb-2 text-left text-slate-400">관리</th>
                      </tr>
                    </thead>
                    <tbody>
                      {modalData.users?.slice(0, 10).map((user: any) => (
                        <tr key={user.id} className="border-b border-slate-800">
                          <td className="py-2">
                            <div>
                              <div className="text-white font-medium">{user.username || 'Unknown'}</div>
                              <div className="text-slate-500 text-xs">{user.email}</div>
                            </div>
                          </td>
                          <td className="py-2 text-slate-300">Rank {user.rank}</td>
                          <td className="py-2 text-blue-400">{formatCurrency(user.personalCoin)} AO</td>
                          <td className="py-2 text-emerald-400">${formatCurrency(user.totalInvestment)}</td>
                          <td className="py-2">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              user.status === 'ACTIVE'
                                ? 'bg-green-500/20 text-green-400'
                                : 'bg-red-500/20 text-red-400'
                            }`}>
                              {user.status}
                            </span>
                          </td>
                          <td className="py-2">
                            <div className="flex gap-1">
                              {user.status === 'ACTIVE' ? (
                                <button
                                  onClick={() => {
                                    const reason = prompt('정지 사유를 입력하세요:');
                                    if (reason) handleUserAction(user.id, 'suspend', reason);
                                  }}
                                  className="px-2 py-1 bg-red-500/20 text-red-400 rounded text-xs hover:bg-red-500/30"
                                >
                                  정지
                                </button>
                              ) : (
                                <button
                                  onClick={() => {
                                    const reason = prompt('활성화 사유를 입력하세요:');
                                    if (reason) handleUserAction(user.id, 'activate', reason);
                                  }}
                                  className="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs hover:bg-green-500/30"
                                >
                                  활성화
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* 금융 리포트 모달 */}
            {openModal === 'reports' && (
              <div className="space-y-6">
                {/* 요약 통계 */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <div className="text-slate-400 text-sm mb-1">총 사용자</div>
                    <div className="text-2xl font-bold text-white">{modalData.summary?.totalUsers?.toLocaleString()}</div>
                    <div className="text-xs text-slate-500">활성: {modalData.summary?.activeUsers?.toLocaleString()}</div>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <div className="text-slate-400 text-sm mb-1">총 투자</div>
                    <div className="text-2xl font-bold text-emerald-400">${formatCurrency(modalData.summary?.totalInvestments?.amount || 0)}</div>
                    <div className="text-xs text-slate-500">{modalData.summary?.totalInvestments?.count?.toLocaleString()}건</div>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <div className="text-slate-400 text-sm mb-1">총 수당 지급</div>
                    <div className="text-2xl font-bold text-blue-400">{formatCurrency(modalData.summary?.totalRewards?.amount || 0)} AO</div>
                    <div className="text-xs text-slate-500">{modalData.summary?.totalRewards?.count?.toLocaleString()}건</div>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-4">
                    <div className="text-slate-400 text-sm mb-1">시스템 유동성</div>
                    <div className="text-2xl font-bold text-purple-400">{formatCurrency(modalData.summary?.systemLiquidity?.totalUserBalance || 0)} AO</div>
                    <div className="text-xs text-slate-500">가용률: {modalData.summary?.systemLiquidity?.availableRatio?.toFixed(1)}%</div>
                  </div>
                </div>

                {/* 수당 분포 */}
                <div>
                  <h4 className="text-white font-semibold mb-3">수당 유형별 분포</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {modalData.distributions?.rewardTypes?.map((type: any) => (
                      <div key={type.type} className="bg-slate-800/30 rounded-lg p-3">
                        <div className="text-slate-400 text-xs mb-1">{type.type}</div>
                        <div className="text-lg font-bold text-white">{formatCurrency(type.amount)} AO</div>
                        <div className="text-xs text-slate-500">{type.count.toLocaleString()}건</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 p-3 rounded-lg bg-blue-500/20 border border-blue-500/30">
                  <p className="text-blue-300 text-sm">
                    ℹ️ 금융 리포트는 최근 30일간의 데이터를 기준으로 합니다.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}

