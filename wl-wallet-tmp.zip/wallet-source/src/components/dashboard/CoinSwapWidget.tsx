'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { ArrowLeftRight, RefreshCw, AlertCircle } from 'lucide-react';

interface CoinSwapWidgetProps {
  userBalance: number;
  onSwapSuccess?: () => void;
}

export default function CoinSwapWidget({ userBalance, onSwapSuccess }: CoinSwapWidgetProps) {
  const { language } = useI18n();
  const [swapType, setSwapType] = useState<'USDT_TO_MSUO' | 'MSUO_TO_USDT' | 'NKT_TO_MSUO' | 'MSUO_TO_NKT'>('NKT_TO_MSUO');
  const [amount, setAmount] = useState('');
  const [currentPrice, setCurrentPrice] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [swapping, setSwapping] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 현재 시세 조회
  useEffect(() => {
    fetchCurrentPrice();
    const interval = setInterval(fetchCurrentPrice, 30000); // 30초마다 갱신
    return () => clearInterval(interval);
  }, []);

  const fetchCurrentPrice = async () => {
    try {
      const res = await fetch('/api/user/exchange/orderbook', {
        credentials: 'include',
      });
      const data = await res.json();
      if (data.ok && data.data?.currentPrice) {
        setCurrentPrice(data.data.currentPrice);
      }
    } catch (err) {
      console.error('시세 조회 실패:', err);
    }
  };

  const calculateReceived = () => {
    if (!amount || !currentPrice) return null;
    const amountNum = parseFloat(amount);
    if (isNaN(amountNum) || amountNum <= 0) return null;

    if (swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO') {
      return (amountNum / currentPrice).toFixed(8);
    } else {
      return (amountNum * currentPrice).toFixed(2);
    }
  };

  const handleSwap = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      setError(language === 'ko' ? '교환 수량을 입력해주세요.' : 'Please enter swap amount.');
      return;
    }

    const amountNum = parseFloat(amount);
    if ((swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO') && amountNum > userBalance) {
      setError(language === 'ko' ? 'NKT 잔액이 부족합니다.' : 'Insufficient NKT balance.');
      return;
    }

    if ((swapType === 'MSUO_TO_USDT' || swapType === 'MSUO_TO_NKT') && amountNum > userBalance) {
      setError(language === 'ko' ? 'MSUO 코인 잔액이 부족합니다.' : 'Insufficient MSUO coin balance.');
      return;
    }

    setSwapping(true);
    setError(null);

    try {
      // NKT 타입으로 변환 (기존 타입 호환성 유지)
      const apiType = swapType === 'NKT_TO_MSUO' ? 'AOT_TO_AO'
        : swapType === 'MSUO_TO_NKT' ? 'AO_TO_AOT'
        : swapType === 'USDT_TO_MSUO' ? 'AOT_TO_AO' // 기존 타입으로 변환
        : 'AO_TO_AOT'; // 기존 타입으로 변환

      const res = await fetch('/api/user/exchange/swap', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          type: apiType,
          amount: amountNum,
        }),
      });

      const data = await res.json();

      if (data.ok) {
        alert(
          language === 'ko'
            ? `✅ 교환이 완료되었습니다!\n${data.data.description}`
            : `✅ Swap completed!\n${data.data.description}`
        );
        setAmount('');
        if (onSwapSuccess) {
          onSwapSuccess();
        }
      } else {
        setError(data.error || (language === 'ko' ? '교환 실패' : 'Swap failed'));
      }
    } catch (err) {
      console.error('교환 실패:', err);
      setError(language === 'ko' ? '교환 중 오류가 발생했습니다.' : 'An error occurred during swap.');
    } finally {
      setSwapping(false);
    }
  };

  const receivedAmount = calculateReceived();

  return (
    <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">
          {language === 'ko' ? '코인 교환' : 'Coin Swap'}
        </h3>
        <button
          onClick={fetchCurrentPrice}
          disabled={loading}
          className="p-2 text-gray-400 hover:text-white transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* 현재 시세 */}
      {currentPrice && (
        <div className="mb-4 p-3 bg-white/5 rounded-lg border border-white/10">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">
              {language === 'ko' ? '현재 시세' : 'Current Price'}
            </span>
            <span className="text-white font-semibold">
              {currentPrice.toFixed(8)} NKT/MSUO
            </span>
          </div>
        </div>
      )}

      {/* 교환 타입 선택 */}
      <div className="mb-4 flex gap-2">
        <button
          onClick={() => {
            setSwapType('NKT_TO_MSUO');
            setError(null);
          }}
          className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
            swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO'
              ? 'bg-[#137fec] text-white'
              : 'bg-white/5 text-gray-300 hover:bg-white/10'
          }`}
        >
          {language === 'ko' ? 'NKT → MSUO' : 'NKT → MSUO'}
        </button>
        <button
          onClick={() => {
            setSwapType('MSUO_TO_NKT');
            setError(null);
          }}
          className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
            swapType === 'MSUO_TO_USDT' || swapType === 'MSUO_TO_NKT'
              ? 'bg-[#137fec] text-white'
              : 'bg-white/5 text-gray-300 hover:bg-white/10'
          }`}
        >
          {language === 'ko' ? 'MSUO → NKT' : 'MSUO → NKT'}
        </button>
      </div>

      {/* 입력 필드 */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            {(swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO')
              ? language === 'ko'
                ? '교환할 NKT 금액'
                : 'NKT Amount to Swap'
              : language === 'ko'
              ? '교환할 MSUO 코인 수량'
              : 'MSUO Coin Amount to Swap'}
          </label>
          <div className="relative">
            <input
              type="number"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                setError(null);
              }}
              placeholder="0"
              step={(swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO') ? '0.01' : '0.00000001'}
              min="0"
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#137fec] transition-colors"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-gray-400">
              {(swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO') ? 'NKT' : 'MSUO'}
            </div>
          </div>
          <p className="mt-1 text-xs text-gray-400">
            {language === 'ko' ? '보유' : 'Balance'}: {userBalance.toFixed((swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO') ? 2 : 8)}{' '}
            {(swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO') ? 'NKT' : 'MSUO'}
          </p>
        </div>

        {/* 교환 화살표 */}
        <div className="flex items-center justify-center">
          <ArrowLeftRight className="h-6 w-6 text-[#137fec]" />
        </div>

        {/* 받을 금액 */}
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            {(swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO')
              ? language === 'ko'
                ? '받을 MSUO 코인 수량'
                : 'MSUO Coins to Receive'
              : language === 'ko'
              ? '받을 NKT 금액'
              : 'NKT Amount to Receive'}
          </label>
          <div className="px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white">
            {receivedAmount ? (
              <span className="text-lg font-semibold">
                {receivedAmount} {(swapType === 'USDT_TO_MSUO' || swapType === 'NKT_TO_MSUO') ? 'MSUO' : 'NKT'}
              </span>
            ) : (
              <span className="text-gray-500">0</span>
            )}
          </div>
        </div>

        {/* 에러 메시지 */}
        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
            <AlertCircle className="h-4 w-4" />
            <span>{error}</span>
          </div>
        )}

        {/* 교환 버튼 */}
        <button
          onClick={handleSwap}
          disabled={swapping || !amount || !receivedAmount}
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-[#137fec] to-[#3A4DFF] text-white rounded-lg font-semibold hover:from-[#137fec]/90 hover:to-[#3A4DFF]/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {swapping ? (
            <>
              <RefreshCw className="h-5 w-5 animate-spin" />
              <span>{language === 'ko' ? '교환 중...' : 'Swapping...'}</span>
            </>
          ) : (
            <>
              <ArrowLeftRight className="h-5 w-5" />
              <span>{language === 'ko' ? '교환하기' : 'Swap Now'}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}

