'use client';

import { useState, useEffect } from 'react';
import { useToast } from './Toast';

type TransferModalProps = {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  currentBalance: number;
  onSuccess: () => void;
};

const TRANSFER_GAS_FEE = 0.01;

export default function TransferModal({
  isOpen,
  onClose,
  currentBalance,
  onSuccess,
}: TransferModalProps) {
  const { showToast } = useToast();
  const [receiverEmail, setReceiverEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ozBalance, setOzBalance] = useState<number>(0);

  useEffect(() => {
    if (isOpen) {
      fetchOzBalance();
      setReceiverEmail('');
      setAmount('');
      setPassword('');
      setError(null);
    }
  }, [isOpen]);

  const fetchOzBalance = async () => {
    try {
      const response = await fetch('/api/auth/me', {
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        if (data.ok && data.data?.users) {
          setOzBalance(data.data.users.ozCoin || 0);
        }
      }
    } catch (error) {
      console.error('OZ COIN 잔고 조회 실패:', error);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setError(null);

    // State 값 직접 사용
    const finalReceiverEmail = receiverEmail.trim();
    const finalAmount = amount;

    console.log('[Transfer Modal] Submit data:', {
      receiverEmail: finalReceiverEmail,
      amount: finalAmount,
      receiverEmailType: typeof finalReceiverEmail,
      amountType: typeof finalAmount,
      receiverEmailLength: finalReceiverEmail.length
    });

    // 명시적인 검증
    if (!finalReceiverEmail || finalReceiverEmail.length === 0) {
      setError('받는 사람 이메일을 입력해주세요.');
      return;
    }

    if (!finalAmount || finalAmount.length === 0) {
      setError('이체 금액을 입력해주세요.');
      return;
    }

    const transferAmount = parseFloat(finalAmount);

    if (isNaN(transferAmount) || transferAmount <= 0) {
      setError('유효한 금액을 입력해주세요.');
      return;
    }

    if (transferAmount < 1) {
      setError('최소 이체 금액은 1 MSUO입니다.');
      return;
    }

    if (transferAmount > currentBalance) {
      setError('MSUO 잔고가 부족합니다.');
      return;
    }

    if (ozBalance < TRANSFER_GAS_FEE) {
      setError('OZ COIN 잔고가 부족합니다.');
      return;
    }

    setLoading(true);

    try {
      const payload = {
        receiverIdentifier: finalReceiverEmail,
        amount: transferAmount,
        password,
      };

      console.log('[Transfer Modal] Final payload:', payload);

      const res = await fetch('/api/user/transfer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload),
        credentials: 'include'
      });

      const data = await res.json();
      console.log('[Transfer Modal] Response:', { status: res.status, data });

      if (!res.ok || !data.ok) {
        throw new Error(data.error || '이체에 실패했습니다.');
      }

      // 성공 처리
      setReceiverEmail('');
      setAmount('');
      setPassword('');
      onSuccess();
      onClose();

      showToast(`이체 완료! ${data.data.receiver.username}에게 ${transferAmount.toLocaleString()} MSUO`, 'success');

    } catch (err: any) {
      console.error('[Transfer Modal] Submit error:', err);
      setError(err.message || '이체 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const transferAmount = parseFloat(amount) || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-slate-900 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-white"
          type="button"
        >
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <h2 className="mb-4 text-2xl font-bold text-white">코인 이체</h2>

        <div className="mb-6 rounded-xl bg-slate-800/50 p-4">
          <p className="text-sm text-slate-400">보유 잔고</p>
          <p className="text-2xl font-bold text-blue-400">
            {currentBalance.toLocaleString()} MSUO
          </p>
          <p className="text-sm text-slate-400">
            OZ COIN: {ozBalance.toFixed(2)} OZ
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="mb-2 block text-sm font-medium text-slate-300">
              받는 사람 이메일
            </label>
            <input
              type="email"
              value={receiverEmail}
              onChange={(e) => {
                console.log('[Transfer Modal] Email input changed:', e.target.value);
                setReceiverEmail(e.target.value);
              }}
              className="w-full rounded-lg border border-white/10 bg-slate-800 px-4 py-3 text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="example@email.com"
              required
              disabled={loading}
              autoComplete="off"
            />
          </div>

          <div className="mb-4">
            <label className="mb-2 block text-sm font-medium text-slate-300">
              이체 금액 (MSUO)
            </label>
            <input
              type="number"
              step="0.01"
              min="1"
              max={currentBalance}
              value={amount}
              onChange={(e) => {
                console.log('[Transfer Modal] Amount input changed:', e.target.value);
                setAmount(e.target.value);
              }}
              className="w-full rounded-lg border border-white/10 bg-slate-800 px-4 py-3 text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="이체할 금액을 입력하세요"
              required
              disabled={loading}
            />
          </div>

          <div className="mb-4">
            <label className="mb-2 block text-sm font-medium text-slate-300">
              비밀번호
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-slate-800 px-4 py-3 text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="비밀번호를 입력하세요"
              required
              disabled={loading}
              autoComplete="off"
            />
          </div>

          {transferAmount > 0 && (
            <div className="mb-4 rounded-xl bg-blue-500/10 border border-blue-500/30 p-4">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">이체 금액</span>
                  <span className="font-semibold text-white">
                    {transferAmount.toLocaleString()} MSUO
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">가스수수료</span>
                  <span className="font-semibold text-orange-400">
                    {TRANSFER_GAS_FEE.toFixed(2)} OZ COIN
                  </span>
                </div>
              </div>
            </div>
          )}

          {error && (
            <div className="mb-4 rounded-lg bg-red-500/20 border border-red-500/50 p-3 text-sm text-red-300">
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="flex-1 rounded-lg border border-white/10 bg-slate-800 px-4 py-3 font-semibold text-white transition hover:bg-slate-700 disabled:opacity-50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={
                loading ||
                !receiverEmail.trim() ||
                !amount ||
                transferAmount < 1 ||
                transferAmount > currentBalance
              }
              className="flex-1 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500 px-4 py-3 font-semibold text-white shadow-lg transition hover:from-blue-600 hover:to-purple-600 disabled:opacity-50"
            >
              {loading ? '처리 중...' : '이체하기'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
