'use client';

import { useState } from 'react';

type InvestmentModalProps = {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  currentBalance: number;
  onSuccess: () => void;
};

// 투자 등급 정보
const TIER_INFO = [
  { tier: 1, min: 50, max: 99, rate: 0.3, depth: 4, label: '1등급' },
  { tier: 2, min: 100, max: 499, rate: 0.5, depth: 6, label: '2등급' },
  { tier: 3, min: 500, max: 999, rate: 0.5, depth: 8, label: '3등급' },
  { tier: 4, min: 1000, max: 4999, rate: 1.0, depth: 8, label: '4등급' },
  { tier: 5, min: 5000, max: 9999, rate: 1.0, depth: 10, label: '5등급' },
  { tier: 6, min: 10000, max: Infinity, rate: 1.2, depth: 12, label: '6등급' },
];

function calculateTier(amount: number) {
  if (amount < 50) return null;
  for (const tier of TIER_INFO) {
    if (amount >= tier.min && amount <= tier.max) {
      return tier;
    }
  }
  // 10000 이상은 6등급
  return TIER_INFO[5];
}

export default function InvestmentModal({
  isOpen,
  onClose,
  userId,
  currentBalance,
  onSuccess,
}: InvestmentModalProps) {
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const investmentAmount = parseFloat(amount) || 0;
  const tierInfo = calculateTier(investmentAmount);
  const dailyProfit = tierInfo ? investmentAmount * (tierInfo.rate / 100) : 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (isNaN(investmentAmount) || investmentAmount <= 0) {
      setError('유효한 금액을 입력해주세요.');
      return;
    }

    if (investmentAmount < 50) {
      setError('최소 투자 금액은 50 MSUO입니다.');
      return;
    }

    if (investmentAmount > currentBalance) {
      setError(`잔고가 부족합니다. (보유: ${currentBalance.toLocaleString()} MSUO)`);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/user/invest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, amount: investmentAmount }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || '투자 신청에 실패했습니다.');
      }

      alert(data.message || '투자가 완료되었습니다!');
      setAmount('');
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || '투자 신청 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-slate-900 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-white"
          aria-label="닫기"
        >
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <h2 className="mb-4 text-2xl font-bold text-white">투자하기</h2>

        <div className="mb-6 rounded-xl bg-slate-800/50 p-4">
          <p className="text-sm text-slate-400">보유 잔고</p>
          <p className="text-2xl font-bold text-blue-400">
            {currentBalance.toLocaleString()} MSUO
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="amount" className="mb-2 block text-sm font-medium text-slate-300">
              투자 금액 (MSUO)
            </label>
            <input
              id="amount"
              type="number"
              step="0.01"
              min="50"
              max={currentBalance}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-slate-800 px-4 py-3 text-white placeholder-slate-500 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="최소 50 MSUO"
              required
              disabled={loading}
            />
            <p className="mt-1 text-xs text-slate-500">
              최소 투자 금액: 50 MSUO
            </p>
          </div>

          {/* 투자 등급 및 수익 정보 */}
          {tierInfo && investmentAmount >= 50 && (
            <div className="mb-4 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 p-4">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm font-medium text-slate-300">투자 등급</span>
                <span className="rounded-full bg-blue-500/30 px-3 py-1 text-sm font-bold text-blue-300">
                  {tierInfo.label}
                </span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">일일 수익률</span>
                  <span className="font-semibold text-emerald-400">
                    {tierInfo.rate}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">예상 일일 수익</span>
                  <span className="font-semibold text-white">
                    {dailyProfit.toLocaleString(undefined, { maximumFractionDigits: 2 })} MSUO
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">매칭 받을 수 있는 세대</span>
                  <span className="font-semibold text-purple-400">
                    {tierInfo.depth}대
                  </span>
                </div>
              </div>
            </div>
          )}

          {error && (
            <div className="mb-4 rounded-lg bg-red-500/20 border border-red-500/50 p-3 text-sm text-red-300">
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="flex-1 rounded-lg border border-white/10 bg-slate-800 px-4 py-3 font-semibold text-white transition hover:bg-slate-700 disabled:opacity-50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={loading || !amount || investmentAmount < 50 || investmentAmount > currentBalance}
              className="flex-1 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500 px-4 py-3 font-semibold text-white shadow-lg transition hover:from-blue-600 hover:to-purple-600 disabled:opacity-50"
            >
              {loading ? '처리 중...' : '투자하기'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
