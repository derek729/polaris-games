'use client';

import { useState } from 'react';

type WithdrawalModalProps = {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  currentBalance: number;
  onSuccess: () => void;
};

export default function WithdrawalModal({
  isOpen,
  onClose,
  userId,
  currentBalance,
  onSuccess,
}: WithdrawalModalProps) {
  const [amount, setAmount] = useState('');
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const withdrawAmount = parseFloat(amount);
    if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
      setError('유효한 금액을 입력해주세요.');
      return;
    }

    if (withdrawAmount > currentBalance) {
      setError(`잔고가 부족합니다. (보유: ${currentBalance.toLocaleString()} MSUO)`);
      return;
    }

    if (!address.trim() || address.trim().length < 10) {
      setError('유효한 지갑 주소를 입력해주세요.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/user/withdraw', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, amount: withdrawAmount, address: address.trim() }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || '출금 신청에 실패했습니다.');
      }

      alert('출금 신청이 완료되었습니다. 관리자 승인을 기다려주세요.');
      setAmount('');
      setAddress('');
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || '출금 신청 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-slate-900 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-white"
          aria-label="닫기"
        >
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <h2 className="mb-4 text-2xl font-bold text-white">출금 신청</h2>

        <div className="mb-6 rounded-xl bg-slate-800/50 p-4">
          <p className="text-sm text-slate-400">보유 잔고</p>
          <p className="text-2xl font-bold text-emerald-400">
            {currentBalance.toLocaleString()} MSUO
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="amount" className="mb-2 block text-sm font-medium text-slate-300">
              출금 금액 (MSUO)
            </label>
            <input
              id="amount"
              type="number"
              step="0.01"
              min="0"
              max={currentBalance}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-slate-800 px-4 py-3 text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="출금할 금액을 입력하세요"
              required
              disabled={loading}
            />
          </div>

          <div className="mb-4">
            <label htmlFor="address" className="mb-2 block text-sm font-medium text-slate-300">
              입금받을 지갑 주소
            </label>
            <input
              id="address"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full rounded-lg border border-white/10 bg-slate-800 px-4 py-3 text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="지갑 주소를 입력하세요"
              required
              disabled={loading}
            />
            <p className="mt-1 text-xs text-slate-500">
              출금이 승인되면 이 주소로 입금됩니다.
            </p>
          </div>

          {error && (
            <div className="mb-4 rounded-lg bg-red-500/20 border border-red-500/50 p-3 text-sm text-red-300">
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="flex-1 rounded-lg border border-white/10 bg-slate-800 px-4 py-3 font-semibold text-white transition hover:bg-slate-700 disabled:opacity-50"
            >
              취소
            </button>
            <button
              type="submit"
              disabled={loading || !amount || !address.trim()}
              className="flex-1 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-500 px-4 py-3 font-semibold text-white shadow-lg transition hover:from-indigo-600 hover:to-purple-600 disabled:opacity-50"
            >
              {loading ? '처리 중...' : '신청하기'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

