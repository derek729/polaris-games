'use client';

import { useState, useEffect, useRef } from 'react';

interface SearchResult {
  id: string;
  username: string;
  email: string;
  walletAddress: string;
  personalCoin: number;
}

interface UserSearchSelectorProps {
  value: string;
  onChange: (value: string, userInfo?: SearchResult) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

export function UserSearchSelector({
  value,
  onChange,
  placeholder = "사용자 검색...",
  disabled = false,
  className = ""
}: UserSearchSelectorProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedUser, setSelectedUser] = useState<SearchResult | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // 초기값 설정
  useEffect(() => {
    setSearchQuery(value);
  }, [value]);

  // 입력값 변경 처리
  const handleInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setSearchQuery(newValue);
    setIsOpen(true);
    setSelectedUser(null);

    if (newValue.trim().length >= 2) {
      setIsLoading(true);
      try {
        const response = await fetch(`/api/user/search?query=${encodeURIComponent(newValue.trim())}`);
        const result = await response.json();

        if (result.ok) {
          setSearchResults(result.data);
        } else {
          setSearchResults([]);
        }
      } catch (error) {
        console.error('Search error:', error);
        setSearchResults([]);
      } finally {
        setIsLoading(false);
      }
    } else {
      setSearchResults([]);
    }

    // 부모 컴포넌트에 변경 알림
    onChange(newValue);
  };

  // 사용자 선택
  const handleUserSelect = (user: SearchResult) => {
    setSelectedUser(user);
    setSearchQuery(user.email);
    setIsOpen(false);

    // 부모 컴포넌트에 선택된 사용자 정보 전달
    onChange(user.email, user);
  };

  // 포커스 아웃 처리
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      {/* 검색 입력 필드 */}
      <input
        ref={inputRef}
        type="text"
        value={searchQuery}
        onChange={handleInputChange}
        onFocus={() => setIsOpen(true)}
        disabled={disabled}
        placeholder={placeholder}
        className={`w-full px-4 py-4 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent text-lg touch-manipulation ${className}`}
      />

      {/* 검색 결과 드롭다운 */}
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-gray-800 border border-white/20 rounded-lg shadow-lg max-h-60 overflow-y-auto">
          {isLoading ? (
            <div className="p-4 text-center text-gray-400">
              검색 중...
            </div>
          ) : searchResults.length > 0 ? (
            searchResults.map((user) => (
              <div
                key={user.id}
                onClick={() => handleUserSelect(user)}
                className="px-4 py-3 hover:bg-gray-700 cursor-pointer border-b border-gray-700 last:border-b-0 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-medium truncate">
                      {user.username}
                    </div>
                    <div className="text-gray-400 text-sm truncate">
                      {user.email}
                    </div>
                    {user.walletAddress && user.walletAddress !== '미설정' && (
                      <div className="text-gray-500 text-xs truncate">
                        {user.walletAddress}
                      </div>
                    )}
                  </div>
                  <div className="ml-3 text-right">
                    <div className="text-yellow-400 text-sm font-medium">
                      {user.personalCoin.toFixed(2)} MSUO
                    </div>
                    <div className="text-gray-500 text-xs">
                      잔액
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : searchQuery.length >= 2 ? (
            <div className="p-4 text-center text-gray-400">
              검색 결과가 없습니다
            </div>
          ) : null}
        </div>
      )}

      {/* 선택된 사용자 정보 표시 */}
      {selectedUser && (
        <div className="mt-2 p-3 bg-black/30 border border-white/10 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="text-green-400 text-sm font-medium">
                선택된 사용자:
              </div>
              <div className="text-white text-sm">
                {selectedUser.username}
              </div>
              <div className="text-gray-400 text-xs">
                {selectedUser.email}
              </div>
            </div>
            <button
              onClick={() => {
                setSelectedUser(null);
                setSearchQuery('');
                onChange('');
              }}
              className="ml-2 text-red-400 hover:text-red-300 text-sm"
            >
              취소
            </button>
          </div>
        </div>
      )}
    </div>
  );
}