/**
 * 향상된 거래 내역 리스트 컴포넌트
 * 메인넷 동기화 상태 포함
 */
'use client';

import React, { useState, useEffect } from 'react';
import {
  ArrowUpRight,
  ArrowDownLeft,
  Gift,
  CreditCard,
  Filter,
  Search,
  RefreshCw,
  ChevronDown
} from 'lucide-react';
import TransactionStatusBadge from './TransactionStatusBadge';

interface Transaction {
  id: string;
  type: 'sent' | 'received';
  category: 'transfer' | 'reward' | 'withdrawal';
  amount: number;
  fee: number;
  status: string;
  networkType: string;
  txHash?: string | null;
  confirmations?: number | null;
  blockNumber?: number | null;
  gasFee?: number | null;
  mainnetSyncedAt?: string | null;
  description?: string | null;
  rewardType?: string;
  sender?: {
    username: string;
    email: string;
  } | null;
  receiver?: {
    username: string;
    email: string;
  } | null;
  address?: string;
  createdAt: string;
  processedAt?: string;
}

interface EnhancedTransactionListProps {
  userId?: string;
  initialLimit?: number;
  showFilters?: boolean;
}

export default function EnhancedTransactionList({
  initialLimit = 20,
  showFilters = true
}: EnhancedTransactionListProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [limit, setLimit] = useState(initialLimit);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(false);

  const fetchTransactions = async (reset = false) => {
    try {
      setLoading(true);
      const currentOffset = reset ? 0 : offset;
      const currentLimit = reset ? limit : limit + 20;

      const params = new URLSearchParams({
        type: filter === 'all' ? '' : filter,
        limit: currentLimit.toString(),
        offset: currentOffset.toString(),
      });

      const response = await fetch(`/api/user/transactions/with-status?${params}`);
      const result = await response.json();

      if (result.ok) {
        if (reset) {
          setTransactions(result.data.transactions);
          setOffset(0);
        } else {
          setTransactions(prev => [...prev, ...result.data.transactions]);
          setOffset(currentOffset);
        }
        setHasMore(result.data.pagination.hasMore);
        setLimit(currentLimit);
        setError(null);
      } else {
        setError(result.error || '거래 내역 조회 실패');
      }
    } catch (err) {
      setError('서버 연결 오류');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions(true);
  }, [filter]);

  const handleLoadMore = () => {
    fetchTransactions(false);
  };

  const getTransactionIcon = (category: string, type: string) => {
    switch (category) {
      case 'transfer':
        return type === 'sent'
          ? <ArrowUpRight className="w-5 h-5 text-red-500" />
          : <ArrowDownLeft className="w-5 h-5 text-green-500" />;
      case 'reward':
        return <Gift className="w-5 h-5 text-yellow-500" />;
      case 'withdrawal':
        return <CreditCard className="w-5 h-5 text-purple-500" />;
      default:
        return <div className="w-5 h-5 bg-gray-300 rounded-full" />;
    }
  };

  const getTransactionTitle = (transaction: Transaction) => {
    switch (transaction.category) {
      case 'transfer':
        return transaction.type === 'sent'
          ? `${transaction.receiver?.username || '알 수 없는 사용자'}에게 전송`
          : `${transaction.sender?.username || '알 수 없는 사용자'}로부터 수신`;
      case 'reward':
        const rewardTypeMap: Record<string, string> = {
          'DAILY': '일일 리워드',
          'REFERRAL': '추천 리워드',
          'MATCHING': '매칭 리워드',
          'RANK': '랭크 리워드',
          'TEAM': '팀 리워드'
        };
        return rewardTypeMap[transaction.rewardType || ''] || '리워드';
      case 'withdrawal':
        return `출금 (${transaction.address?.substring(0, 10)}...)`;
      default:
        return transaction.description || '거래';
    }
  };

  const filteredTransactions = transactions.filter(transaction =>
    searchTerm === '' ||
    transaction.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    transaction.sender?.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    transaction.receiver?.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading && transactions.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
        <p className="text-red-800">{error}</p>
        <button
          onClick={() => fetchTransactions(true)}
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          다시 시도
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 필터 및 검색 */}
      {showFilters && (
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="거래 내역 검색..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
            >
              <option value="all">모든 거래</option>
              <option value="sent">보낸 거래</option>
              <option value="received">받은 거래</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
          </div>
        </div>
      )}

      {/* 거래 목록 */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        {filteredTransactions.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-2">
              {searchTerm ? '검색 결과가 없습니다' : '거래 내역이 없습니다'}
            </div>
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="text-blue-600 hover:text-blue-800"
              >
                검색 지우기
              </button>
            )}
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {filteredTransactions.map((transaction) => (
              <div key={transaction.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    {/* 아이콘 */}
                    <div className="flex-shrink-0">
                      {getTransactionIcon(transaction.category, transaction.type)}
                    </div>

                    {/* 거래 정보 */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-medium text-gray-900 truncate">
                          {getTransactionTitle(transaction)}
                        </h3>
                        <div className="text-lg font-semibold">
                          <span className={transaction.type === 'sent' ? 'text-red-600' : 'text-green-600'}>
                            {transaction.type === 'sent' ? '-' : '+'}{transaction.amount.toFixed(2)} MSUO
                          </span>
                          {transaction.fee > 0 && (
                            <span className="text-sm text-gray-500 ml-2">
                              (수수료: {transaction.fee.toFixed(2)})
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="mt-2 flex items-center space-x-4 text-sm text-gray-600">
                        <span>
                          {new Date(transaction.createdAt).toLocaleString('ko-KR', {
                          year: 'numeric',
                          month: '2-digit',
                          day: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                        </span>
                        {transaction.category === 'transfer' && transaction.gasFee && (
                          <span>가스비: {transaction.gasFee.toFixed(6)} MSUO</span>
                        )}
                      </div>

                      {/* 상태 배지 */}
                      <div className="mt-3">
                        <TransactionStatusBadge
                          status={transaction.status}
                          networkType={transaction.networkType}
                          txHash={transaction.txHash}
                          confirmations={transaction.confirmations}
                          mainnetSyncedAt={transaction.mainnetSyncedAt}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 더보기 버튼 */}
      {hasMore && !searchTerm && (
        <div className="text-center">
          <button
            onClick={handleLoadMore}
            disabled={loading}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? (
              <div className="flex items-center">
                <RefreshCw className="w-5 h-5 animate-spin mr-2" />
                로딩 중...
              </div>
            ) : (
              '더보기'
            )}
          </button>
        </div>
      )}
    </div>
  );
}