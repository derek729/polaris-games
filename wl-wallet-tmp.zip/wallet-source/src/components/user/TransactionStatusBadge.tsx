/**
 * 거래 상태 배지 컴포넌트
 */
'use client';

import React from 'react';
import { CheckCircle, Clock, AlertCircle, XCircle, Activity, ExternalLink } from 'lucide-react';

interface TransactionStatusBadgeProps {
  status: string;
  networkType: string;
  txHash?: string | null;
  confirmations?: number | null;
  mainnetSyncedAt?: string | null;
  showDetails?: boolean;
}

export default function TransactionStatusBadge({
  status,
  networkType,
  txHash,
  confirmations,
  mainnetSyncedAt,
  showDetails = true
}: TransactionStatusBadgeProps) {
  const getStatusInfo = () => {
    // 네트워크 타입별 상태 결정
    if (networkType === 'OFF_CHAIN') {
      return {
        text: '오프체인',
        color: 'bg-gray-100 text-gray-700 border-gray-300',
        icon: <Clock className="w-4 h-4" />,
        description: '메인넷 동기화 대기 중'
      };
    }

    if (networkType === 'MAINNET') {
      if (status === 'CONFIRMED') {
        return {
          text: confirmations && confirmations >= 6 ? '확인됨' : '컨펌 중',
          color: confirmations && confirmations >= 6
            ? 'bg-green-100 text-green-700 border-green-300'
            : 'bg-blue-100 text-blue-700 border-blue-300',
          icon: confirmations && confirmations >= 6
            ? <CheckCircle className="w-4 h-4" />
            : <Activity className="w-4 h-4" />,
          description: confirmations
            ? `${confirmations}개 컨펌`
            : '컨펌 대기 중'
        };
      }

      if (status === 'PENDING') {
        return {
          text: '처리중',
          color: 'bg-yellow-100 text-yellow-700 border-yellow-300',
          icon: <Clock className="w-4 h-4" />,
          description: '메인넷에서 처리 중'
        };
      }

      if (status === 'FAILED') {
        return {
          text: '실패',
          color: 'bg-red-100 text-red-700 border-red-300',
          icon: <XCircle className="w-4 h-4" />,
          description: '처리 실패'
        };
      }
    }

    // 기본 상태
    const statusMap: Record<string, any> = {
      'PENDING': {
        text: '대기중',
        color: 'bg-yellow-100 text-yellow-700 border-yellow-300',
        icon: <Clock className="w-4 h-4" />,
        description: '처리 대기 중'
      },
      'COMPLETED': {
        text: '완료',
        color: 'bg-green-100 text-green-700 border-green-300',
        icon: <CheckCircle className="w-4 h-4" />,
        description: '처리 완료'
      },
      'FAILED': {
        text: '실패',
        color: 'bg-red-100 text-red-700 border-red-300',
        icon: <XCircle className="w-4 h-4" />,
        description: '처리 실패'
      },
      'CANCELLED': {
        text: '취소됨',
        color: 'bg-gray-100 text-gray-700 border-gray-300',
        icon: <XCircle className="w-4 h-4" />,
        description: '처리 취소'
      }
    };

    return statusMap[status] || statusMap['PENDING'];
  };

  const statusInfo = getStatusInfo();

  const handleViewOnExplorer = () => {
    if (txHash) {
      // 실제 블록체인 익스플로러 URL로 변경 필요
      window.open(`https://explorer.ao-coin.com/tx/${txHash}`, '_blank');
    }
  };

  return (
    <div className="flex items-center space-x-2">
      <div className={`inline-flex items-center px-3 py-1 rounded-full border text-sm font-medium ${statusInfo.color}`}>
        {statusInfo.icon}
        <span className="ml-1">{statusInfo.text}</span>
      </div>

      {showDetails && (
        <div className="flex items-center space-x-3 text-sm text-gray-600">
          {/* 컨펌 수 표시 */}
          {confirmations !== null && confirmations !== undefined && networkType === 'MAINNET' && (
            <span className="flex items-center">
              <Activity className="w-3 h-3 mr-1" />
              {confirmations} 컨펌
            </span>
          )}

          {/* 메인넷 동기화 시간 */}
          {mainnetSyncedAt && (
            <span className="flex items-center">
              <CheckCircle className="w-3 h-3 mr-1" />
              {new Date(mainnetSyncedAt).toLocaleDateString('ko-KR')}
            </span>
          )}

          {/* 블록체인 익스플로러 링크 */}
          {txHash && (
            <button
              onClick={handleViewOnExplorer}
              className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
              title="블록체인에서 보기"
            >
              <ExternalLink className="w-3 h-3 mr-1" />
              탐색기
            </button>
          )}
        </div>
      )}
    </div>
  );
}