'use client';

import { useState, useRef, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { getChatbotResponse, getQuickQuestions, type ChatMessage } from '@/services/chatbot';

interface ChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Chatbot({ isOpen, onClose }: ChatbotProps) {
  const { language, t } = useI18n();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const quickQuestions = getQuickQuestions(language);
  const welcomeMessageRef = useRef<string>(t.chatbot.welcome);
  
  // 초기 환영 메시지 설정 및 언어 변경 시 업데이트
  useEffect(() => {
    if (welcomeMessageRef.current !== t.chatbot.welcome) {
      welcomeMessageRef.current = t.chatbot.welcome;
      if (messages.length === 0 || (messages.length === 1 && messages[0].role === 'assistant')) {
        setMessages([{
          role: 'assistant',
          content: t.chatbot.welcome,
          timestamp: new Date()
        }]);
      }
    } else if (messages.length === 0) {
      // 초기 로드 시에만 환영 메시지 설정
      setMessages([{
        role: 'assistant',
        content: t.chatbot.welcome,
        timestamp: new Date()
      }]);
    }
  }, [language, t.chatbot.welcome]); // messages 의존성 제거로 무한 루프 방지

  // 메시지가 추가될 때마다 스크롤
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 챗봇이 열릴 때 입력창 포커스
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // 챗봇 응답 생성 (약간의 지연으로 자연스러운 느낌)
    setTimeout(() => {
      const response = getChatbotResponse(userMessage.content, language);
      
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response.answer,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 500);
  };

  const handleQuickQuestion = (question: string) => {
    setInputValue(question);
    // 자동 전송
    setTimeout(() => {
      const userMessage: ChatMessage = {
        role: 'user',
        content: question,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, userMessage]);
      setIsLoading(true);

      setTimeout(() => {
        const response = getChatbotResponse(question, language);
        
        const assistantMessage: ChatMessage = {
          role: 'assistant',
          content: response.answer,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, assistantMessage]);
        setIsLoading(false);
      }, 500);
    }, 100);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-end pointer-events-none">
      {/* 배경 오버레이 */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity pointer-events-auto"
        onClick={onClose}
      />
      
      {/* 챗봇 창 */}
      <div className="relative w-full max-w-md h-[500px] sm:h-[600px] max-h-[90vh] bg-[#1a2332] border border-white/10 rounded-t-2xl shadow-2xl flex flex-col pointer-events-auto animate-slide-up">
        {/* 헤더 */}
        <div className="flex items-center justify-between p-3 sm:p-4 border-b border-white/10 bg-[#101922] rounded-t-2xl">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-[#137fec] to-[#3A4DFF] flex items-center justify-center flex-shrink-0">
              <span className="material-symbols-outlined text-white text-lg sm:text-xl">smart_toy</span>
            </div>
            <div className="min-w-0">
              <h3 className="text-white font-semibold text-sm sm:text-base truncate">{t.chatbot.title}</h3>
              <p className="text-xs text-gray-400 hidden sm:block">{t.chatbot.subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition-colors flex-shrink-0"
          >
            <span className="material-symbols-outlined text-lg sm:text-xl">close</span>
          </button>
        </div>

        {/* 메시지 영역 */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 sm:space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[80%] rounded-xl sm:rounded-2xl px-3 py-2 sm:px-4 sm:py-3 ${
                  message.role === 'user'
                    ? 'bg-gradient-to-br from-[#137fec] to-[#3A4DFF] text-white'
                    : 'bg-white/5 text-gray-200 border border-white/10'
                }`}
              >
                <p className="text-xs sm:text-sm whitespace-pre-line leading-relaxed break-words">
                  {message.content}
                </p>
                {message.timestamp && (
                  <p className="text-[10px] sm:text-xs mt-1 opacity-60">
                    {new Date(message.timestamp).toLocaleTimeString('ko-KR', {
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                )}
              </div>
            </div>
          ))}
          
          {/* 로딩 인디케이터 */}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white/5 rounded-2xl px-4 py-3 border border-white/10">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}

          {/* 빠른 질문 제안 (첫 메시지 이후에만 표시) */}
          {messages.length === 2 && !isLoading && (
            <div className="space-y-2">
              <p className="text-[10px] sm:text-xs text-gray-400 px-2">{t.chatbot.quickQuestions}</p>
              <div className="flex flex-wrap gap-1.5 sm:gap-2">
                {quickQuestions.slice(0, 3).map((question, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickQuestion(question)}
                    className="text-[10px] sm:text-xs px-2 sm:px-3 py-1.5 sm:py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-gray-300 hover:text-white transition-colors break-words"
                  >
                    {question}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* 입력 영역 */}
        <div className="p-3 sm:p-4 border-t border-white/10 bg-[#101922]">
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={t.chatbot.placeholder}
              className="flex-1 px-3 sm:px-4 py-2 sm:py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#137fec] focus:border-transparent text-sm sm:text-base"
              disabled={isLoading}
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="px-3 sm:px-4 py-2 sm:py-3 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] text-white rounded-lg hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity flex items-center justify-center min-w-[44px]"
            >
              <span className="material-symbols-outlined text-lg sm:text-xl">send</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

