'use client';

import { useEffect, useState } from 'react';
import { X, Download, Smartphone } from 'lucide-react';
import { useI18n } from '@/lib/i18n/context';

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

export function PWAInstallPrompt() {
  const { language } = useI18n();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  // 초기 상태를 함수형 초기화로 변경하여 useEffect 내 setState 제거
  const [showPrompt, setShowPrompt] = useState(() => {
    if (typeof window === 'undefined') return false;
    const dismissed = localStorage.getItem('pwa-install-dismissed');
    if (dismissed) {
      const timeDiff = Date.now() - parseInt(dismissed);
      const hoursDiff = timeDiff / (1000 * 60 * 60);
      return hoursDiff >= 24; // 24시간 이상 지났으면 true
    }
    return false;
  });
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // 이미 설치되었는지 확인
    const checkIfInstalled = () => {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
      const isInWebAppiOS = (window.navigator as any).standalone === true;
      setIsInstalled(isStandalone || isInWebAppiOS);
    };

    checkIfInstalled();

    // 설치 프롬프트 이벤트 감지
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);

      // 3초 후에 프롬프트 표시
      setTimeout(() => {
        const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
        if (!isStandalone && !(window.navigator as any).standalone) {
          setShowPrompt(true);
        }
      }, 3000);
    };

    // 앱이 설치되었는지 감지
    const handleAppInstalled = () => {
      setIsInstalled(true);
      setShowPrompt(false);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;

    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;

      if (outcome === 'accepted') {
        console.log('사용자가 PWA 설치를 수락했습니다');
      } else {
        console.log('사용자가 PWA 설치를 거절했습니다');
      }

      setDeferredPrompt(null);
      setShowPrompt(false);
    } catch (error) {
      console.error('PWA 설치 중 오류 발생:', error);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    // 24시간 후 다시 표시하지 않도록 쿠키 설정
    localStorage.setItem('pwa-install-dismissed', Date.now().toString());
  };

  // 이 useEffect는 제거됨 - 초기 상태가 이미 함수형 초기화로 처리됨

  if (isInstalled || !showPrompt || !deferredPrompt) {
    return null;
  }

  // iOS 사용자를 위한 안내
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);

  return (
    <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:w-96 z-50 animate-slide-up">
      <div className="bg-gray-800 border border-gray-700 rounded-xl p-4 shadow-2xl">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-blue-500/20 rounded-lg">
            <Smartphone className="w-5 h-5 text-blue-400" />
          </div>

          <div className="flex-1 min-w-0">
            <h3 className="text-white font-semibold mb-1">
              {language === 'ko'
                ? 'MSUO Wallet 앱 설치'
                : language === 'en'
                ? 'Install MSUO Wallet App'
                : language === 'zh'
                ? '安装 MSUO Wallet 应用'
                : language === 'ja'
                ? 'MSUO Wallet アプリをインストール'
                : 'Cài đặt ứng dụng MSUO Wallet'}
            </h3>
            <p className="text-gray-400 text-sm mb-3">
              {language === 'ko'
                ? '홈 화면에 추가하여 더 빠르게 접속하세요!'
                : language === 'en'
                ? 'Add to home screen for faster access!'
                : language === 'zh'
                ? '添加到主屏幕以便更快访问！'
                : language === 'ja'
                ? 'ホーム画面に追加してより速くアクセス！'
                : 'Thêm vào màn hình chính để truy cập nhanh hơn!'}
            </p>

            {isIOS ? (
              <div className="text-xs text-gray-500 space-y-1">
                <p>
                  {language === 'ko'
                    ? '1. 공유 버튼을 눌러주세요'
                    : language === 'en'
                    ? '1. Tap the share button'
                    : language === 'zh'
                    ? '1. 点击分享按钮'
                    : language === 'ja'
                    ? '1. 共有ボタンをタップ'
                    : '1. Nhấn nút chia sẻ'}
                </p>
                <p>
                  {language === 'ko'
                    ? "2. '홈 화면에 추가'를 선택하세요"
                    : language === 'en'
                    ? "2. Select 'Add to Home Screen'"
                    : language === 'zh'
                    ? "2. 选择'添加到主屏幕'"
                    : language === 'ja'
                    ? "2. 'ホーム画面に追加'を選択"
                    : "2. Chọn 'Thêm vào Màn hình chính'"}
                </p>
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={handleInstallClick}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                >
                  <Download className="w-4 h-4" />
                  {language === 'ko'
                    ? '설치하기'
                    : language === 'en'
                    ? 'Install'
                    : language === 'zh'
                    ? '安装'
                    : language === 'ja'
                    ? 'インストール'
                    : 'Cài đặt'}
                </button>
                <button
                  onClick={handleDismiss}
                  className="text-gray-400 hover:text-white px-3 py-2 text-sm transition-colors"
                >
                  {language === 'ko'
                    ? '나중에'
                    : language === 'en'
                    ? 'Later'
                    : language === 'zh'
                    ? '稍后'
                    : language === 'ja'
                    ? '後で'
                    : 'Để sau'}
                </button>
              </div>
            )}
          </div>

          <button
            onClick={handleDismiss}
            className="text-gray-400 hover:text-white p-1 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <style jsx>{`
        @keyframes slide-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        .animate-slide-up {
          animation: slide-up 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}