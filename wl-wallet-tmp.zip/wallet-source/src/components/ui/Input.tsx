'use client';

import { forwardRef, InputHTMLAttributes, ReactNode, useState } from 'react';
import { cn } from '@/lib/utils';

// ============================================
// Input 변형 타입
// ============================================
type InputVariant = 'default' | 'glass' | 'filled' | 'underline';
type InputSize = 'sm' | 'md' | 'lg';

interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'> {
  variant?: InputVariant;
  inputSize?: InputSize;
  label?: string;
  error?: string;
  hint?: string;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  leftElement?: ReactNode;
  rightElement?: ReactNode;
  fullWidth?: boolean;
}

// ============================================
// 메인 Input 컴포넌트
// ============================================
export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      className,
      variant = 'default',
      inputSize = 'md',
      label,
      error,
      hint,
      leftIcon,
      rightIcon,
      leftElement,
      rightElement,
      fullWidth = true,
      type,
      id,
      disabled,
      ...props
    },
    ref
  ) => {
    const [showPassword, setShowPassword] = useState(false);
    const inputId = id || `input-${Math.random().toString(36).slice(2, 9)}`;
    const isPassword = type === 'password';

    const baseClasses = cn(
      'w-full rounded-xl transition-all duration-200 ease-out',
      'focus:outline-none focus:ring-2',
      'placeholder:text-gray-500',
      'disabled:opacity-50 disabled:cursor-not-allowed',
      fullWidth ? 'w-full' : 'w-auto'
    );

    const variantClasses: Record<InputVariant, string> = {
      default: cn(
        'bg-slate-800/50 border border-white/10',
        'text-white',
        'hover:border-white/20',
        'focus:border-blue-500/50 focus:ring-blue-500/20',
        error && 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20'
      ),
      glass: cn(
        'bg-white/5 backdrop-blur-md border border-white/10',
        'text-white',
        'hover:bg-white/10 hover:border-white/15',
        'focus:bg-white/10 focus:border-blue-500/50 focus:ring-blue-500/20',
        error && 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20'
      ),
      filled: cn(
        'bg-slate-700/50 border-none',
        'text-white',
        'hover:bg-slate-700/70',
        'focus:bg-slate-700/70 focus:ring-blue-500/20',
        error && 'bg-red-500/10 focus:ring-red-500/20'
      ),
      underline: cn(
        'bg-transparent border-0 border-b-2 border-white/20 rounded-none',
        'text-white',
        'hover:border-white/30',
        'focus:border-blue-500 focus:ring-0 rounded-none',
        error && 'border-red-500'
      ),
    };

    const sizeClasses: Record<InputSize, string> = {
      sm: 'text-sm px-3 py-2 h-9',
      md: 'text-sm px-4 py-2.5 h-11',
      lg: 'text-base px-5 py-3 h-13',
    };

    const iconPadding = {
      sm: { left: 'pl-9', right: 'pr-9' },
      md: { left: 'pl-11', right: 'pr-11' },
      lg: { left: 'pl-13', right: 'pr-13' },
    };

    return (
      <div className={cn('flex flex-col gap-1.5', fullWidth ? 'w-full' : 'w-auto')}>
        {/* 라벨 */}
        {label && (
          <label
            htmlFor={inputId}
            className="text-sm font-medium text-gray-300"
          >
            {label}
          </label>
        )}

        {/* 입력 필드 컨테이너 */}
        <div className="relative">
          {/* 왼쪽 아이콘/요소 */}
          {(leftIcon || leftElement) && (
            <div className={cn(
              'absolute left-0 top-0 bottom-0 flex items-center justify-center',
              'pointer-events-none',
              leftIcon && 'text-gray-400',
              inputSize === 'sm' && 'w-9',
              inputSize === 'md' && 'w-11',
              inputSize === 'lg' && 'w-13'
            )}>
              {leftIcon}
              {leftElement && (
                <div className="pointer-events-auto">
                  {leftElement}
                </div>
              )}
            </div>
          )}

          {/* 입력 필드 */}
          <input
            ref={ref}
            id={inputId}
            type={isPassword && showPassword ? 'text' : type}
            disabled={disabled}
            className={cn(
              baseClasses,
              variantClasses[variant],
              sizeClasses[inputSize],
              leftIcon && iconPadding[inputSize].left,
              rightIcon && iconPadding[inputSize].right,
              (leftElement) && iconPadding[inputSize].left,
              (rightElement || isPassword) && iconPadding[inputSize].right,
              className
            )}
            {...props}
          />

          {/* 오른쪽 아이콘/요소 */}
          {(rightIcon || rightElement || isPassword) && (
            <div className={cn(
              'absolute right-0 top-0 bottom-0 flex items-center justify-center',
              inputSize === 'sm' && 'w-9',
              inputSize === 'md' && 'w-11',
              inputSize === 'lg' && 'w-13'
            )}>
              {/* 비밀번호 토글 */}
              {isPassword && (
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-gray-400 hover:text-white transition-colors p-1"
                  tabIndex={-1}
                >
                  <span className="material-symbols-outlined text-lg">
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </span>
                </button>
              )}
              {rightIcon && !isPassword && (
                <span className="text-gray-400">{rightIcon}</span>
              )}
              {rightElement && !isPassword && (
                <div className="pointer-events-auto">
                  {rightElement}
                </div>
              )}
            </div>
          )}
        </div>

        {/* 에러 메시지 */}
        {error && (
          <p className="text-sm text-red-400 flex items-center gap-1 animate-slide-up">
            <span className="material-symbols-outlined text-sm">error</span>
            {error}
          </p>
        )}

        {/* 힌트 메시지 */}
        {hint && !error && (
          <p className="text-xs text-gray-500">{hint}</p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';

// ============================================
// Textarea 컴포넌트
// ============================================
interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  hint?: string;
  variant?: InputVariant;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, variant = 'default', label, error, hint, id, ...props }, ref) => {
    const textareaId = id || `textarea-${Math.random().toString(36).slice(2, 9)}`;

    const variantClasses: Record<InputVariant, string> = {
      default: 'bg-slate-800/50 border border-white/10 hover:border-white/20 focus:border-blue-500/50',
      glass: 'bg-white/5 backdrop-blur-md border border-white/10 hover:bg-white/10 focus:border-blue-500/50',
      filled: 'bg-slate-700/50 border-none hover:bg-slate-700/70',
      underline: 'bg-transparent border-0 border-b-2 border-white/20 rounded-none focus:border-blue-500',
    };

    return (
      <div className="flex flex-col gap-1.5">
        {label && (
          <label htmlFor={textareaId} className="text-sm font-medium text-gray-300">
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          id={textareaId}
          className={cn(
            'w-full rounded-xl px-4 py-3 text-white',
            'placeholder:text-gray-500',
            'focus:outline-none focus:ring-2 focus:ring-blue-500/20',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            'transition-all duration-200',
            variantClasses[variant],
            error && 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20',
            className
          )}
          {...props}
        />
        {error && (
          <p className="text-sm text-red-400 flex items-center gap-1">
            <span className="material-symbols-outlined text-sm">error</span>
            {error}
          </p>
        )}
        {hint && !error && <p className="text-xs text-gray-500">{hint}</p>}
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';

// ============================================
// Select 컴포넌트
// ============================================
interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface SelectProps extends Omit<InputHTMLAttributes<HTMLSelectElement>, 'size'> {
  options: SelectOption[];
  label?: string;
  error?: string;
  hint?: string;
  inputSize?: InputSize;
  placeholder?: string;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  (
    { className, options, label, error, hint, inputSize = 'md', placeholder, id, ...props },
    ref
  ) => {
    const selectId = id || `select-${Math.random().toString(36).slice(2, 9)}`;

    const sizeClasses: Record<InputSize, string> = {
      sm: 'text-sm px-3 py-2 h-9',
      md: 'text-sm px-4 py-2.5 h-11',
      lg: 'text-base px-5 py-3 h-13',
    };

    return (
      <div className="flex flex-col gap-1.5">
        {label && (
          <label htmlFor={selectId} className="text-sm font-medium text-gray-300">
            {label}
          </label>
        )}
        <div className="relative">
          <select
            ref={ref}
            id={selectId}
            className={cn(
              'w-full rounded-xl appearance-none',
              'bg-slate-800/50 border border-white/10',
              'text-white',
              'hover:border-white/20',
              'focus:outline-none focus:ring-2 focus:border-blue-500/50 focus:ring-blue-500/20',
              'disabled:opacity-50 disabled:cursor-not-allowed',
              'transition-all duration-200',
              'cursor-pointer',
              sizeClasses[inputSize],
              error && 'border-red-500/50 focus:border-red-500 focus:ring-red-500/20',
              className
            )}
            {...props}
          >
            {placeholder && (
              <option value="" disabled>
                {placeholder}
              </option>
            )}
            {options.map((option) => (
              <option key={option.value} value={option.value} disabled={option.disabled}>
                {option.label}
              </option>
            ))}
          </select>
          <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
            expand_more
          </span>
        </div>
        {error && (
          <p className="text-sm text-red-400 flex items-center gap-1">
            <span className="material-symbols-outlined text-sm">error</span>
            {error}
          </p>
        )}
        {hint && !error && <p className="text-xs text-gray-500">{hint}</p>}
      </div>
    );
  }
);

Select.displayName = 'Select';

// ============================================
// Checkbox 컴포넌트
// ============================================
interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  description?: string;
}

export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  ({ className, label, description, id, ...props }, ref) => {
    const checkboxId = id || `checkbox-${Math.random().toString(36).slice(2, 9)}`;

    return (
      <label htmlFor={checkboxId} className="flex items-start gap-3 cursor-pointer group">
        <div className="relative flex items-center justify-center">
          <input
            ref={ref}
            id={checkboxId}
            type="checkbox"
            className={cn(
              'w-5 h-5 rounded-md',
              'bg-slate-800/50 border-2 border-white/20',
              'checked:bg-blue-500 checked:border-blue-500',
              'hover:border-white/40',
              'focus:outline-none focus:ring-2 focus:ring-blue-500/30',
              'transition-all duration-200',
              'cursor-pointer',
              className
            )}
            {...props}
          />
          <span className="material-symbols-outlined absolute text-white text-sm opacity-0 peer-checked:opacity-100 transition-opacity">
            check
          </span>
        </div>
        {(label || description) && (
          <div className="flex flex-col">
            {label && <span className="text-sm font-medium text-white group-hover:text-blue-400 transition-colors">{label}</span>}
            {description && <span className="text-xs text-gray-400">{description}</span>}
          </div>
        )}
      </label>
    );
  }
);

Checkbox.displayName = 'Checkbox';

export default Input;
