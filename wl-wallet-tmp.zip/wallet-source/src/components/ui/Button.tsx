'use client';

import { forwardRef, ButtonHTMLAttributes, ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { Spinner } from './LoadingState';

// ============================================
// 버튼 변형 타입
// ============================================
type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'glass' | 'destructive' | 'outline' | 'link';
type ButtonSize = 'sm' | 'md' | 'lg' | 'xl' | 'icon';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  fullWidth?: boolean;
}

// ============================================
// 메인 Button 컴포넌트
// ============================================
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      children,
      className,
      variant = 'primary',
      size = 'md',
      loading = false,
      leftIcon,
      rightIcon,
      fullWidth = false,
      disabled,
      ...props
    },
    ref
  ) => {
    const baseClasses = cn(
      'inline-flex items-center justify-center gap-2',
      'font-medium rounded-xl',
      'transition-all duration-200 ease-out',
      'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900',
      'disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none',
      'active:scale-[0.98]',
      'select-none'
    );

    const variantClasses: Record<ButtonVariant, string> = {
      primary: cn(
        'bg-gradient-to-r from-blue-500 to-blue-600',
        'text-white',
        'shadow-lg shadow-blue-500/25',
        'hover:shadow-xl hover:shadow-blue-500/30 hover:from-blue-600 hover:to-blue-700',
        'active:shadow-md'
      ),
      secondary: cn(
        'bg-slate-700/80',
        'text-white',
        'border border-white/10',
        'hover:bg-slate-600/80 hover:border-white/20',
        'active:bg-slate-700'
      ),
      ghost: cn(
        'bg-transparent',
        'text-gray-300',
        'hover:bg-white/5 hover:text-white',
        'active:bg-white/10'
      ),
      glass: cn(
        'bg-white/5 backdrop-blur-md',
        'text-white',
        'border border-white/10',
        'hover:bg-white/10 hover:border-white/20',
        'active:bg-white/15'
      ),
      destructive: cn(
        'bg-gradient-to-r from-red-500 to-red-600',
        'text-white',
        'shadow-lg shadow-red-500/25',
        'hover:shadow-xl hover:shadow-red-500/30 hover:from-red-600 hover:to-red-700',
        'active:shadow-md'
      ),
      outline: cn(
        'bg-transparent',
        'text-blue-400',
        'border-2 border-blue-500/50',
        'hover:bg-blue-500/10 hover:border-blue-500',
        'active:bg-blue-500/20'
      ),
      link: cn(
        'bg-transparent',
        'text-blue-400 underline-offset-4',
        'hover:text-blue-300 hover:underline',
        'p-0 h-auto'
      ),
    };

    const sizeClasses: Record<ButtonSize, string> = {
      sm: 'text-xs px-3 py-1.5 h-8',
      md: 'text-sm px-4 py-2.5 h-10',
      lg: 'text-base px-6 py-3 h-12',
      xl: 'text-lg px-8 py-4 h-14',
      icon: 'p-2.5 h-10 w-10',
    };

    return (
      <button
        ref={ref}
        className={cn(
          baseClasses,
          variantClasses[variant],
          sizeClasses[size],
          fullWidth && 'w-full',
          className
        )}
        disabled={disabled || loading}
        {...props}
      >
        {loading ? (
          <Spinner size="sm" color="current" className="opacity-80" />
        ) : (
          leftIcon
        )}
        {children}
        {!loading && rightIcon}
      </button>
    );
  }
);

Button.displayName = 'Button';

// ============================================
// 아이콘 버튼
// ============================================
interface IconButtonProps extends Omit<ButtonProps, 'leftIcon' | 'rightIcon' | 'children'> {
  icon: ReactNode;
  'aria-label': string;
}

export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(
  ({ icon, className, size = 'icon', variant = 'ghost', ...props }, ref) => {
    return (
      <Button
        ref={ref}
        variant={variant}
        size={size}
        className={className}
        {...props}
      >
        {icon}
      </Button>
    );
  }
);

IconButton.displayName = 'IconButton';

// ============================================
// 버튼 그룹
// ============================================
interface ButtonGroupProps {
  children: ReactNode;
  className?: string;
  orientation?: 'horizontal' | 'vertical';
  gap?: 'sm' | 'md' | 'lg';
}

export function ButtonGroup({
  children,
  className,
  orientation = 'horizontal',
  gap = 'md',
}: ButtonGroupProps) {
  const gapClasses = {
    sm: 'gap-2',
    md: 'gap-3',
    lg: 'gap-4',
  };

  return (
    <div
      className={cn(
        'flex',
        orientation === 'vertical' ? 'flex-col' : 'flex-row',
        gapClasses[gap],
        className
      )}
    >
      {children}
    </div>
  );
}

// ============================================
// 로딩 버튼 (기본 제공)
// ============================================
interface LoadingButtonProps extends ButtonProps {
  loadingText?: string;
}

export const LoadingButton = forwardRef<HTMLButtonElement, LoadingButtonProps>(
  ({ loading, loadingText, children, ...props }, ref) => {
    return (
      <Button ref={ref} loading={loading} {...props}>
        {loading && loadingText ? loadingText : children}
      </Button>
    );
  }
);

LoadingButton.displayName = 'LoadingButton';

export default Button;
