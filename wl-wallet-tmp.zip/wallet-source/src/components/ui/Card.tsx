import { cn } from '@/lib/utils';
import { forwardRef, HTMLAttributes } from 'react';

// ============================================
// 기본 Card 컴포넌트
// ============================================
interface CardProps extends HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'glass' | 'gradient' | 'outline';
  hover?: boolean;
  clickable?: boolean;
  glow?: boolean;
}

export const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ children, className, variant = 'default', hover = false, clickable = false, glow = false, ...props }, ref) => {
    const baseClasses = 'rounded-xl transition-all duration-300 overflow-hidden';
    
    const variantClasses = {
      default: 'bg-gradient-to-br from-slate-800/80 to-slate-800/60 border border-white/10',
      glass: 'glass-card',
      gradient: 'bg-gradient-to-br from-blue-900/30 to-purple-900/30 border border-blue-500/20',
      outline: 'bg-transparent border border-white/20',
    };
    
    const hoverClasses = hover 
      ? 'hover:border-white/20 hover:shadow-lg hover:shadow-blue-500/5 hover:-translate-y-1' 
      : '';
    
    const clickClasses = clickable 
      ? 'cursor-pointer active:scale-[0.98] active:shadow-md' 
      : '';
    
    const glowClasses = glow 
      ? 'shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30' 
      : '';

    return (
      <div
        ref={ref}
        className={cn(baseClasses, variantClasses[variant], hoverClasses, clickClasses, glowClasses, className)}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Card.displayName = 'Card';

// ============================================
// Card Header
// ============================================
interface CardHeaderProps extends HTMLAttributes<HTMLDivElement> {
  action?: React.ReactNode;
}

export const CardHeader = forwardRef<HTMLDivElement, CardHeaderProps>(
  ({ children, className, action, ...props }, ref) => (
    <div
      ref={ref}
      className={cn('flex items-center justify-between p-4 sm:p-6 pb-3 sm:pb-4', className)}
      {...props}
    >
      <div className="flex-1">{children}</div>
      {action && <div className="flex-shrink-0">{action}</div>}
    </div>
  )
);

CardHeader.displayName = 'CardHeader';

// ============================================
// Card Content
// ============================================
interface CardContentProps extends HTMLAttributes<HTMLDivElement> {
  padding?: 'none' | 'sm' | 'md' | 'lg';
}

export const CardContent = forwardRef<HTMLDivElement, CardContentProps>(
  ({ children, className, padding = 'md', ...props }, ref) => {
    const paddingClasses = {
      none: '',
      sm: 'p-3',
      md: 'p-4 sm:p-6',
      lg: 'p-6 sm:p-8',
    };

    return (
      <div
        ref={ref}
        className={cn(paddingClasses[padding], className)}
        {...props}
      >
        {children}
      </div>
    );
  }
);

CardContent.displayName = 'CardContent';

// ============================================
// Card Footer
// ============================================
interface CardFooterProps extends HTMLAttributes<HTMLDivElement> {
  divided?: boolean;
}

export const CardFooter = forwardRef<HTMLDivElement, CardFooterProps>(
  ({ children, className, divided = true, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(
        'p-4 sm:p-6 pt-3 sm:pt-4',
        divided && 'border-t border-white/10',
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
);

CardFooter.displayName = 'CardFooter';

// ============================================
// Menu Card (터치 최적화)
// ============================================
interface MenuCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: 'blue' | 'green' | 'purple' | 'orange' | 'red' | 'cyan';
  href: string;
  badge?: string;
  onClick?: () => void;
}

const colorMap = {
  blue: 'from-blue-600/20 to-blue-800/20 hover:from-blue-600/30 hover:to-blue-800/30 border-blue-500/30',
  green: 'from-green-600/20 to-green-800/20 hover:from-green-600/30 hover:to-green-800/30 border-green-500/30',
  purple: 'from-purple-600/20 to-purple-800/20 hover:from-purple-600/30 hover:to-purple-800/30 border-purple-500/30',
  orange: 'from-orange-600/20 to-orange-800/20 hover:from-orange-600/30 hover:to-orange-800/30 border-orange-500/30',
  red: 'from-red-600/20 to-red-800/20 hover:from-red-600/30 hover:to-red-800/30 border-red-500/30',
  cyan: 'from-cyan-600/20 to-cyan-800/20 hover:from-cyan-600/30 hover:to-cyan-800/30 border-cyan-500/30',
};

export function MenuCard({ title, description, icon, color, href, badge, onClick }: MenuCardProps) {
  const content = (
    <>
      <div className="flex items-start justify-between mb-4">
        <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-sm">
          <div className="h-6 w-6 sm:h-8 sm:w-8 text-white">{icon}</div>
        </div>
        {badge && (
          <span className="px-2 py-0.5 text-xs font-medium rounded-full bg-white/10 text-white/80">
            {badge}
          </span>
        )}
      </div>
      <h3 className="text-base sm:text-lg font-semibold text-white mb-1">{title}</h3>
      <p className="text-sm text-gray-400 line-clamp-2">{description}</p>
    </>
  );

  if (onClick) {
    return (
      <button
        onClick={onClick}
        className={`w-full text-left rounded-xl p-4 sm:p-6 bg-gradient-to-br border transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] min-h-[140px] sm:min-h-[160px] ${colorMap[color]}`}
      >
        {content}
      </button>
    );
  }

  return (
    <a
      href={href}
      className={`block rounded-xl p-4 sm:p-6 bg-gradient-to-br border transition-all duration-300 hover:scale-[1.02] active:scale-[0.98] min-h-[140px] sm:min-h-[160px] ${colorMap[color]}`}
    >
      {content}
    </a>
  );
}

// ============================================
// Stat Card (통계 카드)
// ============================================
interface StatCardProps {
  title: string;
  value: string | number;
  icon?: React.ReactNode;
  change?: string;
  trend?: 'up' | 'down' | 'neutral';
  subtitle?: string;
  gradient?: 'blue' | 'green' | 'purple' | 'orange' | 'red';
}

const gradientMap = {
  blue: 'from-blue-500 to-blue-600',
  green: 'from-green-500 to-green-600',
  purple: 'from-purple-500 to-purple-600',
  orange: 'from-orange-500 to-orange-600',
  red: 'from-red-500 to-red-600',
};

export function StatCard({ 
  title, 
  value, 
  icon, 
  change, 
  trend = 'neutral',
  subtitle,
  gradient = 'blue'
}: StatCardProps) {
  const trendColors = {
    up: 'text-green-400 bg-green-400/10',
    down: 'text-red-400 bg-red-400/10',
    neutral: 'text-gray-400 bg-gray-400/10',
  };

  const trendIcons = {
    up: '↑',
    down: '↓',
    neutral: '→',
  };

  return (
    <Card variant="glass" hover glow>
      <CardContent>
        <div className="flex items-start justify-between mb-4">
          {icon && (
            <div className={'p-3 rounded-xl bg-gradient-to-br ' + gradientMap[gradient] + ' shadow-lg'}>
              <div className="h-5 w-5 sm:h-6 sm:w-6 text-white">{icon}</div>
            </div>
          )}
          {change && (
            <span className={cn(
              'flex items-center gap-1 text-xs sm:text-sm font-medium px-2 py-1 rounded-full',
              trendColors[trend]
            )}>
              <span>{trendIcons[trend]}</span>
              {change}
            </span>
          )}
        </div>
        <div className="space-y-1">
          <p className="text-xs sm:text-sm text-gray-400">{title}</p>
          <p className="text-xl sm:text-2xl font-bold text-white">{value}</p>
          {subtitle && (
            <p className="text-xs text-gray-500">{subtitle}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// ============================================
// Feature Card (기능 소개 카드)
// ============================================
interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  features?: string[];
}

export function FeatureCard({ title, description, icon, features }: FeatureCardProps) {
  return (
    <Card variant="glass" hover className="h-full">
      <CardContent padding="lg">
        <div className="flex flex-col items-center text-center">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 mb-4">
            <div className="h-10 w-10 text-blue-400">{icon}</div>
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">{title}</h3>
          <p className="text-sm text-gray-400 mb-4">{description}</p>
          {features && features.length > 0 && (
            <ul className="space-y-2 text-sm text-gray-300">
              {features.map((feature, index) => (
                <li key={index} className="flex items-center gap-2">
                  <span className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                  {feature}
                </li>
              ))}
            </ul>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// 기존 호환성 유지
export { Card as default };
