'use client';

import { createContext, useContext, useState, useCallback, ReactNode, useEffect } from 'react';
import { cn } from '@/lib/utils';

// ============================================
// Toast 타입 정의
// ============================================
type ToastType = 'success' | 'error' | 'warning' | 'info' | 'default';

interface ToastMessage {
  id: string;
  type: ToastType;
  title?: string;
  message: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

interface ToastContextType {
  toasts: ToastMessage[];
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;
  clearAllToasts: () => void;
}

// ============================================
// Context 생성
// ============================================
const ToastContext = createContext<ToastContextType | null>(null);

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
}

// ============================================
// Toast Provider
// ============================================
interface ToastProviderProps {
  children: ReactNode;
  maxToasts?: number;
  defaultDuration?: number;
}

export function ToastProvider({
  children,
  maxToasts = 5,
  defaultDuration = 5000
}: ToastProviderProps) {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    const newToast: ToastMessage = {
      ...toast,
      id,
      duration: toast.duration ?? defaultDuration,
    };

    setToasts((prev) => {
      const updated = [...prev, newToast];
      return updated.slice(-maxToasts);
    });
  }, [maxToasts, defaultDuration]);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const clearAllToasts = useCallback(() => {
    setToasts([]);
  }, []);

  return (
    <ToastContext.Provider value={{ toasts, addToast, removeToast, clearAllToasts }}>
      {children}
      <ToastContainer />
    </ToastContext.Provider>
  );
}

// ============================================
// Toast Container
// ============================================
function ToastContainer() {
  const { toasts, removeToast } = useToast();

  return (
    <div
      aria-live="polite"
      aria-atomic="true"
      className="fixed z-[100] flex flex-col gap-3 pointer-events-none"
      style={{
        bottom: '1.5rem',
        right: '1.5rem',
        maxWidth: 'calc(100vw - 2rem)',
      }}
    >
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onClose={() => removeToast(toast.id)} />
      ))}
    </div>
  );
}

// ============================================
// 개별 Toast 아이템
// ============================================
interface ToastItemProps {
  toast: ToastMessage;
  onClose: () => void;
}

function ToastItem({ toast, onClose }: ToastItemProps) {
  useEffect(() => {
    if (toast.duration && toast.duration > 0) {
      const timer = setTimeout(onClose, toast.duration);
      return () => clearTimeout(timer);
    }
  }, [toast.duration, onClose]);

  const typeStyles = {
    success: {
      bg: 'bg-gradient-to-r from-green-600/90 to-green-700/90',
      border: 'border-green-500/50',
      icon: 'check_circle',
      glow: 'shadow-green-500/30',
    },
    error: {
      bg: 'bg-gradient-to-r from-red-600/90 to-red-700/90',
      border: 'border-red-500/50',
      icon: 'error',
      glow: 'shadow-red-500/30',
    },
    warning: {
      bg: 'bg-gradient-to-r from-amber-600/90 to-amber-700/90',
      border: 'border-amber-500/50',
      icon: 'warning',
      glow: 'shadow-amber-500/30',
    },
    info: {
      bg: 'bg-gradient-to-r from-blue-600/90 to-blue-700/90',
      border: 'border-blue-500/50',
      icon: 'info',
      glow: 'shadow-blue-500/30',
    },
    default: {
      bg: 'bg-gradient-to-r from-slate-700/90 to-slate-800/90',
      border: 'border-slate-500/50',
      icon: 'notifications',
      glow: 'shadow-slate-500/20',
    },
  };

  const style = typeStyles[toast.type];

  return (
    <div
            className={cn(
        'pointer-events-auto flex items-start gap-3 p-4 rounded-xl border backdrop-blur-md',
        'shadow-lg animate-slide-up',
        'min-w-[300px] max-w-[420px]',
        style.bg,
        style.border
      )}
      style={{ boxShadow: `0 10px 40px rgba(0, 0, 0, 0.4), 0 0 20px ${style.glow}` }}
    >
      {/* 아이콘 */}
      <span className="material-symbols-outlined text-xl text-white flex-shrink-0">
        {style.icon}
      </span>

      {/* 내용 */}
      <div className="flex-1 min-w-0">
        {toast.title && (
          <h4 className="text-sm font-semibold text-white mb-0.5">{toast.title}</h4>
        )}
        <p className="text-sm text-white/90">{toast.message}</p>
        
        {/* 액션 버튼 */}
        {toast.action && (
          <button
            onClick={toast.action.onClick}
            className="mt-2 text-sm font-medium text-white/90 hover:text-white underline underline-offset-2 transition-colors"
          >
            {toast.action.label}
          </button>
        )}
      </div>

      {/* 닫기 버튼 */}
      <button
        onClick={onClose}
        className="flex-shrink-0 p-1 rounded-lg hover:bg-white/10 text-white/60 hover:text-white transition-colors"
      >
        <span className="material-symbols-outlined text-lg">close</span>
      </button>
    </div>
  );
}

// ============================================
// 편의 함수들
// ============================================
export const toast = {
  success: (message: string, options?: Partial<ToastMessage>) => ({
    type: 'success' as const,
    message,
    ...options,
  }),
  error: (message: string, options?: Partial<ToastMessage>) => ({
    type: 'error' as const,
    message,
    ...options,
  }),
  warning: (message: string, options?: Partial<ToastMessage>) => ({
    type: 'warning' as const,
    message,
    ...options,
  }),
  info: (message: string, options?: Partial<ToastMessage>) => ({
    type: 'info' as const,
    message,
    ...options,
  }),
};

// 기존 호환성 유지 - 간단한 Toast 함수
interface SimpleToastProps {
  message: string;
  type?: ToastType;
  duration?: number;
}

export function showToast({ message, type = 'info', duration = 3000 }: SimpleToastProps) {
  // 이 함수는 useToast 훅과 함께 사용해야 함
  console.log('Toast:', type, message);
}

export default ToastProvider;
