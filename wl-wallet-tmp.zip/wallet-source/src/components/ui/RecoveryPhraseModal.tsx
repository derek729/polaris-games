'use client';

import { useState } from 'react';

interface RecoveryPhraseModalProps {
  isOpen: boolean;
  onClose: () => void;
  recoveryPhrase: string[];
  address: string;
}

export default function RecoveryPhraseModal({
  isOpen,
  onClose,
  recoveryPhrase,
  address,
}: RecoveryPhraseModalProps) {
  const [copied, setCopied] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [showPhrase, setShowPhrase] = useState(false);

  if (!isOpen) return null;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(recoveryPhrase.join(' '));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([`지갑 주소: ${address}\n\n복구 구문 (20개 단어):\n${recoveryPhrase.join(' ')}`], {
      type: 'text/plain',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `msuo-recovery-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border border-white/10 bg-[#101922] p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">🔐 복구 구문 안내</h2>
          <button
            onClick={onClose}
            className="rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 px-3 py-2 text-sm font-semibold text-white transition-colors"
          >
            닫기
          </button>
        </div>

        <div className="space-y-6">
          <div className="rounded-xl border border-yellow-500/50 bg-yellow-500/10 p-4">
            <div className="flex items-start gap-3">
              <span className="material-symbols-outlined text-2xl text-yellow-500">warning</span>
              <div className="flex-1">
                <h3 className="font-semibold text-yellow-400 mb-2">⚠️ 중요 안내</h3>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li>• 복구 구문은 지갑을 복구하는 유일한 방법입니다.</li>
                  <li>• 복구 구문을 분실하면 지갑을 복구할 수 없습니다.</li>
                  <li>• 복구 구문을 절대 타인과 공유하지 마세요.</li>
                  <li>• 복구 구문을 오프라인으로 안전하게 보관하세요.</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-white/10 bg-black/20 p-6">
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-white mb-2">지갑 주소</h3>
              <code className="text-sm text-gray-300 break-all font-mono bg-black/30 px-3 py-2 rounded block">{address}</code>
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold text-white">복구 구문 (20개 단어)</h3>
                <label className="flex items-center gap-2 text-sm text-gray-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confirmed}
                    onChange={(e) => setConfirmed(e.target.checked)}
                    className="w-4 h-4 rounded"
                  />
                  <span>복구 구문을 안전하게 보관했음</span>
                </label>
              </div>

              {!showPhrase ? (
                <button
                  onClick={() => setShowPhrase(true)}
                  className="w-full rounded-lg bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/50 px-4 py-3 text-sm font-semibold text-yellow-400 transition-colors"
                >
                  복구 구문 표시하기 (클릭하여 확인)
                </button>
              ) : (
                <>
                  <div className="mb-4 rounded-lg bg-black/30 p-4 border border-white/10">
                    <div className="grid grid-cols-4 md:grid-cols-5 gap-2 text-sm">
                      {recoveryPhrase.map((word, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <span className="text-gray-500 font-mono text-xs">{index + 1}.</span>
                          <span className="text-white font-mono">{word}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={handleCopy}
                      className="flex-1 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/50 px-4 py-3 text-sm font-semibold text-blue-400 transition-colors flex items-center justify-center gap-2"
                    >
                      <span className="material-symbols-outlined">content_copy</span>
                      {copied ? '복사됨!' : '복구 구문 복사'}
                    </button>
                    <button
                      onClick={handleDownload}
                      className="flex-1 rounded-lg bg-green-500/20 hover:bg-green-500/30 border border-green-500/50 px-4 py-3 text-sm font-semibold text-green-400 transition-colors flex items-center justify-center gap-2"
                    >
                      <span className="material-symbols-outlined">download</span>
                      파일로 다운로드
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          <button
            onClick={onClose}
            disabled={!confirmed}
            className="w-full rounded-lg bg-[#137fec] hover:bg-[#0f6fd0] px-6 py-3 text-base font-semibold text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            확인하고 닫기
          </button>
        </div>
      </div>
    </div>
  );
}
