'use client';

import { cn } from '@/lib/utils';

// ============================================
// 스켈레톤 컴포넌트
// ============================================
interface SkeletonProps {
  className?: string;
  variant?: 'text' | 'circular' | 'rectangular' | 'rounded';
  width?: string | number;
  height?: string | number;
  animation?: 'pulse' | 'shimmer' | 'none';
}

export function Skeleton({
  className,
  variant = 'text',
  width,
  height,
  animation = 'shimmer'
}: SkeletonProps) {
  const baseClasses = 'bg-slate-700/50';
  
  const variantClasses = {
    text: 'rounded h-4',
    circular: 'rounded-full',
    rectangular: 'rounded-none',
    rounded: 'rounded-xl',
  };
  
  const animationClasses = {
    pulse: 'animate-pulse',
    shimmer: 'relative overflow-hidden before:absolute before:inset-0 before:-translate-x-full before:animate-[shimmer_1.5s_infinite] before:bg-gradient-to-r before:from-transparent before:via-white/10 before:to-transparent',
    none: '',
  };

  return (
    <div
      className={cn(baseClasses, variantClasses[variant], animationClasses[animation], className)}
      style={{ width, height }}
    />
  );
}

// ============================================
// 스켈레톤 텍스트 라인
// ============================================
interface SkeletonTextProps {
  lines?: number;
  className?: string;
  lastLineWidth?: string;
}

export function SkeletonText({ lines = 3, className, lastLineWidth = '60%' }: SkeletonTextProps) {
  return (
    <div className={cn('space-y-2', className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton
          key={i}
          variant="text"
          className={cn('h-4', i === lines - 1 && lastLineWidth)}
          width={i === lines - 1 ? lastLineWidth : undefined}
        />
      ))}
    </div>
  );
}

// ============================================
// 스켈레톤 아바타
// ============================================
interface SkeletonAvatarProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const avatarSizes = {
  sm: 'w-8 h-8',
  md: 'w-10 h-10',
  lg: 'w-12 h-12',
  xl: 'w-16 h-16',
};

export function SkeletonAvatar({ size = 'md', className }: SkeletonAvatarProps) {
  return (
    <Skeleton
      variant="circular"
      className={cn(avatarSizes[size], className)}
    />
  );
}

// ============================================
// 스켈레톤 카드
// ============================================
interface SkeletonCardProps {
  className?: string;
  showHeader?: boolean;
  showAvatar?: boolean;
  lines?: number;
  variant?: 'default' | 'stat' | 'menu';
}

export function SkeletonCard({
  className,
  showHeader = true,
  showAvatar = false,
  lines = 3,
  variant = 'default'
}: SkeletonCardProps) {
  if (variant === 'stat') {
    return (
      <div className={cn(
        'p-4 sm:p-6 rounded-xl bg-gradient-to-br from-slate-800/80 to-slate-800/60 border border-white/10',
        className
      )}>
        <div className="flex items-start justify-between mb-4">
          <Skeleton variant="rounded" className="w-12 h-12" />
          <Skeleton variant="rounded" className="w-16 h-6" />
        </div>
        <Skeleton variant="text" className="w-24 h-3 mb-2" />
        <Skeleton variant="text" className="w-32 h-6" />
      </div>
    );
  }

  if (variant === 'menu') {
    return (
      <div className={cn(
        'p-4 sm:p-6 rounded-xl bg-gradient-to-br from-slate-800/80 to-slate-800/60 border border-white/10 min-h-[140px]',
        className
      )}>
        <div className="flex items-start justify-between mb-4">
          <Skeleton variant="rounded" className="w-10 h-10" />
          <Skeleton variant="rounded" className="w-12 h-5" />
        </div>
        <Skeleton variant="text" className="w-24 h-5 mb-2" />
        <Skeleton variant="text" className="w-full h-3" />
        <Skeleton variant="text" className="w-3/4 h-3 mt-1" />
      </div>
    );
  }

  return (
    <div className={cn(
      'p-4 sm:p-6 rounded-xl bg-gradient-to-br from-slate-800/80 to-slate-800/60 border border-white/10',
      className
    )}>
      {showHeader && (
        <div className="flex items-center gap-3 mb-4">
          {showAvatar && <SkeletonAvatar />}
          <div className="flex-1">
            <Skeleton variant="text" className="w-32 h-4 mb-2" />
            <Skeleton variant="text" className="w-24 h-3" />
          </div>
        </div>
      )}
      <SkeletonText lines={lines} />
    </div>
  );
}

// ============================================
// 스켈레톤 테이블
// ============================================
interface SkeletonTableProps {
  rows?: number;
  columns?: number;
  className?: string;
  showHeader?: boolean;
}

export function SkeletonTable({
  rows = 5,
  columns = 4,
  className,
  showHeader = true
}: SkeletonTableProps) {
  return (
    <div className={cn('rounded-xl overflow-hidden border border-white/10', className)}>
      {showHeader && (
        <div className="flex gap-4 p-4 bg-slate-800/50 border-b border-white/10">
          {Array.from({ length: columns }).map((_, i) => (
            <div key={i} className="flex-1">
              <Skeleton variant="text" className="h-4" />
            </div>
          ))}
        </div>
      )}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        <div
          key={rowIndex}
          className="flex gap-4 p-4 border-b border-white/5 last:border-0"
        >
          {Array.from({ length: columns }).map((_, colIndex) => (
            <div key={colIndex} className="flex-1">
              <Skeleton variant="text" className="h-4" />
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

// ============================================
// 스켈레톤 리스트
// ============================================
interface SkeletonListProps {
  items?: number;
  className?: string;
  showAvatar?: boolean;
}

export function SkeletonList({ items = 5, className, showAvatar = true }: SkeletonListProps) {
  return (
    <div className={cn('space-y-3', className)}>
      {Array.from({ length: items }).map((_, i) => (
        <div
          key={i}
          className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/30 border border-white/5"
        >
          {showAvatar && <SkeletonAvatar size="sm" />}
          <div className="flex-1">
            <Skeleton variant="text" className="w-32 h-4 mb-1" />
            <Skeleton variant="text" className="w-48 h-3" />
          </div>
          <Skeleton variant="rounded" className="w-16 h-8" />
        </div>
      ))}
    </div>
  );
}

// ============================================
// 스켈레톤 네비게이션
// ============================================
export function SkeletonNav() {
  return (
    <div className="flex items-center gap-6">
      {Array.from({ length: 5 }).map((_, i) => (
        <Skeleton key={i} variant="text" className="w-16 h-4" />
      ))}
    </div>
  );
}

// ============================================
// 로딩 스피너
// ============================================
interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  color?: 'primary' | 'white' | 'current';
}

const spinnerSizes = {
  sm: 'w-4 h-4',
  md: 'w-6 h-6',
  lg: 'w-8 h-8',
  xl: 'w-12 h-12',
};

const spinnerColors = {
  primary: 'border-blue-500',
  white: 'border-white',
  current: 'border-current',
};

export function Spinner({ size = 'md', className, color = 'primary' }: SpinnerProps) {
  return (
    <div
      className={cn(
        'border-2 border-t-transparent rounded-full animate-spin',
        spinnerSizes[size],
        spinnerColors[color],
        className
      )}
    />
  );
}

// ============================================
// 로딩 오버레이
// ============================================
interface LoadingOverlayProps {
  isLoading: boolean;
  text?: string;
  blur?: boolean;
  className?: string;
}

export function LoadingOverlay({
  isLoading,
  text = '로딩 중...',
  blur = true,
  className
}: LoadingOverlayProps) {
  if (!isLoading) return null;

  return (
    <div className={cn(
      'absolute inset-0 flex flex-col items-center justify-center z-50',
      blur && 'backdrop-blur-sm bg-black/50',
      !blur && 'bg-black/80',
      className
    )}>
      <Spinner size="lg" className="mb-4" />
      {text && (
        <p className="text-sm text-gray-300 animate-pulse">{text}</p>
      )}
    </div>
  );
}

// ============================================
// 페이지 로딩 상태
// ============================================
interface LoadingStateProps {
  type?: 'spinner' | 'skeleton' | 'dots';
  text?: string;
  className?: string;
  fullScreen?: boolean;
}

export function LoadingState({
  type = 'spinner',
  text,
  className,
  fullScreen = false
}: LoadingStateProps) {
  const content = (
    <div className={cn('flex flex-col items-center justify-center p-8', className)}>
      {type === 'spinner' && (
        <Spinner size="lg" className="mb-4" />
      )}
      {type === 'skeleton' && (
        <div className="w-full max-w-md space-y-4">
          <SkeletonCard showHeader showAvatar lines={3} />
        </div>
      )}
      {type === 'dots' && (
        <div className="flex gap-2 mb-4">
          {[0, 1, 2].map((i) => (
            <div
                            key={i}
              className="w-3 h-3 rounded-full bg-blue-500 animate-bounce"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
      )}
      {text && (
        <p className="text-sm text-gray-400 animate-pulse">{text}</p>
      )}
    </div>
  );

  if (fullScreen) {
    return (
      <div className="fixed inset-0 flex items-center justify-center z-50 bg-slate-900/95">
        {content}
      </div>
    );
  }

  return content;
}

// ============================================
// 스켈레톤 대시보드
// ============================================
export function SkeletonDashboard() {
  return (
    <div className="space-y-6 p-4 sm:p-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <SkeletonCard key={i} variant="stat" />
        ))}
      </div>
      
      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <SkeletonCard lines={6} className="min-h-[300px]" />
        </div>
        <div className="space-y-4">
          <SkeletonCard showHeader showAvatar lines={3} />
          <SkeletonCard showHeader showAvatar lines={3} />
        </div>
      </div>
      
      {/* Table */}
      <SkeletonTable rows={5} columns={5} />
    </div>
  );
}

// 기존 호환성 유지
export default LoadingState;
