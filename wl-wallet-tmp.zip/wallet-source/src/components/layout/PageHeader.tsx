'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import CompanyBrand from '@/components/CompanyBrand';
import DesktopNavLinks from '@/components/navigation/DesktopNavLinks';
import MobileNavigation from '@/components/MobileNavigation';
import { cn } from '@/lib/utils';

interface PageHeaderProps {
  user?: {
    username: string;
    personalCoin: number;
  };
  showRightButtons?: boolean;
  rightButtons?: React.ReactNode;
  variant?: 'default' | 'transparent' | 'glass';
  sticky?: boolean;
}

export default function PageHeader({
  user,
  showRightButtons = false,
  rightButtons,
  variant = 'default',
  sticky = true,
}: PageHeaderProps) {
  const pathname = usePathname();
  const currentPath = pathname || '/';

  const variantStyles = {
    default: 'bg-slate-900/50 backdrop-blur-sm border-b border-white/10',
    transparent: 'bg-transparent',
    glass: 'glass border-b border-white/5',
  };

  return (
    <header className={cn(
      'flex flex-col',
      'px-4 sm:px-6 md:px-10 py-3',
      variantStyles[variant],
      sticky && 'sticky top-0 z-40'
    )}>
      {/* 첫 번째 줄: 로고 */}
      <div className="flex items-center justify-between w-full mb-2">
        <Link 
          href="/" 
          className="flex items-center gap-3 sm:gap-4 text-white hover:opacity-80 transition-all duration-200 group"
        >
          <div className="relative">
            <CompanyBrand
              wrapperClassName="gap-3 sm:gap-4"
              size={40}
              textClassName="text-white text-lg sm:text-xl font-bold leading-tight tracking-tight"
            />
            {/* 호버 효과 - 글로우 */}
            <div className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl bg-blue-500/20" />
          </div>
        </Link>

        {/* 데스크탑: 우측 버튼들 */}
        {showRightButtons && rightButtons && (
          <div className="hidden md:flex items-center gap-3">
            {rightButtons}
          </div>
        )}
      </div>

      {/* 두 번째 줄: 네비게이션 */}
      <div className="flex items-center justify-between w-full">
        {/* 모바일: 햄버거 메뉴 */}
        <div className="md:hidden">
          {user && (
            <MobileNavigation
              user={user}
              currentPath={currentPath}
            />
          )}
        </div>

        {/* 데스크탑: 네비게이션 링크 */}
        <div className="hidden md:flex flex-1">
          <DesktopNavLinks currentPath={currentPath} />
        </div>

        {/* 모바일: 우측 버튼들 */}
        {showRightButtons && rightButtons && (
          <div className="md:hidden flex items-center gap-2">
            {rightButtons}
          </div>
        )}
      </div>
    </header>
  );
}

// ============================================
// 간단한 헤더 (로그인 전 등)
// ============================================
interface SimpleHeaderProps {
  showLogo?: boolean;
  rightContent?: React.ReactNode;
  className?: string;
}

export function SimpleHeader({ showLogo = true, rightContent, className }: SimpleHeaderProps) {
  return (
    <header className={cn(
      'flex items-center justify-between',
      'px-4 sm:px-6 py-4',
      'bg-slate-900/50 backdrop-blur-sm',
      'border-b border-white/10',
      'sticky top-0 z-40',
      className
    )}>
      {showLogo && (
        <Link href="/" className="flex items-center gap-3 group">
          <CompanyBrand
            wrapperClassName="gap-3"
            size={36}
            textClassName="text-white text-lg font-bold"
          />
        </Link>
      )}
      {rightContent && (
        <div className="flex items-center gap-3">
          {rightContent}
        </div>
      )}
    </header>
  );
}

// ============================================
// 페이지 타이틀 컴포넌트
// ============================================
interface PageTitleProps {
  title: string;
  subtitle?: string;
  icon?: string;
  action?: React.ReactNode;
  breadcrumb?: { label: string; href?: string }[];
  className?: string;
}

export function PageTitle({
  title,
  subtitle,
  icon,
  action,
  breadcrumb,
  className
}: PageTitleProps) {
  return (
    <div className={cn('mb-6', className)}>
      {/* 브레드크럼 */}
      {breadcrumb && breadcrumb.length > 0 && (
        <nav className="flex items-center gap-2 text-sm text-gray-400 mb-2">
          {breadcrumb.map((item, index) => (
            <span key={index} className="flex items-center gap-2">
              {index > 0 && (
                <span className="material-symbols-outlined text-xs">chevron_right</span>
              )}
              {item.href ? (
                <Link 
                  href={item.href}
                  className="hover:text-white transition-colors"
                >
                  {item.label}
                </Link>
              ) : (
                <span>{item.label}</span>
              )}
            </span>
          ))}
        </nav>
      )}

      {/* 타이틀 */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {icon && (
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/20">
              <span className="material-symbols-outlined text-xl text-blue-400">
                {icon}
              </span>
            </div>
          )}
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">{title}</h1>
            {subtitle && (
              <p className="text-sm text-gray-400 mt-0.5">{subtitle}</p>
            )}
          </div>
        </div>
        
        {action && (
          <div className="flex-shrink-0">
            {action}
          </div>
        )}
      </div>
    </div>
  );
}

export {};
