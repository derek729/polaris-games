'use client';

import Link from 'next/link';
import { ReactNode, useMemo, useState, useEffect, useRef } from 'react';
import DesktopNavLinks from '@/components/navigation/DesktopNavLinks';
import MobileNavigation from '@/components/MobileNavigation';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { CompanyBrand } from '@/components/CompanyBrand';
import ChangePasswordModal from '@/components/ChangePasswordModal';
import { useI18n } from '@/lib/i18n/useI18n';
import { cn } from '@/lib/utils';

interface UserSummary {
  username?: string | null;
  personalCoin?: number | null;
}

interface UserHeaderProps {
  user?: UserSummary | null;
  currentPath: string;
  onLogout?: () => void | Promise<void>;
  actions?: ReactNode;
  className?: string;
  showLanguageSwitcher?: boolean;
  showMobileNav?: boolean;
  showAvatar?: boolean;
}

export default function UserHeader({
  user,
  currentPath,
  onLogout,
  actions,
  className,
  showLanguageSwitcher = true,
  showMobileNav = true,
  showAvatar = true,
}: UserHeaderProps) {
  const { t } = useI18n();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const safeUser = useMemo(
    () => ({
      username: user?.username ?? '',
      personalCoin: user?.personalCoin ?? 0,
    }),
    [user?.username, user?.personalCoin]
  );

  // 드롭다운 외부 클릭 및 ESC 키 감지
  useEffect(() => {
    if (!isDropdownOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isDropdownOpen]);

  return (
    <header className={cn(
      'flex flex-col border-b border-white/10',
      'px-4 sm:px-6 py-3',
      'bg-slate-900/50 backdrop-blur-sm',
      'sticky top-0 z-40',
      className
    )}>
      {/* 첫 번째 줄: 로고 + 우측 액션 */}
      <div className="flex items-center justify-between w-full">
        <Link 
          href="/" 
          className="flex items-center gap-3 sm:gap-4 text-white hover:opacity-80 transition-opacity shrink-0 min-w-0 group"
        >
          <CompanyBrand
            wrapperClassName="gap-3 sm:gap-4"
            size={36}
            textClassName="text-white text-base sm:text-lg font-bold leading-tight tracking-tight"
          />
        </Link>

        {/* 데스크탑: 언어 스위처 + 액션 + 아바타 */}
        <div className="hidden md:flex items-center gap-3">
          {showLanguageSwitcher && <LanguageSwitcher />}
          {actions && <div className="flex items-center gap-2">{actions}</div>}
          
          {showAvatar && (
            <UserAvatarDropdown
              username={safeUser.username}
              isOpen={isDropdownOpen}
              setIsOpen={setIsDropdownOpen}
              onLogout={onLogout}
              onChangePassword={() => setIsPasswordModalOpen(true)}
              dropdownRef={dropdownRef}
            />
          )}
        </div>
      </div>

      {/* 두 번째 줄: 네비게이션 */}
      <div className="flex items-center justify-between w-full mt-2">
        {/* 모바일: 햄버거 메뉴 */}
        {showMobileNav && (
          <div className="md:hidden">
            <MobileNavigation
              user={{
                username: safeUser.username || '',
                personalCoin: safeUser.personalCoin || 0,
              }}
              currentPath={currentPath || ''}
            />
          </div>
        )}

        {/* 데스크탑: 네비게이션 링크 */}
        <div className="hidden md:flex flex-1">
          <DesktopNavLinks currentPath={currentPath || ''} />
        </div>

        {/* 모바일: 아바타 (햄버거와 별도) */}
        {showAvatar && (
          <div className="md:hidden">
            <UserAvatarDropdown
              username={safeUser.username}
              isOpen={isDropdownOpen}
              setIsOpen={setIsDropdownOpen}
              onLogout={onLogout}
              onChangePassword={() => setIsPasswordModalOpen(true)}
              dropdownRef={dropdownRef}
            />
          </div>
        )}
      </div>

      {/* 비밀번호 변경 모달 */}
      <ChangePasswordModal
        isOpen={isPasswordModalOpen}
        onClose={() => setIsPasswordModalOpen(false)}
        onSuccess={() => setIsPasswordModalOpen(false)}
      />
    </header>
  );
}

// ============================================
// 아바타 드롭다운 컴포넌트
// ============================================
interface UserAvatarDropdownProps {
  username: string;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  onLogout?: () => void | Promise<void>;
  onChangePassword: () => void;
  dropdownRef: React.RefObject<HTMLDivElement>;
}

function UserAvatarDropdown({
  username,
  isOpen,
  setIsOpen,
  onLogout,
  onChangePassword,
  dropdownRef,
}: UserAvatarDropdownProps) {
  const { t } = useI18n();

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          'relative flex items-center justify-center',
          'w-10 h-10 rounded-full',
          'bg-gradient-to-br from-blue-500 to-purple-600',
          'border-2 border-white/20',
          'hover:ring-2 hover:ring-blue-400/50 hover:ring-offset-2 hover:ring-offset-slate-900',
          'transition-all duration-200',
          'cursor-pointer overflow-hidden',
          isOpen && 'ring-2 ring-blue-400/50 ring-offset-2 ring-offset-slate-900'
        )}
        title={username || 'User'}
      >
        {username ? (
          <span className="text-white font-bold text-sm">
            {username[0].toUpperCase()}
          </span>
        ) : (
          <img 
            src="/icons/uoc.svg" 
            alt="Profile" 
            className="w-full h-full object-cover"
          />
        )}
        
        {/* 온라인 상태 표시 */}
        <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-green-500 border-2 border-slate-900" />
      </button>

      {/* 드롭다운 메뉴 */}
      {isOpen && (
        <div className="absolute right-0 top-14 w-56 animate-scale-in origin-top-right">
          <div className="bg-slate-800/95 backdrop-blur-xl border border-white/10 rounded-xl shadow-dropdown overflow-hidden">
            {/* 사용자 정보 헤더 */}
            <div className="px-4 py-3 border-b border-white/10">
              <p className="text-sm font-semibold text-white truncate">{username}</p>
              <p className="text-xs text-gray-400">online</p>
            </div>
            
            {/* 메뉴 아이템 */}
            <div className="py-1">
              {/* 내 프로필 */}
              <Link
                href="/my-profile"
                onClick={() => setIsOpen(false)}
                className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-lg">person</span>
                <span>{t.common?.myProfile || '내 프로필'}</span>
              </Link>
              
              {/* 비밀번호 변경 */}
              <button
                onClick={() => {
                  setIsOpen(false);
                  onChangePassword();
                }}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-lg">lock</span>
                <span>{t.common?.changePassword || '비밀번호 변경'}</span>
              </button>
              
              {/* 설정 */}
              <Link
                href="/settings"
                onClick={() => setIsOpen(false)}
                className="flex items-center gap-3 px-4 py-2.5 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined text-lg">settings</span>
                <span>{t.common?.settings || '설정'}</span>
              </Link>
            </div>
            
            {/* 로그아웃 */}
            {onLogout && (
              <div className="border-t border-white/10">
                <button
                  onClick={() => {
                    setIsOpen(false);
                    onLogout();
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-colors"
                >
                  <span className="material-symbols-outlined text-lg">logout</span>
                  <span>{t.common?.logout || '로그아웃'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export {};
