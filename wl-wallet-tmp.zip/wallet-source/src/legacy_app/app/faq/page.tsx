
'use client';

import { useI18n } from '@/lib/i18n/context';
import Link from 'next/link';

export default function FAQPage() {
    const { t } = useI18n();

    const faqs = [
        {
            question: 'MSUO 월렛은 어떤 서비스인가요?',
            answer: 'MSUO 월렛은 안전하고 편리한 디지털 자산 관리 및 투자 플랫폼입니다. 다양한 투자 상품을 통해 수익을 창출하고, 팀 빌딩을 통해 추가 보상을 받을 수 있습니다.'
        },
        {
            question: '투자는 어떻게 시작하나요?',
            answer: '대시보드의 "투자" 메뉴에서 원하는 상품을 선택하여 투자를 시작할 수 있습니다. 최소 투자 금액은 $50입니다.'
        },
        {
            question: '수익금은 언제 출금할 수 있나요?',
            answer: '수익금은 매일 정산되며, 언제든지 출금 신청이 가능합니다. 출금 신청 후 관리자 승인을 거쳐 지갑으로 전송됩니다.'
        },
        {
            question: '비밀번호를 잊어버렸어요.',
            answer: '로그인 페이지의 "비밀번호 찾기" 링크를 통해 이메일 인증 후 비밀번호를 재설정할 수 있습니다.'
        }
    ];

    return (
        <div className="min-h-screen bg-[#101922] text-white p-6">
            <div className="max-w-3xl mx-auto">
                <header className="mb-8 flex items-center gap-4">
                    <Link href="/dashboard" className="text-gray-400 hover:text-white">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </Link>
                    <h1 className="text-2xl font-bold">자주 묻는 질문 (FAQ)</h1>
                </header>

                <div className="space-y-6">
                    {faqs.map((faq, index) => (
                        <div key={index} className="bg-white/5 rounded-xl p-6 border border-white/10">
                            <h3 className="text-lg font-semibold mb-2 text-[#137fec]">{faq.question}</h3>
                            <p className="text-gray-300 leading-relaxed">{faq.answer}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
