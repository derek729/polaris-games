'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useI18n } from '@/lib/i18n/context';
import UserHeader from '@/components/layout/UserHeader';

interface User {
  id: string;
  username: string | null;
  email: string | null;
  personalCoin: number;
}

interface Game {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  isActive: boolean;
  defaultPaymentPeriod?: string; // 기본 수익 분배 주기
  game_shares: GameShare[];
}

interface GameShare {
  id: string;
  sharePercentage: number;
  price: number;
  totalShares: number;
  availableShares: number;
  soldShares: number;
  isActive: boolean;
}

export default function GameSharesClient({ user }: { users: User }) {
  const router = useRouter();
  const pathname = usePathname();
  const { t, language } = useI18n();
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [selectedShare, setSelectedShare] = useState<GameShare | null>(null);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [purchaseForm, setPurchaseForm] = useState({
    shareCount: 1,
    paymentPeriod: 'DAILY' as 'DAILY' | 'WEEKLY' | 'MONTHLY',
    txHash: '',
    membership_codes: '',
  });
  const [purchasing, setPurchasing] = useState(false);
  const [usdtAddress, setUsdtAddress] = useState('');

  useEffect(() => {
    fetchGames();
    fetchUsdtAddress();
  }, []);

  const fetchGames = async () => {
    try {
      const res = await fetch('/api/user/games');
      const data = await res.json();
      if (data.ok) {
        setGames(data.data);
      }
    } catch (error) {
      console.error('게임 목록 조회 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchUsdtAddress = async () => {
    try {
      const res = await fetch('/api/admin/system-settings');
      const data = await res.json();
      if (data.ok && data.data.usdtAddress) {
        setUsdtAddress(data.data.usdtAddress);
      }
    } catch (error) {
      console.error('USDT 주소 조회 실패:', error);
    }
  };

  const handlePurchaseClick = (game: Game, share: GameShare) => {
    setSelectedGame(game);
    setSelectedShare(share);
    // 게임의 기본 지급 주기 사용 (관리자가 설정한 주기)
    const gameDefaultPeriod = (game as any).defaultPaymentPeriod || 'DAILY';
    setPurchaseForm({
      shareCount: 1,
      paymentPeriod: gameDefaultPeriod as 'DAILY' | 'WEEKLY' | 'MONTHLY',
      txHash: '',
      membership_codes: '',
    });
    setShowPurchaseModal(true);
  };

  const handlePurchase = async () => {
    if (!selectedShare || !purchaseForm.txHash) {
      alert(language === 'ko' ? '모든 필드를 입력해주세요.' : 'Please fill in all fields.');
      return;
    }

    setPurchasing(true);

    try {
      const res = await fetch('/api/user/games/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gameShareId: selectedShare.id,
          shareCount: purchaseForm.shareCount,
          paymentPeriod: purchaseForm.paymentPeriod,
          txHash: purchaseForm.txHash.trim(),
          membership_codes: purchaseForm.membership_codes.trim() || undefined,
        }),
      });

      const data = await res.json();

      if (data.ok) {
        alert(
          language === 'ko'
            ? `게임 지분 구매 신청이 접수되었습니다.\n\n관리자 승인 후 활성화되며, 설정하신 지급 주기(매일/매주/매월)에 따라 수익이 분배됩니다.`
            : `Game share purchase request submitted.\n\nIt will be activated after admin approval, and profits will be distributed according to your selected payment period (daily/weekly/monthly).`
        );
        setShowPurchaseModal(false);
        setSelectedGame(null);
        setSelectedShare(null);
        setPurchaseForm({
          shareCount: 1,
          paymentPeriod: 'DAILY',
          txHash: '',
          membership_codes: '',
        });
        router.refresh();
      } else {
        alert(data.error || (language === 'ko' ? '구매 신청에 실패했습니다.' : 'Purchase request failed.'));
      }
    } catch (error) {
      console.error('게임 지분 구매 실패:', error);
      alert(language === 'ko' ? '네트워크 오류가 발생했습니다.' : 'Network error occurred.');
    } finally {
      setPurchasing(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0B1512] flex items-center justify-center">
        <div className="text-white">{t.common.loading}</div>
      </div>
    );
  }

  const isKorean = language === 'ko';

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#0B1512]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1 overflow-visible">
            <UserHeader
              user={user}
              currentPath={pathname || ''}
              onLogout={handleLogout}
              actions={
                <Link
                  href="/products"
                  className="hidden sm:inline-flex min-w-[120px] items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#2F7F6A]/20 text-[#2F7F6A] gap-2 text-sm font-bold leading-normal hover:opacity-90 border border-[#2F7F6A]"
                >
                  <span className="material-symbols-outlined text-base">inventory_2</span>
                  <span className="truncate">
                    {language === 'ko' ? '보상 플랜 투자' : 'Reward Plan Investment'}
                  </span>
                </Link>
              }
            />

            <main className="flex-1 p-2 sm:p-4 md:p-6 overflow-visible relative z-0">
              <div className="flex flex-wrap justify-between gap-4 py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    {isKorean ? '게임 지분 투자' : 'Game Share Investment'}
                  </p>
                  <p className="text-gray-400 dark:text-gray-400 text-base font-normal leading-normal">
                    {isKorean
                      ? '게임의 수익을 공유하는 지분을 구매하세요'
                      : 'Purchase game_shares to receive a portion of game revenue'}
                  </p>
                </div>
              </div>

              {/* Game Share Products Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 px-2 sm:px-4 py-4 sm:py-6">
                {games.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <p className="text-gray-400">
                      {isKorean ? '등록된 게임 지분 상품이 없습니다.' : 'No game share products available.'}
                    </p>
                  </div>
                ) : (
                  games.flatMap((game) =>
                    game.game_shares.map((share) => {
                      const totalPrice = share.price * share.totalShares;
                      const soldPercentage = (share.soldShares / share.totalShares) * 100;
                      const isRecommended = share.availableShares > 0 && share.isActive;

                      return (
                        <div
                          key={`${game.id}-${share.id}`}
                          className={`flex flex-1 flex-col gap-4 rounded-xl border border-solid p-6 transition-colors duration-300 relative ${
                            isRecommended
                              ? 'border-[#2F7F6A] bg-[#12211C] ring-2 ring-[#2F7F6A]/50'
                              : 'border-[#324d67] bg-[#12211C] hover:border-[#2F7F6A]'
                          }`}
                        >
                          {isRecommended && share.availableShares > share.totalShares * 0.5 && (
                            <div className="absolute top-0 right-0 bg-[#2F7F6A] text-white text-xs font-bold px-8 py-1 -rotate-45 translate-x-1/4 translate-y-2.5">
                              {isKorean ? '추천' : 'Recommended'}
                            </div>
                          )}
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center justify-between gap-2">
                              <h3 className="text-white text-base sm:text-lg font-bold leading-tight">
                                {game.name} - {share.sharePercentage.toFixed(2)}% 지분
                              </h3>
                              <span className="text-[#92adc9] text-xs font-medium px-2 py-1 rounded bg-white/5 whitespace-nowrap shrink-0">
                                {isKorean ? '게임 지분' : 'Game Share'}
                              </span>
                            </div>
                            {game.description && (
                              <p className="text-gray-400 text-xs sm:text-sm leading-normal">
                                {game.description}
                              </p>
                            )}
                            <div className="flex items-center gap-2 mt-2">
                              <span className="text-[#92adc9] text-xs">
                                {isKorean ? '판매 진행률' : 'Sales Progress'}: {soldPercentage.toFixed(1)}% ({share.soldShares}/{share.totalShares})
                              </span>
                            </div>
                            <p className="flex items-baseline gap-1 text-white mt-2">
                              <span className="text-white text-2xl sm:text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                                ${share.price.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US')}
                              </span>
                              <span className="text-gray-400 text-sm">/ 지분</span>
                            </p>
                          </div>
                          <div className="flex flex-col gap-3 my-4">
                            <div className="flex items-center justify-between">
                              <p className="text-[#92adc9] text-xs sm:text-sm font-normal leading-normal">
                                {isKorean ? '지분 비율' : 'Share Percentage'}
                              </p>
                              <p className="text-white text-sm sm:text-base font-bold leading-tight">
                                {share.sharePercentage.toFixed(2)}%
                              </p>
                            </div>
                            <div className="flex items-center justify-between">
                              <p className="text-[#92adc9] text-xs sm:text-sm font-normal leading-normal">
                                {isKorean ? '총 가치' : 'Total Value'}
                              </p>
                              <p className="text-white text-sm sm:text-base font-bold leading-tight">
                                ${totalPrice.toLocaleString()} USDT
                              </p>
                            </div>
                            <div className="flex items-center justify-between">
                              <p className="text-[#92adc9] text-xs sm:text-sm font-normal leading-normal">
                                {isKorean ? '판매 가능' : 'Available'}
                              </p>
                              <p className="text-white text-sm sm:text-base font-bold leading-tight">
                                {share.availableShares} {isKorean ? '개' : 'game_shares'}
                              </p>
                            </div>
                            <div className="flex items-center justify-between">
                              <p className="text-[#92adc9] text-xs sm:text-sm font-normal leading-normal">
                                {isKorean ? '수익 지급' : 'Payment Period'}
                              </p>
                              <p className="text-white text-sm sm:text-base font-bold leading-tight">
                                {isKorean ? '매일/매주/매월 선택' : 'Daily/Weekly/Monthly'}
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={() => handlePurchaseClick(game, share)}
                            disabled={share.availableShares === 0 || !share.isActive}
                            className="flex items-center justify-center gap-2 min-h-[44px] h-auto px-4 py-2 sm:py-0 sm:h-10 rounded-lg bg-[#2F7F6A] text-white text-sm sm:text-base font-bold leading-normal hover:bg-[#2F7F6A]/90 transition-colors no-min-size disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            <span className="truncate">
                              {share.availableShares === 0
                                ? isKorean
                                  ? '매진'
                                  : 'Sold Out'
                                : isKorean
                                  ? '투자하기'
                                  : 'Invest Now'}
                            </span>
                          </button>
                        </div>
                      );
                    })
                  )
                )}
              </div>
            </main>
          </div>
        </div>
      </div>

      {/* Purchase Modal */}
      {showPurchaseModal && selectedGame && selectedShare && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="bg-[#1e293b] rounded-xl max-w-md w-full p-6 border border-white/10 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">
              {isKorean ? '게임 지분 구매' : 'Purchase Game Share'}
            </h3>

            <div className="space-y-4 mb-6">
              <div>
                <p className="text-gray-300 text-sm mb-1">{selectedGame.name}</p>
                <p className="text-white font-semibold">
                  {selectedShare.sharePercentage.toFixed(2)}% 지분 - {selectedShare.price.toLocaleString()} USDT
                </p>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-2 font-medium">
                  {isKorean ? '구매 수량' : 'Quantity'}
                </label>
                <input
                  type="number"
                  min="1"
                  max={selectedShare.availableShares}
                  value={purchaseForm.shareCount}
                  onChange={(e) =>
                    setPurchaseForm({ ...purchaseForm, shareCount: parseInt(e.target.value) || 1 })
                  }
                  className="w-full bg-[#0f172a] border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#2F7F6A] outline-none"
                />
                {(() => {
                  const totalAmount = selectedShare.price * purchaseForm.shareCount;
                  
                  // 멤버쉽 가입 여부 확인 (실제로는 API에서 확인하지만, UI에서는 표시만)
                  return (
                    <div className="mt-2 space-y-1">
                      <p className="text-xs text-gray-400">
                        {isKorean ? '원래 금액' : 'Original'}:{' '}
                        <span className="text-white">{totalAmount.toLocaleString()} USDT</span>
                      </p>
                      <p className="text-xs text-gray-500 italic">
                        {isKorean 
                          ? '※ 멤버쉽 패키지 가입자만 할인 적용 (1,000 USDT: 10%, 3,000 USDT: 15%, 5,000 USDT: 18%, 10,000 USDT: 20%)'
                          : '※ Discount applies only to membership package subscribers (1,000 USDT: 10%, 3,000 USDT: 15%, 5,000 USDT: 18%, 10,000 USDT: 20%)'}
                      </p>
                    </div>
                  );
                })()}
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-2 font-medium">
                  {isKorean ? '수익 지급 주기' : 'Payment Period'}
                  {selectedGame?.defaultPaymentPeriod && (
                    <span className="ml-2 text-xs text-gray-500">
                      ({isKorean ? '기본값: ' : 'Default: '}
                      {selectedGame.defaultPaymentPeriod === 'DAILY' ? (isKorean ? '매일' : 'Daily') :
                       selectedGame.defaultPaymentPeriod === 'WEEKLY' ? (isKorean ? '매주' : 'Weekly') :
                       (isKorean ? '매월' : 'Monthly')})
                    </span>
                  )}
                </label>
                <select
                  value={purchaseForm.paymentPeriod}
                  onChange={(e) =>
                    setPurchaseForm({
                      ...purchaseForm,
                      paymentPeriod: e.target.value as 'DAILY' | 'WEEKLY' | 'MONTHLY',
                    })
                  }
                  className="w-full bg-[#0f172a] border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#2F7F6A] outline-none"
                >
                  <option value="DAILY">{isKorean ? '매일 지급' : 'Daily'}</option>
                  <option value="WEEKLY">{isKorean ? '매주 지급' : 'Weekly'}</option>
                  <option value="MONTHLY">{isKorean ? '매월 지급' : 'Monthly'}</option>
                </select>
                <p className="text-xs text-gray-500 mt-1">
                  {isKorean 
                    ? '※ 관리자가 설정한 게임의 기본 주기가 자동으로 적용됩니다.' 
                    : '※ The game\'s default period set by admin will be automatically applied.'}
                </p>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-2 font-medium">
                  {isKorean ? '멤버쉽 코드 (선택사항)' : 'Membership Code (Optional)'}
                </label>
                <input
                  type="text"
                  value={purchaseForm.membershipCode}
                  onChange={(e) => setPurchaseForm({ ...purchaseForm, membership_codes: e.target.value })}
                  className="w-full bg-[#0f172a] border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#2F7F6A] outline-none"
                  placeholder={isKorean ? '추가 할인 코드 입력 (선택사항)' : 'Enter additional discount code (optional)'}
                />
                <p className="text-xs text-gray-500 mt-1">
                  {isKorean 
                    ? '※ 멤버쉽 패키지($1,000, $3,000, $5,000, $10,000) 가입자만 할인 적용됩니다.'
                    : '※ Discount applies only to membership package ($1,000, $3,000, $5,000, $10,000) subscribers.'}
                </p>
              </div>

              <div className="bg-black/30 p-4 rounded-lg break-all border border-white/5">
                <p className="text-xs text-gray-500 mb-2 font-medium">
                  {isKorean ? '입금 주소 (TRC20)' : 'Deposit Address (TRC20)'}
                </p>
                <div className="flex items-center justify-between gap-2">
                  <p className="text-[#2F7F6A] font-mono text-sm font-bold">
                    {usdtAddress || (isKorean ? '주소가 설정되지 않았습니다.' : 'Address not set.')}
                  </p>
                  <button
                    onClick={() => {
                      if (usdtAddress) {
                        navigator.clipboard.writeText(usdtAddress);
                        alert(isKorean ? '주소가 복사되었습니다.' : 'Address copied.');
                      }
                    }}
                    className="text-gray-400 hover:text-white"
                  >
                    <span className="material-symbols-outlined text-sm">content_copy</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-2 font-medium">TXID (Transaction Hash)</label>
                <input
                  type="text"
                  value={purchaseForm.txHash}
                  onChange={(e) => setPurchaseForm({ ...purchaseForm, txHash: e.target.value })}
                  className="w-full bg-[#0f172a] border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#2F7F6A] outline-none"
                  placeholder={isKorean ? '거래 해시를 입력하세요' : 'Enter transaction hash'}
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowPurchaseModal(false)}
                className="flex-1 py-3 rounded-lg bg-gray-700 text-white font-bold hover:bg-gray-600 transition-colors"
              >
                {isKorean ? '취소' : 'Cancel'}
              </button>
              <button
                onClick={handlePurchase}
                disabled={purchasing || !purchaseForm.txHash}
                className="flex-1 py-3 rounded-lg bg-[#2F7F6A] text-white font-bold hover:bg-[#2F7F6A]/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {purchasing
                  ? isKorean
                    ? '처리 중...'
                    : 'Processing...'
                  : isKorean
                    ? '구매하기'
                    : 'Purchase'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export {};

