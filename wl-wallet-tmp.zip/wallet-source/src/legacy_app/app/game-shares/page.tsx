import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import GameSharesClient from './GameSharesClient';

export const dynamic = 'force-dynamic';

export default async function GameSharesPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  // Decimal 타입을 number로 변환
  return (
    <GameSharesClient
      user={{
        id: user.id,
        username: user.username,
        email: user.email,
        personalCoin: Number(user.personalCoin || 0),
      }}
    />
  );
}

