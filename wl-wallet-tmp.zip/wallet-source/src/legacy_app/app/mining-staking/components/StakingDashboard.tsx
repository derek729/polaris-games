'use client'

import { useState, useEffect, useRef, useMemo, useCallback } from 'react'
import { TrendingUp, DollarSign, Clock, Award, Shield, Zap, Target, Activity, AlertCircle } from 'lucide-react'
import { StakingSimulator, StakingConfig, StakingPool, STAKING_POOLS, calculateStakingProfitability } from '@/lib/staking-physics'

interface StakingStats {
  currentValue: number
  totalEarned: number
  currentApy: number
  efficiency: number
  timeElapsed: number
  projectedDaily: number
  projectedValue: number[]
}

interface PoolMetrics {
  totalStaked: number
  apy: number
  participants: number
  liquidity: number
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH'
}

export default function StakingDashboard() {
  const [selectedPool, setSelectedPool] = useState<StakingPool>(STAKING_POOLS[0])
  const [stakingAmount, setStakingAmount] = useState<number>(10000) // 기본값 10,000 MSUO
  const [lockPeriod, setLockPeriod] = useState<number>(30)
  const [compoundFrequency, setCompoundFrequency] = useState<'continuous' | 'daily' | 'weekly' | 'monthly' | 'yearly'>('daily')
  const [autoCompound, setAutoCompound] = useState(true)

  // 동적 APY 계산
  const calculateDynamicApy = useCallback(() => {
    let apy = selectedPool.baseApy

    // 금액 기반 보너스
    if (stakingAmount >= 10000) apy += 1.5
    if (stakingAmount >= 50000) apy += 2.5
    if (stakingAmount >= 100000) apy += 3.5

    // 락업 기간 기반 보너스
    if (lockPeriod >= 90) apy += 1.0
    if (lockPeriod >= 180) apy += 2.0
    if (lockPeriod >= 365) apy += 3.5

    // 복리 빈도 기반 보너스
    if (compoundFrequency === 'continuous') apy += 0.8
    if (compoundFrequency === 'daily') apy += 0.5
    if (compoundFrequency === 'weekly') apy += 0.3

    return Math.min(apy, selectedPool.maxApy)
  }, [selectedPool, stakingAmount, lockPeriod, compoundFrequency])
  const [isStaking, setIsStaking] = useState(false)

  const [simulator, setSimulator] = useState<StakingSimulator | null>(null)
  const [currentStats, setCurrentStats] = useState<StakingStats>({
    currentValue: 0,
    totalEarned: 0,
    currentApy: 0,
    efficiency: 0,
    timeElapsed: 0,
    projectedDaily: 0,
    projectedValue: []
  })

  const [profitability, setProfitability] = useState(() =>
    calculateStakingProfitability({
      principalAmount: stakingAmount,
      apy: selectedPool.baseApy,
      compoundFrequency,
      lockPeriod,
      autoCompound,
      volatilityRate: selectedPool.riskLevel === 'LOW' ? 5 : selectedPool.riskLevel === 'MEDIUM' ? 15 : 30,
      marketCondition: 'sideways',
      bonusMultiplier: 1,
      stakingFee: 0.5,
      unstakingFee: 0.1,
      performanceFee: 0,
      referralBonus: 2,
      loyaltyBonus: Math.min(5, lockPeriod / 365 * 5),
      volumeBonus: stakingAmount > 10000 ? 3 : 0
    })
  )

  const animationRef = useRef<number | null>(null)
  const lastUpdateRef = useRef<number>(0)

  // 스테이킹 설정 변경 시 재계산
  useEffect(() => {
    const config: StakingConfig = {
      principalAmount: stakingAmount,
      apy: calculateDynamicApy(),
      compoundFrequency,
      lockPeriod,
      autoCompound,
      volatilityRate: selectedPool.riskLevel === 'LOW' ? 5 : selectedPool.riskLevel === 'MEDIUM' ? 15 : 30,
      marketCondition: 'sideways',
      bonusMultiplier: 1,
      stakingFee: 0.5,
      unstakingFee: 0.1,
      performanceFee: selectedPool.performanceBonus ? 10 : 0,
      referralBonus: 2,
      loyaltyBonus: Math.min(5, lockPeriod / 365 * 5),
      volumeBonus: stakingAmount > 10000 ? 3 : 0
    }

    setProfitability(calculateStakingProfitability(config))
  }, [stakingAmount, selectedPool, lockPeriod, compoundFrequency, autoCompound, calculateDynamicApy])

  // 실시간 시뮬레이션
  useEffect(() => {
    lastUpdateRef.current = Date.now()
    if (isStaking && !simulator) {
      const config: StakingConfig = {
        principalAmount: stakingAmount,
        apy: calculateDynamicApy(),
        compoundFrequency,
        lockPeriod,
        autoCompound,
        volatilityRate: selectedPool.riskLevel === 'LOW' ? 5 : selectedPool.riskLevel === 'MEDIUM' ? 15 : 30,
        marketCondition: 'sideways',
        bonusMultiplier: 1,
        stakingFee: 0.5,
        unstakingFee: 0.1,
        performanceFee: selectedPool.performanceBonus ? 10 : 0,
        referralBonus: 2,
        loyaltyBonus: Math.min(5, lockPeriod / 365 * 5),
        volumeBonus: stakingAmount > 10000 ? 3 : 0
      }
      setSimulator(new StakingSimulator(config))
    } else if (!isStaking && simulator) {
      setSimulator(null)
      setCurrentStats({
        currentValue: 0,
        totalEarned: 0,
        currentApy: 0,
        efficiency: 0,
        timeElapsed: 0,
        projectedDaily: 0,
        projectedValue: []
      })
    }
  }, [isStaking, stakingAmount, selectedPool, lockPeriod, compoundFrequency, autoCompound, simulator, calculateDynamicApy])

  // 실시간 시뮬레이션
  useEffect(() => {
    if (!isStaking || !simulator) return

    const animate = () => {
      const now = Date.now()
      const deltaTime = (now - lastUpdateRef.current) / 1000
      lastUpdateRef.current = now

      // 시장 조건 시뮬레이션
      const marketConditions = {
        priceChange: (Math.random() - 0.5) * 0.001, // ±0.1%
        apyChange: (Math.random() - 0.5) * 0.01, // ±0.5%
        volatility: selectedPool.riskLevel === 'LOW' ? 2 : selectedPool.riskLevel === 'MEDIUM' ? 8 : 20
      }

      const result = simulator.update(deltaTime, marketConditions)

      setCurrentStats({
        currentValue: result.currentValue,
        totalEarned: result.totalEarned,
        currentApy: result.currentApy,
        efficiency: result.efficiency,
        timeElapsed: result.timeElapsed,
        projectedDaily: result.projectedDaily,
        projectedValue: profitability.projectedValue
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animationRef.current = requestAnimationFrame(animate)

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [isStaking, simulator, profitability.projectedValue, selectedPool])

  const formatCurrency = (amount: number) =>
    `${amount.toLocaleString('ko-KR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 8,
    })} MSUO`

  const formatPercent = (value: number) => `${value.toFixed(2)}%`
  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = Math.floor(seconds % 60)
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const formatDays = (days: number) => {
    if (days < 30) return `${Math.floor(days)}일`
    if (days < 365) return `${(days / 30.44).toFixed(1)}개월`
    return `${(days / 365.25).toFixed(1)}년`
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'LOW': return 'text-green-400 bg-green-500/20 border-green-500/50'
      case 'MEDIUM': return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/50'
      case 'HIGH': return 'text-red-400 bg-red-500/20 border-red-500/50'
      default: return 'text-gray-400 bg-gray-500/20 border-gray-500/50'
    }
  }

  const getApyColor = (apy: number) => {
    if (apy >= 20) return 'text-purple-400'
    if (apy >= 15) return 'text-blue-400'
    if (apy >= 10) return 'text-green-400'
    if (apy >= 5) return 'text-yellow-400'
    return 'text-gray-400'
  }

  const currentApy = calculateDynamicApy()

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">스테이킹 대시보드</h2>
          <p className="text-gray-400">실시간 복리 이자 및 수익률 모니터링</p>
        </div>
        <button
          onClick={() => setIsStaking(!isStaking)}
          className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
            isStaking
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-green-600 hover:bg-green-700 text-white'
          }`}
        >
          {isStaking ? '스테이킹 중지' : '스테이킹 시작'}
        </button>
      </div>

      {/* 실시간 통계 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">현재 가치</p>
              <p className="text-2xl font-bold text-white">
                {formatCurrency(isStaking ? currentStats.currentValue : stakingAmount)}
              </p>
            </div>
            <div className="bg-blue-500/20 p-3 rounded-lg">
              <DollarSign className="h-6 w-6 text-blue-400" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xs text-gray-500">
              {isStaking ? '실시간 성장 중' : '스테이킹 대기'}
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">현재 APY</p>
              <p className={`text-2xl font-bold ${getApyColor(currentApy)}`}>
                {formatPercent(currentApy)}
              </p>
            </div>
            <div className="bg-green-500/20 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-green-400" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xs text-gray-500">
              실효 APY: {formatPercent(profitability.effectiveApy)}
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">총 수익</p>
              <p className="text-2xl font-bold text-green-400">
                {formatCurrency(currentStats.totalEarned)}
              </p>
            </div>
            <div className="bg-purple-500/20 p-3 rounded-lg">
              <Award className="h-6 w-6 text-purple-400" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xs text-gray-500">
              수익률: {currentStats.efficiency.toFixed(2)}%
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">일일 예상</p>
              <p className="text-2xl font-bold text-yellow-400">
                {formatCurrency(profitability.dailyInterest)}
              </p>
            </div>
            <div className="bg-orange-500/20 p-3 rounded-lg">
              <Clock className="h-6 w-6 text-orange-400" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xs text-gray-500">
              월간: {formatCurrency(profitability.monthlyInterest)}
            </div>
          </div>
        </div>
      </div>

      {/* 스테이킹 설정 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 풀 선택 및 설정 */}
        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">스테이킹 설정</h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                스테이킹 풀 선택
              </label>
              <select
                value={selectedPool.id}
                onChange={(e) => {
                  const pool = STAKING_POOLS.find(p => p.id === e.target.value)
                  if (pool) setSelectedPool(pool)
                }}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {STAKING_POOLS.map(pool => (
                  <option key={pool.id} value={pool.id}>
                    {pool.name} ({formatPercent(pool.baseApy)}-{formatPercent(pool.maxApy)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                스테이킹 금액 (MSUO)
              </label>
              <input
                type="number"
                value={stakingAmount}
                onChange={(e) => setStakingAmount(Math.max(selectedPool.minAmount, parseFloat(e.target.value) || 0))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                min={selectedPool.minAmount}
                max={selectedPool.maxAmount}
                step="100"
              />
              <div className="mt-1 text-xs text-gray-500">
                최소: {selectedPool.minAmount.toLocaleString('ko-KR')} MSUO | 최대: {selectedPool.maxAmount.toLocaleString('ko-KR')} MSUO
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                락업 기간
              </label>
              <select
                value={lockPeriod}
                onChange={(e) => setLockPeriod(parseInt(e.target.value))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {selectedPool.lockPeriods.map(days => (
                  <option key={days} value={days}>
                    {formatDays(days)} ({days >= 365 ? `+${formatPercent(3.5)} APY` : days >= 180 ? `+${formatPercent(2.0)} APY` : days >= 90 ? `+${formatPercent(1.0)} APY` : ''})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                복리 빈도
              </label>
              <select
                value={compoundFrequency}
                onChange={(e) => setCompoundFrequency(e.target.value as any)}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {selectedPool.compoundOptions.map(freq => (
                  <option key={freq} value={freq}>
                    {freq === 'continuous' ? '연속 복리 (+0.8% APY)' :
                     freq === 'daily' ? '일일 복리 (+0.5% APY)' :
                     freq === 'weekly' ? '주간 복리 (+0.3% APY)' :
                     freq === 'monthly' ? '월간 복리' : '연간 복리'}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-300">자동 복리</span>
              <button
                onClick={() => setAutoCompound(!autoCompound)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  autoCompound ? 'bg-blue-600' : 'bg-gray-600'
                }`}
              >
                <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  autoCompound ? 'translate-x-6' : 'translate-x-1'
                }`} />
              </button>
            </div>
          </div>

          {/* 풀 정보 */}
          <div className="mt-6 pt-6 border-t border-white/10">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-400">위험 등급:</span>
                <span className={`ml-2 px-2 py-1 rounded text-xs border ${getRiskColor(selectedPool.riskLevel)}`}>
                  {selectedPool.riskLevel}
                </span>
              </div>
              <div>
                <span className="text-gray-400">유동성:</span>
                <span className="ml-2 text-white">{selectedPool.liquidity}%</span>
              </div>
              <div>
                <span className="text-gray-400">참여자:</span>
                <span className="ml-2 text-white">{selectedPool.participants.toLocaleString()}명</span>
              </div>
              <div>
                <span className="text-gray-400">총 스테이킹:</span>
                <span className="ml-2 text-white">{(selectedPool.totalStaked / 1000000).toFixed(1)}M MSUO</span>
              </div>
            </div>
          </div>
        </div>

        {/* 수익 예측 */}
        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">수익 예측</h3>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">최종 금액</p>
                <p className="text-xl font-bold text-green-400">
                  {formatCurrency(profitability.finalAmount)}
                </p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">총 수익</p>
                <p className="text-xl font-bold text-blue-400">
                  {formatCurrency(profitability.netProfit)}
                </p>
              </div>
            </div>

            <div className="bg-white/5 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-400">수익률</span>
                <span className="text-sm font-bold text-white">
                  {formatPercent((profitability.netProfit / stakingAmount) * 100)}
                </span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-green-400 to-blue-400 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, (profitability.netProfit / stakingAmount) * 100 * 2)}%` }}
                />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">일일 수익:</span>
                <span className="text-white">{formatCurrency(profitability.dailyInterest)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">월간 수익:</span>
                <span className="text-white">{formatCurrency(profitability.monthlyInterest)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">연간 수익:</span>
                <span className="text-white">{formatCurrency(profitability.yearlyInterest)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">복리 배수:</span>
                <span className="text-white">{profitability.compoundMultiplier.toFixed(4)}x</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">배당 시간:</span>
                <span className="text-white">{formatDays(profitability.doublingTime)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">손익분기점:</span>
                <span className="text-white">{formatDays(profitability.breakEvenDays)}</span>
              </div>
            </div>

            {/* 보너스 정보 */}
            {profitability.totalBonuses > 0 && (
              <div className="mt-4 p-4 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <div className="flex items-center mb-2">
                  <Zap className="h-4 w-4 text-purple-400 mr-2" />
                  <span className="text-sm font-medium text-purple-400">보너스 효과</span>
                </div>
                <div className="text-xs text-purple-300">
                  총 보너스: {formatCurrency(profitability.totalBonuses)}
                  <div className="mt-1 space-y-1">
                    {Object.entries(profitability.bonusBreakdown).map(([type, amount]) =>
                      amount > 0 && (
                        <div key={type} className="flex justify-between">
                          <span>{type.charAt(0).toUpperCase() + type.slice(1)}:</span>
                          <span>{formatCurrency(amount)}</span>
                        </div>
                      )
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* 위험 경고 */}
            {selectedPool.riskLevel === 'HIGH' && (
              <div className="mt-4 p-4 bg-red-500/10 rounded-lg border border-red-500/30">
                <div className="flex items-center">
                  <AlertCircle className="h-4 w-4 text-red-400 mr-2" />
                  <span className="text-sm font-medium text-red-400">고위험 풀</span>
                </div>
                <p className="text-xs text-red-300 mt-1">
                  높은 수익률을 기대할 수 있지만, 변동성이 크고 손실 가능성이 있습니다.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 실시간 모니터링 */}
      {isStaking && (
        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">실시간 모니터링</h3>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 성장 차트 */}
            <div>
              <h4 className="text-sm font-medium text-gray-300 mb-2">가치 성장</h4>
              <div className="h-40 bg-black/30 rounded-lg relative overflow-hidden">
                <svg className="w-full h-full">
                  <polyline
                    fill="none"
                    stroke="#10B981"
                    strokeWidth="2"
                    points={profitability.projectedValue
                      .slice(0, Math.min(100, Math.floor(currentStats.timeElapsed)))
                      .map((value, index) => {
                        const x = (index / Math.min(100, lockPeriod)) * 100
                        const maxValue = Math.max(...profitability.projectedValue.slice(0, lockPeriod))
                        const y = 100 - (value / maxValue) * 80
                        return `${x},${y}`
                      })
                      .join(' ')}
                  />
                  {currentStats.currentValue > 0 && (
                    <circle
                      cx={((Math.floor(currentStats.timeElapsed) / lockPeriod) * 100)}
                      cy={100 - (currentStats.currentValue / Math.max(...profitability.projectedValue)) * 80}
                      r="3"
                      fill="#10B981"
                    />
                  )}
                </svg>
                <div className="absolute bottom-2 left-2 text-xs text-gray-400">
                  {formatDays(Math.floor(currentStats.timeElapsed))} / {formatDays(lockPeriod)}
                </div>
              </div>
            </div>

            {/* 이자 누적 */}
            <div>
              <h4 className="text-sm font-medium text-gray-300 mb-2">이자 누적</h4>
              <div className="space-y-2">
                <div className="bg-white/5 rounded-lg p-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">원금:</span>
                    <span className="text-white">{formatCurrency(stakingAmount)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">이자:</span>
                    <span className="text-green-400">{formatCurrency(currentStats.totalEarned)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold">
                    <span className="text-white">합계:</span>
                    <span className="text-white">{formatCurrency(currentStats.currentValue)}</span>
                  </div>
                </div>

                <div className="bg-white/5 rounded-lg p-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">현재 효율:</span>
                    <span className={`font-bold ${currentStats.efficiency > 10 ? 'text-green-400' : 'text-yellow-400'}`}>
                      {currentStats.efficiency.toFixed(3)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-1.5 mt-2">
                    <div
                      className="bg-green-400 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, currentStats.efficiency * 5)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between text-sm border-t border-white/10 pt-4">
            <div className="flex items-center text-gray-400">
              <Clock className="h-4 w-4 mr-1" />
              경과 시간: {formatTime(currentStats.timeElapsed)}
            </div>
            <div className="flex items-center text-gray-400">
              <Target className="h-4 w-4 mr-1" />
              목표 달성: {((currentStats.timeElapsed / lockPeriod) * 100).toFixed(1)}%
            </div>
            <div className="flex items-center text-gray-400">
              <Shield className="h-4 w-4 mr-1" />
              위험 등급: <span className={`ml-1 ${getRiskColor(selectedPool.riskLevel).split(' ')[0]}`}>
                {selectedPool.riskLevel}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}