'use client'

import { useState, useEffect, useRef } from 'react'
import { Activity, Cpu, Zap, TrendingUp, AlertTriangle, DollarSign, Clock, Award } from 'lucide-react'
import { MiningSimulator, MiningConfig, HARDWARE_PRESETS, NETWORK_PRESETS, calculateMiningProfitability } from '@/lib/mining-physics'

interface MiningStats {
  hashrate: number
  efficiency: number
  temperature: number
  powerUsage: number
  uptime: number
  blocksFound: number
  currentProfit: number
  networkDifficulty: number
}

interface RealTimeData {
  timestamp: number
  hashrate: number
  temperature: number
  profit: number
  efficiency: number
}

export default function MiningDashboard() {
  const [selectedHardware, setSelectedHardware] = useState(HARDWARE_PRESETS[0])
  const [miningConfig, setMiningConfig] = useState<MiningConfig>({
    ...NETWORK_PRESETS.bitcoin,
    userHashrate: HARDWARE_PRESETS[0].hashrate,
    powerConsumption: HARDWARE_PRESETS[0].powerConsumption,
    electricityCost: 0.12,
    poolFee: 1,
    poolHashrate: HARDWARE_PRESETS[0].hashrate
  })

  const [simulator, setSimulator] = useState<MiningSimulator | null>(null)
  const [isMining, setIsMining] = useState(false)
  const [realTimeData, setRealTimeData] = useState<RealTimeData[]>([])
  const [currentStats, setCurrentStats] = useState<MiningStats>({
    hashrate: 0,
    efficiency: 0,
    temperature: 45,
    powerUsage: 0,
    uptime: 0,
    blocksFound: 0,
    currentProfit: 0,
    networkDifficulty: NETWORK_PRESETS.bitcoin.networkDifficulty
  })

  const [profitability, setProfitability] = useState(calculateMiningProfitability(miningConfig))
  const animationRef = useRef<number | null>(null)
  const lastUpdateRef = useRef<number>(0)

  // 초기화
  useEffect(() => {
    lastUpdateRef.current = Date.now()
    if (isMining && !simulator) {
      setSimulator(new MiningSimulator(miningConfig))
    } else if (!isMining && simulator) {
      setSimulator(null)
    }
  }, [isMining, miningConfig, simulator])

  // 실시간 시뮬레이션
  useEffect(() => {
    if (!isMining || !simulator) return

    const animate = () => {
      const now = Date.now()
      const deltaTime = (now - lastUpdateRef.current) / 1000
      lastUpdateRef.current = now

      const result = simulator.update(deltaTime)

      // 실시간 데이터 업데이트
      setCurrentStats(prev => ({
        hashrate: result.hashrate,
        efficiency: result.efficiency * 1e9, // GH/W 단위 변환
        temperature: 45 + Math.sin(now / 10000) * 15 + Math.random() * 5, // 온도 변동
        powerUsage: miningConfig.powerConsumption + Math.random() * 100 - 50, // 전력 변동
        uptime: result.uptime,
        blocksFound: result.blocksFound,
        currentProfit: result.currentProfit,
        networkDifficulty: miningConfig.networkDifficulty * (1 + Math.sin(now / 50000) * 0.01) // 난이도 변동
      }))

      // 차트 데이터 추가
      setRealTimeData(prev => {
        const newData = [...prev, {
          timestamp: now,
          hashrate: result.hashrate / 1e12, // TH/s
          temperature: 45 + Math.sin(now / 10000) * 15 + Math.random() * 5,
          profit: result.currentProfit,
          efficiency: result.efficiency * 1e9
        }]

        // 최근 100개 데이터만 유지
        return newData.slice(-100)
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animationRef.current = requestAnimationFrame(animate)

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [isMining, simulator, miningConfig])

  // 수익성 재계산
  useEffect(() => {
    setProfitability(calculateMiningProfitability(miningConfig))
  }, [miningConfig])

  const formatHashrate = (hashrate: number) => {
    if (hashrate >= 1e15) return `${(hashrate / 1e15).toFixed(2)} EH/s`
    if (hashrate >= 1e12) return `${(hashrate / 1e12).toFixed(2)} TH/s`
    if (hashrate >= 1e9) return `${(hashrate / 1e9).toFixed(2)} GH/s`
    if (hashrate >= 1e6) return `${(hashrate / 1e6).toFixed(2)} MH/s`
    return `${hashrate.toFixed(2)} H/s`
  }

  const formatTemperature = (temp: number) => `${temp.toFixed(1)}°C`
  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount)

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = Math.floor(seconds % 60)
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const getTemperatureColor = (temp: number) => {
    if (temp < 50) return 'text-green-400'
    if (temp < 70) return 'text-yellow-400'
    return 'text-red-400'
  }

  const getEfficiencyColor = (efficiency: number) => {
    if (efficiency > 40) return 'text-green-400'
    if (efficiency > 30) return 'text-yellow-400'
    return 'text-red-400'
  }

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">채굴 대시보드</h2>
          <p className="text-gray-400">실시간 채굴 모니터링 및 수익성 분석</p>
        </div>
        <button
          onClick={() => setIsMining(!isMining)}
          className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
            isMining
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-green-600 hover:bg-green-700 text-white'
          }`}
        >
          {isMining ? '채굴 중지' : '채굴 시작'}
        </button>
      </div>

      {/* 실시간 통계 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">해시레이트</p>
              <p className="text-2xl font-bold text-white">
                {formatHashrate(currentStats.hashrate)}
              </p>
            </div>
            <div className="bg-blue-500/20 p-3 rounded-lg">
              <Zap className="h-6 w-6 text-blue-400" />
            </div>
          </div>
          <div className="mt-2">
            <div className="flex items-center text-xs text-gray-500">
              <Activity className="h-3 w-3 mr-1" />
              {isMining ? '실시간 채굴 중' : '대기 중'}
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">효율성</p>
              <p className={`text-2xl font-bold ${getEfficiencyColor(currentStats.efficiency)}`}>
                {currentStats.efficiency.toFixed(2)} GH/W
              </p>
            </div>
            <div className="bg-green-500/20 p-3 rounded-lg">
              <TrendingUp className="h-6 w-6 text-green-400" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xs text-gray-500">
              최적: 40+ GH/W
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">온도</p>
              <p className={`text-2xl font-bold ${getTemperatureColor(currentStats.temperature)}`}>
                {formatTemperature(currentStats.temperature)}
              </p>
            </div>
            <div className="bg-orange-500/20 p-3 rounded-lg">
              <Cpu className="h-6 w-6 text-orange-400" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xs text-gray-500">
              {currentStats.temperature > 70 ? (
                <span className="flex items-center text-red-400">
                  <AlertTriangle className="h-3 w-3 mr-1" />
                  과열 경고
                </span>
              ) : (
                '정상 작동'
              )}
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-sm">현재 수익</p>
              <p className="text-2xl font-bold text-white">
                {formatCurrency(currentStats.currentProfit)}
              </p>
            </div>
            <div className="bg-yellow-500/20 p-3 rounded-lg">
              <DollarSign className="h-6 w-6 text-yellow-400" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-xs text-gray-500">
              블록: {currentStats.blocksFound}개
            </div>
          </div>
        </div>
      </div>

      {/* 상세 정보 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 하드웨어 설정 */}
        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">하드웨어 설정</h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                장비 선택
              </label>
              <select
                value={selectedHardware.name}
                onChange={(e) => {
                  const hardware = HARDWARE_PRESETS.find(h => h.name === e.target.value)
                  if (hardware) {
                    setSelectedHardware(hardware)
                    setMiningConfig(prev => ({
                      ...prev,
                      userHashrate: hardware.hashrate,
                      powerConsumption: hardware.powerConsumption
                    }))
                  }
                }}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {HARDWARE_PRESETS.map(hardware => (
                  <option key={hardware.name} value={hardware.name}>
                    {hardware.name} ({formatHashrate(hardware.hashrate)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                전력 비용 ($/kWh)
              </label>
              <input
                type="number"
                value={miningConfig.electricityCost}
                onChange={(e) => setMiningConfig(prev => ({
                  ...prev,
                  electricityCost: parseFloat(e.target.value) || 0
                }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                step="0.01"
                min="0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                풀 수수료 (%)
              </label>
              <input
                type="number"
                value={miningConfig.poolFee}
                onChange={(e) => setMiningConfig(prev => ({
                  ...prev,
                  poolFee: parseFloat(e.target.value) || 0
                }))}
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                step="0.1"
                min="0"
                max="5"
              />
            </div>
          </div>

          {/* 하드웨어 정보 */}
          <div className="mt-6 pt-6 border-t border-white/10">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-400">장비 가격:</span>
                <span className="ml-2 text-white">{formatCurrency(selectedHardware.cost)}</span>
              </div>
              <div>
                <span className="text-gray-400">알고리즘:</span>
                <span className="ml-2 text-white">{selectedHardware.algorithm}</span>
              </div>
              <div>
                <span className="text-gray-400">효율성:</span>
                <span className="ml-2 text-white">{selectedHardware.efficiency} J/TH</span>
              </div>
              <div>
                <span className="text-gray-400">전력 사용:</span>
                <span className="ml-2 text-white">{selectedHardware.powerConsumption}W</span>
              </div>
            </div>
          </div>
        </div>

        {/* 수익성 분석 */}
        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">수익성 분석</h3>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">일일 수익</p>
                <p className="text-xl font-bold text-green-400">
                  {formatCurrency(profitability.dailyProfit)}
                </p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">월간 수익</p>
                <p className="text-xl font-bold text-blue-400">
                  {formatCurrency(profitability.monthlyProfit)}
                </p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">연간 수익</p>
                <p className="text-xl font-bold text-purple-400">
                  {formatCurrency(profitability.yearlyProfit)}
                </p>
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">ROI</p>
                <p className={`text-xl font-bold ${profitability.roi > 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {profitability.roi.toFixed(1)}%
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">일일 전력비:</span>
                <span className="text-white">{formatCurrency(profitability.dailyPowerCost)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">블록당 평균 시간:</span>
                <span className="text-white">{profitability.averageTimeToBlock.toFixed(1)}시간</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">손익분기점:</span>
                <span className="text-white">
                  {profitability.breakEvenTime === Infinity ? 'N/A' : `${profitability.breakEvenTime.toFixed(0)}일`}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">채굴 확률:</span>
                <span className="text-white">{(profitability.probabilityPerBlock * 100).toFixed(8)}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 실시간 그래프 */}
      {realTimeData.length > 0 && (
        <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">실시간 모니터링</h3>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 해시레이트 그래프 */}
            <div>
              <h4 className="text-sm font-medium text-gray-300 mb-2">해시레이트 (TH/s)</h4>
              <div className="h-32 bg-black/30 rounded-lg relative overflow-hidden">
                <svg className="w-full h-full">
                  <polyline
                    fill="none"
                    stroke="#3B82F6"
                    strokeWidth="2"
                    points={realTimeData
                      .slice(-50)
                      .map((point, index) => {
                        const x = (index / 49) * 100
                        const maxHashrate = Math.max(...realTimeData.slice(-50).map(d => d.hashrate))
                        const y = 100 - (point.hashrate / maxHashrate) * 100
                        return `${x},${y}`
                      })
                      .join(' ')}
                  />
                </svg>
              </div>
            </div>

            {/* 수익 그래프 */}
            <div>
              <h4 className="text-sm font-medium text-gray-300 mb-2">수익 ($)</h4>
              <div className="h-32 bg-black/30 rounded-lg relative overflow-hidden">
                <svg className="w-full h-full">
                  <polyline
                    fill="none"
                    stroke="#10B981"
                    strokeWidth="2"
                    points={realTimeData
                      .slice(-50)
                      .map((point, index) => {
                        const x = (index / 49) * 100
                        const minProfit = Math.min(...realTimeData.slice(-50).map(d => d.profit))
                        const maxProfit = Math.max(...realTimeData.slice(-50).map(d => d.profit))
                        const range = maxProfit - minProfit
                        const y = range > 0 ? 100 - ((point.profit - minProfit) / range) * 100 : 50
                        return `${x},${y}`
                      })
                      .join(' ')}
                  />
                </svg>
              </div>
            </div>
          </div>

          {/* 작업 시간 */}
          <div className="mt-4 flex items-center justify-between text-sm">
            <div className="flex items-center text-gray-400">
              <Clock className="h-4 w-4 mr-1" />
              작업 시간: {formatUptime(currentStats.uptime)}
            </div>
            <div className="flex items-center text-gray-400">
              <Award className="h-4 w-4 mr-1" />
              찾은 블록: {currentStats.blocksFound}개
            </div>
          </div>
        </div>
      )}
    </div>
  )
}