'use client'

import { useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { Activity, DollarSign, TrendingUp, Zap, Shield, Award, Clock, BarChart3, Cpu, AlertCircle } from 'lucide-react'
import MiningDashboard from './components/MiningDashboard'
import StakingDashboard from './components/StakingDashboard'
import UserHeader from '@/components/layout/UserHeader'

interface User {
  id: string
  username: string | null
  email: string | null
  personalCoin: number
  walletAddress: string | null
}

interface AdvancedMiningStakingProps {
  users: User
}

export default function AdvancedMiningStaking({ user }: AdvancedMiningStakingProps) {
  const [activeTab, setActiveTab] = useState('mining')
  const router = useRouter()
  const pathname = usePathname()

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      router.push('/login')
      router.refresh()
    } catch (error) {
      console.error('Logout failed:', error)
    }
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-[#101922] overflow-x-hidden">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-10 md:px-20 lg:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1 overflow-visible">
            <UserHeader
              user={user}
              currentPath={pathname || '/mining-staking'}
              onLogout={handleLogout}
            />

            <main className="flex-1 py-8 px-4 sm:px-6 lg:px-8">
              <div className="container mx-auto">
                <div className="mb-8">
                  <h1 className="text-4xl font-bold text-white mb-4">
                    고급 채굴 & 스테이킹 시뮬레이터
                  </h1>
                  <p className="text-gray-400 text-lg max-w-3xl">
                    물리적 채굴 계산과 실시간 복리 스테이킹으로 암호화폐 수익을 극대화하세요.
                    실제 시장 조건을 반영한 현실적인 수익성 분석과 위험 관리를 제공합니다.
                  </p>
                </div>

                {/* 통계 카드 */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border border-blue-500/20 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-500/20 p-3 rounded-lg">
              <Cpu className="h-6 w-6 text-blue-400" />
            </div>
            <span className="text-blue-400 text-sm font-medium">채굴</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">400+ EH/s</h3>
          <p className="text-gray-400 text-sm">네트워크 총 해시레이트</p>
          <div className="mt-4 flex items-center text-blue-400 text-sm">
            <TrendingUp className="h-4 w-4 mr-1" />
            +12.5% 이번 달
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500/10 to-green-600/10 border border-green-500/20 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-500/20 p-3 rounded-lg">
              <DollarSign className="h-6 w-6 text-green-400" />
            </div>
            <span className="text-green-400 text-sm font-medium">스테이킹</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">$45M+</h3>
          <p className="text-gray-400 text-sm">총 스테이킹 액수</p>
          <div className="mt-4 flex items-center text-green-400 text-sm">
            <TrendingUp className="h-4 w-4 mr-1" />
            +28.3% 이번 달
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border border-purple-500/20 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-purple-500/20 p-3 rounded-lg">
              <Award className="h-6 w-6 text-purple-400" />
            </div>
            <span className="text-purple-400 text-sm font-medium">평균 APY</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">18.7%</h3>
          <p className="text-gray-400 text-sm">가중 평균 수익률</p>
          <div className="mt-4 flex items-center text-purple-400 text-sm">
            <Activity className="h-4 w-4 mr-1" />
            실시간 업데이트
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border border-orange-500/20 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-orange-500/20 p-3 rounded-lg">
              <Shield className="h-6 w-6 text-orange-400" />
            </div>
            <span className="text-orange-400 text-sm font-medium">보험</span>
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">100%</h3>
          <p className="text-gray-400 text-sm">자산 보장 비율</p>
          <div className="mt-4 flex items-center text-orange-400 text-sm">
            <AlertCircle className="h-4 w-4 mr-1" />
            위험 관리 활성
          </div>
                </div>
              </div>

              {/* 탭 네비게이션 */}
              <div className="bg-[#1e293b] border border-white/10 rounded-lg p-1 mb-8">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setActiveTab('mining')}
                    className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2 ${
                      activeTab === 'mining'
                        ? 'bg-[#137fec] text-white'
                        : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Zap className="h-4 w-4" />
                    고급 채굴 시뮬레이터
                  </button>
                  <button
                    onClick={() => setActiveTab('staking')}
                    className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2 ${
                      activeTab === 'staking'
                        ? 'bg-[#137fec] text-white'
                        : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <BarChart3 className="h-4 w-4" />
                    실시간 스테이킹
                  </button>
                </div>
              </div>

              {/* 컨텐츠 */}
              {activeTab === 'mining' && <MiningDashboard />}
              {activeTab === 'staking' && <StakingDashboard />}

              {/* 하단 정보 */}
              <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
            <Cpu className="h-5 w-5 mr-2 text-blue-400" />
            채굴 시스템 특징
          </h3>
          <ul className="space-y-3 text-gray-300">
            <li className="flex items-start">
              <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">실제 물리 계산:</strong> 비트코인/이더리움 네트워크와 동일한 난이도 알고리즘 적용
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">동적 난이도 조정:</strong> 네트워크 난이도 변화에 따른 실시간 수익성 업데이트
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">다중 장비 지원:</strong> Antminer, WhatsMiner, GPU 등 주요 채굴 장비 최적화
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">전력 효율 분석:</strong> 실시간 전력 소비 및 온도 모니터링으로 ROI 최적화
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">스트레스 테스트:</strong> 시장 조건 변화 시뮬레이션으로 위험 관리
              </div>
            </li>
          </ul>
                </div>

                <div className="bg-[#1e293b] border border-white/10 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
            <Shield className="h-5 w-5 mr-2 text-green-400" />
            스테이킹 시스템 특징
          </h3>
          <ul className="space-y-3 text-gray-300">
            <li className="flex items-start">
              <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">실시간 복리:</strong> 초 단위 정확도의 연속/일일/주간/월간 복리 계산
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">동적 APY:</strong> 시장 조건, 락업 기간, 금액에 따른 변동 보너스 시스템
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">다양한 풀:</strong> StableUSD, DeFi, High Yield, Liquid Farming 등 4가지 전략
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">위험 관리:</strong> 변동성, 샤프 비율, 최대 손실 등 체계적인 리스크 분석
              </div>
            </li>
            <li className="flex items-start">
              <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0" />
              <div>
                <strong className="text-white">자동 보너스:</strong> 충성도, 추천, 거래량, 성과 보너스 자동 적용
              </div>
            </li>
          </ul>
                </div>
              </div>

              {/* 알림 */}
              <div className="mt-8 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 rounded-xl p-6">
                  <div className="flex items-start">
                    <AlertCircle className="h-5 w-5 text-yellow-400 mr-3 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-lg font-semibold text-white mb-2">투자 유의사항</h4>
                      <ul className="space-y-2 text-gray-300 text-sm">
                        <li>• 본 시스템은 교육 및 시뮬레이션 목적으로 제공되며, 실제 투자 결정에 대한 법적 책임은 없습니다.</li>
                        <li>• 암호화폐 시장은 높은 변동성을 가지며, 과거 수익이 미래 수익을 보장하지 않습니다.</li>
                        <li>• 채굴 수익성은 네트워크 난이도, 전력 비용, 장비 가격 등 다양한 요인에 의해 변동됩니다.</li>
                        <li>• 스테이킹 스마트 컨트랙트의 취약성, 프로토콜 변경 등 기술적 위험이 존재합니다.</li>
                        <li>• 항상 투자 가능한 금액의 일부만 투자하고, 포트폴리오 다변화를 권장합니다.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  )
}