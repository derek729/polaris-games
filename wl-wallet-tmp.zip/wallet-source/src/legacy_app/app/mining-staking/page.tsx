import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { isAdminUser } from '@/lib/admin-auth';
import AdvancedMiningStaking from './AdvancedMiningStaking';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

export default async function MiningStakingPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  if (isAdminUser(user)) {
    redirect('/a0-admin');
  }

  // Decimal 객체를 숫자로 변환하여 Client Component에 전달
  return (
    <AdvancedMiningStaking
      user={{
        id: user.id,
        username: user.username,
        email: user.email,
        personalCoin: decimalToNumber(user.personalCoin),
        walletAddress: user.walletAddress,
      }}
    />
  );
}

