'use client';

import { useEffect, useState, useMemo } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useI18n } from '@/lib/i18n/context';
import UserHeader from '@/components/layout/UserHeader';

interface User {
  id: string;
  username: string;
  email: string;
  personalCoin: number;
}

interface Product {
  id: number;
  tier: number;
  name: string;
  amount: number;
  dailyRate: number;
  annualRate: number;
  period: number;
  category: string;
  recommended?: boolean;
  matchingDepth?: number;
  description?: string;
}

interface Investment {
  id: string;
  amount: number;
  dailyRate: number;
  isActive: boolean;
  createdAt: string;
  endDate: string;
}

interface GameProduct {
  gameId: string;
  gameName: string;
  description?: string | null;
  imageUrl?: string | null;
  shareId: string;
  sharePercentage: number;
  price: number;
  availableShares: number;
  totalShares: number;
}

export default function ProductsClient({
  user,
  products,
  investments,
  language,
  gameProducts = [],
}: {
  users: User;
  products: Product[];
  investments: Investment[];
  language?: string;
  gameProducts?: GameProduct[];
}) {
  const router = useRouter();
  const pathname = usePathname();
  const { t } = useI18n();
  const currentLanguage = language || 'ko';
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const categories = useMemo(() => {
    return [
      t.categories.all,
      t.categories.shortTermHighYield,
      t.categories.longTermStable,
      t.categories.recommended
    ];
  }, [t.categories]);

  const [selectedCategory, setSelectedCategory] = useState(categories[0]);

  // language가 변경되면 selectedCategory도 업데이트
  useEffect(() => {
    setSelectedCategory(categories[0]);
  }, [categories]);

  const filteredProducts = useMemo(() => {
    if (!products || products.length === 0) return [];

    // 번역된 카테고리 매핑 사용
    const currentCategories = t.product?.categories || {
      shortTerm: currentLanguage === 'ko' ? '단기' : 'Short-term',
      stable: currentLanguage === 'ko' ? '안정형' : 'Stable',
      highYield: currentLanguage === 'ko' ? '고수익' : 'High Yield',
    };

    return products.filter((product) => {
      if (selectedCategory === t.categories.all) return true;
      if (selectedCategory === t.categories.shortTermHighYield)
        return product.category === currentCategories.shortTerm || product.category === currentCategories.highYield;
      if (selectedCategory === t.categories.longTermStable)
        return product.category === currentCategories.stable;
      if (selectedCategory === t.categories.recommended) return product.recommended;
      return true;
    });
  }, [selectedCategory, products, t.categories, currentLanguage, t.product?.categories]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat(language === 'ko' ? 'ko-KR' : 'en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(language === 'ko' ? 'ko-KR' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatNumber = (value: number) =>
    new Intl.NumberFormat(language === 'ko' ? 'ko-KR' : 'en-US').format(value);

  const formatPercentage = (value: number) =>
    Number(value).toFixed(value % 1 === 0 ? 0 : 2);

  // 상품 tier에 따라 번역된 이름과 설명을 반환하는 함수
  const getProductTranslation = (tier: number) => {
    const productMap: Record<number, { name: string; description: string }> = {
      1: {
        name: t.invest.products.starter.name,
        description: t.invest.products.starter.description,
      },
      2: {
        name: t.invest.products.business.name,
        description: t.invest.products.business.description,
      },
      3: {
        name: t.invest.products.professional.name,
        description: t.invest.products.professional.description,
      },
      4: {
        name: t.invest.products.enterprise.name,
        description: t.invest.products.enterprise.description,
      },
    };

    return productMap[tier] || { name: '', description: '' };
  };

  // 카테고리를 번역하는 함수
  const getCategoryTranslation = (category: string) => {
    // 서버에서 한글로 저장된 카테고리를 번역 키로 매핑
    const categoryMap: Record<string, string> = {
      '단기': t.invest.categories?.shortTerm || category,
      '안정형': t.invest.categories?.stable || category,
      '고수익': t.invest.categories?.highYield || category,
    };

    return categoryMap[category] || category;
  };


  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-white">{t.common.loading}</div>
      </div>
    );
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1 overflow-visible">
            {/* Header */}
            <UserHeader
              user={user}
              currentPath={pathname || ''}
              onLogout={handleLogout}
            />

            <main className="flex-1 p-2 sm:p-4 md:p-6 overflow-visible relative z-0">
              {/* Page Title */}
              <div className="flex flex-wrap justify-between gap-3 sm:gap-4 py-3 sm:py-4 px-2">
                <div className="flex flex-col gap-1 sm:gap-2 min-w-0 flex-1">
                  <p className="text-white text-xl sm:text-2xl md:text-3xl lg:text-4xl font-black leading-tight tracking-[-0.033em] break-words">
                    {t.product.title}
                  </p>
                  <p className="text-gray-400 dark:text-gray-400 text-xs sm:text-sm md:text-base font-normal leading-normal break-words">
                    {t.product.subtitle}
                  </p>
                </div>
              </div>

              {/* Category Chips */}
              <div className="flex gap-2 sm:gap-3 p-2 sm:p-3 overflow-x-auto -mx-2 sm:mx-0">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`flex h-8 sm:h-9 shrink-0 items-center justify-center gap-x-1 sm:gap-x-2 rounded-lg pl-3 sm:pl-4 pr-3 sm:pr-4 cursor-pointer transition-colors ${selectedCategory === category
                      ? 'bg-[#137fec] text-white'
                      : 'bg-[#233648] hover:bg-[#137fec]/50 text-white'
                      }`}
                  >
                    <p className="text-xs sm:text-sm font-medium leading-normal break-words">{category}</p>
                  </button>
                ))}
              </div>

              {/* Products Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 px-2 sm:px-4 py-4 sm:py-6">
                {filteredProducts.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <p className="text-gray-400 dark:text-gray-500">
                      {t.product.noProducts}
                    </p>
                  </div>
                ) : (
                  filteredProducts.map((product) => {
                    const productTranslation = getProductTranslation(product.tier);
                    return (
                      <div
                        key={product.id}
                        className={`flex flex-1 flex-col gap-4 rounded-xl border border-solid p-6 transition-colors duration-300 relative ${product.recommended
                          ? 'border-[#137fec] bg-[#192633] ring-2 ring-[#137fec]/50'
                          : 'border-[#324d67] bg-[#192633] hover:border-[#137fec]'
                          }`}
                      >
                        {product.recommended && (
                          <div className="absolute top-0 right-0 bg-[#137fec] text-white text-xs font-bold px-8 py-1 -rotate-45 translate-x-1/4 translate-y-2.5">
                            {t.product.recommended}
                          </div>
                        )}
                        <div className="flex flex-col gap-2">
                          <div className="flex items-center justify-between gap-2">
                            <h3 className="text-white text-base sm:text-lg font-bold leading-tight">
                              {productTranslation.name || product.name}
                            </h3>
                            <span className="text-[#92adc9] text-xs font-medium px-2 py-1 rounded bg-white/5 whitespace-nowrap shrink-0">
                              {getCategoryTranslation(product.category)}
                            </span>
                          </div>
                          {productTranslation.description && (
                            <p className="text-gray-400 text-xs sm:text-sm leading-normal">
                              {productTranslation.description}
                            </p>
                          )}
                          <p className="flex items-baseline gap-1 text-white mt-2">
                            <span className="text-white text-2xl sm:text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                              ${product.amount.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US')}
                            </span>
                          </p>
                        </div>
                        <div className="flex flex-col gap-3 my-4">
                          <div className="flex items-center justify-between">
                            <p className="text-[#92adc9] text-xs sm:text-sm font-normal leading-normal">
                              {t.invest.dailyRate}
                            </p>
                            <p className="text-white text-sm sm:text-base font-bold leading-tight">
                              {(product.dailyRate * 100).toFixed(4)}%
                            </p>
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-[#92adc9] text-xs sm:text-sm font-normal leading-normal">
                              {t.invest.annualRate}
                            </p>
                            <p className="text-white text-sm sm:text-base font-bold leading-tight">
                              {product.annualRate}%
                            </p>
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-[#92adc9] text-xs sm:text-sm font-normal leading-normal">
                              {t.invest.matchingDepth}
                            </p>
                            <p className="text-white text-sm sm:text-base font-bold leading-tight">
                              {product.matchingDepth || 0} {t.product.generations}
                            </p>
                          </div>
                          <div className="flex items-center justify-between">
                            <p className="text-[#92adc9] text-xs sm:text-sm font-normal leading-normal">
                              {t.invest.investmentPeriod}
                            </p>
                            <p className="text-white text-sm sm:text-base font-bold leading-tight">
                              {product.period} {t.product.days}
                            </p>
                          </div>
                        </div>
                        <Link
                          href={`/invest?product=${product.id}`}
                          className="flex items-center justify-center gap-2 min-h-[44px] h-auto px-4 py-2 sm:py-0 sm:h-10 rounded-lg bg-[#137fec] text-white text-sm sm:text-base font-bold leading-normal hover:bg-[#137fec]/90 transition-colors no-min-size"
                        >
                          <span className="truncate">{t.product.investNow}</span>
                        </Link>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Game Share Products */}
              {gameProducts && gameProducts.length > 0 && (
                <section className="mt-4 sm:mt-8 px-2 sm:px-4">
                  <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                    <div className="flex flex-col gap-1">
                      <p className="text-white text-2xl sm:text-3xl font-black leading-tight tracking-[-0.033em]">
                        {t.product.gameSectionTitle || t.common.gameShareInvestment}
                      </p>
                      <p className="text-gray-400 text-sm sm:text-base">
                        {t.product.gameSectionSubtitle ||
                          (language === 'ko'
                            ? '실제 게임 수익을 분배하는 지분 상품을 확인하세요.'
                            : 'Discover revenue-sharing products from live games.')}
                      </p>
                    </div>
                    <Link
                      href="/game-game_shares"
                      className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/20 bg-white/5 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10 transition-colors"
                    >
                      <span className="material-symbols-outlined text-base">stadia_controller</span>
                      {t.product.viewGameShares || t.common.gameShareInvestment}
                    </Link>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                    {gameProducts.map((game) => (
                      <div
                        key={game.shareId}
                        className="flex flex-col gap-4 rounded-xl border border-solid border-[#2e4254] bg-[#13202c] p-5 hover:border-[#137fec] transition-colors"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex flex-col gap-1 min-w-0">
                            <p className="text-white text-lg font-bold leading-tight break-words">
                              {game.gameName}
                            </p>
                            {game.description && (
                              <p className="text-gray-400 text-xs sm:text-sm break-words">
                                {game.description}
                              </p>
                            )}
                          </div>
                          <span className="text-[#7fd1ff] text-sm font-bold bg-white/5 px-3 py-1 rounded-lg">
                            {formatPercentage(game.sharePercentage)}%
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="rounded-lg border border-white/5 bg-white/5 p-3">
                            <p className="text-gray-400 text-xs">{t.product.gameSharePrice}</p>
                            <p className="text-white text-base font-semibold mt-1">
                              {formatCurrency(game.price)}
                            </p>
                          </div>
                          <div className="rounded-lg border border-white/5 bg-white/5 p-3">
                            <p className="text-gray-400 text-xs">{t.product.gameShareAvailable}</p>
                            <p className="text-white text-base font-semibold mt-1">
                              {formatNumber(game.availableShares)} / {formatNumber(game.totalShares)}
                            </p>
                          </div>
                        </div>

                        <Link
                          href="/game-game_shares"
                          className="flex items-center justify-center gap-2 min-h-[44px] rounded-lg bg-[#2f7f6a] text-white text-sm sm:text-base font-bold leading-normal hover:bg-[#2f7f6a]/90 transition-colors"
                        >
                          <span className="material-symbols-outlined text-base">stadia_controller</span>
                          {t.common.gameShareInvestment}
                        </Link>
                      </div>
                    ))}
                  </div>
                </section>
              )}

                {/* My Investments */}
                {investments && investments.length > 0 && (
                  <div className="mt-8 px-4">
                    <div className="rounded-xl border border-white/10 bg-white/5 p-6">
                      <h3 className="text-white text-lg font-bold mb-4">
                        {t.product.myInvestments}
                      </h3>
                      <div className="space-y-3">
                        {investments.map((investment) => (
                          <div
                            key={investment.id}
                            className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                          >
                            <div className="flex items-center gap-4">
                              <div className="flex-shrink-0 size-12 rounded-full bg-[#137fec]/20 text-[#137fec] flex items-center justify-center">
                                <span className="material-symbols-outlined text-xl">account_balance_wallet</span>
                              </div>
                              <div>
                                <p className="text-white text-base font-medium">
                                  {formatCurrency(investment.amount)}
                                </p>
                                <p className="text-gray-400 text-sm">
                                  {t.invest.dailyRate}: {(investment.dailyRate * 100).toFixed(4)}%
                                </p>
                                <p className="text-gray-500 text-xs mt-1">
                                  {t.product.startDate}: {formatDate(investment.createdAt)}
                                </p>
                                {!investment.isActive && (
                                  <p className="text-gray-500 text-xs">
                                    {t.product.endDate}: {formatDate(investment.endDate)}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <span
                                className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${investment.isActive
                                  ? 'bg-green-500/20 text-green-400'
                                  : 'bg-gray-500/20 text-gray-400'
                                  }`}
                              >
                                {investment.isActive ? t.status.active : t.status.expired}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )
                }
            </main>
          </div>
        </div >
      </div >
    </div >
  );
}
