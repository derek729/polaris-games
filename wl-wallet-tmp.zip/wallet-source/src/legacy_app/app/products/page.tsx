import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { headers } from 'next/headers';
import ProductsClient from './ProductsClient';
import { isAdminUser } from '@/lib/admin-auth';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 투자 상품 데이터 가져오기 (서버 사이드)
async function getInvestmentProducts(language: string) {
  try {
    // 기본 상품이 없으면 생성
    const existing = await prisma.investment_tiers.findMany({
      orderBy: { tier: 'asc' },
    });

    if (existing.length === 0) {
      console.log('[Products Page] No investment tiers found. Creating default tiers...');
      try {
        await prisma.investment_tiers.createMany({
          data: [
            {
              id: 1,
              tier: 1,
              minAmount: new Prisma.Decimal(50),
              maxAmount: new Prisma.Decimal(99),
              dailyRate: new Prisma.Decimal(0.003),
              matchingDepth: 0,
              referralRates: [],
              description: '$50-$99: 초보 투자자 (매칭 보너스 없음)',
            },
            {
              id: 2,
              tier: 2,
              minAmount: new Prisma.Decimal(100),
              maxAmount: new Prisma.Decimal(999),
              dailyRate: new Prisma.Decimal(0.005),
              matchingDepth: 4,
              referralRates: [0.12, 0.08, 0.08, 0.08],
              description: '$100-$999: 일반 투자자 (1~4대 매칭 보너스)',
            },
            {
              id: 3,
              tier: 3,
              minAmount: new Prisma.Decimal(1000),
              maxAmount: new Prisma.Decimal(9999),
              dailyRate: new Prisma.Decimal(0.01),
              matchingDepth: 8,
              referralRates: [0.15, 0.12, 0.10, 0.08, 0.08, 0.08, 0.08, 0.08],
              description: '$1,000-$9,999: 고급 투자자 (1~8대 매칭 보너스)',
            },
            {
              id: 4,
              tier: 4,
              minAmount: new Prisma.Decimal(10000),
              maxAmount: new Prisma.Decimal(999999),
              dailyRate: new Prisma.Decimal(0.012),
              matchingDepth: 12,
              referralRates: [0.20, 0.15, 0.12, 0.10, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08],
              description: '$10,000+: VIP 투자자 (1~12대 매칭 보너스)',
            },
          ],
          skipDuplicates: true,
        });
        console.log('[Products Page] Default investment tiers created successfully.');
      } catch (createError: any) {
        console.error('[Products Page] Failed to create default tiers:', createError);
        // 에러가 발생해도 계속 진행 (이미 존재할 수 있음)
      }
    }

    const tiers = await prisma.investment_tiers.findMany({
      orderBy: { tier: 'asc' },
    });

    console.log(`[Products Page] Found ${tiers.length} investment tiers`);

  const productNames = {
    ko: {
      1: { name: '스타터 패키지', category: '단기', description: '스타터 패키지 - 초보 투자자를 위한 단기 상품' },
      2: { name: '비즈니스 패키지', category: '안정형', description: '비즈니스 패키지 - 안정적인 수익을 원하는 투자자를 위한 추천 상품' },
      3: { name: '프로페셔널 패키지', category: '고수익', description: '프로페셔널 패키지 - 고수익을 추구하는 투자자를 위한 상품' },
      4: { name: '엔터프라이즈 패키지', category: '고수익', description: '엔터프라이즈 패키지 - 최고 수익을 원하는 대형 투자자를 위한 프리미엄 상품' },
    },
    en: {
      1: { name: 'Starter Package', category: 'Short-term', description: 'Starter Package - Short-term product for beginner investors' },
      2: { name: 'Business Package', category: 'Stable', description: 'Business Package - Recommended product for investors seeking stable returns' },
      3: { name: 'Professional Package', category: 'High Yield', description: 'Professional Package - Product for investors pursuing high returns' },
      4: { name: 'Enterprise Package', category: 'High Yield', description: 'Enterprise Package - Premium product for large investors seeking maximum returns' },
    },
  };

  return tiers.map((tier) => {
    const dailyRate = decimalToNumber(tier.dailyRate);
    const annualRate = dailyRate * 365 * 100;
    const productInfo = productNames[language === 'en' ? 'en' : 'ko'][tier.tier as keyof typeof productNames.ko] || productNames.ko[tier.tier as keyof typeof productNames.ko];
    let recommended = false;
    let period = 180;
    let displayAmount = decimalToNumber(tier.minAmount);

    if (tier.tier === 1) {
      displayAmount = 50;
      period = 180;
    } else if (tier.tier === 2) {
      displayAmount = 100;
      recommended = true;
      period = 365;
    } else if (tier.tier === 3) {
      displayAmount = 1000;
      period = 730;
    } else if (tier.tier === 4) {
      displayAmount = 10000;
      period = 730;
    }

    return {
      id: tier.id,
      tier: tier.tier,
      name: productInfo.name,
      amount: displayAmount,
      dailyRate,
      annualRate: Math.round(annualRate * 10) / 10,
      period,
      category: productInfo.category,
      recommended,
      matchingDepth: tier.matchingDepth,
      description: productInfo.description,
    };
  });
  } catch (error: any) {
    console.error('[Products Page] Error in getInvestmentProducts:', error);
    // 에러 발생 시 빈 배열 반환
    return [];
  }
}

// 게임 상품 데이터 가져오기 (서버 사이드)
async function getGameProducts() {
  const games = await prisma.games.findMany({
    where: { isActive: true },
    include: {
      game_shares: {
        where: { isActive: true },
        orderBy: { sharePercentage: 'asc' },
      },
    },
    orderBy: { createdAt: 'desc' },
  });

  return games.flatMap((game) =>
    game.game_shares.map((share) => ({
      gameId: game.id,
      gameName: game.name,
      description: game.description,
      imageUrl: game.imageUrl,
      shareId: share.id,
      sharePercentage: decimalToNumber(share.sharePercentage) * 100,
      price: decimalToNumber(share.price),
      availableShares: share.availableShares,
      totalShares: share.totalShares,
    }))
  );
}

// 사용자 투자 내역 가져오기
async function getUserInvestments(userId: string) {
  const investments = await prisma.investments.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    take: 10,
  });

  return investments.map((inv) => ({
    id: inv.id,
    amount: decimalToNumber(inv.amount),
    dailyRate: decimalToNumber(inv.dailyRate),
    isActive: inv.isActive,
    createdAt: inv.createdAt.toISOString(),
    endDate: inv.endDate.toISOString(),
  }));
}

export default async function ProductsPage() {
  // 인증 확인
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  // 관리자는 관리자 페이지로 리다이렉트
  if (isAdminUser(user)) {
    redirect('/a0-admin');
  }

  // 언어 감지 함수
  const requestHeaders = await headers();
  const acceptLanguage = requestHeaders.get('accept-language') || '';
  const cookieHeader = requestHeaders.get('cookie') || '';

  const langCookieMatch = cookieHeader.match(/lang=([^;]+)/);
  const language = langCookieMatch && langCookieMatch[1] === 'en' ? 'en' : (acceptLanguage.includes('en') ? 'en' : 'ko');

  // 서버 사이드에서 직접 데이터 가져오기
  const [products, gameProducts, investments] = await Promise.all([
    getInvestmentProducts(language),
    getGameProducts(),
    getUserInvestments(user.id),
  ]);

  return (
    <ProductsClient
      user={{
        id: user.id,
        username: user.username || '',
        email: user.email || '',
        personalCoin: Number(user.personalCoin || 0),
      }}
      products={products}
      investments={investments}
      language={language}
      gameProducts={gameProducts}
    />
  );
}

