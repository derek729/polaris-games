'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { CompanyBrand } from '@/components/CompanyBrand';

export default function LoginPage() {
  const { t, language } = useI18n();
  const router = useRouter();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          // 입력값에 @가 있으면 email로, 없으면 username으로 처리
          ...(formData.username.trim().includes('@')
            ? { email: formData.username.trim() }
            : { username: formData.username.trim() }),
          password: formData.password,
        }),
      });

      const data = await res.json();

      if (data.ok) {
        // 일반 로그인에서는 항상 대시보드로 이동 (관리자는 이미 차단됨)
        router.push('/dashboard');
        router.refresh();
      } else {
        // 관리자 계정 에러인 경우 특별 처리
        if (data.errorCode === 'ADMIN_ACCOUNT') {
          setError('관리자 계정은 /a0-admin/login 페이지를 사용해주세요.');
        } else {
          setError(data.error || t.auth.loginFailed);
        }
      }
    } catch (err) {
      console.error('로그인 오류:', err);
      setError(t.errors.networkError);
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="relative flex min-h-screen w-full flex-col items-center justify-center p-4">
      {/* 상단 헤더: 회사 로고와 번역 탭을 한 줄로 배치 */}
      <div className="fixed top-4 left-4 right-4 z-20 flex items-center justify-between">
        <CompanyBrand
          wrapperClassName="drop-shadow-lg"
          size={48}
          textClassName="text-base sm:text-lg text-white drop-shadow-lg"
          imageClassName="drop-shadow-lg"
        />
        <LanguageSwitcher />
      </div>


      {/* 콘텐츠 영역 - 배경은 layout.tsx에서 처리 */}
      <div className="relative z-10 w-full max-w-md">

        <header className="mb-8 text-center pt-16">
          {/* Welcome Message */}
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight text-white mb-3 break-words drop-shadow-lg">
            {language === 'ko' ? 'MSUO 월렛에 오신 것을 환영합니다' : 'Welcome to MSUO Wallet'}
          </h1>
          <p className="text-sm sm:text-base text-slate-200 break-words drop-shadow-md">
            {language === 'ko'
              ? '계정에 로그인하거나 새로 만들어 시작하세요.'
              : 'Log in to your account or create a new one to get started.'}
          </p>
        </header>

        <main className="w-full space-y-6">
          {error && (
            <div className="p-3 bg-red-900/80 backdrop-blur-sm border border-red-500 rounded-lg text-red-100 text-sm shadow-lg">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-white drop-shadow-md"
                htmlFor="username"
              >
                {t.auth.usernameOrEmail}
              </label>
              <input
                className="h-12 w-full rounded-lg border-slate-300 bg-white/95 backdrop-blur-sm p-3 text-slate-900 placeholder:text-slate-500 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] shadow-lg"
                id="username"
                type="text"
                placeholder={t.auth.usernameOrEmail}
                value={formData.username}
                onChange={(e) =>
                  setFormData({ ...formData, username: e.target.value })
                }
                required
              />
            </div>

            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-white drop-shadow-md"
                htmlFor="password"
              >
                {t.auth.password}
              </label>
              <div className="relative">
                <input
                  className="h-12 w-full rounded-lg border-slate-300 bg-white/95 backdrop-blur-sm p-3 pr-10 text-slate-900 placeholder:text-slate-500 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] shadow-lg"
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) =>
                    setFormData({ ...formData, password: e.target.value })
                  }
                  required
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 dark:text-slate-500">
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="material-symbols-outlined cursor-pointer text-xl"
                  >
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </button>
                </div>
              </div>
            </div>

            <div className="text-right">
              <Link
                href="/forgot-password"
                className="text-sm font-medium text-[#3A4DFF] hover:underline"
              >
                {t.auth.forgotPassword}
              </Link>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 h-12 items-center justify-center rounded-lg bg-[#3A4DFF] px-4 text-base font-semibold text-white transition-colors hover:bg-[#3A4DFF]/90 focus:outline-none focus:ring-2 focus:ring-[#3A4DFF] focus:ring-offset-2 dark:focus:ring-offset-[#101922] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? t.auth.loggingIn : t.auth.loginButton}
              </button>
              <Link
                href="/register"
                className="flex-1 h-12 flex items-center justify-center rounded-lg bg-gray-700 hover:bg-gray-600 px-4 text-base font-semibold text-white transition-colors focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 dark:focus:ring-offset-[#101922]"
              >
                {t.auth.registerButton}
              </Link>
            </div>
          </form>
        </main>

        <footer className="mt-12 text-center">
          <p className="text-xs text-slate-300">
            <Link className="hover:underline text-white drop-shadow-md" href="/service-terms">
              {language === 'ko' ? '서비스 약관' : 'Terms of Service'}
            </Link>{' '}
            ·{' '}
            <Link className="hover:underline text-white drop-shadow-md" href="/privacy-policy">
              {language === 'ko' ? '개인정보처리방침' : 'Privacy Policy'}
            </Link>
          </p>
        </footer>
      </div>
    </div>
  );
}

