'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n/context';
import { openGameWindow } from '@/lib/games/openGameWindow';

export default function LoulletGame() {
  const router = useRouter();
  const { t } = useI18n();
  const popupHint = t.gamesPage.popupInstruction;
  const popupBlocked = t.gamesPage.popupBlocked;

  useEffect(() => {
    const gameWindow = openGameWindow('loullet');

    if (!gameWindow) {
      alert(popupBlocked);
      router.back();
      return;
    }

    const checkClosed = setInterval(() => {
      if (gameWindow.closed) {
        clearInterval(checkClosed);
        router.back();
      }
    }, 600);

    return () => {
      clearInterval(checkClosed);
      if (gameWindow && !gameWindow.closed) {
        gameWindow.close();
      }
    };
  }, [router, popupBlocked]);

  return (
    <div className="fixed inset-0 z-[9999] bg-[#0f172a] flex items-center justify-center">
      <div className="text-white text-center px-4">
        <p className="text-xl mb-4">{t.gamesPage.openingPopup}</p>
        <p className="text-sm text-gray-400">{popupHint}</p>
      </div>
    </div>
  );
}

