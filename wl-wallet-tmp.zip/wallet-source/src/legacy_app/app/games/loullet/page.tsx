import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import LoulletGame from './LoulletGame';

export const dynamic = 'force-dynamic';

export default async function LoulletPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  return <LoulletGame />;
}

