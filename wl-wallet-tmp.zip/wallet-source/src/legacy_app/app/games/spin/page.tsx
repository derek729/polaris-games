import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import SpinGame from './SpinGame';

export const dynamic = 'force-dynamic';

export default async function SpinPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  return <SpinGame />;
}

