import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import PackGame from './PackGame';

export const dynamic = 'force-dynamic';

export default async function PackPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  return <PackGame />;
}

