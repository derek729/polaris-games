'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { openGameWindow } from '@/lib/games/openGameWindow';
import { Play, Info, X, ExternalLink, Maximize2, Trophy, Sparkles, Gamepad2 } from 'lucide-react';

interface User {
  id: string;
  username: string | null;
  email: string | null;
  personalCoin?: number;
}

interface Game {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  descriptionEn: string;
  icon: string;
  href: string;
  color: string;
  backgroundImage: string;
  tags: {
    ko: string[];
    en: string[];
  };
  features: {
    ko: string[];
    en: string[];
  };
}

const games: Game[] = [
  {
    id: 'blackjack',
    name: '블랙잭',
    nameEn: 'Blackjack',
    description: '럭셔리 카지노 블랙잭 게임',
    descriptionEn: 'Luxury Casino Blackjack Game',
    icon: '🎰',
    href: '/games/blackjack',
    color: 'from-yellow-500 to-orange-600',
    backgroundImage: '/games/blackjack/preview.png',
    tags: {
      ko: ['카지노', '실시간 딜러', '고급 테이블'],
      en: ['Casino', 'Live Dealer', 'VIP Table'],
    },
    features: {
      ko: ['실시간 3D 딜러 연출', '멀티 핸드 & 사이드 베팅', 'VIP 사운드 & 조명 효과'],
      en: ['Real-time 3D dealer animation', 'Multi-hand & side bets', 'VIP-grade audio & lighting'],
    },
  },
  {
    id: 'baccarat',
    name: '럭셔리 바카라',
    nameEn: 'Luxury Baccarat',
    description: '럭셔리 바카라 - Royal Suite',
    descriptionEn: 'Luxury Baccarat - Royal Suite',
    icon: '🎴',
    href: '/games/baccarat',
    color: 'from-amber-500 to-yellow-600',
    backgroundImage: '/games/baccarat/preview.png',
    tags: {
      ko: ['카지노', '럭셔리', '베팅'],
      en: ['Casino', 'Luxury', 'Betting'],
    },
    features: {
      ko: ['플레이어/뱅커/타이 베팅', '실시간 카드 딜링', '럭셔리 카지노 경험'],
      en: ['Player/Banker/Tie betting', 'Real-time card dealing', 'Luxury casino experience'],
    },
  },
  {
    id: 'lotto',
    name: '파워볼 프로',
    nameEn: 'Powerball Pro',
    description: '파워볼 복권 게임',
    descriptionEn: 'Powerball Lottery Game',
    icon: '🎱',
    href: '/games/lotto',
    color: 'from-purple-500 to-pink-600',
    backgroundImage: '/games/lotto/preview.png',
    tags: {
      ko: ['복권', '실시간 추첨', '대박'],
      en: ['Lottery', 'Live Draw', 'Jackpot'],
    },
    features: {
      ko: ['실시간 추첨 애니메이션', '자동/수동 번호 선택 지원', '다중 티켓 관리'],
      en: ['Live draw animation', 'Manual & auto number selection', 'Manage multiple tickets with ease'],
    },
  },
  {
    id: 'loullet',
    name: '로얄 카지노 룰렛',
    nameEn: 'Royal Casino Roulette',
    description: 'GEMINI 로얄 카지노 룰렛',
    descriptionEn: 'GEMINI Royal Casino Roulette',
    icon: '🎲',
    href: '/games/loullet',
    color: 'from-red-500 to-rose-600',
    backgroundImage: '/games/loullet/preview.png',
    tags: {
      ko: ['룰렛', '베팅 전략', '클래식'],
      en: ['Roulette', 'Betting Strategy', 'Classic'],
    },
    features: {
      ko: ['유럽식/미국식 룰렛 선택', '자동 칩 스택 & 빠른 베팅', '슬로모션 볼 트래킹'],
      en: ['European & American wheel modes', 'Auto chip stacking & quick bets', 'Slow-motion ball tracking'],
    },
  },
  {
    id: 'neonslot',
    name: '네온 슬롯',
    nameEn: 'Neon Slots',
    description: '네온 슬롯머신 8라인 게임',
    descriptionEn: 'Neon Slots 8-Lines Game',
    icon: '🎰',
    href: '/games/neonslot',
    color: 'from-purple-600 to-pink-600',
    backgroundImage: '/games/neonslot/preview.png',
    tags: {
      ko: ['슬롯', '네온', '잭팟'],
      en: ['Slots', 'Neon', 'Jackpot'],
    },
    features: {
      ko: ['8라인 페이라인 시스템', '네온 테마 그래픽', '프리 스핀 & 보너스'],
      en: ['8-line payline system', 'Neon-themed graphics', 'Free spins & bonuses'],
    },
  },
];

export default function GamesClient({ users }: { users: User }) {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [introGame, setIntroGame] = useState<Game | null>(null);
  const [popupError, setPopupError] = useState('');
  const locale = 'ko'; // 한국어로 고정

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleGameStart = (game: Game) => {
    const popup = openGameWindow(game.id);
    if (!popup) {
      setPopupError('팝업 차단됨');
      return;
    }
    setPopupError('');
    setIntroGame(null);
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-gray-400 font-medium">Loading Experience...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen w-full bg-[#050505] overflow-x-hidden selection:bg-blue-500/30">
      {/* Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[800px] h-[800px] bg-blue-500/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-[800px] h-[800px] bg-purple-500/5 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12 md:py-20 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-16 md:mb-24">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-6">
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <span className="text-sm font-medium text-gray-300">Premium Casino Collection</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-200 to-gray-400 mb-6 tracking-tight">
            GAME LOUNGE
          </h1>
          <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
            최고의 몰입감을 선사하는 프리미엄 카지노 게임을 경험하세요.
            <br className="hidden md:block" />
            안전하고 공정한 환경에서 승리의 짜릿함을 즐기실 수 있습니다.
          </p>
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {games.map((game) => (
            <button
              key={game.id}
              onClick={() => {
                setIntroGame(game);
                setPopupError('');
              }}
              className="group relative h-full outline-none text-left"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-br from-blue-500 to-purple-600 rounded-[2rem] opacity-0 group-hover:opacity-50 blur transition duration-500" />
              <div className="relative h-full bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-[1.9rem] overflow-hidden transition-transform duration-500 group-hover:-translate-y-2">
                {/* Image Section */}
                <div className="relative h-64 overflow-hidden">
                  <div className={`absolute inset-0 bg-gradient-to-br ${game.color} opacity-20 group-hover:opacity-30 transition-opacity duration-500 z-10`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent z-20" />
                  
                  {/* Image with fallback */}
                  <img
                    src={`/games/${game.id}/preview.png`}
                    alt={game.name}
                    className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      const fallback = target.parentElement?.querySelector('.icon-fallback');
                      if (fallback) (fallback as HTMLElement).style.display = 'flex';
                    }}
                    onLoad={(e) => {
                      const fallback = (e.target as HTMLElement).parentElement?.querySelector('.icon-fallback');
                      if (fallback) (fallback as HTMLElement).style.display = 'none';
                    }}
                  />
                  
                  {/* Fallback Icon */}
                  <div className="icon-fallback absolute inset-0 items-center justify-center hidden bg-gray-800">
                    <span className="text-6xl">{game.icon}</span>
                  </div>

                  {/* Floating Badge */}
                  <div className="absolute top-4 right-4 z-30 w-12 h-12 rounded-2xl bg-black/40 backdrop-blur-md border border-white/20 flex items-center justify-center text-2xl shadow-lg group-hover:scale-110 transition-transform duration-300">
                    {game.icon}
                  </div>
                </div>

                {/* Content Section */}
                <div className="p-6 md:p-8">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {game.tags[locale].slice(0, 2).map((tag) => (
                      <span key={tag} className="px-3 py-1 rounded-lg bg-white/5 border border-white/5 text-xs font-medium text-gray-300 group-hover:text-white transition-colors">
                        {tag}
                      </span>
                    ))}
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">
                    {game.name}
                  </h3>
                  
                  <p className="text-gray-400 text-sm line-clamp-2 mb-8 group-hover:text-gray-300 transition-colors">
                    {game.description}
                  </p>

                  <div className="flex items-center justify-between mt-auto">
                    <div className="flex items-center gap-2 text-sm font-bold text-white group-hover:text-blue-400 transition-colors">
                      <span className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-blue-500/20 transition-colors">
                        <Play className="w-3 h-3 fill-current" />
                      </span>
                      플레이하기
                    </div>
                    <Trophy className="w-5 h-5 text-gray-600 group-hover:text-yellow-500 transition-colors" />
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Intro Modal */}
      {introGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center px-4" onClick={() => setIntroGame(null)}>
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md animate-in fade-in duration-300" />
          
          <div 
            className="relative w-full max-w-5xl bg-[#0a0a0a] rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={() => {
                setIntroGame(null);
                setPopupError('');
              }}
              className="absolute top-4 right-4 z-50 p-2 rounded-full bg-black/50 text-white/70 hover:text-white hover:bg-black/70 backdrop-blur-sm transition-all"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="grid lg:grid-cols-[1.2fr_0.8fr] h-full lg:min-h-[600px]">
              {/* Left: Visual */}
              <div className="relative min-h-[300px] lg:h-full bg-gray-900 overflow-hidden group">
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 group-hover:scale-105"
                  style={{ backgroundImage: `url(${introGame.backgroundImage})` }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/50 to-transparent lg:bg-gradient-to-r lg:from-transparent lg:via-[#0a0a0a]/20 lg:to-[#0a0a0a]" />
                
                <div className="absolute bottom-0 left-0 p-8 lg:p-12 w-full">
                  <div className="w-20 h-20 rounded-3xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-4xl mb-6 shadow-xl">
                    {introGame.icon}
                  </div>
                  <h2 className="text-4xl lg:text-5xl font-black text-white mb-3">
                    {introGame.name}
                  </h2>
                  <p className="text-lg text-gray-300 font-light">
                    {introGame.nameEn}
                  </p>
                </div>
              </div>

              {/* Right: Info */}
              <div className="flex flex-col p-8 lg:p-12 bg-[#0a0a0a]">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-6">
                    <Gamepad2 className="w-5 h-5 text-blue-500" />
                    <span className="text-sm font-bold tracking-wider text-blue-500 uppercase">Game Info</span>
                  </div>

                  <p className="text-xl text-gray-200 leading-relaxed mb-8">
                    {introGame.description}
                  </p>

                  <div className="space-y-8">
                    <div>
                      <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-4">Features</h4>
                      <ul className="grid gap-3">
                        {(introGame.features[locale] || introGame.features.en).map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-3 text-gray-300">
                            <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-blue-500" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-4">Tags</h4>
                      <div className="flex flex-wrap gap-2">
                        {(introGame.tags[locale] || introGame.tags.en).map((tag) => (
                          <span key={tag} className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-sm text-gray-400">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 lg:mt-auto pt-8 border-t border-white/10">
                  {popupError && (
                    <div className="mb-4 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-2">
                      <Info className="w-4 h-4" />
                      {popupError}
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      onClick={() => handleGameStart(introGame)}
                      className="flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-blue-500/25"
                    >
                      <Maximize2 className="w-5 h-5" />
                      전체 화면으로 시작
                    </button>
                    <Link
                      href={introGame.href}
                      className="flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold transition-all hover:-translate-y-1"
                    >
                      <ExternalLink className="w-5 h-5" />
                      새 창으로 열기
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
