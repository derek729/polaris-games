import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import NeonSlotGame from './NeonSlotGame';

export const dynamic = 'force-dynamic';

export default async function NeonSlotPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  return <NeonSlotGame />;
}

