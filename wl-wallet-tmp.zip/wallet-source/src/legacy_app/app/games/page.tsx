import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import GamesClient from './GamesClient';

export const dynamic = 'force-dynamic';

export default async function GamesPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  return <GamesClient user={{
    id: user.id,
    username: user.username,
    email: user.email,
    personalCoin: Number(user.personalCoin || 0),
  }} />;
}

