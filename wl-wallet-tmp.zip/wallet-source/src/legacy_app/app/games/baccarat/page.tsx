import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import BaccaratGame from './BaccaratGame';

export const dynamic = 'force-dynamic';

export default async function BaccaratPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  return <BaccaratGame />;
}

