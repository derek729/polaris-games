import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import LottoGame from './LottoGame';

export const dynamic = 'force-dynamic';

export default async function LottoPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  return <LottoGame />;
}

