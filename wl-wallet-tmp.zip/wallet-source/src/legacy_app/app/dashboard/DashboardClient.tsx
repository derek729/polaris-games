'use client';

import { useEffect, useState, useMemo, memo, useCallback } from 'react';
import React from 'react';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import {
  TrendingUp,
  DollarSign,
  Users,
  Activity,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  User,
  CreditCard,
  Target,
  PieChart,
  Award,
  BarChart3,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import WithdrawalModal from '@/components/dashboard/WithdrawalModal';
import InvestmentModal from '@/components/dashboard/InvestmentModal';
import TransferModal from '@/components/dashboard/TransferModal';
import CoinSwapWidget from '@/components/dashboard/CoinSwapWidget';

type RewardType = 'DAILY' | 'REFERRAL' | 'MATCHING' | 'RANK' | 'TEAM';

const Tree = dynamic(() => import('react-d3-tree').then((mod) => mod.Tree), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center text-slate-400">조직도 로딩 중...</div>
  ),
});

type LineStat = {
  label: 'A라인' | 'B라인' | 'C라인';
  current: number;
  target: number;
};

type RewardLogItem = {
  id: string;
  date: string;
  type: RewardType;
  amount: number;
  description: string | null;
};

type OrgTreeNode = {
  name: string;
  attributes: {
    Rank: string;
    투자: string;
  };
  children?: OrgTreeNode[];
};

type DashboardData = {
  users: {
    id: string;
    username: string | null;
    rank: number;
    rankName: string;
    personalCoin: number;
    totalInvestment: number;
    line1Sales: number;
    line2Sales: number;
    line3Sales: number;
    line4Sales: number;
    line5Sales: number;
    accumulatedSales: number;
    updatedAt: Date;
  };
  lineStats: LineStat[];
  reward_logs: RewardLogItem[];
  orgTree: OrgTreeNode | null;
  totalAssets: number;
  todayExpectedReward: number;
};

type DashboardClientProps = {
  data: DashboardData;
};

// NKT 포맷팅 (리워드 표시용)
const currency = (amount: number) => {
  return `${amount.toLocaleString('ko-KR', {
    maximumFractionDigits: 2,
  })} NKT`;
};

const coinFormat = new Intl.NumberFormat('ko-KR', {
  maximumFractionDigits: 2,
});

const REWARD_TYPE_LABELS: Record<RewardType, string> = {
  DAILY: '데일리',
  REFERRAL: '추천',
  MATCHING: '매칭',
  RANK: '랭크',
  TEAM: '팀',
};

const REWARD_TYPE_COLORS: Record<RewardType, string> = {
  DAILY: 'text-blue-400',
  REFERRAL: 'text-green-400',
  MATCHING: 'text-purple-400',
  RANK: 'text-yellow-400',
  TEAM: 'text-pink-400',
};

type WithdrawalItem = {
  id: string;
  amount: number;
  address: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  requestedAt: string;
  processedAt: string | null;
  rejectionReason?: string | null;
};

type TransferItem = {
  id: string;
  type: 'sent' | 'received';
  sender: { username: string | null; email: string | null };
  receiver: { username: string | null; email: string | null };
  amount: number;
  fee: number;
  transferredAt: string;
};

type TabType = 'assets' | 'investments' | 'transfers' | 'rewards' | 'organization' | 'rank';

const DashboardClient = memo(function DashboardClient({ data }: DashboardClientProps) {
  const [activeTab, setActiveTab] = useState<TabType>('assets');
  const [filter, setFilter] = useState<'ALL' | RewardType>('ALL');
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);
  const [isInvestmentModalOpen, setIsInvestmentModalOpen] = useState(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [withdrawals, setWithdrawals] = useState<WithdrawalItem[]>([]);
  const [transfers, setTransfers] = useState<TransferItem[]>([]);
  const [loadingWithdrawals, setLoadingWithdrawals] = useState(false);
  const [loadingTransfers, setLoadingTransfers] = useState(false);
  const [transferFilter, setTransferFilter] = useState<'all' | 'sent' | 'received'>('all');

  const filteredLogs = useMemo(() => {
    if (filter === 'ALL') return data.rewardLogs;
    return data.reward_logs.filter((log) => log.type === filter);
  }, [filter, data.rewardLogs]);

  // 차트 데이터 준비
  const rewardChartData = useMemo(() => {
    const dailyData: Record<string, number> = {};
    data.reward_logs.forEach((log) => {
      if (!dailyData[log.date]) {
        dailyData[log.date] = 0;
      }
      dailyData[log.date] += log.amount;
    });
    return Object.entries(dailyData)
      .map(([date, amount]) => ({ date, amount }))
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-30); // 최근 30일
  }, [data.rewardLogs]);

  const rewardTypeDistribution = useMemo(() => {
    const distribution: Record<string, number> = {};
    data.reward_logs.forEach((log) => {
      const type = REWARD_TYPE_LABELS[log.type];
      distribution[type] = (distribution[type] || 0) + log.amount;
    });
    return Object.entries(distribution).map(([name, value]) => ({ name, value }));
  }, [data.rewardLogs]);

  const COLORS = ['#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444'];

  // 출금 내역 불러오기
  useEffect(() => {
    const fetchWithdrawals = async () => {
      setLoadingWithdrawals(true);
      try {
        const res = await fetch(`/api/user/withdraw?userId=${data.users.id}`);
        const result = await res.json();
        if (result.ok) {
          setWithdrawals(result.data);
        }
      } catch (error) {
        console.error('출금 내역 조회 실패:', error);
      } finally {
        setLoadingWithdrawals(false);
      }
    };

    fetchWithdrawals();
  }, [data.users.id]);

  // 이체 내역 불러오기
  useEffect(() => {
    const fetchTransfers = async () => {
      setLoadingTransfers(true);
      try {
        const res = await fetch(`/api/user/transfer?type=${transferFilter}`);
        const result = await res.json();
        if (result.ok) {
          setTransfers(result.data);
        }
      } catch (error) {
        console.error('이체 내역 조회 실패:', error);
      } finally {
        setLoadingTransfers(false);
      }
    };

    fetchTransfers();
  }, [transferFilter]);

  const orgTreeData = data.orgTree ? [data.orgTree] : [];

  // 커스텀 노드 렌더링 함수 (카드형 디자인)
  const renderCustomNodeElement = ({ nodeDatum, toggleNode }: any) => {
    const rank = nodeDatum.attributes?.Rank || 'Unranked';
    const investment = nodeDatum.attributes?.투자 || '0';
    const investmentNum = parseFloat(investment.replace(/[^0-9.]/g, '')) || 0;
    const isHighRank = rank.includes('2') || rank.includes('3') || rank.includes('4') || rank.includes('5');

    // 카드 크기
    const cardWidth = 192; // w-48 = 192px
    const cardHeight = 180;

    // 노드 중심점 기준으로 카드 위치 계산 (중앙 정렬)
    // nodeDatum.x, y가 undefined일 수 있으므로 기본값 설정
    const nodeX = typeof nodeDatum.x === 'number' ? nodeDatum.x : 0;
    const nodeY = typeof nodeDatum.y === 'number' ? nodeDatum.y : 0;
    const x = nodeX - cardWidth / 2;
    const y = nodeY - cardHeight / 2;

    // NaN 체크
    if (isNaN(x) || isNaN(y)) {
      return null; // 렌더링하지 않음
    }

    return (
      <g>
        {/* HTML 카드 렌더링 */}
        <foreignObject x={x} y={y} width={cardWidth} height={cardHeight}>
          <div
            onClick={toggleNode}
            className={`flex flex-col items-center bg-gradient-to-br from-slate-800 to-slate-900 border-2 rounded-xl p-3 shadow-2xl w-full h-full cursor-pointer transition-all duration-200 hover:scale-105 ${isHighRank
              ? 'border-purple-500/50 hover:border-purple-400 shadow-purple-500/20'
              : 'border-slate-600 hover:border-slate-500'
              }`}
          >
            {/* 사람 아이콘 */}
            <div
              className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${isHighRank
                ? 'bg-gradient-to-br from-purple-500/30 to-pink-500/30 border-2 border-purple-400/50'
                : 'bg-slate-700 border border-slate-600'
                }`}
            >
              <User className="text-white w-6 h-6" />
            </div>

            {/* 사용자명 */}
            <h3 className="text-white font-bold text-sm mb-1 truncate w-full text-center">
              {nodeDatum.name || 'Unknown'}
            </h3>

            {/* 등급 뱃지 */}
            <span
              className={`text-xs font-semibold px-2.5 py-1 rounded-full mb-2 ${isHighRank
                ? 'text-purple-200 bg-purple-500/20 border border-purple-400/30'
                : 'text-slate-300 bg-slate-700/50 border border-slate-600/50'
                }`}
            >
              {rank}
            </span>

            {/* 투자금 정보 */}
            <div className="w-full text-center">
              <p className="text-xs text-slate-400 mb-0.5">총 투자금</p>
              <p className="text-sm font-semibold text-emerald-400">
                ${investmentNum.toLocaleString()}
              </p>
            </div>
          </div>
        </foreignObject>
      </g>
    );
  };

  const handleLogout = async () => {
    if (confirm('로그아웃 하시겠습니까?')) {
      try {
        await fetch('/api/auth/logout', { method: 'POST' });
        window.location.href = '/login';
      } catch (error) {
        console.error('로그아웃 실패:', error);
      }
    }
  };

  const tabs: { id: TabType; label: string; icon: string }[] = [
    { id: 'assets', label: '자산 현황', icon: '💰' },
    { id: 'investments', label: '투자 관리', icon: '📈' },
    { id: 'transfers', label: '이체/출금', icon: '💸' },
    { id: 'rewards', label: '수익 내역', icon: '🎁' },
    { id: 'organization', label: '조직도', icon: '🌳' },
    { id: 'rank', label: '랭크 현황', icon: '🏆' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="w-full space-y-6 px-4 py-6 sm:px-6 lg:px-8">
        {/* 헤더 */}
        <div className="relative overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-br from-slate-900/60 via-slate-800/40 to-slate-900/60 p-6 shadow-2xl backdrop-blur-sm">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 via-purple-500/5 to-pink-500/5" />
          <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-white via-indigo-200 to-purple-200 bg-clip-text text-transparent">
                대시보드
              </h1>
              <p className="mt-2 text-base text-slate-300">
                {data.users.username || '사용자'}님의 통합 관리 시스템
              </p>
            </div>
            <div className="flex items-center gap-3">
              <a
                href="/a0-admin"
                className="group relative overflow-hidden rounded-xl bg-gradient-to-r from-indigo-500/20 to-purple-500/20 border border-indigo-500/30 px-5 py-2.5 text-sm font-semibold text-indigo-300 transition-all hover:scale-105 hover:bg-indigo-500/30 hover:shadow-lg hover:shadow-indigo-500/50"
              >
                <span className="relative z-10">관리자</span>
              </a>
              <button
                onClick={handleLogout}
                className="group relative overflow-hidden rounded-xl bg-gradient-to-r from-red-500/20 to-rose-500/20 border border-red-500/30 px-5 py-2.5 text-sm font-semibold text-red-300 transition-all hover:scale-105 hover:bg-red-500/30 hover:shadow-lg hover:shadow-red-500/50"
              >
                <span className="relative z-10">로그아웃</span>
              </button>
            </div>
          </div>
        </div>

        {/* 탭 메뉴 */}
        <div className="sticky top-0 z-10 rounded-2xl border border-white/5 bg-slate-900/60 p-2 shadow-xl backdrop-blur-md">
          <div className="flex flex-wrap gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`group relative flex items-center gap-2 overflow-hidden rounded-xl px-5 py-3 text-sm font-semibold transition-all duration-300 ${activeTab === tab.id
                  ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white shadow-lg shadow-indigo-500/50 scale-105'
                  : 'bg-slate-800/50 text-slate-300 hover:bg-slate-700/50 hover:text-white hover:scale-105'
                  }`}
              >
                <span className="relative z-10 text-base">{tab.icon}</span>
                <span className="relative z-10">{tab.label}</span>
                {activeTab === tab.id && (
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/20 to-purple-600/20 animate-pulse" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* 자산 현황 탭 */}
        {activeTab === 'assets' && (
          <div className="space-y-6">
            {/* 요약 카드 섹션 */}
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {/* 등급 뱃지 카드 */}
              <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600/20 via-purple-600/20 to-fuchsia-600/20 p-6 backdrop-blur-sm transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-violet-500/20">
                <div className="absolute inset-0 bg-gradient-to-br from-violet-500/10 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="relative">
                  <p className="text-xs font-medium uppercase tracking-wider text-violet-300/80">현재 등급</p>
                  <div className="mt-3 flex items-center gap-3">
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-lg shadow-violet-500/50">
                      <span className="text-xl font-bold text-white">{data.users.rank || 0}</span>
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white">{data.users.rankName}</h3>
                      <p className="text-xs text-slate-400">
                        {new Date(data.users.updatedAt).toLocaleDateString('ko-KR')} 업데이트
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* 총 자산 카드 */}
              <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600/20 via-teal-600/20 to-cyan-600/20 p-6 backdrop-blur-sm transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-emerald-500/20">
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="relative">
                  <p className="text-xs font-medium uppercase tracking-wider text-emerald-300/80">총 자산</p>
                  <p className="mt-3 text-3xl font-bold text-white">
                    {coinFormat.format(data.totalAssets)} <span className="text-lg text-emerald-400">MSUO</span>
                  </p>
                  <div className="mt-4 grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setIsInvestmentModalOpen(true)}
                      className="rounded-lg bg-blue-500/20 border border-blue-500/30 px-2 py-2 text-xs font-semibold text-blue-300 transition hover:bg-blue-500/30"
                    >
                      💰 투자
                    </button>
                    <button
                      onClick={() => setIsTransferModalOpen(true)}
                      className="rounded-lg bg-purple-500/20 border border-purple-500/30 px-2 py-2 text-xs font-semibold text-purple-300 transition hover:bg-purple-500/30"
                    >
                      🔄 이체
                    </button>
                    <button
                      onClick={() => setIsWithdrawalModalOpen(true)}
                      className="rounded-lg bg-emerald-500/20 border border-emerald-500/30 px-2 py-2 text-xs font-semibold text-emerald-300 transition hover:bg-emerald-500/30"
                    >
                      💸 출금
                    </button>
                  </div>
                </div>
              </div>

              {/* 오늘 예상 수익 카드 */}
              <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-600/20 via-orange-600/20 to-red-600/20 p-6 backdrop-blur-sm transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-amber-500/20">
                <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="relative">
                  <p className="text-xs font-medium uppercase tracking-wider text-amber-300/80">오늘 예상 수익</p>
                  <p className="mt-3 text-3xl font-bold text-white">
                    +{coinFormat.format(data.todayExpectedReward)}{' '}
                    <span className="text-lg text-amber-400">MSUO</span>
                  </p>
                  <p className="mt-1 flex items-center gap-1 text-sm text-emerald-400">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                    활성 투자 기준
                  </p>
                </div>
              </div>
            </div>

            {/* 코인 교환 위젯 */}
            <div className="mb-6">
              <CoinSwapWidget
                userBalance={data.users.personalCoin}
                onSwapSuccess={() => {
                  // 교환 성공 시 페이지 새로고침
                  window.location.reload();
                }}
              />
            </div>

            {/* 자산 추이 차트 */}
            <div className="grid gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
                <div className="mb-4 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-blue-400" />
                  <h3 className="text-lg font-bold text-white">수익 추이</h3>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={rewardChartData}>
                    <defs>
                      <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" stroke="#9CA3AF" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                    <YAxis stroke="#9CA3AF" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1E293B',
                        border: '1px solid #334155',
                        borderRadius: '8px',
                        color: '#F1F5F9',
                      }}
                      formatter={(value: number) => [`${coinFormat.format(value)} MSUO`, '수익']}
                    />
                    <Area
                      type="monotone"
                      dataKey="amount"
                      stroke="#3B82F6"
                      fillOpacity={1}
                      fill="url(#colorAmount)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
                <div className="mb-4 flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-purple-400" />
                  <h3 className="text-lg font-bold text-white">수익 유형 분포</h3>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={rewardTypeDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {rewardTypeDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1E293B',
                        border: '1px solid #334155',
                        borderRadius: '8px',
                        color: '#F1F5F9',
                      }}
                      formatter={(value: number) => `${coinFormat.format(value)} MSUO`}
                    />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* 랭크 현황 탭 */}
        {activeTab === 'rank' && (
          <div className="space-y-6">
            {/* 랭크 정보 카드 */}
            <div className="grid gap-6 lg:grid-cols-3">
              <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600/20 via-purple-600/20 to-fuchsia-600/20 p-6 backdrop-blur-sm transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-violet-500/20">
                <div className="absolute inset-0 bg-gradient-to-br from-violet-500/10 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="relative">
                  <div className="mb-2 flex items-center gap-2">
                    <Award className="h-5 w-5 text-violet-400" />
                    <p className="text-xs font-medium uppercase tracking-wider text-violet-300/80">현재 등급</p>
                  </div>
                  <div className="mt-3 flex items-center gap-3">
                    <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 shadow-lg shadow-violet-500/50">
                      <span className="text-2xl font-bold text-white">{data.users.rank || 0}</span>
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white">{data.users.rankName}</h3>
                      <p className="text-xs text-slate-400">
                        {new Date(data.users.updatedAt).toLocaleDateString('ko-KR')} 업데이트
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600/20 via-teal-600/20 to-cyan-600/20 p-6 backdrop-blur-sm transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-emerald-500/20">
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="relative">
                  <div className="mb-2 flex items-center gap-2">
                    <Wallet className="h-5 w-5 text-emerald-400" />
                    <p className="text-xs font-medium uppercase tracking-wider text-emerald-300/80">총 매출</p>
                  </div>
                  <p className="mt-3 text-3xl font-bold text-white">
                    {coinFormat.format((data.users.line1Sales + data.users.line2Sales + data.users.line3Sales) / 1_000)}K
                  </p>
                  <p className="mt-1 text-sm text-slate-400">A/B/C 라인 합계</p>
                </div>
              </div>

              <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-600/20 via-indigo-600/20 to-purple-600/20 p-6 backdrop-blur-sm transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-blue-500/20">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                <div className="relative">
                  <div className="mb-2 flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-blue-400" />
                    <p className="text-xs font-medium uppercase tracking-wider text-blue-300/80">누적 매출</p>
                  </div>
                  <p className="mt-3 text-3xl font-bold text-white">
                    {coinFormat.format(data.users.accumulatedSales / 1_000)}K
                  </p>
                  <p className="mt-1 text-sm text-slate-400">전체 누적 매출액</p>
                </div>
              </div>
            </div>

            {/* 승급 진행 현황 */}
            <section className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-white">승급 진행 현황</h2>
                <p className="mt-1 text-sm text-slate-400">다음 등급까지 남은 매출 목표</p>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {data.lineStats.map((line, index) => {
                  const progress = Math.min(100, Math.round((line.current / line.target) * 100));
                  const remaining = Math.max(line.target - line.current, 0);
                  const colors = [
                    'from-blue-500 via-cyan-500 to-teal-500',
                    'from-purple-500 via-pink-500 to-rose-500',
                    'from-amber-500 via-orange-500 to-red-500',
                  ];
                  const bgColors = [
                    'bg-blue-500/10',
                    'bg-purple-500/10',
                    'bg-amber-500/10',
                  ];

                  return (
                    <div
                      key={line.label}
                      className={`relative overflow-hidden rounded-xl border border-white/5 ${bgColors[index]} p-5 backdrop-blur-sm`}
                    >
                      <div className="relative z-10">
                        <div className="mb-3 flex items-center justify-between">
                          <span className="text-sm font-semibold uppercase tracking-wider text-slate-300">
                            {line.label}
                          </span>
                          <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-bold text-white">
                            {progress}%
                          </span>
                        </div>
                        <div className="mb-2 text-2xl font-bold text-white">
                          {coinFormat.format(line.current / 1_000)}K
                        </div>
                        <div className="mb-4 h-3 w-full overflow-hidden rounded-full bg-slate-800/50">
                          <div
                            className={`h-full rounded-full bg-gradient-to-r ${colors[index]} shadow-lg transition-all duration-500`}
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">목표</span>
                          <span className="font-semibold text-slate-300">
                            {coinFormat.format(line.target / 1_000)}K
                          </span>
                        </div>
                        <div className="mt-2 text-xs text-slate-500">
                          남은 금액: <span className="font-semibold text-white">{coinFormat.format(remaining / 1_000)}K</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* 라인별 매출 차트 */}
            <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
              <div className="mb-4 flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-indigo-400" />
                <h3 className="text-lg font-bold text-white">라인별 매출 현황</h3>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={data.lineStats.map((line) => ({
                    name: line.label,
                    현재: line.current / 1_000,
                    목표: line.target / 1_000,
                  }))}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="name" stroke="#9CA3AF" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                  <YAxis stroke="#9CA3AF" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1E293B',
                      border: '1px solid #334155',
                      borderRadius: '8px',
                      color: '#F1F5F9',
                    }}
                    formatter={(value: number) => `${coinFormat.format(value)}K`}
                  />
                  <Legend />
                  <Bar dataKey="현재" fill="#3B82F6" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="목표" fill="#8B5CF6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* 조직도 탭 */}
        {activeTab === 'organization' && (
          <div className="space-y-6">
            <section className="rounded-2xl border border-white/5 bg-slate-900/40 p-4 shadow-xl backdrop-blur-sm sm:p-6">
              <div className="mb-4 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
                <div>
                  <h2 className="text-2xl font-bold text-white">내 조직도</h2>
                  <p className="mt-1 text-sm text-slate-400">하위 팀 구조 시각화</p>
                </div>
                <span className="rounded-full bg-white/5 px-4 py-2 text-xs font-medium text-slate-400">
                  상위 3대까지 표시
                </span>
              </div>
              <div className="h-[400px] rounded-xl border border-white/5 bg-slate-950/70 p-4 sm:h-[500px]">
                {orgTreeData.length > 0 ? (
                  <Tree
                    data={orgTreeData}
                    orientation="vertical"
                    translate={{ x: typeof window !== 'undefined' ? window.innerWidth / 2 : 400, y: 60 }}
                    zoomable
                    enableLegacyTransitions
                    pathFunc="step"
                    renderCustomNodeElement={renderCustomNodeElement}
                    nodeSize={{ x: 200, y: 220 }}
                    separation={{ siblings: 1.5, nonSiblings: 1.5 }}
                  />
                ) : (
                  <div className="flex h-full items-center justify-center text-slate-500">
                    <div className="text-center">
                      <svg
                        className="mx-auto h-12 w-12 text-slate-600"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                        />
                      </svg>
                      <p className="mt-2 text-sm">하위 조직도가 없습니다</p>
                    </div>
                  </div>
                )}
              </div>
            </section>
          </div>
        )}

        {/* 수익 내역 탭 */}
        {activeTab === 'rewards' && (
          <div className="space-y-6">
            {/* 차트 섹션 */}
            <div className="grid gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
                <div className="mb-4 flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-emerald-400" />
                  <h3 className="text-lg font-bold text-white">일별 수익 추이</h3>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={rewardChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" stroke="#9CA3AF" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                    <YAxis stroke="#9CA3AF" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1E293B',
                        border: '1px solid #334155',
                        borderRadius: '8px',
                        color: '#F1F5F9',
                      }}
                      formatter={(value: number) => [`${coinFormat.format(value)} MSUO`, '수익']}
                    />
                    <Bar dataKey="amount" fill="#10B981" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
                <div className="mb-4 flex items-center gap-2">
                  <PieChart className="h-5 w-5 text-purple-400" />
                  <h3 className="text-lg font-bold text-white">수익 유형별 분포</h3>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={rewardTypeDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {rewardTypeDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1E293B',
                        border: '1px solid #334155',
                        borderRadius: '8px',
                        color: '#F1F5F9',
                      }}
                      formatter={(value: number) => `${coinFormat.format(value)} MSUO`}
                    />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* 수익 내역 테이블 */}
            <section className="rounded-2xl border border-white/5 bg-slate-900/40 p-4 shadow-xl backdrop-blur-sm sm:p-6">
              <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-white">수익 내역</h2>
                  <p className="mt-1 text-sm text-slate-400">최근 30일 리워드 로그</p>
                </div>
                <div className="flex flex-wrap items-center gap-2 rounded-xl border border-white/5 bg-slate-950/60 p-1">
                  {(['ALL', ...Object.keys(REWARD_TYPE_LABELS)] as const).map((option) => (
                    <button
                      key={option}
                      className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-all sm:px-4 sm:text-sm ${filter === option
                        ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white shadow-lg shadow-indigo-500/50'
                        : 'text-slate-400 hover:bg-white/5 hover:text-white'
                        }`}
                      onClick={() => setFilter(option === 'ALL' ? 'ALL' : (option as RewardType))}
                    >
                      {option === 'ALL' ? '전체' : REWARD_TYPE_LABELS[option as RewardType]}
                    </button>
                  ))}
                </div>
              </div>
              <div className="overflow-hidden rounded-xl border border-white/5 bg-slate-950/70">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-slate-800/60">
                    <thead className="bg-slate-900/50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          날짜
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          타입
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          설명
                        </th>
                        <th className="px-4 py-3 text-right text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          금액
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/40 bg-slate-950/50">
                      {filteredLogs.length > 0 ? (
                        filteredLogs.map((log) => (
                          <tr
                            key={log.id}
                            className="transition-colors hover:bg-white/5"
                          >
                            <td className="whitespace-nowrap px-4 py-4 text-sm text-slate-300 sm:px-6">
                              {log.date}
                            </td>
                            <td className="whitespace-nowrap px-4 py-4 sm:px-6">
                              <span
                                className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${REWARD_TYPE_COLORS[log.type]
                                  } bg-white/5`}
                              >
                                {REWARD_TYPE_LABELS[log.type]}
                              </span>
                            </td>
                            <td className="px-4 py-4 text-sm text-slate-400 sm:px-6">
                              {log.description || '-'}
                            </td>
                            <td className="whitespace-nowrap px-4 py-4 text-right text-sm font-bold text-emerald-400 sm:px-6">
                              +{coinFormat.format(log.amount)} MSUO
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={4} className="px-6 py-12 text-center">
                            <div className="mx-auto max-w-sm">
                              <svg
                                className="mx-auto h-12 w-12 text-slate-600"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                />
                              </svg>
                              <p className="mt-4 text-sm text-slate-500">
                                해당 타입의 리워드 내역이 없습니다
                              </p>
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* 이체/출금 탭 */}
        {activeTab === 'transfers' && (
          <div className="space-y-6">
            {/* 이체/출금 액션 카드 */}
            <section className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
              <h2 className="mb-4 text-2xl font-bold text-white">이체 및 출금</h2>
              <div className="grid gap-4 sm:grid-cols-2">
                <button
                  onClick={() => setIsTransferModalOpen(true)}
                  className="group relative overflow-hidden rounded-xl bg-gradient-to-br from-purple-600/20 via-pink-600/20 to-rose-600/20 p-6 backdrop-blur-sm transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-purple-500/20"
                >
                  <div className="relative z-10">
                    <div className="mb-2 text-2xl">🔄</div>
                    <h3 className="text-lg font-bold text-white">코인 이체</h3>
                    <p className="mt-1 text-sm text-slate-400">다른 회원에게 코인 전송</p>
                  </div>
                </button>
                <button
                  onClick={() => setIsWithdrawalModalOpen(true)}
                  className="group relative overflow-hidden rounded-xl bg-gradient-to-br from-emerald-600/20 via-teal-600/20 to-cyan-600/20 p-6 backdrop-blur-sm transition-all hover:scale-[1.02] hover:shadow-2xl hover:shadow-emerald-500/20"
                >
                  <div className="relative z-10">
                    <div className="mb-2 text-2xl">💸</div>
                    <h3 className="text-lg font-bold text-white">출금 신청</h3>
                    <p className="mt-1 text-sm text-slate-400">지갑으로 코인 출금</p>
                  </div>
                </button>
              </div>
            </section>

            {/* 이체 내역 섹션 */}
            <section className="rounded-2xl border border-white/5 bg-slate-900/40 p-4 shadow-xl backdrop-blur-sm sm:p-6">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-white">이체 내역</h2>
                <p className="mt-1 text-sm text-slate-400">최근 이체 거래 내역</p>
              </div>
              <div className="mb-4 flex gap-2 rounded-xl border border-white/5 bg-slate-950/60 p-1">
                {(['all', 'sent', 'received'] as const).map((type) => (
                  <button
                    key={type}
                    onClick={() => setTransferFilter(type)}
                    className={`flex-1 rounded-lg px-3 py-2 text-sm font-medium transition-all ${transferFilter === type
                      ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white shadow-lg shadow-indigo-500/50'
                      : 'text-slate-400 hover:bg-white/5 hover:text-white'
                      }`}
                  >
                    {type === 'all' ? '전체' : type === 'sent' ? '보낸 내역' : '받은 내역'}
                  </button>
                ))}
              </div>
              <div className="overflow-hidden rounded-xl border border-white/5 bg-slate-950/70">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-slate-800/60">
                    <thead className="bg-slate-900/50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          날짜
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          타입
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          상대방
                        </th>
                        <th className="px-4 py-3 text-right text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          금액
                        </th>
                        <th className="px-4 py-3 text-right text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          수수료
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/40 bg-slate-950/50">
                      {loadingTransfers ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center">
                            <p className="text-sm text-slate-500">로딩 중...</p>
                          </td>
                        </tr>
                      ) : transfers.length > 0 ? (
                        transfers.map((transfer) => (
                          <tr key={transfer.id} className="transition-colors hover:bg-white/5">
                            <td className="whitespace-nowrap px-4 py-4 text-sm text-slate-300 sm:px-6">
                              {new Date(transfer.transferredAt).toLocaleDateString('ko-KR')}
                            </td>
                            <td className="whitespace-nowrap px-4 py-4 sm:px-6">
                              <span
                                className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${transfer.type === 'sent'
                                  ? 'bg-red-500/20 text-red-400'
                                  : 'bg-emerald-500/20 text-emerald-400'
                                  }`}
                              >
                                {transfer.type === 'sent' ? '보냄' : '받음'}
                              </span>
                            </td>
                            <td className="px-4 py-4 text-sm text-slate-400 sm:px-6">
                              {transfer.type === 'sent'
                                ? transfer.users.username || transfer.users.email
                                : transfer.users.username || transfer.users.email}
                            </td>
                            <td
                              className={`whitespace-nowrap px-4 py-4 text-right text-sm font-bold sm:px-6 ${transfer.type === 'sent' ? 'text-red-400' : 'text-emerald-400'
                                }`}
                            >
                              {transfer.type === 'sent' ? '-' : '+'}
                              {coinFormat.format(transfer.amount)} MSUO
                            </td>
                            <td className="whitespace-nowrap px-4 py-4 text-right text-sm text-slate-400 sm:px-6">
                              {transfer.fee > 0 ? `-${coinFormat.format(transfer.fee)}` : '-'}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center">
                            <p className="text-sm text-slate-500">이체 내역이 없습니다</p>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>

            {/* 출금 신청 내역 섹션 */}
            <section className="rounded-2xl border border-white/5 bg-slate-900/40 p-4 shadow-xl backdrop-blur-sm sm:p-6">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-white">출금 신청 내역</h2>
                <p className="mt-1 text-sm text-slate-400">최근 출금 신청 및 처리 현황</p>
              </div>
              <div className="overflow-hidden rounded-xl border border-white/5 bg-slate-950/70">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-slate-800/60">
                    <thead className="bg-slate-900/50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          신청일
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          금액
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          지갑 주소
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          상태
                        </th>
                        <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                          처리일
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/40 bg-slate-950/50">
                      {loadingWithdrawals ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center">
                            <div className="mx-auto max-w-sm">
                              <p className="text-sm text-slate-500">로딩 중...</p>
                            </div>
                          </td>
                        </tr>
                      ) : withdrawals.length > 0 ? (
                        withdrawals.map((withdrawal) => {
                          const statusColors = {
                            PENDING: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
                            APPROVED: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
                            REJECTED: 'bg-red-500/20 text-red-400 border-red-500/30',
                          };
                          const statusLabels = {
                            PENDING: '대기 중',
                            APPROVED: '승인됨',
                            REJECTED: '거절됨',
                          };

                          return (
                            <tr key={withdrawal.id} className="transition-colors hover:bg-white/5">
                              <td className="whitespace-nowrap px-4 py-4 text-sm text-slate-300 sm:px-6">
                                {new Date(withdrawal.requestedAt).toLocaleDateString('ko-KR')}
                              </td>
                              <td className="whitespace-nowrap px-4 py-4 text-sm font-semibold text-white sm:px-6">
                                {coinFormat.format(withdrawal.amount)} MSUO
                              </td>
                              <td className="px-4 py-4 text-sm text-slate-400 sm:px-6">
                                <span className="font-mono text-xs">
                                  {withdrawal.address.slice(0, 10)}...{withdrawal.address.slice(-8)}
                                </span>
                              </td>
                              <td className="whitespace-nowrap px-4 py-4 sm:px-6">
                                <span
                                  className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-semibold ${statusColors[withdrawal.status]}`}
                                >
                                  {statusLabels[withdrawal.status]}
                                </span>
                                {withdrawal.rejectionReason && (
                                  <p className="mt-1 text-xs text-red-400">{withdrawal.rejectionReason}</p>
                                )}
                              </td>
                              <td className="whitespace-nowrap px-4 py-4 text-sm text-slate-400 sm:px-6">
                                {withdrawal.processedAt
                                  ? new Date(withdrawal.processedAt).toLocaleDateString('ko-KR')
                                  : '-'}
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center">
                            <div className="mx-auto max-w-sm">
                              <svg
                                className="mx-auto h-12 w-12 text-slate-600"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                />
                              </svg>
                              <p className="mt-4 text-sm text-slate-500">출금 신청 내역이 없습니다</p>
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* 투자 관리 탭 */}
        {activeTab === 'investments' && (
          <div className="space-y-6">
            <section className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-white">투자 관리</h2>
                <p className="mt-1 text-sm text-slate-400">코인을 투자하여 수익을 창출하세요</p>
              </div>
              <button
                onClick={() => setIsInvestmentModalOpen(true)}
                className="w-full rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 px-6 py-4 text-lg font-bold text-white shadow-lg shadow-blue-500/50 transition hover:scale-[1.02] hover:shadow-xl hover:shadow-blue-500/50"
              >
                💰 새 투자하기
              </button>
              <div className="mt-6 rounded-xl border border-white/5 bg-slate-950/70 p-6">
                <p className="text-center text-slate-400">투자 내역 기능은 추후 추가 예정입니다</p>
              </div>
            </section>

            {/* 투자 성과 차트 (예시) */}
            <div className="grid gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
                <div className="mb-4 flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-emerald-400" />
                  <h3 className="text-lg font-bold text-white">예상 수익 추이</h3>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={rewardChartData}>
                    <defs>
                      <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" stroke="#9CA3AF" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                    <YAxis stroke="#9CA3AF" tick={{ fill: '#9CA3AF', fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1E293B',
                        border: '1px solid #334155',
                        borderRadius: '8px',
                        color: '#F1F5F9',
                      }}
                      formatter={(value: number) => [`${coinFormat.format(value)} MSUO`, '수익']}
                    />
                    <Area
                      type="monotone"
                      dataKey="amount"
                      stroke="#10B981"
                      fillOpacity={1}
                      fill="url(#colorProfit)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
                <div className="mb-4 flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-400" />
                  <h3 className="text-lg font-bold text-white">투자 성과 요약</h3>
                </div>
                <div className="space-y-4">
                  <div className="rounded-xl border border-white/5 bg-slate-950/70 p-4">
                    <p className="text-sm text-slate-400">총 투자금</p>
                    <p className="mt-1 text-2xl font-bold text-white">
                      {coinFormat.format(data.users.totalInvestment)} MSUO
                    </p>
                  </div>
                  <div className="rounded-xl border border-white/5 bg-slate-950/70 p-4">
                    <p className="text-sm text-slate-400">오늘 예상 수익</p>
                    <p className="mt-1 text-2xl font-bold text-emerald-400">
                      +{coinFormat.format(data.todayExpectedReward)} MSUO
                    </p>
                  </div>
                  <div className="rounded-xl border border-white/5 bg-slate-950/70 p-4">
                    <p className="text-sm text-slate-400">예상 일일 수익률</p>
                    <p className="mt-1 text-2xl font-bold text-blue-400">
                      {data.users.totalInvestment > 0
                        ? ((data.todayExpectedReward / data.users.totalInvestment) * 100).toFixed(2)
                        : '0.00'}
                      %
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 모달들 */}
      <WithdrawalModal
        isOpen={isWithdrawalModalOpen}
        onClose={() => setIsWithdrawalModalOpen(false)}
        userId={data.users.id}
        currentBalance={data.totalAssets}
        onSuccess={async () => {
          // 성공 시 출금 내역 다시 불러오기
          try {
            const res = await fetch(`/api/user/withdraw?userId=${data.users.id}`);
            const result = await res.json();
            if (result.ok) {
              setWithdrawals(result.data);
            }
          } catch (error) {
            console.error('출금 내역 조회 실패:', error);
          }
          // 페이지 새로고침으로 잔고 업데이트
          window.location.reload();
        }}
      />

      <InvestmentModal
        isOpen={isInvestmentModalOpen}
        onClose={() => setIsInvestmentModalOpen(false)}
        userId={data.users.id}
        currentBalance={data.totalAssets}
        onSuccess={() => {
          // 성공 시 페이지 새로고침으로 잔고 업데이트
          window.location.reload();
        }}
      />

      <TransferModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
        userId={data.users.id}
        currentBalance={data.totalAssets}
        onSuccess={async () => {
          // 성공 시 이체 내역 다시 불러오기
          try {
            const res = await fetch(`/api/user/transfer?type=${transferFilter}`);
            const result = await res.json();
            if (result.ok) {
              setTransfers(result.data);
            }
          } catch (error) {
            console.error('이체 내역 조회 실패:', error);
          }
          // 페이지 새로고침으로 잔고 업데이트
          window.location.reload();
        }}
      />
    </div>
  );
});

export default DashboardClient;
