import { redirect } from 'next/navigation';
import NewDashboard from './NewDashboard';
import { getCurrentUser } from '@/lib/auth';
import { isAdminUser } from '@/lib/admin-auth';
import { getDashboardData } from '@/lib/dashboard-data';

export default async function DashboardPage() {
  // 인증 확인
  const user = await getCurrentUser();
  
  if (!user) {
    console.log('[Dashboard] 사용자 인증 실패 - 로그인 페이지로 리다이렉트');
    redirect('/login');
  }

  // role이 null인 경우 USER로 처리
  const userRole = user.role || 'USER';
  console.log('[Dashboard] 사용자 정보:', { 
    id: user.id, 
    username: user.username, 
    role: user.role, 
    normalizedRole: userRole 
  });

  // 관리자는 관리자 페이지로 리다이렉트
  if (isAdminUser(user)) {
    console.log('[Dashboard] 관리자 계정 - 관리자 페이지로 리다이렉트');
    redirect('/a0-admin');
  }

  // 서버 컴포넌트에서 직접 데이터 가져오기 (API 라우트 거치지 않음)
  const dashboardDataResult = await getDashboardData(user.id);

  // 사용자 정보 가져오기
  const totalInvestmentAmount = dashboardDataResult.stats.totalInvestment;
  const totalWithdrawalAmount = dashboardDataResult.totalWithdrawalAmount;

  // API 응답 형식으로 변환
  const dashboardData = {
    ok: true,
    data: {
      users: {
        ...users,
        username: user.username || '',
        email: user.email || '',
        personalCoin: Number(user.personalCoin || 0),
        totalInvestment: totalInvestmentAmount,
        totalWithdrawals: totalWithdrawalAmount,
        _count: dashboardDataResult.userCounts,
        createdAt: user.createdAt.toISOString(),
        other_users_users_referrerIdTousers: user.referrer ? {
          username: user.other_users_users_referrerIdTousers.username || ''
        } : null,
      },
      stats: {
        ...dashboardDataResult.stats,
        availableBalance: Number(user.personalCoin || 0)
      },
      recentActivities: dashboardDataResult.recentActivities,
      orgTree: dashboardDataResult.orgTree
    }
  };

  return <NewDashboard data={dashboardData} />;
}
