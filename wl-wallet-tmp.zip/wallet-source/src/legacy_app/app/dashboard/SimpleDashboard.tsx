'use client';

import Link from 'next/link';
import {
  TrendingUp,
  DollarSign,
  Users,
  Activity,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  User,
  CreditCard,
  Target
} from 'lucide-react';
import { Container } from '@/components/ui/Container';
import { StatCardsGrid, MenuGrid, ContentGrid } from '@/components/ui/Grid';
import { Card, CardContent, CardHeader, StatCard, MenuCard } from '@/components/ui/Card';
import { formatCurrency, formatNumber, formatDate } from '@/lib/utils';
import { PWAInstallPrompt } from '@/components/PWAInstallPrompt';

interface DashboardData {
  ok: boolean;
  data: {
    users: {
      id: string;
      username: string;
      email: string;
      rank: number;
      totalInvestment: number;
      personalCoin: number;
      createdAt: string;
      referrer?: { username: string } | null;
      _count: {
        other_users_users_referrerIdTousers: number;
        investments: number;
      };
    };
    stats: {
      totalInvestment: number;
      activeInvestments: number;
      todayEarnings: number;
      monthlyEarnings: number;
      totalEarnings: number;
      expectedDailyEarnings: number;
      availableBalance: number;
    };
    recentActivities: {
      investments: Array<{
        id: string;
        amount: number;
        dailyRate: number;
        isActive: boolean;
        createdAt: string;
        endDate: string;
      }>;
      rewards: Array<{
        id: string;
        type: string;
        amount: number;
        description: string;
        createdAt: string;
      }>;
    };
  };
}

export default function SimpleDashboard({ data }: { data: DashboardData }) {
  if (!data.ok || !data.data) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-red-400">데이터를 불러올 수 없습니다.</div>
      </div>
    );
  }

  const { user, stats, recentActivities } = data.data;

  // 통계 카드 데이터
  const statCards = [
    {
      title: '총 투자금',
      value: `$${stats.totalInvestment.toLocaleString()}`,
      icon: DollarSign,
      color: 'from-blue-500 to-blue-600',
      change: `${stats.activeInvestments}개 활성`
    },
    {
      title: '예상 일수익',
      value: `$${stats.expectedDailyEarnings.toFixed(2)}`,
      icon: TrendingUp,
      color: 'from-green-500 to-green-600',
      change: '+0.5%'
    },
    {
      title: '오늘 수익',
      value: `$${stats.todayEarnings.toFixed(2)}`,
      icon: Calendar,
      color: 'from-purple-500 to-purple-600',
      change: stats.todayEarnings > 0 ? '수익 발생' : '아직 없음'
    },
    {
      title: '가용 잔액',
      value: `$${stats.availableBalance.toFixed(2)}`,
      icon: Wallet,
      color: 'from-orange-500 to-orange-600',
      change: '출금 가능'
    }
  ];

  // 메뉴 아이템
  const menuItems = [
    {
      title: '투자하기',
      description: '새로운 투자 시작',
      icon: Target,
      href: '/invest',
      color: 'bg-gradient-to-r from-blue-600 to-blue-700'
    },
    {
      title: '출금',
      description: '수익 출금 요청',
      icon: CreditCard,
      href: '/withdraw',
      color: 'bg-gradient-to-r from-green-600 to-green-700'
    },
    {
      title: '추천인',
      description: `${user._count.referredUsers}명`,
      icon: Users,
      href: '/referrals',
      color: 'bg-gradient-to-r from-purple-600 to-purple-700'
    },
    {
      title: '프로필',
      description: '계정 정보 관리',
      icon: User,
      href: '/profile',
      color: 'bg-gradient-to-r from-orange-600 to-orange-700'
    }
  ];

  // 통계 카드 데이터
  const statCardsData: Array<{
    title: string;
    value: string;
    icon: React.ReactNode;
    color: string;
    change: string;
    trend?: 'up' | 'down' | 'neutral';
  }> = [
      {
        title: '총 투자금',
        value: formatCurrency(stats.totalInvestment),
        icon: <DollarSign />,
        color: 'from-blue-500 to-blue-600',
        change: `${stats.activeInvestments}개 활성`,
        trend: 'neutral'
      },
      {
        title: '예상 일수익',
        value: formatCurrency(stats.expectedDailyEarnings),
        icon: <TrendingUp />,
        color: 'from-green-500 to-green-600',
        change: '+0.5%',
        trend: 'up'
      },
      {
        title: '오늘 수익',
        value: formatCurrency(stats.todayEarnings),
        icon: <Calendar />,
        color: 'from-purple-500 to-purple-600',
        change: stats.todayEarnings > 0 ? '수익 발생' : '아직 없음',
        trend: stats.todayEarnings > 0 ? 'up' : 'neutral'
      },
      {
        title: '가용 잔액',
        value: formatCurrency(stats.availableBalance),
        icon: <Wallet />,
        color: 'from-orange-500 to-orange-600',
        change: '출금 가능',
        trend: 'neutral'
      }
    ];

  // 메뉴 아이템 데이터
  const menuItemsData = [
    {
      title: '투자하기',
      description: '새로운 투자 시작',
      icon: <Target />,
      href: '/invest',
      color: 'bg-gradient-to-r from-blue-600 to-blue-700'
    },
    {
      title: '출금',
      description: '수익 출금 요청',
      icon: <CreditCard />,
      href: '/withdraw',
      color: 'bg-gradient-to-r from-green-600 to-green-700'
    },
    {
      title: '추천인',
      description: `${user._count.referredUsers}명`,
      icon: <Users />,
      href: '/referrals',
      color: 'bg-gradient-to-r from-purple-600 to-purple-700'
    },
    {
      title: '프로필',
      description: '계정 정보 관리',
      icon: <User />,
      href: '/profile',
      color: 'bg-gradient-to-r from-orange-600 to-orange-700'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      <PWAInstallPrompt />
      {/* 헤더 */}
      <header className="bg-gray-800 border-b border-gray-700 sticky top-0 z-40">
        <Container>
          <div className="py-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-white leading-tight">
                  안녕하세요, {user.username}님! 👋
                </h1>
                <p className="text-gray-400 mt-1">Level {user.rank} 투자자</p>
              </div>
              <div className="flex items-center gap-2 sm:gap-4">
                <div className="text-right">
                  <p className="text-sm text-gray-400">총 수익</p>
                  <p className="text-xl sm:text-2xl font-bold text-green-400">
                    {formatCurrency(stats.totalEarnings)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Container>
      </header>

      <main>
        <Container className="py-6">
          {/* 통계 카드 */}
          <StatCardsGrid className="mb-8">
            {statCardsData.map((stat, index) => (
              <StatCard key={index} {...stat} />
            ))}
          </StatCardsGrid>

          {/* 빠른 메뉴 */}
          <section className="mb-8">
            <h2 className="text-xl font-semibold text-white mb-4">빠른 메뉴</h2>
            <MenuGrid>
              {menuItemsData.map((item, index) => (
                <MenuCard key={index} {...item} />
              ))}
            </MenuGrid>
          </section>

          {/* 최근 활동 */}
          <ContentGrid>
            {/* 최근 투자 */}
            <Card>
              <CardHeader className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-white">최근 투자</h2>
                <Link href="/investments" className="text-blue-400 hover:text-blue-300 text-sm">
                  전체보기
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivities.investments.length > 0 ? (
                    recentActivities.investments.map((investment) => (
                      <div
                        key={investment.id}
                        className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg ${investment.isActive ? 'bg-green-500/20' : 'bg-gray-600/20'
                            }`}>
                            <DollarSign className="h-4 w-4 text-green-400" />
                          </div>
                          <div>
                            <p className="text-white font-medium">
                              {formatCurrency(investment.amount)}
                            </p>
                            <p className="text-xs text-gray-400">
                              {formatDate(investment.createdAt)}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-green-400">
                            {(investment.dailyRate * 100).toFixed(2)}%
                          </p>
                          <p className="text-xs text-gray-400">
                            {investment.isActive ? '활성' : '만료'}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-400">투자 내역이 없습니다</p>
                      <Link
                        href="/invest"
                        className="mt-2 inline-block text-blue-400 hover:text-blue-300 text-sm"
                      >
                        첫 투자 시작하기
                      </Link>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* 최근 수익 */}
            <Card>
              <CardHeader className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-white">최근 수익</h2>
                <Link href="/rewards" className="text-blue-400 hover:text-blue-300 text-sm">
                  전체보기
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivities.rewards.length > 0 ? (
                    recentActivities.rewards.map((reward) => (
                      <div
                        key={reward.id}
                        className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-green-500/20">
                            <TrendingUp className="h-4 w-4 text-green-400" />
                          </div>
                          <div>
                            <p className="text-white font-medium">
                              {formatCurrency(reward.amount)}
                            </p>
                            <p className="text-xs text-gray-400">
                              {reward.description || reward.type}
                            </p>
                          </div>
                        </div>
                        <p className="text-xs text-gray-400">
                          {formatDate(reward.createdAt)}
                        </p>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-400">수익 내역이 없습니다</p>
                      <p className="text-xs text-gray-500 mt-1">
                        투자를 시작하면 수익이 발생합니다
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </ContentGrid>
        </Container>
      </main>
    </div>
  );
}