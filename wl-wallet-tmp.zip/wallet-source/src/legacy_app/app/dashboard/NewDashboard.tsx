'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import Chatbot from '@/components/Chatbot';
import PageHeader from '@/components/layout/PageHeader';
import CoinSwapWidget from '@/components/dashboard/CoinSwapWidget';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardData {
  ok: boolean;
  data: {
    users: {
      id: string;
      username: string;
      email: string;
      rank: number;
      totalInvestment: number;
      personalCoin: number;
      createdAt: string;
      referrer?: { username: string } | null;
      _count: {
        other_users_users_referrerIdTousers: number;
        totalTeamMembers?: number; // 전체 하위 조직원 수 (재귀적 계산)
        investments: number;
      };
    };
    stats: {
      totalInvestment: number;
      activeInvestments: number;
      todayEarnings: number;
      monthlyEarnings: number;
      totalEarnings: number;
      expectedDailyEarnings: number;
      availableBalance: number;
    };
    recentActivities: {
      investments: Array<{
        id: string;
        amount: number;
        dailyRate: number;
        isActive: boolean;
        createdAt: string;
        endDate: string;
      }>;
      rewards: Array<{
        id: string;
        type: string;
        amount: number;
        description: string;
        createdAt: string;
      }>;
    };
  };
}

export default function NewDashboard({ data }: { data: DashboardData }) {
  const router = useRouter();
  const { t, language } = useI18n();
  const [mounted, setMounted] = useState(false);
  const [currentPath, setCurrentPath] = useState('/dashboard');
  const [timeRange, setTimeRange] = useState(t.dashboard.periods.oneMonth);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);

  // 데이터 추출 (조건부이지만 Hooks가 아니므로 괜찮음)
  const user = data.ok && data.data ? data.data.users : null;
  const stats = data.ok && data.data ? data.data.stats : null;
  const recentActivities = data.ok && data.data ? data.data.recentActivities : null;

  // 언어 변경 시 timeRange도 업데이트
  useEffect(() => {
    const periods = [
      t.dashboard.periods.oneWeek,
      t.dashboard.periods.oneMonth,
      t.dashboard.periods.threeMonths,
      t.dashboard.periods.oneYear
    ];

    // 현재 timeRange가 새로운 언어의 기간 목록에 있는지 확인하고 없으면 기본값으로 설정
    if (!periods.includes(timeRange)) {
      setTimeRange(t.dashboard.periods.oneMonth);
    }
  }, [t.dashboard.periods, timeRange]);

  // 잔액 상태
  const [upcBalance, setNkbBalance] = useState<number>(0);
  const [upcCoinBalance, setNkbCoinBalance] = useState<number>(0);
  const [loadingBalance, setLoadingBalance] = useState(true);

  // 잔액 조회
  useEffect(() => {
    const fetchBalance = async () => {
      try {
        const res = await fetch('/api/user/balance', {
          credentials: 'include',
        });
        const data = await res.json();
        if (data.ok && data.data) {
          setNkbBalance(data.data.aotBalance || 0);
          setNkbCoinBalance(data.data.aoCoinBalance || 0);
        }
      } catch (error) {
        console.error('잔액 조회 실패:', error);
      } finally {
        setLoadingBalance(false);
      }
    };
    fetchBalance();
  }, []);

  // MSUO 코인 잔액 (personalCoin을 MSUO 단위로 표시) - 메모이제이션
  const totalCoinBalance = useMemo(() => Number(user?.personalCoin || 0), [user?.personalCoin]);
  const totalReward = useMemo(() => stats?.totalEarnings || 0, [stats?.totalEarnings]);
  const teamMembers = useMemo(() => user?._count?.totalTeamMembers || user?._count?.referredUsers || 0, [user?._count?.totalTeamMembers, user?._count?.referredUsers]);
  const totalSales = useMemo(() => stats?.totalInvestment || 0, [stats?.totalInvestment]);


  // 일일 리워드와 추천 리워드 계산 - 메모이제이션
  const dailyReward = useMemo(() => stats?.todayEarnings || 0, [stats?.todayEarnings]);
  const referralReward = useMemo(() => {
    if (!recentActivities?.rewards) return 0;
    return recentActivities.rewards
      .filter((r) => r.type === 'REFERRAL' || r.type === 'MATCHING')
      .reduce((sum, r) => sum + r.amount, 0);
  }, [recentActivities?.rewards]);

  useEffect(() => {
    setMounted(true);
  }, []);

  // 모든 Hooks는 조건부 렌더링 전에 호출되어야 함

  const handleLogout = useCallback(async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
      });
      router.push('/login');
      router.refresh();
    } catch (error) {
      console.error('로그아웃 실패:', error);
      // 로그아웃 실패해도 로그인 페이지로 이동
      router.push('/login');
    }
  }, [router]);

  // 알림 아이콘 및 색상 함수 - 메모이제이션
  const getIcon = useCallback((type: string) => {
    switch (type) {
      case 'REFERRAL':
      case 'MATCHING':
        return 'emoji_events';
      case 'DAILY':
        return 'account_balance_wallet';
      default:
        return 'description';
    }
  }, []);

  const getColor = useCallback((type: string) => {
    switch (type) {
      case 'REFERRAL':
      case 'MATCHING':
        return 'bg-blue-500/20 text-blue-400';
      case 'DAILY':
        return 'bg-yellow-500/20 text-yellow-400';
      default:
        return 'bg-green-500/20 text-green-400';
    }
  }, []);

  const timeAgo = useCallback((date: string) => {
    const now = new Date();
    const then = new Date(date);
    const diff = now.getTime() - then.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    if (days > 0) return `${days}일 전`;
    if (hours > 0) return `${hours}시간 전`;
    return '방금 전';
  }, []);

  // 차트 데이터 생성
  const chartData = useMemo(() => {
    const rewards = recentActivities?.rewards || [];
    const now = new Date();
    const dataPoints: { date: string; amount: number }[] = [];

    let days = 7;
    let labelFormat = (date: Date) => `${date.getMonth() + 1}.${date.getDate()}`;

    if (timeRange === t.dashboard.periods.oneWeek) days = 7;
    else if (timeRange === t.dashboard.periods.oneMonth) days = 30;
    else if (timeRange === t.dashboard.periods.threeMonths) days = 90;
    else if (timeRange === t.dashboard.periods.oneYear) {
      days = 365;
      labelFormat = (date: Date) => `${date.getFullYear()}.${date.getMonth() + 1}`;
    }

    // 지난 날짜들에 대한 데이터 포인트 생성
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const dateStr = d.toISOString().split('T')[0]; // YYYY-MM-DD

      // 해당 날짜의 리워드 합계 계산
      const amount = rewards
        .filter(r => r.createdAt.startsWith(dateStr))
        .reduce((sum, r) => sum + r.amount, 0);

      dataPoints.push({
        date: labelFormat(d),
        amount: amount
      });
    }

    // 데이터가 너무 많으면 리샘플링 (3개월 이상일 때)
    if (days > 30) {
      return dataPoints.filter((_, index) => index % Math.ceil(days / 30) === 0);
    }

    return dataPoints;
  }, [timeRange, recentActivities, t.dashboard.periods]);

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-white">로딩 중...</div>
      </div>
    );
  }

  if (!data.ok || !data.data || !user || !stats || !recentActivities) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-red-400">데이터를 불러올 수 없습니다.</div>
      </div>
    );
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1 overflow-visible">
            {/* Header */}
            <PageHeader
              user={user || { username: '', personalCoin: 0 }}
              showRightButtons={true}
              rightButtons={
                <>
                  <LanguageSwitcher />
                  <div className="flex gap-2">
                    <button
                      onClick={() => setIsChatbotOpen(true)}
                      className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] hover:opacity-90 text-white transition-opacity"
                      title="고객지원 챗봇"
                    >
                      <span className="material-symbols-outlined">smart_toy</span>
                    </button>
                    <Link href="/notifications" className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white">
                      <span className="material-symbols-outlined">notifications</span>
                    </Link>
                    <Link href="/faq" className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white">
                      <span className="material-symbols-outlined">help</span>
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white"
                      title="Logout"
                    >
                      <span className="material-symbols-outlined">logout</span>
                    </button>
                  </div>
                  <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] flex items-center justify-center text-white font-bold">
                    {user.username?.[0]?.toUpperCase() || 'U'}
                  </div>
                </>
              }
            />

            <main className="flex-1 p-2 sm:p-4 md:p-6 overflow-visible relative z-0">
              {/* Page Title */}
              <div className="flex flex-wrap justify-between gap-3 sm:gap-4 py-3 sm:py-4 px-2">
                <div className="flex flex-col gap-1 sm:gap-2 min-w-0 flex-1">
                  <p className="text-white text-2xl sm:text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em] break-words">
                    {t.dashboard.title}
                  </p>
                  <p className="text-gray-400 dark:text-gray-400 text-sm sm:text-base font-normal leading-normal break-words">
                    {t.dashboard.subtitle}
                  </p>
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button className="flex flex-1 sm:flex-none min-w-0 sm:min-w-[84px] max-w-full sm:max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-3 sm:px-4 bg-white/5 text-white gap-2 text-xs sm:text-sm font-medium leading-normal hover:bg-white/10">
                    <span className="material-symbols-outlined text-sm sm:text-base">
                      file_upload
                    </span>
                    <span className="truncate hidden sm:inline">{t.dashboard.downloadReport}</span>
                    <span className="truncate sm:hidden">다운로드</span>
                  </button>
                  <Link
                    href="/transfer"
                    className="flex flex-1 sm:flex-none min-w-0 sm:min-w-[84px] max-w-full sm:max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-3 sm:px-4 bg-[#137fec] text-white gap-2 text-xs sm:text-sm font-bold leading-normal hover:opacity-90"
                  >
                    <span className="material-symbols-outlined text-sm sm:text-base">send</span>
                    <span className="truncate">{t.dashboard.sendCoin}</span>
                  </Link>
                </div>
              </div>

              {/* Stats Cards - 한 줄로 배치 */}
              <div className="grid grid-cols-5 gap-2 sm:gap-3 p-2">
                <div className="flex flex-col gap-1 rounded-xl p-3 sm:p-4 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-xs sm:text-sm font-medium leading-normal break-words">
                    MSUO 잔액
                  </p>
                  <p className="text-white tracking-light text-lg sm:text-xl font-bold leading-tight break-words">
                    {loadingBalance ? (
                      <span className="text-gray-400 text-sm">로딩...</span>
                    ) : (
                      <>
                        {upcBalance.toLocaleString('ko-KR', {
                          maximumFractionDigits: 2,
                        })}{' '}
                        <span className="text-sm sm:text-base">MSUO</span>
                      </>
                    )}
                  </p>
                </div>
                <div className="flex flex-col gap-1 rounded-xl p-3 sm:p-4 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-xs sm:text-sm font-medium leading-normal break-words">
                    MSUO 코인 잔액
                  </p>
                  <p className="text-white tracking-light text-lg sm:text-xl font-bold leading-tight break-words">
                    {loadingBalance ? (
                      <span className="text-gray-400 text-sm">로딩...</span>
                    ) : (
                      <>
                        {upcCoinBalance.toLocaleString('ko-KR', {
                          maximumFractionDigits: 8,
                        })}{' '}
                        <span className="text-sm sm:text-base">MSUO</span>
                      </>
                    )}
                  </p>
                </div>
                <div className="flex flex-col gap-1 rounded-xl p-3 sm:p-4 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-xs sm:text-sm font-medium leading-normal break-words">
                    {t.dashboard.totalReward}
                  </p>
                  <p className="text-white tracking-light text-lg sm:text-xl font-bold leading-tight break-words">
                    {totalReward.toLocaleString('ko-KR', {
                      maximumFractionDigits: 2,
                    })}{' '}
                    <span className="text-sm sm:text-base">MSUO</span>
                  </p>
                  <p className="text-green-500 text-[10px] sm:text-xs font-medium leading-normal flex items-center break-words">
                    <span className="material-symbols-outlined text-xs sm:text-sm">
                      arrow_upward
                    </span>
                    +{totalReward > 0 && stats.monthlyEarnings > 0 ? ((stats.monthlyEarnings / totalReward) * 100).toFixed(1) : '0'}%
                  </p>
                </div>
                <div className="flex flex-col gap-1 rounded-xl p-3 sm:p-4 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-xs sm:text-sm font-medium leading-normal break-words">
                    {t.dashboard.totalTeamMembers}
                  </p>
                  <p className="text-white tracking-light text-lg sm:text-xl font-bold leading-tight break-words">
                    {teamMembers.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US')}{language === 'ko' ? '명' : ''}
                  </p>
                  <p className="text-green-500 text-[10px] sm:text-xs font-medium leading-normal flex items-center break-words">
                    <span className="material-symbols-outlined text-xs sm:text-sm">
                      arrow_upward
                    </span>
                    +{teamMembers > 0 ? Math.floor(teamMembers * 0.02) : '0'}{language === 'ko' ? '명' : ''}
                  </p>
                </div>
                <div className="flex flex-col gap-1 rounded-xl p-3 sm:p-4 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-xs sm:text-sm font-medium leading-normal break-words">
                    {t.dashboard.totalSales}
                  </p>
                  <p className="text-white tracking-light text-lg sm:text-xl font-bold leading-tight break-words">
                    ${totalSales.toLocaleString('ko-KR', { maximumFractionDigits: 2 })}
                  </p>
                  <p className="text-green-500 text-[10px] sm:text-xs font-medium leading-normal flex items-center break-words">
                    <span className="material-symbols-outlined text-xs sm:text-sm">
                      arrow_upward
                    </span>
                    +{stats.activeInvestments > 0 ? '5.2' : '0'}%
                  </p>
                </div>
              </div>

              {/* Chart and Sidebar */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 p-2 mt-3 sm:mt-4">
                {/* Reward Chart */}
                <div className="lg:col-span-2 flex min-w-0 flex-1 flex-col gap-3 sm:gap-4 rounded-xl border border-white/10 p-4 sm:p-6 bg-white/5">
                  <div className="flex flex-wrap justify-between items-start gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="text-white text-base sm:text-lg font-medium leading-normal break-words">
                        {t.dashboard.rewardStatus}
                      </p>
                      <div className="flex flex-wrap items-end gap-2 sm:gap-3 mt-1">
                        <p className="text-white tracking-light text-2xl sm:text-3xl lg:text-4xl font-bold leading-tight break-words">
                          {stats.monthlyEarnings.toLocaleString('ko-KR', {
                            maximumFractionDigits: 2,
                          })}{' '}
                          <span className="text-xl sm:text-2xl lg:text-3xl">MSUO</span>
                        </p>
                        <p className="text-green-500 text-sm sm:text-base font-medium leading-normal pb-1 break-words">
                          +{stats.monthlyEarnings > 0 ? '8.5' : '0'}%
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 rounded-lg border border-white/10 p-1 flex-wrap">
                      {[
                        { key: 'oneWeek', value: t.dashboard.periods.oneWeek },
                        { key: 'oneMonth', value: t.dashboard.periods.oneMonth },
                        { key: 'threeMonths', value: t.dashboard.periods.threeMonths },
                        { key: 'oneYear', value: t.dashboard.periods.oneYear }
                      ].map((period) => (
                        <button
                          key={period.key}
                          onClick={() => setTimeRange(period.value)}
                          className={`px-2 sm:px-3 py-1 text-[10px] sm:text-xs font-medium rounded-md ${timeRange === period.value
                            ? 'text-white bg-white/10'
                            : 'text-gray-300 hover:text-white'
                            }`}
                        >
                          {period.value}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex min-h-[200px] sm:min-h-[250px] flex-1 flex-col justify-end gap-4 sm:gap-8 py-2 sm:py-4 w-full">
                    <ResponsiveContainer width="100%" height={200}>
                      <AreaChart data={chartData}>
                        <defs>
                          <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#137fec" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#137fec" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <Tooltip
                          contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px', color: '#fff' }}
                          itemStyle={{ color: '#fff' }}
                          formatter={(value: number) => [`${value.toLocaleString()} MSUO`, '수익']}
                        />
                        <Area
                          type="monotone"
                          dataKey="amount"
                          stroke="#137fec"
                          strokeWidth={3}
                          fillOpacity={1}
                          fill="url(#colorAmount)"
                        />
                        <XAxis
                          dataKey="date"
                          hide
                          interval="preserveStartEnd"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                    <div className="flex justify-between px-2">
                      {chartData.filter((_, i, arr) => i === 0 || i === Math.floor(arr.length / 2) || i === arr.length - 1).map((point, i) => (
                        <p
                          key={i}
                          className="text-gray-400 text-[13px] font-bold leading-normal tracking-[0.015em]"
                        >
                          {point.date}
                        </p>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Sidebar */}
                <div className="lg:col-span-1 flex flex-col gap-3 sm:gap-4">
                  {/* Daily/Referral Rewards */}
                  <div className="rounded-xl border border-white/10 bg-white/5 p-4 sm:p-6">
                    <div className="flex flex-col items-stretch justify-start">
                      <div className="flex w-full grow flex-col items-stretch justify-center gap-3 sm:gap-4">
                        <div>
                          <p className="text-gray-300 text-xs sm:text-sm font-medium leading-tight break-words">
                            {t.dashboard.dailyReward}
                          </p>
                          <p className="text-white text-xl sm:text-2xl font-bold leading-tight mt-1 break-words">
                            {dailyReward.toLocaleString('ko-KR', {
                              maximumFractionDigits: 2,
                            })}{' '}
                            <span className="text-lg sm:text-xl">MSUO</span>
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-300 text-xs sm:text-sm font-medium leading-tight break-words">
                            {t.dashboard.referralReward}
                          </p>
                          <p className="text-white text-xl sm:text-2xl font-bold leading-tight mt-1 break-words">
                            {referralReward.toLocaleString('ko-KR', {
                              maximumFractionDigits: 2,
                            })}{' '}
                            <span className="text-lg sm:text-xl">MSUO</span>
                          </p>
                        </div>
                        {/* 코인 교환 위젯 */}
                        <div className="mt-4">
                          <CoinSwapWidget
                            userBalance={totalCoinBalance}
                            onSwapSuccess={() => {
                              // 교환 성공 시 잔액 새로고침
                              window.location.reload();
                            }}
                          />
                        </div>
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3 justify-start mt-3 sm:mt-4">
                          <Link
                            href="/rewards"
                            className="flex w-full sm:w-auto max-w-full sm:max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-3 sm:px-4 bg-[#137fec] text-white text-xs sm:text-sm font-bold leading-normal hover:opacity-90"
                          >
                            <span className="truncate">{t.dashboard.claimReward}</span>
                          </Link>
                          <Link
                            href="/transactions"
                            className="flex w-full sm:w-auto max-w-full sm:max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-3 sm:px-4 bg-white/5 text-white text-xs sm:text-sm font-medium leading-normal hover:bg-white/10"
                          >
                            <span className="truncate">{t.dashboard.transactionHistory}</span>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Notifications */}
                  <div className="rounded-xl border border-white/10 bg-white/5 p-4 sm:p-6 flex flex-col gap-3 sm:gap-4 h-full">
                    <h3 className="text-white text-base sm:text-lg font-medium break-words">{t.dashboard.latestNotifications}</h3>
                    <div className="flex flex-col gap-3 sm:gap-4 overflow-y-auto">
                      {recentActivities.rewards.length > 0 ? (
                        recentActivities.rewards.slice(0, 4).map((reward) => {

                          return (
                            <div key={reward.id} className="flex items-start gap-2 sm:gap-3">
                              <div
                                className={`mt-1 flex-shrink-0 size-7 sm:size-8 rounded-full ${getColor(
                                  reward.type
                                )} flex items-center justify-center`}
                              >
                                <span className="material-symbols-outlined text-sm sm:text-base">
                                  {getIcon(reward.type)}
                                </span>
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="text-white text-xs sm:text-sm font-medium break-words">
                                  {reward.description ? reward.description.replace(/USDT/g, 'MSUO').replace(/AOT/g, 'MSUO') :
                                    `${reward.type} 리워드 ${reward.amount.toFixed(2)} MSUO`}
                                </p>
                                <p className="text-gray-400 text-[10px] sm:text-xs break-words">
                                  {timeAgo(reward.createdAt)}
                                </p>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <div className="text-center py-4">
                          <p className="text-gray-400 text-xs sm:text-sm break-words">{t.dashboard.noNotifications}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
      
      {/* 챗봇 컴포넌트 */}
      <Chatbot isOpen={isChatbotOpen} onClose={() => setIsChatbotOpen(false)} />
    </div>
  );
}

