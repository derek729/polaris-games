import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { isValidEmail, validateRequired } from '@/lib/validation';
import { checkRateLimit, rateLimitConfigs } from '@/lib/rate-limit';
import crypto from 'crypto';

export async function POST(request: Request) {
  // Rate Limiting 체크
  const rateLimitResult = await checkRateLimit(request, rateLimitConfigs.auth);
  if (!rateLimitResult.success) {
    return rateLimitResult.response;
  }

  try {
    const body = await request.json();
    const { email } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['email']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '이메일을 입력해주세요.');
    }

    // 이메일 형식 검증
    if (!isValidEmail(email)) {
      return validationErrorResponse('올바른 이메일 형식이 아닙니다.');
    }

    // 사용자 조회
    const user = await prisma.users.findUnique({
      where: { email: email.trim() },
      select: {
        id: true,
        username: true,
        email: true,
        isActive: true,
        status: true,
      },
    });

    // 보안을 위해 사용자가 존재하지 않아도 성공 메시지 반환
    // (이메일 열거 공격 방지)
    if (!user) {
      return successResponse(
        { message: '이메일이 등록되어 있다면 비밀번호 재설정 링크를 전송했습니다.' },
        '비밀번호 재설정 링크가 전송되었습니다.'
      );
    }

    if (!user.isActive || user.status !== 'ACTIVE') {
      return successResponse(
        { message: '이메일이 등록되어 있다면 비밀번호 재설정 링크를 전송했습니다.' },
        '비밀번호 재설정 링크가 전송되었습니다.'
      );
    }

    // 비밀번호 재설정 토큰 생성
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetTokenExpiry = new Date();
    resetTokenExpiry.setHours(resetTokenExpiry.getHours() + 1); // 1시간 후 만료

    // TODO: 실제로는 데이터베이스에 resetToken과 resetTokenExpiry를 저장해야 합니다.
    // 현재는 Prisma 스키마에 해당 필드가 없으므로, 나중에 추가해야 합니다.
    // 예: await prisma.users.update({
    //   where: { id: user.id },
    //   data: { resetToken, resetTokenExpiry }
    // });

    // TODO: 실제 이메일 전송 기능 구현
    // 현재는 콘솔에 로그만 출력합니다.
    const resetLink = `${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3009'}/reset-password?token=${resetToken}`;
    console.log(`[비밀번호 재설정] 사용자: ${user.email}, 링크: ${resetLink}`);

    // 실제 프로덕션에서는 이메일 서비스(예: SendGrid, AWS SES, Nodemailer)를 사용해야 합니다.
    // 예시:
    // await sendEmail({
    //   to: user.email,
    //   subject: '비밀번호 재설정',
    //   html: `비밀번호를 재설정하려면 다음 링크를 클릭하세요: <a href="${resetLink}">${resetLink}</a>`
    // });

    return successResponse(
      { message: '이메일이 등록되어 있다면 비밀번호 재설정 링크를 전송했습니다.' },
      '비밀번호 재설정 링크가 전송되었습니다.'
    );
  } catch (error: any) {
    console.error('비밀번호 찾기 실패:', error);
    return errorResponse(
      error.message || '비밀번호 찾기 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

