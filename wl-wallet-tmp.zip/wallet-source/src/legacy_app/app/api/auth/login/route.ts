import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import { successResponse, errorResponse, validationErrorResponse, unauthorizedResponse } from '@/lib/api-response';
import { checkRateLimit, rateLimitConfigs } from '@/lib/rate-limit';

export async function POST(request: Request) {
  // Rate Limiting 체크
  const rateLimitResult = await checkRateLimit(request, rateLimitConfigs.auth);
  if (!rateLimitResult.success) {
    return rateLimitResult.response;
  }

  try {
    const body = await request.json();
    const { username, email, password } = body;

    // username 또는 email 중 하나는 필수
    const identifier = username || email;
    if (!identifier || !password) {
      return validationErrorResponse('사용자명(또는 이메일)과 비밀번호를 입력해주세요.');
    }

    // 유저 조회 (username 또는 email로 검색)
    const whereConditions: any[] = [];
    if (username) {
      whereConditions.push({ username });
    }
    if (email) {
      whereConditions.push({ email });
    }

    if (whereConditions.length === 0) {
      return validationErrorResponse('사용자명 또는 이메일을 입력해주세요.');
    }

    const user = await prisma.users.findFirst({
      where: {
        OR: whereConditions,
      },
      select: {
        id: true,
        username: true,
        email: true,
        password: true,
        status: true,
        isActive: true,
        role: true,
      },
    });

    if (!user) {
      console.log('[Login] 사용자를 찾을 수 없음:', { username, email, whereConditions });
      return unauthorizedResponse('사용자명 또는 비밀번호가 올바르지 않습니다.');
    }

    // role이 null이거나 undefined인 경우 USER로 설정
    const userRole = user.role || 'USER';
    
    // role이 null인 사용자는 USER로 업데이트 (다음 요청부터는 정상 작동)
    if (!user.role) {
      try {
        await prisma.users.update({
          where: { id: user.id },
          data: { role: 'USER' },
        });
        console.log('[Login] role이 null인 사용자를 USER로 업데이트:', user.id);
      } catch (updateError) {
        console.error('[Login] role 업데이트 실패:', updateError);
        // 업데이트 실패해도 로그인은 계속 진행
      }
    }

    console.log('[Login] 사용자 조회 성공:', { 
      id: user.id, 
      username: user.username, 
      email: user.email, 
      role: user.role,
      normalizedRole: userRole,
      isActive: user.isActive,
      status: user.status,
      hasPassword: !!user.password 
    });

    if (!user.isActive || user.status !== 'ACTIVE') {
      return errorResponse('비활성화된 계정입니다.', 403, 'FORBIDDEN');
    }

    // 일반 로그인에서는 관리자 계정 차단
    if (userRole === 'ADMIN' || userRole === 'SUPER_ADMIN') {
      return errorResponse(
        '관리자 계정은 관리자 전용 로그인 페이지를 사용해주세요.',
        403,
        'ADMIN_ACCOUNT'
      );
    }

    // 비밀번호 확인
    if (!user.password) {
      console.log('[Login] 비밀번호가 설정되지 않은 계정:', user.id);
      return unauthorizedResponse('비밀번호가 설정되지 않은 계정입니다.');
    }

    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      console.log('[Login] 비밀번호 불일치:', { 
        userId: user.id, 
        username: user.username,
        passwordLength: password.length 
      });
      return unauthorizedResponse('사용자명 또는 비밀번호가 올바르지 않습니다.');
    }

    console.log('[Login] 로그인 성공:', { userId: user.id, username: user.username });

    // 세션 쿠키 설정 (간단한 구현, 실제로는 JWT나 세션 스토어 사용 권장)
    const cookieStore = await cookies();
    
    // 모바일 앱 호환성을 위해 쿠키 설정 조정
    const isProduction = process.env.NODE_ENV === 'production';
    const forwardedProto = request.headers.get('x-forwarded-proto');
    const isHttps = forwardedProto === 'https' || request.url.startsWith('https://');
    
    // sameSite: 'none'을 사용하려면 secure: true가 필수
    // 모바일 앱에서는 sameSite: 'lax' 또는 'none' 사용
    const cookieOptions: any = {
      httpOnly: true,
      maxAge: 60 * 60 * 24 * 7, // 7일
      path: '/',
    };

    if (isProduction && isHttps) {
      // 프로덕션 HTTPS 환경: secure + sameSite none (모바일 앱 호환)
      cookieOptions.secure = true;
      cookieOptions.sameSite = 'none';
    } else if (isProduction) {
      // 프로덕션 HTTP 환경: secure false + sameSite lax
      cookieOptions.secure = false;
      cookieOptions.sameSite = 'lax';
    } else {
      // 개발 환경: secure false + sameSite lax
      cookieOptions.secure = false;
      cookieOptions.sameSite = 'lax';
    }

    // 개발 환경에서 쿠키 설정 강화
    const finalCookieOptions = {
      httpOnly: true,
      maxAge: 60 * 60 * 24 * 7, // 7일
      path: '/',
      secure: false, // 개발 환경에서는 false
      sameSite: 'lax' as const,
    };

    cookieStore.set('userId', user.id, finalCookieOptions);
    console.log('[Login] 쿠키 설정 완료:', {
      userId: user.id,
      cookieOptions: finalCookieOptions,
      isProduction,
      isHttps
    });

    // 성공한 로그인은 Rate Limit 카운트에서 제외 (설정에 따라)
    const response = successResponse(
      {
        id: user.id,
        username: user.username,
        email: user.email,
        role: userRole, // 정규화된 role 사용
      },
      '로그인 성공'
    );

    // Rate Limit 헤더 추가
    if (rateLimitResult.remaining !== undefined && rateLimitResult.resetTime) {
      response.headers.set('X-RateLimit-Remaining', rateLimitResult.remaining.toString());
      response.headers.set('X-RateLimit-Reset', new Date(rateLimitResult.resetTime).toISOString());
    }

    return response;
  } catch (error: any) {
    console.error('로그인 실패:', error);
    return errorResponse(
      error.message || '로그인 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

