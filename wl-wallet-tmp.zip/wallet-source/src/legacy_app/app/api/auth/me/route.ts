import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'

// 현재 로그인한 사용자 정보 반환
export async function GET() {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json(
        { error: '로그인이 필요합니다.' },
        { status: 401 }
      )
    }

    return NextResponse.json({
      ok: true,
      data: user
    })
  } catch (error) {
    console.error('[Auth] 사용자 정보 조회 실패:', error)
    return NextResponse.json(
      { ok: false, error: '사용자 정보 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}