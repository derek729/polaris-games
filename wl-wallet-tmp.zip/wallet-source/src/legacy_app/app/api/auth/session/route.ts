import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { cookies } from 'next/headers';

export async function GET() {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get('userId')?.value;

    if (!userId) {
      return NextResponse.json({
        ok: false,
        authenticated: false,
        message: '로그인이 필요합니다.',
      });
    }

    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        rank: true,
        role: true,
        status: true,
        isActive: true,
      },
    });

    if (!user || !user.isActive || user.status !== 'ACTIVE') {
      // 유효하지 않은 세션
      cookieStore.delete('userId');
      return NextResponse.json({
        ok: false,
        authenticated: false,
        message: '유효하지 않은 세션입니다.',
      });
    }

    console.log('[API /auth/session] 사용자 정보:', {
      id: user.id,
      username: user.username,
      role: user.role,
      rank: user.rank,
      status: user.status,
      isActive: user.isActive,
    });

    return NextResponse.json({
      ok: true,
      authenticated: true,
      data: user,
    });
  } catch (error: any) {
    console.error('세션 확인 실패:', error);
    return NextResponse.json(
      { ok: false, error: error.message || '세션 확인 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

