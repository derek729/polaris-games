import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { successResponse, errorResponse, validationErrorResponse, handlePrismaError } from '@/lib/api-response';
import { isValidEmail, isValidPassword, isValidUsername, validateRequired } from '@/lib/validation';
import { cookies } from 'next/headers';
import { findSponsorWithSpillover } from '@/services/spillover';
import { generateUniqueReferralCode } from '@/lib/referral-code';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { username, email, password, referrerCode } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['username', 'email', 'password', 'referrerCode']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    // 사용자명 검증
    const usernameCheck = isValidUsername(username);
    if (!usernameCheck.valid) {
      return validationErrorResponse(usernameCheck.message || '사용자명이 유효하지 않습니다.');
    }

    // 이메일 검증
    if (!isValidEmail(email)) {
      return validationErrorResponse('올바른 이메일 형식이 아닙니다.');
    }

    // 비밀번호 검증
    const passwordCheck = isValidPassword(password);
    if (!passwordCheck.valid) {
      return validationErrorResponse(passwordCheck.message || '비밀번호가 유효하지 않습니다.');
    }

    // 중복 확인
    const existingUser = await prisma.users.findFirst({
      where: {
        OR: [{ username }, { email }],
      },
      select: {
        id: true,
        username: true,
        email: true,
      },
    });

    if (existingUser) {
      return errorResponse('이미 사용 중인 사용자명 또는 이메일입니다.', 409, 'DUPLICATE_ENTRY');
    }

    // 추천인 확인 (필수) - referralCode 또는 username으로 찾기
    const trimmedReferrerCode = referrerCode.trim().toUpperCase();
    const referrer = await prisma.users.findFirst({
      where: {
        OR: [
          { referralCode: trimmedReferrerCode },
          { username: trimmedReferrerCode },
        ],
      },
      select: { 
        id: true,
        isActive: true,
        status: true,
      },
    });
    
    if (!referrer) {
      return validationErrorResponse(`추천인 코드 "${trimmedReferrerCode}"에 해당하는 사용자를 찾을 수 없습니다.`);
    }
    
    if (!referrer.isActive || referrer.status !== 'ACTIVE') {
      return validationErrorResponse('활성 상태가 아닌 추천인입니다.');
    }
    
    const referrerId = referrer.id;

    // 스필오버 로직으로 후원인 자동 찾기
    const sponsorId = await findSponsorWithSpillover(referrerId);

    // 비밀번호 해싱
    const hashedPassword = await bcrypt.hash(password, 10);

    // 고유한 추천인 코드 생성
    const referralCode = await generateUniqueReferralCode();

    // 유저 생성
    let user;
    try {
      user = await prisma.1.create({{ data: {
          username,
          email,
          password: hashedPassword,
          referralCode, // 자동 생성된 추천인 코드
          referrerId,
          sponsorId, // 스필오버로 찾은 후원인
          status: 'ACTIVE',
          isActive: true,
        },
        select: {
          id: true,
          username: true,
          email: true,
          createdAt: true,
        },
      });
    } catch (error: any) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }

    // 세션 쿠키 설정 (회원가입 후 자동 로그인)
    const cookieStore = await cookies();
    cookieStore.set('userId', user.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7일
      path: '/',
    });

    return successResponse(user, '회원가입이 완료되었습니다.');
  } catch (error: any) {
    console.error('회원가입 실패:', error);
    
    // Prisma 에러 처리
    if (error.code?.startsWith('P')) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }
    
    return errorResponse(
      error.message || '회원가입 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

