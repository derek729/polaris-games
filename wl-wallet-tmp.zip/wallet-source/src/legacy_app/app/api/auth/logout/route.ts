import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

export async function POST() {
  try {
    const cookieStore = await cookies();
    // 일반 사용자 쿠키 삭제
    cookieStore.delete('userId');
    // 관리자 쿠키도 삭제 (혹시 모를 경우 대비)
    cookieStore.delete('adminUserId');
    cookieStore.delete('adminRole');

    return NextResponse.json({
      ok: true,
      message: '로그아웃되었습니다.',
    });
  } catch (error: any) {
    console.error('로그아웃 실패:', error);
    return NextResponse.json(
      { ok: false, error: error.message || '로그아웃 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

