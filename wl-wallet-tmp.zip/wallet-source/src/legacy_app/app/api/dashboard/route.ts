import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { checkUserRateLimit, rateLimitConfigs } from '@/lib/rate-limit'
import { unauthorizedResponse, errorResponse, successResponse } from '@/lib/api-response'
import { getDashboardData } from '@/lib/dashboard-data'

export async function GET(request: Request) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // Rate Limiting 체크 (사용자 기반)
    const rateLimitResult = await checkUserRateLimit(user.id, rateLimitConfigs.dashboard);
    if (!rateLimitResult.success) {
      return rateLimitResult.response!;
    }

    // 공통 함수를 사용하여 데이터 가져오기
    const dashboardDataResult = await getDashboardData(user.id);
    const totalInvestmentAmount = dashboardDataResult.stats.totalInvestment;
    const totalWithdrawalAmount = dashboardDataResult.totalWithdrawalAmount;

    const response = successResponse({
      users: {
        ...users,
        totalInvestment: totalInvestmentAmount,
        totalWithdrawals: totalWithdrawalAmount,
        _count: dashboardDataResult.userCounts,
        createdAt: user.createdAt.toISOString(),
      },
      stats: {
        ...dashboardDataResult.stats,
        availableBalance: Number(user.personalCoin || 0)
      },
      recentActivities: dashboardDataResult.recentActivities
    });

    // Rate Limit 헤더 추가
    if (rateLimitResult.remaining !== undefined && rateLimitResult.resetTime) {
      response.headers.set('X-RateLimit-Remaining', rateLimitResult.remaining.toString());
      response.headers.set('X-RateLimit-Reset', new Date(rateLimitResult.resetTime).toISOString());
    }

    return response;

  } catch (error: any) {
    console.error('[Dashboard] 데이터 조회 실패:', error)
    return errorResponse(
      error.message || '대시보드 데이터 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    )
  }
}
