import { NextResponse } from 'next/server';
import { Prisma } from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 최초 배포 환경에서 투자 상품(InvesmentTier)이 비어있는 경우가 많아
 * 기본 상품 4개를 자동으로 생성해주는 헬퍼입니다.
 */
async function ensureInvestmentTiers() {
  const existing = await prisma.investment_tiers.findMany({
    orderBy: { tier: 'asc' },
  });

  if (existing.length > 0) {
    return existing;
  }

  console.log('[Investment Products API] No investment tiers found. Creating default tiers...');

  const defaultTiers = [
    {
      id: 1,
      tier: 1,
      minAmount: new Prisma.Decimal(50),
      maxAmount: new Prisma.Decimal(99),
      dailyRate: new Prisma.Decimal(0.003), // 0.3%
      matchingDepth: 0,
      referralRates: [],
      description: '$50-$99: 초보 투자자 (매칭 보너스 없음)',
    },
    {
      id: 2,
      tier: 2,
      minAmount: new Prisma.Decimal(100),
      maxAmount: new Prisma.Decimal(999),
      dailyRate: new Prisma.Decimal(0.005), // 0.5%
      matchingDepth: 4,
      referralRates: [0.12, 0.08, 0.08, 0.08],
      description: '$100-$999: 일반 투자자 (1~4대 매칭 보너스)',
    },
    {
      id: 3,
      tier: 3,
      minAmount: new Prisma.Decimal(1000),
      maxAmount: new Prisma.Decimal(9999),
      dailyRate: new Prisma.Decimal(0.01), // 1%
      matchingDepth: 8,
      referralRates: [0.05, 0.05, 0.05, 0.05],
      description: '$1,000-$9,999: 고급 투자자 (5~8대 매칭 보너스)',
    },
    {
      id: 4,
      tier: 4,
      minAmount: new Prisma.Decimal(10000),
      maxAmount: new Prisma.Decimal(999999),
      dailyRate: new Prisma.Decimal(0.012), // 1.2%
      matchingDepth: 12,
      referralRates: [0.03, 0.03, 0.03, 0.03],
      description: '$10,000+: 최고 등급 투자자 (9~12대 매칭 보너스)',
    },
  ];

  await prisma.investment_tiers.createMany({
    data: defaultTiers,
    skipDuplicates: true,
  });

  console.log('[Investment Products API] Default investment tiers created.');

  return prisma.investment_tiers.findMany({
    orderBy: { tier: 'asc' },
  });
}

export async function GET(request: Request) {
  try {
    // 언어 확인 (쿼리 파라미터에서)
    const { searchParams } = new URL(request.url);
    const lang = searchParams.get('lang') || 'ko';
    const language = lang === 'en' ? 'en' : 'ko';
    
    // 디버깅용 로그
    console.log('[Investment Products API] Language:', language, 'lang param:', lang);

    // 투자 상품 목록 조회 (UI 디자인 기준 4개 상품)
    const tiers = await ensureInvestmentTiers();

    // 번역 데이터
    const productNames = {
      ko: {
        1: { name: '스타터 패키지', category: '단기', description: '스타터 패키지 - 초보 투자자를 위한 단기 상품' },
        2: { name: '비즈니스 패키지', category: '안정형', description: '비즈니스 패키지 - 안정적인 수익을 원하는 투자자를 위한 추천 상품' },
        3: { name: '프로페셔널 패키지', category: '고수익', description: '프로페셔널 패키지 - 고수익을 추구하는 투자자를 위한 상품' },
        4: { name: '엔터프라이즈 패키지', category: '고수익', description: '엔터프라이즈 패키지 - 최고 수익을 원하는 대형 투자자를 위한 프리미엄 상품' },
      },
      en: {
        1: { name: 'Starter Package', category: 'Short-term', description: 'Starter Package - Short-term product for beginner investors' },
        2: { name: 'Business Package', category: 'Stable', description: 'Business Package - Recommended product for investors seeking stable returns' },
        3: { name: 'Professional Package', category: 'High Yield', description: 'Professional Package - Product for investors pursuing high returns' },
        4: { name: 'Enterprise Package', category: 'High Yield', description: 'Enterprise Package - Premium product for large investors seeking maximum returns' },
      },
    };

    // UI 디자인에 맞게 변환 (이미지 기준: $1,000, $5,000, $10,000, $20,000)
    const products = tiers.map((tier) => {
      const dailyRate = decimalToNumber(tier.dailyRate);
      const annualRate = dailyRate * 365 * 100; // 연 수익률

      // 상품명 및 카테고리 결정 (언어별)
      const langData = productNames[language as 'ko' | 'en'];
      const tierKey = tier.tier as 1 | 2 | 3 | 4;
      
      // 언어별 상품 정보 가져오기 (없으면 한국어 폴백)
      let productInfo = langData?.[tierKey];
      if (!productInfo) {
        console.warn(`[Investment Products API] Product info not found for tier ${tier.tier} and language ${language}, using Korean fallback`);
        productInfo = productNames.ko[tierKey];
      }
      
      if (!productInfo) {
        console.error(`[Investment Products API] Product info not found for tier ${tier.tier} in any language`);
        // 최소한의 기본값 제공
        productInfo = { name: `Tier ${tier.tier}`, category: 'Unknown', description: '' };
      }
      
      // 디버깅: 실제 반환되는 값 확인
      console.log(`[Investment Products API] Tier ${tier.tier} (${language}):`, {
        name: productInfo.name,
        category: productInfo.category,
        description: productInfo.description?.substring(0, 30) + '...'
      });
      let recommended = false;
      let period = 180; // 기본 6개월
      let displayAmount = decimalToNumber(tier.minAmount); // 기본값

      // 보상 플랜 기준 상품 가격 설정
      if (tier.tier === 1) {
        displayAmount = 50; // 스타터 패키지: $50
        period = 180; // 6개월
      } else if (tier.tier === 2) {
        displayAmount = 100; // 비즈니스 패키지: $100
        recommended = true;
        period = 365; // 12개월
      } else if (tier.tier === 3) {
        displayAmount = 1000; // 프로페셔널 패키지: $1,000
        period = 730; // 24개월
      } else if (tier.tier === 4) {
        displayAmount = 10000; // 엔터프라이즈 패키지: $10,000
        period = 730; // 24개월
      }

      const product = {
        id: tier.id,
        tier: tier.tier,
        name: productInfo.name,
        amount: displayAmount,
        dailyRate,
        annualRate: Math.round(annualRate * 10) / 10, // 소수점 1자리
        period,
        category: productInfo.category,
        recommended,
        matchingDepth: tier.matchingDepth,
        description: productInfo.description,
      };
      
      // 디버깅: 실제 반환되는 값 확인 (Tier 1만 로그)
      if (tier.tier === 1) {
        console.log(`[Investment Products API] Tier 1 (${language}):`, {
          name: product.name,
          category: product.category,
          description: product.description?.substring(0, 40) + '...'
        });
      }
      
      return product;
    });

    console.log('[Investment Products API] Final products summary:', products.map(p => ({
      tier: p.tier,
      name: p.name,
      category: p.category
    })));

    return successResponse(products);
  } catch (error: any) {
    console.error('[Investment Products] 상품 조회 실패:', error);
    return errorResponse(
      error.message || '투자 상품 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

