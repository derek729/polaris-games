import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';
import { Prisma } from '@prisma/client';

/**
 * 게임에서 재화 사용 (차감)
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { gameId, amount, currencyType } = body; // currencyType: 'MSUO' | 'COIN'

    const requiredCheck = validateRequired(body, ['gameId', 'amount', 'currencyType']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    const deductAmount = new Prisma.Decimal(amount);
    if (deductAmount.lessThanOrEqualTo(0)) {
      return validationErrorResponse('사용할 금액은 0보다 커야 합니다.');
    }

    // 현재 사용자 잔액 확인
    const currentUser = await prisma.users.findUnique({
      where: { id: user.id },
      select: { personalCoin: true },
    });

    if (!currentUser) {
      return errorResponse('사용자를 찾을 수 없습니다.', 404, 'USER_NOT_FOUND');
    }

    const currentBalance = new Prisma.Decimal(currentUser.personalCoin || 0);
    if (currentBalance.lessThan(deductAmount)) {
      return errorResponse('잔액이 부족합니다.', 400, 'INSUFFICIENT_BALANCE');
    }

    // 잔액 차감
    const updatedUser = await prisma.users.update({
      where: { id: user.id },
      data: {
        personalCoin: { decrement: deductAmount },
      },
      select: {
        personalCoin: true,
      },
    });

    return successResponse({
      newBalance: Number(updatedUser.personalCoin),
      message: '재화가 차감되었습니다.',
    });
  } catch (error: any) {
    console.error('[Use Game Balance] Error:', error);
    return errorResponse(
      error.message || '재화 사용 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}


