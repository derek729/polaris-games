import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 게임에서 사용할 사용자 잔액 조회
 */
export async function GET(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 최신 사용자 정보 조회
    const currentUser = await prisma.users.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        personalCoin: true,
      },
    });

    if (!currentUser) {
      return errorResponse('사용자를 찾을 수 없습니다.', 404, 'USER_NOT_FOUND');
    }

    return successResponse({
      upccoin: decimalToNumber(currentUser.personalCoin),
      aocoin: decimalToNumber(currentUser.personalCoin), // 하위 호환성
      coin: decimalToNumber(currentUser.personalCoin), // 오셀로/마작용 코인 (현재는 personalCoin과 동일)
    });
  } catch (error: any) {
    console.error('[Get Game Balance] Error:', error);
    return errorResponse(
      error.message || '잔액 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

