import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';
import { Prisma } from '@prisma/client';

/**
 * 게임에서 재화 획득 (증가)
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { gameId, amount, currencyType } = body; // currencyType: 'MSUO' | 'COIN'

    const requiredCheck = validateRequired(body, ['gameId', 'amount', 'currencyType']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    const addAmount = new Prisma.Decimal(amount);
    if (addAmount.lessThanOrEqualTo(0)) {
      return validationErrorResponse('획득할 금액은 0보다 커야 합니다.');
    }

    // 잔액 증가
    const updatedUser = await prisma.users.update({
      where: { id: user.id },
      data: {
        personalCoin: { increment: addAmount },
      },
      select: {
        personalCoin: true,
      },
    });

    return successResponse({
      newBalance: Number(updatedUser.personalCoin),
      message: '재화가 추가되었습니다.',
    });
  } catch (error: any) {
    console.error('[Add Game Balance] Error:', error);
    return errorResponse(
      error.message || '재화 추가 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}


