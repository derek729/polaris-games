import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { getCurrentUser } from '@/lib/auth';
import { validateAndApplyMembershipCode, recordMembershipCodeUsage } from '@/services/membershipCode';
import { checkUserMembership, calculateGameShareDiscountRate } from '@/services/membershipCheck';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 게임 지분 구매
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return errorResponse('로그인이 필요합니다.', 401, 'UNAUTHORIZED');
    }

    const userId = user.id;
    const body = await request.json();
    const { gameShareId, shareCount, txHash, membershipCode, paymentPeriod } = body;

    // 필수 필드 검증
    if (!gameShareId || !shareCount || !txHash) {
      return validationErrorResponse('게임 지분 ID, 구매 수량, 트랜잭션 해시는 필수입니다.');
    }

    if (shareCount <= 0 || !Number.isInteger(shareCount)) {
      return validationErrorResponse('구매 수량은 1 이상의 정수여야 합니다.');
    }

    // 게임 지분 상품 조회
    const gameShare = await prisma.game_shares.findUnique({
      where: { id: gameShareId },
      include: {
        games: true,
      },
    });

    if (!gameShare) {
      return validationErrorResponse('게임 지분 상품을 찾을 수 없습니다.');
    }

    if (!gameShare.isActive || !gameShare.games.isActive) {
      return validationErrorResponse('비활성화된 게임 지분 상품입니다.');
    }

    // 게임의 기본 지급 주기 사용 (관리자가 설정한 주기)
    const gameDefaultPeriod = gameShare.games.defaultPaymentPeriod || 'DAILY';
    const validPeriods = ['DAILY', 'WEEKLY', 'MONTHLY'];
    
    // 사용자가 선택한 주기가 있으면 검증, 없으면 게임의 기본 주기 사용
    let selectedPeriod = paymentPeriod || gameDefaultPeriod;
    if (!validPeriods.includes(selectedPeriod)) {
      selectedPeriod = gameDefaultPeriod; // 유효하지 않으면 게임 기본 주기 사용
    }

    // 구매 가능 수량 확인
    if (shareCount > gameShare.availableShares) {
      return validationErrorResponse(
        `구매 가능한 지분 수가 부족합니다. (가능: ${gameShare.availableShares}개, 요청: ${shareCount}개)`
      );
    }

    // 총 가격 계산
    let originalPrice = gameShare.price.mul(shareCount);
    let totalPrice = originalPrice;
    let discountAmount = new Prisma.Decimal(0);
    let membershipCodeId: string | null = null;

    // 멤버쉽 패키지 가입 여부 확인
    const membershipStatus = await checkUserMembership(userId);
    
    // 멤버쉽 가입자만 할인 적용
    if (membershipStatus.isMember && membershipStatus.membershipAmount && membershipStatus.discountRate) {
      const purchaseAmount = decimalToNumber(originalPrice);
      const discountRate = calculateGameShareDiscountRate(
        membershipStatus.membershipAmount,
        purchaseAmount
      );
      
      if (discountRate > 0) {
        discountAmount = originalPrice.mul(new Prisma.Decimal(discountRate));
        totalPrice = originalPrice.minus(discountAmount);
      }
    }

    // 멤버쉽 코드가 입력된 경우, 코드의 할인률과 멤버쉽 할인률 중 큰 값 사용
    if (membershipCode && typeof membershipCode === 'string' && membershipCode.trim()) {
      const codeValidation = await validateAndApplyMembershipCode(
        membershipCode.trim(),
        originalPrice,
        userId
      );

      if (!codeValidation.valid) {
        return validationErrorResponse(codeValidation.error || '멤버쉽 코드가 유효하지 않습니다.');
      }

      // 코드 할인률과 멤버쉽 할인률 중 큰 값 사용
      const codeDiscountRate = codeValidation.discountRate || new Prisma.Decimal(0);
      const membershipDiscountRate = membershipStatus.discountRate 
        ? new Prisma.Decimal(membershipStatus.discountRate) 
        : new Prisma.Decimal(0);
      const finalDiscountRate = codeDiscountRate.gt(membershipDiscountRate) 
        ? codeDiscountRate 
        : membershipDiscountRate;
      
      discountAmount = originalPrice.mul(finalDiscountRate);
      totalPrice = originalPrice.minus(discountAmount);

      const membershipCodeRecord = await prisma.membership_codes.findUnique({
        where: { code: membershipCode.toUpperCase().trim() },
        select: { id: true },
      });
      membershipCodeId = membershipCodeRecord?.id || null;
    }

    // 트랜잭션 해시 중복 확인
    if (txHash) {
      const existingPurchase = await prisma.game_share_purchases.findUnique({
        where: { txHash },
      });

      if (existingPurchase) {
        return validationErrorResponse('이미 사용된 트랜잭션 해시입니다.');
      }
    }

    // 구매 신청 처리 (PENDING 상태로 생성, 관리자 승인 대기)
    const purchase = await prisma.1.create({{ data: {
        userId,
        gameId: gameShare.gameId,
        gameShareId,
        sharePercentage: gameShare.sharePercentage,
        purchasePrice: totalPrice,
        shareCount,
        membershipCodeId,
        originalPrice: discountAmount.gt(0) ? originalPrice : null,
        discountAmount: discountAmount.gt(0) ? discountAmount : null,
        paymentPeriod: selectedPeriod,
        txHash: txHash.trim(),
        status: 'PENDING', // 관리자 승인 대기 상태
      },
    });

    // 멤버쉽 코드 사용 기록
    if (membershipCodeId && discountAmount.gt(0)) {
      try {
        await recordMembershipCodeUsage(
          membershipCodeId,
          userId,
          null, // investmentId는 null
          purchase.id, // gameSharePurchaseId
          gameShare.price.mul(shareCount), // 원래 가격
          discountAmount,
          totalPrice // 최종 가격
        );
      } catch (error) {
        console.error('[Game Purchase] 멤버쉽 코드 사용 기록 실패:', error);
      }
    }

    return successResponse(
      {
        purchaseId: purchase.id,
        gameId: purchase.gameId,
        gameShareId: purchase.gameShareId,
        shareCount: purchase.shareCount,
        sharePercentage: decimalToNumber(purchase.sharePercentage) * 100,
        purchasePrice: decimalToNumber(purchase.purchasePrice),
        discountAmount: decimalToNumber(discountAmount),
        paymentPeriod: purchase.paymentPeriod,
        status: purchase.status,
        purchasedAt: purchase.purchasedAt,
      },
      `게임 지분 구매 신청이 접수되었습니다. 관리자 승인 후 활성화됩니다.`
    );
  } catch (error: any) {
    console.error('[User Game Purchase] 게임 지분 구매 실패:', error);
    return errorResponse(error.message || '게임 지분 구매 중 오류가 발생했습니다.', 500);
  }
}


