import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 사용자용 게임 목록 조회 (활성 게임만)
export async function GET(request: Request) {
  try {
    const games = await prisma.games.findMany({
      where: { isActive: true },
      include: {
        game_shares: {
          where: { isActive: true },
          orderBy: { sharePercentage: 'asc' },
        },
        _count: {
          select: {
            game_share_purchases: {
              where: { status: 'COMPLETED' },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return successResponse(
      games.map((game) => ({
        id: game.id,
        name: game.name,
        description: game.description,
        imageUrl: game.imageUrl,
        defaultPaymentPeriod: game.defaultPaymentPeriod,
        game_shares: game.game_shares.map((share) => ({
          id: share.id,
          sharePercentage: decimalToNumber(share.sharePercentage) * 100,
          price: decimalToNumber(share.price),
          availableShares: share.availableShares,
          totalShares: share.totalShares,
        })),
        purchaseCount: game._count.game_share_purchases,
      }))
    );
  } catch (error: any) {
    console.error('[User Games] 게임 목록 조회 실패:', error);
    return errorResponse(error.message || '게임 목록 조회 중 오류가 발생했습니다.', 500);
  }
}

