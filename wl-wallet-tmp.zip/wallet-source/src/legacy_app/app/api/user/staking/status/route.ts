import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';

/**
 * 사용자의 스테이킹 상태 조회
 */
export async function GET(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 활성 스테이킹 조회
    const activeStaking = await prisma.staking_records.findMany({
      where: {
        userId: user.id,
        status: 'ACTIVE',
      },
      orderBy: { stakedAt: 'desc' },
    });

    // 스테이킹 통계
    const stakingStats = await prisma.staking_records.aggregate({
      where: { userId: user.id },
      _sum: {
        stakedAmount: true,
        rewardAmount: true,
      },
      _count: { id: true },
    });

    const totalStaked = Number(stakingStats._sum.stakedAmount || 0);
    const totalRewards = Number(stakingStats._sum.rewardAmount || 0);
    const totalRecords = stakingStats._count.id || 0;

    return successResponse({
      activeStaking: activeStaking.map((s) => ({
        id: s.id,
        stakedAmount: Number(s.stakedAmount),
        rewardAmount: Number(s.rewardAmount),
        apy: s.apy ? Number(s.apy) : null,
        startDate: s.startDate,
        endDate: s.endDate,
        lockPeriod: s.lockPeriod,
        txHash: s.txHash,
        status: s.status,
      })),
      stats: {
        totalStaked,
        totalRewards,
        totalRecords,
        activeCount: activeStaking.length,
      },
    });
  } catch (error: any) {
    console.error('[Staking Status] Error:', error);
    return errorResponse(
      error.message || '스테이킹 상태 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

