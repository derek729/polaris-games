import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { generateTransactionHash } from '@/services/mainnet-api';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';
import { Prisma } from '@prisma/client';

/**
 * 스테이킹 시작
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { amount, mainnetAddress, lockPeriod, apy, angelLockAmount } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['amount', 'mainnetAddress']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    const stakedAmount = new Prisma.Decimal(amount);
    const angelLock = new Prisma.Decimal(angelLockAmount || 0);
    const userBalance = new Prisma.Decimal(user.personalCoin || 0);
    
    // 엔젤 물량 락 금액이 스테이킹 금액보다 클 수 없음
    if (angelLock.gt(stakedAmount)) {
      return validationErrorResponse('엔젤 물량 락 금액은 스테이킹 금액보다 클 수 없습니다.');
    }

    // 잔액 확인
    if (userBalance.lt(stakedAmount)) {
      return errorResponse('잔액이 부족합니다.', 400, 'INSUFFICIENT_BALANCE');
    }

    // 최소 스테이킹 금액 확인 (예: 1,000 MSUO)
    const minStake = new Prisma.Decimal(1000);
    if (stakedAmount.lt(minStake)) {
      return errorResponse(`최소 스테이킹 금액은 ${minStake.toString()} MSUO입니다.`, 400, 'INVALID_AMOUNT');
    }

    // 트랜잭션 해시 생성
    const txHash = generateTransactionHash({
      userId: user.id,
      type: 'STAKING',
      amount: Number(stakedAmount),
      timestamp: Date.now(),
    });

    // 스테이킹 기록 생성 및 잔액 차감 (타임아웃 30초)
    const result = await prisma.$transaction(async (tx) => {
      // 1. 잔액 차감
      await tx.users.update({
        where: { id: user.id },
        data: {
          personalCoin: { decrement: stakedAmount },
        },
      });

      // 2. 스테이킹 기록 생성
      const stakingRecord = await tx.staking_records.create({
        data: {
          userId: user.id,
          mainnetAddress,
          stakedAmount,
          angelLockAmount: angelLock,
          apy: apy ? new Prisma.Decimal(apy) : null,
          lockPeriod: lockPeriod || null,
          endDate: lockPeriod ? new Date(Date.now() + lockPeriod * 24 * 60 * 60 * 1000) : null,
          txHash,
          status: 'ACTIVE',
          confirmations: 0,
        },
      });

      return stakingRecord;
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    return successResponse({
      message: '스테이킹이 시작되었습니다.',
      staking_records: {
        id: result.id,
        txHash: result.txHash,
        stakedAmount: Number(result.stakedAmount),
        angelLockAmount: Number(result.angelLockAmount),
        apy: result.apy ? Number(result.apy) : null,
        lockPeriod: result.lockPeriod,
        startDate: result.startDate,
        endDate: result.endDate,
      },
    });
  } catch (error: any) {
    console.error('[Start Staking] Error:', error);
    return errorResponse(
      error.message || '스테이킹 시작 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}


