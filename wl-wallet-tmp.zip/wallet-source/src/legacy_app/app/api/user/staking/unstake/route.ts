import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { generateTransactionHash } from '@/services/mainnet-api';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';
import { Prisma } from '@prisma/client';

/**
 * 언스테이킹 (스테이킹 해제)
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { stakingRecordId } = body;

    // 필수 필드 검증
    if (!stakingRecordId) {
      return validationErrorResponse('스테이킹 기록 ID가 필요합니다.');
    }

    // 스테이킹 기록 조회
    const stakingRecord = await prisma.staking_records.findUnique({
      where: { id: stakingRecordId },
    });

    if (!stakingRecord) {
      return errorResponse('스테이킹 기록을 찾을 수 없습니다.', 404, 'NOT_FOUND');
    }

    if (stakingRecord.userId !== user.id) {
      return unauthorizedResponse('권한이 없습니다.');
    }

    if (stakingRecord.status !== 'ACTIVE') {
      return errorResponse('활성화된 스테이킹만 해제할 수 있습니다.', 400, 'INVALID_STATUS');
    }

    // 락업 기간 확인
    if (stakingRecord.endDate && new Date() < stakingRecord.endDate) {
      return errorResponse('락업 기간이 아직 끝나지 않았습니다.', 400, 'LOCKED');
    }

    // 언스테이킹 트랜잭션 해시 생성
    const unstakeTxHash = generateTransactionHash({
      userId: user.id,
      type: 'UNSTAKING',
      amount: Number(stakingRecord.stakedAmount),
      timestamp: Date.now(),
    });

    // 언스테이킹 처리 및 잔액 반환 (타임아웃 30초)
    const result = await prisma.$transaction(async (tx) => {
      // 1. 스테이킹 기록 업데이트
      const updatedRecord = await tx.staking_records.update({
        where: { id: stakingRecordId },
        data: {
          status: 'UNSTAKING',
          unstakeTxHash,
          unstakedAt: new Date(),
        },
      });

      // 2. 잔액 반환 (스테이킹 금액 + 보상)
      const totalAmount = new Prisma.Decimal(stakingRecord.stakedAmount).plus(
        new Prisma.Decimal(stakingRecord.rewardAmount || 0)
      );

      await tx.users.update({
        where: { id: user.id },
        data: {
          personalCoin: { increment: totalAmount },
        },
      });

      return updatedRecord;
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    return successResponse({
      message: '언스테이킹이 완료되었습니다.',
      unstakingRecord: {
        id: result.id,
        unstakeTxHash: result.unstakeTxHash,
        stakedAmount: Number(result.stakedAmount),
        rewardAmount: Number(result.rewardAmount),
        totalReturned: Number(result.stakedAmount) + Number(result.rewardAmount),
      },
    });
  } catch (error: any) {
    console.error('[Unstake] Error:', error);
    return errorResponse(
      error.message || '언스테이킹 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}


