import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { distributeReferralBonus } from '@/services/referralBonus';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse } from '@/lib/api-response';
import { validateRequired, isValidInvestmentAmount } from '@/lib/validation';
import { checkUserRateLimit, rateLimitConfigs } from '@/lib/rate-limit';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 투자 등급 산정 함수
 * @param amount 투자 금액
 * @returns { investment_tiers: number, dailyRate: number, matchingDepth: number }
 */
function calculateInvestmentTier(amount: Decimal) {
  const amountNum = decimalToNumber(amount);

  // 이미지 기준에 맞게 수정:
  // 50$: 0.3% (리워드 적용 범위 미지정 - 최소 투자금액이므로 매칭 보너스 없음)
  // 100$: 0.5% (1~4대)
  // 1,000$: 1% (5~8대)
  // 10,000$: 1.2% (9~12대)
  if (amountNum >= 50 && amountNum <= 99) {
    return { investment_tiers: 1, dailyRate: 0.003, matchingDepth: 0 }; // 0.3%, 매칭 보너스 없음
  } else if (amountNum >= 100 && amountNum <= 499) {
    return { investment_tiers: 2, dailyRate: 0.005, matchingDepth: 4 }; // 0.5%, 1~4대
  } else if (amountNum >= 500 && amountNum <= 999) {
    return { investment_tiers: 3, dailyRate: 0.005, matchingDepth: 4 }; // 0.5%, 1~4대 (100$와 동일)
  } else if (amountNum >= 1000 && amountNum <= 4999) {
    return { investment_tiers: 4, dailyRate: 0.010, matchingDepth: 8 }; // 1.0%, 5~8대
  } else if (amountNum >= 5000 && amountNum <= 9999) {
    return { investment_tiers: 5, dailyRate: 0.010, matchingDepth: 8 }; // 1.0%, 5~8대 (1,000$와 동일)
  } else if (amountNum >= 10000) {
    return { investment_tiers: 6, dailyRate: 0.012, matchingDepth: 12 }; // 1.2%, 9~12대
  } else {
    throw new Error('최소 투자 금액은 $50입니다.');
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, amount, txHash } = body;

    // Rate Limiting 체크 (사용자 기반)
    if (userId) {
      const rateLimitResult = await checkUserRateLimit(userId, rateLimitConfigs.investment);
      if (!rateLimitResult.success) {
        return rateLimitResult.response;
      }
    }

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['userId', 'amount', 'txHash']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    // 투자 금액 검증
    const amountCheck = isValidInvestmentAmount(amount);
    if (!amountCheck.valid) {
      return validationErrorResponse(amountCheck.message || '투자 금액이 유효하지 않습니다.');
    }

    const investmentAmount = new Prisma.Decimal(amount);

    // 투자 등급 산정
    let tierInfo;
    try {
      tierInfo = calculateInvestmentTier(investmentAmount);
    } catch (error: any) {
      return NextResponse.json(
        { ok: false, error: error.message },
        { status: 400 }
      );
    }

    console.log(`💼 [Investment] 투자 신청(USDT): 유저 ${userId}, 금액 $${investmentAmount}, 티어 ${tierInfo.investmentTier}, TXID: ${txHash}`);

    // 1. 유저 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return notFoundResponse('사용자를 찾을 수 없습니다.');
    }

    // 2. 투자 종료일 계산 (1년 후)
    const endDate = new Date();
    endDate.setFullYear(endDate.getFullYear() + 1);

    // 3. 투자 레코드 생성 (PENDING 상태)
    const investment = await prisma.1.create({{ data: {
        userId,
        amount: investmentAmount,
        dailyRate: new Prisma.Decimal(tierInfo.dailyRate),
        matchingDepth: tierInfo.matchingDepth,
        investment_tiers: tierInfo.investmentTier,
        startDate: new Date(),
        endDate,
        isActive: false, // 승인 전에는 비활성
        status: 'PENDING',
      },
    });

    console.log(`✅ [Investment] 투자 신청 접수 완료: ID ${investment.id}`);

    const response = successResponse(
      {
        investmentId: investment.id,
        amount: decimalToNumber(investment.amount),
        status: 'PENDING',
        createdAt: investment.createdAt,
      },
      '투자 신청이 접수되었습니다. 관리자 승인 후 활성화됩니다.'
    );

    // Rate Limit 헤더 추가 (userId가 있는 경우)
    if (userId) {
      const rateLimitResult = await checkUserRateLimit(userId, rateLimitConfigs.investment);
      if (rateLimitResult.remaining !== undefined && rateLimitResult.resetTime) {
        response.headers.set('X-RateLimit-Remaining', rateLimitResult.remaining.toString());
        response.headers.set('X-RateLimit-Reset', new Date(rateLimitResult.resetTime).toISOString());
      }
    }

    return response;
  } catch (error: any) {
    console.error('[Investment] 투자 신청 실패:', error);

    // 에러 타입에 따라 적절한 상태 코드 및 메시지 설정
    if (error.message === 'USER_NOT_FOUND') {
      return notFoundResponse('사용자를 찾을 수 없습니다.');
    }

    if (error.message?.includes('부족') || error.message?.includes('최소')) {
      return validationErrorResponse(error.message);
    }

    return errorResponse(
      error.message || '투자 신청 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

// 사용자 투자 내역 조회
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { ok: false, error: 'userId가 필요합니다.' },
        { status: 400 }
      );
    }

    // 활성 투자 내역 조회
    const investments = await prisma.investments.findMany({
      where: {
        userId,
        isActive: true
      },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        amount: true,
        dailyRate: true,
        matchingDepth: true,
        investment_tiers: true,
        startDate: true,
        endDate: true,
        isActive: true,
        createdAt: true,
      },
    });

    return successResponse(
      investments.map((inv) => ({
        id: inv.id,
        amount: decimalToNumber(inv.amount),
        dailyRate: decimalToNumber(inv.dailyRate),
        matchingDepth: inv.matchingDepth,
        investment_tiers: inv.investmentTier,
        startDate: inv.startDate,
        endDate: inv.endDate,
        isActive: inv.isActive,
        createdAt: inv.createdAt,
        dailyProfit: decimalToNumber(inv.amount.mul(inv.dailyRate)), // 일일 예상 수익
      }))
    );
  } catch (error: any) {
    console.error('[Investment] 투자 내역 조회 실패:', error);
    return errorResponse(
      error.message || '투자 내역 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}
