import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, validationErrorResponse, unauthorizedResponse, notFoundResponse } from '@/lib/api-response';
import { validateRequired, isValidAmount, isValidEmail } from '@/lib/validation';

const decimalToNumber = (value: Decimal | null) => Number(value?.toString() ?? 0);

// 이체 가스수수료 (OZ COIN 고정 0.01개)
const TRANSFER_GAS_FEE = 0.01;

// 이체 한도 설정 (환경 변수에서 읽어오기)
const MIN_TRANSFER_AMOUNT = Number(process.env.MIN_TRANSFER_AMOUNT) || 1;

export async function POST(request: Request) {
  try {
    // 현재 로그인한 유저 확인
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { receiverEmail, amount, password } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['receiverEmail', 'amount', 'password']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    // 이메일 형식 검증
    if (!isValidEmail(receiverEmail)) {
      return validationErrorResponse('올바른 이메일 형식이 아닙니다.');
    }

    // 금액 검증
    const amountCheck = isValidAmount(amount);
    if (!amountCheck.valid) {
      return validationErrorResponse(amountCheck.message || '이체 금액이 유효하지 않습니다.');
    }

    // 금액을 숫자로 변환 및 검증
    let numAmount: number;
    try {
      numAmount = typeof amount === 'string' ? parseFloat(amount) : Number(amount);
      if (isNaN(numAmount) || !isFinite(numAmount)) {
        return validationErrorResponse('유효한 숫자 형식이 아닙니다.');
      }
    } catch (error) {
      return validationErrorResponse('금액 변환 중 오류가 발생했습니다.');
    }

    const transferAmount = new Prisma.Decimal(numAmount.toFixed(8)); // 소수점 8자리로 제한
    const gasFeeOzCoin = TRANSFER_GAS_FEE; // OZ COIN 가스수수료 (고정)
    const totalDeduct = transferAmount; // MSUO는 전송금액만 차감

    // 최소 이체 금액 체크
    if (transferAmount.lt(MIN_TRANSFER_AMOUNT)) {
      return validationErrorResponse(`최소 이체 금액은 ${MIN_TRANSFER_AMOUNT} MSUO입니다.`);
    }

    // 본인에게 전송 불가
    if (receiverEmail.toLowerCase() === currentUser.email?.toLowerCase()) {
      return validationErrorResponse('본인에게는 이체할 수 없습니다.');
    }

    // 비밀번호 확인
    const user = await prisma.users.findUnique({
      where: { id: currentUser.id },
      select: {
        password: true,
        personalCoin: true,
      },
    });

    if (!user || !user.password) {
      return notFoundResponse('유저 정보를 찾을 수 없습니다.');
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return unauthorizedResponse('비밀번호가 올바르지 않습니다.');
    }

    // 잔액 확인
    const currentBalance = new Prisma.Decimal(user.personalCoin);
    if (currentBalance.lt(totalDeduct)) {
      return validationErrorResponse(
        `MSUO 잔고가 부족합니다. (보유: ${decimalToNumber(currentBalance)} MSUO, 필요: ${decimalToNumber(totalDeduct)} MSUO)`
      );
    }

    // OZ 코인 잔액 확인
    const userWithOzCoin = await prisma.users.findUnique({
      where: { id: currentUser.id },
      select: { ozCoin: true },
    });

    if (!userWithOzCoin) {
      return notFoundResponse('유저 정보를 찾을 수 없습니다.');
    }

    const ozCoinBalance = new Prisma.Decimal(userWithOzCoin.ozCoin || 0);
    if (ozCoinBalance.lt(gasFeeOzCoin)) {
      return validationErrorResponse(
        `OZ COIN 잔고가 부족합니다. (보유: ${decimalToNumber(ozCoinBalance)} OZ, 필요: ${gasFeeOzCoin} OZ)`
      );
    }

    // 받는 사람 확인 및 검증 강화
    const receiver = await prisma.users.findUnique({
      where: { email: receiverEmail },
      select: {
        id: true,
        username: true,
        email: true,
        isActive: true,
        status: true,
        walletAddress: true,
        rank: true,
        createdAt: true
      },
    });

    if (!receiver) {
      return notFoundResponse('받는 사람을 찾을 수 없습니다.');
    }

    // 계정 상태 검증
    if (!receiver.isActive || receiver.status !== 'ACTIVE') {
      return errorResponse('비활성화된 계정입니다.', 403, 'FORBIDDEN');
    }

    // 추가 검증: 지갑 주소 확인 (보안 강화)
    if (!receiver.walletAddress) {
      return errorResponse('받는 사람의 지갑 주소가 설정되지 않았습니다.', 400, 'INVALID_RECEIVER');
    }

    // 계정 생성일 검증 (최소 24시간 경과)
    const accountAge = Date.now() - receiver.createdAt.getTime();
    const minAccountAge = 24 * 60 * 60 * 1000; // 24시간
    if (accountAge < minAccountAge) {
      return errorResponse('받는 사람의 계정이 너무 최근에 생성되었습니다. 보안을 위해 24시간 후에 시도해주세요.', 400, 'ACCOUNT_TOO_NEW');
    }

    // 트랜잭션으로 이체 처리 (타임아웃 30초)
    const result = await prisma.$transaction(async (tx) => {
      // 잔액 재확인 (동시성 제어)
      const sender = await tx.users.findUnique({
        where: { id: currentUser.id },
        select: { personalCoin: true, ozCoin: true },
      });
      if (!sender || new Prisma.Decimal(sender.personalCoin).lt(totalDeduct)) {
        throw new Error('잔액이 부족합니다. 다시 시도해주세요.');
      }
      if (!sender || new Prisma.Decimal(sender.ozCoin || 0).lt(gasFeeOzCoin)) {
        throw new Error('OZ COIN 잔액이 부족합니다. 다시 시도해주세요.');
      }

      // 1. 보내는 사람 MSUO 및 OZ COIN 잔액 차감
      await tx.users.update({
        where: { id: currentUser.id },
        data: {
          personalCoin: { decrement: totalDeduct }, // MSUO 전송금액만 차감
          ozCoin: { decrement: gasFeeOzCoin }, // OZ COIN 수수료 차감
        },
      });

      // 2. 받는 사람 MSUO 잔액 증가
      await tx.users.update({
        where: { id: receiver.id },
        data: {
          personalCoin: { increment: transferAmount },
        },
      });

      // 3. 이체 기록 생성
      const transfer = await tx.transfers.create({
        data: {
          senderId: currentUser.id,
          receiverId: receiver.id,
          amount: transferAmount,
          fee: new Prisma.Decimal(gasFeeOzCoin), // OZ COIN 가스수수료 기록
        },
      });

      return transfer;
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    console.log(
      `✅ [Transfer] ${currentUser.username} → ${receiver.username}: ${transferAmount.toFixed(2)} MSUO (수수료: ${gasFeeOzCoin.toFixed(2)} OZCOIN)`
    );

    return successResponse(
      {
        id: result.id,
        receiver: {
          username: receiver.username,
          email: receiver.email,
        },
        amount: decimalToNumber(transferAmount),
        fee: decimalToNumber(gasFeeOzCoin),
        totalDeduct: decimalToNumber(totalDeduct),
        transferredAt: result.transferredAt,
      },
      '이체가 완료되었습니다.'
    );
  } catch (error: unknown) {
    console.error('[Transfer] 이체 실패:', error);

    // 에러 타입에 따라 적절한 응답
    if (error instanceof Error) {
      const message = error.message;

      if (message.includes('잔액이 부족') || message.includes('부족')) {
        return validationErrorResponse(message);
      }

      if (message.includes('찾을 수 없') || message.includes('not found')) {
        return notFoundResponse(message);
      }

      if (message.includes('비밀번호') || message.includes('password')) {
        return unauthorizedResponse(message);
      }

      if (message.includes('timeout') || message.includes('타임아웃')) {
        return errorResponse('이체 처리 시간이 초과되었습니다. 다시 시도해주세요.', 408, 'TIMEOUT');
      }

      // Prisma 관련 오류
      if (message.includes('P2002')) {
        return errorResponse('데이터베이스 제약 조건 위반입니다.', 400, 'CONSTRAINT_VIOLATION');
      }

      if (message.includes('P2028')) {
        return errorResponse('트랜잭션 시간이 초과되었습니다.', 408, 'TRANSACTION_TIMEOUT');
      }

      return errorResponse(message, 500, 'SERVER_ERROR');
    }

    return errorResponse('이체 중 알 수 없는 오류가 발생했습니다.', 500, 'UNKNOWN_ERROR');
  }
}

// 이체 내역 조회
export async function GET(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type'); // 'sent' | 'received' | 'all'

    let whereClause: Record<string, unknown> = {};

    if (type === 'sent') {
      whereClause = { senderId: currentUser.id };
    } else if (type === 'received') {
      whereClause = { receiverId: currentUser.id };
    } else {
      // all: 보낸 것과 받은 것 모두
      whereClause = {
        OR: [{ senderId: currentUser.id }, { receiverId: currentUser.id }],
      };
    }

    const transfers = await prisma.transfers.findMany({
      where: whereClause,
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            email: true,
            walletAddress: true,
            rank: true,
          },
        },
        receiver: {
          select: {
            id: true,
            username: true,
            email: true,
            walletAddress: true,
            rank: true,
          },
        },
      },
      orderBy: { transferredAt: 'desc' },
      take: 50, // 최근 50건
    });

    return successResponse(
      transfers.map((t) => ({
        id: t.id,
        type: t.senderId === currentUser.id ? 'sent' : 'received',
        status: 'completed', // 모든 전송은 완료 상태
        sender: {
          id: t.users.id,
          username: t.users.username,
          email: t.users.email,
          walletAddress: t.users.walletAddress,
          rank: t.users.rank,
        },
        receiver: {
          id: t.users.id,
          username: t.users.username,
          email: t.users.email,
          walletAddress: t.users.walletAddress,
          rank: t.users.rank,
        },
        amount: decimalToNumber(t.amount),
        fee: decimalToNumber(t.fee),
        totalAmount: decimalToNumber(t.amount) + decimalToNumber(t.fee),
        transferredAt: t.transferredAt,
        confirmations: 1, // 온체인 전송이 아니므로 1로 고정
        txHash: t.txHash || null,
        networkType: t.networkType || 'OFF_CHAIN',
        description: `MSUO 전송: ${decimalToNumber(t.amount)} MSUO`,
      }))
    );
  } catch (error: unknown) {
    console.error('[Transfer] 이체 내역 조회 실패:', error);
    const message = error instanceof Error ? error.message : '이체 내역 조회 중 오류가 발생했습니다.';
    return errorResponse(message, 500, 'SERVER_ERROR');
  }
}


