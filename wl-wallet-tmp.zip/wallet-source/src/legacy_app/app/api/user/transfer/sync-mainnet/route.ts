import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';
import { Prisma } from '@prisma/client';

/**
 * 메인넷과 P2P 거래 동기화 API
 * 메인넷에서 거래가 완료되면 이 API를 호출하여 Transfer 레코드를 업데이트합니다.
 */
export async function POST(request: Request) {
  try {
    // 관리자 권한 확인 (메인넷 연동은 관리자만 가능)
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return unauthorizedResponse('관리자 권한이 필요합니다.');
    }

    const body = await request.json();
    const { transferId, txHash, blockNumber, confirmations, mainnetStatus, gasFee } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['transferId', 'txHash']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    // Transfer 레코드 찾기
    const transfer = await prisma.transfers.findUnique({
      where: { id: transferId },
      include: {
        sender: { select: { walletAddress: true } },
        receiver: { select: { walletAddress: true } },
      },
    });

    if (!transfer) {
      return errorResponse('이체 내역을 찾을 수 없습니다.', 404, 'NOT_FOUND');
    }

    // 메인넷 정보 업데이트
    const updatedTransfer = await prisma.transfers.update({
      where: { id: transferId },
      data: {
        networkType: 'MAINNET',
        txHash: txHash,
        blockNumber: blockNumber || null,
        confirmations: confirmations || 0,
        mainnetStatus: mainnetStatus || 'PENDING',
        senderMainnetAddress: transfer.users.walletAddress,
        receiverMainnetAddress: transfer.users.walletAddress,
        gasFee: gasFee ? new Prisma.Decimal(gasFee) : null,
        mainnetSyncedAt: new Date(),
        metadata: {
          syncType: 'MANUAL_ADMIN',
          syncedBy: currentUser.id,
          syncedAt: new Date().toISOString(),
        },
      },
    });

    console.log(
      `✅ [Mainnet Sync] Transfer ${transferId} synced to mainnet. TXID: ${txHash}, Status: ${mainnetStatus}`
    );

    return successResponse(
      {
        id: updatedTransfer.id,
        txHash: updatedTransfer.txHash,
        mainnetStatus: updatedTransfer.mainnetStatus,
        confirmations: updatedTransfer.confirmations,
        blockNumber: updatedTransfer.blockNumber,
        gasFee: updatedTransfer.gasFee ? Number(updatedTransfer.gasFee) : null,
        mainnetSyncedAt: updatedTransfer.mainnetSyncedAt,
      },
      '메인넷 동기화가 완료되었습니다.'
    );
  } catch (error: any) {
    console.error('[Mainnet Sync] 동기화 실패:', error);
    return errorResponse(
      error.message || '메인넷 동기화 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

/**
 * 메인넷 동기화 상태 조회
 */
export async function GET(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const transferId = searchParams.get('transferId');

    if (!transferId) {
      return validationErrorResponse('transferId가 필요합니다.');
    }

    const transfer = await prisma.transfers.findUnique({
      where: { id: transferId },
    });

    if (!transfer) {
      return errorResponse('이체 내역을 찾을 수 없습니다.', 404, 'NOT_FOUND');
    }

    // 본인 거래만 조회 가능
    const isSender = transfer.senderId === currentUser.id;
    const isReceiver = transfer.receiverId === currentUser.id;
    
    if (!isSender && !isReceiver && currentUser.role !== 'ADMIN') {
      return unauthorizedResponse('권한이 없습니다.');
    }

    return successResponse(transfer);
  } catch (error: any) {
    console.error('[Mainnet Sync] 조회 실패:', error);
    return errorResponse(
      error.message || '메인넷 동기화 상태 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}


