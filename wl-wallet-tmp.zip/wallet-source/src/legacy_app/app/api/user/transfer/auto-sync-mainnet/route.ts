import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';
import { getBlockchainInfo, sendTransaction } from '@/services/mainnet-api';
import { createTransactionHash } from '@/lib/wallet-utils';

/**
 * 메인넷 자동 동기화 API
 * P2P 이체를 메인넷으로 자동 전송
 */
export async function POST(request: Request) {
  try {
    // 관리자 권한 확인
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return unauthorizedResponse('관리자 권한이 필요합니다.');
    }

    const body = await request.json();
    const { transferId, forceSync = false } = body;

    if (!transferId) {
      return errorResponse('transferId가 필요합니다.', 400, 'BAD_REQUEST');
    }

    // Transfer 레코드 조회
    const transfer = await prisma.transfers.findUnique({
      where: { id: transferId },
      include: {
        sender: {
          select: { id: true, walletAddress: true, personalCoin: true },
        },
        receiver: {
          select: { id: true, walletAddress: true, personalCoin: true },
        },
      },
    });

    if (!transfer) {
      return errorResponse('이체 내역을 찾을 수 없습니다.', 404, 'NOT_FOUND');
    }

    // 이미 메인넷에 동기화된 경우
    if (transfer.networkType === 'MAINNET' && !forceSync) {
      return errorResponse('이미 메인넷에 동기화된 거래입니다.', 400, 'ALREADY_SYNCED');
    }

    // 필수 정보 확인
    if (!transfer.users.walletAddress || !transfer.users.walletAddress) {
      return errorResponse('지갑 주소 정보가 없습니다.', 400, 'NO_WALLET_ADDRESS');
    }

    // 메인넷 연결 상태 확인
    const blockchainInfo = await getBlockchainInfo();
    if (!blockchainInfo.success) {
      return errorResponse('메인넷에 연결할 수 없습니다.', 503, 'MAINNET_UNAVAILABLE');
    }

    console.log(`[Auto Sync] 메인넷 동기화 시작: ${transferId}`);
    console.log(`[Auto Sync] 보내는 사람: ${transfer.users.walletAddress}`);
    console.log(`[Auto Sync] 받는 사람: ${transfer.users.walletAddress}`);
    console.log(`[Auto Sync] 금액: ${transfer.amount} AO`);

    // 메인넷 트랜잭션 전송
    const txResult = await sendTransaction(
      transfer.users.walletAddress,
      transfer.users.walletAddress,
      Number(transfer.amount)
    );

    if (!txResult.success) {
      // 실패 시 Transfer 레코드에 실패 정보 기록
      await prisma.transfers.update({
        where: { id: transferId },
        data: {
          networkType: 'MAINNET',
          mainnetStatus: 'FAILED',
          mainnetSyncedAt: new Date(),
          metadata: JSON.stringify({
            syncType: 'AUTO_ADMIN',
            syncedBy: currentUser.id,
            syncedAt: new Date().toISOString(),
            error: txResult.error,
            blockchainInfo: {
              success: blockchainInfo.success,
              data: blockchainInfo.data,
              error: blockchainInfo.error,
            },
          }),
        },
      });

      return errorResponse(
        `메인넷 전송 실패: ${txResult.error}`,
        500,
        'MAINNET_TX_FAILED'
      );
    }

    // 성공 시 Transfer 레코드 업데이트
    const updatedTransfer = await prisma.transfers.update({
      where: { id: transferId },
      data: {
        networkType: 'MAINNET',
        txHash: txResult.data?.txId || txResult.data?.txHash,
        blockNumber: txResult.data?.blockNumber,
        confirmations: txResult.data?.confirmations || 0,
        mainnetStatus: 'CONFIRMED',
        senderMainnetAddress: transfer.users.walletAddress,
        receiverMainnetAddress: transfer.users.walletAddress,
        mainnetSyncedAt: new Date(),
        metadata: JSON.stringify({
          syncType: 'AUTO_ADMIN',
          syncedBy: currentUser.id,
          syncedAt: new Date().toISOString(),
          blockchainInfo: {
            success: blockchainInfo.success,
            data: blockchainInfo.data,
            error: blockchainInfo.error,
          },
          txResult: txResult.data,
        }),
      },
    });

    console.log(
      `✅ [Auto Sync] 메인넷 동기화 완료: ${transferId}, TXID: ${updatedTransfer.txHash}`
    );

    return successResponse(
      {
        id: updatedTransfer.id,
        txHash: updatedTransfer.txHash,
        blockNumber: updatedTransfer.blockNumber,
        confirmations: updatedTransfer.confirmations,
        mainnetStatus: updatedTransfer.mainnetStatus,
        mainnetSyncedAt: updatedTransfer.mainnetSyncedAt,
        blockchainInfo: blockchainInfo.data,
      },
      '메인넷 자동 동기화가 완료되었습니다.'
    );

  } catch (error: any) {
    console.error('[Auto Sync] 동기화 실패:', error);
    return errorResponse(
      error.message || '메인넷 자동 동기화 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

/**
 * 대기 중인 이체 목록 조회 (메인넷 동기화가 필요한 것들)
 */
export async function GET(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return unauthorizedResponse('관리자 권한이 필요합니다.');
    }

    // 메인넷 동기화가 필요한 이체 목록 조회
    const pendingTransfers = await prisma.transfers.findMany({
      where: {
        networkType: 'OFF_CHAIN',
      },
      include: {
        sender: {
          select: { id: true, username: true, email: true, walletAddress: true },
        },
        receiver: {
          select: { id: true, username: true, email: true, walletAddress: true },
        },
      },
      orderBy: { transferredAt: 'desc' },
      take: 50,
    });

    return successResponse(
      pendingTransfers.map((transfer) => ({
        id: transfer.id,
        amount: Number(transfer.amount),
        fee: Number(transfer.fee),
        sender: {
          id: transfer.users.id,
          username: transfer.users.username,
          email: transfer.users.email,
          walletAddress: transfer.users.walletAddress,
        },
        receiver: {
          id: transfer.users.id,
          username: transfer.users.username,
          email: transfer.users.email,
          walletAddress: transfer.users.walletAddress,
        },
        transferredAt: transfer.transferredAt,
        canSync: !!(transfer.users.walletAddress && transfer.users.walletAddress),
      }))
    );

  } catch (error: any) {
    console.error('[Auto Sync] 대기 목록 조회 실패:', error);
    return errorResponse(
      error.message || '대기 목록 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}