import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { isValidUsername } from '@/lib/validation';

/**
 * 사용자명 변경 API
 * POST /api/user/username
 */
export async function POST(request: NextRequest) {
  try {
    // 현재 로그인한 사용자 확인
    const currentUser = await getCurrentUser();
    
    if (!currentUser) {
      return NextResponse.json(
        { ok: false, error: '로그인이 필요합니다.' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { username } = body;

    // 필수 필드 검증
    if (!username || typeof username !== 'string') {
      return NextResponse.json(
        { ok: false, error: '사용자명을 입력해주세요.' },
        { status: 400 }
      );
    }

    // 사용자명 유효성 검사
    const usernameCheck = isValidUsername(username.trim());
    if (!usernameCheck.valid) {
      return NextResponse.json(
        { ok: false, error: usernameCheck.message || '사용자명이 유효하지 않습니다.' },
        { status: 400 }
      );
    }

    const newUsername = username.trim();

    // 현재 사용자명과 동일한지 확인
    if (currentUser.username === newUsername) {
      return NextResponse.json(
        { ok: false, error: '현재 사용자명과 동일합니다.' },
        { status: 400 }
      );
    }

    // 중복 체크 (다른 사용자가 이미 사용 중인지 확인)
    const existingUser = await prisma.users.findFirst({
      where: {
        username: newUsername,
        id: { not: currentUser.id }, // 현재 사용자 제외
      },
    });

    if (existingUser) {
      return NextResponse.json(
        { ok: false, error: '이미 사용 중인 사용자명입니다.' },
        { status: 409 }
      );
    }

    // 사용자명 업데이트
    const updatedUser = await prisma.users.update({
      where: { id: currentUser.id },
      data: { username: newUsername },
      select: {
        id: true,
        username: true,
        email: true,
        rank: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    console.log(`[User] 사용자명 변경 완료: ${currentUser.username} -> ${newUsername} (userId: ${currentUser.id})`);

    return NextResponse.json({
      ok: true,
      message: '사용자명이 성공적으로 변경되었습니다.',
      data: {
        users: updatedUser,
      },
    });
  } catch (error: any) {
    console.error('[User] 사용자명 변경 실패:', error);
    
    // Prisma 에러 처리
    if (error.code === 'P2002') {
      return NextResponse.json(
        { ok: false, error: '이미 사용 중인 사용자명입니다.' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { ok: false, error: error.message || '사용자명 변경 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

