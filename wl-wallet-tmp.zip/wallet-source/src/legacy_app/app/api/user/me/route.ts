import { NextResponse } from 'next/server';
import { Prisma } from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { getLineVolumes } from '@/services/rankSystem';

const decimalToNumber = (value?: Prisma.Decimal | null) =>
  Number(value?.toString() ?? 0);

export async function GET(request: Request) {
  try {
    // 쿠키에서 userId 가져오기
    const cookieHeader = request.headers.get('cookie');
    const userIdMatch = cookieHeader?.match(/userId=([^;]+)/);
    const userId = userIdMatch?.[1];

    if (!userId) {
      return NextResponse.json(
        { ok: false, error: '로그인이 필요합니다.' },
        { status: 401 }
      );
    }

    // 사용자 정보 조회
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        rank: true,
        totalInvestment: true,
        personalCoin: true,
        accumulatedSales: true,
        referralCode: true, // 추천인 코드 추가
        createdAt: true,
        updatedAt: true,
        referrerId: true,
        other_users_users_referrerIdTousers: {
          select: {
            username: true,
          },
        },
        _count: {
          select: {
            other_users_users_referrerIdTousers: true,
            investments: true,
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      );
    }

    const lineVolumes = await getLineVolumes(user.id);

    return NextResponse.json({
      ok: true,
      users: {
        id: user.id,
        username: user.username,
        email: user.email,
        rank: user.rank,
        totalInvestment: decimalToNumber(user.totalInvestment),
        personalCoin: decimalToNumber(user.personalCoin),
        accumulatedSales: decimalToNumber(user.accumulatedSales),
        referralCode: user.referralCode, // 추천인 코드 추가
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
        other_users_users_referrerIdTousers: user.referrer,
        _count: user._count,
        lines: lineVolumes,
      },
    });
  } catch (error) {
    console.error('[user/me] 사용자 정보 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: '사용자 정보 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

