import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { createWallet } from '@/services/mainnet-api';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';

/**
 * 메인넷 지갑 생성
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 이미 지갑이 있는지 확인
    if (user.walletAddress) {
      return validationErrorResponse('이미 지갑이 생성되어 있습니다.');
    }

    // 메인넷에 지갑 생성 요청
    const walletResponse = await createWallet();

    if (!walletResponse.success || !walletResponse.data) {
      return errorResponse(
        walletResponse.error || '지갑 생성에 실패했습니다.',
        500,
        'WALLET_CREATION_ERROR'
      );
    }

    const { address } = walletResponse.data;

    // 사용자 데이터베이스에 지갑 주소 저장
    await prisma.users.update({
      where: { id: user.id },
      data: { walletAddress: address },
    });

    return successResponse({
      address,
      message: '지갑이 성공적으로 생성되었습니다.',
    });
  } catch (error: any) {
    console.error('[Create Wallet] Error:', error);
    return errorResponse(
      error.message || '지갑 생성 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

