import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';
import { RewardType } from '@prisma/client';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

export async function GET(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'all'; // all, DAILY, REFERRAL, MATCHING, RANK, LEADERSHIP
    const period = searchParams.get('period') || '30'; // 7, 30, 90, all
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const skip = (page - 1) * limit;

    // 기간 필터
    let dateFilter: any = {};
    if (period !== 'all') {
      const days = parseInt(period);
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      dateFilter = { gte: startDate };
    }

    // 타입 필터
    let typeFilter: any = {};
    if (type !== 'all') {
      typeFilter = { type: type as RewardType };
    }

    // 리워드 조회
    const [rewards, totalCount] = await Promise.all([
      prisma.reward_logs.findMany({
        where: {
          userId: currentUser.id,
          createdAt: dateFilter,
          ...typeFilter,
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        select: {
          id: true,
          type: true,
          amount: true,
          description: true,
          createdAt: true,
          sourceUserId: true,
          generation: true,
        },
      }),
      prisma.reward_logs.count({
        where: {
          userId: currentUser.id,
          createdAt: dateFilter,
          ...typeFilter,
        },
      }),
    ]);

    // 전체 통계 계산 (필터 적용 전)
    const [totalStats, dailyStats, referralStats, matchingStats, rankStats, leadershipStats] = await Promise.all([
      // 전체 리워드
      prisma.reward_logs.aggregate({
        where: { userId: currentUser.id },
        _sum: { amount: true },
        _count: true,
      }),
      // 일일 리워드 (30일)
      prisma.reward_logs.aggregate({
        where: {
          userId: currentUser.id,
          type: 'DAILY',
          createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        },
        _sum: { amount: true },
      }),
      // 추천/매칭 보너스 (30일)
      prisma.reward_logs.aggregate({
        where: {
          userId: currentUser.id,
          type: { in: ['REFERRAL', 'MATCHING'] },
          createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        },
        _sum: { amount: true },
      }),
      // 매칭 보너스 (30일)
      prisma.reward_logs.aggregate({
        where: {
          userId: currentUser.id,
          type: 'MATCHING',
          createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        },
        _sum: { amount: true },
      }),
      // 랭크/리더십 보너스 (30일)
      prisma.reward_logs.aggregate({
        where: {
          userId: currentUser.id,
          type: { in: ['RANK', 'TEAM'] },
          createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        },
        _sum: { amount: true },
      }),
      // 리더십 보너스 (30일)
      prisma.reward_logs.aggregate({
        where: {
          userId: currentUser.id,
          type: 'TEAM',
          createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        },
        _sum: { amount: true },
      }),
    ]);

    // sourceUserId가 있는 리워드들의 사용자 정보를 일괄 조회
    const sourceUserIds = rewards
      .map((r) => r.sourceUserId)
      .filter((id): id is string => id !== null);
    
    const sourceUsers = sourceUserIds.length > 0
      ? await prisma.users.findMany({
          where: { id: { in: sourceUserIds } },
          select: { id: true, username: true, email: true },
        })
      : [];
    
    const sourceUserMap = new Map(sourceUsers.map((u) => [u.id, u]));

    return successResponse({
      rewards: rewards.map((r) => {
        // sourceUserId가 있으면 현재 사용자 정보를 조회하여 표시
        let displayDescription = r.description || `${r.type} 리워드`;
        
        // REFERRAL 타입이고 sourceUserId가 있으면 현재 사용자 정보로 업데이트
        if (r.type === 'REFERRAL' && r.sourceUserId) {
          const sourceUser = sourceUserMap.get(r.sourceUserId);
          if (sourceUser) {
            const currentUsername = sourceUser.username || sourceUser.email || '알 수 없음';
            // description에 투자자 정보가 포함되어 있으면 현재 이름으로 교체
            if (r.description && r.description.includes('투자자:')) {
              displayDescription = r.description.replace(
                /투자자:\s*[^,)]+/,
                `투자자: ${currentUsername}`
              );
            } else {
              displayDescription = `추천 보너스 지급 (투자자: ${currentUsername})`;
            }
          }
        }
        
        return {
          id: r.id,
          type: r.type,
          amount: decimalToNumber(r.amount),
          description: displayDescription,
          createdAt: r.createdAt.toISOString(),
          sourceUserId: r.sourceUserId,
          sourceUser: r.sourceUserId ? sourceUserMap.get(r.sourceUserId) || null : null,
          generation: r.generation,
        };
      }),
      pagination: {
        page,
        limit,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limit),
      },
      stats: {
        total: decimalToNumber(totalStats._sum.amount),
        daily: decimalToNumber(dailyStats._sum.amount),
        referralMatching: decimalToNumber(referralStats._sum.amount),
        matching: decimalToNumber(matchingStats._sum.amount),
        rankLeadership: decimalToNumber(rankStats._sum.amount),
        leadership: decimalToNumber(leadershipStats._sum.amount),
      },
    });
  } catch (error: any) {
    console.error('[Rewards] 리워드 조회 실패:', error);
    return errorResponse(
      error.message || '리워드 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

