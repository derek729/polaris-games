import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';

/**
 * 메인넷 동기화 상태를 포함한 거래 내역 조회
 */
export async function GET(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type'); // 'sent' | 'received' | 'all'
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');

    let whereClause: Record<string, unknown> = {};

    if (type === 'sent') {
      whereClause = { senderId: currentUser.id };
    } else if (type === 'received') {
      whereClause = { receiverId: currentUser.id };
    } else {
      // all: 보낸 것과 받은 것 모두
      whereClause = {
        OR: [{ senderId: currentUser.id }, { receiverId: currentUser.id }],
      };
    }

    const transfers = await prisma.transfers.findMany({
      where: whereClause,
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
        receiver: {
          select: {
            id: true,
            username: true,
            email: true,
            walletAddress: true,
          },
        },
      },
      orderBy: { transferredAt: 'desc' },
      take: limit,
      skip: offset,
    });

    // 추가 정보: 리워드, 출금 등 다른 거래 유형도 조회
    const [rewardLogs, withdrawalRequests] = await Promise.all([
      // 리워드 내역
      prisma.reward_logs.findMany({
        where: { userId: currentUser.id },
        select: {
          id: true,
          type: true,
          amount: true,
          description: true,
          createdAt: true,
          isPaid: true,
        },
        orderBy: { createdAt: 'desc' },
        take: 10,
      }),

      // 출금 신청 내역
      prisma.withdrawal_requests.findMany({
        where: { userId: currentUser.id },
        select: {
          id: true,
          amount: true,
          address: true,
          status: true,
          requestedAt: true,
          processedAt: true,
        },
        orderBy: { requestedAt: 'desc' },
        take: 10,
      }),
    ]);

    // 모든 거래를 통합한 형태로 변환
    const allTransactions = [
      // 이체 내역
      ...transfers.map((t) => ({
        id: t.id,
        type: t.senderId === currentUser.id ? 'sent' : 'received',
        category: 'transfer',
        amount: Number(t.amount),
        fee: Number(t.fee),
        status: t.mainnetStatus || 'OFF_CHAIN',
        networkType: t.networkType,
        txHash: t.txHash,
        confirmations: t.confirmations,
        blockNumber: t.blockNumber,
        gasFee: t.gasFee ? Number(t.gasFee) : null,
        mainnetSyncedAt: t.mainnetSyncedAt,
        description: null,
        sender: {
          username: t.users.username,
          email: t.users.email,
        },
        receiver: {
          username: t.users.username,
          email: t.users.email,
        },
        createdAt: t.transferredAt,
      })),

      // 리워드 내역
      ...reward_logs.map((r) => ({
        id: r.id,
        type: 'received',
        category: 'reward',
        amount: Number(r.amount),
        fee: 0,
        status: r.isPaid ? 'COMPLETED' : 'PENDING',
        networkType: 'OFF_CHAIN',
        txHash: null,
        confirmations: null,
        blockNumber: null,
        gasFee: null,
        mainnetSyncedAt: null,
        description: r.description,
        rewardType: r.type,
        sender: null,
        receiver: null,
        createdAt: r.createdAt,
      })),

      // 출금 내역
      ...withdrawal_requests.map((w) => ({
        id: w.id,
        type: 'sent',
        category: 'withdrawal',
        amount: Number(w.amount),
        fee: 0,
        status: w.status,
        networkType: 'OFF_CHAIN',
        txHash: null,
        confirmations: null,
        blockNumber: null,
        gasFee: null,
        mainnetSyncedAt: null,
        description: `출금: ${w.address.substring(0, 10)}...`,
        sender: null,
        receiver: null,
        address: w.address,
        createdAt: w.requestedAt,
        processedAt: w.processedAt,
      })),
    ];

    // 시간순 정렬
    allTransactions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    return successResponse({
      transactions: allTransactions,
      pagination: {
        total: transfers.length + rewardLogs.length + withdrawalRequests.length,
        limit,
        offset,
        hasMore: transfers.length === limit,
      },
      summary: {
        totalTransfers: transfers.length,
        totalRewards: rewardLogs.length,
        totalWithdrawals: withdrawalRequests.length,
        syncedToMainnet: transfers.filter(t => t.networkType === 'MAINNET').length,
        pendingSync: transfers.filter(t => t.networkType === 'OFF_CHAIN').length,
      }
    }, '거래 내역 조회 완료.');

  } catch (error: unknown) {
    console.error('[Transactions with Status] 조회 실패:', error);
    const message = error instanceof Error ? error.message : '거래 내역 조회 중 오류가 발생했습니다.';
    return errorResponse(
      message,
      500,
      'SERVER_ERROR'
    );
  }
}