import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';
import { Prisma } from '@prisma/client';

const decimalToNumber = (value: Prisma.Decimal | null) => Number(value?.toString() ?? 0);

export async function GET(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'all'; // all, reward, withdrawal, transfer, investment
    const period = searchParams.get('period') || '30'; // 7, 30, 90, all
    const search = searchParams.get('search') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    // 기간 필터
    let dateFilter: { gte?: Date } = {};
    if (period !== 'all') {
      const days = parseInt(period);
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      dateFilter = { gte: startDate };
    }

    // 거래 내역 통합 조회
    const transactions: unknown[] = [];

    // 1. 리워드 내역
    if (type === 'all' || type === 'reward') {
      const rewards = await prisma.reward_logs.findMany({
        where: {
          userId: currentUser.id,
          createdAt: dateFilter,
          ...(search && {
            OR: [
              { description: { contains: search, mode: 'insensitive' } },
              { id: { contains: search, mode: 'insensitive' } },
            ],
          }),
        },
        orderBy: { createdAt: 'desc' },
        take: 100, // 최대 100건
      });

      rewards.forEach((reward) => {
        transactions.push({
          id: reward.id,
          type: 'reward',
          typeLabel: '리워드',
          amount: decimalToNumber(reward.amount),
          description: reward.description || `${reward.type} 리워드`,
          relatedInfo: reward.sourceUserId ? `회원: ${reward.sourceUserId.slice(0, 8)}` : null,
          createdAt: reward.createdAt,
          balance: null, // 잔액은 클라이언트에서 계산
        });
      });
    }

    // 2. 출금 내역
    if (type === 'all' || type === 'withdrawal') {
      const withdrawals = await prisma.withdrawal_requests.findMany({
        where: {
          userId: currentUser.id,
          requestedAt: dateFilter,
          ...(search && {
            OR: [
              { address: { contains: search, mode: 'insensitive' } },
              { id: { contains: search, mode: 'insensitive' } },
            ],
          }),
        },
        orderBy: { requestedAt: 'desc' },
        take: 100,
      });

      withdrawals.forEach((withdrawal) => {
        transactions.push({
          id: withdrawal.id,
          type: 'withdrawal',
          typeLabel: '출금',
          amount: decimalToNumber(withdrawal.amount),
          description: '출금 요청',
          relatedInfo: withdrawal.address ? `TXID: ${withdrawal.address.slice(0, 10)}...` : null,
          createdAt: withdrawal.requestedAt,
          status: withdrawal.status,
          balance: null,
        });
      });
    }

    // 3. 이체 내역 (보낸 것 + 받은 것) - P2P 거래 이력
    if (type === 'all' || type === 'transfer') {
      const sentTransfers = await prisma.transfers.findMany({
        where: {
          senderId: currentUser.id,
          transferredAt: dateFilter,
          ...(search && {
            OR: [
              { receiver: { username: { contains: search, mode: 'insensitive' } } },
              { id: { contains: search, mode: 'insensitive' } },
            ],
          }),
        },
        include: {
          receiver: {
            select: { username: true, email: true },
          },
        },
        orderBy: { transferredAt: 'desc' },
        take: 100,
      });

      sentTransfers.forEach((transfer) => {
        // 내부 거래 ID 표시
        const transferId = `ID: ${transfer.id.slice(0, 8)}...`;
        // 트랜잭션 해시 표시
        const txHashDisplay = transfer.txHash 
          ? `TX: ${transfer.txHash.slice(0, 16)}...${transfer.txHash.slice(-8)}` 
          : null;

        transactions.push({
          id: transfer.id,
          type: 'transfer_sent',
          typeLabel: '이체',
          amount: decimalToNumber(transfer.amount),
          description: `${transfer.users.username || transfer.users.email}에게 이체`,
          relatedInfo: `${transferId}${txHashDisplay ? ` | ${txHashDisplay}` : ''} | 회원: ${transfer.users.username || transfer.users.email}`,
          createdAt: transfer.transferredAt,
          balance: null,
          txHash: transfer.txHash,
          networkType: transfer.networkType || 'OFF_CHAIN',
        });
      });

      const receivedTransfers = await prisma.transfers.findMany({
        where: {
          receiverId: currentUser.id,
          transferredAt: dateFilter,
          ...(search && {
            OR: [
              { sender: { username: { contains: search, mode: 'insensitive' } } },
              { id: { contains: search, mode: 'insensitive' } },
            ],
          }),
        },
        include: {
          sender: {
            select: { username: true, email: true },
          },
        },
        orderBy: { transferredAt: 'desc' },
        take: 100,
      });

      receivedTransfers.forEach((transfer) => {
        // 내부 거래 ID 표시
        const transferId = `ID: ${transfer.id.slice(0, 8)}...`;
        // 트랜잭션 해시 표시
        const txHashDisplay = transfer.txHash 
          ? `TX: ${transfer.txHash.slice(0, 16)}...${transfer.txHash.slice(-8)}` 
          : null;

        transactions.push({
          id: transfer.id,
          type: 'transfer_received',
          typeLabel: '이체',
          amount: decimalToNumber(transfer.amount),
          description: `${transfer.users.username || transfer.users.email}로부터 이체`,
          relatedInfo: `${transferId}${txHashDisplay ? ` | ${txHashDisplay}` : ''} | 회원: ${transfer.users.username || transfer.users.email}`,
          createdAt: transfer.transferredAt,
          balance: null,
          txHash: transfer.txHash,
          networkType: transfer.networkType || 'OFF_CHAIN',
        });
      });
    }

    // 4. 투자 내역 (충전)
    if (type === 'all' || type === 'investment') {
      const investments = await prisma.investments.findMany({
        where: {
          userId: currentUser.id,
          createdAt: dateFilter,
          ...(search && {
            OR: [
              { id: { contains: search, mode: 'insensitive' } },
            ],
          }),
        },
        orderBy: { createdAt: 'desc' },
        take: 100,
      });

      investments.forEach((investment) => {
        transactions.push({
          id: investment.id,
          type: 'investment',
          typeLabel: '충전',
          amount: decimalToNumber(investment.amount),
          description: '코인 충전',
          relatedInfo: `투자 ID: ${investment.id.slice(0, 8)}`,
          createdAt: investment.createdAt,
          balance: null,
        });
      });
    }

    // 날짜순 정렬 및 페이지네이션
    transactions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    const total = transactions.length;
    const paginatedTransactions = transactions.slice(skip, skip + limit);

    // 통계 계산
    const stats = {
      totalRewards: transactions
        .filter((t) => t.type === 'reward')
        .reduce((sum, t) => sum + t.amount, 0),
      totalWithdrawals: transactions
        .filter((t) => t.type === 'withdrawal')
        .reduce((sum, t) => sum + t.amount, 0),
      totalInvestments: transactions
        .filter((t) => t.type === 'investment')
        .reduce((sum, t) => sum + t.amount, 0),
    };

    return successResponse({
      transactions: paginatedTransactions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      stats,
    });
  } catch (error: unknown) {
    console.error('[Transactions] 거래 내역 조회 실패:', error);
    const message = error instanceof Error ? error.message : '거래 내역 조회 중 오류가 발생했습니다.';
    return errorResponse(
      message,
      500,
      'SERVER_ERROR'
    );
  }
}

