import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { getMiningStatus, getBlockchainInfo } from '@/services/mainnet-api';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';

/**
 * 사용자의 채굴 상태 조회
 */
export async function GET(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 현재 진행 중인 채굴 조회
    const currentMining = await prisma.mining_records.findFirst({
      where: {
        userId: user.id,
        status: { in: ['MINING', 'PENDING'] },
      },
      orderBy: { createdAt: 'desc' },
    });

    // 메인넷에서 채굴 상태 조회
    const miningStatusResponse = await getMiningStatus();
    const blockchainInfoResponse = await getBlockchainInfo();

    if (!miningStatusResponse.success || !blockchainInfoResponse.success) {
      return errorResponse('메인넷 연결에 실패했습니다.', 503, 'MAINNET_ERROR');
    }

    // 사용자의 채굴 통계 (최근 30일)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const miningStats = await prisma.mining_records.aggregate({
      where: {
        userId: user.id,
        createdAt: { gte: thirtyDaysAgo },
      },
      _sum: { rewardAmount: true, miningPower: true },
      _count: { id: true },
      _avg: { difficulty: true },
    });

    // 최근 채굴 기록 (최근 10건)
    const recentMinings = await prisma.mining_records.findMany({
      where: { userId: user.id },
      orderBy: { minedAt: 'desc' },
      take: 10,
      select: {
        id: true,
        txHash: true,
        blockNumber: true,
        rewardAmount: true,
        miningPower: true,
        difficulty: true,
        status: true,
        minedAt: true,
        createdAt: true,
      },
    });

    // 채굴 효율성 계산
    const totalRewards = Number(miningStats._sum.rewardAmount || 0);
    const totalBlocks = miningStats._count.id || 0;
    const avgMiningPower = Number(miningStats._avg.miningPower || 1);
    const avgDifficulty = Number(miningStats._avg.difficulty || 4);

    // 예상 수익률 계산 (시간당)
    const estimatedHourlyReward = (totalRewards / 30 / 24) * (avgMiningPower / avgDifficulty);

    return successResponse({
      currentMining: currentMining ? {
        id: currentMining.id,
        status: currentMining.status,
        miningPower: currentMining.miningPower,
        startedAt: currentMining.createdAt,
        estimatedCompletionTime: currentMining.estimatedCompletionTime,
        progress: currentMining.estimatedCompletionTime
          ? Math.max(0, Math.min(100, ((Date.now() - currentMining.createdAt.getTime()) /
              (currentMining.estimatedCompletionTime.getTime() - currentMining.createdAt.getTime())) * 100))
          : 0,
      } : null,

      networkStats: {
        isMining: miningStatusResponse.data?.mining || false,
        networkHashrate: miningStatusResponse.data?.hashrate || 0,
        currentBlockHeight: blockchainInfoResponse.data?.height || 0,
        difficulty: blockchainInfoResponse.data?.difficulty || 4,
        blockReward: blockchainInfoResponse.data?.blockReward || 50,
      },

      userStats: {
        totalRewards,
        totalBlocks,
        avgMiningPower,
        avgDifficulty,
        estimatedHourlyReward: isNaN(estimatedHourlyReward) ? 0 : estimatedHourlyReward,
        efficiency: avgMiningPower / avgDifficulty,
      },

      recentMinings: recentMinings.map(mining => ({
        id: mining.id,
        txHash: mining.txHash,
        blockNumber: mining.blockNumber,
        rewardAmount: Number(mining.rewardAmount),
        miningPower: mining.miningPower,
        difficulty: mining.difficulty,
        status: mining.status,
        minedAt: mining.minedAt,
        createdAt: mining.createdAt,
        duration: mining.minedAt ? (mining.minedAt.getTime() - mining.createdAt.getTime()) / 1000 : null, // 초 단위
      })),
    });
  } catch (error: any) {
    console.error('[Mining Status] Error:', error);
    return errorResponse(
      error.message || '채굴 상태 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

