import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { stopMining } from '@/services/mainnet-api';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';

/**
 * 채굴 중지
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 메인넷에 채굴 중지 요청
    const stopResponse = await stopMining();

    if (!stopResponse.success) {
      return errorResponse(
        stopResponse.error || '채굴 중지에 실패했습니다.',
        500,
        'MINING_ERROR'
      );
    }

    return successResponse({
      message: '채굴이 중지되었습니다.',
    });
  } catch (error: any) {
    console.error('[Stop Mining] Error:', error);
    return errorResponse(
      error.message || '채굴 중지 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

