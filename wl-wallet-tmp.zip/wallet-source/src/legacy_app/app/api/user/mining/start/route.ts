import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { startMining, getBlockchainInfo, generateTransactionHash, generateBlockHash } from '@/services/mainnet-api';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';

/**
 * 채굴 시작
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { mainnetAddress, miningPower = 1 } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['mainnetAddress']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '메인넷 지갑 주소가 필요합니다.');
    }

    // 메인넷 주소 검증 강화
    if (!mainnetAddress || typeof mainnetAddress !== 'string' || mainnetAddress.length < 20) {
      return validationErrorResponse('올바른 메인넷 지갑 주소가 필요합니다.');
    }

    // 채굴 파워 검증
    if (miningPower < 1 || miningPower > 100) {
      return validationErrorResponse('채굴 파워는 1-100 범위여야 합니다.');
    }

    // 이미 진행 중인 채굴 확인
    const existingMining = await prisma.mining_records.findFirst({
      where: {
        userId: user.id,
        status: { in: ['PENDING', 'MINING'] },
      },
    });

    if (existingMining) {
      return validationErrorResponse('이미 진행 중인 채굴이 있습니다.');
    }

    // 최근 채굴 기록 확인 (과도한 채굴 방지)
    const recentMinings = await prisma.mining_records.count({
      where: {
        userId: user.id,
        createdAt: {
          gte: new Date(Date.now() - 60 * 1000), // 최근 1분
        },
      },
    });

    if (recentMinings >= 5) {
      return validationErrorResponse('너무 잦은 채굴 요청입니다. 잠시 후 다시 시도해주세요.');
    }

    // 메인넷에 채굴 시작 요청
    const miningResponse = await startMining(mainnetAddress, miningPower);

    if (!miningResponse.success) {
      return errorResponse(
        miningResponse.error || '채굴 시작에 실패했습니다.',
        500,
        'MINING_ERROR'
      );
    }

    // 블록체인 정보 조회
    const blockchainInfo = await getBlockchainInfo();
    const currentBlock = blockchainInfo.data?.height || 0;
    const baseReward = blockchainInfo.data?.blockReward || 50;

    // 채굴 파워에 따른 보상 계산
    const rewardAmount = baseReward * miningPower;

    // 채굴 기록 생성 (트랜잭션 해시 자동 생성)
    const txHash = generateTransactionHash({
      userId: user.id,
      type: 'MINING',
      amount: rewardAmount,
      miningPower,
      timestamp: Date.now(),
    });

    const blockHash = generateBlockHash({
      blockNumber: currentBlock + 1,
      previousHash: blockchainInfo.data?.previousHash || '0x' + Array(64).fill(0).join(''),
      transactions: [txHash],
      timestamp: Date.now(),
      miningPower,
    });

    const miningRecord = await prisma.1.create({{ data: {
        userId: user.id,
        mainnetAddress,
        txHash,
        blockHash,
        blockNumber: currentBlock + 1,
        blockHeight: currentBlock + 1,
        rewardAmount,
        difficulty: blockchainInfo.data?.difficulty || 4,
        miningPower,
        status: 'MINING', // 즉시 MINING 상태로 시작
        confirmations: 0,
        estimatedCompletionTime: new Date(Date.now() + (miningPower * 60 * 1000)), // 채굴 파워에 따른 예상 완료 시간
      },
    });

    return successResponse({
      message: `채굴이 시작되었습니다. (파워: ${miningPower}x)`,
      mining_records: {
        id: miningRecord.id,
        txHash: miningRecord.txHash,
        blockNumber: miningRecord.blockNumber,
        rewardAmount: Number(miningRecord.rewardAmount),
        miningPower,
        estimatedCompletionTime: miningRecord.estimatedCompletionTime,
      },
    });
  } catch (error: any) {
    console.error('[Start Mining] Error:', error);
    return errorResponse(
      error.message || '채굴 시작 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

