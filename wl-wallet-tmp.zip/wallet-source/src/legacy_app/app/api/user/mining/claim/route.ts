import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { claimMiningReward, getBlockchainInfo } from '@/services/mainnet-api';
import { successResponse, errorResponse, unauthorizedResponse, validationErrorResponse } from '@/lib/api-response';
import { Prisma } from '@prisma/client';

/**
 * 채굴 보상 클레임
 */
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const body = await request.json();
    const { miningRecordId } = body;

    if (!miningRecordId) {
      return validationErrorResponse('채굴 기록 ID가 필요합니다.');
    }

    // 채굴 기록 조회 및 검증
    const miningRecord = await prisma.mining_records.findFirst({
      where: {
        id: miningRecordId,
        userId: user.id,
        status: 'COMPLETED', // 완료된 채굴만 클레임 가능
      },
    });

    if (!miningRecord) {
      return errorResponse('채굴 기록을 찾을 수 없거나 클레임할 수 없는 상태입니다.', 404, 'MINING_RECORD_NOT_FOUND');
    }

    // 이미 클레임했는지 확인
    if (miningRecord.claimedAt) {
      return validationErrorResponse('이미 클레임된 보상입니다.');
    }

    // 메인넷에서 보상 클레임
    const claimResponse = await claimMiningReward(miningRecord.txHash);

    if (!claimResponse.success) {
      return errorResponse(
        claimResponse.error || '보상 클레임에 실패했습니다.',
        500,
        'CLAIM_ERROR'
      );
    }

    const rewardAmount = new Prisma.Decimal(miningRecord.rewardAmount);

    // 트랜잭션으로 보상 지급 및 기록 업데이트
    await prisma.$transaction(async (tx) => {
      // 사용자 잔액 증가
      await tx.users.update({
        where: { id: user.id },
        data: {
          personalCoin: { increment: rewardAmount },
        },
      });

      // 채굴 기록 업데이트
      await tx.mining_records.update({
        where: { id: miningRecordId },
        data: {
          status: 'CLAIMED',
          claimedAt: new Date(),
          confirmations: miningRecord.confirmations + 1,
        },
      });

      // 보상 로그 생성
      await tx.reward_logs.create({
        data: {
          userId: user.id,
          type: 'MINING',
          amount: rewardAmount,
          description: `채굴 보상: 블록 #${miningRecord.blockNumber}`,
        },
      });
    });

    console.log(`✅ [Mining Claim] ${user.username}: ${rewardAmount.toFixed(2)} MSUO (Block: ${miningRecord.blockNumber})`);

    return successResponse({
      message: `채굴 보상이 성공적으로 클레임되었습니다.`,
      claimed: {
        amount: Number(rewardAmount),
        blockNumber: miningRecord.blockNumber,
        txHash: miningRecord.txHash,
        claimedAt: new Date(),
      },
    });
  } catch (error: any) {
    console.error('[Mining Claim] Error:', error);
    return errorResponse(
      error.message || '보상 클레임 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

/**
 * 클레임 가능한 채굴 보상 목록 조회
 */
export async function GET(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 클레임 가능한 채굴 기록 조회
    const claimableMinings = await prisma.mining_records.findMany({
      where: {
        userId: user.id,
        status: 'COMPLETED',
        claimedAt: null,
      },
      orderBy: { minedAt: 'desc' },
      take: 20,
    });

    // 총 클레임 가능 금액 계산
    const totalClaimable = claimableMinings.reduce(
      (sum, mining) => sum + Number(mining.rewardAmount),
      0
    );

    return successResponse({
      claimableMinings: claimableMinings.map(mining => ({
        id: mining.id,
        txHash: mining.txHash,
        blockNumber: mining.blockNumber,
        rewardAmount: Number(mining.rewardAmount),
        miningPower: mining.miningPower,
        minedAt: mining.minedAt,
        confirmations: mining.confirmations,
      })),
      totalClaimable,
      count: claimableMinings.length,
    });
  } catch (error: any) {
    console.error('[Mining Claim List] Error:', error);
    return errorResponse(
      error.message || '클레임 가능 보상 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}