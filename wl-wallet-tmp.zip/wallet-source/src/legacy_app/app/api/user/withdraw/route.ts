import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse, unauthorizedResponse, forbiddenResponse } from '@/lib/api-response';
import { validateRequired, isValidAmount, isValidWalletAddress, isValidMSUOWalletAddress } from '@/lib/validation';
import { checkUserRateLimit, rateLimitConfigs } from '@/lib/rate-limit';
import { getCurrentUser } from '@/lib/auth';

const decimalToNumber = (value: Decimal | null) => Number(value?.toString() ?? 0);

// 출금 한도 설정 (환경 변수에서 읽어오기)
const MIN_WITHDRAWAL_AMOUNT = Number(process.env.MIN_WITHDRAWAL_AMOUNT) || 100;
const MAX_WITHDRAWAL_AMOUNT = Number(process.env.MAX_WITHDRAWAL_AMOUNT) || 100000;

export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('인증이 필요합니다.');
    }

    const body = await request.json();
    const { userId, amount, address } = body;

    // 호환성: 기존 클라이언트가 userId를 보내는 경우가 있어, 일치 여부만 검증
    if (userId && userId !== currentUser.id) {
      return forbiddenResponse('본인 계정으로만 출금 신청이 가능합니다.');
    }

    // Rate Limiting 체크 (사용자 기반, 매우 엄격)
    const rateLimitResult = await checkUserRateLimit(currentUser.id, rateLimitConfigs.withdrawal);
    if (!rateLimitResult.success) {
      return rateLimitResult.response;
    }

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['amount', 'address']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    // 금액 검증
  const amountCheck = isValidAmount(amount);
  if (!amountCheck.valid) {
    return validationErrorResponse(amountCheck.message || '출금 금액이 유효하지 않습니다.');
  }

    // 락업 상태 확인: LOCKED 또는 ACTIVE_RELEASE이며 남은 금액이 있으면 출금 제한
    const activeLockup = await prisma.lockup_settings.findFirst({
      where: {
        userId: currentUser.id,
        status: { in: ['LOCKED', 'ACTIVE_RELEASE'] },
        remainingAmount: { gt: 0 },
      },
      select: { id: true, status: true, remainingAmount: true },
    });

    if (activeLockup) {
      return forbiddenResponse('락업 상태에서는 출금이 제한됩니다.');
    }

  // 지갑 주소 검증 (MSUO 코인 주소 우선 검증)
  const upcAddressCheck = isValidMSUOWalletAddress(address);
  if (upcAddressCheck.valid) {
    // AO 지갑 주소가 유효한 경우
    console.log(`[Withdrawal] AO 지갑 주소 검증 통과: ${address}`);
    } else {
      // AO 지갑 주소가 아닌 경우, 일반 지갑 주소 검증
      const generalAddressCheck = isValidWalletAddress(address);
      if (!generalAddressCheck.valid) {
        return validationErrorResponse(
          aoAddressCheck.message || generalAddressCheck.message || '지갑 주소가 유효하지 않습니다.'
        );
      }
      console.log(`[Withdrawal] 일반 지갑 주소 검증 통과: ${address}`);
    }

    const withdrawAmount = new Prisma.Decimal(amount);

    // 최소/최대 출금 금액 체크
    if (withdrawAmount.lt(MIN_WITHDRAWAL_AMOUNT)) {
      return validationErrorResponse(`최소 출금 금액은 ${MIN_WITHDRAWAL_AMOUNT} AO입니다.`);
    }

    if (withdrawAmount.gt(MAX_WITHDRAWAL_AMOUNT)) {
      return validationErrorResponse(`최대 출금 금액은 ${MAX_WITHDRAWAL_AMOUNT} AO입니다.`);
    }

    // 트랜잭션으로 출금 신청 처리 (유저 조회 및 잔액 확인 포함, 타임아웃 30초)
    const result = await prisma.$transaction(async (tx) => {
      // 1. 유저 조회 (트랜잭션 내에서 최신 상태 확인)
      const user = await tx.users.findUnique({
        where: { id: currentUser.id },
      });

      if (!user) {
        throw new Error('USER_NOT_FOUND');
      }

      const currentBalance = new Prisma.Decimal(user.personalCoin);

      // 2. 잔액 부족 체크
      if (currentBalance.lt(withdrawAmount)) {
        throw new Error(
          `잔고가 부족합니다. (보유: ${currentBalance.toFixed(2)} AO, 요청: ${withdrawAmount.toFixed(2)} AO)`
        );
      }

      // 3. 잔액 차감
      await tx.users.update({
        where: { id: currentUser.id },
        data: {
          personalCoin: { decrement: withdrawAmount },
        },
      });

      // 4. 출금 요청 기록 생성
      const withdrawalRequest = await tx.withdrawal_requests.create({
        data: {
          userId: currentUser.id,
          amount: withdrawAmount,
          address: address.trim(),
          status: 'PENDING',
        },
      });

      return withdrawalRequest;
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    const response = successResponse(
      {
        id: result.id,
        amount: decimalToNumber(result.amount),
        address: result.address,
        status: result.status,
        requestedAt: result.requestedAt,
      },
      '출금 신청이 완료되었습니다.'
    );

    // Rate Limit 헤더 추가
    if (rateLimitResult.remaining !== undefined && rateLimitResult.resetTime) {
      response.headers.set('X-RateLimit-Remaining', rateLimitResult.remaining.toString());
      response.headers.set('X-RateLimit-Reset', new Date(rateLimitResult.resetTime).toISOString());
    }

    return response;
  } catch (error: unknown) {
    console.error('Withdrawal Error:', error);

    // 에러 타입에 따라 적절한 응답
    const message = error instanceof Error ? error.message : '출금 중 오류가 발생했습니다.';
    if (message === 'USER_NOT_FOUND') {
      return notFoundResponse('사용자를 찾을 수 없습니다.');
    }
    
    if (error.message?.includes('부족')) {
      return validationErrorResponse(error.message);
    }
    
    return errorResponse(
      error.message || '출금 신청 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

// 출금 신청 내역 조회
export async function GET(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return unauthorizedResponse('인증이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    // 호환성: userId 쿼리가 있으면 일치 여부만 확인 (타인 조회 차단)
    if (userId && userId !== currentUser.id) {
      return forbiddenResponse('본인 출금 내역만 조회할 수 있습니다.');
    }

    // 출금 신청 내역 조회 (최신순)
    const withdrawals = await prisma.withdrawal_requests.findMany({
      where: { userId: currentUser.id },
      orderBy: { requestedAt: 'desc' },
      select: {
        id: true,
        amount: true,
        address: true,
        status: true,
        requestedAt: true,
        processedAt: true,
      },
    });

    return successResponse(
      withdrawals.map((w) => ({
        id: w.id,
        amount: decimalToNumber(w.amount),
        address: w.address,
        status: w.status,
        requestedAt: w.requestedAt,
        processedAt: w.processedAt,
      }))
    );
  } catch (error: unknown) {
    console.error('출금 내역 조회 실패:', error);
    const message = error instanceof Error ? error.message : '출금 내역 조회 중 오류가 발생했습니다.';
    const stack = error instanceof Error ? error.stack : undefined;
    return errorResponse(
      message,
      500,
      'SERVER_ERROR',
      process.env.NODE_ENV === 'development' ? stack : undefined
    );
  }
}


