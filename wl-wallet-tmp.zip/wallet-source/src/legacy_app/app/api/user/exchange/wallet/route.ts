import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';
import { WalletService } from '@/services/exchange/WalletService';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 사용자 지갑 정보 조회
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    // 지갑 정보 조회
    const walletInfo = await WalletService.getWalletInfo(user.id);

    return successResponse({
      userId: user.id,
      totalBalance: decimalToNumber(walletInfo.totalBalance),
      availableBalance: decimalToNumber(walletInfo.availableBalance),
      pendingAmount: decimalToNumber(walletInfo.pendingAmount),
      walletAddress: user.walletAddress,
      lastUpdated: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('[Exchange Wallet] 지갑 정보 조회 실패:', error);
    return errorResponse(
      error.message || '지갑 정보 조회 중 오류가 발생했습니다.',
      500,
      'WALLET_INFO_ERROR'
    );
  }
}