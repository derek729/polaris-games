import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';
import { OrderService } from '@/services/exchange/OrderService';
import { TradeService } from '@/services/exchange/TradeService';
import { WalletService } from '@/services/exchange/WalletService';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 거래소 대시보드 데이터 조회
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || '24h'; // 24h, 7d, 30d

    // 병렬로 데이터 조회
    const [
      walletInfo,
      userOrders,
      userTrades,
      orderStats,
      tradeStats,
      globalStats
    ] = await Promise.all([
      // 지갑 정보
      WalletService.getWalletInfo(user.id),

      // 사용자 최근 주문 (5개)
      OrderService.getUserOrders(user.id, undefined, 5, 0),

      // 사용자 최근 거래 (10개)
      TradeService.getUserTrades(user.id, 10, 0),

      // 사용자 주문 통계
      OrderService.getOrderStats(user.id),

      // 사용자 거래 통계
      TradeService.getTradeStats(), // 전체 기간

      // 전체 24시간 통계
      TradeService.get24hStats()
    ]);

    // 기간별 시작 시간 계산
    const now = new Date();
    let startTime: Date;

    switch (period) {
      case '7d':
        startTime = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        startTime = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      case '24h':
      default:
        startTime = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        break;
    }

    // 기간별 거래 통계 조회
    const periodTradeStats = await TradeService.getTradeStats(startTime, now);

    // 포맷된 데이터
    const formattedOrders = userOrders.orders.map(order => ({
      id: order.id,
      type: order.type,
      price: decimalToNumber(order.price),
      amount: decimalToNumber(order.amount),
      filledAmount: decimalToNumber(order.filledAmount),
      remainingAmount: decimalToNumber(order.remainingAmount),
      status: order.status,
      orderType: order.orderType,
      createdAt: order.createdAt,
      updatedAt: order.updatedAt
    }));

    const formattedTrades = userTrades.trades.map(trade => ({
      id: trade.id,
      price: decimalToNumber(trade.price),
      amount: decimalToNumber(trade.amount),
      totalValue: decimalToNumber(trade.totalValue),
      type: trade.buyerId === user.id ? 'BUY' : 'SELL',
      counterparty: trade.buyerId === user.id
        ? trade.seller.username
        : trade.buyer.username,
      tradedAt: trade.tradedAt,
      txHash: trade.txHash
    }));

    return successResponse({
      // 지갑 정보
      wallet: {
        totalBalance: decimalToNumber(walletInfo.totalBalance),
        availableBalance: decimalToNumber(walletInfo.availableBalance),
        pendingAmount: decimalToNumber(walletInfo.pendingAmount)
      },

      // 주문 정보
      orders: {
        recent: formattedOrders,
        stats: {
          total: orderStats.totalOrders,
          pending: orderStats.pendingOrders,
          completed: orderStats.completedOrders,
          cancelled: orderStats.cancelledOrders,
          totalVolume: decimalToNumber(orderStats.totalVolume)
        }
      },

      // 거래 정보
      trades: {
        recent: formattedTrades,
        periodStats: {
          volume: decimalToNumber(periodTradeStats.totalVolume),
          totalValue: decimalToNumber(periodTradeStats.totalValue),
          tradeCount: periodTradeStats.totalTrades,
          avgPrice: decimalToNumber(periodTradeStats.averagePrice),
          period
        }
      },

      // 전체 시장 통계
      market: {
        ...globalStats,
        lastUpdated: new Date().toISOString()
      },

      // 요약 정보
      summary: {
        activeOrders: orderStats.pendingOrders,
        totalTrades24h: globalStats.tradeCount,
        userTradeVolume24h: userTrades.trades
          .filter(trade => {
            const tradeTime = new Date(trade.tradedAt);
            const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
            return tradeTime >= dayAgo;
          })
          .reduce((sum, trade) => sum + decimalToNumber(trade.amount), 0),
        lastTradePrice: globalStats.avgPrice
      }
    });
  } catch (error: any) {
    console.error('[Exchange Dashboard] 대시보드 데이터 조회 실패:', error);
    return errorResponse(
      error.message || '대시보드 데이터 조회 중 오류가 발생했습니다.',
      500,
      'DASHBOARD_ERROR'
    );
  }
}