import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { getCurrentMarketPrice } from '@/services/exchange-bot';
import { logger } from '@/lib/logger';

/**
 * 즉시 교환 API (AOT ↔ AO 코인)
 * 시장가로 즉시 교환합니다.
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json(
        { ok: false, error: '인증이 필요합니다.' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { type, amount } = body;

    if (!type || !amount) {
      return NextResponse.json(
        { ok: false, error: '교환 타입과 수량이 필요합니다.' },
        { status: 400 }
      );
    }

    if (type !== 'USDT_TO_AO' && type !== 'AO_TO_USDT' && type !== 'AOT_TO_AO' && type !== 'AO_TO_AOT') {
      return NextResponse.json(
        { ok: false, error: '올바른 교환 타입이 아닙니다.' },
        { status: 400 }
      );
    }

    const swapAmount = new Prisma.Decimal(amount);
    if (swapAmount.lte(0)) {
      return NextResponse.json(
        { ok: false, error: '교환 수량은 0보다 커야 합니다.' },
        { status: 400 }
      );
    }

    // 현재 시세 조회
    const currentPrice = await getCurrentMarketPrice();

    // 사용자 정보 조회
    const userData = await prisma.users.findUnique({
      where: { id: user.id },
      select: { personalCoin: true },
    });

    if (!userData) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      );
    }

    const userBalance = new Prisma.Decimal(userData.personalCoin || 0);

    // 트랜잭션으로 처리
    const result = await prisma.$transaction(async (tx) => {
      if (type === 'USDT_TO_AO' || type === 'AOT_TO_AO') {
        // AOT → AO 코인 교환
        const requiredAOT = swapAmount; // 교환할 AOT 금액
        const receivedAO = swapAmount.div(currentPrice); // 받을 AO 코인 수량

        if (userBalance.lt(requiredAOT)) {
          throw new Error(`AOT 잔액이 부족합니다. (보유: ${userBalance.toFixed(2)} AOT, 필요: ${requiredAOT.toFixed(2)} AOT)`);
        }

        // AOT 차감, AO 코인 증가
        const newBalance = userBalance.sub(requiredAOT).add(receivedAO);
        const description = `AOT → AO 코인 교환 (${requiredAOT.toFixed(2)} AOT → ${receivedAO.toFixed(8)} AO, 시세: ${currentPrice.toFixed(8)} AOT/AO)`;

        await tx.users.update({
          where: { id: user.id },
          data: {
            personalCoin: newBalance,
          },
        });

        // 거래 기록 생성
        await tx.trades.create({
          data: {
            buyOrderId: 'swap',
            sellOrderId: 'swap',
            price: currentPrice,
            amount: receivedAO,
            totalValue: swapAmount,
            buyerId: user.id,
            sellerId: 'system',
            txHash: `swap_${Date.now()}_${user.id}`,
          },
        });

        return {
          newBalance,
          receivedAmount: receivedAO,
          description,
        };
      } else {
        // AO 코인 → AOT 교환
        const requiredAO = swapAmount; // 교환할 AO 코인 수량
        const receivedAOT = swapAmount.mul(currentPrice); // 받을 AOT 금액

        if (userBalance.lt(requiredAO)) {
          throw new Error(`AO 코인 잔액이 부족합니다. (보유: ${userBalance.toFixed(8)} AO, 필요: ${requiredAO.toFixed(8)} AO)`);
        }

        // AO 코인 차감, AOT 증가
        const newBalance = userBalance.sub(requiredAO).add(receivedAOT);
        const description = `AO 코인 → AOT 교환 (${requiredAO.toFixed(8)} AO → ${receivedAOT.toFixed(2)} AOT, 시세: ${currentPrice.toFixed(8)} AOT/AO)`;

        await tx.users.update({
          where: { id: user.id },
          data: {
            personalCoin: newBalance,
          },
        });

        // 거래 기록 생성
        await tx.trades.create({
          data: {
            buyOrderId: 'swap',
            sellOrderId: 'swap',
            price: currentPrice,
            amount: swapAmount,
            totalValue: receivedAOT,
            buyerId: 'system',
            sellerId: user.id,
            txHash: `swap_${Date.now()}_${user.id}`,
          },
        });

        return {
          newBalance,
          receivedAmount: receivedAOT,
          description,
        };
      }
    });

    const { newBalance, receivedAmount, description } = result;

    logger.info('ExchangeSwap', description, {
      userId: user.id,
      type,
      amount: swapAmount.toFixed(8),
      receivedAmount: receivedAmount.toFixed(8),
      currentPrice: currentPrice.toFixed(8),
      newBalance: newBalance.toFixed(8),
    });

    return NextResponse.json({
      ok: true,
      message: '교환이 완료되었습니다.',
      data: {
        type,
        amount: swapAmount.toFixed(8),
        receivedAmount: receivedAmount.toFixed(8),
        currentPrice: currentPrice.toFixed(8),
        newBalance: newBalance.toFixed(8),
        description,
      },
    });
  } catch (error: any) {
    console.error('교환 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '교환 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}


