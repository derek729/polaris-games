import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { successResponse, errorResponse, unauthorizedResponse, notFoundResponse } from '@/lib/api-response';
import { Decimal } from '@prisma/client/runtime/library';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 주문 취소
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ orderId: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return unauthorizedResponse('로그인이 필요합니다.');
    }

    const { orderId } = await params;

    // 주문 조회
    const order = await prisma.orders.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      return notFoundResponse('주문을 찾을 수 없습니다.');
    }

    // 주문 소유자 확인
    if (order.userId !== user.id) {
      return errorResponse('주문을 취소할 권한이 없습니다.', 403, 'FORBIDDEN');
    }

    // 이미 체결되거나 취소된 주문은 취소 불가
    if (order.status === 'FILLED') {
      return errorResponse('이미 완전히 체결된 주문은 취소할 수 없습니다.', 400, 'INVALID_STATUS');
    }

    if (order.status === 'CANCELLED') {
      return errorResponse('이미 취소된 주문입니다.', 400, 'INVALID_STATUS');
    }

    // 주문 취소 및 잔액 반환
    const result = await prisma.$transaction(async (tx) => {
      // 취소할 수량 계산
      const remainingAmount = new Decimal(order.remainingAmount);

      if (order.type === 'BUY') {
        // 매수 주문 취소: USDT 반환
        const refundAmount = new Decimal(order.price).mul(remainingAmount);
        await tx.users.update({
          where: { id: user.id },
          data: {
            personalCoin: { increment: refundAmount },
          },
        });
      } else {
        // 매도 주문 취소: AO 코인 반환
        await tx.users.update({
          where: { id: user.id },
          data: {
            personalCoin: { increment: remainingAmount },
          },
        });
      }

      // 주문 상태 업데이트
      const cancelledOrder = await tx.orders.update({
        where: { id: orderId },
        data: {
          status: 'CANCELLED',
          cancelledAt: new Date(),
        },
      });

      return cancelledOrder;
    }, {
      maxWait: 30000,
      timeout: 30000,
    });

    return successResponse({
      message: '주문이 취소되었습니다.',
      orders: {
        id: result.id,
        status: result.status,
        cancelledAt: result.cancelledAt,
      },
    });
  } catch (error: any) {
    console.error('[Cancel Order] Error:', error);
    return errorResponse(
      error.message || '주문 취소 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

