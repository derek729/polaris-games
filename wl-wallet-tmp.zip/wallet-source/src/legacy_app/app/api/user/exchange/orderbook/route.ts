import { NextRequest, NextResponse } from 'next/server';
import { successResponse, errorResponse } from '@/lib/api-response';
import { OrderMatchingEngine } from '@/services/exchange/OrderMatchingEngine';

/**
 * 주문북 조회 (매수/매도 호가 및 실시간 데이터)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '20', 10);

    // 주문 매칭 엔진을 통한 실시간 주문북 데이터 가져오기
    const orderBookData = await OrderMatchingEngine.getOrderBook();

    // 개수 제한 적용
    const limitedBuyOrders = orderBookData.buyOrders.slice(0, limit);
    const limitedSellOrders = orderBookData.sellOrders.slice(0, limit);
    const limitedRecentTrades = orderBookData.recentTrades.slice(0, limit);

    return successResponse({
      buyOrders: limitedBuyOrders,
      sellOrders: limitedSellOrders,
      recentTrades: limitedRecentTrades,
      currentPrice: orderBookData.currentPrice,
      stats24h: orderBookData.stats24h,
      lastUpdated: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('[Order Book] 조회 실패:', error);
    return errorResponse(error.message || '주문북 조회 중 오류가 발생했습니다.', 500);
  }
}

