import { NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';

/**
 * 사용자 잔액 조회 API
 * AOT 잔액과 AO 코인 잔액을 분리하여 반환
 * 
 * 현재는 personalCoin을 기준으로 추정하지만,
 * 향후 정확한 분리를 위해 거래 내역 기반 계산으로 개선 예정
 */
export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json(
        { ok: false, error: '인증이 필요합니다.' },
        { status: 401 }
      );
    }

    // personalCoin (혼합 잔액)
    const personalCoin = new Prisma.Decimal(user.personalCoin || 0);
    
    // 간단한 추정 방법: personalCoin을 기준으로 비율 계산
    // 실제로는 모든 거래 내역을 추적하여 정확히 계산해야 함
    // 현재는 personalCoin을 그대로 사용하되, UI에서만 분리 표시
    
    // 리워드로 지급된 AOT 총액 계산
    const totalRewards = await prisma.reward_logs.aggregate({
      where: {
        userId: user.id,
        isPaid: true,
        OR: [
          { description: { contains: 'AOT' } },
          { description: { contains: 'USDT' } },
        ],
      },
      _sum: { amount: true },
    });
    
    const totalRewardAOT = new Prisma.Decimal(totalRewards._sum.amount || 0);
    
    // 투자로 사용된 AOT 총액 계산
    const totalInvestments = await prisma.investments.aggregate({
      where: {
        userId: user.id,
      },
      _sum: { amount: true },
    });
    
    const totalInvestmentAOT = new Prisma.Decimal(totalInvestments._sum.amount || 0);
    
    // 매수 체결로 획득한 AO 코인 총액 계산
    const buyTrades = await prisma.trades.aggregate({
      where: {
        buyerId: user.id,
        buyOrderId: { not: 'swap' },
      },
      _sum: { amount: true },
    });
    
    const totalBoughtAO = new Prisma.Decimal(buyTrades._sum.amount || 0);
    
    // 매도 체결로 획득한 AOT 총액 계산
    const sellTrades = await prisma.trades.aggregate({
      where: {
        sellerId: user.id,
        sellOrderId: { not: 'swap' },
      },
      _sum: { totalValue: true },
    });
    
    const totalSoldAOT = new Prisma.Decimal(sellTrades._sum.totalValue || 0);
    
    // 즉시 교환: AOT → AO
    const swapToAO = await prisma.trades.aggregate({
      where: {
        buyerId: user.id,
        buyOrderId: 'swap',
      },
      _sum: {
        amount: true, // 받은 AO 코인
        totalValue: true, // 사용한 AOT
      },
    });
    
    // 즉시 교환: AO → AOT
    const swapToAOT = await prisma.trades.aggregate({
      where: {
        sellerId: user.id,
        sellOrderId: 'swap',
      },
      _sum: {
        amount: true, // 사용한 AO 코인
        totalValue: true, // 받은 AOT
      },
    });
    
    // 출금으로 차감된 AO 코인
    const withdrawals = await prisma.withdrawal_requests.aggregate({
      where: {
        userId: user.id,
        status: { not: 'REJECTED' },
      },
      _sum: { amount: true },
    });
    
    const totalWithdrawnAO = new Prisma.Decimal(withdrawals._sum.amount || 0);
    
    // 매도 주문으로 차감된 AO 코인 (체결된 부분만)
    const sellOrders = await prisma.orders.aggregate({
      where: {
        userId: user.id,
        type: 'SELL',
        status: { in: ['FILLED', 'PARTIAL'] },
      },
      _sum: { filledAmount: true },
    });
    
    const totalSoldAO = new Prisma.Decimal(sellOrders._sum.filledAmount || 0);
    
    // 매수 주문으로 차감된 AOT (체결된 부분만)
    const buyOrders = await prisma.orders.findMany({
      where: {
        userId: user.id,
        type: 'BUY',
        status: { in: ['FILLED', 'PARTIAL'] },
      },
      select: {
        price: true,
        filledAmount: true,
      },
    });
    
    let totalBoughtAOTCost = new Prisma.Decimal(0);
    buyOrders.forEach(order => {
      totalBoughtAOTCost = totalBoughtAOTCost.add(order.price.mul(order.filledAmount));
    });
    
    // AOT 잔액 계산
    // = 리워드로 획득한 AOT + 매도로 획득한 AOT + AO→AOT 교환으로 획득한 AOT
    //   - 투자로 사용한 AOT - 매수 주문으로 사용한 AOT - AOT→AO 교환으로 사용한 AOT
    let aotBalance = totalRewardAOT
      .add(totalSoldAOT)
      .add(new Prisma.Decimal(swapToAOT._sum.totalValue || 0))
      .sub(totalInvestmentAOT)
      .sub(totalBoughtAOTCost)
      .sub(new Prisma.Decimal(swapToAO._sum.totalValue || 0));
    
    // AO 코인 잔액 계산
    // = 매수로 획득한 AO 코인 + AOT→AO 교환으로 획득한 AO 코인
    //   - 매도로 판매한 AO 코인 - 출금으로 차감한 AO 코인 - AO→AOT 교환으로 사용한 AO 코인
    let aoCoinBalance = totalBoughtAO
      .add(new Prisma.Decimal(swapToAO._sum.amount || 0))
      .sub(totalSoldAO)
      .sub(totalWithdrawnAO)
      .sub(new Prisma.Decimal(swapToAOT._sum.amount || 0));
    
    // 음수 방지
    if (aotBalance.lt(0)) aotBalance = new Prisma.Decimal(0);
    if (aoCoinBalance.lt(0)) aoCoinBalance = new Prisma.Decimal(0);
    
    // personalCoin과 비교하여 보정
    // personalCoin = AOT + AO 코인 (단위가 다를 수 있음)
    const calculatedTotal = aotBalance.add(aoCoinBalance);
    const actualTotal = personalCoin;
    
    // 차이가 있으면 비율로 보정
    if (calculatedTotal.gt(0) && actualTotal.gt(0)) {
      const ratio = actualTotal.div(calculatedTotal);
      aotBalance = aotBalance.mul(ratio);
      aoCoinBalance = aoCoinBalance.mul(ratio);
    } else if (calculatedTotal.eq(0) && actualTotal.gt(0)) {
      // 계산된 값이 0이지만 실제 잔액이 있으면 모두 AOT로 간주 (리워드가 대부분이므로)
      aotBalance = actualTotal;
      aoCoinBalance = new Prisma.Decimal(0);
    }

    return NextResponse.json({
      ok: true,
      data: {
        personalCoin: Number(personalCoin), // 혼합 잔액
        aotBalance: Number(aotBalance), // AOT 잔액
        aoCoinBalance: Number(aoCoinBalance), // AO 코인 잔액
      },
    });
  } catch (error: any) {
    console.error('[Balance API] Error:', error);
    return NextResponse.json(
      { ok: false, error: error.message || '잔액 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

