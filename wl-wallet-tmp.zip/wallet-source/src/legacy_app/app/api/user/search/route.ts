import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getCurrentUser } from '@/lib/auth';
import { isValidEmail } from '@/lib/validation';

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    // 현재 사용자 확인 (보안 강화)
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({
        ok: false,
        error: '로그인이 필요합니다.'
      }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const query = searchParams.get('query')?.trim();
    const type = searchParams.get('type') || 'all'; // 'email', 'username', 'wallet', 'all'

    if (!query || query.length < 2) {
      return NextResponse.json({
        ok: false,
        error: '검색어는 최소 2자 이상이어야 합니다.'
      }, { status: 400 });
    }

    // 검색 타입별 검증
    if (type === 'email' && !isValidEmail(query)) {
      return NextResponse.json({
        ok: false,
        error: '올바른 이메일 형식이 아닙니다.'
      }, { status: 400 });
    }

    // 검색 조건 구성
    let whereCondition: any = {
      AND: [
        { isActive: true },
        { status: 'ACTIVE' },
        { id: { not: currentUser.id } } // 자신 제외
      ]
    };

    if (type === 'email') {
      whereCondition.AND.push({
        email: {
          equals: query,
          mode: 'insensitive'
        }
      });
    } else if (type === 'username') {
      whereCondition.AND.push({
        username: {
          contains: query,
          mode: 'insensitive'
        }
      });
    } else if (type === 'wallet') {
      whereCondition.AND.push({
        walletAddress: {
          contains: query,
          mode: 'insensitive'
        }
      });
    } else {
      // all
      whereCondition.AND.push({
        OR: [
          {
            username: {
              contains: query,
              mode: 'insensitive'
            }
          },
          {
            email: {
              contains: query,
              mode: 'insensitive'
            }
          },
          {
            walletAddress: {
              contains: query,
              mode: 'insensitive'
            }
          }
        ]
      });
    }

    // 사용자 검색
    const users = await prisma.users.findMany({
      where: whereCondition,
      select: {
        id: true,
        username: true,
        email: true,
        walletAddress: true,
        personalCoin: true,
        rank: true,
        createdAt: true
      },
      take: 20, // 최대 20개 결과
      orderBy: [
        { username: 'asc' },
        { createdAt: 'desc' }
      ]
    });

    return NextResponse.json({
      ok: true,
      data: users.map(user => ({
        id: user.id,
        username: user.username || '미설정',
        email: user.email || '미설정',
        walletAddress: user.walletAddress || '미설정',
        personalCoin: Number(user.personalCoin) || 0,
        rank: user.rank,
        isVerified: !!user.walletAddress, // 지갑 주소 있으면 검증됨
        joinedAt: user.createdAt
      }))
    });

  } catch (error) {
    console.error('User search error:', error);
    return NextResponse.json({
      ok: false,
      error: '사용자 검색 중 오류가 발생했습니다.'
    }, { status: 500 });
  }
}