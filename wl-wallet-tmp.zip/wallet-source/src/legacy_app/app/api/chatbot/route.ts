import { NextRequest, NextResponse } from 'next/server';
import { getChatbotResponse, getQuickQuestions } from '@/services/chatbot';

/**
 * 챗봇 API 라우트
 * POST: 챗봇 응답 생성
 * GET: 빠른 질문 목록 반환
 */
export async function POST(request: NextRequest) {
  try {
    const { message } = await request.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: '메시지가 필요합니다.' },
        { status: 400 }
      );
    }

    const response = getChatbotResponse(message);

    return NextResponse.json({
      success: true,
      data: response
    });
  } catch (error: any) {
    console.error('Chatbot API error:', error);
    return NextResponse.json(
      { error: '서버 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const quickQuestions = getQuickQuestions();

    return NextResponse.json({
      success: true,
      data: { questions: quickQuestions }
    });
  } catch (error: any) {
    console.error('Chatbot API error:', error);
    return NextResponse.json(
      { error: '서버 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

