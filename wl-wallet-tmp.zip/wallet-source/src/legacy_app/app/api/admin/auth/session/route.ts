import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { UserRole } from '@prisma/client';
import { cookies } from 'next/headers';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, serverErrorResponse, unauthorizedResponse, forbiddenResponse } from '@/lib/api-response';

/**
 * 관리자 전용 세션 확인 API
 */
export async function GET(request: Request) {
  // 관리자 권한 확인
  const authResult = await requireAdmin(request);
  if (authResult) {
    // 에러 응답에서 redirectTo가 있으면 반환 (클라이언트 호환성을 위해 특별 형식 유지)
    try {
      const errorData = await authResult.json();
      return errorResponse(
        errorData.error || '관리자 인증이 필요합니다.',
        401,
        'UNAUTHORIZED',
        { redirectTo: errorData.redirectTo || '/a0-admin/login', authenticated: false }
      );
    } catch {
      return unauthorizedResponse('관리자 인증이 필요합니다.');
    }
  }

  try {
    const cookieStore = await cookies();
    const adminUserId = cookieStore.get('adminUserId')?.value;

    if (!adminUserId) {
      return errorResponse(
        '관리자 로그인이 필요합니다.',
        401,
        'UNAUTHORIZED',
        { redirectTo: '/a0-admin/login', authenticated: false }
      );
    }

    const user = await prisma.users.findUnique({
      where: { id: adminUserId },
      select: {
        id: true,
        username: true,
        email: true,
        rank: true,
        role: true,
        status: true,
        isActive: true,
      },
    });

    if (!user || !user.isActive || user.status !== 'ACTIVE') {
      // 유효하지 않은 세션
      cookieStore.delete('adminUserId');
      cookieStore.delete('adminRole');
      return errorResponse(
        '유효하지 않은 관리자 세션입니다.',
        401,
        'UNAUTHORIZED',
        { redirectTo: '/a0-admin/login', authenticated: false }
      );
    }

    // 관리자 권한 재확인
    const userRole = user.role as string;
    const isAdmin = userRole === UserRole.ADMIN || 
                    userRole === UserRole.SUPER_ADMIN ||
                    userRole === 'ADMIN' || 
                    userRole === 'SUPER_ADMIN';
    
    if (!isAdmin) {
      console.log('[Admin Session] 관리자 권한 없음:', { 
        role: user.role, 
        roleType: typeof user.role 
      });
      cookieStore.delete('adminUserId');
      cookieStore.delete('adminRole');
      return errorResponse(
        '관리자 권한이 없습니다.',
        403,
        'FORBIDDEN',
        { redirectTo: '/a0-admin/login', authenticated: false }
      );
    }

    // 성공 응답은 클라이언트 호환성을 위해 특별 형식 유지
    return NextResponse.json({
      ok: true,
      authenticated: true,
      data: user,
    }, { status: 200 });
  } catch (error: any) {
    console.error('관리자 세션 확인 실패:', error);
    return serverErrorResponse(error.message || '세션 확인 중 오류가 발생했습니다.');
  }
}

