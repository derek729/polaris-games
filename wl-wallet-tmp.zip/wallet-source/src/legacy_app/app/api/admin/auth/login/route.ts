import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { UserRole } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import { successResponse, errorResponse, validationErrorResponse, unauthorizedResponse } from '@/lib/api-response';
import { checkRateLimit, rateLimitConfigs } from '@/lib/rate-limit';

/**
 * 관리자 전용 로그인 API
 * 일반 사용자는 이 API를 통해 로그인할 수 없습니다.
 */
export async function POST(request: Request) {
  // Rate Limiting 체크 (관리자 로그인은 더 엄격하게)
  const rateLimitResult = await checkRateLimit(request, {
    ...rateLimitConfigs.auth,
    maxRequests: 5, // 관리자 로그인은 5회로 제한
    windowMs: 15 * 60 * 1000, // 15분
  });
  if (!rateLimitResult.success) {
    return rateLimitResult.response;
  }

  try {
    const body = await request.json();
    const { username, email, password } = body;

    console.log('[Admin Login] 로그인 시도:', { 
      hasUsername: !!username, 
      hasEmail: !!email,
      hasPassword: !!password 
    });

    // username 또는 email 중 하나는 필수
    const identifier = username || email;
    if (!identifier || !password) {
      console.log('[Admin Login] 필수 입력값 누락');
      return validationErrorResponse('사용자명(또는 이메일)과 비밀번호를 입력해주세요.');
    }

    // 유저 조회 (username 또는 email로 검색)
    const whereConditions: any[] = [];
    if (username) {
      whereConditions.push({ username });
      console.log('[Admin Login] username으로 검색:', username);
    }
    if (email) {
      whereConditions.push({ email });
      console.log('[Admin Login] email로 검색:', email);
    }

    if (whereConditions.length === 0) {
      return validationErrorResponse('사용자명 또는 이메일을 입력해주세요.');
    }

    console.log('[Admin Login] 검색 조건:', whereConditions);

    const user = await prisma.users.findFirst({
      where: {
        OR: whereConditions,
      },
      select: {
        id: true,
        username: true,
        email: true,
        password: true,
        status: true,
        isActive: true,
        role: true,
      },
    });

    if (!user) {
      console.log('[Admin Login] 사용자를 찾을 수 없음:', { username, email });
      // 보안을 위해 일반 사용자와 동일한 에러 메시지 반환
      return unauthorizedResponse('사용자명 또는 비밀번호가 올바르지 않습니다.');
    }

    console.log('[Admin Login] 사용자 찾음:', { 
      id: user.id, 
      username: user.username, 
      role: user.role,
      roleType: typeof user.role,
      isActive: user.isActive,
      status: user.status
    });

    // 관리자 권한 확인 (ADMIN 또는 SUPER_ADMIN만 허용)
    // role이 enum이거나 문자열일 수 있으므로 둘 다 체크
    const userRole = user.role as string;
    const isAdmin = userRole === UserRole.ADMIN || 
                    userRole === UserRole.SUPER_ADMIN ||
                    userRole === 'ADMIN' || 
                    userRole === 'SUPER_ADMIN';
    
    if (!isAdmin) {
      console.log('[Admin Login] 관리자 권한 없음:', { 
        role: user.role, 
        roleType: typeof user.role,
        expected: [UserRole.ADMIN, UserRole.SUPER_ADMIN, 'ADMIN', 'SUPER_ADMIN']
      });
      // 보안을 위해 일반 사용자와 동일한 에러 메시지 반환
      return unauthorizedResponse('사용자명 또는 비밀번호가 올바르지 않습니다.');
    }
    
    console.log('[Admin Login] 관리자 권한 확인됨:', { role: userRole });

    if (!user.isActive || user.status !== 'ACTIVE') {
      return errorResponse('비활성화된 계정입니다.', 403, 'FORBIDDEN');
    }

    // 비밀번호 확인
    if (!user.password) {
      console.log('[Admin Login] 비밀번호가 설정되지 않음');
      return unauthorizedResponse('비밀번호가 설정되지 않은 계정입니다.');
    }

    console.log('[Admin Login] 비밀번호 비교 시작');
    const isValidPassword = await bcrypt.compare(password, user.password);
    console.log('[Admin Login] 비밀번호 비교 결과:', isValidPassword);

    if (!isValidPassword) {
      console.log('[Admin Login] 비밀번호 불일치', {
        providedPasswordLength: password.length,
        storedPasswordHash: user.password.substring(0, 20) + '...',
      });
      return unauthorizedResponse('사용자명 또는 비밀번호가 올바르지 않습니다.');
    }

    console.log('[Admin Login] 비밀번호 확인 완료, 쿠키 설정 시작');

    // 관리자 전용 세션 쿠키 설정
    const cookieStore = await cookies();
    
    // 일반 사용자 쿠키는 삭제 (보안 강화)
    cookieStore.delete('userId');
    
    // 모바일 앱 호환성을 위해 쿠키 설정 조정
    const isProduction = process.env.NODE_ENV === 'production';
    const forwardedProto = request.headers.get('x-forwarded-proto');
    const isHttps = forwardedProto === 'https' || request.url.startsWith('https://');
    
    // sameSite: 'none'을 사용하려면 secure: true가 필수
    // 모바일 앱에서는 sameSite: 'lax' 또는 'none' 사용
    const cookieOptions: any = {
      httpOnly: true,
      maxAge: 60 * 60 * 24 * 7, // 7일
      path: '/',
    };

    if (isProduction && isHttps) {
      // 프로덕션 HTTPS 환경: secure + sameSite none (모바일 앱 호환)
      cookieOptions.secure = true;
      cookieOptions.sameSite = 'none';
    } else if (isProduction) {
      // 프로덕션 HTTP 환경: secure false + sameSite lax
      cookieOptions.secure = false;
      cookieOptions.sameSite = 'lax';
    } else {
      // 개발 환경: secure false + sameSite lax
      cookieOptions.secure = false;
      cookieOptions.sameSite = 'lax';
    }
    
    // 관리자 전용 쿠키 설정
    cookieStore.set('adminUserId', user.id, cookieOptions);

    // 관리자 권한 쿠키도 설정 (빠른 권한 체크용)
    cookieStore.set('adminRole', user.role, cookieOptions);

    console.log('[Admin Login] 쿠키 설정 완료:', {
      adminUserId: user.id,
      adminRole: user.role,
      username: user.username,
      secure: cookieOptions.secure,
      sameSite: cookieOptions.sameSite,
      isProduction,
      isHttps,
      forwardedProto,
    });

    const response = successResponse(
      {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
      },
      '관리자 로그인 성공'
    );

    // Rate Limit 헤더 추가
    if (rateLimitResult.remaining !== undefined && rateLimitResult.resetTime) {
      response.headers.set('X-RateLimit-Remaining', rateLimitResult.remaining.toString());
      response.headers.set('X-RateLimit-Reset', new Date(rateLimitResult.resetTime).toISOString());
    }

    return response;
  } catch (error: any) {
    console.error('관리자 로그인 실패:', error);
    return errorResponse(
      error.message || '관리자 로그인 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

