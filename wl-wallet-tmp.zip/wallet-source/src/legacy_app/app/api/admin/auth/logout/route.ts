import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { requireAdmin } from '@/lib/admin-auth';

/**
 * 관리자 전용 로그아웃 API
 */
export async function POST(request: Request) {
  // 관리자 권한 확인
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const cookieStore = await cookies();
    // 관리자 쿠키 삭제
    cookieStore.delete('adminUserId');
    cookieStore.delete('adminRole');
    // 일반 사용자 쿠키도 삭제 (혹시 모를 경우 대비)
    cookieStore.delete('userId');

    return NextResponse.json({
      ok: true,
      message: '관리자 로그아웃되었습니다.',
    });
  } catch (error: any) {
    console.error('관리자 로그아웃 실패:', error);
    return NextResponse.json(
      { ok: false, error: error.message || '로그아웃 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

