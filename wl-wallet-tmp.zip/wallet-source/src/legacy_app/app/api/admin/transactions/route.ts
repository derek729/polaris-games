import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 관리자용 전체 거래 내역 조회
export async function GET(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'all'; // all, reward, withdrawal, transfer, investment
    const period = searchParams.get('period') || '30'; // 7, 30, 90, all
    const userId = searchParams.get('userId'); // 특정 사용자 필터
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const skip = (page - 1) * limit;

    // 기간 필터
    let dateFilter: any = {};
    if (period !== 'all') {
      const days = parseInt(period);
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      dateFilter = { gte: startDate };
    }

    const transactions: any[] = [];

    // 1. 리워드 내역
    if (type === 'all' || type === 'reward') {
      const whereClause: any = {
        createdAt: dateFilter,
      };
      if (userId) whereClause.userId = userId;

      const rewards = await prisma.reward_logs.findMany({
        where: whereClause,
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit * 2, // 여러 타입을 합치므로 2배로 가져와서 페이지네이션
        skip: 0,
      });

      rewards.forEach((reward) => {
        transactions.push({
          id: reward.id,
          type: 'reward',
          typeLabel: '리워드',
          amount: decimalToNumber(reward.amount),
          description: reward.description || '리워드 지급',
          users: {
            id: reward.users.id,
            username: reward.users.username,
            email: reward.users.email,
          },
          createdAt: reward.createdAt,
          rewardType: reward.type,
        });
      });
    }

    // 2. 출금 내역
    if (type === 'all' || type === 'withdrawal') {
      const whereClause: any = {
        requestedAt: dateFilter,
      };
      if (userId) whereClause.userId = userId;

      const withdrawals = await prisma.withdrawal_requests.findMany({
        where: whereClause,
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
            },
          },
        },
        orderBy: { requestedAt: 'desc' },
        take: limit * 2,
        skip: 0,
      });

      withdrawals.forEach((withdrawal) => {
        transactions.push({
          id: withdrawal.id,
          type: 'withdrawal',
          typeLabel: '출금',
          amount: decimalToNumber(withdrawal.amount),
          description: `출금 신청 - ${withdrawal.address.slice(0, 10)}...`,
          users: {
            id: withdrawal.users.id,
            username: withdrawal.users.username,
            email: withdrawal.users.email,
          },
          status: withdrawal.status,
          address: withdrawal.address,
          createdAt: withdrawal.requestedAt,
        });
      });
    }

    // 3. 이체 내역
    if (type === 'all' || type === 'transfer') {
      const whereClause: any = {
        transferredAt: dateFilter,
      };
      if (userId) {
        whereClause.OR = [
          { senderId: userId },
          { receiverId: userId },
        ];
      }

      const transfers = await prisma.transfers.findMany({
        where: whereClause,
        include: {
          sender: {
            select: {
              id: true,
              username: true,
              email: true,
            },
          },
          receiver: {
            select: {
              id: true,
              username: true,
              email: true,
            },
          },
        },
        orderBy: { transferredAt: 'desc' },
        take: limit * 2,
        skip: 0,
      });

      transfers.forEach((transfer: any) => {
        transactions.push({
          id: transfer.id,
          type: 'transfer',
          typeLabel: '이체',
          amount: decimalToNumber(transfer.amount),
          description: `${transfer.users.username} → ${transfer.users.username}`,
          sender: {
            id: transfer.users.id,
            username: transfer.users.username,
            email: transfer.users.email,
          },
          receiver: {
            id: transfer.users.id,
            username: transfer.users.username,
            email: transfer.users.email,
          },
          txHash: transfer.txHash || null,
          networkType: transfer.networkType || 'OFF_CHAIN',
          createdAt: transfer.transferredAt,
        });
      });
    }

    // 4. 투자 내역
    if (type === 'all' || type === 'investment') {
      const whereClause: any = {
        createdAt: dateFilter,
      };
      if (userId) whereClause.userId = userId;

      const investments = await prisma.investments.findMany({
        where: whereClause,
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit * 2,
        skip: 0,
      });

      investments.forEach((investment) => {
        transactions.push({
          id: investment.id,
          type: 'investment',
          typeLabel: '투자',
          amount: decimalToNumber(investment.amount),
          description: `투자 상품 Tier ${investment.investmentTier}`,
          users: {
            id: investment.users.id,
            username: investment.users.username,
            email: investment.users.email,
          },
          dailyRate: decimalToNumber(investment.dailyRate),
          isActive: investment.isActive,
          createdAt: investment.createdAt,
        });
      });
    }

    // 날짜순 정렬 및 페이지네이션
    transactions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    const total = transactions.length;
    const paginatedTransactions = transactions.slice(skip, skip + limit);

    // 통계 계산
    const stats = {
      total: transactions.length,
      totalRewards: transactions.filter((t) => t.type === 'reward').reduce((sum, t) => sum + t.amount, 0),
      totalWithdrawals: transactions.filter((t) => t.type === 'withdrawal').reduce((sum, t) => sum + t.amount, 0),
      totalTransfers: transactions.filter((t) => t.type === 'transfer').reduce((sum, t) => sum + t.amount, 0),
      totalInvestments: transactions.filter((t) => t.type === 'investment').reduce((sum, t) => sum + t.amount, 0),
    };

    return successResponse({
      transactions: paginatedTransactions,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(total / limit),
        totalCount: total,
        limit,
        hasNext: skip + limit < total,
        hasPrev: page > 1,
      },
      stats,
    });
  } catch (error: any) {
    console.error('[Admin] 거래 내역 조회 실패:', error);
    return errorResponse(
      error.message || '거래 내역 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

