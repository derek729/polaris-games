import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { getSchedulerStatus } from '@/services/scheduler';
import { prisma } from '@/lib/prisma';

/**
 * 스케줄러 상태 확인 API
 * 자동 마감 모드 상태도 함께 확인합니다.
 */
export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const status = getSchedulerStatus();

    // 자동 마감 모드 상태 확인
    const autoModeSetting = await prisma.system_settings.findUnique({
      where: { key: 'autoSettlementEnabled' },
    });

    const isAutoModeEnabled = autoModeSetting?.value === 'true';

    return NextResponse.json({
      ok: true,
      data: {
        ...status,
        autoMode: {
          enabled: isAutoModeEnabled,
          lastUpdated: autoModeSetting?.updatedAt || null,
        },
        // 다음 실행 예정 시간 계산 (매일 23:59)
        nextExecutionTime: isAutoModeEnabled
          ? new Date(new Date().setHours(23, 59, 0, 0)).toISOString()
          : null,
      },
    });
  } catch (error: any) {
    console.error('스케줄러 상태 확인 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '스케줄러 상태 확인 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

