import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { processGameRevenuePayments } from '@/services/gameRevenueScheduler';

/**
 * 게임 수익 지급 수동 실행 (테스트/관리자용)
 * POST /api/admin/run-game-revenue
 * Body: { paymentPeriod: 'DAILY' | 'WEEKLY' | 'MONTHLY' }
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const body = await request.json().catch(() => ({}));
    const { paymentPeriod } = body; // 'DAILY' | 'WEEKLY' | 'MONTHLY'

    if (!paymentPeriod || !['DAILY', 'WEEKLY', 'MONTHLY'].includes(paymentPeriod)) {
      return NextResponse.json(
        {
          ok: false,
          error: 'paymentPeriod는 DAILY, WEEKLY, MONTHLY 중 하나여야 합니다.',
        },
        { status: 400 }
      );
    }

    console.log(`[run-game-revenue] ${paymentPeriod} 지급 주기 게임 수익 지급 수동 실행 시작...`);

    const result = await processGameRevenuePayments(paymentPeriod);

    return NextResponse.json({
      ok: true,
      message: `${paymentPeriod} 지급 주기 게임 수익 지급이 완료되었습니다.`,
      result: {
        processedCount: result.processedCount,
        errorCount: result.errorCount,
        totalPurchases: result.totalPurchases,
      },
    });
  } catch (error: any) {
    console.error('[run-game-revenue] 게임 수익 지급 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '게임 수익 지급 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

