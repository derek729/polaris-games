import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { Prisma } from '@prisma/client';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse } from '@/lib/api-response';
import { createAndDistributeGameRevenue, distributeGameRevenue } from '@/services/gameRevenue';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 게임 수익 목록 조회
export async function GET(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const gameId = searchParams.get('gameId');

    const game_revenues = await prisma.game_revenues.findMany({
      where: gameId ? { gameId } : {},
      include: {
        games: {
          select: {
            id: true,
            name: true,
          },
        },
        _count: {
          select: {
            distributions: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return successResponse(
      game_revenues.map((revenue) => ({
        id: revenue.id,
        gameId: revenue.gameId,
        gameName: revenue.games.name,
        totalRevenue: decimalToNumber(revenue.totalRevenue),
        periodStart: revenue.periodStart,
        periodEnd: revenue.periodEnd,
        description: revenue.description,
        isDistributed: revenue.isDistributed,
        distributedAt: revenue.distributedAt,
        distributionCount: revenue._count.distributions,
        createdAt: revenue.createdAt,
      }))
    );
  } catch (error: any) {
    console.error('[Admin Game Revenue] 수익 목록 조회 실패:', error);
    return errorResponse(error.message || '수익 목록 조회 중 오류가 발생했습니다.', 500);
  }
}

// 게임 수익 기록 생성 및 분배
export async function POST(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { gameId, totalRevenue, periodStart, periodEnd, description, autoDistribute } = body;

    // 입력 검증
    if (!gameId) {
      return validationErrorResponse('게임 ID는 필수입니다.');
    }

    if (!totalRevenue || totalRevenue <= 0) {
      return validationErrorResponse('총 수익은 0보다 커야 합니다.');
    }

    if (!periodStart || !periodEnd) {
      return validationErrorResponse('수익 기간 시작일과 종료일은 필수입니다.');
    }

    // 게임 존재 확인
    const game = await prisma.games.findUnique({
      where: { id: gameId },
    });

    if (!game) {
      return notFoundResponse('게임을 찾을 수 없습니다.');
    }

    // 게임 수익 기록 생성 및 분배
    const result = await createAndDistributeGameRevenue(
      gameId,
      new Prisma.Decimal(totalRevenue),
      new Date(periodStart),
      new Date(periodEnd),
      description,
      autoDistribute !== false // 기본값: true
    );

    return successResponse(
      {
        gameRevenueId: result.gameRevenueId,
        gameId,
        totalRevenue,
        periodStart,
        periodEnd,
        autoDistributed: autoDistribute !== false,
      },
      '게임 수익이 기록되고 분배되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin Game Revenue] 수익 기록 생성 실패:', error);
    return errorResponse(error.message || '수익 기록 생성 중 오류가 발생했습니다.', 500);
  }
}

// 게임 수익 수동 분배
export async function PUT(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { gameRevenueId } = body;

    if (!gameRevenueId) {
      return validationErrorResponse('게임 수익 ID는 필수입니다.');
    }

    const result = await distributeGameRevenue(gameRevenueId);

    return successResponse(
      {
        gameRevenueId,
        distributedCount: result.distributedCount,
        totalDistributedAmount: result.totalDistributedAmount,
      },
      '게임 수익이 분배되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin Game Revenue] 수익 분배 실패:', error);
    return errorResponse(error.message || '수익 분배 중 오류가 발생했습니다.', 500);
  }
}


