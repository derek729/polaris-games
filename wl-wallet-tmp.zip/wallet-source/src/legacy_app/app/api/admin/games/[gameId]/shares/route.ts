import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { Decimal } from '@prisma/client/runtime/library';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 게임 지분 상품 목록 조회
export async function GET(
  request: NextRequest,
  { params }: { params: { gameId: string } }
) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const { gameId } = params;

    const game = await prisma.games.findUnique({
      where: { id: gameId },
      include: {
        game_shares: {
          orderBy: { sharePercentage: 'asc' },
        },
      },
    });

    if (!game) {
      return notFoundResponse('게임을 찾을 수 없습니다.');
    }

    return successResponse(
      game.game_shares.map((share) => ({
        id: share.id,
        gameId: share.gameId,
        sharePercentage: decimalToNumber(share.sharePercentage),
        price: decimalToNumber(share.price),
        totalShares: share.totalShares,
        availableShares: share.availableShares,
        soldShares: share.soldShares,
        isActive: share.isActive,
        createdAt: share.createdAt,
        updatedAt: share.updatedAt,
      }))
    );
  } catch (error: any) {
    console.error('[Admin Game Shares] 지분 상품 목록 조회 실패:', error);
    return errorResponse(error.message || '지분 상품 목록 조회 중 오류가 발생했습니다.', 500);
  }
}

// 게임 지분 상품 생성
export async function POST(
  request: NextRequest,
  { params }: { params: { gameId: string } }
) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const { gameId } = params;
    const body = await request.json();
    const { sharePercentage, price, totalShares } = body;

    // 게임 존재 확인
    const game = await prisma.games.findUnique({
      where: { id: gameId },
      include: {
        game_shares: {
          where: { isActive: true },
        },
      },
    });

    if (!game) {
      return notFoundResponse('게임을 찾을 수 없습니다.');
    }

    // 입력 검증
    if (!sharePercentage || sharePercentage <= 0 || sharePercentage > 100) {
      return validationErrorResponse('지분 비율은 0보다 크고 100 이하여야 합니다.');
    }

    if (!price || price <= 0) {
      return validationErrorResponse('가격은 0보다 커야 합니다.');
    }

    if (!totalShares || totalShares <= 0) {
      return validationErrorResponse('총 지분 수는 0보다 커야 합니다.');
    }

    const sharePercentageDecimal = new Decimal(sharePercentage).div(100); // 퍼센트를 소수로 변환

    // 기존 지분 총합 확인 (100% 초과 방지)
    const existingTotalPercentage = game.game_shares.reduce(
      (sum, share) => sum.add(share.sharePercentage),
      new Decimal(0)
    );

    const newTotalPercentage = existingTotalPercentage.add(sharePercentageDecimal);
    if (newTotalPercentage.gt(1)) {
      return validationErrorResponse(
        `지분 비율이 100%를 초과합니다. (현재: ${existingTotalPercentage.mul(100).toFixed(2)}%, 추가: ${sharePercentage}%)`
      );
    }

    // 지분 상품 생성
    const gameShare = await prisma.1.create({{ data: {
        gameId,
        sharePercentage: sharePercentageDecimal,
        price: new Decimal(price),
        totalShares,
        availableShares: totalShares,
        soldShares: 0,
        isActive: true,
      },
    });

    return successResponse(
      {
        id: gameShare.id,
        gameId: gameShare.gameId,
        sharePercentage: decimalToNumber(gameShare.sharePercentage) * 100,
        price: decimalToNumber(gameShare.price),
        totalShares: gameShare.totalShares,
        availableShares: gameShare.availableShares,
        soldShares: gameShare.soldShares,
        isActive: gameShare.isActive,
        createdAt: gameShare.createdAt,
      },
      '게임 지분 상품이 생성되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin Game Shares] 지분 상품 생성 실패:', error);
    return errorResponse(error.message || '지분 상품 생성 중 오류가 발생했습니다.', 500);
  }
}

// 게임 지분 상품 수정
export async function PUT(
  request: NextRequest,
  { params }: { params: { gameId: string } }
) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { id, sharePercentage, price, totalShares, isActive } = body;

    if (!id) {
      return validationErrorResponse('지분 상품 ID는 필수입니다.');
    }

    const existingShare = await prisma.game_shares.findUnique({
      where: { id },
      include: {
        games: {
          include: {
            game_shares: {
              where: {
                isActive: true,
                id: { not: id }, // 현재 수정 중인 지분 제외
              },
            },
          },
        },
      },
    });

    if (!existingShare) {
      return notFoundResponse('지분 상품을 찾을 수 없습니다.');
    }

    // 지분 비율 변경 시 100% 초과 방지
    if (sharePercentage !== undefined) {
      const sharePercentageDecimal = new Decimal(sharePercentage).div(100);
      const existingTotalPercentage = existingShare.games.game_shares.reduce(
        (sum, share) => sum.add(share.sharePercentage),
        new Decimal(0)
      );

      const newTotalPercentage = existingTotalPercentage.add(sharePercentageDecimal);
      if (newTotalPercentage.gt(1)) {
        return validationErrorResponse(
          `지분 비율이 100%를 초과합니다. (현재: ${existingTotalPercentage.mul(100).toFixed(2)}%, 변경: ${sharePercentage}%)`
        );
      }
    }

    // 총 지분 수 변경 시 판매된 지분 수 확인
    if (totalShares !== undefined && totalShares < existingShare.soldShares) {
      return validationErrorResponse(
        `총 지분 수는 판매된 지분 수(${existingShare.soldShares})보다 작을 수 없습니다.`
      );
    }

    const gameShare = await prisma.game_shares.update({
      where: { id },
      data: {
        ...(sharePercentage !== undefined && {
          sharePercentage: new Decimal(sharePercentage).div(100),
        }),
        ...(price !== undefined && { price: new Decimal(price) }),
        ...(totalShares !== undefined && {
          totalShares,
          availableShares: totalShares - existingShare.soldShares,
        }),
        ...(isActive !== undefined && { isActive }),
      },
    });

    return successResponse(
      {
        id: gameShare.id,
        sharePercentage: decimalToNumber(gameShare.sharePercentage) * 100,
        price: decimalToNumber(gameShare.price),
        totalShares: gameShare.totalShares,
        availableShares: gameShare.availableShares,
        soldShares: gameShare.soldShares,
        isActive: gameShare.isActive,
        updatedAt: gameShare.updatedAt,
      },
      '게임 지분 상품이 수정되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin Game Shares] 지분 상품 수정 실패:', error);
    return errorResponse(error.message || '지분 상품 수정 중 오류가 발생했습니다.', 500);
  }
}

