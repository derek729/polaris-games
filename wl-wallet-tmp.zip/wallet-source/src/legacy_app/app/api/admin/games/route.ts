import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { Prisma } from '@prisma/client';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 게임 목록 조회
export async function GET(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const includeInactive = searchParams.get('includeInactive') === 'true';

    const games = await prisma.games.findMany({
      where: includeInactive ? {} : { isActive: true },
      include: {
        game_shares: {
          where: { isActive: true },
          orderBy: { sharePercentage: 'asc' },
        },
        _count: {
          select: {
            game_share_purchases: true,
            game_revenues: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return successResponse(
      games.map((game) => ({
        id: game.id,
        name: game.name,
        description: game.description,
        imageUrl: game.imageUrl,
        isActive: game.isActive,
        defaultPaymentPeriod: game.defaultPaymentPeriod,
        winRate: (game as any).winRate ? decimalToNumber((game as any).winRate) : null,
        prizeAmounts: (game as any).prizeAmounts as any,
        game_shares: game.game_shares.map((share) => ({
          id: share.id,
          sharePercentage: decimalToNumber(share.sharePercentage),
          price: decimalToNumber(share.price),
          totalShares: share.totalShares,
          availableShares: share.availableShares,
          soldShares: share.soldShares,
          isActive: share.isActive,
        })),
        purchaseCount: game._count.game_share_purchases,
        revenueCount: game._count.game_revenues,
        createdAt: game.createdAt,
        updatedAt: game.updatedAt,
      }))
    );
  } catch (error: any) {
    console.error('[Admin Games] 게임 목록 조회 실패:', error);
    return errorResponse(error.message || '게임 목록 조회 중 오류가 발생했습니다.', 500);
  }
}

// 게임 생성
export async function POST(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { name, description, imageUrl, defaultPaymentPeriod, winRate, prizeAmounts } = body;

    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return validationErrorResponse('게임 이름은 필수입니다.');
    }

    // 기본 주기 검증
    const validPeriods = ['DAILY', 'WEEKLY', 'MONTHLY'];
    const paymentPeriod = defaultPaymentPeriod && validPeriods.includes(defaultPaymentPeriod) 
      ? defaultPaymentPeriod 
      : 'DAILY';

    // 승률 검증 (0 ~ 1 사이)
    let winRateDecimal = null;
    if (winRate !== undefined && winRate !== null) {
      const winRateNum = parseFloat(winRate);
      if (isNaN(winRateNum) || winRateNum < 0 || winRateNum > 1) {
        return validationErrorResponse('승률은 0과 1 사이의 값이어야 합니다.');
      }
      winRateDecimal = new Prisma.Decimal(winRateNum);
    }

    // 추첨 금액 검증
    let prizeAmountsJson = null;
    if (prizeAmounts !== undefined && prizeAmounts !== null) {
      if (typeof prizeAmounts === 'object') {
        prizeAmountsJson = prizeAmounts;
      } else {
        return validationErrorResponse('추첨 금액은 객체 형식이어야 합니다.');
      }
    }

    const game = await prisma.1.create({{ data: {
        name: name.trim(),
        description: description?.trim() || null,
        imageUrl: imageUrl?.trim() || null,
        isActive: true,
        defaultPaymentPeriod: paymentPeriod,
        winRate: winRateDecimal,
        prizeAmounts: prizeAmountsJson,
      } as any,
      include: {
        game_shares: true,
      },
    });

    return successResponse(
      {
        id: game.id,
        name: game.name,
        description: game.description,
        imageUrl: game.imageUrl,
        isActive: game.isActive,
        defaultPaymentPeriod: game.defaultPaymentPeriod,
        winRate: (game as any).winRate ? decimalToNumber((game as any).winRate) : null,
        prizeAmounts: (game as any).prizeAmounts as any,
        createdAt: game.createdAt,
      },
      '게임이 생성되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin Games] 게임 생성 실패:', error);
    return errorResponse(error.message || '게임 생성 중 오류가 발생했습니다.', 500);
  }
}

// 게임 수정
export async function PUT(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { id, name, description, imageUrl, isActive, defaultPaymentPeriod, winRate, prizeAmounts } = body;

    if (!id) {
      return validationErrorResponse('게임 ID는 필수입니다.');
    }

    // 기본 주기 검증
    const validPeriods = ['DAILY', 'WEEKLY', 'MONTHLY'];
    const updateData: any = {
      ...(name && { name: name.trim() }),
      ...(description !== undefined && { description: description?.trim() || null }),
      ...(imageUrl !== undefined && { imageUrl: imageUrl?.trim() || null }),
      ...(isActive !== undefined && { isActive }),
    };

    if (defaultPaymentPeriod && validPeriods.includes(defaultPaymentPeriod)) {
      updateData.defaultPaymentPeriod = defaultPaymentPeriod;
    }

    // 승률 업데이트
    if (winRate !== undefined) {
      if (winRate === null || winRate === '') {
        updateData.winRate = null;
      } else {
        const winRateNum = parseFloat(winRate);
        if (isNaN(winRateNum) || winRateNum < 0 || winRateNum > 1) {
          return validationErrorResponse('승률은 0과 1 사이의 값이어야 합니다.');
        }
        updateData.winRate = new Prisma.Decimal(winRateNum);
      }
    }

    // 추첨 금액 업데이트
    if (prizeAmounts !== undefined) {
      if (prizeAmounts === null || prizeAmounts === '') {
        updateData.prizeAmounts = null;
      } else if (typeof prizeAmounts === 'object') {
        updateData.prizeAmounts = prizeAmounts;
      } else {
        return validationErrorResponse('추첨 금액은 객체 형식이어야 합니다.');
      }
    }

    const game = await prisma.games.update({
      where: { id },
      data: updateData,
    });

    return successResponse(
      {
        id: game.id,
        name: game.name,
        description: game.description,
        imageUrl: game.imageUrl,
        isActive: game.isActive,
        defaultPaymentPeriod: game.defaultPaymentPeriod,
        winRate: (game as any).winRate ? decimalToNumber((game as any).winRate) : null,
        prizeAmounts: (game as any).prizeAmounts as any,
        updatedAt: game.updatedAt,
      },
      '게임 정보가 수정되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin Games] 게임 수정 실패:', error);
    return errorResponse(error.message || '게임 수정 중 오류가 발생했습니다.', 500);
  }
}


