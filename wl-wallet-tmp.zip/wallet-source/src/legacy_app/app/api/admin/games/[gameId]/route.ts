import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse } from '@/lib/api-response';

/**
 * 게임 삭제 API
 * DELETE /api/admin/games/[gameId]
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ gameId: string }> }
) {
  try {
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    const { gameId } = await params;

    // 게임 존재 확인 및 관련 데이터 확인
    const game = await prisma.games.findUnique({
      where: { id: gameId },
      include: {
        _count: {
          select: {
            game_share_purchases: true,
            game_revenues: true,
            game_shares: true,
          },
        },
      },
    });

    if (!game) {
      return notFoundResponse('게임을 찾을 수 없습니다.');
    }

    // 구매 내역이나 수익 기록이 있으면 삭제 불가 (안전을 위해)
    if (game._count.game_share_purchases > 0 || game._count.game_revenues > 0) {
      return validationErrorResponse(
        '구매 내역이나 수익 기록이 있는 게임은 삭제할 수 없습니다. 대신 비활성화해주세요.'
      );
    }

    // 트랜잭션으로 관련 데이터와 함께 삭제
    await prisma.$transaction(async (tx) => {
      // 지분 상품 삭제
      await tx.game_shares.deleteMany({
        where: { gameId },
      });

      // 게임 삭제
      await tx.games.delete({
        where: { id: gameId },
      });
    });

    console.log(`🗑️ [Admin] 게임 삭제 완료: ${game.name} (ID: ${gameId})`);

    return successResponse(
      {
        gameId,
        gameName: game.name,
      },
      '게임이 성공적으로 삭제되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin Games] 게임 삭제 실패:', error);
    return errorResponse(error.message || '게임 삭제 중 오류가 발생했습니다.', 500);
  }
}

