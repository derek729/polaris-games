
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';

export async function GET(request: Request) {
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    try {
        // @ts-ignore: status field might not be recognized by IDE yet
        const investments = await prisma.investments.findMany({
            where: { status: 'PENDING' },
            include: { users: { select: { username: true, email: true } } },
            orderBy: { createdAt: 'desc' },
        });
        return NextResponse.json({ ok: true, data: investments });
    } catch (error) {
        console.error('Failed to fetch pending investments:', error);
        return NextResponse.json({ ok: false, error: 'Failed to fetch pending investments' }, { status: 500 });
    }
}
