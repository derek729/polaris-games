import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { distributeReferralBonus } from '@/services/referralBonus';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';

export async function POST(request: Request) {
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { investmentId, action } = body; // action: 'APPROVE' | 'REJECT' (대/소문자 호환)

    const requiredCheck = validateRequired(body, ['investmentId', 'action']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    const normalizedAction = String(action).toUpperCase();
    if (!['APPROVE', 'REJECT'].includes(normalizedAction)) {
      return validationErrorResponse('action은 APPROVE 또는 REJECT여야 합니다.');
    }

    const now = new Date();
    const endDate = new Date(now);
    endDate.setFullYear(endDate.getFullYear() + 1);

    // 동시 요청(더블 클릭/복수 관리자)에서도 1회만 처리되도록 status 조건 + updateMany 사용
    const { latestInvestment, referralParams } = await prisma.$transaction(async (tx) => {
      const investment = await tx.investments.findUnique({
        where: { id: investmentId },
      });

      if (!investment) {
        throw new Error('INVESTMENT_NOT_FOUND');
      }

      if (normalizedAction === 'APPROVE') {
        const updated = await tx.investments.updateMany({
          where: { id: investmentId, status: 'PENDING' },
          data: {
            isActive: true,
            status: 'ACTIVE',
            startDate: now, // 승인 시점부터 시작
            endDate,
          },
        });

        if (updated.count === 0) {
          throw new Error('ALREADY_PROCESSED');
        }

        // 사용자 총 투자금 업데이트 (승인 1회에만 증가)
        await tx.users.update({
          where: { id: investment.userId },
          data: { totalInvestment: { increment: investment.amount } },
        });
      } else {
        const updated = await tx.investments.updateMany({
          where: { id: investmentId, status: 'PENDING' },
          data: { status: 'REJECTED', isActive: false },
        });

        if (updated.count === 0) {
          throw new Error('ALREADY_PROCESSED');
        }
      }

      const latest = await tx.investments.findUnique({ where: { id: investmentId } });
      if (!latest) {
        throw new Error('INVESTMENT_NOT_FOUND');
      }

      return {
        latestInvestment: latest,
        referralParams: normalizedAction === 'APPROVE'
          ? { investorId: investment.userId, investmentId: investment.id, investmentAmount: investment.amount }
          : null,
      };
    }, {
      maxWait: 30000,
      timeout: 30000,
    });

    // 추천 보너스 지급(승인 시) - 실패해도 승인 자체는 유지(기존 정책 유지)
    if (referralParams) {
      try {
        await distributeReferralBonus(referralParams.investorId, referralParams.investmentId, referralParams.investmentAmount);
      } catch (e) {
        console.error('Referral bonus distribution failed:', e);
      }
    }

    return successResponse(
      { investmentId: latestInvestment.id, status: latestInvestment.status },
      normalizedAction === 'APPROVE' ? '투자가 승인되었습니다.' : '투자가 거절되었습니다.'
    );
  } catch (error: any) {
    console.error('Investment approval failed:', error);

    if (error.message === 'INVESTMENT_NOT_FOUND') {
      return notFoundResponse('투자 내역을 찾을 수 없습니다.');
    }

    if (error.message === 'ALREADY_PROCESSED') {
      return validationErrorResponse('이미 처리된 투자 요청입니다.');
    }

    return errorResponse(error.message || '투자 승인/거절 처리 중 오류가 발생했습니다.', 500, 'SERVER_ERROR');
  }
}
