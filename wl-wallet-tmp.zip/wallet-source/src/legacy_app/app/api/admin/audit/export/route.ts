import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';

export async function GET(request: NextRequest) {
  try {
    await requireAdmin(request);

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const action = searchParams.get('action') || '';
    const severity = searchParams.get('severity') || '';
    const status = searchParams.get('status') || '';
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    // 검색 조건 구성 (GET과 동일)
    const where: any = {
      description: {
        contains: '[AUDIT]',
        mode: 'insensitive'
      }
    };

    if (search) {
      where.OR = [
        {
          users: {
            OR: [
              { username: { contains: search, mode: 'insensitive' } },
              { email: { contains: search, mode: 'insensitive' } }
            ]
          }
        },
        { description: { contains: search, mode: 'insensitive' } }
      ];
    }

    if (action && action !== 'ALL') {
      where.description = {
        ...where.description,
        contains: `[AUDIT] ${action}`,
        mode: 'insensitive'
      };
    }

    if (severity && severity !== 'ALL') {
      where.description = {
        ...where.description,
        contains: `| ${severity}`,
        mode: 'insensitive'
      };
    }

    if (status && status !== 'ALL') {
      where.description = {
        ...where.description,
        contains: `| ${status}`,
        mode: 'insensitive'
      };
    }

    if (startDate || endDate) {
      where.paidAt = {};
      if (startDate) {
        where.paidAt.gte = new Date(startDate);
      }
      if (endDate) {
        where.paidAt.lte = new Date(endDate);
      }
    }

    // 모든 감사 로그 조회 (제한 없음)
    const auditLogs = await prisma.reward_logs.findMany({
      where,
      orderBy: { paidAt: 'desc' },
      select: {
        id: true,
        userId: true,
        sourceUserId: true,
        description: true,
        paidAt: true,
        users: {
          select: {
            username: true,
            email: true
          }
        },
        // sourceUser는 관계가 없으므로 sourceUserId로 조회
      }
    });

    // CSV 헤더
    const headers = [
      'Timestamp',
      'Admin User',
      'Admin Email',
      'Action',
      'Target User',
      'Severity',
      'Status',
      'IP Address',
      'Details'
    ];

    // CSV 데이터 생성
    const csvData = auditLogs.map(log => {
      const description = log.description || '';
      const auditMatch = description.match(/\[AUDIT\] (.+?) \| (.+?) \| (.+?)(?:\s*\|\s*(.+))?$/);

      const action = auditMatch?.[1] || '알 수 없음';
      const severity = auditMatch?.[2] || 'INFO';
      const status = auditMatch?.[3] || 'SUCCESS';
      let details = '';

      if (auditMatch?.[4]) {
        try {
          const parsed = JSON.parse(auditMatch[4]);
          details = JSON.stringify(parsed);
        } catch {
          details = auditMatch[4];
        }
      }

      // IP 주소 추출
      let ipAddress = '';
      if (details) {
        try {
          const parsed = JSON.parse(details);
          ipAddress = parsed.ip || '';
        } catch {
          // ignore
        }
      }

      return [
        log.paidAt?.toISOString() || new Date().toISOString(),
        log.users?.username || '',
        log.users?.email || '',
        action,
        log.sourceUserId || '시스템',
        severity,
        status,
        ipAddress,
        details.replace(/"/g, '""') // CSV escaping
      ];
    });

    // CSV 생성
    const csvContent = [
      headers.join(','),
      ...csvData.map(row =>
        row.map(field => `"${field}"`).join(',')
      )
    ].join('\n');

    // UTF-8 BOM 추가 (한글 깨짐 방지)
    const bom = '\uFEFF';
    const csvWithBom = bom + csvContent;

    return new NextResponse(csvWithBom, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="audit-logs-${new Date().toISOString().split('T')[0]}.csv"`
      }
    });

  } catch (error) {
    console.error('Error exporting audit logs:', error);
    return NextResponse.json(
      { error: 'Failed to export audit logs' },
      { status: 500 }
    );
  }
}