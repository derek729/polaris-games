import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';

// 감사 로그 인터페이스
interface AuditLogData {
  userId: string;
  action: string;
  target?: string;
  targetId?: string;
  details: Record<string, any>;
  ipAddress: string;
  userAgent?: string;
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
}

// POST /api/admin/audit - 감사 로그 생성
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      adminId,
      action,
      targetUserId = null,
      targetId = null,
      details,
      ip = null,
      userAgent = null,
      severity = 'INFO',
      status = 'SUCCESS'
    } = body;

    if (!adminId || !action) {
      return NextResponse.json(
        { ok: false, error: '관리자 ID와 액션은 필수입니다.' },
        { status: 400 }
      );
    }

    // 임시로 RewardLog에 감사 로그 기록 (향후 별도 테이블로 분리 권장)
    const auditLog = await prisma.1.create({{ data: {
        userId: adminId,
        sourceUserId: targetUserId,
        type: 'RANK', // 임시로 RANK 타입 사용
        amount: 0,
        description: `[AUDIT] ${action} | ${severity} | ${status}${details ? ` | ${JSON.stringify(details)}` : ''}`,
        isPaid: true,
        paidAt: new Date(),
      }
    });

    const auditData = {
      action,
      adminId,
      targetUserId,
      targetId,
      details,
      ip,
      userAgent,
      severity,
      status,
      timestamp: new Date().toISOString()
    };

    console.log(`🔍 [Audit] 관리자 액션 기록: ${action} (${severity}/${status})`);
    console.log(`   관리자: ${adminId}`);
    console.log(`   대상: ${targetUserId || targetId || '시스템'}`);
    if (details) console.log(`   상세: ${JSON.stringify(details)}`);

    return NextResponse.json({
      ok: true,
      message: '감사 로그가 기록되었습니다.',
      data: {
        id: auditLog.id,
        auditData
      }
    });
  } catch (error) {
    console.error('[Audit] 감사 로그 기록 실패:', error);
    return NextResponse.json(
      { ok: false, error: '감사 로그 기록 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

// GET /api/admin/audit - 감사 로그 조회
export async function GET(request: NextRequest) {
  try {
    await requireAdmin(request);

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search') || '';
    const action = searchParams.get('action') || '';
    const severity = searchParams.get('severity') || '';
    const status = searchParams.get('status') || '';
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    const skip = (page - 1) * limit;

    // 검색 조건 구성
    const where: any = {
      description: {
        contains: '[AUDIT]',
        mode: 'insensitive'
      }
    };

    // 검색어 필터링
    if (search) {
      where.OR = [
        {
          users: {
            OR: [
              { username: { contains: search, mode: 'insensitive' } },
              { email: { contains: search, mode: 'insensitive' } }
            ]
          }
        },
        { description: { contains: search, mode: 'insensitive' } }
      ];
    }

    // 액션 필터링
    if (action && action !== 'ALL') {
      where.description = {
        ...where.description,
        contains: `[AUDIT] ${action}`,
        mode: 'insensitive'
      };
    }

    // 심각도 필터링
    if (severity && severity !== 'ALL') {
      where.description = {
        ...where.description,
        contains: `| ${severity}`,
        mode: 'insensitive'
      };
    }

    // 상태 필터링
    if (status && status !== 'ALL') {
      where.description = {
        ...where.description,
        contains: `| ${status}`,
        mode: 'insensitive'
      };
    }

    // 날짜 범위 필터링
    if (startDate || endDate) {
      where.paidAt = {};
      if (startDate) {
        where.paidAt.gte = new Date(startDate);
      }
      if (endDate) {
        where.paidAt.lte = new Date(endDate);
      }
    }

    // 감사 로그 조회
    const [auditLogs, totalCount] = await Promise.all([
      prisma.reward_logs.findMany({
        where,
        skip,
        take: limit,
        orderBy: { paidAt: 'desc' },
        select: {
          id: true,
          userId: true,
          sourceUserId: true,
          description: true,
          paidAt: true,
          createdAt: true,
          users: {
            select: {
              username: true,
              email: true
            }
          },
          // sourceUser는 관계가 없으므로 sourceUserId만 사용
        }
      }),
      prisma.reward_logs.count({ where })
    ]);

    const totalPages = Math.ceil(totalCount / limit);

    // 감사 로그 데이터 포맷팅
    const formattedLogs = auditLogs.map(log => {
      const description = log.description || '';
      // 새로운 포맷: [AUDIT] action | severity | status | details
      const auditMatch = description.match(/\[AUDIT\] (.+?) \| (.+?) \| (.+?)(?:\s*\|\s*(.+))?$/);

      const action = auditMatch?.[1] || '알 수 없음';
      const severity = auditMatch?.[2] || 'INFO';
      const status = auditMatch?.[3] || 'SUCCESS';
      let details = null;

      if (auditMatch?.[4]) {
        try {
          details = JSON.parse(auditMatch[4]);
        } catch {
          details = auditMatch[4];
        }
      }

      // IP 주소 추출 (details에 있을 경우)
      let ipAddress = '192.168.1.1'; // 기본값
      if (details && typeof details === 'object' && details.ip) {
        ipAddress = details.ip;
      }

      return {
        id: log.id,
        userId: log.userId,
        userName: log.users?.username || null,
        userEmail: log.users?.email || null,
        action,
        target: log.sourceUserId || '시스템',
        targetId: log.sourceUserId,
        details: details || {},
        ipAddress,
        userAgent: details?.userAgent || 'Unknown',
        severity: severity as 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL',
        status: status as 'SUCCESS' | 'FAILED' | 'PENDING',
        timestamp: log.paidAt || log.createdAt
      };
    });

    return NextResponse.json({
      logs: formattedLogs,
      pagination: {
        currentPage: page,
        totalPages,
        totalLogs: totalCount,
        hasNext: page < totalPages,
        hasPreviousPage: page > 1
      }
    });

  } catch (error) {
    console.error('Error fetching audit logs:', error);
    return NextResponse.json(
      { error: 'Failed to fetch audit logs' },
      { status: 500 }
    );
  }
}