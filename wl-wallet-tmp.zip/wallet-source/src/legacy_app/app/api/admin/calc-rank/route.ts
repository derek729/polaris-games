import { NextResponse } from 'next/server';
import { recalcAllUserRanks } from '@/services/rankSystem';

export async function POST() {
  try {
    const result = await recalcAllUserRanks();
    return NextResponse.json({
      ok: true,
      ...result,
    });
  } catch (error) {
    console.error('[calc-rank] Failed to recalc ranks', error);
    return NextResponse.json(
      { ok: false, message: '랭크 계산 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

