import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { processDailyRewards } from '@/services/dailyReward';
import { processDailyRewardsFast } from '@/services/dailyReward-fast';
import { processAllLeadershipBonuses } from '@/services/leadershipBonus';

// Railway에서 긴 실행 시간을 허용하기 위한 설정
export const maxDuration = 300; // 5분 (Railway 최대값)
export const dynamic = 'force-dynamic';

// Railway는 실제로 60초 타임아웃이 있을 수 있으므로, 더 짧은 타임아웃으로 처리
// 배치 처리로 개선하여 처리 시간 단축

/**
 * 강제 재지급 API
 * 특정 날짜 범위에 대해 기존 지급 내역을 무시하고 강제로 재지급합니다.
 * AOT로 통일하여 지급합니다.
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const body = await request.json();
    const { startDate, endDate, filters } = body;

    if (!startDate || !endDate) {
      return NextResponse.json(
        {
          ok: false,
          error: 'startDate와 endDate가 필요합니다.',
        },
        { status: 400 }
      );
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    start.setHours(0, 0, 0, 0);
    end.setHours(23, 59, 59, 999);

    if (start > end) {
      return NextResponse.json(
        {
          ok: false,
          error: 'startDate는 endDate보다 이전이어야 합니다.',
        },
        { status: 400 }
      );
    }

    // 날짜 범위가 너무 크면 경고
    const daysDiff = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    if (daysDiff > 7) {
      return NextResponse.json(
        {
          ok: false,
          error: `한 번에 7일 이상 처리할 수 없습니다. (요청: ${daysDiff}일)\n하루씩 처리하거나 더 짧은 기간으로 나누어 처리해주세요.`,
        },
        { status: 400 }
      );
    }
    
    // 날짜 범위가 크면 경고
    if (daysDiff > 3) {
      console.warn(`⚠️ 큰 날짜 범위 처리 시작: ${daysDiff}일 (${startDate} ~ ${endDate})`);
    }

    const results = [];
    const currentDate = new Date(start);

    // 각 날짜별로 강제 재지급 실행
    while (currentDate <= end) {
      const targetDate = new Date(currentDate);
      targetDate.setHours(0, 0, 0, 0);

      try {
        // 일일 수익 강제 재지급 (AOT로 통일) - 고속 모드 사용 (필터 적용)
        const dailyResult = await processDailyRewardsFast(targetDate, true, filters);
        
        // 리더십 보너스 강제 재지급 (AOT로 통일)
        const leadershipResult = await processAllLeadershipBonuses(targetDate);

        results.push({
          date: targetDate.toISOString().split('T')[0],
          daily: {
            processed: dailyResult.processedCount,
            skipped: dailyResult.skippedCount,
            errors: dailyResult.errorCount,
            total: dailyResult.totalInvestments,
          },
          leadership: {
            processed: leadershipResult.processedCount,
            errors: leadershipResult.errorCount,
            total: leadershipResult.totalUsers,
          },
          success: true,
        });
      } catch (error: any) {
        console.error(`강제 재지급 실패 (${targetDate.toISOString().split('T')[0]}):`, error);
        results.push({
          date: targetDate.toISOString().split('T')[0],
          success: false,
          error: error.message || '알 수 없는 오류',
          errorDetails: error.stack || String(error),
        });
      }

      // 다음 날로 이동
      currentDate.setDate(currentDate.getDate() + 1);
    }

    const successCount = results.filter((r) => r.success).length;
    const failCount = results.filter((r) => !r.success).length;

    return NextResponse.json({
      ok: true,
      message: `${startDate}부터 ${endDate}까지 강제 재지급 완료`,
      summary: {
        totalDays: daysDiff,
        successDays: successCount,
        failDays: failCount,
      },
      results,
    });
  } catch (error: any) {
    console.error('강제 재지급 실패:', error);
    console.error('에러 스택:', error.stack);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '강제 재지급 중 오류가 발생했습니다.',
        errorDetails: process.env.NODE_ENV === 'development' ? error.stack : undefined,
      },
      { status: 500 }
    );
  }
}

