import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { processDailyRewards } from '@/services/dailyReward';
import { processAllLeadershipBonuses } from '@/services/leadershipBonus';
import { processGameRevenuePayments } from '@/services/gameRevenueScheduler';
import { prisma } from '@/lib/prisma';
import { RewardType } from '@prisma/client';

/**
 * 전체 마감 실행 (일일 수익 + 매칭 보너스 + 랭크 보상 + 리더십 보너스)
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const body = await request.json().catch(() => ({}));
    const { type, date } = body; // type: 'daily' | 'leadership' | 'all', date: 'YYYY-MM-DD' 형식

    // 날짜 지정 (지정하지 않으면 오늘 날짜)
    let targetDate: Date;
    if (date) {
      targetDate = new Date(date);
      targetDate.setHours(0, 0, 0, 0);
    } else {
      targetDate = new Date();
      targetDate.setHours(0, 0, 0, 0);
    }

    const results: any = {};

    // 일일 수익 지급 (매칭 보너스, 랭크 보상 포함)
    if (type === 'daily' || type === 'all' || !type) {
      try {
        const dailyResult = await processDailyRewards(targetDate);
        results.daily = dailyResult;
      } catch (error: any) {
        results.daily = {
          success: false,
          error: error.message || '일일 수익 지급 실패',
        };
      }
    }

    // 리더십 보너스 지급
    if (type === 'leadership' || type === 'all' || !type) {
      try {
        const leadershipResult = await processAllLeadershipBonuses(targetDate);
        results.leadership = leadershipResult;
      } catch (error: any) {
        results.leadership = {
          success: false,
          error: error.message || '리더십 보너스 지급 실패',
        };
      }
    }

    // 대상 날짜 마감 내역 조회
    const targetDateEnd = new Date(targetDate);
    targetDateEnd.setHours(23, 59, 59, 999);

    const targetStats = await prisma.reward_logs.groupBy({
      by: ['type'],
      where: {
        createdAt: {
          gte: targetDate,
          lte: targetDateEnd,
        },
        isPaid: true,
      },
      _count: true,
      _sum: {
        amount: true,
      },
    });

    return NextResponse.json({
      ok: true,
      message: `마감 처리가 완료되었습니다. (대상 날짜: ${targetDate.toISOString().split('T')[0]})`,
      data: {
        targetDate: targetDate.toISOString().split('T')[0],
        results,
        stats: targetStats.map((stat) => ({
          type: stat.type,
          count: stat._count,
          totalAmount: Number(stat._sum.amount || 0),
        })),
      },
    });
  } catch (error: any) {
    console.error('마감 처리 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '마감 처리 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

/**
 * 마감 내역 조회
 */
export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const { searchParams } = new URL(request.url);
    const date = searchParams.get('date'); // YYYY-MM-DD 형식

    let startDate: Date;
    let endDate: Date;

    if (date) {
      startDate = new Date(date);
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
    } else {
      // 오늘 날짜
      startDate = new Date();
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date();
      endDate.setHours(23, 59, 59, 999);
    }

    // 날짜별 통계
    const stats = await prisma.reward_logs.groupBy({
      by: ['type'],
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
        isPaid: true,
      },
      _count: true,
      _sum: {
        amount: true,
      },
    });

    // 상세 내역 (최근 100건)
    const details = await prisma.reward_logs.findMany({
      where: {
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
        isPaid: true,
      },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: 100,
    });

    return NextResponse.json({
      ok: true,
      data: {
        date: date || startDate.toISOString().split('T')[0],
        stats: stats.map((stat) => ({
          type: stat.type,
          count: stat._count,
          totalAmount: Number(stat._sum.amount || 0),
        })),
        details: details.map((detail) => ({
          id: detail.id,
          type: detail.type,
          amount: Number(detail.amount),
          description: detail.description,
          createdAt: detail.createdAt.toISOString(),
          users: detail.users,
        })),
      },
    });
  } catch (error: any) {
    console.error('마감 내역 조회 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '마감 내역 조회 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

