import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';

/**
 * 일일 수익 지급 상태 확인 API
 * Railway 환경에서 관리자 페이지에서 직접 확인할 수 있습니다.
 */
export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    // 1. 활성 투자 건 확인
    const activeInvestments = await prisma.investments.findMany({
      where: { isActive: true },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // 2. 오늘 일일 수익 지급 내역
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayRewards = await prisma.reward_logs.findMany({
      where: {
        type: 'DAILY',
        isPaid: true,
        createdAt: { gte: today },
      },
      include: {
        users: {
          select: {
            username: true,
            email: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // 3. 어제 일일 수익 지급 내역
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    const yesterdayRewards = await prisma.reward_logs.findMany({
      where: {
        type: 'DAILY',
        isPaid: true,
        createdAt: {
          gte: yesterday,
          lt: today,
        },
      },
    });

    // 4. 지급되지 않은 투자 건 확인
    const paidInvestmentIds = new Set(
      todayRewards
        .map((r) => r.sourceInvestmentId)
        .filter((id): id is string => id !== null)
    );

    const unpaidInvestments = activeInvestments
      .filter((inv) => !paidInvestmentIds.has(inv.id))
      .map((inv) => ({
        id: inv.id,
        userId: inv.userId,
        username: inv.users.username || inv.users.email || inv.userId,
        amount: Number(inv.amount),
        dailyRate: Number(inv.dailyRate),
        expectedDailyProfit: Number(inv.amount) * Number(inv.dailyRate),
        startDate: inv.startDate.toISOString(),
      }));

    // 5. 자동 모드 상태
    const autoModeSetting = await prisma.system_settings.findUnique({
      where: { key: 'autoSettlementEnabled' },
    });

    const isAutoModeEnabled = autoModeSetting?.value === 'true';

    // 통계 계산
    const todayTotal = todayRewards.reduce((sum, r) => sum + Number(r.amount), 0);
    const yesterdayTotal = yesterdayRewards.reduce((sum, r) => sum + Number(r.amount), 0);
    const totalInvestmentAmount = activeInvestments.reduce(
      (sum, inv) => sum + Number(inv.amount),
      0
    );
    const expectedDailyTotal = activeInvestments.reduce(
      (sum, inv) => sum + Number(inv.amount) * Number(inv.dailyRate),
      0
    );

    return NextResponse.json({
      ok: true,
      data: {
        activeInvestments: {
          count: activeInvestments.length,
          totalAmount: Number(totalInvestmentAmount.toFixed(2)),
          expectedDailyTotal: Number(expectedDailyTotal.toFixed(2)),
        },
        today: {
          count: todayRewards.length,
          totalAmount: Number(todayTotal.toFixed(2)),
          rewards: todayRewards.slice(0, 10).map((r) => ({
            id: r.id,
            userId: r.userId,
            username: r.users.username || r.users.email || r.userId,
            amount: Number(r.amount),
            createdAt: r.createdAt.toISOString(),
          })),
        },
        yesterday: {
          count: yesterdayRewards.length,
          totalAmount: Number(yesterdayTotal.toFixed(2)),
        },
        unpaidInvestments: {
          count: unpaidInvestments.length,
          list: unpaidInvestments.slice(0, 20),
        },
        autoMode: {
          enabled: isAutoModeEnabled,
        },
        status: {
          hasActiveInvestments: activeInvestments.length > 0,
          isTodayPaid: todayRewards.length > 0,
          hasUnpaidInvestments: unpaidInvestments.length > 0,
          message:
            activeInvestments.length === 0
              ? '활성 투자 건이 없습니다.'
              : todayRewards.length === 0
              ? '오늘 일일 수익이 지급되지 않았습니다.'
              : unpaidInvestments.length > 0
              ? `${unpaidInvestments.length}건의 투자에 대해 일일 수익이 지급되지 않았습니다.`
              : '일일 수익 지급이 정상적으로 작동하고 있습니다.',
        },
      },
    });
  } catch (error: any) {
    console.error('일일 수익 확인 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '일일 수익 확인 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

