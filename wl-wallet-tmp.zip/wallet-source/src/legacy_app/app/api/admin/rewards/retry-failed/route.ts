import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { processDailyRewards } from '@/services/dailyReward';
import { prisma } from '@/lib/prisma';
import { RewardType } from '@prisma/client';

/**
 * 실패한 투자 건 재처리 API
 * 특정 날짜에 지급되지 않은 투자 건을 재처리합니다.
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const body = await request.json().catch(() => ({}));
    const { date, investmentIds } = body; // date: 'YYYY-MM-DD', investmentIds: string[] (선택사항)

    // 날짜 지정 (지정하지 않으면 오늘 날짜)
    let targetDate: Date;
    if (date) {
      targetDate = new Date(date);
      targetDate.setHours(0, 0, 0, 0);
    } else {
      targetDate = new Date();
      targetDate.setHours(0, 0, 0, 0);
    }

    const targetEnd = new Date(targetDate);
    targetEnd.setHours(23, 59, 59, 999);

    // 지급되지 않은 투자 건 조회
    const whereCondition: any = {
      isActive: true,
      startDate: { lte: targetEnd },
      endDate: { gte: targetDate },
    };

    // 특정 투자 건 ID가 지정된 경우
    if (investmentIds && Array.isArray(investmentIds) && investmentIds.length > 0) {
      whereCondition.id = { in: investmentIds };
    }

    const investments = await prisma.investments.findMany({
      where: whereCondition,
      include: { users: true },
    });

    // 이미 지급된 투자 건 필터링
    const paidInvestmentIds = await prisma.reward_logs.findMany({
      where: {
        type: RewardType.DAILY,
        createdAt: {
          gte: targetDate,
          lte: targetEnd,
        },
        isPaid: true,
        sourceInvestmentId: { in: investments.map(inv => inv.id) },
      },
      select: {
        sourceInvestmentId: true,
      },
    });

    const paidIds = new Set(paidInvestmentIds.map(r => r.sourceInvestmentId).filter(Boolean));
    const unpaidInvestments = investments.filter(inv => !paidIds.has(inv.id));

    if (unpaidInvestments.length === 0) {
      return NextResponse.json({
        ok: true,
        message: '재처리할 투자 건이 없습니다.',
        data: {
          totalInvestments: investments.length,
          paidCount: paidInvestmentIds.length,
          unpaidCount: 0,
        },
      });
    }

    console.log(`[retry-failed] 재처리 대상: ${unpaidInvestments.length}건 (총 ${investments.length}건 중)`);

    // 재처리 실행
    const result = await processDailyRewards(targetDate, false);

    // 재처리 후 다시 확인
    const afterPaidCount = await prisma.reward_logs.count({
      where: {
        type: RewardType.DAILY,
        createdAt: {
          gte: targetDate,
          lte: targetEnd,
        },
        isPaid: true,
        sourceInvestmentId: { in: investments.map(inv => inv.id) },
      },
    });

    return NextResponse.json({
      ok: true,
      message: `재처리 완료: ${result.processedCount}건 처리, ${result.errorCount}건 오류`,
      data: {
        targetDate: targetDate.toISOString().split('T')[0],
        beforePaidCount: paidInvestmentIds.length,
        afterPaidCount,
        processedCount: result.processedCount,
        errorCount: result.errorCount,
        skippedCount: result.skippedCount,
        consistencyCheck: result.consistencyCheck,
        failedInvestments: result.failedInvestments || [],
      },
    });
  } catch (error: any) {
    console.error('실패한 투자 건 재처리 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '재처리 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

