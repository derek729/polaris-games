import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';

/**
 * 자동 모드 상태 조회
 */
export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const setting = await prisma.system_settings.findUnique({
      where: { key: 'autoSettlementEnabled' },
    });

    const isEnabled = setting?.value === 'true';

    return NextResponse.json({
      ok: true,
      data: {
        enabled: isEnabled,
        lastUpdated: setting?.updatedAt || null,
      },
    });
  } catch (error: any) {
    console.error('자동 모드 상태 조회 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '자동 모드 상태 조회 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

/**
 * 자동 모드 활성화/비활성화
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const body = await request.json().catch(() => ({}));
    const { enabled } = body; // boolean

    if (typeof enabled !== 'boolean') {
      return NextResponse.json(
        {
          ok: false,
          error: 'enabled 파라미터는 boolean 타입이어야 합니다.',
        },
        { status: 400 }
      );
    }

    await prisma.system_settings.upsert({
      where: { key: 'autoSettlementEnabled' },
      update: { value: enabled.toString() },
      create: {
        key: 'autoSettlementEnabled',
        value: enabled.toString(),
        description: '수당 마감 자동 모드 활성화 여부',
      },
    });

    return NextResponse.json({
      ok: true,
      message: enabled
        ? '자동 모드가 활성화되었습니다. 매일 자정에 자동으로 마감이 실행됩니다.'
        : '자동 모드가 비활성화되었습니다.',
      data: {
        enabled,
      },
    });
  } catch (error: any) {
    console.error('자동 모드 설정 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '자동 모드 설정 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

