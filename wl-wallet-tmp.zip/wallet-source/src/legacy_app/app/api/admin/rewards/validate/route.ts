import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';
import { RewardType } from '@prisma/client';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 리워드 집계 검증 API
 * 총 리워드가 총 투자금보다 많은지 확인하고, 중복 지급이나 잘못된 지급을 검증합니다.
 */
export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    // 1. 총 투자금 조회
    const totalInvestments = await prisma.investments.aggregate({
      _sum: { amount: true },
      _count: true,
    });

    const totalInvestmentAmount = decimalToNumber(totalInvestments._sum.amount);

    // 2. 총 리워드 조회 (지급된 것만, AOT로 지급된 것만, 기존 USDT 내역도 포함)
    const totalRewards = await prisma.reward_logs.aggregate({
      where: {
        isPaid: true,
        OR: [
          { description: { contains: 'AOT' } }, // AOT로 지급된 것만 집계
          { description: { contains: 'USDT' } }, // 기존 USDT 내역 호환성
        ],
      },
      _sum: { amount: true },
      _count: true,
    });

    const totalRewardAmount = decimalToNumber(totalRewards._sum.amount);

    // 3. 리워드 타입별 집계 (AOT로 지급된 것만, 기존 USDT 내역도 포함)
    const rewardByType = await prisma.reward_logs.groupBy({
      by: ['type'],
      where: {
        isPaid: true,
        OR: [
          { description: { contains: 'AOT' } }, // AOT로 지급된 것만 집계
          { description: { contains: 'USDT' } }, // 기존 USDT 내역 호환성
        ],
      },
      _sum: { amount: true },
      _count: true,
    });

    // 4. 중복 지급 확인 (같은 투자 건에 같은 날짜에 여러 번 지급된 경우)
    // Prisma의 groupBy having은 지원하지 않으므로, 다른 방식으로 확인
    const allDailyRewards = await prisma.reward_logs.findMany({
      where: {
        isPaid: true,
        sourceInvestmentId: { not: null },
        type: RewardType.DAILY,
      },
      select: {
        id: true,
        sourceInvestmentId: true,
        createdAt: true,
        amount: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    // 날짜별로 그룹화하여 중복 확인
    const rewardMap = new Map<string, Array<{ id: string; amount: any; createdAt: Date }>>();
    for (const reward of allDailyRewards) {
      if (!reward.sourceInvestmentId) continue;
      const dateKey = `${reward.sourceInvestmentId}-${reward.createdAt.toISOString().split('T')[0]}`;
      if (!rewardMap.has(dateKey)) {
        rewardMap.set(dateKey, []);
      }
      rewardMap.get(dateKey)!.push({
        id: reward.id,
        amount: reward.amount,
        createdAt: reward.createdAt,
      });
    }

    const duplicateRewards: Array<{
      sourceInvestmentId: string;
      date: string;
      count: number;
      totalAmount: number;
    }> = [];
    
    for (const [key, rewards] of rewardMap.entries()) {
      if (rewards.length > 1) {
        const [investmentId, date] = key.split('-');
        const totalAmount = rewards.reduce((sum, r) => sum + decimalToNumber(r.amount), 0);
        duplicateRewards.push({
          sourceInvestmentId: investmentId,
          date,
          count: rewards.length,
          totalAmount,
        });
      }
    }

    // 5. 일일 수익 리워드만 집계 (매칭, 랭크, 리더십 제외, AOT로 지급된 것만, 기존 USDT 내역도 포함)
    const dailyRewardsOnly = await prisma.reward_logs.aggregate({
      where: {
        isPaid: true,
        type: RewardType.DAILY,
        OR: [
          { description: { contains: 'AOT' } }, // AOT로 지급된 것만 집계
          { description: { contains: 'USDT' } }, // 기존 USDT 내역 호환성
        ],
      },
      _sum: { amount: true },
      _count: true,
    });

    const dailyRewardAmount = decimalToNumber(dailyRewardsOnly._sum.amount);

    // 6. 검증 결과
    const validation = {
      totalInvestment: totalInvestmentAmount,
      totalReward: totalRewardAmount,
      dailyRewardOnly: dailyRewardAmount,
      difference: totalRewardAmount - totalInvestmentAmount,
      ratio: totalInvestmentAmount > 0 ? (totalRewardAmount / totalInvestmentAmount) * 100 : 0,
      isAbnormal: totalRewardAmount > totalInvestmentAmount * 1.5, // 투자금의 150%를 초과하면 비정상
      hasDuplicates: duplicateRewards.length > 0,
      duplicateCount: duplicateRewards.length,
    };

    // 7. 상세 분석
    const analysis = {
      rewardByType: rewardByType.map(r => ({
        type: r.type,
        amount: decimalToNumber(r._sum.amount),
        count: r._count,
        percentage: totalRewardAmount > 0 ? (decimalToNumber(r._sum.amount) / totalRewardAmount) * 100 : 0,
      })),
      duplicateDetails: duplicateRewards.slice(0, 10).map(d => ({
        sourceInvestmentId: d.sourceInvestmentId,
        date: d.date,
        count: d.count,
        totalAmount: d.totalAmount,
      })),
      recommendation: validation.isAbnormal
        ? '⚠️ 총 리워드가 총 투자금보다 많습니다. 중복 지급이나 잘못된 지급을 확인하세요.'
        : validation.hasDuplicates
        ? '⚠️ 중복 지급이 감지되었습니다. 상세 내역을 확인하세요.'
        : '✅ 리워드 집계가 정상입니다.',
    };

    return NextResponse.json({
      ok: true,
      data: {
        validation,
        analysis,
        summary: {
          totalInvestmentCount: totalInvestments._count,
          totalRewardCount: totalRewards._count,
          dailyRewardCount: dailyRewardsOnly._count,
        },
      },
    });
  } catch (error: any) {
    console.error('리워드 검증 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '리워드 검증 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

