import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { RewardType } from '@prisma/client';

/**
 * 어제 지급된 AO 코인을 차감하고 AOT로 재지급하는 API
 * 관리자만 접근 가능
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    // 어제 날짜 계산
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    yesterday.setHours(0, 0, 0, 0);
    
    const yesterdayEnd = new Date(yesterday);
    yesterdayEnd.setHours(23, 59, 59, 999);

    console.log(`\n어제(${yesterday.toISOString().split('T')[0]}) 지급 내역 재정산 시작...\n`);

    // 어제 지급된 DAILY 타입 리워드 조회
    const yesterdayRewards = await prisma.reward_logs.findMany({
      where: {
        type: RewardType.DAILY,
        isPaid: true,
        createdAt: {
          gte: yesterday,
          lte: yesterdayEnd,
        },
      },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });

    console.log(`재정산 대상: ${yesterdayRewards.length}건\n`);

    if (yesterdayRewards.length === 0) {
      return NextResponse.json({
        success: true,
        message: '재정산할 내역이 없습니다.',
        totalCount: 0,
        successCount: 0,
        errorCount: 0,
        skippedCount: 0,
      });
    }

    let successCount = 0;
    let errorCount = 0;
    let skippedCount = 0;
    const errors: Array<{ rewardId: string; error: string }> = [];

    for (const reward of yesterdayRewards) {
      try {
        // sourceInvestmentId가 없으면 스킵
        if (!reward.sourceInvestmentId) {
          console.log(`⚠️  ${reward.id}: sourceInvestmentId 없음 - 스킵`);
          skippedCount++;
          continue;
        }

        // Investment 정보 별도 조회
        const investment = await prisma.investments.findUnique({
          where: { id: reward.sourceInvestmentId },
          select: {
            id: true,
            amount: true,
            dailyRate: true,
          },
        });

        if (!investment) {
          console.log(`⚠️  ${reward.id}: Investment 정보 없음 - 스킵`);
          skippedCount++;
          continue;
        }
        
        // AOT 금액 재계산
        const dailyProfitUSDT = new Prisma.Decimal(investment.amount).mul(investment.dailyRate);
        
        // 기존 지급된 AO 코인 수량
        const paidAOAmount = new Prisma.Decimal(reward.amount);

        await prisma.$transaction(async (tx) => {
          // 1. 기존 AO 코인 차감
          await tx.users.update({
            where: { id: reward.userId },
            data: {
              personalCoin: { decrement: paidAOAmount },
            },
          });

          // 2. 기존 리워드 로그 삭제
          await tx.reward_logs.delete({
            where: { id: reward.id },
          });

          // 3. AOT로 재지급
          await tx.reward_logs.create({
            data: {
              userId: reward.userId,
              type: RewardType.DAILY,
              amount: dailyProfitUSDT,
              sourceInvestmentId: investment.id,
              description: `일일 수익 지급 (율: ${investment.dailyRate}, AOT: ${dailyProfitUSDT.toFixed(2)}, 날짜: ${yesterday.toISOString().split('T')[0]}, 재정산)`,
              isPaid: true,
              paidAt: new Date(),
              createdAt: yesterday,
            },
          });

          // 4. AOT로 재지급
          await tx.users.update({
            where: { id: reward.userId },
            data: {
              personalCoin: { increment: dailyProfitUSDT },
            },
          });
        });

        const username = reward.users?.username || reward.users?.email || reward.userId;
        console.log(`✅ ${username}: AO ${paidAOAmount.toFixed(8)} 차감 → AOT ${dailyProfitUSDT.toFixed(2)} 지급`);
        successCount++;
      } catch (error: any) {
        console.error(`❌ ${reward.id} 재정산 실패:`, error.message);
        errors.push({
          rewardId: reward.id,
          error: error.message || String(error),
        });
        errorCount++;
      }
    }

    console.log(`\n재정산 완료:`);
    console.log(`  성공: ${successCount}건`);
    console.log(`  실패: ${errorCount}건`);
    console.log(`  스킵: ${skippedCount}건`);
    console.log(`  총계: ${yesterdayRewards.length}건\n`);

    return NextResponse.json({
      success: true,
      message: '재정산이 완료되었습니다.',
      targetDate: yesterday.toISOString().split('T')[0],
      totalCount: yesterdayRewards.length,
      successCount,
      errorCount,
      skippedCount,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error: any) {
    console.error('재정산 API 오류:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || '재정산 처리 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}


