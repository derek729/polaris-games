import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 원본 AO 코인 지급 내역 정리 API
 * description에 "USDT"가 없는 리워드를 찾아서 삭제합니다.
 * 재정산 후 남아있는 원본 AO 코인 지급 내역을 정리하는 용도입니다.
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const body = await request.json();
    const { targetDate, dryRun = true } = body;

    if (!targetDate) {
      return NextResponse.json(
        {
          ok: false,
          error: 'targetDate가 필요합니다. (예: "2025-12-12")',
        },
        { status: 400 }
      );
    }

    // 날짜 범위 계산
    const dateStart = new Date(targetDate);
    dateStart.setHours(0, 0, 0, 0);
    const dateEnd = new Date(targetDate);
    dateEnd.setHours(23, 59, 59, 999);

    // description에 "AOT" 또는 "USDT"가 없는 리워드 찾기 (원본 MSUO 코인 지급 내역)
    const aoRewards = await prisma.reward_logs.findMany({
      where: {
        isPaid: true,
        createdAt: {
          gte: dateStart,
          lte: dateEnd,
        },
        NOT: {
          OR: [
            { description: { contains: 'AOT' } },
            { description: { contains: 'USDT' } },
          ],
        },
      },
      include: {
        users: {
          select: {
            username: true,
            email: true,
          },
        },
      },
    });

    console.log(`[Cleanup MSUO Coin] ${targetDate} 원본 MSUO 코인 지급 내역: ${aoRewards.length}건`);

    if (aoRewards.length === 0) {
      return NextResponse.json({
        ok: true,
        data: {
          message: '원본 AO 코인 지급 내역이 없습니다.',
          deletedCount: 0,
          totalAmount: 0,
        },
      });
    }

    // 타입별 집계
    const byType = new Map<string, { count: number; total: Decimal }>();
    for (const reward of aoRewards) {
      const existing = byType.get(reward.type) || { count: 0, total: new Prisma.Decimal(0) };
      byType.set(reward.type, {
        count: existing.count + 1,
        total: existing.total.add(reward.amount),
      });
    }

    const summary = Array.from(byType.entries()).map(([type, data]) => ({
      type,
      count: data.count,
      totalAmount: decimalToNumber(data.total),
    }));

    const totalAmount = aoRewards.reduce(
      (sum, r) => sum.add(r.amount),
      new Prisma.Decimal(0)
    );

    // Dry run 모드면 삭제하지 않고 정보만 반환
    if (dryRun) {
      return NextResponse.json({
        ok: true,
        data: {
          message: 'Dry run 모드: 실제로 삭제하지 않았습니다.',
          foundCount: aoRewards.length,
          totalAmount: decimalToNumber(totalAmount),
          summary,
          samples: aoRewards.slice(0, 10).map((r) => ({
            id: r.id,
            type: r.type,
            userId: r.userId,
            username: r.users?.username || r.users?.email || r.userId,
            amount: decimalToNumber(r.amount),
            description: r.description || '(description 없음)',
          })),
        },
      });
    }

    // 실제 삭제 실행
    let deletedCount = 0;
    let errorCount = 0;
    const errors: Array<{ rewardId: string; error: string }> = [];

    for (const reward of aoRewards) {
      try {
        await prisma.$transaction(async (tx) => {
          // 1. 사용자 잔액에서 차감
          await tx.users.update({
            where: { id: reward.userId },
            data: {
              personalCoin: { decrement: reward.amount },
            },
          });

          // 2. 리워드 로그 삭제
          await tx.reward_logs.delete({
            where: { id: reward.id },
          });
        });

        deletedCount++;
      } catch (error: any) {
        console.error(`[Cleanup MSUO Coin] ${reward.id} 삭제 실패:`, error.message);
        errorCount++;
        errors.push({
          rewardId: reward.id,
          error: error.message || String(error),
        });
      }
    }

    return NextResponse.json({
      ok: true,
      data: {
        message: '원본 AO 코인 지급 내역 정리 완료',
        deletedCount,
        errorCount,
        totalAmount: decimalToNumber(totalAmount),
        summary,
        errors: errors.slice(0, 10), // 최대 10개 오류만 반환
      },
    });
  } catch (error: any) {
    console.error('[Cleanup MSUO Coin] 오류:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '원본 MSUO 코인 지급 내역 정리 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}


