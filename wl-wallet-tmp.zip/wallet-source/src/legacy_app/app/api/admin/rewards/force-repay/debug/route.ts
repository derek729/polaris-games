import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';
import { RewardType } from '@prisma/client';

/**
 * 강제 재지급 디버그 API
 * 특정 날짜의 활성 투자 건과 기존 지급 내역을 확인합니다.
 */
export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const { searchParams } = new URL(request.url);
    const dateStr = searchParams.get('date');

    if (!dateStr) {
      return NextResponse.json(
        {
          ok: false,
          error: 'date 파라미터가 필요합니다.',
        },
        { status: 400 }
      );
    }

    const target = new Date(dateStr);
    target.setHours(0, 0, 0, 0);
    
    const targetEnd = new Date(target);
    targetEnd.setHours(23, 59, 59, 999);

    // 활성 투자 건 조회
    const investments = await prisma.investments.findMany({
      where: {
        isActive: true,
        startDate: { lte: targetEnd },
        endDate: { gte: target },
      },
      include: { users: true },
      take: 10, // 샘플로 10건만
    });

    // 기존 지급 내역 조회
    const existingRewards = await prisma.reward_logs.findMany({
      where: {
        type: RewardType.DAILY,
        createdAt: {
          gte: target,
          lte: targetEnd,
        },
        isPaid: true,
      },
      take: 10, // 샘플로 10건만
    });

    // 통계
    const totalInvestments = await prisma.investments.count({
      where: {
        isActive: true,
        startDate: { lte: targetEnd },
        endDate: { gte: target },
      },
    });

    const totalRewards = await prisma.reward_logs.count({
      where: {
        type: RewardType.DAILY,
        createdAt: {
          gte: target,
          lte: targetEnd,
        },
        isPaid: true,
      },
    });

    return NextResponse.json({
      ok: true,
      data: {
        date: dateStr,
        targetDate: target.toISOString(),
        targetEndDate: targetEnd.toISOString(),
        investments: {
          total: totalInvestments,
          sample: investments.map((inv) => ({
            id: inv.id,
            userId: inv.userId,
            username: inv.users.username,
            amount: inv.amount.toString(),
            dailyRate: inv.dailyRate.toString(),
            startDate: inv.startDate.toISOString(),
            endDate: inv.endDate.toISOString(),
            isActive: inv.isActive,
          })),
        },
        existingRewards: {
          total: totalRewards,
          sample: existingRewards.map((reward) => ({
            id: reward.id,
            userId: reward.userId,
            amount: reward.amount.toString(),
            sourceInvestmentId: reward.sourceInvestmentId,
            createdAt: reward.createdAt.toISOString(),
            description: reward.description,
          })),
        },
      },
    });
  } catch (error: any) {
    console.error('디버그 정보 조회 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '디버그 정보 조회 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

