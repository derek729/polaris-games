import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';

/**
 * 어제 수당 마감 실행 여부 확인 API
 * Railway 환경에서 관리자 페이지에서 직접 확인할 수 있습니다.
 */
export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    // 어제 날짜 계산 (한국 시간 기준)
    const now = new Date();
    const koreaTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Seoul' }));
    const yesterday = new Date(koreaTime);
    yesterday.setDate(yesterday.getDate() - 1);
    yesterday.setHours(0, 0, 0, 0);

    const yesterdayEnd = new Date(yesterday);
    yesterdayEnd.setHours(23, 59, 59, 999);

    const yesterdayStr = yesterday.toISOString().split('T')[0];

    // 1. 자동 모드 활성화 상태 확인
    const autoModeSetting = await prisma.system_settings.findUnique({
      where: { key: 'autoSettlementEnabled' },
    });

    const isAutoModeEnabled = autoModeSetting?.value === 'true';

    // 2. 어제 날짜의 마감 내역 통계
    const stats = await prisma.reward_logs.groupBy({
      by: ['type'],
      where: {
        createdAt: {
          gte: yesterday,
          lte: yesterdayEnd,
        },
        isPaid: true,
      },
      _count: true,
      _sum: {
        amount: true,
      },
    });

    const totalCount = stats.reduce((sum, stat) => sum + stat._count, 0);
    // Decimal 타입을 올바르게 변환 (AOT 기준)
    const totalAmount = stats.reduce(
      (sum, stat) => {
        const amount = stat._sum.amount;
        return sum + (amount ? Number(amount.toString()) : 0);
      },
      0
    );

    // 3. 어제 자정 시간대 (00:00 ~ 01:00) 마감 실행 확인
    const midnightStart = new Date(yesterday);
    midnightStart.setHours(0, 0, 0, 0);

    const midnightEnd = new Date(yesterday);
    midnightEnd.setHours(1, 0, 0, 0);

    const midnightRewards = await prisma.reward_logs.findMany({
      where: {
        createdAt: {
          gte: midnightStart,
          lt: midnightEnd,
        },
        isPaid: true,
      },
      orderBy: {
        createdAt: 'asc',
      },
      take: 10,
    });

    // 4. 최근 3일간 마감 내역 비교
    const recentDaysStats = [];
    for (let i = 2; i >= 0; i--) {
      const checkDate = new Date(koreaTime);
      checkDate.setDate(checkDate.getDate() - i);
      checkDate.setHours(0, 0, 0, 0);

      const checkDateEnd = new Date(checkDate);
      checkDateEnd.setHours(23, 59, 59, 999);

      const dateStats = await prisma.reward_logs.groupBy({
        by: ['type'],
        where: {
          createdAt: {
            gte: checkDate,
            lte: checkDateEnd,
          },
          isPaid: true,
        },
        _count: true,
        _sum: {
          amount: true,
        },
      });

      const dayTotalCount = dateStats.reduce((sum, stat) => sum + stat._count, 0);
      // Decimal 타입을 올바르게 변환 (AOT 기준)
      const dayTotalAmount = dateStats.reduce(
        (sum, stat) => {
          const amount = stat._sum.amount;
          return sum + (amount ? Number(amount.toString()) : 0);
        },
        0
      );

      recentDaysStats.push({
        date: checkDate.toISOString().split('T')[0],
        daysAgo: i,
        totalCount: dayTotalCount,
        totalAmount: Number(dayTotalAmount.toFixed(2)),
        stats: dateStats.map((stat) => {
          const amount = stat._sum.amount;
          return {
            type: stat.type,
            count: stat._count,
            totalAmount: amount ? Number(amount.toString()) : 0,
          };
        }),
      });
    }

    // 타입 이름 매핑
    const typeNameMap: Record<string, string> = {
      DAILY: '일일 수익',
      REFERRAL: '추천 보너스',
      MATCHING: '매칭 보너스',
      RANK: '랭크 보상',
      TEAM: '리더십 보너스',
    };

    return NextResponse.json({
      ok: true,
      data: {
        checkDate: yesterdayStr,
        autoMode: {
          enabled: isAutoModeEnabled,
          setting: autoModeSetting
            ? {
                value: autoModeSetting.value,
                description: autoModeSetting.description,
                updatedAt: autoModeSetting.updatedAt.toISOString(),
              }
            : null,
        },
        yesterday: {
          totalCount,
          totalAmount: Number(totalAmount.toFixed(2)),
          stats: stats.map((stat) => {
            const amount = stat._sum.amount;
            return {
              type: stat.type,
              typeName: typeNameMap[stat.type] || stat.type,
              count: stat._count,
              totalAmount: amount ? Number(amount.toString()) : 0,
            };
          }),
          midnightRewards: {
            count: midnightRewards.length,
            firstRewards: midnightRewards.slice(0, 5).map((reward) => ({
              type: reward.type,
              typeName: typeNameMap[reward.type] || reward.type,
              amount: Number(reward.amount),
              createdAt: reward.createdAt.toISOString(),
            })),
          },
        },
        recentDays: recentDaysStats,
        conclusion: {
          wasExecuted: totalCount > 0,
          message:
            totalCount === 0
              ? '어제 마감이 실행되지 않았습니다. 자동 모드 상태와 서버 로그를 확인하세요.'
              : `어제 마감이 정상적으로 실행되었습니다. 총 ${totalCount}건, ${totalAmount.toFixed(2)} AOT가 지급되었습니다.`,
          recommendations:
            totalCount === 0
              ? [
                  '관리자 페이지에서 자동 모드 상태를 확인하세요.',
                  'Railway 로그에서 자정 시간대의 에러를 확인하세요.',
                  '수동으로 어제 날짜 마감을 실행하세요.',
                ]
              : ['정상적으로 실행되었습니다.'],
        },
      },
    });
  } catch (error: any) {
    console.error('어제 마감 확인 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '어제 마감 확인 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

