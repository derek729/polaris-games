import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';

/**
 * 특정 날짜에 활성 투자 건이 있는 사용자 ID 목록 조회
 */
export async function GET(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const { searchParams } = new URL(request.url);
    const date = searchParams.get('date');

    if (!date) {
      return NextResponse.json(
        {
          ok: false,
          error: 'date 파라미터가 필요합니다.',
        },
        { status: 400 }
      );
    }

    const target = new Date(date);
    target.setHours(0, 0, 0, 0);
    
    const targetEnd = new Date(target);
    targetEnd.setHours(23, 59, 59, 999);

    // 해당 날짜에 활성 투자 건이 있는 사용자 ID 목록 조회
    const investments = await prisma.investments.findMany({
      where: {
        isActive: true,
        startDate: { lte: targetEnd },
        endDate: { gte: target },
      },
      select: {
        userId: true,
      },
      distinct: ['userId'],
    });

    const userIds = investments.map(inv => inv.userId).sort();

    return NextResponse.json({
      ok: true,
      date,
      userIds,
      count: userIds.length,
    });
  } catch (error: any) {
    console.error('사용자 ID 목록 조회 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error.message || '사용자 ID 목록 조회 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}

