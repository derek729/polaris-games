import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { RewardType } from '@prisma/client';

/**
 * 특정 날짜의 AO 코인 지급을 AOT로 변환하는 API
 * 관리자만 접근 가능
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const body = await request.json();
    const { targetDate } = body;

    if (!targetDate) {
      return NextResponse.json(
        {
          success: false,
          error: 'targetDate가 필요합니다. (예: "2024-12-11")',
        },
        { status: 400 }
      );
    }

    // 날짜 파싱
    const target = new Date(targetDate);
    target.setHours(0, 0, 0, 0);
    
    const targetEnd = new Date(target);
    targetEnd.setHours(23, 59, 59, 999);

    console.log(`\n${targetDate} 지급 내역 재정산 시작 (AO 코인 → AOT)...\n`);

    // 해당 날짜의 모든 타입 리워드 조회 (DAILY, REFERRAL, MATCHING, RANK, TEAM)
    const rewards = await prisma.reward_logs.findMany({
      where: {
        isPaid: true,
        createdAt: {
          gte: target,
          lte: targetEnd,
        },
      },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });

    console.log(`재정산 대상: ${rewards.length}건\n`);

    if (rewards.length === 0) {
      return NextResponse.json({
        success: true,
        message: '재정산할 내역이 없습니다.',
        targetDate,
        totalCount: 0,
        successCount: 0,
        errorCount: 0,
        skippedCount: 0,
      });
    }

    let successCount = 0;
    let errorCount = 0;
    let skippedCount = 0;
    const errors: Array<{ rewardId: string; error: string }> = [];

    // 타입별 처리
    for (const reward of rewards) {
      try {
        let usdtAmount: Decimal;
        let description: string;

        if (reward.type === RewardType.DAILY) {
          // 일일 수익: Investment 정보 필요
          if (!reward.sourceInvestmentId) {
            console.log(`⚠️  ${reward.id}: sourceInvestmentId 없음 - 스킵`);
            skippedCount++;
            continue;
          }

          const investment = await prisma.investments.findUnique({
            where: { id: reward.sourceInvestmentId },
            select: {
              id: true,
              amount: true,
              dailyRate: true,
            },
          });

          if (!investment) {
            console.log(`⚠️  ${reward.id}: Investment 정보 없음 - 스킵`);
            skippedCount++;
            continue;
          }

          // AOT 금액 재계산
          usdtAmount = new Prisma.Decimal(investment.amount).mul(investment.dailyRate);
          description = `일일 수익 지급 (율: ${investment.dailyRate}, AOT: ${usdtAmount.toFixed(2)}, 날짜: ${targetDate}, AO→AOT 변환)`;
        } else {
          // 다른 타입 (REFERRAL, MATCHING, RANK, TEAM): 기존 금액을 그대로 사용
          // 이미 AOT로 지급되었을 수도 있으므로, description을 확인하거나
          // 기존 amount를 그대로 사용 (이미 AOT 기준일 수 있음)
          usdtAmount = new Prisma.Decimal(reward.amount);
          
          const typeNames: Record<string, string> = {
            REFERRAL: '추천 보너스',
            MATCHING: '매칭 보너스',
            RANK: '랭크 보상',
            TEAM: '리더십 보너스',
          };
          
          description = `${typeNames[reward.type] || reward.type} (AOT: ${usdtAmount.toFixed(2)}, 날짜: ${targetDate}, AO→AOT 변환)`;
        }

        // 기존 지급된 금액 (AO 코인 또는 AOT)
        const paidAmount = new Prisma.Decimal(reward.amount);

        await prisma.$transaction(async (tx) => {
          // 1. 기존 지급 금액 차감
          await tx.users.update({
            where: { id: reward.userId },
            data: {
              personalCoin: { decrement: paidAmount },
            },
          });

          // 2. 기존 리워드 로그 삭제
          await tx.reward_logs.delete({
            where: { id: reward.id },
          });

          // 3. AOT로 재지급
          await tx.reward_logs.create({
            data: {
              userId: reward.userId,
              type: reward.type,
              amount: usdtAmount,
              sourceInvestmentId: reward.sourceInvestmentId,
              sourceUserId: reward.sourceUserId,
              generation: reward.generation,
              description,
              isPaid: true,
              paidAt: new Date(),
              createdAt: target, // 원래 날짜 유지
            },
          });

          // 4. AOT로 재지급
          await tx.users.update({
            where: { id: reward.userId },
            data: {
              personalCoin: { increment: usdtAmount },
            },
          });
        });

        const username = reward.users?.username || reward.users?.email || reward.userId;
        console.log(`✅ ${username} (${reward.type}): ${paidAmount.toFixed(8)} 차감 → AOT ${usdtAmount.toFixed(2)} 지급`);
        successCount++;
      } catch (error: any) {
        console.error(`❌ ${reward.id} 재정산 실패:`, error.message);
        errors.push({
          rewardId: reward.id,
          error: error.message || String(error),
        });
        errorCount++;
      }
    }

    console.log(`\n재정산 완료:`);
    console.log(`  성공: ${successCount}건`);
    console.log(`  실패: ${errorCount}건`);
    console.log(`  스킵: ${skippedCount}건`);
    console.log(`  총계: ${rewards.length}건\n`);

    return NextResponse.json({
      success: true,
      message: `${targetDate} 재정산이 완료되었습니다.`,
      targetDate,
      totalCount: rewards.length,
      successCount,
      errorCount,
      skippedCount,
      errors: errors.length > 0 ? errors : undefined,
    });
  } catch (error: any) {
    console.error('재정산 API 오류:', error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || '재정산 처리 중 오류가 발생했습니다.',
      },
      { status: 500 }
    );
  }
}


