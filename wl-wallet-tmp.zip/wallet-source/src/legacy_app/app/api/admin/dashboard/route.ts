import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAdmin } from '@/lib/admin-auth'
import { successResponse, errorResponse } from '@/lib/api-response'

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0)

// 대시보드 데이터 조회
export async function GET() {
  // 관리자 권한 체크
  const authResult = await requireAdmin({} as any)
  if (authResult) return authResult

  try {
    const now = new Date()
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1)
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0)

    // 병렬로 데이터 조회
    const [
      totalUsers,
      activeUsers,
      todayUsers,
      totalInvestments,
      activeInvestments,
      monthlyInvestments,
      lastMonthInvestments,
      todayInvestments,
      totalWithdrawals,
      pendingWithdrawals,
      todayWithdrawals,
      approvedWithdrawals,
      rejectedWithdrawals,
      totalRewards,
      monthlyRewards,
      todayRewards,
      rankDistribution,
      recentUsers,
      recentWithdrawals,
      topInvestors,
      systemMetrics
    ] = await Promise.all([
      // 기본 사용자 통계
      prisma.users.count(),
      prisma.users.count({ where: { isActive: true, status: 'ACTIVE' } }),
      prisma.users.count({
        where: {
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0))
          }
        }
      }),

      // 투자 통계
      prisma.investments.aggregate({
        _sum: { amount: true },
        _count: true
      }),
      prisma.investments.count({ where: { isActive: true } }),
      prisma.investments.aggregate({
        where: {
          createdAt: { gte: startOfMonth }
        },
        _sum: { amount: true },
        _count: true
      }),
      prisma.investments.aggregate({
        where: {
          createdAt: {
            gte: startOfLastMonth,
            lte: endOfLastMonth
          }
        },
        _sum: { amount: true },
        _count: true
      }),
      prisma.investments.aggregate({
        where: {
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0))
          }
        },
        _sum: { amount: true },
        _count: true
      }),

      // 출금 통계
      prisma.withdrawal_requests.aggregate({
        _sum: { amount: true },
        _count: true
      }),
      prisma.withdrawal_requests.count({ where: { status: 'PENDING' } }),
      prisma.withdrawal_requests.aggregate({
        where: {
          requestedAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0))
          }
        },
        _sum: { amount: true },
        _count: true
      }),
      prisma.withdrawal_requests.count({ where: { status: 'APPROVED' } }),
      prisma.withdrawal_requests.count({ where: { status: 'REJECTED' } }),

      // 보상 통계 (지급된 리워드만 집계)
      // AOT로 지급된 리워드만 집계 (기존 USDT 내역도 포함)
      // - description에 "AOT" 또는 "USDT"가 포함된 것만 집계 (정상 AOT 지급 + 재정산된 것 포함)
      // - description에 "AO"만 있고 "AOT"/"USDT"가 없는 것은 제외 (원본 AO 코인 지급 내역)
      prisma.reward_logs.aggregate({
        where: {
          isPaid: true, // 지급된 리워드만 집계
          OR: [
            { description: { contains: 'AOT' } }, // AOT로 지급된 것만 집계
            { description: { contains: 'USDT' } }, // 기존 USDT 내역 호환성
          ],
        },
        _sum: { amount: true },
        _count: true
      }),
      prisma.reward_logs.aggregate({
        where: {
          isPaid: true, // 지급된 리워드만 집계
          OR: [
            { description: { contains: 'AOT' } },
            { description: { contains: 'USDT' } },
          ],
          createdAt: { gte: startOfMonth }
        },
        _sum: { amount: true },
        _count: true
      }),
      prisma.reward_logs.aggregate({
        where: {
          isPaid: true, // 지급된 리워드만 집계
          OR: [
            { description: { contains: 'AOT' } },
            { description: { contains: 'USDT' } },
          ],
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0))
          }
        },
        _sum: { amount: true },
        _count: true
      }),

      // 랭크 분포
      prisma.users.groupBy({
        by: ['rank'],
        _count: true
      }),

      // 최근 활동
      prisma.users.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          username: true,
          email: true,
          rank: true,
          totalInvestment: true,
          createdAt: true,
          other_users_users_referrerIdTousers: {
            select: { username: true }
          }
        }
      }),

      // 최근 출금 요청
      prisma.withdrawal_requests.findMany({
        take: 5,
        orderBy: { requestedAt: 'desc' },
        select: {
          id: true,
          amount: true,
          status: true,
          requestedAt: true,
          users: {
            select: {
              username: true,
              email: true
            }
          }
        }
      }),

      // 상위 투자자
      prisma.users.findMany({
        take: 5,
        orderBy: { totalInvestment: 'desc' },
        select: {
          id: true,
          username: true,
          email: true,
          rank: true,
          totalInvestment: true,
          createdAt: true,
          _count: {
            select: {
              other_users_users_referrerIdTousers: true,
              investments: true
            }
          }
        }
      }),

      // 시스템 메트릭
      Promise.all([
        prisma.investments.findFirst({
          orderBy: { createdAt: 'asc' },
          select: { createdAt: true }
        }),
        prisma.withdrawal_requests.findFirst({
          orderBy: { requestedAt: 'asc' },
          select: { requestedAt: true }
        }),
        prisma.reward_logs.findFirst({
          orderBy: { createdAt: 'asc' },
          select: { createdAt: true }
        })
      ])
    ])

    // 투자 증감률 계산
    const currentMonthInvestment = decimalToNumber(monthlyInvestments._sum.amount)
    const lastMonthInvestment = decimalToNumber(lastMonthInvestments._sum.amount)
    const investmentGrowthRate = lastMonthInvestment > 0
      ? ((currentMonthInvestment - lastMonthInvestment) / lastMonthInvestment) * 100
      : 0

    // 시스템 메트릭 정리
    const [firstInvestment, firstWithdrawal, firstReward] = systemMetrics;
    const systemDaysSinceLaunch = firstInvestment?.createdAt
      ? Math.floor((now.getTime() - firstInvestment.createdAt.getTime()) / (1000 * 60 * 60 * 24))
      : 0

    // 리워드 타입별 집계 (검증용) - AOT로 지급된 것만 (기존 USDT 내역도 포함)
    const rewardByType = await prisma.reward_logs.groupBy({
      by: ['type'],
      where: {
        isPaid: true,
        OR: [
          { description: { contains: 'AOT' } }, // AOT로 지급된 것만 집계
          { description: { contains: 'USDT' } }, // 기존 USDT 내역 호환성
        ],
      },
      _sum: { amount: true },
      _count: true,
    });

    return successResponse({
      overview: {
        totalUsers,
        activeUsers,
        todayUsers,
        totalInvestment: decimalToNumber(totalInvestments._sum.amount),
        totalInvestmentCount: totalInvestments._count,
        activeInvestments,
        monthlyInvestment: currentMonthInvestment,
        investmentGrowthRate,
        todayInvestment: decimalToNumber(todayInvestments._sum.amount),
        totalWithdrawal: decimalToNumber(totalWithdrawals._sum.amount),
        pendingWithdrawals,
        approvedWithdrawals,
        rejectedWithdrawals,
        todayWithdrawal: decimalToNumber(todayWithdrawals._sum.amount),
        totalRewards: decimalToNumber(totalRewards._sum.amount),
        monthlyRewards: decimalToNumber(monthlyRewards._sum.amount),
        todayRewards: decimalToNumber(todayRewards._sum.amount),
        rewardByType: rewardByType.map(r => ({
          type: r.type,
          amount: decimalToNumber(r._sum.amount),
          count: r._count,
        })),
      },

      rankDistribution: rankDistribution.map(item => ({
        rank: item.rank,
        count: item._count
      })),

      recentActivities: {
        newUsers: recentUsers.map(user => ({
          ...users,
          totalInvestment: decimalToNumber(user.totalInvestment)
        })),
        withdrawals: recentWithdrawals.map(withdrawal => ({
          ...withdrawal,
          amount: decimalToNumber(withdrawal.amount)
        }))
      },

      topInvestors: topInvestors.map(investor => ({
        ...investor,
        totalInvestment: decimalToNumber(investor.totalInvestment)
      })),

      systemMetrics: {
        daysSinceLaunch: systemDaysSinceLaunch,
        firstInvestmentDate: firstInvestment?.createdAt,
        firstWithdrawalDate: firstWithdrawal?.requestedAt,
        firstRewardDate: firstReward?.createdAt
      }
    }, '관리자 대시보드 데이터 조회 성공')
  } catch (error: any) {
    console.error('[Admin] 대시보드 데이터 조회 실패:', error)
    return errorResponse(
      error.message || '대시보드 데이터 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    )
  }
}