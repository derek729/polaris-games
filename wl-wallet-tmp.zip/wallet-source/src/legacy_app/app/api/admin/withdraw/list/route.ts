import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// GET: 모든 출금 신청 내역 조회 (관리자용)
export async function GET(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status'); // PENDING, APPROVED, REJECTED 필터

    // 출금 신청 내역 조회
    const withdrawals = await prisma.withdrawal_requests.findMany({
      where: status ? { status: status.toUpperCase() } : undefined,
      orderBy: { requestedAt: 'desc' },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
    });

    return successResponse(
      withdrawals.map((w) => ({
        id: w.id,
        userId: w.userId,
        username: w.users.username,
        email: w.users.email,
        amount: decimalToNumber(w.amount),
        address: w.address,
        status: w.status,
        requestedAt: w.requestedAt,
        processedAt: w.processedAt,
      }))
    );
  } catch (error: any) {
    console.error('[Admin] 출금 내역 조회 실패:', error);
    return errorResponse(
      error.message || '출금 내역 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

