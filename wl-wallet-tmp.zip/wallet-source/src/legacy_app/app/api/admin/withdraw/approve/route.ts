import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse, handlePrismaError } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// POST: 출금 승인/거절 처리 (기존 API와의 호환성을 위해 POST 유지)
export async function POST(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { requestId, action, rejectionReason } = body; // action: 'APPROVE' | 'REJECT' 또는 'approve' | 'reject'

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['requestId', 'action']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    // action을 대문자로 정규화 (호환성 유지)
    const normalizedAction = action?.toUpperCase();

    if (!['APPROVE', 'REJECT'].includes(normalizedAction)) {
      return validationErrorResponse('action은 APPROVE 또는 REJECT여야 합니다.');
    }

    // 트랜잭션으로 승인/거절 처리 (타임아웃 30초)
    // 중요: 동시 요청(더블 클릭/복수 관리자)에서도 1회만 처리되도록 updateMany + status 조건으로 원자 처리
    const result = await prisma.$transaction(async (tx) => {
      // 1) 출금 신청 조회 (환불을 위해 userId/amount 필요)
      const withdrawal = await tx.withdrawal_requests.findUnique({
        where: { id: requestId },
      });

      if (!withdrawal) {
        throw new Error('WITHDRAWAL_NOT_FOUND');
      }

      const now = new Date();

      if (normalizedAction === 'APPROVE') {
        // 2-A) 승인: PENDING -> APPROVED (원자 처리)
        const updated = await tx.withdrawal_requests.updateMany({
          where: { id: requestId, status: 'PENDING' },
          data: { status: 'APPROVED', processedAt: now },
        });

        if (updated.count === 0) {
          throw new Error('ALREADY_PROCESSED');
        }
      } else {
        // 2-B) 거절: PENDING -> REJECTED (원자 처리) 후 환불
        const updated = await tx.withdrawal_requests.updateMany({
          where: { id: requestId, status: 'PENDING' },
          data: { status: 'REJECTED', processedAt: now },
        });

        if (updated.count === 0) {
          throw new Error('ALREADY_PROCESSED');
        }

        // 거절 처리: 차감된 금액 환불 (Rollback)
        await tx.users.update({
          where: { id: withdrawal.userId },
          data: {
            personalCoin: { increment: withdrawal.amount },
          },
        });
      }

      // 3) 최신 상태 반환
      const updatedWithdrawal = await tx.withdrawal_requests.findUnique({
        where: { id: requestId },
      });

      if (!updatedWithdrawal) {
        throw new Error('WITHDRAWAL_NOT_FOUND');
      }

      return updatedWithdrawal;
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    return successResponse(
      {
        id: result.id,
        amount: decimalToNumber(result.amount),
        address: result.address,
        status: result.status,
        processedAt: result.processedAt,
      },
      normalizedAction === 'APPROVE'
        ? '출금 신청이 승인되었습니다.'
        : '출금 신청이 거절되었고 잔고가 복구되었습니다.'
    );
  } catch (error: any) {
    console.error('Withdrawal Approval Error:', error);

    // 에러 타입에 따라 적절한 응답
    if (error.message === 'WITHDRAWAL_NOT_FOUND') {
      return notFoundResponse('출금 신청을 찾을 수 없습니다.');
    }
    
    if (error.message === 'ALREADY_PROCESSED') {
      return validationErrorResponse('이미 처리된 요청입니다.');
    }

    // Prisma 에러 처리
    if (error.code?.startsWith('P')) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }

    return errorResponse(
      error.message || '출금 처리 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

