import { NextResponse } from 'next/server';
import { processAllLeadershipBonuses } from '@/services/leadershipBonus';

export async function POST() {
  try {
    const result = await processAllLeadershipBonuses();
    return NextResponse.json({
      ok: true,
      message: '리더십 보너스 처리가 완료되었습니다.',
      data: result,
    });
  } catch (error: any) {
    console.error('리더십 보너스 처리 실패:', error);
    return NextResponse.json(
      { ok: false, error: error.message || '리더십 보너스 처리 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

