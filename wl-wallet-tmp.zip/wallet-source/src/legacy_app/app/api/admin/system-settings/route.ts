
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, serverErrorResponse } from '@/lib/api-response';

export async function GET(request: Request) {
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    try {
        const settings = await prisma.system_settings.findMany();
        const settingsMap = settings.reduce((acc, curr) => {
            acc[curr.key] = curr.value;
            return acc;
        }, {} as Record<string, string>);

        return successResponse(settingsMap);
    } catch (error) {
        console.error('시스템 설정 조회 실패:', error);
        return serverErrorResponse('설정 조회 실패');
    }
}

export async function PUT(request: Request) {
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    try {
        const body = await request.json();
        const {
            usdtAddress,
            upcTotalSupply,
            upcInitialPrice,
            upcCurrentPrice,
            exchangeBotEnabled,
            exchangeBotMinPrice,
            exchangeBotMaxPrice,
            exchangeBotSpread,
            exchangeBotOrderAmount,
            upcSellAmount,
        } = body;

        if (usdtAddress !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'usdtAddress' },
                update: { value: usdtAddress },
                create: { key: 'usdtAddress', value: usdtAddress, description: 'USDT Deposit Address' },
            });
        }

        if (upcTotalSupply !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'upcTotalSupply' },
                update: { value: upcTotalSupply },
                create: { key: 'upcTotalSupply', value: upcTotalSupply, description: 'MSUO Total Supply (총 발행량)' },
            });
        }

        if (upcInitialPrice !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'upcInitialPrice' },
                update: { value: upcInitialPrice },
                create: { key: 'upcInitialPrice', value: upcInitialPrice, description: 'MSUO Initial Price (시작가, USDT)' },
            });
        }

        if (upcCurrentPrice !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'upcCurrentPrice' },
                update: { value: upcCurrentPrice },
                create: { key: 'upcCurrentPrice', value: upcCurrentPrice, description: 'MSUO Current Price (현재 시세 강제 설정, MSUO)' },
            });
        }

        if (upcSellAmount !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'upcSellAmount' },
                update: { value: upcSellAmount },
                create: { key: 'upcSellAmount', value: upcSellAmount, description: 'MSUO 판매 수량 (관리자 판매용, MSUO)' },
            });
        }

        // 거래 봇 설정
        if (exchangeBotEnabled !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'exchangeBotEnabled' },
                update: { value: exchangeBotEnabled.toString() },
                create: { key: 'exchangeBotEnabled', value: exchangeBotEnabled.toString(), description: '거래 봇 활성화 여부' },
            });
        }

        if (exchangeBotMinPrice !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'exchangeBotMinPrice' },
                update: { value: exchangeBotMinPrice },
                create: { key: 'exchangeBotMinPrice', value: exchangeBotMinPrice, description: '거래 봇 최저가 (USDT)' },
            });
        }

        if (exchangeBotMaxPrice !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'exchangeBotMaxPrice' },
                update: { value: exchangeBotMaxPrice },
                create: { key: 'exchangeBotMaxPrice', value: exchangeBotMaxPrice, description: '거래 봇 최고가 (USDT)' },
            });
        }

        if (exchangeBotSpread !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'exchangeBotSpread' },
                update: { value: exchangeBotSpread },
                create: { key: 'exchangeBotSpread', value: exchangeBotSpread, description: '거래 봇 스프레드 (가격 차이, USDT)' },
            });
        }

        if (exchangeBotOrderAmount !== undefined) {
            await prisma.system_settings.upsert({
                where: { key: 'exchangeBotOrderAmount' },
                update: { value: exchangeBotOrderAmount },
                create: { key: 'exchangeBotOrderAmount', value: exchangeBotOrderAmount, description: '거래 봇 주문 수량 (MSUO)' },
            });
        }

        return successResponse(undefined, '설정이 저장되었습니다.');
    } catch (error) {
        console.error('시스템 설정 저장 실패:', error);
        return serverErrorResponse('설정 저장 실패');
    }
}
