import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import { startDailyRewardScheduler, restartScheduler } from '@/services/scheduler';

/**
 * 스케줄러 시작/재시작 API
 * 관리자가 수동으로 호출하여 일일 리워드 스케줄러를 시작하거나 재시작합니다.
 */
export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const body = await request.json().catch(() => ({}));
    const { restart } = body;

    let result;
    if (restart) {
      result = restartScheduler();
    } else {
      result = startDailyRewardScheduler();
    }

    if (result.success) {
      return NextResponse.json({
        ok: true,
        message: result.message,
      });
    } else {
      return NextResponse.json(
        {
          ok: false,
          message: result.message,
        },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('[start-scheduler] 스케줄러 시작 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        message: '스케줄러 시작에 실패했습니다.',
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

