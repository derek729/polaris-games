import { NextResponse } from 'next/server';
import { processDailyRewards } from '@/services/dailyReward';

export async function POST() {
  try {
    await processDailyRewards();
    return NextResponse.json({ ok: true, message: 'Daily rewards processed.' });
  } catch (error) {
    console.error('[run-daily] Failed to process daily rewards', error);
    return NextResponse.json(
      { ok: false, message: 'Failed to process daily rewards.' },
      { status: 500 }
    );
  }
}

