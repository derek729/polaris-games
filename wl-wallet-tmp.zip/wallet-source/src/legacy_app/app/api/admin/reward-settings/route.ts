import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRange } from '@/lib/validation';

// 보상 설정 조회
export async function GET(request: NextRequest) {
  try {
    const authError = await requireAdmin(request);
    if (authError) return authError;

    // DB에서 보상 설정 조회
    const [referralBonusSetting, matchingBonusSetting, leadershipBonusSetting] = await Promise.all([
      prisma.system_settings.findUnique({ where: { key: 'reward.referralBonus' } }),
      prisma.system_settings.findUnique({ where: { key: 'reward.matchingBonus' } }),
      prisma.system_settings.findUnique({ where: { key: 'reward.leadershipBonus' } }),
    ]);

    // DB에 데이터가 있으면 파싱하여 반환, 없으면 기본값 반환
    const settings = {
      referralBonus: referralBonusSetting
        ? JSON.parse(referralBonusSetting.value)
        : {
            rate: 0.1,
            description: '직접 추천 시 지급되는 보너스 비율',
          },
      matchingBonus: matchingBonusSetting
        ? JSON.parse(matchingBonusSetting.value)
        : {
            generation1: 0.12,
            generation2to4: 0.08,
            generation5to8: 0.05,
            generation9to12: 0.03,
            description: '세대별 매칭 보너스 비율',
          },
      leadershipBonus: leadershipBonusSetting
        ? JSON.parse(leadershipBonusSetting.value)
        : {
            rank1: 0.04,
            rank2: 0.08,
            rank3: 0.12,
            rank4: 0.16,
            rank5: 0.20,
            description: '랭크별 리더십 보너스 비율',
          },
    };

    return successResponse(settings);
  } catch (error: any) {
    console.error('[Admin] 보상 설정 조회 실패:', error);
    return errorResponse(
      error.message || '보상 설정 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

// 보상 설정 업데이트
export async function PUT(request: NextRequest) {
  try {
    const authError = await requireAdmin(request);
    if (authError) return authError;

    const body = await request.json();
    const { referralBonus, matchingBonus, leadershipBonus } = body;

    // 유효성 검사
    if (referralBonus !== undefined) {
      if (typeof referralBonus.rate !== 'number') {
        return validationErrorResponse('추천 보너스 비율은 숫자여야 합니다.');
      }
      const rateCheck = validateRange(referralBonus.rate, 0, 1, '추천 보너스 비율');
      if (!rateCheck.valid) {
        return validationErrorResponse(rateCheck.message || '추천 보너스 비율은 0~1 사이의 값이어야 합니다.');
      }
    }

    if (matchingBonus !== undefined) {
      const rates = [
        { value: matchingBonus.generation1, name: '1대 매칭 보너스' },
        { value: matchingBonus.generation2to4, name: '2~4대 매칭 보너스' },
        { value: matchingBonus.generation5to8, name: '5~8대 매칭 보너스' },
        { value: matchingBonus.generation9to12, name: '9~12대 매칭 보너스' },
      ];
      
      for (const { value, name } of rates) {
        if (typeof value !== 'number') {
          return validationErrorResponse(`${name}는 숫자여야 합니다.`);
        }
        const rateCheck = validateRange(value, 0, 1, name);
        if (!rateCheck.valid) {
          return validationErrorResponse(rateCheck.message || `${name}는 0~1 사이의 값이어야 합니다.`);
        }
      }
    }

    if (leadershipBonus !== undefined) {
      const rates = [
        { value: leadershipBonus.rank1, name: 'Rank 1 리더십 보너스' },
        { value: leadershipBonus.rank2, name: 'Rank 2 리더십 보너스' },
        { value: leadershipBonus.rank3, name: 'Rank 3 리더십 보너스' },
        { value: leadershipBonus.rank4, name: 'Rank 4 리더십 보너스' },
        { value: leadershipBonus.rank5, name: 'Rank 5 리더십 보너스' },
      ];
      
      for (const { value, name } of rates) {
        if (typeof value !== 'number') {
          return validationErrorResponse(`${name}는 숫자여야 합니다.`);
        }
        const rateCheck = validateRange(value, 0, 1, name);
        if (!rateCheck.valid) {
          return validationErrorResponse(rateCheck.message || `${name}는 0~1 사이의 값이어야 합니다.`);
        }
      }
    }

    // DB에 보상 설정 저장 (upsert 방식)
    const updates = [];

    if (referralBonus !== undefined) {
      const referralBonusData = {
        rate: referralBonus.rate,
        description: referralBonus.description || '직접 추천 시 지급되는 보너스 비율',
      };
      updates.push(
        prisma.system_settings.upsert({
          where: { key: 'reward.referralBonus' },
          update: {
            value: JSON.stringify(referralBonusData),
            description: '추천 보너스 설정',
          },
          create: {
            key: 'reward.referralBonus',
            value: JSON.stringify(referralBonusData),
            description: '추천 보너스 설정',
          },
        })
      );
    }

    if (matchingBonus !== undefined) {
      const matchingBonusData = {
        generation1: matchingBonus.generation1,
        generation2to4: matchingBonus.generation2to4,
        generation5to8: matchingBonus.generation5to8,
        generation9to12: matchingBonus.generation9to12,
        description: matchingBonus.description || '세대별 매칭 보너스 비율',
      };
      updates.push(
        prisma.system_settings.upsert({
          where: { key: 'reward.matchingBonus' },
          update: {
            value: JSON.stringify(matchingBonusData),
            description: '매칭 보너스 설정',
          },
          create: {
            key: 'reward.matchingBonus',
            value: JSON.stringify(matchingBonusData),
            description: '매칭 보너스 설정',
          },
        })
      );
    }

    if (leadershipBonus !== undefined) {
      const leadershipBonusData = {
        rank1: leadershipBonus.rank1,
        rank2: leadershipBonus.rank2,
        rank3: leadershipBonus.rank3,
        rank4: leadershipBonus.rank4,
        rank5: leadershipBonus.rank5,
        description: leadershipBonus.description || '랭크별 리더십 보너스 비율',
      };
      updates.push(
        prisma.system_settings.upsert({
          where: { key: 'reward.leadershipBonus' },
          update: {
            value: JSON.stringify(leadershipBonusData),
            description: '리더십 보너스 설정',
          },
          create: {
            key: 'reward.leadershipBonus',
            value: JSON.stringify(leadershipBonusData),
            description: '리더십 보너스 설정',
          },
        })
      );
    }

    await Promise.all(updates);

    console.log('📝 [Admin] 보상 설정 업데이트 완료:', updates.length, '개 설정');

    // 업데이트된 설정 반환
    const [updatedReferralBonus, updatedMatchingBonus, updatedLeadershipBonus] = await Promise.all([
      referralBonus !== undefined
        ? prisma.system_settings.findUnique({ where: { key: 'reward.referralBonus' } })
        : Promise.resolve(null),
      matchingBonus !== undefined
        ? prisma.system_settings.findUnique({ where: { key: 'reward.matchingBonus' } })
        : Promise.resolve(null),
      leadershipBonus !== undefined
        ? prisma.system_settings.findUnique({ where: { key: 'reward.leadershipBonus' } })
        : Promise.resolve(null),
    ]);

    const result = {
      referralBonus: updatedReferralBonus
        ? JSON.parse(updatedReferralBonus.value)
        : referralBonus || {
            rate: 0.1,
            description: '직접 추천 시 지급되는 보너스 비율',
          },
      matchingBonus: updatedMatchingBonus
        ? JSON.parse(updatedMatchingBonus.value)
        : matchingBonus || {
            generation1: 0.12,
            generation2to4: 0.08,
            generation5to8: 0.05,
            generation9to12: 0.03,
            description: '세대별 매칭 보너스 비율',
          },
      leadershipBonus: updatedLeadershipBonus
        ? JSON.parse(updatedLeadershipBonus.value)
        : leadershipBonus || {
            rank1: 0.04,
            rank2: 0.08,
            rank3: 0.12,
            rank4: 0.16,
            rank5: 0.20,
            description: '랭크별 리더십 보너스 비율',
          },
    };

    return successResponse(result, '보상 설정이 업데이트되었습니다.');
  } catch (error: any) {
    console.error('[Admin] 보상 설정 업데이트 실패:', error);
    
    if (error.status === 401 || error.status === 403) {
      return errorResponse('관리자 권한이 필요합니다.', error.status, 'FORBIDDEN');
    }

    return errorResponse(
      error.message || '보상 설정 업데이트 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

