import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRange } from '@/lib/validation';
import { Prisma } from '@prisma/client';

export async function GET(request?: Request) {
  try {
    // 관리자 권한 체크 (request가 있을 때만)
    if (request) {
      const authResult = await requireAdmin(request);
      if (authResult) return authResult;
    }
    // DB에서 투자 등급 설정 조회
    const dbTiers = await prisma.investment_tiers.findMany({
      orderBy: { tier: 'asc' },
    });

    // DB에 데이터가 있으면 반환, 없으면 기본값 반환
    if (dbTiers.length > 0) {
      const tiers = dbTiers.map((tier) => ({
        tier: tier.tier,
        minAmount: Number(tier.minAmount),
        maxAmount: tier.maxAmount ? Number(tier.maxAmount) : null,
        dailyRate: Number(tier.dailyRate),
        matchingDepth: tier.matchingDepth,
        referralRates: tier.referralRates,
        description: tier.description,
      }));
      return successResponse(tiers);
    }

    // DB에 데이터가 없으면 기본값 반환 (하위 호환성)
    const defaultTiers = [
      {
        tier: 1,
        minAmount: 50,
        maxAmount: 99,
        dailyRate: 0.003, // 0.3%
        matchingDepth: 0, // 매칭 보너스 없음
        referralRates: [],
        description: '$50-$99: 초보 투자자 (매칭 보너스 없음)'
      },
      {
        tier: 2,
        minAmount: 100,
        maxAmount: 999,
        dailyRate: 0.005, // 0.5%
        matchingDepth: 4, // 1~4대
        referralRates: [],
        description: '$100-$999: 일반 투자자 (1~4대 매칭 보너스)'
      },
      {
        tier: 3,
        minAmount: 1000,
        maxAmount: 9999,
        dailyRate: 0.010, // 1%
        matchingDepth: 8, // 5~8대
        referralRates: [],
        description: '$1,000-$9,999: 고급 투자자 (5~8대 매칭 보너스)'
      },
      {
        tier: 4,
        minAmount: 10000,
        maxAmount: null, // 무제한
        dailyRate: 0.012, // 1.2%
        matchingDepth: 12, // 9~12대
        referralRates: [],
        description: '$10,000+: 최고 등급 투자자 (9~12대 매칭 보너스)'
      }
    ];

    return successResponse(defaultTiers);
  } catch (error: any) {
    console.error('[Admin] 투자 등급 조회 실패:', error);
    return errorResponse(
      error.message || '투자 등급 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

export async function PUT(request: Request) {
  try {
    // 관리자 권한 체크
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;
    const body = await request.json();
    const { tiers } = body;

    if (!Array.isArray(tiers) || tiers.length === 0) {
      return validationErrorResponse('유효한 등급 데이터가 필요합니다.');
    }

    // 유효성 검사
    for (const tier of tiers) {
      // 필수 필드 검증
      if (!tier.tier || tier.minAmount === undefined || tier.dailyRate === undefined || tier.matchingDepth === undefined) {
        return validationErrorResponse(`등급 ${tier.tier || 'N/A'}: 모든 필수 정보가 필요합니다.`);
      }

      // 등급 번호 검증 (1-6)
      const tierCheck = validateRange(tier.tier, 1, 6, '등급 번호');
      if (!tierCheck.valid) {
        return validationErrorResponse(tierCheck.message || `등급 번호는 1~6 사이여야 합니다.`);
      }

      // 최소 금액 검증
      const minAmountCheck = validateRange(tier.minAmount, 0, 1000000, '최소 금액');
      if (!minAmountCheck.valid) {
        return validationErrorResponse(minAmountCheck.message || `등급 ${tier.tier}: 최소 금액이 유효하지 않습니다.`);
      }

      // 일일 수익률 검증 (0-1)
      const rateCheck = validateRange(tier.dailyRate, 0, 1, '일일 수익률');
      if (!rateCheck.valid) {
        return validationErrorResponse(rateCheck.message || `등급 ${tier.tier}: 일일 수익률은 0~1 사이여야 합니다.`);
      }

      // 매칭 깊이 검증 (0-12)
      const depthCheck = validateRange(tier.matchingDepth, 0, 12, '매칭 깊이');
      if (!depthCheck.valid) {
        return validationErrorResponse(depthCheck.message || `등급 ${tier.tier}: 매칭 깊이는 0~12 사이여야 합니다.`);
      }
    }

    // DB에 투자 등급 설정 저장 (upsert 방식)
    const savedTiers = [];
    for (const tier of tiers) {
      // maxAmount를 null로 설정할 수 있도록 타입 단언 사용
      const maxAmountValue: Decimal | null = tier.maxAmount !== null && tier.maxAmount !== undefined 
        ? new Prisma.Decimal(tier.maxAmount) 
        : null;

      const savedTier = await prisma.investment_tiers.upsert({
        where: { tier: tier.tier },
        update: {
          minAmount: new Prisma.Decimal(tier.minAmount),
          maxAmount: maxAmountValue as any, // Prisma nullable Decimal 타입 호환성
          dailyRate: new Prisma.Decimal(tier.dailyRate),
          matchingDepth: tier.matchingDepth,
          referralRates: tier.referralRates || [],
          description: tier.description || null,
        },
        create: {
          tier: tier.tier,
          minAmount: new Prisma.Decimal(tier.minAmount),
          maxAmount: maxAmountValue as any, // Prisma nullable Decimal 타입 호환성
          dailyRate: new Prisma.Decimal(tier.dailyRate),
          matchingDepth: tier.matchingDepth,
          referralRates: tier.referralRates || [],
          description: tier.description || null,
        } as any, // Prisma 타입 호환성을 위한 타입 단언
      });

      savedTiers.push({
        tier: savedTier.tier,
        minAmount: Number(savedTier.minAmount),
        maxAmount: savedTier.maxAmount ? Number(savedTier.maxAmount) : null,
        dailyRate: Number(savedTier.dailyRate),
        matchingDepth: savedTier.matchingDepth,
        referralRates: savedTier.referralRates,
        description: savedTier.description,
      });
    }

    console.log('📝 [Admin] 투자 등급 설정 업데이트 완료:', savedTiers.length, '개 등급');

    return successResponse(savedTiers, '투자 등급 설정이 업데이트되었습니다.');
  } catch (error: any) {
    console.error('[Admin] 투자 등급 업데이트 실패:', error);
    return errorResponse(
      error.message || '투자 등급 업데이트 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}
