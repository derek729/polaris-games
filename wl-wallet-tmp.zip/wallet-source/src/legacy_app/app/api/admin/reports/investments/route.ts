import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

export async function GET(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || '30d';
    const tier = searchParams.get('tier') ? parseInt(searchParams.get('tier')!) : null;

    // 기간 계산
    const now = new Date();
    let startDate = new Date();

    switch (period) {
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      case '1y':
        startDate.setFullYear(now.getFullYear() - 1);
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }

    // 기본 where 조건
    const whereCondition: any = {
      createdAt: { gte: startDate }
    };

    if (tier && !isNaN(tier)) {
      whereCondition.investmentTier = tier;
    }

    // 투자 상세 통계
    const [
      totalStats,
      tierStats,
      recentInvestments,
      topInvestors,
      investmentGrowth
    ] = await Promise.all([
      // 총 투자 통계
      prisma.investments.aggregate({
        where: whereCondition,
        _sum: { amount: true },
        _count: true,
        _avg: { amount: true, dailyRate: true },
        _max: { amount: true },
        _min: { amount: true }
      }),

      // 등급별 통계
      prisma.investments.groupBy({
        by: ['investmentTier'],
        where: whereCondition,
        _sum: { amount: true },
        _count: true,
        _avg: { amount: true, dailyRate: true }
      }),

      // 최신 투자 내역
      prisma.investments.findMany({
        where: whereCondition,
        take: 20,
        orderBy: { createdAt: 'desc' },
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
              rank: true
            }
          }
        }
      }),

      // 상위 투자자
      prisma.$queryRaw`
        SELECT
          u.id,
          u.username,
          u.email,
          u.rank,
          COUNT(i.id) as investment_count,
          COALESCE(SUM(i.amount), 0) as total_invested,
          COALESCE(AVG(i.amount), 0) as avg_investment,
          MAX(i."createdAt") as last_investment_date
        FROM users u
        LEFT JOIN investments i ON u.id = i."userId"
        WHERE i."createdAt" >= ${startDate}
        GROUP BY u.id, u.username, u.email, u.rank
        HAVING COUNT(i.id) > 0
        ORDER BY total_invested DESC
        LIMIT 10
      `,

      // 투자 성장 추세 (월별)
      prisma.$queryRaw`
        SELECT
          DATE_TRUNC('month', "createdAt") as month,
          COUNT(*) as count,
          COALESCE(SUM(amount), 0) as total_amount,
          COALESCE(AVG(amount), 0) as avg_amount
        FROM investments
        WHERE "createdAt" >= ${startDate}
        GROUP BY DATE_TRUNC('month', "createdAt")
        ORDER BY month DESC
      `
    ]);

    // 일별 투자량 (최근 30일)
    const dailyInvestmentVolume = await prisma.$queryRaw`
      SELECT
        DATE("createdAt") as date,
        COUNT(*) as count,
        COALESCE(SUM(amount), 0) as total_amount
      FROM investments
      WHERE "createdAt" >= ${startDate}
      GROUP BY DATE("createdAt")
      ORDER BY date DESC
      LIMIT 30
    `;

    // 수익률 분포
    const rateDistribution = await prisma.$queryRaw`
      SELECT
        CASE
          WHEN "dailyRate" < 0.004 THEN '0.3%'
          WHEN "dailyRate" < 0.006 THEN '0.5%'
          WHEN "dailyRate" < 0.011 THEN '1.0%'
          ELSE '1.2%'
        END as rate_category,
        COUNT(*) as count,
        COALESCE(SUM(amount), 0) as total_amount
      FROM investments
      WHERE "createdAt" >= ${startDate}
      GROUP BY rate_category
      ORDER BY total_amount DESC
    `;

    // 응답 데이터 구성
    const investmentData = {
      summary: {
        totalInvestments: totalStats._count,
        totalAmount: decimalToNumber(totalStats._sum.amount),
        averageAmount: decimalToNumber(totalStats._avg.amount),
        averageDailyRate: decimalToNumber(totalStats._avg.dailyRate) * 100,
        maxAmount: decimalToNumber(totalStats._max.amount),
        minAmount: decimalToNumber(totalStats._min.amount)
      },

      tierDistribution: tierStats.map(stat => ({
        tier: stat.investmentTier,
        count: stat._count,
        totalAmount: decimalToNumber(stat._sum.amount),
        averageAmount: decimalToNumber(stat._avg.amount),
        averageDailyRate: decimalToNumber(stat._avg.dailyRate) * 100
      })).sort((a, b) => a.tier - b.tier),

      recentInvestments: recentInvestments.map(inv => ({
        id: inv.id,
        amount: decimalToNumber(inv.amount),
        dailyRate: decimalToNumber(inv.dailyRate) * 100,
        matchingDepth: inv.matchingDepth,
        investment_tiers: inv.investmentTier,
        startDate: inv.startDate,
        endDate: inv.endDate,
        isActive: inv.isActive,
        users: inv.users,
        dailyProfit: decimalToNumber(inv.amount.mul(inv.dailyRate))
      })),

      topInvestors: (topInvestors as any[]).map(investor => ({
        id: investor.id,
        username: investor.username,
        email: investor.email,
        rank: investor.rank,
        investmentCount: Number(investor.investment_count),
        totalInvested: decimalToNumber(investor.total_invested),
        averageInvestment: decimalToNumber(investor.avg_investment),
        lastInvestmentDate: investor.last_investment_date
      })),

      trends: {
        monthlyGrowth: (investmentGrowth as any[]).map(growth => ({
          month: growth.month,
          count: Number(growth.count),
          totalAmount: decimalToNumber(growth.total_amount),
          averageAmount: decimalToNumber(growth.avg_amount)
        })),

        dailyVolume: (dailyInvestmentVolume as any[]).map(volume => ({
          date: volume.date,
          count: Number(volume.count),
          totalAmount: decimalToNumber(volume.total_amount)
        })),

        rateDistribution: (rateDistribution as any[]).map(dist => ({
          rateCategory: dist.rate_category,
          count: Number(dist.count),
          totalAmount: decimalToNumber(dist.total_amount)
        }))
      },

      period: {
        startDate,
        endDate: now,
        days: Math.ceil((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
      }
    };

    return NextResponse.json({
      ok: true,
      data: investmentData
    });
  } catch (error) {
    console.error('[Admin] 투자 리포트 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: '투자 리포트 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}