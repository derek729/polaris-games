import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

export async function GET(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || '30d'; // 7d, 30d, 90d, 1y

    // 기간 계산
    const now = new Date();
    let startDate = new Date();

    switch (period) {
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(now.getDate() - 90);
        break;
      case '1y':
        startDate.setFullYear(now.getFullYear() - 1);
        break;
      default:
        startDate.setDate(now.getDate() - 30);
    }

    // 병렬로 각종 통계 데이터 조회
    const [
      totalUsers,
      activeUsers,
      totalInvestments,
      activeInvestments,
      totalRewards,
      totalWithdrawals,
      investmentStats,
      rewardStats,
      withdrawalStats,
      tierDistribution,
      rankDistribution
    ] = await Promise.all([
      // 총 사용자 수
      prisma.users.count(),

      // 활성 사용자 수
      prisma.users.count({
        where: {
          isActive: true,
          status: 'ACTIVE'
        }
      }),

      // 총 투자 금액
      prisma.investments.aggregate({
        _sum: { amount: true },
        _count: true
      }),

      // 활성 투자 통계
      prisma.investments.aggregate({
        where: { isActive: true },
        _sum: { amount: true },
        _count: true,
        _avg: { dailyRate: true }
      }),

      // 총 지급된 수당
      prisma.reward_logs.aggregate({
        where: {
          isPaid: true,
          createdAt: { gte: startDate }
        },
        _sum: { amount: true },
        _count: true
      }),

      // 총 출금 금액
      prisma.withdrawal_requests.aggregate({
        where: {
          status: 'APPROVED',
          requestedAt: { gte: startDate }
        },
        _sum: { amount: true },
        _count: true
      }),

      // 기간별 투자 통계
      prisma.investments.groupBy({
        by: ['investmentTier'],
        where: {
          createdAt: { gte: startDate }
        },
        _sum: { amount: true },
        _count: true
      }),

      // 기간별 수당 통계
      prisma.reward_logs.groupBy({
        by: ['type'],
        where: {
          isPaid: true,
          createdAt: { gte: startDate }
        },
        _sum: { amount: true },
        _count: true
      }),

      // 기간별 출금 통계
      prisma.withdrawal_requests.groupBy({
        by: ['status'],
        where: {
          requestedAt: { gte: startDate }
        },
        _sum: { amount: true },
        _count: true
      }),

      // 투자 등급 분포
      prisma.investments.groupBy({
        by: ['investmentTier'],
        _count: true
      }),

      // 랭크 분포
      prisma.users.groupBy({
        by: ['rank'],
        _count: true
      })
    ]);

    // 일별 수당 추세 (최근 30일)
    const dailyRewards = await prisma.$queryRaw`
      SELECT
        DATE("createdAt") as date,
        COALESCE(SUM(amount), 0) as total_amount,
        COUNT(*) as count
      FROM reward_logs
      WHERE "isPaid" = true
        AND "createdAt" >= ${startDate}
      GROUP BY DATE("createdAt")
      ORDER BY date DESC
      LIMIT 30
    `;

    // 일별 투자 추세 (최근 30일)
    const dailyInvestments = await prisma.$queryRaw`
      SELECT
        DATE("createdAt") as date,
        COALESCE(SUM(amount), 0) as total_amount,
        COUNT(*) as count
      FROM investments
      WHERE "createdAt" >= ${startDate}
      GROUP BY DATE("createdAt")
      ORDER BY date DESC
      LIMIT 30
    `;

    // 시스템 유동성 계산
    const systemLiquidity = await prisma.users.aggregate({
      _sum: { personalCoin: true }
    });

    // 응답 데이터 구성
    const financialData = {
      summary: {
        totalUsers,
        activeUsers,
        inactiveUsers: totalUsers - activeUsers,
        totalInvestments: {
          count: totalInvestments._count,
          amount: decimalToNumber(totalInvestments._sum.amount)
        },
        activeInvestments: {
          count: activeInvestments._count,
          amount: decimalToNumber(activeInvestments._sum.amount),
          avgDailyRate: decimalToNumber(activeInvestments._avg.dailyRate) * 100
        },
        totalRewards: {
          count: totalRewards._count,
          amount: decimalToNumber(totalRewards._sum.amount)
        },
        totalWithdrawals: {
          count: totalWithdrawals._count,
          amount: decimalToNumber(totalWithdrawals._sum.amount)
        },
        systemLiquidity: {
          totalUserBalance: decimalToNumber(systemLiquidity._sum.personalCoin),
          investedAmount: decimalToNumber(activeInvestments._sum.amount),
          availableRatio: systemLiquidity._sum.personalCoin && activeInvestments._sum.amount
            ? (Number(systemLiquidity._sum.personalCoin) / Number(activeInvestments._sum.amount)) * 100
            : 0
        }
      },

      distributions: {
        investment_tiers: tierDistribution.map(tier => ({
          tier: tier.investmentTier,
          count: tier._count
        })).sort((a, b) => a.tier - b.tier),

        ranks: rankDistribution.map(rank => ({
          rank: rank.rank,
          count: rank._count
        })).sort((a, b) => a.rank - b.rank),

        rewardTypes: rewardStats.map(stat => ({
          type: stat.type,
          count: stat._count,
          amount: decimalToNumber(stat._sum.amount)
        })),

        withdrawalStatuses: withdrawalStats.map(stat => ({
          status: stat.status,
          count: stat._count,
          amount: decimalToNumber(stat._sum.amount)
        }))
      },

      trends: {
        dailyRewards: (dailyRewards as any[]).map(row => ({
          date: row.date,
          amount: decimalToNumber(row.total_amount),
          count: Number(row.count)
        })),

        dailyInvestments: (dailyInvestments as any[]).map(row => ({
          date: row.date,
          amount: decimalToNumber(row.total_amount),
          count: Number(row.count)
        }))
      },

      period: {
        startDate,
        endDate: now,
        days: Math.ceil((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
      }
    };

    return NextResponse.json({
      ok: true,
      data: financialData
    });
  } catch (error) {
    console.error('[Admin] 금융 리포트 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: '금융 리포트 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}