import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';

export async function GET(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const hours = parseInt(searchParams.get('hours') || '24'); // 기본 24시간

    const since = new Date();
    since.setHours(since.getHours() - hours);

    const anomalies: any[] = [];

    // 1. 대규모 투자 감지 (단일 트랜잭션 $5,000 이상)
    const largeInvestments = await prisma.investments.findMany({
      where: {
        createdAt: { gte: since },
        amount: { gte: 5000 }
      },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
            rank: true,
            totalInvestment: true,
            personalCoin: true
          }
        }
      },
      orderBy: { amount: 'desc' }
    });

    if (largeInvestments.length > 0) {
      anomalies.push({
        type: 'large_investment',
        severity: 'high',
        count: largeInvestments.length,
        data: largeInvestments,
        message: `${largeInvestments.length}건의 대규모 투자($5,000+) 감지`
      });
    }

    // 2. 단시간 다수 투자 감지 (1시간 내 5건 이상)
    const oneHourAgo = new Date();
    oneHourAgo.setHours(oneHourAgo.getHours() - 1);

    const frequentInvestors = await prisma.$queryRaw<Array<{
      id: string;
      username: string | null;
      email: string | null;
      rank: number;
      investment_count: bigint;
      total_amount: any;
      last_investment: Date | null;
    }>>`
      SELECT
        u.id,
        u.username,
        u.email,
        u.rank,
        COUNT(i.id) as investment_count,
        COALESCE(SUM(i.amount), 0) as total_amount,
        MAX(i."createdAt") as last_investment
      FROM users u
      JOIN investments i ON u.id = i."userId"
      WHERE i."createdAt" >= ${oneHourAgo}
      GROUP BY u.id, u.username, u.email, u.rank
      HAVING COUNT(i.id) >= 5
      ORDER BY investment_count DESC
    `;

    if (frequentInvestors.length > 0) {
      anomalies.push({
        type: 'frequent_investment',
        severity: 'medium',
        count: frequentInvestors.length,
        data: frequentInvestors.map(inv => ({
          ...inv,
          investment_count: Number(inv.investment_count),
          total_amount: Number(inv.total_amount)
        })),
        message: `${frequentInvestors.length}명의 사용자가 단시간 내 다수 투자`
      });
    }

    // 3. 대규모 출금 요청 감지 ($10,000 이상)
    const largeWithdrawals = await prisma.withdrawal_requests.findMany({
      where: {
        requestedAt: { gte: since },
        amount: { gte: 10000 }
      },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
            rank: true,
            personalCoin: true
          }
        }
      },
      orderBy: { amount: 'desc' }
    });

    if (largeWithdrawals.length > 0) {
      anomalies.push({
        type: 'large_withdrawal',
        severity: 'high',
        count: largeWithdrawals.length,
        data: largeWithdrawals,
        message: `${largeWithdrawals.length}건의 대규모 출금 요청($10,000+) 감지`
      });
    }

    // 4. 수수료 이상 증가 감지 (평균보다 3배 이상)
    const avgDailyReward = await prisma.reward_logs.aggregate({
      where: {
        type: 'DAILY',
        isPaid: true,
        paidAt: { gte: since }
      },
      _avg: { amount: true }
    });

    if (avgDailyReward._avg.amount && avgDailyReward._avg.amount.gt(0)) {
      const threshold = avgDailyReward._avg.amount.mul(3);
      const abnormalRewards = await prisma.reward_logs.findMany({
        where: {
          type: 'DAILY',
          isPaid: true,
          paidAt: { gte: since },
          amount: { gt: threshold }
        },
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
              rank: true
            }
          }
        },
        orderBy: { amount: 'desc' }
      });

      if (abnormalRewards.length > 0) {
        anomalies.push({
          type: 'abnormal_reward',
          severity: 'medium',
          count: abnormalRewards.length,
          data: abnormalRewards,
          message: `${abnormalRewards.length}건의 이상 수당 지급 감지`
        });
      }
    }

    // 5. 다수 계정 등록 감지 (동일 IP에서 여러 계정)
    // TODO: IP 기반 감지는 로그 시스템 확장 후 구현

    // 6. 투자 없는 대량 수당 수령 감지
    const usersWithoutInvestments = await prisma.$queryRaw<Array<{
      id: string;
      username: string | null;
      email: string | null;
      rank: number;
      total_rewards: any;
      reward_count: bigint;
    }>>`
      SELECT
        u.id,
        u.username,
        u.email,
        u.rank,
        COALESCE(SUM(rl.amount), 0) as total_rewards,
        COUNT(rl.id) as reward_count
      FROM users u
      LEFT JOIN reward_logs rl ON u.id = rl."userId" AND rl."isPaid" = true AND rl."paidAt" >= ${since}
      LEFT JOIN investments i ON u.id = i."userId"
      WHERE i.id IS NULL
        AND rl.id IS NOT NULL
      GROUP BY u.id, u.username, u.email, u.rank
      HAVING SUM(rl.amount) > 1000
      ORDER BY total_rewards DESC
    `;

    if (usersWithoutInvestments.length > 0) {
      anomalies.push({
        type: 'rewards_without_investment',
        severity: 'high',
        count: usersWithoutInvestments.length,
        data: usersWithoutInvestments.map(user => ({
          ...users,
          total_rewards: Number(user.total_rewards),
          reward_count: Number(user.reward_count)
        })),
        message: `${usersWithoutInvestments.length}명의 사용자가 투자 없이 대량 수당 수령`
      });
    }

    // 7. 시스템 유동성 이상 감지
    const systemLiquidity = await prisma.users.aggregate({
      _sum: { personalCoin: true }
    });

    const activeInvestments = await prisma.investments.aggregate({
      where: { isActive: true },
      _sum: { amount: true }
    });

    const liquidityRatio = systemLiquidity._sum.personalCoin && activeInvestments._sum.amount
      ? (Number(systemLiquidity._sum.personalCoin) / Number(activeInvestments._sum.amount)) * 100
      : 0;

    if (liquidityRatio < 50) {
      anomalies.push({
        type: 'low_liquidity',
        severity: 'critical',
        count: 1,
        data: {
          liquidityRatio,
          totalUserBalance: Number(systemLiquidity._sum.personalCoin),
          totalInvestedAmount: Number(activeInvestments._sum.amount)
        },
        message: `시스템 유동성 위험 (${liquidityRatio.toFixed(1)}%)`
      });
    }

    // 총계 및 통계
    const stats = {
      totalAnomalies: anomalies.length,
      severityCount: {
        low: anomalies.filter(a => a.severity === 'low').length,
        medium: anomalies.filter(a => a.severity === 'medium').length,
        high: anomalies.filter(a => a.severity === 'high').length,
        critical: anomalies.filter(a => a.severity === 'critical').length
      },
      monitoringPeriod: `${hours}시간`,
      liquidityRatio,
      lastChecked: new Date()
    };

    // 자동 알림 생성 (중요 이상 감지시)
    const criticalAnomalies = anomalies.filter(a =>
      a.severity === 'critical' || a.severity === 'high'
    );

    if (criticalAnomalies.length > 0) {
      // 알림 API 호출
      try {
        await fetch('/api/admin/notifications', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'abnormal_detection',
            title: `🚨 중요 이상 거래 감지 (${criticalAnomalies.length}건)`,
            message: criticalAnomalies.map(a => a.message).join(', '),
            severity: 'high',
            metadata: { anomalies: criticalAnomalies }
          })
        });
      } catch (notificationError) {
        console.error('이상 거래 알림 생성 실패:', notificationError);
      }
    }

    console.log(`🔍 [Monitoring] 이상 거래 감지 완료`);
    console.log(`   감지 기간: 최근 ${hours}시간`);
    console.log(`   이상 거래: ${anomalies.length}건`);
    console.log(`   심각도: HIGH(${stats.severityCount.high}), CRITICAL(${stats.severityCount.critical})`);

    return NextResponse.json({
      ok: true,
      data: {
        anomalies,
        stats,
        systemHealth: {
          liquidityRatio,
          status: liquidityRatio < 50 ? 'warning' : 'healthy',
          message: liquidityRatio < 50
            ? '시스템 유동성이 부족합니다. 관리자 주의가 필요합니다.'
            : '시스템이 정상 운영 중입니다.'
        }
      }
    });
  } catch (error) {
    console.error('[Monitoring] 이상 거래 감지 실패:', error);
    return NextResponse.json(
      { ok: false, error: '이상 거래 감지 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}