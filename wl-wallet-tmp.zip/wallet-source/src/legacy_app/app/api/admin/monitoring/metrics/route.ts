import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/admin-auth-server';
import {
  getMetrics,
  getErrorLogs,
  getMetricsSummary,
  getEndpointMetrics,
  getAverageResponseTime,
  getErrorRate,
} from '@/lib/monitoring';
import { successResponse, errorResponse } from '@/lib/api-response';

/**
 * GET /api/admin/monitoring/metrics
 * API 성능 메트릭 조회
 */
export async function GET(request: NextRequest) {
  try {
    const authError = await requireAdmin(request);
    if (authError) return authError;

    const { searchParams } = new URL(request.url);
    const endpoint = searchParams.get('endpoint') || undefined;
    const type = searchParams.get('type') || 'summary'; // summary, detailed, errors

    switch (type) {
      case 'summary': {
        const summary = getMetricsSummary();
        return successResponse({
          ...summary,
          averageResponseTime: Math.round(summary.averageResponseTime),
          errorRate: Math.round(summary.errorRate * 100) / 100,
        });
      }

      case 'detailed': {
        const metrics = endpoint ? [getEndpointMetrics(endpoint)] : getMetrics();
        const formattedMetrics = metrics
          .filter((m): m is NonNullable<typeof m> => m !== null)
          .map((m) => ({
            endpoint: m.endpoint,
            method: m.method,
            count: m.count,
            averageResponseTime: m.count > 0 ? Math.round(m.totalResponseTime / m.count) : 0,
            minResponseTime: m.minResponseTime === Infinity ? 0 : Math.round(m.minResponseTime),
            maxResponseTime: Math.round(m.maxResponseTime),
            errorCount: m.errorCount,
            errorRate: m.count > 0 ? Math.round((m.errorCount / m.count) * 100 * 100) / 100 : 0,
            lastRequestTime: m.lastRequestTime,
            lastErrorTime: m.lastErrorTime,
          }));

        return successResponse({
          metrics: formattedMetrics,
          totalEndpoints: formattedMetrics.length,
        });
      }

      case 'errors': {
        const limit = parseInt(searchParams.get('limit') || '100');
        const errors = getErrorLogs(limit, endpoint);
        return successResponse({
          errors: errors.map((e) => ({
            endpoint: e.endpoint,
            method: e.method,
            error: e.error,
            statusCode: e.statusCode,
            timestamp: e.timestamp,
            userId: e.userId,
            ip: e.ip,
          })),
          total: errors.length,
        });
      }

      case 'endpoint': {
        if (!endpoint) {
          return errorResponse('endpoint 파라미터가 필요합니다.', 400, 'VALIDATION_ERROR');
        }

        const metric = getEndpointMetrics(endpoint);
        if (!metric) {
          return successResponse({
            endpoint,
            message: '해당 엔드포인트에 대한 메트릭이 없습니다.',
          });
        }

        return successResponse({
          endpoint: metric.endpoint,
          count: metric.count,
          averageResponseTime: metric.count > 0 ? Math.round(metric.totalResponseTime / metric.count) : 0,
          minResponseTime: metric.minResponseTime === Infinity ? 0 : Math.round(metric.minResponseTime),
          maxResponseTime: Math.round(metric.maxResponseTime),
          errorCount: metric.errorCount,
          errorRate: metric.count > 0 ? Math.round((metric.errorCount / metric.count) * 100 * 100) / 100 : 0,
          lastRequestTime: metric.lastRequestTime,
          lastErrorTime: metric.lastErrorTime,
        });
      }

      default:
        return errorResponse('유효하지 않은 type 파라미터입니다.', 400, 'VALIDATION_ERROR');
    }
  } catch (error: any) {
    console.error('[Admin] 메트릭 조회 실패:', error);
    return errorResponse(
      error.message || '메트릭 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

