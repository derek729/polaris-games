import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';
import { getBlockchainInfo } from '@/services/mainnet-api';

/**
 * 메인넷 연동 상태 모니터링 API
 */
export async function GET(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return unauthorizedResponse('관리자 권한이 필요합니다.');
    }

    // 메인넷 연결 상태 확인
    const blockchainInfo = await getBlockchainInfo();

    // 데이터베이스 통계
    const [
      totalUsers,
      usersWithWallets,
      pendingTransfers,
      syncedTransfers,
      failedTransfers,
      recentTransfers,
      totalSupply
    ] = await Promise.all([
      // 전체 사용자 수
      prisma.users.count(),

      // 지갑 주소가 있는 사용자 수
      prisma.users.count({
        where: { walletAddress: { not: null } }
      }),

      // 메인넷 동기화 대기 중인 이체
      prisma.transfers.count({
        where: { networkType: 'OFF_CHAIN' }
      }),

      // 메인넷 동기화 완료된 이체
      prisma.transfers.count({
        where: {
          networkType: 'MAINNET',
          mainnetStatus: 'CONFIRMED'
        }
      }),

      // 메인넷 동기화 실패한 이체
      prisma.transfers.count({
        where: {
          networkType: 'MAINNET',
          mainnetStatus: 'FAILED'
        }
      }),

      // 최근 24시간 이체 내역
      prisma.transfers.count({
        where: {
          transferredAt: {
            gte: new Date(Date.now() - 24 * 60 * 60 * 1000)
          }
        }
      }),

      // 전체 AO 코인 공급량
      prisma.users.aggregate({
        _sum: { personalCoin: true }
      })
    ]);

    // 메인넷 상태 정보
    const mainnetStatus = {
      connected: blockchainInfo.success,
      height: blockchainInfo.data?.height || 0,
      difficulty: blockchainInfo.data?.difficulty || 0,
      blockReward: blockchainInfo.data?.blockReward || 0,
      totalSupply: blockchainInfo.data?.totalSupply || 0,
      lastBlockHash: blockchainInfo.data?.lastBlockHash || null,
      errorMessage: blockchainInfo.error || null,
      lastChecked: new Date()
    };

    // 동기화 상태 계산
    const totalTransfers = pendingTransfers + syncedTransfers + failedTransfers;
    const syncRate = totalTransfers > 0 ? (syncedTransfers / totalTransfers) * 100 : 0;
    const failureRate = totalTransfers > 0 ? (failedTransfers / totalTransfers) * 100 : 0;

    // 데이터베이스 상태
    const databaseStatus = {
      totalUsers,
      usersWithWallets,
      walletCreationRate: totalUsers > 0 ? (usersWithWallets / totalUsers) * 100 : 0,
      totalSupply: totalSupply._sum.personalCoin || 0,
      recentTransfers24h: recentTransfers
    };

    // 동기화 건강 상태
    const healthStatus = {
      overall: syncRate >= 95 && failureRate <= 5 ? 'HEALTHY' : syncRate >= 80 ? 'WARNING' : 'CRITICAL',
      mainnetConnection: mainnetStatus.connected ? 'CONNECTED' : 'DISCONNECTED',
      syncRate: Math.round(syncRate * 100) / 100,
      failureRate: Math.round(failureRate * 100) / 100,
      pendingCount: pendingTransfers,
      recommendations: generateRecommendations(mainnetStatus, syncRate, failureRate, pendingTransfers)
    };

    return successResponse({
      timestamp: new Date().toISOString(),
      mainnet: mainnetStatus,
      database: databaseStatus,
      sync: {
        total: totalTransfers,
        pending: pendingTransfers,
        synced: syncedTransfers,
        failed: failedTransfers,
        rate: Math.round(syncRate * 100) / 100,
        rate24h: recentTransfers
      },
      health: healthStatus
    }, '메인넷 상태 조회 완료.');

  } catch (error: any) {
    console.error('[Mainnet Monitoring] 상태 조회 실패:', error);
    return errorResponse(
      error.message || '메인넷 상태 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

/**
 * 모니터링 추천 사항 생성
 */
function generateRecommendations(
  mainnetStatus: any,
  syncRate: number,
  failureRate: number,
  pendingCount: number
): string[] {
  const recommendations: string[] = [];

  if (!mainnetStatus.connected) {
    recommendations.push('메인넷 연결을 확인하세요. 서버가 실행 중인지 확인해야 합니다.');
  }

  if (syncRate < 95) {
    recommendations.push('동기화율이 낮습니다. 대기 중인 이체를 처리하세요.');
  }

  if (failureRate > 5) {
    recommendations.push('실패율이 높습니다. 실패한 이체 원인을 분석하세요.');
  }

  if (pendingCount > 100) {
    recommendations.push('대기 중인 이체가 너무 많습니다. 자동 동기화를 실행하세요.');
  }

  if (mainnetStatus.height === 0) {
    recommendations.push('메인넷 블록高度가 0입니다. 노드가 초기화되었는지 확인하세요.');
  }

  if (recommendations.length === 0) {
    recommendations.push('시스템이 정상적으로 운영되고 있습니다.');
  }

  return recommendations;
}

/**
 * 메인넷 자동 동기화 트리거
 */
export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || currentUser.role !== 'ADMIN') {
      return unauthorizedResponse('관리자 권한이 필요합니다.');
    }

    const { autoSync = false, maxTransfers = 10 } = await request.json();

    if (!autoSync) {
      return errorResponse('자동 동기화 옵션이 필요합니다.', 400, 'BAD_REQUEST');
    }

    // 대기 중인 이체 조회
    const pendingTransfers = await prisma.transfers.findMany({
      where: { networkType: 'OFF_CHAIN' },
      include: {
        sender: {
          select: { id: true, username: true, email: true, walletAddress: true },
        },
        receiver: {
          select: { id: true, username: true, email: true, walletAddress: true },
        },
      },
      take: maxTransfers,
      orderBy: { transferredAt: 'asc' },
    });

    if (pendingTransfers.length === 0) {
      return successResponse({
        processed: 0,
        message: '동기화할 대기 중인 이체가 없습니다.'
      }, '자동 동기화 완료.');
    }

    // 메인넷 연결 확인
    const blockchainInfo = await getBlockchainInfo();
    if (!blockchainInfo.success) {
      return errorResponse('메인넷에 연결할 수 없습니다.', 503, 'MAINNET_UNAVAILABLE');
    }

    // 실제 동기화 로직은 auto-sync-mainnet API에서 처리
    // 여기서는 결과만 반환
    return successResponse({
      pending: pendingTransfers.length,
      transfers: pendingTransfers.map(t => ({
        id: t.id,
        amount: Number(t.amount),
        sender: {
          username: t.users.username,
          walletAddress: t.users.walletAddress,
        },
        receiver: {
          username: t.users.username,
          walletAddress: t.users.walletAddress,
        },
        canSync: !!(t.users.walletAddress && t.users.walletAddress),
        transferredAt: t.transferredAt
      })),
      message: `${pendingTransfers.length}개의 대기 중인 이체를 찾았습니다. 자동 동기화 API를 호출하세요.`
    }, '자동 동기화 준비 완료.');

  } catch (error: any) {
    console.error('[Mainnet Monitoring] 자동 동기화 실패:', error);
    return errorResponse(
      error.message || '자동 동기화 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}