import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { RewardType } from '@prisma/client';
import { Prisma } from '@prisma/client';

/**
 * 리워드 지급 통계 조회 API
 * GET: 전체 통계 조회
 * POST: 특정 기간 통계 조회
 */
export async function GET() {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // 오늘 통계
    const todayStats = await getRewardStats(today);

    // 이번 주 통계
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());
    const weekStats = await getRewardStats(weekStart);

    // 이번 달 통계
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthStats = await getRewardStats(monthStart);

    // 전체 통계
    const allTimeStats = await getRewardStats(new Date(0));

    return NextResponse.json({
      ok: true,
      data: {
        today: todayStats,
        week: weekStats,
        month: monthStats,
        allTime: allTimeStats,
      },
    });
  } catch (error) {
    console.error('[monitoring/rewards] 통계 조회 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const { startDate, endDate } = await request.json();

    if (!startDate || !endDate) {
      return NextResponse.json(
        { ok: false, error: 'startDate와 endDate가 필요합니다.' },
        { status: 400 }
      );
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    const stats = await getRewardStats(start, end);

    return NextResponse.json({
      ok: true,
      data: stats,
    });
  } catch (error) {
    console.error('[monitoring/rewards] 통계 조회 실패:', error);
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

/**
 * 리워드 통계 계산
 */
async function getRewardStats(startDate: Date, endDate?: Date) {
  const whereClause: any = {
    createdAt: { gte: startDate },
  };

  if (endDate) {
    whereClause.createdAt.lte = endDate;
  }

  // 타입별 통계
  const typeStats = await prisma.reward_logs.groupBy({
    by: ['type', 'isPaid'],
    where: whereClause,
    _count: { id: true },
    _sum: { amount: true },
  });

  // 전체 통계
  const totalStats = await prisma.reward_logs.aggregate({
    where: whereClause,
    _count: { id: true },
    _sum: { amount: true },
  });

  // 지급 완료 통계
  const paidStats = await prisma.reward_logs.aggregate({
    where: {
      ...whereClause,
      isPaid: true,
    },
    _count: { id: true },
    _sum: { amount: true },
  });

  // 미지급 통계
  const unpaidStats = await prisma.reward_logs.aggregate({
    where: {
      ...whereClause,
      isPaid: false,
    },
    _count: { id: true },
    _sum: { amount: true },
  });

  // 타입별 상세 통계
  const typeDetails: Record<string, any> = {};
  for (const type of Object.values(RewardType)) {
    const typeData = await prisma.reward_logs.aggregate({
      where: {
        ...whereClause,
        type: type,
      },
      _count: { id: true },
      _sum: { amount: true },
    });

    const typePaid = await prisma.reward_logs.aggregate({
      where: {
        ...whereClause,
        type: type,
        isPaid: true,
      },
      _count: { id: true },
      _sum: { amount: true },
    });

    const totalAmount = typeData._sum.amount ?? new Prisma.Decimal(0);
    const paidAmount = typePaid._sum.amount ?? new Prisma.Decimal(0);
    const unpaidAmount = totalAmount.minus(paidAmount);

    typeDetails[type] = {
      total: {
        count: typeData._count.id,
        amount: totalAmount.toString(),
      },
      paid: {
        count: typePaid._count.id,
        amount: paidAmount.toString(),
      },
      unpaid: {
        count: typeData._count.id - typePaid._count.id,
        amount: unpaidAmount.toString(),
      },
    };
  }

  return {
    total: {
      count: totalStats._count.id,
      amount: totalStats._sum.amount?.toString() || '0',
    },
    paid: {
      count: paidStats._count.id,
      amount: paidStats._sum.amount?.toString() || '0',
    },
    unpaid: {
      count: unpaidStats._count.id,
      amount: unpaidStats._sum.amount?.toString() || '0',
    },
    paymentRate:
      totalStats._count.id > 0
        ? ((paidStats._count.id / totalStats._count.id) * 100).toFixed(2) + '%'
        : '0%',
    byType: typeDetails,
    period: {
      start: startDate.toISOString(),
      end: endDate?.toISOString() || new Date().toISOString(),
    },
  };
}


