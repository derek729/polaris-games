import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { successResponse, errorResponse, validationErrorResponse, notFoundResponse } from '@/lib/api-response';

// 게임 지분 구매 승인/거절
export async function POST(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { purchaseId, action } = body; // action: 'APPROVE' | 'REJECT'

    if (!purchaseId || !action) {
      return validationErrorResponse('구매 ID와 액션(APPROVE/REJECT)은 필수입니다.');
    }

    if (action !== 'APPROVE' && action !== 'REJECT') {
      return validationErrorResponse('액션은 APPROVE 또는 REJECT여야 합니다.');
    }

    // 구매 정보 조회
    const purchase = await prisma.game_share_purchases.findUnique({
      where: { id: purchaseId },
      include: {
        users: true,
        games: true,
        game_shares: true,
      },
    });

    if (!purchase) {
      return notFoundResponse('구매 내역을 찾을 수 없습니다.');
    }

    if (purchase.status !== 'PENDING') {
      return validationErrorResponse(`이미 처리된 구매 내역입니다. (현재 상태: ${purchase.status})`);
    }

    if (action === 'APPROVE') {
      // 승인 처리
      await prisma.$transaction(async (tx) => {
        // 1. 구매 상태를 COMPLETED로 변경 (동시 요청 방지: status 조건 + updateMany)
        const updatedPurchase = await tx.game_share_purchases.updateMany({
          where: { id: purchaseId, status: 'PENDING' },
          data: { status: 'COMPLETED' },
        });

        if (updatedPurchase.count === 0) {
          throw new Error('ALREADY_PROCESSED');
        }

        // 2. 게임 지분 상품 업데이트 (판매 수량 증가) - 잔여 수량 확인 포함
        const updatedShare = await tx.game_shares.updateMany({
          where: { id: purchase.gameShareId, availableShares: { gte: purchase.shareCount } },
          data: {
            soldShares: { increment: purchase.shareCount },
            availableShares: { decrement: purchase.shareCount },
          },
        });

        if (updatedShare.count === 0) {
          throw new Error('INSUFFICIENT_SHARES');
        }
      }, {
        maxWait: 30000, // 최대 대기 시간 30초
        timeout: 30000, // 타임아웃 30초
      });

      console.log(
        `✅ [Admin] 게임 지분 구매 승인 완료: ID ${purchaseId}, 사용자 ${purchase.users.username || purchase.userId}, 게임 ${purchase.games.name}, 지분 ${purchase.shareCount}개`
      );

      return successResponse(
        {
          purchaseId,
          status: 'COMPLETED',
        },
        '게임 지분 구매가 승인되었습니다.'
      );
    } else {
      // 거절 처리
      const updated = await prisma.game_share_purchases.updateMany({
        where: { id: purchaseId, status: 'PENDING' },
        data: { status: 'CANCELLED' },
      });

      if (updated.count === 0) {
        return validationErrorResponse('이미 처리된 구매 요청입니다.');
      }

      console.log(`❌ [Admin] 게임 지분 구매 거절: ID ${purchaseId}`);

      return successResponse(
        {
          purchaseId,
          status: 'CANCELLED',
        },
        '게임 지분 구매가 거절되었습니다.'
      );
    }
  } catch (error: any) {
    console.error('[Admin Game Shares] 구매 승인/거절 실패:', error);

    if (error.message === 'ALREADY_PROCESSED') {
      return validationErrorResponse('이미 처리된 구매 요청입니다.');
    }

    if (error.message === 'INSUFFICIENT_SHARES') {
      return validationErrorResponse('판매 가능한 지분 수량이 부족합니다.');
    }

    return errorResponse(error.message || '구매 승인/거절 중 오류가 발생했습니다.', 500);
  }
}

