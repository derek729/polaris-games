import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { successResponse, errorResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 대기 중인 게임 지분 구매 목록 조회
export async function GET(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const game_share_purchases = await prisma.game_share_purchases.findMany({
      where: { status: 'PENDING' },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
        games: {
          select: {
            id: true,
            name: true,
          },
        },
        game_shares: {
          select: {
            id: true,
            sharePercentage: true,
            price: true,
          },
        },
      },
      orderBy: { purchasedAt: 'desc' },
    });

    return successResponse(
      game_share_purchases.map((purchase) => ({
        id: purchase.id,
        userId: purchase.userId,
        username: purchase.users.username,
        email: purchase.users.email,
        gameId: purchase.gameId,
        gameName: purchase.games.name,
        gameShareId: purchase.gameShareId,
        sharePercentage: decimalToNumber(purchase.sharePercentage) * 100,
        sharePrice: decimalToNumber(purchase.game_shares.price),
        shareCount: purchase.shareCount,
        purchasePrice: decimalToNumber(purchase.purchasePrice),
        originalPrice: purchase.originalPrice ? decimalToNumber(purchase.originalPrice) : null,
        discountAmount: purchase.discountAmount ? decimalToNumber(purchase.discountAmount) : null,
        paymentPeriod: purchase.paymentPeriod,
        txHash: purchase.txHash,
        status: purchase.status,
        purchasedAt: purchase.purchasedAt,
      }))
    );
  } catch (error: any) {
    console.error('[Admin Game Shares] 대기 중인 구매 목록 조회 실패:', error);
    return errorResponse(error.message || '구매 목록 조회 중 오류가 발생했습니다.', 500);
  }
}

