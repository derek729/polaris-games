import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRequired } from '@/lib/validation';

// 캠페인 목록 조회
export async function GET(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    // 현재는 빈 배열 반환 (향후 캠페인 모델 추가 시 구현)
    return successResponse({
      campaigns: [],
      pagination: {
        currentPage: 1,
        totalPages: 1,
        totalCount: 0,
        limit: 20,
        hasNext: false,
        hasPrev: false,
      },
    });
  } catch (error: any) {
    console.error('[Admin] 캠페인 조회 실패:', error);
    return errorResponse(
      error.message || '캠페인 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

// 캠페인 생성
export async function POST(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { name, description, startDate, endDate, discountRate, isActive } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['name', 'startDate', 'endDate']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    // 현재는 성공 응답만 반환 (향후 캠페인 모델 추가 시 구현)
    return successResponse(
      {
        id: 'temp-id',
        name,
        description,
        startDate,
        endDate,
        discountRate: discountRate || 0,
        isActive: isActive !== undefined ? isActive : true,
        createdAt: new Date(),
      },
      '캠페인이 생성되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin] 캠페인 생성 실패:', error);
    return errorResponse(
      error.message || '캠페인 생성 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

