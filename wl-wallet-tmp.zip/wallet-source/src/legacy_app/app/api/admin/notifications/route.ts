import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

// 알림 생성
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      type,
      title,
      message,
      severity = 'medium', // low, medium, high, critical
      userId = null, // 특정 사용자에게만 알림 (null이면 전체 관리자에게)
      metadata = {}
    } = body;

    if (!type || !title || !message) {
      return NextResponse.json(
        { ok: false, error: '알림 타입, 제목, 메시지는 필수입니다.' },
        { status: 400 }
      );
    }

    // 알림 데이터 생성 (RewardLog에 기록)
    const notification = await prisma.1.create({{ data: {
        userId: userId || 'admin', // 시스템 알림의 경우
        type: 'RANK', // 임시로 RANK 타입 사용
        amount: 0,
        description: `[NOTIFICATION] [${severity.toUpperCase()}] ${title} | ${message}`,
        isPaid: true,
        paidAt: new Date(),
      }
    });

    // 심각도에 따른 로깅
    const severityEmojis = {
      low: 'ℹ️',
      medium: '⚠️',
      high: '🚨',
      critical: '🔴'
    };

    console.log(`${severityEmojis[severity as keyof typeof severityEmojis]} [Notification] 알림 생성`);
    console.log(`   타입: ${type}`);
    console.log(`   제목: ${title}`);
    console.log(`   심각도: ${severity}`);
    console.log(`   대상: ${userId ? `사용자 ${userId}` : '전체 관리자'}`);

    // 실시간 알림을 위한 추가 처리 (WebSocket 등)
    // TODO: 실시간 알림 시스템 구현 필요시 추가

    return NextResponse.json({
      ok: true,
      message: '알림이 생성되었습니다.',
      data: {
        id: notification.id,
        type,
        title,
        message,
        severity,
        timestamp: notification.paidAt
      }
    });
  } catch (error) {
    console.error('[Notification] 알림 생성 실패:', error);
    return NextResponse.json(
      { ok: false, error: '알림 생성 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

// 알림 목록 조회
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const severity = searchParams.get('severity');
    const type = searchParams.get('type');
    const unread = searchParams.get('unread');

    const skip = (page - 1) * limit;

    // 검색 조건 구성
    const where: any = {
      description: {
        contains: '[NOTIFICATION]',
        mode: 'insensitive'
      }
    };

    if (severity) {
      where.description = {
        contains: `[NOTIFICATION] [${severity.toUpperCase()}]`,
        mode: 'insensitive'
      };
    }

    if (type) {
      where.description = {
        contains: `[NOTIFICATION] [${severity?.toUpperCase() || ''}]`,
        AND: [
          { description: { contains: `[NOTIFICATION]`, mode: 'insensitive' } },
          { description: { contains: `${type}`, mode: 'insensitive' } }
        ]
      };
    }

    // 최근 알림 조회 (최근 7일)
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    where.paidAt = { gte: weekAgo };

    // 알림 목록 조회
    const [notifications, totalCount] = await Promise.all([
      prisma.reward_logs.findMany({
        where,
        skip,
        take: limit,
        orderBy: { paidAt: 'desc' },
        select: {
          id: true,
          description: true,
          paidAt: true,
        }
      }),
      prisma.reward_logs.count({ where })
    ]);

    const totalPages = Math.ceil(totalCount / limit);

    // 알림 데이터 포맷팅
    const formattedNotifications = notifications.map(notif => {
      const description = notif.description || '';
      const notifMatch = description.match(/\[NOTIFICATION\] \[(\w+)\] (.+?) \| (.+)/);

      return {
        id: notif.id,
        severity: notifMatch?.[1]?.toLowerCase() || 'medium',
        title: notifMatch?.[2] || '알림',
        message: notifMatch?.[3] || description,
        timestamp: notif.paidAt,
        read: false // TODO: 읽음 상태 관리 기능 추가
      };
    });

    // 통계 정보
    const stats = {
      total: totalCount,
      bySeverity: {
        low: formattedNotifications.filter(n => n.severity === 'low').length,
        medium: formattedNotifications.filter(n => n.severity === 'medium').length,
        high: formattedNotifications.filter(n => n.severity === 'high').length,
        critical: formattedNotifications.filter(n => n.severity === 'critical').length
      }
    };

    return NextResponse.json({
      ok: true,
      data: {
        notifications: formattedNotifications,
        stats,
        pagination: {
          currentPage: page,
          totalPages,
          totalCount,
          limit,
          hasNext: page < totalPages,
          hasPrev: page > 1,
        }
      }
    });
  } catch (error) {
    console.error('[Notification] 알림 목록 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: '알림 목록 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}