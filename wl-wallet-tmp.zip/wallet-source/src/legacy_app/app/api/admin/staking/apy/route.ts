import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { Prisma } from '@prisma/client';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 스테이킹 APY 조정 (전체 또는 특정 기록)
 */
export async function POST(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { stakingRecordId, apy, applyToAll } = body;

    if (apy === undefined || apy === null) {
      return validationErrorResponse('APY 값이 필요합니다.');
    }

    const apyValue = new Prisma.Decimal(apy);
    
    // APY 유효성 검사 (0 ~ 100% 범위)
    if (apyValue.lt(0) || apyValue.gt(100)) {
      return validationErrorResponse('APY는 0% ~ 100% 사이의 값이어야 합니다.');
    }

    // 전체 적용
    if (applyToAll) {
      const result = await prisma.staking_records.updateMany({
        where: {
          status: 'ACTIVE', // 활성 스테이킹만
        },
        data: {
          apy: apyValue,
        },
      });

      return successResponse({
        message: `모든 활성 스테이킹의 APY가 ${apy}%로 조정되었습니다.`,
        updatedCount: result.count,
      });
    }

    // 특정 기록만 업데이트
    if (!stakingRecordId) {
      return validationErrorResponse('스테이킹 기록 ID가 필요합니다.');
    }

    // 스테이킹 기록 존재 확인
    const stakingRecord = await prisma.staking_records.findUnique({
      where: { id: stakingRecordId },
    });

    if (!stakingRecord) {
      return errorResponse('스테이킹 기록을 찾을 수 없습니다.', 404);
    }

    // APY 업데이트
    const updatedRecord = await prisma.staking_records.update({
      where: { id: stakingRecordId },
      data: {
        apy: apyValue,
      },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
    });

    return successResponse({
      message: '스테이킹 APY가 성공적으로 조정되었습니다.',
      staking_records: {
        id: updatedRecord.id,
        userId: updatedRecord.userId,
        users: updatedRecord.users,
        stakedAmount: decimalToNumber(updatedRecord.stakedAmount),
        angelLockAmount: decimalToNumber(updatedRecord.angelLockAmount),
        apy: decimalToNumber(updatedRecord.apy),
        lockPeriod: updatedRecord.lockPeriod,
        status: updatedRecord.status,
      },
    });
  } catch (error: any) {
    console.error('[Admin Staking APY] 조정 실패:', error);
    return errorResponse(error.message || 'APY 조정 중 오류가 발생했습니다.', 500);
  }
}


