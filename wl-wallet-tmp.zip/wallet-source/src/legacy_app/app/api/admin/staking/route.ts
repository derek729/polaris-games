import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { Prisma } from '@prisma/client';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 스테이킹 기록 목록 조회
 */
export async function GET(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const userId = searchParams.get('userId') || '';
    const status = searchParams.get('status') || '';
    const period = searchParams.get('period') || '30';

    const skip = (page - 1) * limit;

    // 날짜 필터
    let dateFilter: any = {};
    if (period !== 'all') {
      const days = parseInt(period, 10);
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      dateFilter.stakedAt = { gte: startDate };
    }

    // 사용자 필터
    const where: any = {
      ...dateFilter,
      ...(userId && { userId }),
      ...(status && { status }),
    };

    // 스테이킹 기록 조회
    const [stakingRecords, totalCount] = await Promise.all([
      prisma.staking_records.findMany({
        where,
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
            },
          },
        },
        orderBy: { stakedAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.staking_records.count({ where }),
    ]);

    // 통계 계산
    const stats = await prisma.staking_records.aggregate({
      where: dateFilter,
      _sum: {
        stakedAmount: true,
        rewardAmount: true,
      },
      _count: {
        id: true,
      },
    });

    const totalPages = Math.ceil(totalCount / limit);

    return successResponse({
      staking_records: stakingRecords.map((record) => ({
        id: record.id,
        userId: record.userId,
        users: record.users,
        mainnetAddress: record.mainnetAddress,
        validatorAddress: record.validatorAddress,
        txHash: record.txHash,
        unstakeTxHash: record.unstakeTxHash,
        stakedAmount: decimalToNumber(record.stakedAmount),
        rewardAmount: decimalToNumber(record.rewardAmount),
        angelLockAmount: decimalToNumber(record.angelLockAmount),
        apy: record.apy ? decimalToNumber(record.apy) : null,
        startDate: record.startDate,
        endDate: record.endDate,
        lockPeriod: record.lockPeriod,
        status: record.status,
        confirmations: record.confirmations,
        stakedAt: record.stakedAt,
        unstakedAt: record.unstakedAt,
        confirmedAt: record.confirmedAt,
        createdAt: record.createdAt,
        updatedAt: record.updatedAt,
      })),
      pagination: {
        currentPage: page,
        totalPages,
        totalCount,
        limit,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      },
      stats: {
        total: stats._count.id || 0,
        totalStaked: decimalToNumber(stats._sum.stakedAmount) || 0,
        totalRewards: decimalToNumber(stats._sum.rewardAmount) || 0,
      },
    });
  } catch (error: any) {
    console.error('[Admin Staking] 스테이킹 기록 조회 실패:', error);
    return errorResponse(error.message || '스테이킹 기록 조회 중 오류가 발생했습니다.', 500);
  }
}

/**
 * 스테이킹 APY 조정
 */
export async function POST(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const body = await request.json();
    const { stakingRecordId, apy } = body;

    if (!stakingRecordId) {
      return validationErrorResponse('스테이킹 기록 ID가 필요합니다.');
    }

    if (apy === undefined || apy === null) {
      return validationErrorResponse('APY 값이 필요합니다.');
    }

    const apyValue = new Prisma.Decimal(apy);
    
    // APY 유효성 검사 (0 ~ 100% 범위)
    if (apyValue.lt(0) || apyValue.gt(100)) {
      return validationErrorResponse('APY는 0% ~ 100% 사이의 값이어야 합니다.');
    }

    // 스테이킹 기록 존재 확인
    const stakingRecord = await prisma.staking_records.findUnique({
      where: { id: stakingRecordId },
    });

    if (!stakingRecord) {
      return errorResponse('스테이킹 기록을 찾을 수 없습니다.', 404);
    }

    // APY 업데이트
    const updatedRecord = await prisma.staking_records.update({
      where: { id: stakingRecordId },
      data: {
        apy: apyValue,
      },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
    });

    return successResponse({
      message: '스테이킹 APY가 성공적으로 조정되었습니다.',
      staking_records: {
        id: updatedRecord.id,
        userId: updatedRecord.userId,
        users: updatedRecord.users,
        stakedAmount: decimalToNumber(updatedRecord.stakedAmount),
        angelLockAmount: decimalToNumber(updatedRecord.angelLockAmount),
        apy: decimalToNumber(updatedRecord.apy),
        lockPeriod: updatedRecord.lockPeriod,
        status: updatedRecord.status,
      },
    });
  } catch (error: any) {
    console.error('[Admin Staking] APY 조정 실패:', error);
    return errorResponse(error.message || 'APY 조정 중 오류가 발생했습니다.', 500);
  }
}


