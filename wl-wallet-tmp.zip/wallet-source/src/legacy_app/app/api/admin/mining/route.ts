import { NextRequest } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse } from '@/lib/api-response';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

/**
 * 채굴 기록 목록 조회
 */
export async function GET(request: NextRequest) {
  const authResult = await requireAdmin(request);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '20', 10);
    const userId = searchParams.get('userId') || '';
    const status = searchParams.get('status') || '';
    const period = searchParams.get('period') || '30';

    const skip = (page - 1) * limit;

    // 날짜 필터
    let dateFilter: any = {};
    if (period !== 'all') {
      const days = parseInt(period, 10);
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);
      dateFilter.minedAt = { gte: startDate };
    }

    // 사용자 필터
    const where: any = {
      ...dateFilter,
      ...(userId && { userId }),
      ...(status && { status }),
    };

    // 채굴 기록 조회
    const [miningRecords, totalCount] = await Promise.all([
      prisma.mining_records.findMany({
        where,
        include: {
          users: {
            select: {
              id: true,
              username: true,
              email: true,
            },
          },
        },
        orderBy: { minedAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.mining_records.count({ where }),
    ]);

    // 통계 계산
    const stats = await prisma.mining_records.aggregate({
      where: dateFilter,
      _sum: {
        rewardAmount: true,
      },
      _count: {
        id: true,
      },
    });

    const totalPages = Math.ceil(totalCount / limit);

    return successResponse({
      mining_records: miningRecords.map((record) => ({
        id: record.id,
        userId: record.userId,
        users: record.users,
        mainnetAddress: record.mainnetAddress,
        txHash: record.txHash,
        blockHash: record.blockHash,
        blockNumber: record.blockNumber,
        blockHeight: record.blockHeight,
        rewardAmount: decimalToNumber(record.rewardAmount),
        difficulty: record.difficulty,
        hashrate: record.hashrate,
        miningDuration: record.miningDuration,
        status: record.status,
        confirmations: record.confirmations,
        minedAt: record.minedAt,
        confirmedAt: record.confirmedAt,
        createdAt: record.createdAt,
        updatedAt: record.updatedAt,
      })),
      pagination: {
        currentPage: page,
        totalPages,
        totalCount,
        limit,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      },
      stats: {
        total: stats._count.id || 0,
        totalRewards: decimalToNumber(stats._sum.rewardAmount) || 0,
      },
    });
  } catch (error: any) {
    console.error('[Admin Mining] 채굴 기록 조회 실패:', error);
    return errorResponse(error.message || '채굴 기록 조회 중 오류가 발생했습니다.', 500);
  }
}

