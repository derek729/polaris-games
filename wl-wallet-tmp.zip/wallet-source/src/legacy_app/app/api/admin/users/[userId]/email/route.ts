import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { isValidEmail } from '@/lib/validation';

/**
 * 관리자용 이메일 변경 API
 * PUT /api/admin/users/[userId]/email
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    const { userId } = await params;
    const body = await request.json();
    const { email } = body;

    // 필수 필드 검증
    if (!email || typeof email !== 'string') {
      return NextResponse.json(
        { ok: false, error: '이메일을 입력해주세요.' },
        { status: 400 }
      );
    }

    // 이메일 형식 검증
    if (!isValidEmail(email.trim())) {
      return NextResponse.json(
        { ok: false, error: '올바른 이메일 형식이 아닙니다.' },
        { status: 400 }
      );
    }

    const newEmail = email.trim().toLowerCase();

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      );
    }

    // 현재 이메일과 동일한지 확인
    if (user.email && user.email.toLowerCase() === newEmail) {
      return NextResponse.json(
        { ok: false, error: '현재 이메일과 동일합니다.' },
        { status: 400 }
      );
    }

    // 중복 체크 (다른 사용자가 이미 사용 중인지 확인)
    const existingUser = await prisma.users.findFirst({
      where: {
        email: newEmail,
        id: { not: userId },
      },
    });

    if (existingUser) {
      return NextResponse.json(
        { ok: false, error: '이미 사용 중인 이메일입니다.' },
        { status: 409 }
      );
    }

    // 이메일 업데이트
    const updatedUser = await prisma.users.update({
      where: { id: userId },
      data: { email: newEmail },
      select: {
        id: true,
        username: true,
        email: true,
        rank: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    console.log(`[Admin] 이메일 변경 완료: ${user.email || '(없음)'} -> ${newEmail} (userId: ${userId})`);

    return NextResponse.json({
      ok: true,
      message: '이메일이 성공적으로 변경되었습니다.',
      data: {
        users: updatedUser,
      },
    });
  } catch (error: any) {
    console.error('[Admin] 이메일 변경 실패:', error);
    
    // Prisma 에러 처리
    if (error.code === 'P2002') {
      return NextResponse.json(
        { ok: false, error: '이미 사용 중인 이메일입니다.' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { ok: false, error: error.message || '이메일 변경 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

