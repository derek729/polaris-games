import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { UserRole } from '@prisma/client'
import { requireAdmin } from '@/lib/admin-auth'
import { successResponse, errorResponse, notFoundResponse, serverErrorResponse } from '@/lib/api-response'

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0)

// 사용자 상세 정보 조회
export async function GET(
  request: Request,
  { params }: { params: Promise<{ userId: string }> }
) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any)
  if (authResult) return authResult

  try {
    const { userId } = await params

    const [user, userCounts, userWithdrawals] = await Promise.all([
      prisma.users.findUnique({
        where: { id: userId },
        select: {
          id: true,
          username: true,
          email: true,
          walletAddress: true,
          rank: true,
          totalInvestment: true,
          personalCoin: true,
          accumulatedSales: true,
          status: true,
          role: true,
          isActive: true,
          createdAt: true,
          updatedAt: true,
          other_users_users_referrerIdTousers: {
            select: {
              id: true,
              username: true,
              email: true,
              referralCode: true,
            }
          },
          other_users_users_sponsorIdTousers: {
            select: {
              id: true,
              username: true,
              email: true,
              referralCode: true,
            }
          },
          other_users_users_centerIdTousers: {
            select: {
              id: true,
              username: true,
              email: true,
              referralCode: true,
            }
          },
          other_users_users_referrerIdTousers: {
            select: {
              id: true,
              username: true,
              email: true,
              rank: true,
              totalInvestment: true,
              createdAt: true,
            },
            orderBy: { createdAt: 'desc' },
            take: 10,
          },
          investments: {
            select: {
              id: true,
              amount: true,
              dailyRate: true,
              matchingDepth: true,
              investment_tiers: true,
              startDate: true,
              endDate: true,
              isActive: true,
              status: true,
              createdAt: true,
            },
            orderBy: { createdAt: 'desc' },
            take: 10,
          },
        }
      }),
      prisma.users.findUnique({
        where: { id: userId },
        select: {
          _count: {
            select: {
              other_users_users_referrerIdTousers: true,
              investments: true,
              reward_logs: true,
            }
          }
        }
      }),
      prisma.withdrawal_requests.findMany({
        where: { userId },
        orderBy: { requestedAt: 'desc' },
        take: 10,
      })
    ])

    if (!user) {
      return notFoundResponse('사용자를 찾을 수 없습니다.')
    }

    // 사용자 통계 데이터
    const [
      totalRewards,
      monthlyRewards,
      todayRewards,
      lineStats
    ] = await Promise.all([
      // 총 보상
      prisma.reward_logs.aggregate({
        where: { userId },
        _sum: { amount: true },
        _count: true
      }),
      // 이번 달 보상
      prisma.reward_logs.aggregate({
        where: {
          userId,
          createdAt: {
            gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1)
          }
        },
        _sum: { amount: true },
        _count: true
      }),
      // 오늘 보상
      prisma.reward_logs.aggregate({
        where: {
          userId,
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0))
          }
        },
        _sum: { amount: true },
        _count: true
      }),
      // 라인별 통계
      prisma.team_sales.groupBy({
        by: ['generation'],
        where: { userId },
        _sum: { salesAmount: true },
        _count: true
      })
    ])

    // 라인별 판매량 정리
    const lineSales = {
      line1: 0,
      line2: 0,
      line3: 0,
      line4: 0,
      line5: 0,
    }

    lineStats.forEach(stat => {
      if (stat.generation >= 1 && stat.generation <= 5) {
        lineSales[`line${stat.generation}` as keyof typeof lineSales] = decimalToNumber(stat._sum.salesAmount)
      }
    })

    const responseData = {
      users: {
        id: user.id,
        username: user.username,
        email: user.email,
        walletAddress: user.walletAddress,
        rank: user.rank,
        totalInvestment: decimalToNumber(user.totalInvestment),
        personalCoin: decimalToNumber(user.personalCoin),
        accumulatedSales: decimalToNumber(user.accumulatedSales),
        status: user.status,
        role: user.role,
        isActive: user.isActive,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      },
      other_users_users_referrerIdTousers: user.referrer,
      other_users_users_sponsorIdTousers: user.sponsor,
      statistics: {
        totalRewards: decimalToNumber(totalRewards._sum.amount),
        totalRewardCount: totalRewards._count,
        monthlyRewards: decimalToNumber(monthlyRewards._sum.amount),
        monthlyRewardCount: monthlyRewards._count,
        todayRewards: decimalToNumber(todayRewards._sum.amount),
        todayRewardCount: todayRewards._count,
        ...lineSales,
      },
      counts: {
        other_users_users_referrerIdTousers: userCounts?._count.referredUsers || 0,
        investments: userCounts?._count.investments || 0,
        reward_logs: userCounts?._count.rewardLogs || 0,
        withdrawals: userWithdrawals?.length || 0,
      },
      activities: {
        other_users_users_referrerIdTousers: user?.other_users_users_referrerIdTousers.map(refUser => ({
          ...refUser,
          totalInvestment: decimalToNumber(refUser.totalInvestment)
        })) || [],
        investments: user?.investments.map(investment => ({
          ...investment,
          amount: decimalToNumber(investment.amount),
          dailyRate: decimalToNumber(investment.dailyRate),
          investment_tiers: investment.investmentTier,
        })) || [],
        withdrawals: userWithdrawals.map(withdrawal => ({
          ...withdrawal,
          amount: decimalToNumber(withdrawal.amount)
        }))
      }
    }

    return successResponse(responseData)
  } catch (error) {
    console.error('[Admin] 사용자 상세 정보 조회 실패:', error)
    return serverErrorResponse('사용자 정보 조회 중 오류가 발생했습니다.')
  }
}