import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAdmin } from '@/lib/admin-auth'
import { recalculateMatchingBonusForUser } from '@/services/matchingBonus'

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ userId: string }> }
) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any)
  if (authResult) return authResult

  try {
    const { userId } = await params
    const body = await request.json()
    const { referrerCode, sponsorCode } = body

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      )
    }

    // 추천인 변경
    let referrerId: string | null = null
    if (referrerCode !== undefined) {
      if (referrerCode === '' || referrerCode === null) {
        // 추천인 제거
        referrerId = null
      } else {
        // 추천인 찾기 (사용자명 또는 추천인 코드로)
        const referrer = await prisma.users.findFirst({
          where: {
            OR: [
              { referralCode: referrerCode.trim().toUpperCase() },
              { username: referrerCode.trim() },
            ],
          },
          select: { id: true, isActive: true, status: true },
        })

        if (!referrer) {
          return NextResponse.json(
            { ok: false, error: `추천인 코드 "${referrerCode}"에 해당하는 사용자를 찾을 수 없습니다.` },
            { status: 400 }
          )
        }

        if (!referrer.isActive || referrer.status !== 'ACTIVE') {
          return NextResponse.json(
            { ok: false, error: '활성 상태가 아닌 추천인입니다.' },
            { status: 400 }
          )
        }

        // 자기 자신을 추천인으로 설정할 수 없음
        if (referrer.id === userId) {
          return NextResponse.json(
            { ok: false, error: '자기 자신을 추천인으로 설정할 수 없습니다.' },
            { status: 400 }
          )
        }

        referrerId = referrer.id
      }
    }

    // 후원인 변경
    let sponsorId: string | null = null
    if (sponsorCode !== undefined) {
      if (sponsorCode === '' || sponsorCode === null) {
        // 후원인 제거
        sponsorId = null
      } else {
        // 후원인 찾기 (사용자명 또는 추천인 코드로)
        const sponsor = await prisma.users.findFirst({
          where: {
            OR: [
              { referralCode: sponsorCode.trim().toUpperCase() },
              { username: sponsorCode.trim() },
            ],
          },
          select: { id: true, isActive: true, status: true },
        })

        if (!sponsor) {
          return NextResponse.json(
            { ok: false, error: `후원인 코드 "${sponsorCode}"에 해당하는 사용자를 찾을 수 없습니다.` },
            { status: 400 }
          )
        }

        if (!sponsor.isActive || sponsor.status !== 'ACTIVE') {
          return NextResponse.json(
            { ok: false, error: '활성 상태가 아닌 후원인입니다.' },
            { status: 400 }
          )
        }

        // 자기 자신을 후원인으로 설정할 수 없음
        if (sponsor.id === userId) {
          return NextResponse.json(
            { ok: false, error: '자기 자신을 후원인으로 설정할 수 없습니다.' },
            { status: 400 }
          )
        }

        sponsorId = sponsor.id
      }
    }

    // 업데이트할 데이터 준비
    const updateData: {
      referrerId?: string | null
      sponsorId?: string | null
    } = {}

    if (referrerCode !== undefined) {
      updateData.referrerId = referrerId
    }
    if (sponsorCode !== undefined) {
      updateData.sponsorId = sponsorId
    }

    // 기존 추천인/후원인 정보 확인 (재계산 여부 판단용)
    const oldReferrerId = user.referrerId
    const oldSponsorId = user.sponsorId

    // 사용자 정보 업데이트
    const updatedUser = await prisma.users.update({
      where: { id: userId },
      data: updateData,
      include: {
        other_users_users_referrerIdTousers: {
          select: {
            id: true,
            username: true,
            email: true,
            referralCode: true,
          },
        },
        other_users_users_sponsorIdTousers: {
          select: {
            id: true,
            username: true,
            email: true,
            referralCode: true,
          },
        },
      },
    })

    // 추천인 또는 후원인이 새로 지정된 경우, 과거 일일 수익에 대한 매칭 보너스 재계산
    const referrerChanged = referrerCode !== undefined && updatedUser.referrerId !== oldReferrerId && updatedUser.referrerId !== null
    const sponsorChanged = sponsorCode !== undefined && updatedUser.sponsorId !== oldSponsorId && updatedUser.sponsorId !== null

    if (referrerChanged || sponsorChanged) {
      // 비동기로 재계산 수행 (응답을 블로킹하지 않음)
      recalculateMatchingBonusForUser(userId, 30)
        .then((result) => {
          console.log(`[Admin] 추천인/후원인 변경 후 매칭 보너스 재계산 완료: ${userId}`, result)
        })
        .catch((error) => {
          console.error(`[Admin] 추천인/후원인 변경 후 매칭 보너스 재계산 실패: ${userId}`, error)
        })
    }

    return NextResponse.json({
      ok: true,
      message: '추천인/후원인 정보가 성공적으로 변경되었습니다.' + (referrerChanged || sponsorChanged ? ' 과거 일일 수익에 대한 매칭 보너스 재계산이 진행 중입니다.' : ''),
      data: {
        users: {
          id: updatedUser.id,
          referrerId: updatedUser.referrerId,
          sponsorId: updatedUser.sponsorId,
          other_users_users_referrerIdTousers: updatedUser.referrer,
          other_users_users_sponsorIdTousers: updatedUser.sponsor,
        },
      },
    })
  } catch (error: any) {
    console.error('[Admin] 추천인/후원인 변경 실패:', error)
    return NextResponse.json(
      { ok: false, error: error.message || '추천인/후원인 변경 중 오류가 발생했습니다.' },
      { status: 500 }
    )
  }
}

