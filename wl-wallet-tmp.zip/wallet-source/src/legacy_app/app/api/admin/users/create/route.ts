import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { UserRole } from '@prisma/client';
import { requireAdmin } from '@/lib/admin-auth-server';
import { Prisma } from '@prisma/client';
import { successResponse, errorResponse, validationErrorResponse, handlePrismaError } from '@/lib/api-response';
import { isValidEmail, isValidPassword, isValidUsername, validateRequired, validateRange } from '@/lib/validation';

export async function POST(request: NextRequest) {
  try {
    // 슈퍼관리자 권한 체크
    const authError = await requireAdmin(request, UserRole.SUPER_ADMIN);
    if (authError) {
      return authError;
    }

    const body = await request.json();
    const { username, email, password, role, rank, initialCoin, initialInvestment } = body;

    // 필수 필드 검증
    const requiredCheck = validateRequired(body, ['username', 'email', 'password']);
    if (!requiredCheck.valid) {
      return validationErrorResponse(requiredCheck.message || '필수 필드가 누락되었습니다.');
    }

    // 사용자명 검증
    const usernameCheck = isValidUsername(username);
    if (!usernameCheck.valid) {
      return validationErrorResponse(usernameCheck.message || '사용자명이 유효하지 않습니다.');
    }

    // 이메일 형식 검증
    if (!isValidEmail(email)) {
      return validationErrorResponse('올바른 이메일 형식이 아닙니다.');
    }

    // 비밀번호 검증
    const passwordCheck = isValidPassword(password);
    if (!passwordCheck.valid) {
      return validationErrorResponse(passwordCheck.message || '비밀번호가 유효하지 않습니다.');
    }

    // 랭크 검증 (0-5)
    if (rank !== undefined) {
      const rankCheck = validateRange(rank, 0, 5, '랭크');
      if (!rankCheck.valid) {
        return validationErrorResponse(rankCheck.message || '랭크가 유효하지 않습니다.');
      }
    }

    // 권한 검증 (USER, ADMIN, SUPER_ADMIN만 허용)
    const validRoles = [UserRole.USER, UserRole.ADMIN, UserRole.SUPER_ADMIN];
    const userRole = role && validRoles.includes(role) ? role : UserRole.USER;

    // 중복 체크
    const existingUser = await prisma.users.findFirst({
      where: {
        OR: [
          { username },
          { email },
        ],
      },
      select: {
        id: true,
        username: true,
        email: true,
      },
    });

    if (existingUser) {
      return errorResponse('이미 존재하는 사용자명 또는 이메일입니다.', 409, 'DUPLICATE_ENTRY');
    }

    // 비밀번호 해싱
    const hashedPassword = await bcrypt.hash(password, 10);

    // 사용자 생성
    let user;
    try {
      user = await prisma.1.create({{ data: {
          username,
          email,
          password: hashedPassword,
          role: userRole,
          rank: rank !== undefined ? rank : 0,
          personalCoin: new Prisma.Decimal(initialCoin || 0),
          totalInvestment: new Prisma.Decimal(initialInvestment || 0),
          status: 'ACTIVE',
          isActive: true,
          accumulatedSales: new Prisma.Decimal(0),
          line1Sales: new Prisma.Decimal(0),
          line2Sales: new Prisma.Decimal(0),
          line3Sales: new Prisma.Decimal(0),
          line4Sales: new Prisma.Decimal(0),
          line5Sales: new Prisma.Decimal(0),
        },
      });
    } catch (error: any) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }

    // 초기 투자가 있으면 투자 생성
    if (initialInvestment && initialInvestment > 0) {
      try {
        await prisma.1.create({{ data: {
            userId: user.id,
            amount: new Prisma.Decimal(initialInvestment),
            dailyRate: new Prisma.Decimal(0.012), // 1.2%
            matchingDepth: 12,
            investment_tiers: 6,
            startDate: new Date(),
            endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
          },
        });
      } catch (error: any) {
        console.error('[Admin] 초기 투자 생성 실패:', error);
        // 투자 생성 실패해도 사용자 생성은 성공으로 처리
      }
    }

    return successResponse(
      {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        rank: user.rank,
      },
      '관리자 계정이 성공적으로 생성되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin] 관리자 계정 생성 실패:', error);

    // Prisma 에러 처리
    if (error.code?.startsWith('P')) {
      const { message, status, code } = handlePrismaError(error);
      return errorResponse(message, status, code);
    }

    return errorResponse(
      error.message || '관리자 계정 생성 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}


