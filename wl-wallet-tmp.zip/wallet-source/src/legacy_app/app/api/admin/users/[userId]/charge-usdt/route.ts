import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin, getCurrentAdminUser } from '@/lib/admin-auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';
import { Decimal } from '@prisma/client/runtime/library';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    // 관리자 사용자 정보 가져오기
    const admin = await getCurrentAdminUser();
    if (!admin) {
      return unauthorizedResponse('관리자 권한이 필요합니다.');
    }

    const { userId } = await params;

    const body = await request.json();
    const { amount, memo } = body;

    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      return errorResponse('올바른 금액을 입력해주세요.', 400);
    }

    const chargeAmount = new Decimal(amount);

    // 사용자 조회
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        personalCoin: true,
      },
    });

    if (!user) {
      return errorResponse('사용자를 찾을 수 없습니다.', 404);
    }

    // AOT 잔액 증가 (personalCoin에 AOT를 저장)
    const newBalance = new Decimal(user.personalCoin || 0).plus(chargeAmount);

    await prisma.$transaction(
      async (tx) => {
        // 사용자 잔액 업데이트
        await tx.users.update({
          where: { id: userId },
          data: {
            personalCoin: newBalance,
          },
        });

        // 충전 내역 로그 (RewardLog에 기록 - TEAM 타입 사용)
        await tx.reward_logs.create({
          data: {
            userId,
            type: 'TEAM', // 임시로 TEAM 타입 사용 (RewardType enum에 ADMIN_CHARGE가 없음)
            amount: chargeAmount,
            isPaid: true, // 즉시 지급 완료
            paidAt: new Date(), // 지급 시간
            description: memo
              ? `[관리자 AOT 충전] ${memo} | 관리자: ${admin.username || admin.email} | 이전: ${user.personalCoin?.toString() || '0'} | 이후: ${newBalance.toString()}`
              : `[관리자 AOT 충전] 관리자: ${admin.username || admin.email} | 이전: ${user.personalCoin?.toString() || '0'} | 이후: ${newBalance.toString()}`,
          },
        });
      },
      {
        maxWait: 30000,
        timeout: 30000,
      }
    );

    return successResponse({
      userId: user.id,
      username: user.username,
      chargeAmount: chargeAmount.toString(),
      previousBalance: user.personalCoin?.toString() || '0',
      newBalance: newBalance.toString(),
    });
  } catch (error: any) {
    console.error('[AOT 충전] 오류:', error);
    return errorResponse(error.message || 'AOT 충전 중 오류가 발생했습니다.', 500);
  }
}

