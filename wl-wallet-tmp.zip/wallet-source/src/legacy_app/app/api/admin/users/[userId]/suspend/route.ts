import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { UserStatus } from '@prisma/client';

// 사용자 정지
export async function POST(
  request: Request,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    const { userId } = await params;
    const { reason } = await request.json();

    if (!userId) {
      return NextResponse.json(
        { ok: false, error: '사용자 ID가 필요합니다.' },
        { status: 400 }
      );
    }

    // 사용자 존재 여부 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        status: true,
        isActive: true,
        _count: {
          select: {
            investments: {
              where: { isActive: true }
            }
          }
        }
      }
    });

    if (!user) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      );
    }

    if (user.status === UserStatus.SUSPENDED) {
      return NextResponse.json(
        { ok: false, error: '이미 정지된 사용자입니다.' },
        { status: 400 }
      );
    }

    // 트랜잭션으로 사용자 정지 처리 (타임아웃 30초)
    await prisma.$transaction(async (tx) => {
      // 1. 사용자 상태 변경
      await tx.users.update({
        where: { id: userId },
        data: {
          status: UserStatus.SUSPENDED,
          isActive: false,
          updatedAt: new Date(),
        }
      });

      // 2. 활성 투자 모두 중지
      const activeInvestments = await tx.investments.updateMany({
        where: {
          userId,
          isActive: true
        },
        data: {
          isActive: false,
        }
      });

      // 3. 정지 로그 생성 (RewardLog에 기록)
      if (reason) {
        await tx.reward_logs.create({
          data: {
            userId,
            type: 'RANK', // 임시로 RANK 타입 사용
            amount: 0,
            description: `관리자에 의해 계정 정지됨: ${reason}`,
            isPaid: true,
            paidAt: new Date(),
          }
        });
      }

      console.log(`🚫 [Admin] 사용자 정지 완료: ${user.username} (ID: ${userId})`);
      console.log(`   정지 사유: ${reason || '사유 없음'}`);
      console.log(`   중지된 투자 수: ${activeInvestments.count}건`);
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    return NextResponse.json({
      ok: true,
      message: '사용자가 성공적으로 정지되었습니다.',
      data: {
        userId,
        username: user.username,
        status: UserStatus.SUSPENDED,
        suspendedInvestments: user._count.investments,
        reason: reason || '사유 없음'
      }
    });
  } catch (error) {
    console.error('[Admin] 사용자 정지 실패:', error);
    return NextResponse.json(
      { ok: false, error: '사용자 정지 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}