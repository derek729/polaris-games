import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { isValidPassword } from '@/lib/validation';
import bcrypt from 'bcryptjs';

/**
 * 관리자용 사용자 비밀번호 변경 API
 * PUT /api/admin/users/[userId]/password
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    const { userId } = await params;
    const body = await request.json();
    const { password } = body;

    // 필수 필드 검증
    if (!password || typeof password !== 'string') {
      return NextResponse.json(
        { ok: false, error: '비밀번호를 입력해주세요.' },
        { status: 400 }
      );
    }

    // 비밀번호 유효성 검사
    const passwordCheck = isValidPassword(password);
    if (!passwordCheck.valid) {
      return NextResponse.json(
        { ok: false, error: passwordCheck.message || '비밀번호가 유효하지 않습니다.' },
        { status: 400 }
      );
    }

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      );
    }

    // 비밀번호 해싱
    const hashedPassword = await bcrypt.hash(password, 10);

    // 비밀번호 업데이트
    await prisma.users.update({
      where: { id: userId },
      data: { password: hashedPassword },
    });

    console.log(`[Admin] 비밀번호 변경 완료: ${user.username} (userId: ${userId})`);

    return NextResponse.json({
      ok: true,
      message: '비밀번호가 성공적으로 변경되었습니다.',
    });
  } catch (error: any) {
    console.error('[Admin] 비밀번호 변경 실패:', error);
    return NextResponse.json(
      { ok: false, error: error.message || '비밀번호 변경 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

