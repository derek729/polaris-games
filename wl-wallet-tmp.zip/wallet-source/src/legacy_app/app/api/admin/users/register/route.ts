import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';
import { Prisma } from '@prisma/client';
import { requireAdmin } from '@/lib/admin-auth-server';
import { findSponsorWithSpillover } from '@/services/spillover';
import { generateUniqueReferralCode } from '@/lib/referral-code';
import { distributeReferralBonus } from '@/services/referralBonus';

export async function POST(request: NextRequest) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }
    const body = await request.json();
    const {
      username,
      email,
      password,
      walletAddress,
      referrerId,
      initialCoins = 0,
      rank = 0,
      investmentAmount = null,
      investmentTier = null
    } = body;

    // 필수 입력값 검증
    if (!username || !password) {
      return NextResponse.json(
        { ok: false, error: '아이디와 비밀번호는 필수입니다.' },
        { status: 400 }
      );
    }

    // 중복 체크
    const existingUser = await prisma.users.findFirst({
      where: {
        OR: [
          username ? { username } : {},
          email ? { email } : {},
          walletAddress ? { walletAddress } : {}
        ].filter(condition => Object.keys(condition).length > 0)
      },
      select: {
        id: true,
        username: true,
        email: true,
        walletAddress: true,
      }
    });

    if (existingUser) {
      let conflictField = '';
      if (existingUser.username === username) conflictField = '아이디';
      else if (existingUser.email === email) conflictField = '이메일';
      else if (existingUser.walletAddress === walletAddress) conflictField = '지갑 주소';

      return NextResponse.json(
        { ok: false, error: `이미 사용 중인 ${conflictField}입니다.` },
        { status: 409 }
      );
    }

    // 추천인 유효성 검사
    let referrer = null;
    if (referrerId) {
      referrer = await prisma.users.findUnique({
        where: { id: referrerId },
        select: {
          id: true,
          username: true,
          isActive: true,
          status: true
        }
      });

      if (!referrer) {
        return NextResponse.json(
          { ok: false, error: '존재하지 않는 추천인입니다.' },
          { status: 400 }
        );
      }

      if (!referrer.isActive || referrer.status !== 'ACTIVE') {
        return NextResponse.json(
          { ok: false, error: '활성 상태가 아닌 추천인입니다.' },
          { status: 400 }
        );
      }
    }

    // 스필오버 로직으로 후원인 찾기
    const sponsorId = await findSponsorWithSpillover(referrer?.id || null);

    // 비밀번호 해시
    const hashedPassword = await bcrypt.hash(password, 10);

    // 고유한 추천인 코드 생성
    const referralCode = await generateUniqueReferralCode();

    // 트랜잭션으로 사용자 생성
    const result = await prisma.$transaction(async (tx) => {
      // 1. 사용자 생성
      const newUser = await tx.users.create({
        data: {
          username,
          email: email || null,
          password: hashedPassword,
          walletAddress: walletAddress || null,
          referralCode, // 자동 생성된 추천인 코드
          referrerId: referrer?.id || null,
          sponsorId, // 스필오버로 찾은 후원인
          rank,
          role: 'USER', // 일반 사용자로 명시적으로 설정
          personalCoin: initialCoins,
          status: 'ACTIVE',
          isActive: true,
          // 랭크 시스템을 위한 초기값 설정
          line1Sales: 0,
          line2Sales: 0,
          line3Sales: 0,
          line4Sales: 0,
          line5Sales: 0,
          accumulatedSales: 0,
        },
        select: {
          id: true,
          username: true,
          email: true,
          walletAddress: true,
          rank: true,
          personalCoin: true,
          referrerId: true,
          createdAt: true
        }
      });

      // 2. 초기 코인 지급 로그 (초기 코인이 있는 경우)
      if (initialCoins > 0) {
        await tx.reward_logs.create({
          data: {
            userId: newUser.id,
            type: 'RANK', // 임시로 RANK 타입 사용
            amount: initialCoins,
            description: `관리자에 의한 초기 코인 지급 (${initialCoins} AO)`,
            isPaid: true,
            paidAt: new Date(),
          }
        });
      }

      // 3. 투자 상품 등록 (선택사항)
      let investment = null;
      if (investmentAmount && investmentTier) {
        // 투자 등급 정보 조회
        const tierInfo = await tx.investment_tiers.findUnique({
          where: { tier: investmentTier },
        });

        if (tierInfo) {
          const investmentAmountDecimal = new Prisma.Decimal(investmentAmount);
          const endDate = new Date();
          endDate.setFullYear(endDate.getFullYear() + 1);

          investment = await tx.investments.create({
            data: {
              userId: newUser.id,
              amount: investmentAmountDecimal,
              dailyRate: tierInfo.dailyRate,
              matchingDepth: tierInfo.matchingDepth,
              investment_tiers: investmentTier,
              startDate: new Date(),
              endDate: endDate,
              isActive: true,
              status: 'ACTIVE', // 관리자가 등록한 투자는 자동 활성화
            },
          });

          // 사용자의 총 투자금액 업데이트
          await tx.users.update({
            where: { id: newUser.id },
            data: {
              totalInvestment: {
                increment: investmentAmountDecimal,
              },
            },
          });
        }
      }

      // 4. 관리자 등록 로그
      await tx.reward_logs.create({
        data: {
          userId: newUser.id,
          type: 'RANK',
          amount: 0,
          description: `관리자에 의해 계정 생성됨 (추천인: ${referrer?.username || '없음'}${investment ? `, 투자: $${investmentAmount}` : ''})`,
          isPaid: true,
          paidAt: new Date(),
        }
      });

      return {
        users: newUser,
        other_users_users_referrerIdTousers: referrer?.username || null,
        investments: investment ? {
          id: investment.id,
          amount: investment.amount.toString(),
          tier: investment.investmentTier,
        } : null
      };
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    // ✅ 수당 체계 연동: 투자 상품이 등록된 경우 (트랜잭션 밖에서 실행)
    if (result.investment) {
      const investmentId = result.investments.id;
      const investmentAmount = new Prisma.Decimal(result.investments.amount);

      // 추천 보너스 지급
      // 참고: 리더십 보너스, 매칭 보너스, 랭크 보상은 일일 수익 지급 프로세스에서 자동으로 처리됨
      try {
        await distributeReferralBonus(result.users.id, investmentId, investmentAmount);
        console.log(`✅ [Admin] 회원 등록 시 추천 보너스 지급 완료: ${username}, 투자 ID ${investmentId}`);
      } catch (referralError) {
        console.error('[Admin] 회원 등록 시 추천 보너스 지급 실패:', referralError);
        // 보너스 지급 실패해도 회원 등록은 성공으로 처리
      }
    }

    console.log(`👤 [Admin] 관리자 회원가입 완료: ${username}`);
    console.log(`   추천인: ${result.referrer || '없음'}`);
    console.log(`   초기 코인: ${initialCoins} AO`);
    console.log(`   초기 랭크: ${rank}`);
    if (result.investment) {
      console.log(`   투자 상품: Tier ${result.investments.tier}, 금액: $${result.investments.amount}`);
    }

    return NextResponse.json({
      ok: true,
      message: '회원가입이 완료되었습니다.',
      data: {
        users: result.users,
        other_users_users_referrerIdTousers: result.referrer,
        initialCoins,
        rank,
        investments: result.investment
      }
    });
  } catch (error: any) {
    console.error('[Admin] 회원가입 실패:', error);

    // 에러 메시지 세분화
    let errorMessage = '회원가입 중 오류가 발생했습니다.';

    if (error.code === 'P2002') {
      // Prisma unique constraint violation
      errorMessage = '이미 사용 중인 정보가 있습니다.';
    } else if (error.code === 'P2025') {
      // Record not found
      errorMessage = '관련 정보를 찾을 수 없습니다.';
    } else if (error.message) {
      errorMessage = error.message;
    }

    return NextResponse.json(
      { ok: false, error: errorMessage },
      { status: 500 }
    );
  }
}

// 유효한 추천인 목록 조회 (드롭다운용)
export async function GET() {
  try {
    const referrers = await prisma.users.findMany({
      where: {
        isActive: true,
        status: 'ACTIVE'
      },
      select: {
        id: true,
        username: true,
        email: true,
        rank: true,
        createdAt: true
      },
      orderBy: [
        { rank: 'desc' },
        { createdAt: 'asc' }
      ]
    });

    return NextResponse.json({
      ok: true,
      data: referrers
    });
  } catch (error) {
    console.error('[Admin] 추천인 목록 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: '추천인 목록 조회 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}
