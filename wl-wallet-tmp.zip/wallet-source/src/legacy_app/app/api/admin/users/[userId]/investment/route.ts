import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { Decimal } from '@prisma/client/runtime/library';
import { requireAdmin } from '@/lib/admin-auth-server';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { distributeReferralBonus } from '@/services/referralBonus';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const { userId } = await params;
    const body = await request.json();
    const { amount, tier } = body;

    // 필수 필드 검증
    if (!amount || !tier) {
      return validationErrorResponse('투자 금액과 등급은 필수입니다.');
    }

    const investmentAmount = parseFloat(amount);
    if (isNaN(investmentAmount) || investmentAmount < 50) {
      return validationErrorResponse('투자 금액은 최소 $50 이상이어야 합니다.');
    }

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
      },
    });

    if (!user) {
      return errorResponse('사용자를 찾을 수 없습니다.', 404, 'USER_NOT_FOUND');
    }

    // 투자 등급 정보 조회
    const tierInfo = await prisma.investment_tiers.findUnique({
      where: { tier: parseInt(tier) },
    });

    if (!tierInfo) {
      return errorResponse('유효하지 않은 투자 등급입니다.', 400, 'INVALID_TIER');
    }

    // 투자 금액이 등급 범위 내인지 확인
    const amountDecimal = new Decimal(investmentAmount);
    if (amountDecimal.lessThan(tierInfo.minAmount)) {
      return validationErrorResponse(`투자 금액은 최소 $${tierInfo.minAmount} 이상이어야 합니다.`);
    }
    if (tierInfo.maxAmount && amountDecimal.greaterThan(tierInfo.maxAmount)) {
      return validationErrorResponse(`투자 금액은 최대 $${tierInfo.maxAmount} 이하여야 합니다.`);
    }

    // 투자 종료일 계산 (1년 후)
    const endDate = new Date();
    endDate.setFullYear(endDate.getFullYear() + 1);

    // 트랜잭션으로 투자 생성 및 사용자 정보 업데이트 (타임아웃 30초)
    const result = await prisma.$transaction(async (tx) => {
      // 투자 생성
      const investment = await tx.investments.create({
        data: {
          userId,
          amount: amountDecimal,
          dailyRate: tierInfo.dailyRate,
          matchingDepth: tierInfo.matchingDepth,
          investment_tiers: tierInfo.tier,
          startDate: new Date(),
          endDate: endDate,
          isActive: true,
          status: 'ACTIVE', // 관리자가 등록한 투자는 자동 활성화
        },
      });

      // 사용자의 총 투자금액 업데이트
      await tx.users.update({
        where: { id: userId },
        data: {
          totalInvestment: {
            increment: amountDecimal,
          },
        },
      });

      // 관리자 투자 등록 로그
      await tx.reward_logs.create({
        data: {
          userId,
          type: 'RANK',
          amount: 0,
          description: `관리자에 의해 투자 상품 등록됨 (Tier ${tierInfo.tier}, 금액: $${investmentAmount})`,
          isPaid: true,
          paidAt: new Date(),
        },
      });

      return investment;
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    // ✅ 수당 체계 연동: 추천 보너스 지급 (트랜잭션 밖에서 실행)
    // 참고: 리더십 보너스, 매칭 보너스, 랭크 보상은 일일 수익 지급 프로세스에서 자동으로 처리됨
    try {
      await distributeReferralBonus(userId, result.id, amountDecimal);
      console.log(`✅ [Admin] 추천 보너스 지급 완료: 사용자 ${user.username}, 투자 ID ${result.id}`);
    } catch (referralError) {
      console.error('[Admin] 추천 보너스 지급 실패:', referralError);
      // 보너스 지급 실패해도 투자 등록은 성공으로 처리
    }

    console.log(`💼 [Admin] 투자 상품 등록 완료: 사용자 ${user.username}, 금액 $${investmentAmount}, Tier ${tier}`);

    return successResponse(
      {
        id: result.id,
        amount: result.amount.toString(),
        tier: result.investmentTier,
        dailyRate: result.dailyRate.toString(),
        matchingDepth: result.matchingDepth,
        startDate: result.startDate,
        endDate: result.endDate,
      },
      '투자 상품이 성공적으로 등록되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin] 투자 등록 실패:', error);
    return errorResponse(
      error.message || '투자 등록 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

