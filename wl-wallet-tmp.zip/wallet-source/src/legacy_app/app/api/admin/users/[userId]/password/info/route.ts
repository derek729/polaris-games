import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { successResponse, errorResponse } from '@/lib/api-response';

/**
 * 관리자용 사용자 비밀번호 정보 조회 API
 * GET /api/admin/users/[userId]/password/info
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    const { userId } = await params;

    // 사용자 조회
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        password: true,
      },
    });

    if (!user) {
      return errorResponse('사용자를 찾을 수 없습니다.', 404, 'USER_NOT_FOUND');
    }

    return successResponse({
      hasPassword: !!user.password,
      passwordHash: user.password || null,
      passwordLength: user.password ? user.password.length : 0,
    });
  } catch (error: any) {
    console.error('[Admin] 비밀번호 정보 조회 실패:', error);
    return errorResponse(
      error.message || '비밀번호 정보 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

