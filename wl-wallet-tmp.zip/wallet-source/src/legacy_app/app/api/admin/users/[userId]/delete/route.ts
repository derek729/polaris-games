import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';

/**
 * 관리자용 사용자 삭제 API
 * DELETE /api/admin/users/[userId]/delete
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    const { userId } = await params;

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        role: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      );
    }

    // 관리자 계정 삭제 방지 (선택사항)
    if (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN') {
      return NextResponse.json(
        { ok: false, error: '관리자 계정은 삭제할 수 없습니다. 정지 기능을 사용해주세요.' },
        { status: 403 }
      );
    }

    // 트랜잭션으로 관련 데이터와 함께 삭제
    await prisma.$transaction(async (tx) => {
      // 관련 데이터 삭제 (병렬 처리로 속도 향상)
      await Promise.all([
        tx.reward_logs.deleteMany({ where: { userId } }),
        tx.investments.deleteMany({ where: { userId } }),
        tx.withdrawal_requests.deleteMany({ where: { userId } }),
        tx.transfers.deleteMany({ 
          where: { 
            OR: [
              { senderId: userId },
              { receiverId: userId }
            ]
          } 
        }),
        tx.game_share_purchases.deleteMany({ where: { userId } }),
        tx.game_revenue_distributions.deleteMany({ where: { userId } }),
        tx.mining_records.deleteMany({ where: { userId } }),
        tx.staking_records.deleteMany({ where: { userId } }),
        tx.team_sales.deleteMany({ where: { userId } }),
        tx.membership_code_usages.deleteMany({ where: { userId } }),
      ]);

      // 추천인/후원인 관계 해제 (다른 사용자의 referrerId, sponsorId를 null로)
      await Promise.all([
        tx.users.updateMany({
          where: { referrerId: userId },
          data: { referrerId: null }
        }),
        tx.users.updateMany({
          where: { sponsorId: userId },
          data: { sponsorId: null }
        }),
      ]);

      // 사용자 삭제
      await tx.users.delete({
        where: { id: userId }
      });
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    console.log(`🗑️ [Admin] 사용자 삭제 완료: ${user.username} (ID: ${userId})`);

    return NextResponse.json({
      ok: true,
      message: '사용자가 성공적으로 삭제되었습니다.',
      data: {
        userId,
        username: user.username,
      },
    });
  } catch (error: any) {
    console.error('[Admin] 사용자 삭제 실패:', error);
    
    return NextResponse.json(
      { ok: false, error: error.message || '사용자 삭제 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

