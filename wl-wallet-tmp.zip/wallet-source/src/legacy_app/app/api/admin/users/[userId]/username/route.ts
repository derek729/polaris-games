import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin } from '@/lib/admin-auth-server';
import { isValidUsername } from '@/lib/validation';

/**
 * 관리자용 사용자명 변경 API
 * PUT /api/admin/users/[userId]/username
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authResult = await requireAdmin(request);
    if (authResult) return authResult;

    const { userId } = await params;
    const body = await request.json();
    const { username } = body;

    // 필수 필드 검증
    if (!username || typeof username !== 'string') {
      return NextResponse.json(
        { ok: false, error: '사용자명을 입력해주세요.' },
        { status: 400 }
      );
    }

    // 사용자명 유효성 검사 (영문, 숫자, 언더스코어, 하이픈만 허용)
    const usernameCheck = isValidUsername(username.trim());
    if (!usernameCheck.valid) {
      return NextResponse.json(
        { ok: false, error: usernameCheck.message || '사용자명이 유효하지 않습니다.' },
        { status: 400 }
      );
    }

    const newUsername = username.trim();

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
      },
    });

    if (!user) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      );
    }

    // 현재 사용자명과 동일한지 확인
    if (user.username === newUsername) {
      return NextResponse.json(
        { ok: false, error: '현재 사용자명과 동일합니다.' },
        { status: 400 }
      );
    }

    // 중복 체크 (다른 사용자가 이미 사용 중인지 확인)
    const existingUser = await prisma.users.findFirst({
      where: {
        username: newUsername,
        id: { not: userId },
      },
    });

    if (existingUser) {
      return NextResponse.json(
        { ok: false, error: '이미 사용 중인 사용자명입니다.' },
        { status: 409 }
      );
    }

    // 사용자명 업데이트
    const updatedUser = await prisma.users.update({
      where: { id: userId },
      data: { username: newUsername },
      select: {
        id: true,
        username: true,
        email: true,
        rank: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    console.log(`[Admin] 사용자명 변경 완료: ${user.username} -> ${newUsername} (userId: ${userId})`);

    return NextResponse.json({
      ok: true,
      message: '사용자명이 성공적으로 변경되었습니다.',
      data: {
        users: updatedUser,
      },
    });
  } catch (error: any) {
    console.error('[Admin] 사용자명 변경 실패:', error);
    
    // Prisma 에러 처리
    if (error.code === 'P2002') {
      return NextResponse.json(
        { ok: false, error: '이미 사용 중인 사용자명입니다.' },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { ok: false, error: error.message || '사용자명 변경 중 오류가 발생했습니다.' },
      { status: 500 }
    );
  }
}

