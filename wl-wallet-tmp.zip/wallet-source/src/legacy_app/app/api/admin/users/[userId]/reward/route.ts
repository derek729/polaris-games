import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAdmin, getCurrentAdminUser } from '@/lib/admin-auth';
import { successResponse, errorResponse, unauthorizedResponse } from '@/lib/api-response';
import { Decimal } from '@prisma/client/runtime/library';
import { RewardType } from '@prisma/client';

/**
 * 관리자 수동 보상 지급 API
 * POST /api/admin/users/[userId]/reward
 * Body: { type: RewardType, amount: number, description?: string }
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    // 관리자 권한 확인
    const authError = await requireAdmin();
    if (authError) {
      return authError;
    }

    // 관리자 사용자 정보 가져오기
    const admin = await getCurrentAdminUser();
    if (!admin) {
      return unauthorizedResponse('관리자 권한이 필요합니다.');
    }

    const { userId } = await params;

    const body = await request.json();
    const { type, amount, description } = body;

    // 유효성 검사
    if (!type || !Object.values(RewardType).includes(type)) {
      return errorResponse('올바른 보상 타입을 선택해주세요.', 400);
    }

    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      return errorResponse('올바른 AO 코인 수량을 입력해주세요.', 400);
    }

    const rewardAmount = new Decimal(amount);

    // 사용자 조회
    const user = await prisma.users.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        personalCoin: true,
      },
    });

    if (!user) {
      return errorResponse('사용자를 찾을 수 없습니다.', 404);
    }

    // AO 코인 잔액 증가
    const newBalance = new Decimal(user.personalCoin || 0).plus(rewardAmount);

    // 보상 설명 생성
    const rewardDescription = description
      ? `[관리자 수동 지급] ${description} | 관리자: ${admin.username || admin.email} | 타입: ${type} | 이전: ${user.personalCoin?.toString() || '0'} AO | 지급: ${rewardAmount.toString()} AO | 이후: ${newBalance.toString()} AO`
      : `[관리자 수동 지급] 관리자: ${admin.username || admin.email} | 타입: ${type} | 이전: ${user.personalCoin?.toString() || '0'} AO | 지급: ${rewardAmount.toString()} AO | 이후: ${newBalance.toString()} AO`;

    await prisma.$transaction(
      async (tx) => {
        // 사용자 잔액 업데이트
        await tx.users.update({
          where: { id: userId },
          data: {
            personalCoin: newBalance,
          },
        });

        // 보상 로그 생성
        await tx.reward_logs.create({
          data: {
            userId,
            type: type as RewardType,
            amount: rewardAmount,
            isPaid: true,
            paidAt: new Date(),
            description: rewardDescription,
          },
        });
      },
      {
        maxWait: 30000,
        timeout: 30000,
      }
    );

    console.log(`[Admin Manual Reward] 보상 지급 완료: ${user.username} (${type}, ${rewardAmount.toString()} AO)`);

    return successResponse({
      userId: user.id,
      username: user.username,
      type,
      rewardAmount: rewardAmount.toString(),
      previousBalance: user.personalCoin?.toString() || '0',
      newBalance: newBalance.toString(),
    }, 'AO 코인이 성공적으로 지급되었습니다.');
  } catch (error: any) {
    console.error('[Admin Manual Reward] 오류:', error);
    return errorResponse(error.message || '보상 지급 중 오류가 발생했습니다.', 500);
  }
}

