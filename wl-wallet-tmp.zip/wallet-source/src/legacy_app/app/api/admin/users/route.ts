import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { UserStatus, UserRole } from '@prisma/client';
import { requireAdmin } from '@/lib/admin-auth';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';
import { validateRange } from '@/lib/validation';

const decimalToNumber = (value: any) => Number(value?.toString() ?? 0);

// 사용자 목록 조회
export async function GET(request: Request) {
  // 관리자 권한 체크
  const authResult = await requireAdmin(request as any);
  if (authResult) return authResult;

  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status') as UserStatus | null;
    const search = searchParams.get('search') || '';
    const rank = searchParams.get('rank') ? parseInt(searchParams.get('rank')!) : null;

    // 페이지네이션 검증
    const pageCheck = validateRange(page, 1, 1000, '페이지');
    if (!pageCheck.valid) {
      return validationErrorResponse(pageCheck.message || '페이지 번호가 유효하지 않습니다.');
    }

    const limitCheck = validateRange(limit, 1, 100, '페이지당 항목 수');
    if (!limitCheck.valid) {
      return validationErrorResponse(limitCheck.message || '페이지당 항목 수가 유효하지 않습니다.');
    }

    // 랭크 검증
    if (rank !== null) {
      const rankCheck = validateRange(rank, 0, 5, '랭크');
      if (!rankCheck.valid) {
        return validationErrorResponse(rankCheck.message || '랭크가 유효하지 않습니다.');
      }
    }

    const skip = (page - 1) * limit;

    // 검색 조건 구성
    const where: any = {};

    // 기본 필터 조건
    if (status) {
      where.status = status;
    }

    if (rank && !isNaN(rank)) {
      where.rank = rank;
    }

    // 검색 조건이 있을 때 AND 조건으로 결합
    if (search) {
      const searchConditions = [
        { username: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { walletAddress: { contains: search, mode: 'insensitive' } }
      ];

      // 다른 필터 조건이 있으면 AND로 결합
      if (status || rank) {
        where.AND = [
          ...(status ? [{ status }] : []),
          ...(rank && !isNaN(rank) ? [{ rank }] : []),
          { OR: searchConditions }
        ];
        // 기존 조건 제거 (AND로 재구성했으므로)
        delete where.status;
        delete where.rank;
      } else {
        // 검색만 있으면 OR 조건 사용
        where.OR = searchConditions;
      }
    }

    // 사용자 목록 조회
    const [users, totalCount] = await Promise.all([
      prisma.users.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          username: true,
          email: true,
          walletAddress: true,
          rank: true,
          totalInvestment: true,
          personalCoin: true,
          status: true,
          isActive: true,
          createdAt: true,
          updatedAt: true,
          referrerId: true,
          other_users_users_referrerIdTousers: {
            select: {
              username: true,
              referralCode: true,
            }
          },
          sponsorId: true,
          other_users_users_sponsorIdTousers: {
            select: {
              username: true,
              referralCode: true,
            }
          },
          _count: {
            select: {
              other_users_users_referrerIdTousers: true,
              investments: true,
              reward_logs: true,
            }
          }
        }
      }),
      prisma.users.count({ where })
    ]);

    const totalPages = Math.ceil(totalCount / limit);

    return successResponse({
      users: users.map(user => ({
        ...users,
        totalInvestment: decimalToNumber(user.totalInvestment),
        personalCoin: decimalToNumber(user.personalCoin),
      })),
      pagination: {
        currentPage: page,
        totalPages,
        totalCount,
        limit,
        hasNext: page < totalPages,
        hasPrev: page > 1,
      }
    });
  } catch (error: any) {
    console.error('[Admin] 사용자 목록 조회 실패:', error);
    return errorResponse(
      error.message || '사용자 목록 조회 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}