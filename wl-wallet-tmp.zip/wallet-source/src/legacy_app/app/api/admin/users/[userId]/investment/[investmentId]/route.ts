import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { Decimal } from '@prisma/client/runtime/library';
import { requireAdmin } from '@/lib/admin-auth-server';
import { successResponse, errorResponse, validationErrorResponse } from '@/lib/api-response';

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string; investmentId: string }> }
) {
  try {
    // 관리자 권한 체크
    const authError = await requireAdmin(request);
    if (authError) {
      return authError;
    }

    const { userId, investmentId } = await params;
    const body = await request.json();
    const { amount, tier } = body;

    // 필수 필드 검증
    if (!amount || !tier) {
      return validationErrorResponse('투자 금액과 등급은 필수입니다.');
    }

    const investmentAmount = parseFloat(amount);
    if (isNaN(investmentAmount) || investmentAmount < 50) {
      return validationErrorResponse('투자 금액은 최소 $50 이상이어야 합니다.');
    }

    // 사용자 존재 확인
    const user = await prisma.users.findUnique({
      where: { id: userId },
    });

    if (!user) {
      return errorResponse('사용자를 찾을 수 없습니다.', 404, 'USER_NOT_FOUND');
    }

    // 투자 존재 확인
    const existingInvestment = await prisma.investments.findUnique({
      where: { id: investmentId },
    });

    if (!existingInvestment) {
      return errorResponse('투자를 찾을 수 없습니다.', 404, 'INVESTMENT_NOT_FOUND');
    }

    if (existingInvestment.userId !== userId) {
      return errorResponse('해당 사용자의 투자가 아닙니다.', 403, 'FORBIDDEN');
    }

    // 투자 등급 정보 조회
    const tierInfo = await prisma.investment_tiers.findUnique({
      where: { tier: parseInt(tier) },
    });

    if (!tierInfo) {
      return errorResponse('유효하지 않은 투자 등급입니다.', 400, 'INVALID_TIER');
    }

    // 투자 금액이 등급 범위 내인지 확인
    const amountDecimal = new Decimal(investmentAmount);
    if (amountDecimal.lessThan(tierInfo.minAmount)) {
      return validationErrorResponse(`투자 금액은 최소 $${tierInfo.minAmount} 이상이어야 합니다.`);
    }
    if (tierInfo.maxAmount && amountDecimal.greaterThan(tierInfo.maxAmount)) {
      return validationErrorResponse(`투자 금액은 최대 $${tierInfo.maxAmount} 이하여야 합니다.`);
    }

    // 기존 투자 금액과의 차이 계산
    const oldAmount = new Decimal(existingInvestment.amount);
    const amountDifference = amountDecimal.minus(oldAmount);

    // 트랜잭션으로 투자 수정 및 사용자 정보 업데이트 (타임아웃 30초)
    const result = await prisma.$transaction(async (tx) => {
      // 투자 수정
      const updatedInvestment = await tx.investments.update({
        where: { id: investmentId },
        data: {
          amount: amountDecimal,
          dailyRate: tierInfo.dailyRate,
          matchingDepth: tierInfo.matchingDepth,
          investment_tiers: tierInfo.tier,
        },
      });

      // 사용자의 총 투자금액 업데이트 (차이만큼 조정)
      await tx.users.update({
        where: { id: userId },
        data: {
          totalInvestment: {
            increment: amountDifference,
          },
        },
      });

      // 관리자 투자 수정 로그
      await tx.reward_logs.create({
        data: {
          userId,
          type: 'RANK',
          amount: 0,
          description: `관리자에 의해 투자 상품 수정됨 (ID: ${investmentId}, Tier ${existingInvestment.investmentTier} → ${tierInfo.tier}, 금액: $${oldAmount} → $${investmentAmount})`,
          isPaid: true,
          paidAt: new Date(),
        },
      });

      return updatedInvestment;
    }, {
      maxWait: 30000, // 최대 대기 시간 30초
      timeout: 30000, // 타임아웃 30초
    });

    console.log(`💼 [Admin] 투자 상품 수정 완료: 사용자 ${user.username}, 투자 ID ${investmentId}, 금액 $${oldAmount} → $${investmentAmount}, Tier ${existingInvestment.investmentTier} → ${tier}`);

    return successResponse(
      {
        id: result.id,
        amount: result.amount.toString(),
        tier: result.investmentTier,
        dailyRate: result.dailyRate.toString(),
        matchingDepth: result.matchingDepth,
        startDate: result.startDate,
        endDate: result.endDate,
      },
      '투자 상품이 성공적으로 수정되었습니다.'
    );
  } catch (error: any) {
    console.error('[Admin] 투자 수정 실패:', error);
    return errorResponse(
      error.message || '투자 수정 중 오류가 발생했습니다.',
      500,
      'SERVER_ERROR'
    );
  }
}

