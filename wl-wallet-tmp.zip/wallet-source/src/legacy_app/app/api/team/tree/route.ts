import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';

// 조직도 트리 노드 타입
type OrgTreeNode = {
  name: string;
  attributes: {
    Rank: string;
    투자: string;
  };
  children?: OrgTreeNode[];
};

const RANK_NAMES: Record<number, string> = {
  0: '신입',
  1: '1성',
  2: '2성',
  3: '3성',
  4: '4성',
  5: '5성',
};

function decimalToNumber(value?: Prisma.Decimal | null): number {
  return Number(value?.toString() ?? 0);
}

async function buildOrgTree(
  userId: string,
  currentDepth: number,
  maxDepth: number
): Promise<OrgTreeNode | null> {
  if (currentDepth > maxDepth) return null;

  const user = await prisma.users.findUnique({
    where: { id: userId },
    select: {
      id: true,
      username: true,
      rank: true,
      totalInvestment: true,
    },
  });

  if (!user) return null;

  const children = await prisma.users.findMany({
    where: { referrerId: userId, isActive: true },
    select: { id: true },
    orderBy: { createdAt: 'asc' },
  });

  const childrenNodes: OrgTreeNode[] = [];
  for (const child of children) {
    const childNode = await buildOrgTree(child.id, currentDepth + 1, maxDepth);
    if (childNode) {
      childrenNodes.push(childNode);
    }
  }

  return {
    name: user.username || `User ${user.id.slice(0, 6)}`,
    attributes: {
      Rank: RANK_NAMES[user.rank] || '신입',
      투자: `$${decimalToNumber(user.totalInvestment).toLocaleString()}`,
    },
    children: childrenNodes.length > 0 ? childrenNodes : undefined,
  };
}

/**
 * 특정 사용자의 조직도 트리 조회
 * GET /api/team/tree?username=okknj6053
 */
export async function GET(request: NextRequest) {
  try {
    // 인증 확인
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json(
        { ok: false, error: '로그인이 필요합니다.' },
        { status: 401 }
      );
    }

    // 쿼리 파라미터에서 username 가져오기
    const searchParams = request.nextUrl.searchParams;
    const username = searchParams.get('username');

    if (!username) {
      return NextResponse.json(
        { ok: false, error: '사용자명이 필요합니다.' },
        { status: 400 }
      );
    }

    // 사용자 찾기
    const targetUser = await prisma.users.findFirst({
      where: {
        OR: [
          { username: username },
          { email: username },
        ],
      },
      select: {
        id: true,
        username: true,
        email: true,
        rank: true,
        totalInvestment: true,
        _count: {
          select: {
            other_users_users_referrerIdTousers: true,
          },
        },
      },
    });

    if (!targetUser) {
      return NextResponse.json(
        { ok: false, error: '사용자를 찾을 수 없습니다.' },
        { status: 404 }
      );
    }

    // 조직도 트리 생성 (최대 5단계)
    const orgTree = await buildOrgTree(targetUser.id, 0, 5);

    return NextResponse.json({
      ok: true,
      data: {
        users: {
          id: targetUser.id,
          username: targetUser.username,
          email: targetUser.email,
          rank: targetUser.rank,
          totalInvestment: decimalToNumber(targetUser.totalInvestment),
          referredUsersCount: targetUser._count.referredUsers,
        },
        orgTree,
      },
    });
  } catch (error: any) {
    console.error('[Team Tree] 조직도 조회 실패:', error);
    return NextResponse.json(
      { ok: false, error: '조직도 조회에 실패했습니다.' },
      { status: 500 }
    );
  }
}

