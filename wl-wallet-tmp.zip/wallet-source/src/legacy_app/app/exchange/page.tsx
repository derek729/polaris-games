import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { isAdminUser } from '@/lib/admin-auth';
import ExchangeClient from './ExchangeClient';

export default async function ExchangePage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  if (isAdminUser(user)) {
    redirect('/a0-admin');
  }

  // personalCoin을 number로 변환
  const userForClient: { id: string; username: string | null; personalCoin: number } = {
    id: user.id,
    username: user.username,
    personalCoin: typeof user.personalCoin === 'object' && user.personalCoin !== null
      ? Number(user.personalCoin.toString())
      : Number(user.personalCoin || 0),
  };

  return <ExchangeClient user={userForClient} />;
}

