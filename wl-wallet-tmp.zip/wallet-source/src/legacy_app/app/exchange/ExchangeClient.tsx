'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n/context';
import PageHeader from '@/components/layout/PageHeader';
import { Decimal } from '@prisma/client';
import CandlestickChart from '@/components/exchange/CandlestickChart';

interface User {
  id: string;
  username: string | null;
  personalCoin: number;
}

interface OrderBookItem {
  price: number;
  totalAmount: number;
  orders: Array<{
    id: string;
    amount: number;
    createdAt: Date;
  }>;
}

interface RecentTrade {
  id: string;
  price: number;
  amount: number;
  totalValue: number;
  buyer: { id: string; username: string | null };
  seller: { id: string; username: string | null };
  tradedAt: Date;
  txHash: string | null;
}

interface OrderBookData {
  buyOrders: OrderBookItem[];
  sellOrders: OrderBookItem[];
  recentTrades: RecentTrade[];
  currentPrice: number;
  stats24h: {
    volume: number;
    totalValue: number;
    tradeCount: number;
    avgPrice: number;
  };
}

export default function ExchangeClient({ user }: { users: User }) {
  const router = useRouter();
  const { t, language } = useI18n();
  const [mounted, setMounted] = useState(false);
  const [orderBook, setOrderBook] = useState<OrderBookData | null>(null);
  const [loading, setLoading] = useState(false);
  const [orderType, setOrderType] = useState<'BUY' | 'SELL'>('BUY');
  const [priceType, setPriceType] = useState<'LIMIT' | 'MARKET'>('LIMIT');
  const [price, setPrice] = useState('');
  const [amount, setAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [chartPeriod, setChartPeriod] = useState<'1m' | '5m' | '15m' | '30m' | '1h' | '4h' | '1d'>('15m');
  const [showIndicators, setShowIndicators] = useState(true);

  useEffect(() => {
    setMounted(true);
    fetchOrderBook();
    const interval = setInterval(fetchOrderBook, 5000); // 5초마다 갱신
    return () => clearInterval(interval);
  }, []);

  const fetchOrderBook = useCallback(async () => {
    try {
      const res = await fetch('/api/user/exchange/orderbook', {
        credentials: 'include',
      });
      const data = await res.json();
      if (data.ok && data.data) {
        setOrderBook(data.data);
        // 현재 가격을 기본 가격으로 설정
        if (data.data.currentPrice && !price) {
          setPrice(data.data.currentPrice.toFixed(8));
        }
      }
    } catch (err) {
      console.error('주문북 조회 실패:', err);
    }
  }, [price]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!price && priceType === 'LIMIT') {
      alert(language === 'ko' ? '가격을 입력해주세요.' : 'Please enter a price.');
      return;
    }
    if (!amount) {
      alert(language === 'ko' ? '수량을 입력해주세요.' : 'Please enter an amount.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/user/exchange/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          type: orderType,
          price: priceType === 'LIMIT' ? parseFloat(price) : 0,
          amount: parseFloat(amount),
          orderType: priceType,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        alert(
          language === 'ko'
            ? `${orderType === 'BUY' ? '매수' : '매도'} 주문이 생성되었습니다.`
            : `${orderType === 'BUY' ? 'Buy' : 'Sell'} order created.`
        );
        setPrice('');
        setAmount('');
        fetchOrderBook();
      } else {
        alert(data.error || (language === 'ko' ? '주문 생성 실패' : 'Failed to create order'));
      }
    } catch (err) {
      console.error('주문 생성 실패:', err);
      alert(language === 'ko' ? '주문 생성 중 오류가 발생했습니다.' : 'Error creating order.');
    } finally {
      setSubmitting(false);
    }
  };

  const formatPrice = (price: number) => {
    return price.toFixed(8);
  };

  const formatAmount = (amount: number) => {
    return amount.toFixed(8);
  };

  // RSI 계산 함수
  const calculateRSI = (data: Array<{ close: number }>) => {
    if (data.length < 15) return '50.00';
    
    const closes = data.map(d => d.close);
    const gains: number[] = [];
    const losses: number[] = [];
    
    for (let i = 1; i < closes.length; i++) {
      const change = closes[i] - closes[i - 1];
      gains.push(Math.max(0, change));
      losses.push(Math.max(0, -change));
    }
    
    const period = 14;
    const recentGains = gains.slice(-period);
    const recentLosses = losses.slice(-period);
    
    const avgGain = recentGains.reduce((a, b) => a + b, 0) / period;
    const avgLoss = recentLosses.reduce((a, b) => a + b, 0) / period;
    
    if (avgLoss === 0) return '100.00';
    const rs = avgGain / avgLoss;
    const rsi = 100 - (100 / (1 + rs));
    
    return rsi.toFixed(2);
  };

  // 차트 데이터 생성 (거래 내역 기반)
  const chartData = useMemo(() => {
    const periodMs = {
      '1m': 60000,
      '5m': 300000,
      '15m': 900000,
      '30m': 1800000,
      '1h': 3600000,
      '4h': 14400000,
      '1d': 86400000,
    }[chartPeriod];

    if (!orderBook || !orderBook.recentTrades.length) {
      // 거래 내역이 없으면 샘플 데이터 생성
      const now = new Date();
      const data = [];
      const basePrice = orderBook?.currentPrice || 0.00010;
      
      for (let i = 29; i >= 0; i--) {
        const time = new Date(now.getTime() - i * periodMs);
        const variation = (Math.random() - 0.5) * 0.00001;
        const open = basePrice + variation;
        const close = open + (Math.random() - 0.5) * 0.00001;
        const high = Math.max(open, close) + Math.random() * 0.000005;
        const low = Math.min(open, close) - Math.random() * 0.000005;
        const volume = Math.random() * 1000;
        
        data.push({
          time: time.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
          open,
          high,
          low,
          close,
          volume,
        });
      }
      return data;
    }

    // 실제 거래 내역을 기반으로 차트 데이터 생성
    const trades = orderBook.recentTrades;
    const groupedTrades: { [key: string]: typeof trades } = {};
    
    trades.forEach((trade) => {
      const tradeTime = new Date(trade.tradedAt);
      let timeKey = '';
      
      if (chartPeriod === '1m') {
        timeKey = tradeTime.toISOString().slice(0, 16);
      } else if (chartPeriod === '5m') {
        const minutes = Math.floor(tradeTime.getMinutes() / 5) * 5;
        timeKey = `${tradeTime.toISOString().slice(0, 13)}:${minutes.toString().padStart(2, '0')}`;
      } else if (chartPeriod === '15m') {
        const minutes = Math.floor(tradeTime.getMinutes() / 15) * 15;
        timeKey = `${tradeTime.toISOString().slice(0, 13)}:${minutes.toString().padStart(2, '0')}`;
      } else if (chartPeriod === '30m') {
        const minutes = Math.floor(tradeTime.getMinutes() / 30) * 30;
        timeKey = `${tradeTime.toISOString().slice(0, 13)}:${minutes.toString().padStart(2, '0')}`;
      } else if (chartPeriod === '1h') {
        timeKey = tradeTime.toISOString().slice(0, 13) + ':00';
      } else if (chartPeriod === '4h') {
        const hours = Math.floor(tradeTime.getHours() / 4) * 4;
        timeKey = `${tradeTime.toISOString().slice(0, 11)}${hours.toString().padStart(2, '0')}:00`;
      } else {
        timeKey = tradeTime.toISOString().slice(0, 10);
      }
      
      if (!groupedTrades[timeKey]) {
        groupedTrades[timeKey] = [];
      }
      groupedTrades[timeKey].push(trade);
    });

    const result = Object.keys(groupedTrades)
      .sort()
      .map((timeKey) => {
        const periodTrades = groupedTrades[timeKey];
        const prices = periodTrades.map((t) => t.price);
        const volumes = periodTrades.map((t) => t.amount);
        
        return {
          time: new Date(timeKey).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
          open: prices[0] || 0,
          high: Math.max(...prices) || 0,
          low: Math.min(...prices) || 0,
          close: prices[prices.length - 1] || 0,
          volume: volumes.reduce((a, b) => a + b, 0),
        };
      });

    // 데이터가 30개 미만이면 샘플 데이터로 채우기
    if (result.length < 30) {
      const basePrice = result.length > 0 ? result[result.length - 1].close : (orderBook?.currentPrice || 0.00010);
      const now = new Date();
      for (let i = result.length; i < 30; i++) {
        const time = new Date(now.getTime() - (29 - i) * periodMs);
        const variation = (Math.random() - 0.5) * 0.00001;
        const open = basePrice + variation;
        const close = open + (Math.random() - 0.5) * 0.00001;
        const high = Math.max(open, close) + Math.random() * 0.000005;
        const low = Math.min(open, close) - Math.random() * 0.000005;
        const volume = Math.random() * 1000;
        
        result.push({
          time: time.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }),
          open,
          high,
          low,
          close,
          volume,
        });
      }
    }

    return result;
  }, [orderBook, chartPeriod]);

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-white">{t.common.loading}</div>
      </div>
    );
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-[#101922] overflow-x-hidden">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-10 md:px-20 lg:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col max-w-7xl flex-1">
            {/* Header */}
            <PageHeader
              user={{ username: user.username || '', personalCoin: user.personalCoin }}
            />

            {/* Main Content */}
            <main className="flex-1 px-4 sm:px-10 py-6">
              <div className="mb-6">
                <h1 className="text-white text-2xl font-bold">
                  {language === 'ko' ? 'MSUO 코인 거래소' : 'MSUO Coin Exchange'}
                </h1>
                {orderBook && (
                  <div className="mt-4 flex flex-wrap gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">{language === 'ko' ? '현재가: ' : 'Current: '}</span>
                      <span className="text-white font-semibold">{formatPrice(orderBook.currentPrice)} USDT</span>
                    </div>
                    <div>
                      <span className="text-gray-400">{language === 'ko' ? '24h 거래량: ' : '24h Volume: '}</span>
                      <span className="text-white">{formatAmount(orderBook.stats24h.volume)} MSUO</span>
                    </div>
                    <div>
                      <span className="text-gray-400">{language === 'ko' ? '시작가: ' : 'Initial: '}</span>
                      <span className="text-white">$0.00010 USDT</span>
                    </div>
                    <div>
                      <span className="text-gray-400">{language === 'ko' ? '총 발행량: ' : 'Total Supply: '}</span>
                      <span className="text-white">5,000,000,000 MSUO</span>
                    </div>
                  </div>
                )}
              </div>

              {/* 차트 섹션 */}
              <div className="mb-6 bg-white/5 border border-white/10 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-white text-lg font-semibold">
                    {language === 'ko' ? '가격 차트' : 'Price Chart'}
                  </h2>
                  <div className="flex items-center gap-2">
                    {/* 기간 선택 */}
                    <div className="flex gap-1 bg-white/5 rounded-lg p-1">
                      {(['1m', '5m', '15m', '30m', '1h', '4h', '1d'] as const).map((p) => (
                        <button
                          key={p}
                          onClick={() => setChartPeriod(p)}
                          className={`px-3 py-1 text-xs rounded transition-colors ${
                            chartPeriod === p
                              ? 'bg-blue-500 text-white'
                              : 'text-gray-400 hover:text-white hover:bg-white/10'
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                    {/* 보조지표 토글 */}
                    <button
                      onClick={() => setShowIndicators(!showIndicators)}
                      className={`px-3 py-1 text-xs rounded transition-colors ${
                        showIndicators
                          ? 'bg-green-500 text-white'
                          : 'bg-white/5 text-gray-400 hover:text-white'
                      }`}
                    >
                      {language === 'ko' ? '보조지표' : 'Indicators'}
                    </button>
                  </div>
                </div>
                <div className="h-96">
                  <CandlestickChart data={chartData} period={chartPeriod} showIndicators={showIndicators} />
                </div>
                {showIndicators && (
                  <div className="mt-4 flex gap-4 text-xs text-gray-400">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-0.5 bg-blue-500"></div>
                      <span>SMA5</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-0.5 bg-yellow-500"></div>
                      <span>SMA20</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span>RSI: {chartData.length > 0 ? calculateRSI(chartData) : '50.00'}</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* 주문 입력 */}
                <div className="lg:col-span-1">
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <div className="flex gap-2 mb-4">
                      <button
                        onClick={() => setOrderType('BUY')}
                        className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors ${
                          orderType === 'BUY'
                            ? 'bg-green-500 text-white'
                            : 'bg-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        {language === 'ko' ? '매수' : 'Buy'}
                      </button>
                      <button
                        onClick={() => setOrderType('SELL')}
                        className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors ${
                          orderType === 'SELL'
                            ? 'bg-red-500 text-white'
                            : 'bg-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        {language === 'ko' ? '매도' : 'Sell'}
                      </button>
                    </div>

                    <div className="flex gap-2 mb-4">
                      <button
                        onClick={() => setPriceType('LIMIT')}
                        className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                          priceType === 'LIMIT'
                            ? 'bg-blue-500 text-white'
                            : 'bg-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        {language === 'ko' ? '지정가' : 'Limit'}
                      </button>
                      <button
                        onClick={() => setPriceType('MARKET')}
                        className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                          priceType === 'MARKET'
                            ? 'bg-blue-500 text-white'
                            : 'bg-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        {language === 'ko' ? '시장가' : 'Market'}
                      </button>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      {priceType === 'LIMIT' && (
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            {language === 'ko' ? '가격 (USDT)' : 'Price (USDT)'}
                          </label>
                          <input
                            type="number"
                            step="0.00000001"
                            value={price}
                            onChange={(e) => setPrice(e.target.value)}
                            className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500"
                            placeholder="0.00000000"
                            required
                          />
                        </div>
                      )}

                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          {language === 'ko' ? '수량 (MSUO)' : 'Amount (MSUO)'}
                        </label>
                        <input
                          type="number"
                          step="0.00000001"
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-blue-500"
                          placeholder="0.00000000"
                          required
                        />
                      </div>

                      {priceType === 'LIMIT' && price && amount && (
                        <div className="text-sm text-gray-400">
                          {language === 'ko' ? '총액: ' : 'Total: '}
                          <span className="text-white font-semibold">
                            {(parseFloat(price) * parseFloat(amount)).toFixed(8)} USDT
                          </span>
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={submitting}
                        className={`w-full py-3 px-4 rounded-lg font-semibold text-white transition-colors ${
                          orderType === 'BUY'
                            ? 'bg-green-500 hover:bg-green-600'
                            : 'bg-red-500 hover:bg-red-600'
                        } disabled:opacity-50 disabled:cursor-not-allowed`}
                      >
                        {submitting
                          ? (language === 'ko' ? '처리 중...' : 'Processing...')
                          : orderType === 'BUY'
                          ? (language === 'ko' ? '매수' : 'Buy')
                          : (language === 'ko' ? '매도' : 'Sell')}
                      </button>
                    </form>
                  </div>
                </div>

                {/* 주문북 및 거래 내역 */}
                <div className="lg:col-span-2 space-y-6">
                  {/* 주문북 */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <h2 className="text-white text-lg font-semibold mb-4">
                      {language === 'ko' ? '주문북' : 'Order Book'}
                    </h2>
                    <div className="grid grid-cols-2 gap-4">
                      {/* 매도 호가 */}
                      <div>
                        <h3 className="text-red-400 text-sm font-medium mb-2">
                          {language === 'ko' ? '매도 호가' : 'Sell Orders'}
                        </h3>
                        <div className="space-y-1 max-h-64 overflow-y-auto">
                          {orderBook && orderBook.sellOrders && orderBook.sellOrders.length > 0 ? (
                            orderBook.sellOrders.slice(0, 10).map((item: any, idx: number) => (
                              <div
                                key={idx}
                                className="flex justify-between text-xs py-1 px-2 hover:bg-white/5 rounded cursor-pointer"
                                onClick={() => {
                                  if (orderType === 'BUY') {
                                    setPrice(item.price.toFixed(8));
                                  }
                                }}
                              >
                                <span className="text-red-400">{formatPrice(item.price)}</span>
                                <span className="text-gray-300">{formatAmount(item.totalAmount)}</span>
                              </div>
                            ))
                          ) : (
                            <div className="text-center text-gray-500 text-xs py-4">
                              {language === 'ko' ? '매도 호가가 없습니다.' : 'No sell orders'}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* 매수 호가 */}
                      <div>
                        <h3 className="text-green-400 text-sm font-medium mb-2">
                          {language === 'ko' ? '매수 호가' : 'Buy Orders'}
                        </h3>
                        <div className="space-y-1 max-h-64 overflow-y-auto">
                          {orderBook && orderBook.buyOrders && orderBook.buyOrders.length > 0 ? (
                            orderBook.buyOrders.slice(0, 10).map((item: any, idx: number) => (
                              <div
                                key={idx}
                                className="flex justify-between text-xs py-1 px-2 hover:bg-white/5 rounded cursor-pointer"
                                onClick={() => {
                                  if (orderType === 'SELL') {
                                    setPrice(item.price.toFixed(8));
                                  }
                                }}
                              >
                                <span className="text-green-400">{formatPrice(item.price)}</span>
                                <span className="text-gray-300">{formatAmount(item.totalAmount)}</span>
                              </div>
                            ))
                          ) : (
                            <div className="text-center text-gray-500 text-xs py-4">
                              {language === 'ko' ? '매수 호가가 없습니다.' : 'No buy orders'}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 최근 거래 내역 */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-6">
                    <h2 className="text-white text-lg font-semibold mb-4">
                      {language === 'ko' ? '최근 거래' : 'Recent Trades'}
                    </h2>
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {orderBook && orderBook.recentTrades && orderBook.recentTrades.length > 0 ? (
                        orderBook.recentTrades.slice(0, 20).map((trade: any) => (
                          <div
                            key={trade.id}
                            className="flex justify-between text-xs py-2 px-3 border-b border-white/5 hover:bg-white/5 rounded"
                          >
                            <div className="flex-1">
                              <div className="text-white font-medium">{formatPrice(trade.price)}</div>
                              <div className="text-gray-400 text-[10px]">
                                {new Date(trade.tradedAt).toLocaleTimeString('ko-KR', { 
                                  hour: '2-digit', 
                                  minute: '2-digit',
                                  second: '2-digit'
                                })}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-gray-300 font-medium">{formatAmount(trade.amount)} MSUO</div>
                              {trade.txHash && (
                                <div className="text-gray-500 text-[10px] font-mono">
                                  {trade.txHash.slice(0, 8)}...
                                </div>
                              )}
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center text-gray-500 text-xs py-8">
                          {language === 'ko' ? '최근 거래 내역이 없습니다.' : 'No recent trades'}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}

