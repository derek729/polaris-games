
'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';

interface Notification {
    id: string;
    title: string;
    message: string;
    date: string;
    read: boolean;
}

export default function NotificationsPage() {
    const [notifications, setNotifications] = useState<Notification[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        fetchNotifications();
    }, []);

    const fetchNotifications = async () => {
        try {
            const response = await fetch('/api/admin/notifications', {
                credentials: 'include'
            });

            if (response.ok) {
                const data = await response.json();
                if (data.ok) {
                    setNotifications(data.notifications || []);
                }
            }
        } catch (error) {
            console.error('알림 조회 실패:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const markAsRead = async (id: string) => {
        try {
            await fetch(`/api/admin/notifications/${id}/read`, {
                method: 'PUT',
                credentials: 'include'
            });
            setNotifications(notifications.map(n => 
                n.id === id ? { ...n, read: true } : n
            ));
        } catch (error) {
            console.error('읽음 처리 실패:', error);
        }
    };

    return (
        <div className="min-h-screen bg-[#101922] text-white p-6">
            <div className="max-w-3xl mx-auto">
                <header className="mb-8 flex items-center gap-4">
                    <Link href="/dashboard" className="text-gray-400 hover:text-white">
                        <span className="material-symbols-outlined">arrow_back</span>
                    </Link>
                    <h1 className="text-2xl font-bold">알림 센터</h1>
                </header>

                {isLoading ? (
                    <div className="text-center py-12 text-gray-500">
                        <p>로딩 중...</p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {notifications.length > 0 ? (
                            notifications.map((noti) => (
                                <div
                                    key={noti.id}
                                    onClick={() => !noti.read && markAsRead(noti.id)}
                                    className={`bg-white/5 rounded-xl p-5 border cursor-pointer hover:bg-white/10 transition-colors ${noti.read ? 'border-white/5 opacity-70' : 'border-[#137fec]/50 bg-[#137fec]/10'}`}
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <h3 className="font-semibold text-lg">{noti.title}</h3>
                                        <span className="text-xs text-gray-400">{new Date(noti.date).toLocaleDateString('ko-KR')}</span>
                                    </div>
                                    <p className="text-gray-300">{noti.message}</p>
                                    {!noti.read && (
                                        <div className="mt-2 flex items-center gap-2 text-xs text-[#137fec]">
                                            <span className="material-symbols-outlined text-sm">circle</span>
                                            <span>읽지 않음</span>
                                        </div>
                                    )}
                                </div>
                            ))
                        ) : (
                            <div className="text-center py-12 text-gray-500">
                                <span className="material-symbols-outlined text-4xl mb-2">notifications_off</span>
                                <p>새로운 알림이 없습니다.</p>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

