'use client'

import { useEffect, useState, useCallback, useMemo } from 'react'
import Link from 'next/link'
import { useI18n } from '@/lib/i18n/context'

interface DashboardData {
  overview: {
    totalUsers: number
    activeUsers: number
    todayUsers: number
    totalInvestment: number
    totalInvestmentCount: number
    activeInvestments: number
    monthlyInvestment: number
    investmentGrowthRate: number
    todayInvestment: number
    totalWithdrawal: number
    pendingWithdrawals: number
    approvedWithdrawals: number
    rejectedWithdrawals: number
    todayWithdrawal: number
    totalRewards: number
    monthlyRewards: number
    todayRewards: number
    rewardByType?: Array<{
      type: string
      amount: number
      count: number
    }>
  }
  rankDistribution: Array<{
    rank: number
    count: number
  }>
  recentActivities: {
    newUsers: Array<{
      id: string
      username: string
      email: string
      rank: number
      totalInvestment: number
      createdAt: string
      referrer?: { username: string }
    }>
    withdrawals: Array<{
      id: string
      amount: number
      status: string
      requestedAt: string
      users: { username: string; email: string }
    }>
  }
  topInvestors: Array<{
    id: string
    username: string
    email: string
    rank: number
    totalInvestment: number
    createdAt: string
    _count: { other_users_users_referrerIdTousers: number; investments: number }
  }>
  systemMetrics: {
    daysSinceLaunch: number
    firstInvestmentDate?: string
    firstWithdrawalDate?: string
    firstRewardDate?: string
  }
}

export default function NewAdminDashboard() {
  const { t, language } = useI18n()
  const [data, setData] = useState<DashboardData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [retryCount, setRetryCount] = useState(0)

  const fetchDashboardData = useCallback(async (retry = 0) => {
    try {
      setIsLoading(true)
      setError(null)

      const response = await fetch('/api/admin/dashboard', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      })

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
          setError('관리자 권한이 필요합니다.')
          return
        }
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      const result = await response.json()

      if (!result.ok) {
        throw new Error(result.error || '데이터를 불러올 수 없습니다.')
      }

      if (!result.data) {
        throw new Error('데이터 형식이 올바르지 않습니다.')
      }

      // 데이터 검증
      if (
        !result.data.overview ||
        !result.data.rankDistribution ||
        !result.data.recentActivities
      ) {
        throw new Error('필수 데이터가 누락되었습니다.')
      }

      setData(result.data)
      setRetryCount(0)
    } catch (err: any) {
      console.error('대시보드 데이터 조회 실패:', err)
      setError(err.message || '데이터를 불러오는 중 오류가 발생했습니다.')

      // 재시도 로직 (최대 3회)
      if (retry < 3) {
        setTimeout(() => {
          setRetryCount(retry + 1)
          fetchDashboardData(retry + 1)
        }, 1000 * (retry + 1)) // 지수 백오프
      }
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchDashboardData()
  }, [fetchDashboardData])

  // 포맷팅 함수들
  const formatCurrency = useCallback((amount: number) => {
    if (isNaN(amount) || amount === null || amount === undefined) return '0 MSUO'
    return `${amount.toLocaleString('ko-KR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })} MSUO`
  }, [])

  const formatNumber = useCallback((num: number) => {
    if (isNaN(num) || num === null || num === undefined) return '0'
    return new Intl.NumberFormat('ko-KR').format(num)
  }, [])

  const formatDate = useCallback((dateString: string) => {
    if (!dateString) return '-'
    try {
      return new Date(dateString).toLocaleDateString('ko-KR')
    } catch {
      return '-'
    }
  }, [])

  const timeAgo = useCallback((dateString: string) => {
    if (!dateString) return '-'
    try {
      const now = new Date()
      const then = new Date(dateString)
      const diff = now.getTime() - then.getTime()
      const minutes = Math.floor(diff / (1000 * 60))
      const hours = Math.floor(diff / (1000 * 60 * 60))
      const days = Math.floor(hours / 24)
      if (days > 0) return `${days}일 전`
      if (hours > 0) return `${hours}시간 전`
      if (minutes > 0) return `${minutes}분 전`
      return '방금 전'
    } catch {
      return '-'
    }
  }, [])

  // 상태별 설정
  const withdrawalStatusConfig = useMemo(() => ({
    PENDING: {
      icon: 'payments',
      bgColor: 'bg-yellow-900/50',
      textColor: 'text-yellow-400',
      borderColor: 'border-yellow-500/50',
    },
    APPROVED: {
      icon: 'check_circle',
      bgColor: 'bg-green-900/50',
      textColor: 'text-green-400',
      borderColor: 'border-green-500/50',
    },
    REJECTED: {
      icon: 'cancel',
      bgColor: 'bg-red-900/50',
      textColor: 'text-red-400',
      borderColor: 'border-red-500/50',
    },
  }), [])

  // 로딩 스켈레톤 UI
  if (isLoading && !data) {
    return (
      <div className="flex flex-col gap-8">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div className="flex flex-col gap-1">
            <div className="h-9 w-64 bg-[#1e293b] rounded animate-pulse"></div>
            <div className="h-5 w-96 bg-[#1e293b] rounded animate-pulse mt-2"></div>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div
              key={i}
              className="flex flex-col gap-2 rounded-xl p-6 bg-[#1e293b] border border-white/10"
            >
              <div className="h-4 w-32 bg-white/10 rounded animate-pulse"></div>
              <div className="h-8 w-24 bg-white/10 rounded animate-pulse"></div>
              <div className="h-4 w-20 bg-white/10 rounded animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // 에러 상태
  if (error && !data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
        <div className="text-red-400 text-lg font-semibold">{error}</div>
        {retryCount < 3 && (
          <button
            onClick={() => fetchDashboardData(0)}
            className="px-4 py-2 bg-[#137fec] text-white rounded-lg hover:bg-[#137fec]/90 transition-colors"
          >
            다시 시도
          </button>
        )}
        {retryCount >= 3 && (
          <p className="text-gray-400 text-sm">
            여러 번 시도했지만 데이터를 불러올 수 없습니다. 페이지를 새로고침해주세요.
          </p>
        )}
      </div>
    )
  }

  if (!data) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-red-400">데이터를 불러올 수 없습니다.</div>
      </div>
    )
  }

  const { overview, rankDistribution, recentActivities, topInvestors, systemMetrics } = data

  return (
    <div className="flex flex-col gap-8">
      {/* Page Heading */}
      <div className="flex flex-wrap justify-between items-center gap-4">
        <div className="flex flex-col gap-1">
          <p className="text-white text-3xl font-bold leading-tight tracking-tight">
            Admin Dashboard
          </p>
          <p className="text-gray-400 text-sm">
            시스템 운영 {systemMetrics.daysSinceLaunch}일차
          </p>
        </div>
      </div>

      {/* 통계 카드 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* 총 사용자 */}
        <div className="flex flex-col gap-2 rounded-xl p-6 bg-[#1e293b] border border-white/10">
          <div className="flex items-center justify-between">
            <p className="text-gray-400 text-sm font-medium">{t.admin.dashboard.totalUsers}</p>
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <span className="material-symbols-outlined text-blue-400">people</span>
            </div>
          </div>
          <p className="text-white text-2xl font-bold">{formatNumber(overview.totalUsers)}</p>
          <p className="text-gray-500 text-xs">
            {language === 'ko' 
              ? `활성: ${formatNumber(overview.activeUsers)} | 오늘: +${formatNumber(overview.todayUsers)}`
              : `Active: ${formatNumber(overview.activeUsers)} | Today: +${formatNumber(overview.todayUsers)}`}
          </p>
        </div>

        {/* 총 투자 */}
        <div className="flex flex-col gap-2 rounded-xl p-6 bg-[#1e293b] border border-white/10">
          <div className="flex items-center justify-between">
            <p className="text-gray-400 text-sm font-medium">{t.admin.dashboard.totalInvestments}</p>
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <span className="material-symbols-outlined text-green-400">trending_up</span>
            </div>
          </div>
          <p className="text-white text-2xl font-bold">{formatCurrency(overview.totalInvestment)}</p>
          <p className="text-gray-500 text-xs">
            {language === 'ko'
              ? `활성: ${formatNumber(overview.activeInvestments)}건 | `
              : `Active: ${formatNumber(overview.activeInvestments)} | `}
            {overview.investmentGrowthRate >= 0 ? (
              <span className="text-green-400"> +{overview.investmentGrowthRate.toFixed(1)}%</span>
            ) : (
              <span className="text-red-400"> {overview.investmentGrowthRate.toFixed(1)}%</span>
            )}
          </p>
        </div>

        {/* 총 출금 */}
        <div className="flex flex-col gap-2 rounded-xl p-6 bg-[#1e293b] border border-white/10">
          <div className="flex items-center justify-between">
            <p className="text-gray-400 text-sm font-medium">{language === 'ko' ? '총 출금' : 'Total Withdrawals'}</p>
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <span className="material-symbols-outlined text-yellow-400">account_balance_wallet</span>
            </div>
          </div>
          <p className="text-white text-2xl font-bold">{formatCurrency(overview.totalWithdrawal)}</p>
          <p className="text-gray-500 text-xs">
            대기: {formatNumber(overview.pendingWithdrawals)} | 
            승인: {formatNumber(overview.approvedWithdrawals)}
          </p>
        </div>

        {/* 총 리워드 */}
        <div className="flex flex-col gap-2 rounded-xl p-6 bg-[#1e293b] border border-white/10">
          <div className="flex items-center justify-between">
            <p className="text-gray-400 text-sm font-medium">{t.admin.dashboard.totalRewards}</p>
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <span className="material-symbols-outlined text-purple-400">stars</span>
            </div>
          </div>
          <p className="text-white text-2xl font-bold">
            {formatCurrency(overview.totalRewards)}
          </p>
          <p className="text-gray-500 text-xs">
            이번 달: {formatCurrency(overview.monthlyRewards)} | 
            오늘: {formatCurrency(overview.todayRewards)}
          </p>
          {overview.rewardByType && overview.rewardByType.length > 0 && (
            <div className="mt-2 pt-2 border-t border-white/10">
              <p className="text-gray-400 text-xs mb-1">{language === 'ko' ? '타입별:' : 'By Type:'}</p>
              <div className="flex flex-wrap gap-2">
                {overview.rewardByType.map((r) => (
                  <span key={r.type} className="text-xs text-gray-500">
                    {r.type}: {formatCurrency(r.amount)}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 하단 섹션 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 최근 활동 */}
        <div className="flex flex-col gap-4 rounded-xl p-6 bg-[#1e293b] border border-white/10">
          <div className="flex items-center justify-between">
            <h3 className="text-white text-lg font-semibold">{t.admin.dashboard.recentActivities}</h3>
            <Link
              href="/u0-admin/users"
              className="text-[#137fec] text-sm hover:text-[#137fec]/80 transition-colors"
            >
              {language === 'ko' ? '전체 보기' : 'View All'}
            </Link>
          </div>
          <ul className="flex flex-col gap-2">
            {recentActivities.newUsers.length > 0 ? (
              recentActivities.newUsers.slice(0, 3).map((user) => (
                <li key={user.id} className="flex items-center gap-4 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                  <div className="flex-shrink-0 size-10 rounded-full bg-green-500/20 flex items-center justify-center">
                    <span className="material-symbols-outlined text-green-400">person_add</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">
                      신규 회원 <span className="font-bold">{user.username}</span> 가입
                    </p>
                    <p className="text-xs text-gray-400 truncate">
                      {timeAgo(user.createdAt)}
                    </p>
                  </div>
                </li>
              ))
            ) : (
              <li className="p-4 text-center text-gray-400 text-sm">
                최근 가입자가 없습니다.
              </li>
            )}
            {recentActivities.withdrawals.length > 0 && (
              recentActivities.withdrawals.slice(0, 2).map((withdrawal) => {
                const config =
                  withdrawalStatusConfig[
                    withdrawal.status as keyof typeof withdrawalStatusConfig
                  ] || withdrawalStatusConfig.PENDING

                return (
                  <li key={withdrawal.id} className="flex items-center gap-4 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                    <div className={`flex-shrink-0 size-10 rounded-full ${config.bgColor} flex items-center justify-center`}>
                      <span className={`material-symbols-outlined ${config.textColor}`}>
                        {config.icon}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">
                        출금 요청{' '}
                        <span className="font-bold">{formatCurrency(withdrawal.amount)}</span>{' '}
                        by <span className="font-bold">{withdrawal.users?.username || 'Unknown'}</span>
                      </p>
                      <p className="text-xs text-gray-400 truncate">
                        {timeAgo(withdrawal.requestedAt)}
                      </p>
                    </div>
                  </li>
                )
              })
            )}
          </ul>
        </div>

        {/* 상위 투자자 */}
        <div className="flex flex-col gap-4 rounded-xl p-6 bg-[#1e293b] border border-white/10">
          <div className="flex items-center justify-between">
            <h3 className="text-white text-lg font-semibold">{t.admin.dashboard.topInvestors}</h3>
            <Link
              href="/u0-admin/users"
              className="text-[#137fec] text-sm hover:text-[#137fec]/80 transition-colors"
            >
              {language === 'ko' ? '전체 보기' : 'View All'}
            </Link>
          </div>
          <ul className="flex flex-col gap-2">
            {topInvestors.length > 0 ? (
              topInvestors.map((investor, index) => (
                <li key={investor.id} className="flex items-center gap-4 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                  <div className="flex-shrink-0 size-10 rounded-full bg-gradient-to-br from-[#137fec] to-[#3A4DFF] flex items-center justify-center text-white font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">
                      {investor.username}
                    </p>
                    <p className="text-xs text-gray-400 truncate">
                      {formatCurrency(investor.totalInvestment)} |
                      추천 {investor._count.other_users_users_referrerIdTousers}명 |
                      투자 {investor._count.investments}건
                    </p>
                  </div>
                </li>
              ))
            ) : (
              <li className="p-4 text-center text-gray-400 text-sm">
                투자자가 없습니다.
              </li>
            )}
          </ul>
        </div>
      </div>

      {/* 랭크 분포 */}
      <div className="flex flex-col gap-4 rounded-xl p-6 bg-[#1e293b] border border-white/10">
        <h3 className="text-white text-lg font-semibold">{t.admin.dashboard.rankDistribution}</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[0, 1, 2, 3, 4, 5].map((rank) => {
            const rankData = rankDistribution.find((r) => r.rank === rank)
            const count = rankData?.count || 0
            const rankNames = ['신입', '1성', '2성', '3성', '4성', '5성']
            
            return (
              <div key={rank} className="flex flex-col gap-2 p-4 rounded-lg bg-white/5">
                <p className="text-gray-400 text-xs font-medium">{rankNames[rank]}</p>
                <p className="text-white text-xl font-bold">{formatNumber(count)}</p>
                <p className="text-gray-500 text-xs">
                  {overview.totalUsers > 0 
                    ? ((count / overview.totalUsers) * 100).toFixed(1) 
                    : '0'}%
                </p>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
