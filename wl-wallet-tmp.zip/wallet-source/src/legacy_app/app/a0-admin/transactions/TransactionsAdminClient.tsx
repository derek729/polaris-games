'use client'

import { useEffect, useState, useCallback } from 'react'
import { useI18n } from '@/lib/i18n/context'

interface Transaction {
  id: string
  type: 'reward' | 'withdrawal' | 'transfer' | 'investment'
  typeLabel: string
  amount: number
  description: string
  user?: {
    id: string
    username: string
    email: string
  }
  sender?: {
    id: string
    username: string
    email: string
  }
  receiver?: {
    id: string
    username: string
    email: string
  }
  status?: string
  address?: string
  rewardType?: string
  dailyRate?: number
  isActive?: boolean
  txHash?: string
  networkType?: string
  createdAt: string
}

interface TransactionsResponse {
  ok: boolean
  data: {
    transactions: Transaction[]
    pagination: {
      currentPage: number
      totalPages: number
      totalCount: number
      limit: number
      hasNext: boolean
      hasPrev: boolean
    }
    stats: {
      total: number
      totalRewards: number
      totalWithdrawals: number
      totalTransfers: number
      totalInvestments: number
    }
  }
}

export default function TransactionsAdminClient() {
  const { t } = useI18n()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalCount: 0,
    limit: 20,
    hasNext: false,
    hasPrev: false,
  })
  const [stats, setStats] = useState({
    total: 0,
    totalRewards: 0,
    totalWithdrawals: 0,
    totalTransfers: 0,
    totalInvestments: 0,
  })

  // 필터링 상태
  const [filters, setFilters] = useState({
    type: 'all',
    period: '30',
    userId: '',
  })

  const fetchTransactions = useCallback(async () => {
    try {
      setIsLoading(true)
      const params = new URLSearchParams({
        page: pagination.currentPage.toString(),
        limit: pagination.limit.toString(),
        type: filters.type,
        period: filters.period,
        ...(filters.userId && { userId: filters.userId }),
      })

      const response = await fetch(`/api/admin/transactions?${params}`)
      if (response.ok) {
        const data: TransactionsResponse = await response.json()
        setTransactions(data.data.transactions)
        setPagination(data.data.pagination)
        setStats(data.data.stats)
      }
    } catch (error) {
      console.error('거래 내역 조회 실패:', error)
    } finally {
      setIsLoading(false)
    }
  }, [pagination.currentPage, filters])

  useEffect(() => {
    fetchTransactions()
  }, [fetchTransactions])

  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString('ko-KR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })} AOT`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(num)
  }

  const getTypeBadge = (type: string) => {
    const configs = {
      reward_logs: { label: t.admin.transactions.reward, className: 'bg-purple-500/20 text-purple-400 border-purple-500/50' },
      withdrawal: { label: t.admin.transactions.withdrawal, className: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50' },
      transfers: { label: t.admin.transactions.transfer, className: 'bg-blue-500/20 text-blue-400 border-blue-500/50' },
      investments: { label: t.admin.transactions.investment, className: 'bg-green-500/20 text-green-400 border-green-500/50' },
    }
    const config = configs[type as keyof typeof configs] || configs.reward
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    )
  }

  const getStatusBadge = (status: string) => {
    const configs = {
      PENDING: { label: t.status.pending, className: 'bg-yellow-500/20 text-yellow-400' },
      APPROVED: { label: t.status.approved, className: 'bg-green-500/20 text-green-400' },
      REJECTED: { label: t.status.rejected, className: 'bg-red-500/20 text-red-400' },
    }
    const config = configs[status as keyof typeof configs] || configs.PENDING
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.className}`}>
        {config.label}
      </span>
    )
  }

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination(prev => ({ ...prev, currentPage: newPage }))
    }
  }

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }))
    setPagination(prev => ({ ...prev, currentPage: 1 }))
  }

  if (isLoading && transactions.length === 0) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-[#1e293b] rounded w-48 mb-6"></div>
          <div className="bg-[#1e293b] rounded-lg border border-white/10 overflow-hidden">
            <div className="h-16 bg-white/5"></div>
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-16 bg-white/5 border-t border-white/10"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div>
        <h1 className="text-2xl font-bold text-white">{t.admin.transactions.title}</h1>
        <p className="text-gray-400 mt-1">{t.admin.transactions.totalCount} {formatNumber(stats.total)}{t.admin.transactions.total}</p>
      </div>

      {/* 통계 카드 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="flex flex-col gap-2 rounded-xl p-4 bg-[#1e293b] border border-white/10">
          <p className="text-gray-400 text-sm font-medium">{t.admin.transactions.stats.totalRewards}</p>
          <p className="text-white text-xl font-bold">{formatCurrency(stats.totalRewards)}</p>
        </div>
        <div className="flex flex-col gap-2 rounded-xl p-4 bg-[#1e293b] border border-white/10">
          <p className="text-gray-400 text-sm font-medium">{t.admin.transactions.stats.totalWithdrawals}</p>
          <p className="text-white text-xl font-bold">{formatCurrency(stats.totalWithdrawals)}</p>
        </div>
        <div className="flex flex-col gap-2 rounded-xl p-4 bg-[#1e293b] border border-white/10">
          <p className="text-gray-400 text-sm font-medium">{t.admin.transactions.stats.totalTransfers}</p>
          <p className="text-white text-xl font-bold">{formatCurrency(stats.totalTransfers)}</p>
        </div>
        <div className="flex flex-col gap-2 rounded-xl p-4 bg-[#1e293b] border border-white/10">
          <p className="text-gray-400 text-sm font-medium">{t.admin.transactions.stats.totalInvestments}</p>
          <p className="text-white text-xl font-bold">{formatCurrency(stats.totalInvestments)}</p>
        </div>
      </div>

      {/* 검색 및 필터 */}
      <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.transactions.type}</label>
            <select
              value={filters.type}
              onChange={(e) => handleFilterChange('type', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="all">{t.admin.transactions.all}</option>
              <option value="reward">{t.admin.transactions.reward}</option>
              <option value="withdrawal">{t.admin.transactions.withdrawal}</option>
              <option value="transfer">{t.admin.transactions.transfer}</option>
              <option value="investment">{t.admin.transactions.investment}</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.transactions.period}</label>
            <select
              value={filters.period}
              onChange={(e) => handleFilterChange('period', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="7">{t.admin.transactions.period7Days}</option>
              <option value="30">{t.admin.transactions.period30Days}</option>
              <option value="90">{t.admin.transactions.period90Days}</option>
              <option value="all">{t.admin.transactions.periodAll}</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.transactions.userIdFilter}</label>
            <input
              type="text"
              value={filters.userId}
              onChange={(e) => handleFilterChange('userId', e.target.value)}
              placeholder={t.admin.transactions.userIdPlaceholder}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* 거래 내역 테이블 */}
      <div className="bg-[#1e293b] shadow-sm border border-white/10 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-white/10">
            <thead className="bg-white/5">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.transactions.transactionInfo}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.transactions.users}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.transactions.amount}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.transactions.status}
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.transactions.time}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {transactions.map((transaction) => (
                <tr key={transaction.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      {getTypeBadge(transaction.type)}
                      <div>
                        <div className="text-sm font-medium text-white">{transaction.description ? transaction.description.replace(/USDT/g, 'AOT') : '-'}</div>
                        {transaction.txHash && (
                          <div className="text-xs text-gray-400 truncate max-w-[200px]">
                            TX: {transaction.txHash.slice(0, 10)}...
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {transaction.users ? (
                      <div>
                        <div className="text-sm font-medium text-white">{transaction.users.username}</div>
                        <div className="text-xs text-gray-400">{transaction.users.email}</div>
                      </div>
                    ) : transaction.sender && transaction.receiver ? (
                      <div>
                        <div className="text-sm font-medium text-white">
                          {transaction.users.username} → {transaction.users.username}
                        </div>
                        <div className="text-xs text-gray-400">
                          {transaction.users.email} → {transaction.users.email}
                        </div>
                      </div>
                    ) : (
                      <span className="text-gray-400 text-sm">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                    {formatCurrency(transaction.amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {transaction.status ? getStatusBadge(transaction.status) : (
                      <span className="text-gray-400 text-sm">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {formatDate(transaction.createdAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {transactions.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-400">{t.admin.transactions.noTransactions}</p>
          </div>
        )}
      </div>

      {/* 페이지네이션 */}
      {pagination.totalPages > 1 && (
        <div className="flex items-center justify-between bg-[#1e293b] px-6 py-3 rounded-lg border border-white/10">
          <div className="flex-1 flex justify-between sm:hidden">
            <button
              onClick={() => handlePageChange(pagination.currentPage - 1)}
              disabled={!pagination.hasPrev}
              className="relative inline-flex items-center px-4 py-2 border border-white/10 text-sm font-medium rounded-md text-white bg-white/5 hover:bg-white/10 disabled:opacity-50"
            >
              {t.admin.transactions.previous}
            </button>
            <button
              onClick={() => handlePageChange(pagination.currentPage + 1)}
              disabled={!pagination.hasNext}
              className="ml-3 relative inline-flex items-center px-4 py-2 border border-white/10 text-sm font-medium rounded-md text-white bg-white/5 hover:bg-white/10 disabled:opacity-50"
            >
              {t.admin.transactions.next}
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-300">
                <span className="font-medium">
                  {(pagination.currentPage - 1) * pagination.limit + 1}
                </span>
                {' '}
                {t.admin.transactions.from}{' '}
                <span className="font-medium">
                  {Math.min(pagination.currentPage * pagination.limit, pagination.totalCount)}
                </span>
                {' '}
                {t.admin.transactions.to} / {t.admin.transactions.total}{' '}
                <span className="font-medium">{formatNumber(pagination.totalCount)}</span>
              </p>
            </div>
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                <button
                  onClick={() => handlePageChange(pagination.currentPage - 1)}
                  disabled={!pagination.hasPrev}
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-white/10 bg-white/5 text-sm font-medium text-white hover:bg-white/10 disabled:opacity-50"
                >
                  {t.admin.transactions.previous}
                </button>

                {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                  let pageNum
                  if (pagination.totalPages <= 5) {
                    pageNum = i + 1
                  } else if (pagination.currentPage <= 3) {
                    pageNum = i + 1
                  } else if (pagination.currentPage >= pagination.totalPages - 2) {
                    pageNum = pagination.totalPages - 4 + i
                  } else {
                    pageNum = pagination.currentPage - 2 + i
                  }

                  return (
                    <button
                      key={pageNum}
                      onClick={() => handlePageChange(pageNum)}
                      className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                        pageNum === pagination.currentPage
                          ? 'z-10 bg-[#137fec]/20 border-[#137fec] text-[#137fec]'
                          : 'bg-white/5 border-white/10 text-white hover:bg-white/10'
                      }`}
                    >
                      {pageNum}
                    </button>
                  )
                })}

                <button
                  onClick={() => handlePageChange(pagination.currentPage + 1)}
                  disabled={!pagination.hasNext}
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-white/10 bg-white/5 text-sm font-medium text-white hover:bg-white/10 disabled:opacity-50"
                >
                  {t.admin.transactions.next}
                </button>
              </nav>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

