'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';
import { Play, RefreshCw, Calendar, TrendingUp, Users, Award, DollarSign, Power, PowerOff, CheckCircle, AlertCircle, Clock } from 'lucide-react';

interface CloseStats {
  type: string;
  count: number;
  totalAmount: number;
}

interface CloseDetail {
  id: string;
  type: string;
  amount: number;
  description: string | null;
  createdAt: string;
  users: {
    id: string;
    username: string | null;
    email: string | null;
  };
}

interface CloseHistory {
  date: string;
  stats: CloseStats[];
  details: CloseDetail[];
}

export default function RewardsClosePage() {
  const { t, language } = useI18n();
  const [isClosing, setIsClosing] = useState(false);
  const [closeType, setCloseType] = useState<'all' | 'daily' | 'leadership'>('all');
  const [history, setHistory] = useState<CloseHistory | null>(null);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [closeDate, setCloseDate] = useState<string>(''); // 마감 실행 날짜 (빈 값이면 오늘)
  const [lastCloseResult, setLastCloseResult] = useState<any>(null);
  const [autoModeEnabled, setAutoModeEnabled] = useState(false);
  const [isTogglingAutoMode, setIsTogglingAutoMode] = useState(false);
  const [yesterdayCheck, setYesterdayCheck] = useState<any>(null);
  const [isCheckingYesterday, setIsCheckingYesterday] = useState(false);
  const [dailyRewardsCheck, setDailyRewardsCheck] = useState<any>(null);
  const [isCheckingDailyRewards, setIsCheckingDailyRewards] = useState(false);
  const [schedulerStatus, setSchedulerStatus] = useState<any>(null);
  const [isCheckingScheduler, setIsCheckingScheduler] = useState(false);
  const [isRestartingScheduler, setIsRestartingScheduler] = useState(false);
  const [cleanupDate, setCleanupDate] = useState('2025-12-12');
  const [isCleaningUp, setIsCleaningUp] = useState(false);
  const [cleanupResult, setCleanupResult] = useState<any>(null);

  // 마감 내역 로드
  const loadHistory = async (date?: string) => {
    setIsLoadingHistory(true);
    try {
      const dateParam = date || selectedDate;
      const response = await fetch(`/api/admin/rewards/close?date=${dateParam}`, {
        credentials: 'include',
      });
      const result = await response.json();
      if (result.ok) {
        setHistory(result.data);
      }
    } catch (error) {
      console.error('마감 내역 로드 실패:', error);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  // 마감 실행
  const handleClose = async () => {
    if (isClosing) return;

    const targetDate = closeDate || new Date().toISOString().split('T')[0];
    const confirmMessage = closeDate
      ? language === 'ko'
        ? `${targetDate} 날짜의 미지급 수당을 지급하시겠습니까?`
        : `Do you want to pay unpaid rewards for ${targetDate}?`
      : language === 'ko'
      ? '마감을 실행하시겠습니까?'
      : 'Do you want to execute the closing?';

    if (!confirm(confirmMessage)) {
      return;
    }

    setIsClosing(true);
    try {
      const response = await fetch('/api/admin/rewards/close', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ 
          type: closeType,
          date: closeDate || undefined, // 날짜 지정 (빈 값이면 오늘)
        }),
      });

      const result = await response.json();

      if (result.ok) {
        setLastCloseResult(result.data);
        alert(`${language === 'ko' ? '✅ 마감 처리가 완료되었습니다!' : '✅ Closing process completed!'}`);
        // 마감 내역 새로고침
        loadHistory();
      } else {
        alert(`❌ ${result.error || (language === 'ko' ? '마감 처리 실패' : 'Closing failed')}`);
      }
    } catch (error) {
      console.error('마감 실행 실패:', error);
      alert(`❌ ${language === 'ko' ? '마감 처리 중 오류가 발생했습니다.' : 'An error occurred during closing.'}`);
    } finally {
      setIsClosing(false);
    }
  };

  // 자동 모드 상태 로드
  const loadAutoModeStatus = async () => {
    try {
      const response = await fetch('/api/admin/rewards/close/auto', {
        credentials: 'include',
      });
      const result = await response.json();
      if (result.ok) {
        setAutoModeEnabled(result.data.enabled);
      }
    } catch (error) {
      console.error('자동 모드 상태 로드 실패:', error);
    }
  };

  // 자동 모드 토글
  const handleToggleAutoMode = async () => {
    if (isTogglingAutoMode) return;

    const newState = !autoModeEnabled;
    const confirmMessage = newState
      ? language === 'ko'
        ? '자동 모드를 활성화하시겠습니까?\n매일 자정에 자동으로 전체 마감이 실행됩니다.'
        : 'Do you want to enable auto mode?\nFull settlement will run automatically at midnight every day.'
      : language === 'ko'
      ? '자동 모드를 비활성화하시겠습니까?'
      : 'Do you want to disable auto mode?';

    if (!confirm(confirmMessage)) {
      return;
    }

    setIsTogglingAutoMode(true);
    try {
      const response = await fetch('/api/admin/rewards/close/auto', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ enabled: newState }),
      });

      const result = await response.json();

      if (result.ok) {
        setAutoModeEnabled(newState);
        alert(
          newState
            ? language === 'ko'
              ? '✅ 자동 모드가 활성화되었습니다.\n매일 자정에 자동으로 마감이 실행됩니다.'
              : '✅ Auto mode has been enabled.\nSettlement will run automatically at midnight every day.'
            : language === 'ko'
            ? '✅ 자동 모드가 비활성화되었습니다.'
            : '✅ Auto mode has been disabled.'
        );
      } else {
        alert(`❌ ${result.error || (language === 'ko' ? '자동 모드 설정 실패' : 'Failed to set auto mode')}`);
      }
    } catch (error) {
      console.error('자동 모드 토글 실패:', error);
      alert(`❌ ${language === 'ko' ? '자동 모드 설정 중 오류가 발생했습니다.' : 'An error occurred while setting auto mode.'}`);
    } finally {
      setIsTogglingAutoMode(false);
    }
  };

  // 어제 마감 확인
  const checkYesterdaySettlement = async () => {
    setIsCheckingYesterday(true);
    try {
      const response = await fetch('/api/admin/rewards/close/check-yesterday', {
        credentials: 'include',
      });
      const result = await response.json();
      if (result.ok) {
        setYesterdayCheck(result.data);
      } else {
        alert(`❌ ${result.error || (language === 'ko' ? '확인 실패' : 'Check failed')}`);
      }
    } catch (error) {
      console.error('어제 마감 확인 실패:', error);
      alert(`❌ ${language === 'ko' ? '확인 중 오류가 발생했습니다.' : 'An error occurred during check.'}`);
    } finally {
      setIsCheckingYesterday(false);
    }
  };

  // 일일 수익 지급 상태 확인
  const checkDailyRewards = async () => {
    setIsCheckingDailyRewards(true);
    try {
      const response = await fetch('/api/admin/rewards/check-daily', {
        credentials: 'include',
      });
      const result = await response.json();
      if (result.ok) {
        setDailyRewardsCheck(result.data);
      } else {
        alert(`❌ ${result.error || (language === 'ko' ? '확인 실패' : 'Check failed')}`);
      }
    } catch (error) {
      console.error('일일 수익 확인 실패:', error);
      alert(`❌ ${language === 'ko' ? '확인 중 오류가 발생했습니다.' : 'An error occurred during check.'}`);
    } finally {
      setIsCheckingDailyRewards(false);
    }
  };


  // 원본 AO 코인 지급 내역 정리
  const cleanupAOCoinRewards = async (dryRun: boolean = true) => {
    if (!cleanupDate) {
      alert(language === 'ko' ? '날짜를 입력해주세요.' : 'Please enter a date.');
      return;
    }

    setIsCleaningUp(true);
    try {
      const response = await fetch('/api/admin/rewards/cleanup-ao-coin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          targetDate: cleanupDate,
          dryRun,
        }),
      });
      const result = await response.json();
      if (result.ok) {
        setCleanupResult(result.data);
        if (!dryRun) {
          alert(
            language === 'ko'
              ? `정리 완료: ${result.data.deletedCount}건 삭제됨`
              : `Cleanup complete: ${result.data.deletedCount} items deleted`
          );
        }
      } else {
        alert(`❌ ${result.error || (language === 'ko' ? '정리 실패' : 'Cleanup failed')}`);
      }
    } catch (error) {
      console.error('원본 AO 코인 정리 실패:', error);
      alert(`❌ ${language === 'ko' ? '정리 중 오류가 발생했습니다.' : 'An error occurred during cleanup.'}`);
    } finally {
      setIsCleaningUp(false);
    }
  };

  // 스케줄러 상태 확인
  const checkSchedulerStatus = async () => {
    setIsCheckingScheduler(true);
    try {
      const response = await fetch('/api/admin/scheduler/status', {
        credentials: 'include',
      });
      const result = await response.json();
      if (result.ok) {
        setSchedulerStatus(result.data);
      } else {
        alert(`❌ ${result.error || (language === 'ko' ? '스케줄러 상태 확인 실패' : 'Failed to check scheduler status')}`);
      }
    } catch (error) {
      console.error('스케줄러 상태 확인 실패:', error);
      alert(`❌ ${language === 'ko' ? '스케줄러 상태 확인 중 오류가 발생했습니다.' : 'An error occurred while checking scheduler status.'}`);
    } finally {
      setIsCheckingScheduler(false);
    }
  };

  // 스케줄러 재시작
  const handleRestartScheduler = async () => {
    if (isRestartingScheduler) return;

    const confirmMessage =
      language === 'ko'
        ? '스케줄러를 재시작하시겠습니까?'
        : 'Do you want to restart the scheduler?';

    if (!confirm(confirmMessage)) {
      return;
    }

    setIsRestartingScheduler(true);
    try {
      const response = await fetch('/api/admin/start-scheduler', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ restart: true }),
      });

      const result = await response.json();

      if (result.ok) {
        alert(`✅ ${result.message || (language === 'ko' ? '스케줄러가 재시작되었습니다.' : 'Scheduler restarted.')}`);
        checkSchedulerStatus();
      } else {
        alert(`❌ ${result.message || (language === 'ko' ? '스케줄러 재시작 실패' : 'Failed to restart scheduler')}`);
      }
    } catch (error) {
      console.error('스케줄러 재시작 실패:', error);
      alert(`❌ ${language === 'ko' ? '스케줄러 재시작 중 오류가 발생했습니다.' : 'An error occurred while restarting the scheduler.'}`);
    } finally {
      setIsRestartingScheduler(false);
    }
  };

  useEffect(() => {
    loadHistory();
    loadAutoModeStatus();
    checkYesterdaySettlement(); // 페이지 로드 시 자동 확인
    checkDailyRewards(); // 페이지 로드 시 자동 확인
    checkSchedulerStatus(); // 페이지 로드 시 스케줄러 상태 확인
  }, []);

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      DAILY: language === 'ko' ? '일일 수익' : 'Daily Reward',
      MATCHING: language === 'ko' ? '매칭 보너스' : 'Matching Bonus',
      LEADERSHIP: language === 'ko' ? '리더십 보너스' : 'Leadership Bonus',
      RANK: language === 'ko' ? '랭크 보상' : 'Rank Reward',
      REFERRAL: language === 'ko' ? '추천 보너스' : 'Referral Bonus',
    };
    return labels[type] || type;
  };

  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString('ko-KR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })} AOT`;
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(num);
  };

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div>
        <h1 className="text-2xl font-bold text-white">
          {language === 'ko' ? '수당 마감 관리' : 'Reward Closing Management'}
        </h1>
        <p className="text-gray-400 mt-1">
          {language === 'ko'
            ? '수당 지급을 수동으로 실행하고 마감 내역을 확인할 수 있습니다.'
            : 'Manually execute reward payments and view closing history.'}
        </p>
      </div>

      {/* 스케줄러 상태 카드 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {language === 'ko' ? '스케줄러 상태' : 'Scheduler Status'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko'
                ? '자동 마감 스케줄러의 실행 상태를 확인하고 재시작할 수 있습니다.'
                : 'Check the status of the automatic settlement scheduler and restart if needed.'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={checkSchedulerStatus}
              disabled={isCheckingScheduler}
              className="flex items-center gap-2 px-4 py-2 bg-[#137fec]/20 border border-[#137fec] text-[#137fec] rounded-lg font-medium hover:bg-[#137fec]/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isCheckingScheduler ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>{language === 'ko' ? '확인 중...' : 'Checking...'}</span>
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4" />
                  <span>{language === 'ko' ? '상태 확인' : 'Check Status'}</span>
                </>
              )}
            </button>
            <button
              onClick={handleRestartScheduler}
              disabled={isRestartingScheduler}
              className="flex items-center gap-2 px-4 py-2 bg-orange-500/20 border border-orange-500 text-orange-400 rounded-lg font-medium hover:bg-orange-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isRestartingScheduler ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>{language === 'ko' ? '재시작 중...' : 'Restarting...'}</span>
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4" />
                  <span>{language === 'ko' ? '재시작' : 'Restart'}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {schedulerStatus && (
          <div className="space-y-3">
            <div className={`p-4 rounded-lg border ${
              schedulerStatus.schedulerStarted
                ? 'bg-green-500/10 border-green-500/30'
                : 'bg-red-500/10 border-red-500/30'
            }`}>
              <div className="flex items-center gap-2 mb-2">
                {schedulerStatus.schedulerStarted ? (
                  <CheckCircle className="h-4 w-4 text-green-400" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-400" />
                )}
                <span className={`text-sm font-medium ${
                  schedulerStatus.schedulerStarted ? 'text-green-400' : 'text-red-400'
                }`}>
                  {language === 'ko' ? '스케줄러 상태' : 'Scheduler Status'}
                </span>
              </div>
              <p className={`text-sm ${
                schedulerStatus.schedulerStarted ? 'text-green-400' : 'text-red-400'
              }`}>
                {schedulerStatus.schedulerStarted
                  ? language === 'ko'
                    ? '✅ 실행 중'
                    : '✅ Running'
                  : language === 'ko'
                  ? '❌ 중지됨'
                  : '❌ Stopped'}
              </p>
            </div>

            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <p className="text-sm font-medium text-white mb-2">
                {language === 'ko' ? '작업 상태' : 'Task Status'}
              </p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">{language === 'ko' ? '일일 리워드' : 'Daily Reward'}:</span>
                  <span className={schedulerStatus.tasks.dailyReward ? 'text-green-400' : 'text-red-400'}>
                    {schedulerStatus.tasks.dailyReward ? '✅' : '❌'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">{language === 'ko' ? '자동 마감' : 'Auto Settlement'}:</span>
                  <span className={schedulerStatus.tasks.autoSettlement ? 'text-green-400' : 'text-red-400'}>
                    {schedulerStatus.tasks.autoSettlement ? '✅' : '❌'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">{language === 'ko' ? '게임 수익 (일)' : 'Game Revenue (Daily)'}:</span>
                  <span className={schedulerStatus.tasks.gameRevenueDaily ? 'text-green-400' : 'text-red-400'}>
                    {schedulerStatus.tasks.gameRevenueDaily ? '✅' : '❌'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">{language === 'ko' ? '게임 수익 (주)' : 'Game Revenue (Weekly)'}:</span>
                  <span className={schedulerStatus.tasks.gameRevenueWeekly ? 'text-green-400' : 'text-red-400'}>
                    {schedulerStatus.tasks.gameRevenueWeekly ? '✅' : '❌'}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <p className="text-sm font-medium text-white mb-1">
                {language === 'ko' ? '타임존' : 'Timezone'}
              </p>
              <p className="text-xs text-gray-400">{schedulerStatus.timezone}</p>
            </div>
          </div>
        )}
      </div>

      {/* 자동 모드 카드 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {language === 'ko' ? '자동 모드' : 'Auto Mode'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko'
                ? '자동 모드를 활성화하면 매일 자정에 전체 마감이 자동으로 실행됩니다.'
                : 'When enabled, full settlement will run automatically at midnight every day.'}
            </p>
          </div>
          <button
            onClick={handleToggleAutoMode}
            disabled={isTogglingAutoMode}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
              autoModeEnabled
                ? 'bg-red-500/20 border border-red-500 text-red-400 hover:bg-red-500/30'
                : 'bg-green-500/20 border border-green-500 text-green-400 hover:bg-green-500/30'
            }`}
          >
            {isTogglingAutoMode ? (
              <>
                <RefreshCw className="h-5 w-5 animate-spin" />
                <span>{language === 'ko' ? '처리 중...' : 'Processing...'}</span>
              </>
            ) : autoModeEnabled ? (
              <>
                <PowerOff className="h-5 w-5" />
                <span>{language === 'ko' ? '자동 모드 중지' : 'Stop Auto Mode'}</span>
              </>
            ) : (
              <>
                <Power className="h-5 w-5" />
                <span>{language === 'ko' ? '자동 모드 시작' : 'Start Auto Mode'}</span>
              </>
            )}
          </button>
        </div>
        {autoModeEnabled && (
          <div className="mt-4 p-4 bg-green-500/10 rounded-lg border border-green-500/30">
            <div className="flex items-center gap-2 text-green-400">
              <Power className="h-4 w-4" />
              <span className="text-sm font-medium">
                {language === 'ko'
                  ? '자동 모드가 활성화되어 있습니다. 매일 자정에 자동으로 마감이 실행됩니다.'
                  : 'Auto mode is enabled. Settlement will run automatically at midnight every day.'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* 어제 마감 확인 카드 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {language === 'ko' ? '어제 마감 확인' : 'Yesterday Settlement Check'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko'
                ? '어제 자동 마감이 정상적으로 실행되었는지 확인합니다.'
                : 'Check if yesterday\'s automatic settlement ran successfully.'}
            </p>
          </div>
          <button
            onClick={checkYesterdaySettlement}
            disabled={isCheckingYesterday}
            className="flex items-center gap-2 px-4 py-2 bg-[#137fec]/20 border border-[#137fec] text-[#137fec] rounded-lg font-medium hover:bg-[#137fec]/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isCheckingYesterday ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>{language === 'ko' ? '확인 중...' : 'Checking...'}</span>
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4" />
                <span>{language === 'ko' ? '확인' : 'Check'}</span>
              </>
            )}
          </button>
        </div>

        {yesterdayCheck && (
          <div className="space-y-4">
            {/* 자동 모드 상태 */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <div className="flex items-center gap-2 mb-2">
                <Power className={`h-4 w-4 ${yesterdayCheck.autoMode.enabled ? 'text-green-400' : 'text-red-400'}`} />
                <span className="text-sm font-medium text-white">
                  {language === 'ko' ? '자동 모드 상태' : 'Auto Mode Status'}
                </span>
              </div>
              <p className={`text-sm ${yesterdayCheck.autoMode.enabled ? 'text-green-400' : 'text-red-400'}`}>
                {yesterdayCheck.autoMode.enabled
                  ? language === 'ko'
                    ? '✅ 활성화됨'
                    : '✅ Enabled'
                  : language === 'ko'
                  ? '❌ 비활성화됨'
                  : '❌ Disabled'}
              </p>
            </div>

            {/* 어제 마감 결과 */}
            <div className={`p-4 rounded-lg border ${
              yesterdayCheck.conclusion.wasExecuted
                ? 'bg-green-500/10 border-green-500/30'
                : 'bg-red-500/10 border-red-500/30'
            }`}>
              <div className="flex items-start gap-3">
                {yesterdayCheck.conclusion.wasExecuted ? (
                  <CheckCircle className="h-5 w-5 text-green-400 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-red-400 mt-0.5" />
                )}
                <div className="flex-1">
                  <p className={`font-medium mb-1 ${
                    yesterdayCheck.conclusion.wasExecuted ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {language === 'ko' ? `확인 날짜: ${yesterdayCheck.checkDate}` : `Check Date: ${yesterdayCheck.checkDate}`}
                  </p>
                  <p className="text-sm text-white mb-2">
                    {yesterdayCheck.conclusion.message}
                  </p>
                  {yesterdayCheck.yesterday.totalCount > 0 && (
                    <div className="mt-2 space-y-1">
                      <p className="text-xs text-gray-400">
                        {language === 'ko' 
                          ? `총 ${yesterdayCheck.yesterday.totalCount}건, ${yesterdayCheck.yesterday.totalAmount.toFixed(2)} AOT 지급`
                          : `Total ${yesterdayCheck.yesterday.totalCount} items, ${yesterdayCheck.yesterday.totalAmount.toFixed(2)} AOT paid`}
                      </p>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {yesterdayCheck.yesterday.stats.map((stat: any) => (
                          <span key={stat.type} className="text-xs px-2 py-1 bg-white/10 rounded text-gray-300">
                            {stat.typeName}: {stat.count}건 ({stat.totalAmount.toFixed(2)} AOT)
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* 권장 사항 */}
            {yesterdayCheck.conclusion.recommendations.length > 0 && (
              <div className="p-4 bg-yellow-500/10 rounded-lg border border-yellow-500/30">
                <div className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 text-yellow-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-yellow-400 mb-2">
                      {language === 'ko' ? '권장 사항' : 'Recommendations'}
                    </p>
                    <ul className="text-xs text-gray-300 space-y-1">
                      {yesterdayCheck.conclusion.recommendations.map((rec: string, index: number) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-yellow-400">•</span>
                          <span>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* 최근 3일 비교 */}
            {yesterdayCheck.recentDays && yesterdayCheck.recentDays.length > 0 && (
              <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                <p className="text-sm font-medium text-white mb-3">
                  {language === 'ko' ? '최근 3일간 마감 내역' : 'Recent 3 Days Settlement'}
                </p>
                <div className="space-y-2">
                  {yesterdayCheck.recentDays.map((day: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-white/5 rounded">
                      <div className="flex items-center gap-2">
                        <Clock className="h-3 w-3 text-gray-400" />
                        <span className="text-xs text-gray-300">
                          {day.daysAgo === 0
                            ? language === 'ko' ? '오늘' : 'Today'
                            : day.daysAgo === 1
                            ? language === 'ko' ? '어제' : 'Yesterday'
                            : language === 'ko'
                            ? `${day.daysAgo}일 전`
                            : `${day.daysAgo} days ago`}
                        </span>
                        <span className="text-xs text-gray-500">({day.date})</span>
                      </div>
                      <div className="text-xs text-white">
                        {day.totalCount}건, {day.totalAmount.toFixed(2)} AOT
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 일일 수익 지급 상태 확인 카드 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {language === 'ko' ? '일일 수익 지급 상태' : 'Daily Rewards Status'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko'
                ? '일일 수익 지급이 정상적으로 작동하는지 확인합니다.'
                : 'Check if daily rewards are being paid correctly.'}
            </p>
          </div>
          <button
            onClick={checkDailyRewards}
            disabled={isCheckingDailyRewards}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isCheckingDailyRewards ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>{language === 'ko' ? '확인 중...' : 'Checking...'}</span>
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4" />
                <span>{language === 'ko' ? '확인' : 'Check'}</span>
              </>
            )}
          </button>
        </div>
        {dailyRewardsCheck && (
          <div className="mt-4 p-4 bg-white/5 rounded-lg border border-white/10">
            <div className="text-sm text-white">
              {language === 'ko' ? '확인 결과' : 'Check Result'}: {dailyRewardsCheck.totalCount || 0}건
            </div>
          </div>
        )}
      </div>

      {/* 일일 수익 지급 상태 카드 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {language === 'ko' ? '일일 수익 지급 상태' : 'Daily Reward Payment Status'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko'
                ? '일일 수익 지급이 정상적으로 작동하는지 확인합니다.'
                : 'Check if daily reward payments are working normally.'}
            </p>
          </div>
          <button
            onClick={checkDailyRewards}
            disabled={isCheckingDailyRewards}
            className="flex items-center gap-2 px-4 py-2 bg-[#137fec]/20 border border-[#137fec] text-[#137fec] rounded-lg font-medium hover:bg-[#137fec]/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isCheckingDailyRewards ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>{language === 'ko' ? '확인 중...' : 'Checking...'}</span>
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4" />
                <span>{language === 'ko' ? '상태 확인' : 'Check Status'}</span>
              </>
            )}
          </button>
        </div>

        {dailyRewardsCheck && (
          <div className="space-y-4">
            {/* 활성 투자 건 */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-blue-400" />
                <span className="text-sm font-medium text-white">
                  {language === 'ko' ? '활성 투자 건' : 'Active Investments'}
                </span>
              </div>
              <p className="text-sm text-gray-300">
                {language === 'ko'
                  ? `총 ${dailyRewardsCheck.activeInvestments.count}건, 총 투자금: $${dailyRewardsCheck.activeInvestments.totalAmount.toFixed(2)}`
                  : `Total ${dailyRewardsCheck.activeInvestments.count} investments, Total amount: $${dailyRewardsCheck.activeInvestments.totalAmount.toFixed(2)}`}
              </p>
              <p className="text-xs text-gray-400 mt-1">
                {language === 'ko'
                  ? `예상 일일 수익: $${dailyRewardsCheck.activeInvestments.expectedDailyTotal.toFixed(2)}`
                  : `Expected daily profit: $${dailyRewardsCheck.activeInvestments.expectedDailyTotal.toFixed(2)}`}
              </p>
            </div>

            {/* 오늘 지급 내역 */}
            <div className={`p-4 rounded-lg border ${
              dailyRewardsCheck.today.count > 0
                ? 'bg-green-500/10 border-green-500/30'
                : 'bg-red-500/10 border-red-500/30'
            }`}>
              <div className="flex items-start gap-3">
                {dailyRewardsCheck.today.count > 0 ? (
                  <CheckCircle className="h-5 w-5 text-green-400 mt-0.5" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-red-400 mt-0.5" />
                )}
                <div className="flex-1">
                  <p className={`font-medium mb-1 ${
                    dailyRewardsCheck.today.count > 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {language === 'ko' ? '오늘 지급 내역' : 'Today Payments'}
                  </p>
                  <p className="text-sm text-white">
                    {dailyRewardsCheck.today.count > 0
                      ? language === 'ko'
                        ? `✅ ${dailyRewardsCheck.today.count}건 지급됨, 총 $${dailyRewardsCheck.today.totalAmount.toFixed(2)}`
                        : `✅ ${dailyRewardsCheck.today.count} payments, Total $${dailyRewardsCheck.today.totalAmount.toFixed(2)}`
                      : language === 'ko'
                      ? '❌ 오늘 일일 수익이 지급되지 않았습니다.'
                      : '❌ No daily rewards paid today.'}
                  </p>
                </div>
              </div>
            </div>

            {/* 지급되지 않은 투자 건 */}
            {dailyRewardsCheck.unpaidInvestments.count > 0 && (
              <div className="p-4 bg-yellow-500/10 rounded-lg border border-yellow-500/30">
                <div className="flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 text-yellow-400 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-yellow-400 mb-2">
                      {language === 'ko' ? '지급되지 않은 투자 건' : 'Unpaid Investments'}
                    </p>
                    <p className="text-xs text-gray-300 mb-2">
                      {language === 'ko'
                        ? `${dailyRewardsCheck.unpaidInvestments.count}건의 투자에 대해 일일 수익이 지급되지 않았습니다.`
                        : `${dailyRewardsCheck.unpaidInvestments.count} investments have not received daily rewards.`}
                    </p>
                    <div className="space-y-1 max-h-40 overflow-y-auto">
                      {dailyRewardsCheck.unpaidInvestments.list.slice(0, 5).map((inv: any, index: number) => (
                        <div key={index} className="text-xs text-gray-300 p-2 bg-white/5 rounded">
                          {inv.username}: ${inv.expectedDailyProfit.toFixed(2)} 예상
                        </div>
                      ))}
                      {dailyRewardsCheck.unpaidInvestments.list.length > 5 && (
                        <p className="text-xs text-gray-400">
                          ... {language === 'ko' ? '외' : 'and'} {dailyRewardsCheck.unpaidInvestments.list.length - 5}{language === 'ko' ? '건' : ' more'}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 상태 요약 */}
            <div className={`p-4 rounded-lg border ${
              dailyRewardsCheck.status.hasActiveInvestments && 
              dailyRewardsCheck.status.isTodayPaid && 
              !dailyRewardsCheck.status.hasUnpaidInvestments
                ? 'bg-green-500/10 border-green-500/30'
                : 'bg-yellow-500/10 border-yellow-500/30'
            }`}>
              <p className="text-sm font-medium text-white mb-2">
                {language === 'ko' ? '상태 요약' : 'Status Summary'}
              </p>
              <p className="text-xs text-gray-300">
                {dailyRewardsCheck.status.message}
              </p>
              {!dailyRewardsCheck.status.isTodayPaid && dailyRewardsCheck.status.hasActiveInvestments && (
                <div className="mt-3">
                  <p className="text-xs text-yellow-400 mb-2">
                    {language === 'ko' ? '권장 조치:' : 'Recommended Actions:'}
                  </p>
                  <ul className="text-xs text-gray-300 space-y-1">
                    <li>• {language === 'ko' ? '관리자 페이지에서 수동으로 마감을 실행하세요.' : 'Execute manual closing from admin page.'}</li>
                    <li>• {language === 'ko' ? 'Railway 로그에서 자정 시간대의 에러를 확인하세요.' : 'Check Railway logs for midnight errors.'}</li>
                    <li>• {language === 'ko' ? '자동 모드가 활성화되어 있는지 확인하세요.' : 'Verify auto mode is enabled.'}</li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </div>


      {/* 마감 실행 카드 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
        <h2 className="text-lg font-semibold text-white mb-4">
          {language === 'ko' ? '수동 마감 실행' : 'Manual Closing'}
        </h2>

        {/* 날짜 선택 */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            {language === 'ko' ? '마감 날짜 지정 (선택사항)' : 'Settlement Date (Optional)'}
          </label>
          <div className="flex items-center gap-3">
            <input
              type="date"
              value={closeDate}
              onChange={(e) => setCloseDate(e.target.value)}
              max={new Date().toISOString().split('T')[0]}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:border-[#137fec] transition-colors"
            />
            {closeDate && (
              <button
                onClick={() => setCloseDate('')}
                className="px-3 py-2 text-sm text-gray-400 hover:text-white transition-colors"
              >
                {language === 'ko' ? '오늘로 초기화' : 'Reset to Today'}
              </button>
            )}
          </div>
          <p className="text-xs text-gray-400 mt-1">
            {language === 'ko'
              ? '날짜를 지정하면 해당 날짜에 지급되지 않은 수당만 지급됩니다. 지정하지 않으면 오늘 날짜로 실행됩니다.'
              : 'Specify a date to pay only unpaid rewards for that date. Leave empty to execute for today.'}
          </p>
        </div>

        {/* 마감 타입 선택 */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-300 mb-2">
            {language === 'ko' ? '마감 타입' : 'Closing Type'}
          </label>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <button
              onClick={() => setCloseType('all')}
              className={`px-4 py-3 rounded-lg border transition-colors ${
                closeType === 'all'
                  ? 'bg-[#137fec]/20 border-[#137fec] text-[#137fec]'
                  : 'bg-white/5 border-white/10 text-white hover:bg-white/10'
              }`}
            >
              <div className="flex items-center gap-2">
                <Play className="h-4 w-4" />
                <span className="font-medium">
                  {language === 'ko' ? '전체 마감' : 'Full Closing'}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                {language === 'ko' ? '일일 수익 + 리더십 보너스' : 'Daily + Leadership'}
              </p>
            </button>

            <button
              onClick={() => setCloseType('daily')}
              className={`px-4 py-3 rounded-lg border transition-colors ${
                closeType === 'daily'
                  ? 'bg-green-500/20 border-green-500 text-green-400'
                  : 'bg-white/5 border-white/10 text-white hover:bg-white/10'
              }`}
            >
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                <span className="font-medium">
                  {language === 'ko' ? '일일 수익' : 'Daily Reward'}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                {language === 'ko' ? '매칭/랭크 포함' : 'Includes Matching/Rank'}
              </p>
            </button>

            <button
              onClick={() => setCloseType('leadership')}
              className={`px-4 py-3 rounded-lg border transition-colors ${
                closeType === 'leadership'
                  ? 'bg-blue-500/20 border-blue-500 text-blue-400'
                  : 'bg-white/5 border-white/10 text-white hover:bg-white/10'
              }`}
            >
              <div className="flex items-center gap-2">
                <Award className="h-4 w-4" />
                <span className="font-medium">
                  {language === 'ko' ? '리더십 보너스' : 'Leadership Bonus'}
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                {language === 'ko' ? '상위 스폰서 보너스' : 'Upper Sponsor Bonus'}
              </p>
            </button>
          </div>
        </div>

        {/* 마감 실행 버튼 */}
        <button
          onClick={handleClose}
          disabled={isClosing}
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-[#137fec] to-[#3A4DFF] text-white rounded-lg font-semibold hover:from-[#137fec]/90 hover:to-[#3A4DFF]/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isClosing ? (
            <>
              <RefreshCw className="h-5 w-5 animate-spin" />
              <span>{language === 'ko' ? '마감 처리 중...' : 'Processing...'}</span>
            </>
          ) : (
            <>
              <Play className="h-5 w-5" />
              <span>{language === 'ko' ? '마감 실행' : 'Execute Closing'}</span>
            </>
          )}
        </button>

        {/* 마지막 마감 결과 */}
        {lastCloseResult && (
          <div className="mt-4 p-4 bg-white/5 rounded-lg border border-white/10">
            <h3 className="text-sm font-medium text-white mb-2">
              {language === 'ko' ? '마지막 마감 결과' : 'Last Closing Result'}
            </h3>
            <div className="space-y-2 text-sm">
              {lastCloseResult.results?.daily && (
                <div className="flex justify-between">
                  <span className="text-gray-400">
                    {language === 'ko' ? '일일 수익' : 'Daily Reward'}:
                  </span>
                  <span className="text-white">
                    {lastCloseResult.results.daily.success ? (
                      <span className="text-green-400">
                        ✅ {lastCloseResult.results.daily.processedCount || 0}{' '}
                        {language === 'ko' ? '건 처리' : 'processed'}
                      </span>
                    ) : (
                      <span className="text-red-400">❌ 실패</span>
                    )}
                  </span>
                </div>
              )}
              {lastCloseResult.results?.leadership && (
                <div className="flex justify-between">
                  <span className="text-gray-400">
                    {language === 'ko' ? '리더십 보너스' : 'Leadership Bonus'}:
                  </span>
                  <span className="text-white">
                    {lastCloseResult.results.leadership.success ? (
                      <span className="text-green-400">
                        ✅ {lastCloseResult.results.leadership.processedCount || 0}{' '}
                        {language === 'ko' ? '명 처리' : 'users processed'}
                      </span>
                    ) : (
                      <span className="text-red-400">❌ 실패</span>
                    )}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 원본 AO 코인 지급 내역 정리 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {language === 'ko' ? '원본 MSUO 코인 지급 내역 정리' : 'Cleanup Original MSUO Coin Rewards'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko'
                ? '재정산 후 남아있는 원본 AO 코인 지급 내역을 찾아서 삭제합니다. (description에 "AOT" 또는 "USDT"가 없는 리워드)'
                : 'Find and delete original AO coin payment records remaining after resettlement. (Rewards without "AOT" or "USDT" in description)'}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              {language === 'ko' ? '정리할 날짜' : 'Target Date'}
            </label>
            <input
              type="date"
              value={cleanupDate}
              onChange={(e) => setCleanupDate(e.target.value)}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:outline-none focus:border-[#137fec] transition-colors"
            />
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => cleanupAOCoinRewards(true)}
              disabled={isCleaningUp}
              className="px-4 py-2 bg-yellow-500/20 border border-yellow-500 text-yellow-400 rounded-lg font-medium hover:bg-yellow-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isCleaningUp ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  <span>{language === 'ko' ? '확인 중...' : 'Checking...'}</span>
                </>
              ) : (
                <>
                  <AlertCircle className="h-4 w-4" />
                  <span>{language === 'ko' ? '확인 (Dry Run)' : 'Check (Dry Run)'}</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                if (
                  confirm(
                    language === 'ko'
                      ? `정말로 ${cleanupDate}의 원본 MSUO 코인 지급 내역을 삭제하시겠습니까?`
                      : `Are you sure you want to delete original MSUO coin rewards for ${cleanupDate}?`
                  )
                ) {
                  cleanupAOCoinRewards(false);
                }
              }}
              disabled={isCleaningUp || !cleanupResult}
              className="px-4 py-2 bg-red-500/20 border border-red-500 text-red-400 rounded-lg font-medium hover:bg-red-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {language === 'ko' ? '실제 삭제' : 'Delete'}
            </button>
          </div>

          {cleanupResult && (
            <div className="p-4 bg-white/5 rounded-lg border border-white/10">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">
                    {language === 'ko' ? '발견된 내역' : 'Found Records'}
                  </span>
                  <span className="text-sm font-medium text-white">
                    {cleanupResult.foundCount || cleanupResult.deletedCount || 0}건
                  </span>
                </div>
                {cleanupResult.totalAmount && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-400">
                      {language === 'ko' ? '총 금액' : 'Total Amount'}
                    </span>
                    <span className="text-sm font-medium text-white">
                      ${cleanupResult.totalAmount.toLocaleString('ko-KR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                )}
                {cleanupResult.summary && cleanupResult.summary.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-white/10">
                    <p className="text-xs text-gray-400 mb-2">
                      {language === 'ko' ? '타입별 내역' : 'By Type'}
                    </p>
                    <div className="space-y-1">
                      {cleanupResult.summary.map((item: any, index: number) => (
                        <div key={index} className="flex items-center justify-between text-xs">
                          <span className="text-gray-300">{item.type}</span>
                          <span className="text-white">
                            {item.count}건, ${item.totalAmount.toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {cleanupResult.message && (
                  <p className="text-xs text-gray-400 mt-2">{cleanupResult.message}</p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 마감 내역 조회 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white">
            {language === 'ko' ? '마감 내역' : 'Closing History'}
          </h2>
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => {
                setSelectedDate(e.target.value);
                loadHistory(e.target.value);
              }}
              className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white text-sm focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
            <button
              onClick={() => loadHistory()}
              disabled={isLoadingHistory}
              className="p-2 bg-white/5 border border-white/10 rounded-lg text-white hover:bg-white/10 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 ${isLoadingHistory ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {isLoadingHistory ? (
          <div className="text-center py-8 text-gray-400">
            {language === 'ko' ? '로딩 중...' : 'Loading...'}
          </div>
        ) : history ? (
          <>
            {/* 통계 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {history.stats.map((stat) => (
                <div
                  key={stat.type}
                  className="p-4 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="h-4 w-4 text-[#137fec]" />
                    <span className="text-sm font-medium text-gray-400">
                      {getTypeLabel(stat.type)}
                    </span>
                  </div>
                  <div className="text-2xl font-bold text-white">
                    {formatCurrency(stat.totalAmount)}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {formatNumber(stat.count)} {language === 'ko' ? '건' : 'transactions'}
                  </div>
                </div>
              ))}
            </div>

            {/* 상세 내역 */}
            {history.details.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-white/10">
                  <thead className="bg-white/5">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                        {language === 'ko' ? '시간' : 'Time'}
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                        {language === 'ko' ? '타입' : 'Type'}
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                        {language === 'ko' ? '사용자' : 'User'}
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                        {language === 'ko' ? '금액' : 'Amount'}
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase">
                        {language === 'ko' ? '설명' : 'Description'}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {history.details.map((detail) => (
                      <tr key={detail.id} className="hover:bg-white/5">
                        <td className="px-4 py-3 text-sm text-white">
                          {new Date(detail.createdAt).toLocaleTimeString('ko-KR')}
                        </td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-[#137fec]/20 text-[#137fec] border border-[#137fec]/50">
                            {getTypeLabel(detail.type)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-white">
                          {detail.users.username || detail.users.email || 'Unknown'}
                        </td>
                        <td className="px-4 py-3 text-sm font-medium text-white">
                          {formatCurrency(detail.amount)}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-400">
                          {detail.description ? detail.description.replace(/USDT/g, 'AOT') : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                {language === 'ko' ? '해당 날짜에 마감 내역이 없습니다.' : 'No closing history for this date.'}
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-8 text-gray-400">
            {language === 'ko' ? '마감 내역을 불러올 수 없습니다.' : 'Failed to load closing history.'}
          </div>
        )}
      </div>
    </div>
  );
}

