'use client'

import { useEffect, useState, useCallback } from 'react'
import { useParams, useRouter } from 'next/navigation'
import UpdateRelationsModal from '@/components/admin/UpdateRelationsModal'
import UpdatePasswordModal from '@/components/admin/UpdatePasswordModal'
import VerifyPasswordModal from '@/components/admin/VerifyPasswordModal'
import ViewPasswordModal from '@/components/admin/ViewPasswordModal'
import UpdateEmailModal from '@/components/admin/UpdateEmailModal'
import AddInvestmentModal from '@/components/admin/AddInvestmentModal'
import UpdateInvestmentModal from '@/components/admin/UpdateInvestmentModal'
import ChargeUSDTModal from '@/components/admin/ChargeUSDTModal'

interface UserDetailData {
  users: {
    id: string
    username: string
    email: string
    walletAddress?: string
    rank: number
    totalInvestment: number
    personalCoin: number
    accumulatedSales: number
    status: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED'
    role: 'USER' | 'ADMIN' | 'SUPER_ADMIN'
    isActive: boolean
    createdAt: string
    updatedAt: string
  }
  referrer?: {
    id: string
    username: string
    email: string
    referralCode?: string
  }
  sponsor?: {
    id: string
    username: string
    email: string
    referralCode?: string
  }
  statistics: {
    totalRewards: number
    totalRewardCount: number
    monthlyRewards: number
    monthlyRewardCount: number
    todayRewards: number
    todayRewardCount: number
    line1: number
    line2: number
    line3: number
    line4: number
    line5: number
  }
  counts: {
    other_users_users_referrerIdTousers: number
    investments: number
    reward_logs: number
    withdrawals: number
  }
  activities: {
    other_users_users_referrerIdTousers: Array<{
      id: string
      username: string
      email: string
      rank: number
      totalInvestment: number
      createdAt: string
    }>
    investments: Array<{
      id: string
      amount: number
      dailyRate: number
      matchingDepth: number
      investment_tiers: number
      startDate: string
      endDate: string
      isActive: boolean
      createdAt: string
    }>
    withdrawals: Array<{
      id: string
      amount: number
      status: string
      requestedAt: string
      processedAt?: string
    }>
  }
}

export default function UserDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [data, setData] = useState<UserDetailData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'overview' | 'referrals' | 'investments' | 'withdrawals'>('overview')
  const [isUpdateRelationsModalOpen, setIsUpdateRelationsModalOpen] = useState(false)
  const [isUpdatePasswordModalOpen, setIsUpdatePasswordModalOpen] = useState(false)
  const [isVerifyPasswordModalOpen, setIsVerifyPasswordModalOpen] = useState(false)
  const [isViewPasswordModalOpen, setIsViewPasswordModalOpen] = useState(false)
  const [isUpdateEmailModalOpen, setIsUpdateEmailModalOpen] = useState(false)
  const [isAddInvestmentModalOpen, setIsAddInvestmentModalOpen] = useState(false)
  const [isUpdateInvestmentModalOpen, setIsUpdateInvestmentModalOpen] = useState(false)
  const [isChargeUSDTModalOpen, setIsChargeUSDTModalOpen] = useState(false)
  const [selectedInvestment, setSelectedInvestment] = useState<{
    id: string;
    amount: number;
    investment_tiers: number;
    dailyRate: number;
    matchingDepth: number;
    isActive: boolean;
  } | null>(null)

  const fetchUserDetail = useCallback(async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/admin/users/${params.userId}`)
      if (response.ok) {
        const result = await response.json()
        setData(result.data)
      } else {
        alert('사용자 정보를 불러올 수 없습니다.')
        router.push('/a0-admin/users')
      }
    } catch (error) {
      console.error('사용자 상세 정보 조회 실패:', error)
      alert('사용자 정보 조회 중 오류가 발생했습니다.')
      router.push('/a0-admin/users')
    } finally {
      setIsLoading(false)
    }
  }, [params.userId, router])

  useEffect(() => {
    fetchUserDetail()
  }, [fetchUserDetail])

  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString('ko-KR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })} AOT`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ko-KR')
  }

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('ko-KR')
  }

  const getRankBadge = (rank: number) => {
    const rankConfig = {
      1: { label: '브론즈', className: 'bg-gray-700/50 text-gray-300 border border-gray-600' },
      2: { label: '실버', className: 'bg-green-700/30 text-green-300 border border-green-600/50' },
      3: { label: '골드', className: 'bg-blue-700/30 text-blue-300 border border-blue-600/50' },
      4: { label: '플래티넘', className: 'bg-purple-700/30 text-purple-300 border border-purple-600/50' },
      5: { label: '다이아몬드', className: 'bg-yellow-700/30 text-yellow-300 border border-yellow-600/50' },
    }

    const config = rankConfig[rank as keyof typeof rankConfig] || rankConfig[1]
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.className}`}>
        {config.label}
      </span>
    )
  }

  const getStatusBadge = (status: string, isActive: boolean) => {
    if (!isActive) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-700/50 text-gray-300 border border-gray-600">
          비활성
        </span>
      )
    }

    const statusConfig = {
      ACTIVE: { label: '활성', className: 'bg-green-700/30 text-green-300 border border-green-600/50' },
      INACTIVE: { label: '비활성', className: 'bg-gray-700/50 text-gray-300 border border-gray-600' },
      SUSPENDED: { label: '정지', className: 'bg-red-700/30 text-red-300 border border-red-600/50' },
    }

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.ACTIVE
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.className}`}>
        {config.label}
      </span>
    )
  }

  const getRoleBadge = (role: string) => {
    const roleConfig = {
      USER: { label: '사용자', className: 'bg-blue-700/30 text-blue-300 border border-blue-600/50' },
      ADMIN: { label: '관리자', className: 'bg-purple-700/30 text-purple-300 border border-purple-600/50' },
      SUPER_ADMIN: { label: '슈퍼관리자', className: 'bg-red-700/30 text-red-300 border border-red-600/50' },
    }

    const config = roleConfig[role as keyof typeof roleConfig] || roleConfig.USER
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.className}`}>
        {config.label}
      </span>
    )
  }

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-[#1e293b] rounded w-64 mb-6"></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
                <div className="h-32 bg-[#111a22] rounded mb-4"></div>
                <div className="space-y-3">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="h-4 bg-[#111a22] rounded"></div>
                  ))}
                </div>
              </div>
            </div>
            <div className="lg:col-span-2">
              <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
                <div className="h-6 bg-[#111a22] rounded w-32 mb-4"></div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[...Array(8)].map((_, i) => (
                    <div key={i} className="h-16 bg-[#111a22] rounded"></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="p-6">
        <div className="text-center text-gray-400">
          사용자 정보를 불러올 수 없습니다.
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 페이지 헤더 */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => router.push('/a0-admin/users')}
            className="text-gray-400 hover:text-white flex items-center space-x-2 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span>목록으로</span>
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">{data.users.username}</h1>
            <p className="text-gray-400">{data.users.email}</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {getRoleBadge(data.users.role)}
          {getStatusBadge(data.users.status, data.users.isActive)}
          {getRankBadge(data.users.rank)}
          <button
            onClick={() => setIsChargeUSDTModalOpen(true)}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
          >
            <span className="material-symbols-outlined text-sm">account_balance_wallet</span>
            AOT 충전
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 사용자 정보 */}
        <div className="lg:col-span-1">
          <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
            <h3 className="text-lg font-semibold text-white mb-4">기본 정보</h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-400">사용자명</label>
                <p className="mt-1 text-sm text-white">{data.users.username}</p>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-sm font-medium text-gray-400">이메일</label>
                  <button
                    onClick={() => setIsUpdateEmailModalOpen(true)}
                    className="text-xs text-orange-400 hover:text-orange-300 transition-colors"
                  >
                    변경
                  </button>
                </div>
                <p className="mt-1 text-sm text-white">{data.users.email || '(등록되지 않음)'}</p>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-sm font-medium text-gray-400">비밀번호</label>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsViewPasswordModalOpen(true)}
                      className="text-xs text-purple-400 hover:text-purple-300 transition-colors"
                    >
                      확인
                    </button>
                    <button
                      onClick={() => setIsUpdatePasswordModalOpen(true)}
                      className="text-xs text-orange-400 hover:text-orange-300 transition-colors"
                    >
                      변경
                    </button>
                  </div>
                </div>
                <p className="mt-1 text-sm text-gray-500">••••••••</p>
              </div>
              {data.users.walletAddress && (
                <div>
                  <label className="text-sm font-medium text-gray-400">지갑 주소</label>
                  <p className="mt-1 text-sm text-white font-mono break-all">{data.users.walletAddress}</p>
                </div>
              )}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-sm font-medium text-gray-400">추천인</label>
                  <button
                    onClick={() => setIsUpdateRelationsModalOpen(true)}
                    className="text-xs text-[#137fec] hover:text-[#137fec]/80 transition-colors"
                  >
                    변경
                  </button>
                </div>
                {data.referrer ? (
                  <p className="mt-1 text-sm text-[#137fec] hover:text-[#137fec]/80 cursor-pointer">
                    {data.other_users_users_referrerIdTousers.username} ({data.other_users_users_referrerIdTousers.email})
                    {data.other_users_users_referrerIdTousers.referralCode && ` - ${data.other_users_users_referrerIdTousers.referralCode}`}
                  </p>
                ) : (
                  <p className="mt-1 text-sm text-gray-500">없음</p>
                )}
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-sm font-medium text-gray-400">후원인</label>
                  <button
                    onClick={() => setIsUpdateRelationsModalOpen(true)}
                    className="text-xs text-[#137fec] hover:text-[#137fec]/80 transition-colors"
                  >
                    변경
                  </button>
                </div>
                {data.sponsor ? (
                  <p className="mt-1 text-sm text-[#137fec] hover:text-[#137fec]/80 cursor-pointer">
                    {data.other_users_users_sponsorIdTousers.username} ({data.other_users_users_sponsorIdTousers.email})
                    {data.other_users_users_sponsorIdTousers.referralCode && ` - ${data.other_users_users_sponsorIdTousers.referralCode}`}
                  </p>
                ) : (
                  <p className="mt-1 text-sm text-gray-500">없음</p>
                )}
              </div>
              <div>
                <label className="text-sm font-medium text-gray-400">가입일</label>
                <p className="mt-1 text-sm text-white">{formatDate(data.users.createdAt)}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-400">최종 업데이트</label>
                <p className="mt-1 text-sm text-white">{formatDate(data.users.updatedAt)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* 메인 콘텐츠 */}
        <div className="lg:col-span-2">
          {/* 탭 네비게이션 */}
          <div className="bg-[#1e293b] rounded-lg border border-white/10">
            <div className="border-b border-white/10">
              <nav className="flex space-x-8 px-6" aria-label="Tabs">
                {[
                  { key: 'overview', label: '개요' },
                  { key: 'referrals', label: `추천인 (${data.counts.referredUsers})` },
                  { key: 'investments', label: `투자 (${data.counts.investments})` },
                  { key: 'withdrawals', label: `출금 (${data.counts.withdrawals})` },
                ].map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key as any)}
                    className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === tab.key
                        ? 'border-[#137fec] text-[#137fec]'
                        : 'border-transparent text-gray-400 hover:text-gray-300 hover:border-gray-600'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </nav>
            </div>

            <div className="p-6">
              {/* 개요 탭 */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* 재무 요약 */}
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">재무 요약</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-white/5 border border-white/10 p-4 rounded-lg">
                        <p className="text-sm font-medium text-gray-400">총 투자</p>
                        <p className="mt-1 text-lg font-semibold text-white">
                          {formatCurrency(data.users.totalInvestment)}
                        </p>
                      </div>
                      <div className="bg-white/5 border border-white/10 p-4 rounded-lg">
                        <p className="text-sm font-medium text-gray-400">보유 코인</p>
                        <p className="mt-1 text-lg font-semibold text-white">
                          {formatCurrency(data.users.personalCoin)}
                        </p>
                      </div>
                      <div className="bg-white/5 border border-white/10 p-4 rounded-lg">
                        <p className="text-sm font-medium text-gray-400">총 수당</p>
                        <p className="mt-1 text-lg font-semibold text-white">
                          {formatCurrency(data.statistics.totalRewards)}
                        </p>
                      </div>
                      <div className="bg-white/5 border border-white/10 p-4 rounded-lg">
                        <p className="text-sm font-medium text-gray-400">총 매출</p>
                        <p className="mt-1 text-lg font-semibold text-white">
                          {formatCurrency(data.users.accumulatedSales)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* 라인별 매출 */}
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">라인별 매출</h3>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                      {[1, 2, 3, 4, 5].map((line) => (
                        <div key={line} className="bg-[#137fec]/10 border border-[#137fec]/20 p-4 rounded-lg">
                          <p className="text-sm font-medium text-[#137fec]">{line}라인</p>
                          <p className="mt-1 text-lg font-semibold text-white">
                            {formatCurrency(data.statistics[`line${line}` as keyof typeof data.statistics] as number)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 수당 통계 */}
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-4">수당 통계</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-green-700/20 border border-green-600/30 p-4 rounded-lg">
                        <p className="text-sm font-medium text-green-400">오늘 수당</p>
                        <p className="mt-1 text-lg font-semibold text-white">
                          {formatCurrency(data.statistics.todayRewards)}
                        </p>
                        <p className="text-xs text-green-400 mt-1">
                          {data.statistics.todayRewardCount}건
                        </p>
                      </div>
                      <div className="bg-yellow-700/20 border border-yellow-600/30 p-4 rounded-lg">
                        <p className="text-sm font-medium text-yellow-400">이번 달 수당</p>
                        <p className="mt-1 text-lg font-semibold text-white">
                          {formatCurrency(data.statistics.monthlyRewards)}
                        </p>
                        <p className="text-xs text-yellow-400 mt-1">
                          {data.statistics.monthlyRewardCount}건
                        </p>
                      </div>
                      <div className="bg-purple-700/20 border border-purple-600/30 p-4 rounded-lg">
                        <p className="text-sm font-medium text-purple-400">총 수당 건수</p>
                        <p className="mt-1 text-lg font-semibold text-white">
                          {data.statistics.totalRewardCount.toLocaleString()}건
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* 추천인 탭 */}
              {activeTab === 'referrals' && (
                <div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-white/10">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            사용자
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            랭크
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            투자금액
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            가입일
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {data.activities.other_users_users_referrerIdTousers.map((referral) => (
                          <tr key={referral.id} className="hover:bg-white/5 transition-colors">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div>
                                <div className="text-sm font-medium text-white">{referral.username}</div>
                                <div className="text-sm text-gray-400">{referral.email}</div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {getRankBadge(referral.rank)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                              {formatCurrency(referral.totalInvestment)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatDate(referral.createdAt)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {data.activities.other_users_users_referrerIdTousers.length === 0 && (
                    <div className="text-center py-8 text-gray-400">
                      추천인이 없습니다.
                    </div>
                  )}
                </div>
              )}

              {/* 투자 탭 */}
              {activeTab === 'investments' && (
                <div>
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-white">투자 내역</h3>
                    <button
                      onClick={() => setIsAddInvestmentModalOpen(true)}
                      className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-500 to-green-500 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-blue-500/50"
                    >
                      <span>+</span>
                      투자 추가
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-white/10">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            투자금액
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            일이율
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            매칭깊이
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            상태
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            투자일
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            만기일
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            작업
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {data.activities.investments.map((investment) => (
                          <tr key={investment.id} className="hover:bg-white/5 transition-colors">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                              {formatCurrency(investment.amount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {(investment.dailyRate * 100).toFixed(2)}%
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {investment.matchingDepth}세대
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                investment.isActive
                                  ? 'bg-green-700/30 text-green-300 border border-green-600/50'
                                  : 'bg-gray-700/50 text-gray-300 border border-gray-600'
                              }`}>
                                {investment.isActive ? '활성' : '만료'}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatDate(investment.startDate)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatDate(investment.endDate)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <button
                                onClick={() => {
                                  setSelectedInvestment({
                                    id: investment.id,
                                    amount: investment.amount,
                                    investment_tiers: investment.investmentTier,
                                    dailyRate: investment.dailyRate,
                                    matchingDepth: investment.matchingDepth,
                                    isActive: investment.isActive,
                                  });
                                  setIsUpdateInvestmentModalOpen(true);
                                }}
                                className="text-yellow-400 hover:text-yellow-300 transition-colors text-xs font-medium"
                                disabled={!investment.isActive}
                              >
                                {investment.isActive ? '수정' : '-'}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {data.activities.investments.length === 0 && (
                    <div className="text-center py-8 text-gray-400">
                      투자 내역이 없습니다.
                    </div>
                  )}
                </div>
              )}

              {/* 출금 탭 */}
              {activeTab === 'withdrawals' && (
                <div>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-white/10">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            금액
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            상태
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            요청일
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            처리일
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {data.activities.withdrawals.map((withdrawal) => (
                          <tr key={withdrawal.id} className="hover:bg-white/5 transition-colors">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                              {formatCurrency(withdrawal.amount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                withdrawal.status === 'PENDING' ? 'bg-yellow-700/30 text-yellow-300 border border-yellow-600/50' :
                                withdrawal.status === 'APPROVED' ? 'bg-green-700/30 text-green-300 border border-green-600/50' :
                                'bg-red-700/30 text-red-300 border border-red-600/50'
                              }`}>
                                {withdrawal.status === 'PENDING' ? '대기' :
                                 withdrawal.status === 'APPROVED' ? '승인' : '거절'}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatDateTime(withdrawal.requestedAt)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {withdrawal.processedAt ? formatDateTime(withdrawal.processedAt) : '-'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {data.activities.withdrawals.length === 0 && (
                    <div className="text-center py-8 text-gray-400">
                      출금 내역이 없습니다.
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 추천인/후원인 변경 모달 */}
      <UpdateRelationsModal
        isOpen={isUpdateRelationsModalOpen}
        onClose={() => setIsUpdateRelationsModalOpen(false)}
        userId={params.userId as string}
        currentReferrer={data?.referrer || null}
        currentSponsor={data?.sponsor || null}
        onSuccess={() => {
          fetchUserDetail()
          setIsUpdateRelationsModalOpen(false)
        }}
      />

      {/* 비밀번호 정보 확인 모달 */}
      <ViewPasswordModal
        isOpen={isViewPasswordModalOpen}
        onClose={() => setIsViewPasswordModalOpen(false)}
        userId={params.userId as string}
        username={data?.users.username || ''}
        onSuccess={() => {
          fetchUserDetail()
        }}
      />

      {/* 비밀번호 변경 모달 */}
      <UpdatePasswordModal
        isOpen={isUpdatePasswordModalOpen}
        onClose={() => setIsUpdatePasswordModalOpen(false)}
        userId={params.userId as string}
        username={data?.users.username || ''}
        onSuccess={() => {
          fetchUserDetail()
          setIsUpdatePasswordModalOpen(false)
        }}
      />

      {/* 이메일 변경 모달 */}
      {data && (
        <UpdateEmailModal
          isOpen={isUpdateEmailModalOpen}
          onClose={() => setIsUpdateEmailModalOpen(false)}
          userId={params.userId as string}
          currentEmail={data.users.email}
          onSuccess={() => {
            fetchUserDetail()
            setIsUpdateEmailModalOpen(false)
          }}
        />
      )}

      {/* 투자 추가 모달 */}
      {data && (
        <AddInvestmentModal
          isOpen={isAddInvestmentModalOpen}
          onClose={() => setIsAddInvestmentModalOpen(false)}
          userId={params.userId as string}
          username={data.users.username}
          onSuccess={() => {
            fetchUserDetail()
            setIsAddInvestmentModalOpen(false)
          }}
        />
      )}

      {/* 투자 수정 모달 */}
      {data && selectedInvestment && (
        <UpdateInvestmentModal
          isOpen={isUpdateInvestmentModalOpen}
          onClose={() => {
            setIsUpdateInvestmentModalOpen(false)
            setSelectedInvestment(null)
          }}
          userId={params.userId as string}
          username={data.users.username}
          investment={selectedInvestment}
          onSuccess={() => {
            fetchUserDetail()
            setIsUpdateInvestmentModalOpen(false)
            setSelectedInvestment(null)
          }}
        />
      )}

      {/* USDT 충전 모달 */}
      {data && (
        <ChargeUSDTModal
          isOpen={isChargeUSDTModalOpen}
          onClose={() => setIsChargeUSDTModalOpen(false)}
          userId={params.userId as string}
          username={data.users.username}
          currentBalance={data.users.personalCoin}
          onSuccess={() => {
            fetchUserDetail()
            setIsChargeUSDTModalOpen(false)
          }}
        />
      )}
    </div>
  )
}