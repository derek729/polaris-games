'use client'

import { useEffect, useState, useCallback } from 'react'
import { useI18n } from '@/lib/i18n/context'

interface MiningRecord {
  id: string
  userId: string
  user?: {
    id: string
    username: string
    email: string
  }
  mainnetAddress?: string
  txHash?: string
  blockHash?: string
  blockNumber?: number
  blockHeight?: number
  rewardAmount: number
  difficulty?: number
  hashrate?: number
  miningDuration?: number
  status: string
  confirmations: number
  minedAt: string
  confirmedAt?: string
  createdAt: string
  updatedAt: string
}

interface MiningResponse {
  ok: boolean
  data: {
    mining_records: MiningRecord[]
    pagination: {
      currentPage: number
      totalPages: number
      totalCount: number
      limit: number
      hasNext: boolean
      hasPrev: boolean
    }
    stats: {
      total: number
      totalRewards: number
    }
  }
}

export default function MiningAdminClient() {
  const { t } = useI18n()
  const [miningRecords, setMiningRecords] = useState<MiningRecord[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalCount: 0,
    limit: 20,
    hasNext: false,
    hasPrev: false,
  })
  const [stats, setStats] = useState({
    total: 0,
    totalRewards: 0,
  })

  // 필터링 상태
  const [filters, setFilters] = useState({
    period: '30',
    userId: '',
    status: '',
  })

  const fetchMiningRecords = useCallback(async () => {
    try {
      setIsLoading(true)
      const params = new URLSearchParams({
        page: pagination.currentPage.toString(),
        limit: pagination.limit.toString(),
        period: filters.period,
        ...(filters.userId && { userId: filters.userId }),
        ...(filters.status && { status: filters.status }),
      })

      const response = await fetch(`/api/admin/mining?${params}`)
      if (response.ok) {
        const data: MiningResponse = await response.json()
        setMiningRecords(data.data.miningRecords)
        setPagination(data.data.pagination)
        setStats(data.data.stats)
      }
    } catch (error) {
      console.error('채굴 기록 조회 실패:', error)
    } finally {
      setIsLoading(false)
    }
  }, [pagination.currentPage, filters])

  useEffect(() => {
    fetchMiningRecords()
  }, [fetchMiningRecords])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(num)
  }

  const getStatusBadge = (status: string) => {
    const configs = {
      PENDING: { label: '대기중', className: 'bg-yellow-500/20 text-yellow-400' },
      CONFIRMED: { label: '확인됨', className: 'bg-green-500/20 text-green-400' },
      FAILED: { label: '실패', className: 'bg-red-500/20 text-red-400' },
    }
    const config = configs[status as keyof typeof configs] || configs.PENDING
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.className}`}>
        {config.label}
      </span>
    )
  }

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination(prev => ({ ...prev, currentPage: newPage }))
    }
  }

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }))
    setPagination(prev => ({ ...prev, currentPage: 1 }))
  }

  if (isLoading && miningRecords.length === 0) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-[#1e293b] rounded w-48 mb-6"></div>
          <div className="bg-[#1e293b] rounded-lg border border-white/10 overflow-hidden">
            <div className="h-16 bg-white/5"></div>
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-16 bg-white/5 border-t border-white/10"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div>
        <h1 className="text-2xl font-bold text-white">채굴 기록 관리</h1>
        <p className="text-gray-400 mt-1">총 {formatNumber(stats.total)}건</p>
      </div>

      {/* 통계 카드 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="flex flex-col gap-2 rounded-xl p-4 bg-[#1e293b] border border-white/10">
          <p className="text-gray-400 text-sm font-medium">총 채굴 기록</p>
          <p className="text-white text-xl font-bold">{formatNumber(stats.total)}건</p>
        </div>
        <div className="flex flex-col gap-2 rounded-xl p-4 bg-[#1e293b] border border-white/10">
          <p className="text-gray-400 text-sm font-medium">총 채굴 보상</p>
          <p className="text-white text-xl font-bold">{formatCurrency(stats.totalRewards)}</p>
        </div>
      </div>

      {/* 검색 및 필터 */}
      <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">기간</label>
            <select
              value={filters.period}
              onChange={(e) => handleFilterChange('period', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="7">최근 7일</option>
              <option value="30">최근 30일</option>
              <option value="90">최근 90일</option>
              <option value="all">전체</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">상태</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="">전체</option>
              <option value="PENDING">대기중</option>
              <option value="CONFIRMED">확인됨</option>
              <option value="FAILED">실패</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">사용자 ID</label>
            <input
              type="text"
              value={filters.userId}
              onChange={(e) => handleFilterChange('userId', e.target.value)}
              placeholder="사용자 ID 입력"
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* 채굴 기록 테이블 */}
      <div className="bg-[#1e293b] shadow-sm border border-white/10 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-white/10">
            <thead className="bg-white/5">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  사용자
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  보상 금액
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  블록 정보
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  상태
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  채굴 시간
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {miningRecords.map((record) => (
                <tr key={record.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    {record.users ? (
                      <div>
                        <div className="text-sm font-medium text-white">{record.users.username}</div>
                        <div className="text-xs text-gray-400">{record.users.email}</div>
                      </div>
                    ) : (
                      <span className="text-gray-400 text-sm">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                    {formatCurrency(record.rewardAmount)} MSUO
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-300">
                      {record.blockNumber && (
                        <div>블록 #{record.blockNumber}</div>
                      )}
                      {record.txHash && (
                        <div className="text-xs text-gray-400 truncate max-w-[200px]">
                          TX: {record.txHash.slice(0, 10)}...
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(record.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {formatDate(record.minedAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {miningRecords.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-400">채굴 기록이 없습니다.</p>
          </div>
        )}
      </div>

      {/* 페이지네이션 */}
      {pagination.totalPages > 1 && (
        <div className="flex items-center justify-between bg-[#1e293b] px-6 py-3 rounded-lg border border-white/10">
          <div className="flex-1 flex justify-between sm:hidden">
            <button
              onClick={() => handlePageChange(pagination.currentPage - 1)}
              disabled={!pagination.hasPrev}
              className="relative inline-flex items-center px-4 py-2 border border-white/10 text-sm font-medium rounded-md text-white bg-white/5 hover:bg-white/10 disabled:opacity-50"
            >
              이전
            </button>
            <button
              onClick={() => handlePageChange(pagination.currentPage + 1)}
              disabled={!pagination.hasNext}
              className="ml-3 relative inline-flex items-center px-4 py-2 border border-white/10 text-sm font-medium rounded-md text-white bg-white/5 hover:bg-white/10 disabled:opacity-50"
            >
              다음
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-300">
                <span className="font-medium">
                  {(pagination.currentPage - 1) * pagination.limit + 1}
                </span>
                {' '}
                -{' '}
                <span className="font-medium">
                  {Math.min(pagination.currentPage * pagination.limit, pagination.totalCount)}
                </span>
                {' '}
                / 총{' '}
                <span className="font-medium">{formatNumber(pagination.totalCount)}</span>
              </p>
            </div>
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                <button
                  onClick={() => handlePageChange(pagination.currentPage - 1)}
                  disabled={!pagination.hasPrev}
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-white/10 bg-white/5 text-sm font-medium text-white hover:bg-white/10 disabled:opacity-50"
                >
                  이전
                </button>

                {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                  let pageNum
                  if (pagination.totalPages <= 5) {
                    pageNum = i + 1
                  } else if (pagination.currentPage <= 3) {
                    pageNum = i + 1
                  } else if (pagination.currentPage >= pagination.totalPages - 2) {
                    pageNum = pagination.totalPages - 4 + i
                  } else {
                    pageNum = pagination.currentPage - 2 + i
                  }

                  return (
                    <button
                      key={pageNum}
                      onClick={() => handlePageChange(pageNum)}
                      className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                        pageNum === pagination.currentPage
                          ? 'z-10 bg-[#137fec]/20 border-[#137fec] text-[#137fec]'
                          : 'bg-white/5 border-white/10 text-white hover:bg-white/10'
                      }`}
                    >
                      {pageNum}
                    </button>
                  )
                })}

                <button
                  onClick={() => handlePageChange(pagination.currentPage + 1)}
                  disabled={!pagination.hasNext}
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-white/10 bg-white/5 text-sm font-medium text-white hover:bg-white/10 disabled:opacity-50"
                >
                  다음
                </button>
              </nav>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

