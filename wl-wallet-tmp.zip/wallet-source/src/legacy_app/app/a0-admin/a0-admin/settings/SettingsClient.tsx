'use client';

import React, { useState, useEffect } from 'react';

interface RewardSettings {
  referralBonus: {
    rate: number;
    description: string;
  };
  matchingBonus: {
    generation1: number;
    generation2to4: number;
    generation5to8: number;
    generation9to12: number;
    description: string;
  };
  leadershipBonus: {
    rank1: number;
    rank2: number;
    rank3: number;
    rank4: number;
    rank5: number;
    description: string;
  };
}

interface InvestmentTier {
  tier: number;
  minAmount: number;
  maxAmount: number | null;
  dailyRate: number;
  matchingDepth: number;
  label: string;
  description: string;
}

export default function SettingsClient() {
  const [rewardSettings, setRewardSettings] = useState<RewardSettings | null>(null);
  const [investmentTiers, setInvestmentTiers] = useState<InvestmentTier[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<'reward' | 'investment' | 'system'>('reward');
  const [systemSettings, setSystemSettings] = useState<{
    usdtAddress: string;
    upcTotalSupply: string;
    upcInitialPrice: string;
    exchangeBotEnabled: string;
    exchangeBotMinPrice: string;
    exchangeBotMaxPrice: string;
    exchangeBotSpread: string;
    exchangeBotOrderAmount: string;
  }>({
    usdtAddress: '',
    upcTotalSupply: '10000000000', // 100억개
    upcInitialPrice: '0.00010', // $0.00010
    exchangeBotEnabled: 'false',
    exchangeBotMinPrice: '0.00005', // 최저가
    exchangeBotMaxPrice: '0.00015', // 최고가
    exchangeBotSpread: '0.00001', // 스프레드
    exchangeBotOrderAmount: '1000', // 주문 수량
  });
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const [rewardRes, tierRes, systemRes] = await Promise.all([
        fetch('/api/admin/reward-settings'),
        fetch('/api/admin/investment/tiers'),
        fetch('/api/admin/system-settings'),
      ]);

      if (rewardRes.ok) {
        const rewardData = await rewardRes.json();
        if (rewardData.ok) {
          setRewardSettings(rewardData.data);
        }
      }

      if (tierRes.ok) {
        const tierData = await tierRes.json();
        if (tierData.ok) {
          setInvestmentTiers(tierData.data);
        }
      }

      if (systemRes.ok) {
        const systemData = await systemRes.json();
        if (systemData.ok) {
          setSystemSettings({
            usdtAddress: systemData.data.usdtAddress || '',
            upcTotalSupply: systemData.data.upcTotalSupply || '10000000000',
            upcInitialPrice: systemData.data.upcInitialPrice || '0.00010',
            exchangeBotEnabled: systemData.data.exchangeBotEnabled || 'false',
            exchangeBotMinPrice: systemData.data.exchangeBotMinPrice || '0.00005',
            exchangeBotMaxPrice: systemData.data.exchangeBotMaxPrice || '0.00015',
            exchangeBotSpread: systemData.data.exchangeBotSpread || '0.00001',
            exchangeBotOrderAmount: systemData.data.exchangeBotOrderAmount || '1000',
          });
        }
      }
    } catch (error) {
      console.error('설정 조회 실패:', error);
      setMessage({ type: 'error', text: '설정을 불러오는데 실패했습니다.' });
    } finally {
      setLoading(false);
    }
  };

  const handleRewardSettingsSave = async () => {
    if (!rewardSettings) return;

    try {
      setSaving(true);
      const response = await fetch('/api/admin/reward-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rewardSettings),
      });

      const result = await response.json();
      if (result.ok) {
        setMessage({ type: 'success', text: '보상 설정이 저장되었습니다.' });
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage({ type: 'error', text: result.error || '저장에 실패했습니다.' });
      }
    } catch (error) {
      console.error('보상 설정 저장 실패:', error);
      setMessage({ type: 'error', text: '저장 중 오류가 발생했습니다.' });
    } finally {
      setSaving(false);
    }
  };

  const handleInvestmentTiersSave = async () => {
    try {
      setSaving(true);
      const response = await fetch('/api/admin/investment/tiers', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tiers: investmentTiers }),
      });

      const result = await response.json();
      if (result.ok) {
        setMessage({ type: 'success', text: '투자 등급 설정이 저장되었습니다.' });
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage({ type: 'error', text: result.error || '저장에 실패했습니다.' });
      }
    } catch (error) {
      console.error('투자 등급 설정 저장 실패:', error);
      setMessage({ type: 'error', text: '저장 중 오류가 발생했습니다.' });
    } finally {
      setSaving(false);
    }
  };

  const handleSystemSettingsSave = async () => {
    try {
      setSaving(true);
      const response = await fetch('/api/admin/system-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(systemSettings),
      });

      const result = await response.json();
      if (result.ok) {
        setMessage({ type: 'success', text: '시스템 설정이 저장되었습니다.' });
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage({ type: 'error', text: result.error || '저장에 실패했습니다.' });
      }
    } catch (error) {
      console.error('시스템 설정 저장 실패:', error);
      setMessage({ type: 'error', text: '저장 중 오류가 발생했습니다.' });
    } finally {
      setSaving(false);
    }
  };

  const updateRewardSetting = (section: keyof RewardSettings, field: string, value: number) => {
    if (!rewardSettings) return;
    setRewardSettings({
      ...rewardSettings,
      [section]: {
        ...rewardSettings[section],
        [field]: value,
      },
    });
  };

  const updateInvestmentTier = (index: number, field: keyof InvestmentTier, value: number | string | null) => {
    const updated = [...investmentTiers];
    updated[index] = {
      ...updated[index],
      [field]: value,
    };
    setInvestmentTiers(updated);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">시스템 설정</h1>
          <p className="text-gray-400 mt-1">보상 플랜 및 투자 등급 설정을 관리합니다.</p>
        </div>
      </div>

      {/* 메시지 */}
      {message && (
        <div
          className={`p-4 rounded-lg border ${message.type === 'success'
            ? 'bg-green-900/20 text-green-200 border-green-800'
            : 'bg-red-900/20 text-red-200 border-red-800'
            }`}
        >
          {message.text}
        </div>
      )}

      {/* 탭 */}
      <div className="flex gap-2 border-b border-gray-800">
        <button
          onClick={() => setActiveTab('reward')}
          className={`px-4 py-2 font-medium transition-colors ${activeTab === 'reward'
            ? 'text-[#137fec] border-b-2 border-[#137fec]'
            : 'text-gray-400 hover:text-gray-300'
            }`}
        >
          보상 설정
        </button>
        <button
          onClick={() => setActiveTab('investment')}
          className={`px-4 py-2 font-medium transition-colors ${activeTab === 'investment'
            ? 'text-[#137fec] border-b-2 border-[#137fec]'
            : 'text-gray-400 hover:text-gray-300'
            }`}
        >
          투자 등급 설정
        </button>
        <button
          onClick={() => setActiveTab('system')}
          className={`px-4 py-2 font-medium transition-colors ${activeTab === 'system'
            ? 'text-[#137fec] border-b-2 border-[#137fec]'
            : 'text-gray-400 hover:text-gray-300'
            }`}
        >
          기본 설정
        </button>
      </div>

      {/* 보상 설정 */}
      {activeTab === 'reward' && rewardSettings && (
        <div className="space-y-6">
          {/* 추천 보너스 */}
          <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-white">추천 보너스</h2>
                <p className="text-sm text-gray-400 mt-1">
                  {rewardSettings.referralBonus.description}
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  보너스 비율 (%)
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="100"
                    value={rewardSettings.referralBonus.rate * 100}
                    onChange={(e) =>
                      updateRewardSetting('referralBonus', 'rate', parseFloat(e.target.value) / 100)
                    }
                    className="flex-1 px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                  <span className="text-gray-400">%</span>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  현재: {(rewardSettings.referralBonus.rate * 100).toFixed(2)}%
                </p>
              </div>
            </div>
          </div>

          {/* 매칭 보너스 */}
          <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-white">매칭 보너스</h2>
                <p className="text-sm text-gray-400 mt-1">
                  {rewardSettings.matchingBonus.description}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  1대 보너스 비율 (%)
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="100"
                    value={rewardSettings.matchingBonus.generation1 * 100}
                    onChange={(e) =>
                      updateRewardSetting('matchingBonus', 'generation1', parseFloat(e.target.value) / 100)
                    }
                    className="flex-1 px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                  <span className="text-gray-400">%</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  2~4대 보너스 비율 (%)
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="100"
                    value={rewardSettings.matchingBonus.generation2to4 * 100}
                    onChange={(e) =>
                      updateRewardSetting('matchingBonus', 'generation2to4', parseFloat(e.target.value) / 100)
                    }
                    className="flex-1 px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                  <span className="text-gray-400">%</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  5~8대 보너스 비율 (%)
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="100"
                    value={rewardSettings.matchingBonus.generation5to8 * 100}
                    onChange={(e) =>
                      updateRewardSetting('matchingBonus', 'generation5to8', parseFloat(e.target.value) / 100)
                    }
                    className="flex-1 px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                  <span className="text-gray-400">%</span>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  9~12대 보너스 비율 (%)
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="100"
                    value={rewardSettings.matchingBonus.generation9to12 * 100}
                    onChange={(e) =>
                      updateRewardSetting('matchingBonus', 'generation9to12', parseFloat(e.target.value) / 100)
                    }
                    className="flex-1 px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                  <span className="text-gray-400">%</span>
                </div>
              </div>
            </div>
          </div>

          {/* 리더십 보너스 */}
          <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-white">리더십 보너스</h2>
                <p className="text-sm text-gray-400 mt-1">
                  {rewardSettings.leadershipBonus.description}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {[1, 2, 3, 4, 5].map((rank) => (
                <div key={rank}>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Rank {rank} 보너스 비율 (%)
                  </label>
                  <div className="flex items-center gap-4">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      max="100"
                      value={(rewardSettings.leadershipBonus[`rank${rank}` as keyof typeof rewardSettings.leadershipBonus] as number) * 100}
                      onChange={(e) =>
                        updateRewardSetting('leadershipBonus', `rank${rank}`, parseFloat(e.target.value) / 100)
                      }
                      className="flex-1 px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                    />
                    <span className="text-gray-400">%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 저장 버튼 */}
          <div className="flex justify-end">
            <button
              onClick={handleRewardSettingsSave}
              disabled={saving}
              className="px-6 py-2 bg-[#137fec] text-white rounded-lg font-medium hover:bg-[#0f6bc7] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? '저장 중...' : '보상 설정 저장'}
            </button>
          </div>
        </div>
      )}

      {/* 투자 등급 설정 */}
      {activeTab === 'investment' && (
        <div className="space-y-6">
          <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
            <div className="mb-4">
              <h2 className="text-xl font-bold text-white">투자 등급별 설정</h2>
              <p className="text-sm text-gray-400 mt-1">
                투자 금액 구간별 일일 수익률 및 매칭 보너스 깊이를 설정합니다.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700 bg-[#111a22]">
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">등급</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">최소 금액</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">최대 금액</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">일일 수익률 (%)</th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">매칭 깊이</th>
                  </tr>
                </thead>
                <tbody>
                  {investmentTiers.map((tier, index) => (
                    <tr key={tier.tier} className="border-b border-gray-700 hover:bg-[#111a22]">
                      <td className="py-3 px-4">
                        <div className="font-medium text-white">{tier.label}</div>
                        <div className="text-xs text-gray-400">{tier.description}</div>
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          min="0"
                          value={tier.minAmount}
                          onChange={(e) => updateInvestmentTier(index, 'minAmount', parseFloat(e.target.value))}
                          className="w-24 px-3 py-1 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                        />
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          min="0"
                          value={tier.maxAmount || ''}
                          onChange={(e) =>
                            updateInvestmentTier(index, 'maxAmount', e.target.value ? parseFloat(e.target.value) : null)
                          }
                          placeholder="무제한"
                          className="w-24 px-3 py-1 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                        />
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            step="0.0001"
                            min="0"
                            max="1"
                            value={tier.dailyRate * 100}
                            onChange={(e) => updateInvestmentTier(index, 'dailyRate', parseFloat(e.target.value) / 100)}
                            className="w-24 px-3 py-1 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                          />
                          <span className="text-gray-400">%</span>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <input
                          type="number"
                          min="0"
                          max="12"
                          value={tier.matchingDepth}
                          onChange={(e) => updateInvestmentTier(index, 'matchingDepth', parseInt(e.target.value))}
                          className="w-24 px-3 py-1 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex justify-end mt-6">
              <button
                onClick={handleInvestmentTiersSave}
                disabled={saving}
                className="px-6 py-2 bg-[#137fec] text-white rounded-lg font-medium hover:bg-[#0f6bc7] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {saving ? '저장 중...' : '투자 등급 설정 저장'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 시스템 설정 */}
      {activeTab === 'system' && (
        <div className="space-y-6">
          <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
            <div className="mb-4">
              <h2 className="text-xl font-bold text-white">입금 계좌 설정</h2>
              <p className="text-sm text-gray-400 mt-1">
                사용자가 투자 시 입금할 USDT 지갑 주소를 설정합니다.
              </p>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  USDT 입금 주소 (TRC20)
                </label>
                <input
                  type="text"
                  value={systemSettings.usdtAddress}
                  onChange={(e) => setSystemSettings({ ...systemSettings, usdtAddress: e.target.value })}
                  placeholder="T..."
                  className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  MSUO 총 발행량
                </label>
                <input
                  type="text"
                  value={systemSettings.upcTotalSupply}
                  onChange={(e) => setSystemSettings({ ...systemSettings, upcTotalSupply: e.target.value })}
                  placeholder="10000000000"
                  className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                />
                <p className="text-xs text-gray-500 mt-1">
                  총 발행량: {parseInt(systemSettings.upcTotalSupply || '0').toLocaleString()}개 (100억개)
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  MSUO 시작가 (USDT)
                </label>
                <input
                  type="number"
                  step="0.00000001"
                  value={systemSettings.upcInitialPrice}
                  onChange={(e) => setSystemSettings({ ...systemSettings, upcInitialPrice: e.target.value })}
                  placeholder="0.00010"
                  className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                />
                <p className="text-xs text-gray-500 mt-1">
                  시작가: ${parseFloat(systemSettings.upcInitialPrice || '0').toFixed(8)} USDT
                </p>
              </div>
            </div>

            {/* 거래 봇 설정 */}
            <div className="mt-6 pt-6 border-t border-gray-700">
              <div className="mb-4">
                <h2 className="text-xl font-bold text-white">거래 봇 설정</h2>
                <p className="text-sm text-gray-400 mt-1">
                  가격 범위 내에서 자동으로 매수/매도를 처리하는 봇을 설정합니다.
                </p>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="flex items-center gap-2 mb-2">
                    <input
                      type="checkbox"
                      checked={systemSettings.exchangeBotEnabled === 'true'}
                      onChange={(e) => setSystemSettings({ ...systemSettings, exchangeBotEnabled: e.target.checked ? 'true' : 'false' })}
                      className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                    />
                    <span className="text-sm font-medium text-gray-300">거래 봇 활성화</span>
                  </label>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    최저가 (USDT)
                  </label>
                  <input
                    type="number"
                    step="0.00000001"
                    value={systemSettings.exchangeBotMinPrice}
                    onChange={(e) => setSystemSettings({ ...systemSettings, exchangeBotMinPrice: e.target.value })}
                    placeholder="0.00005"
                    className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    최고가 (USDT)
                  </label>
                  <input
                    type="number"
                    step="0.00000001"
                    value={systemSettings.exchangeBotMaxPrice}
                    onChange={(e) => setSystemSettings({ ...systemSettings, exchangeBotMaxPrice: e.target.value })}
                    placeholder="0.00015"
                    className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    스프레드 (USDT)
                  </label>
                  <input
                    type="number"
                    step="0.00000001"
                    value={systemSettings.exchangeBotSpread}
                    onChange={(e) => setSystemSettings({ ...systemSettings, exchangeBotSpread: e.target.value })}
                    placeholder="0.00001"
                    className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    봇이 사용자 주문 가격과의 차이 (가격 차이)
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    봇 주문 수량 (MSUO)
                  </label>
                  <input
                    type="number"
                    step="1"
                    value={systemSettings.exchangeBotOrderAmount}
                    onChange={(e) => setSystemSettings({ ...systemSettings, exchangeBotOrderAmount: e.target.value })}
                    placeholder="1000"
                    className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    봇이 한 번에 생성할 주문 수량
                  </p>
                </div>
              </div>
            </div>
            <div className="flex justify-end mt-6">
              <button
                onClick={handleSystemSettingsSave}
                disabled={saving}
                className="px-6 py-2 bg-[#137fec] text-white rounded-lg font-medium hover:bg-[#0f6bc7] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {saving ? '저장 중...' : '설정 저장'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
