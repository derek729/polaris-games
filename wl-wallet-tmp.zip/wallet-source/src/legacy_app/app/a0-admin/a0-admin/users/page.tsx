'use client'

import { useEffect, useState } from 'react'
import { UserPlus, Users } from 'lucide-react'
import CreateAdminModal from '@/components/admin/CreateAdminModal'
import CreateUserModal from '@/components/admin/CreateUserModal'
import UpdateRelationsModal from '@/components/admin/UpdateRelationsModal'
import UpdateUsernameModal from '@/components/admin/UpdateUsernameModal'
import DeleteUserModal from '@/components/admin/DeleteUserModal'
import ViewPasswordModal from '@/components/admin/ViewPasswordModal'
import ManualRewardModal from '@/components/admin/ManualRewardModal'
import { useI18n } from '@/lib/i18n/context'

interface User {
  id: string
  username: string
  email: string
  walletAddress?: string
  rank: number
  totalInvestment: number
  personalCoin: number
  status: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED'
  isActive: boolean
  createdAt: string
  updatedAt: string
  referrerId?: string
  referrer?: {
    username: string
    referralCode?: string
  }
  sponsorId?: string
  sponsor?: {
    username: string
    referralCode?: string
  }
  _count: {
    other_users_users_referrerIdTousers: number
    investments: number
    reward_logs: number
  }
}

interface UsersResponse {
  ok: boolean
  data: {
    users: User[]
    pagination: {
      currentPage: number
      totalPages: number
      totalCount: number
      limit: number
      hasNext: boolean
      hasPrev: boolean
    }
  }
}

export default function UsersPage() {
  const { t, language } = useI18n()
  const [users, setUsers] = useState<User[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalCount: 0,
    limit: 20,
    hasNext: false,
    hasPrev: false,
  })

  // 필터링 상태
  const [filters, setFilters] = useState({
    status: '',
    rank: '',
    search: '',
  })

  // 액션 로딩 상태
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  
  // 관리자 추가 모달 상태
  const [isCreateAdminModalOpen, setIsCreateAdminModalOpen] = useState(false)
  
  // 회원 추가 모달 상태
  const [isCreateUserModalOpen, setIsCreateUserModalOpen] = useState(false)
  
  // 추천인/후원인 변경 모달 상태
  const [updateRelationsModal, setUpdateRelationsModal] = useState<{
    isOpen: boolean
    userId: string
    referrer?: { username: string; referralCode?: string } | null
    sponsor?: { username: string; referralCode?: string } | null
  }>({
    isOpen: false,
    userId: '',
  })

  // 사용자명 변경 모달 상태
  const [updateUsernameModal, setUpdateUsernameModal] = useState<{
    isOpen: boolean
    userId: string
    username: string
  }>({
    isOpen: false,
    userId: '',
    username: '',
  })

  // 사용자 삭제 모달 상태
  const [deleteUserModal, setDeleteUserModal] = useState<{
    isOpen: boolean
    userId: string
    username: string
  }>({
    isOpen: false,
    userId: '',
    username: '',
  })

  // 비밀번호 확인 모달 상태
  const [viewPasswordModal, setViewPasswordModal] = useState<{
    isOpen: boolean
    userId: string
    username: string
  }>({
    isOpen: false,
    userId: '',
    username: '',
  })

  // 수동 보상 지급 모달 상태
  const [manualRewardModal, setManualRewardModal] = useState<{
    isOpen: boolean
    userId: string
    username: string
    currentBalance?: number
  }>({
    isOpen: false,
    userId: '',
    username: '',
    currentBalance: 0,
  })

  const fetchUsers = async () => {
    try {
      setIsLoading(true)
      const params = new URLSearchParams({
        page: pagination.currentPage.toString(),
        limit: pagination.limit.toString(),
        ...(filters.status && { status: filters.status }),
        ...(filters.rank && { rank: filters.rank }),
        ...(filters.search && { search: filters.search }),
      })

      const response = await fetch(`/api/admin/users?${params}`)
      if (response.ok) {
        const data: UsersResponse = await response.json()
        setUsers(data.data.users)
        setPagination(data.data.pagination)
      } else {
        const errorData = await response.json().catch(() => ({}))
        console.error('사용자 목록 조회 실패:', response.status, errorData)
        alert(`사용자 목록 조회 실패: ${errorData.error || response.statusText}`)
      }
    } catch (error) {
      console.error('사용자 목록 조회 실패:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleStatusChange = async (userId: string, action: 'suspend' | 'activate') => {
    try {
      setActionLoading(userId)
      const endpoint = action === 'suspend' ? 'suspend' : 'activate'
      const response = await fetch(`/api/admin/users/${userId}/${endpoint}`, {
        method: 'POST',
      })

      if (response.ok) {
        fetchUsers() // 목록 새로고침
      } else {
        alert('상태 변경에 실패했습니다.')
      }
    } catch (error) {
      console.error('상태 변경 실패:', error)
      alert('상태 변경 중 오류가 발생했습니다.')
    } finally {
      setActionLoading(null)
    }
  }

  useEffect(() => {
    fetchUsers()
  }, [pagination.currentPage, filters.status, filters.rank, filters.search])

  const formatCurrency = (amount: number) => {
    return `${amount.toLocaleString('ko-KR', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })} MSUO`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ko-KR')
  }

  const getStatusBadge = (status: string, isActive: boolean) => {
    if (!isActive) {
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-500/20 text-gray-400 border border-gray-500/50">
          비활성
        </span>
      )
    }

    const statusConfig = {
      ACTIVE: { label: '활성', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      INACTIVE: { label: '비활성', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' },
      SUSPENDED: { label: '정지', className: 'bg-red-500/20 text-red-400 border border-red-500/50' },
    }

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.ACTIVE

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    )
  }

  const getRankBadge = (rank: number) => {
    const rankConfig = {
      1: { label: '브론즈', className: 'bg-gray-500/20 text-gray-400 border border-gray-500/50' },
      2: { label: '실버', className: 'bg-green-500/20 text-green-400 border border-green-500/50' },
      3: { label: '골드', className: 'bg-blue-500/20 text-blue-400 border border-blue-500/50' },
      4: { label: '플래티넘', className: 'bg-purple-500/20 text-purple-400 border border-purple-500/50' },
      5: { label: '다이아몬드', className: 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50' },
    }

    const config = rankConfig[rank as keyof typeof rankConfig] || rankConfig[1]

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${config.className}`}>
        {config.label}
      </span>
    )
  }

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination(prev => ({ ...prev, currentPage: newPage }))
    }
  }

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }))
    setPagination(prev => ({ ...prev, currentPage: 1 })) // 필터 변경시 첫 페이지로
  }

  const clearFilters = () => {
    setFilters({ status: '', rank: '', search: '' })
    setPagination(prev => ({ ...prev, currentPage: 1 }))
  }

  if (isLoading && users.length === 0) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-[#1e293b] rounded w-48 mb-6"></div>
          <div className="bg-[#1e293b] rounded-lg border border-white/10 overflow-hidden">
            <div className="h-16 bg-white/5"></div>
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-16 bg-white/5 border-t border-white/10"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">{t.admin.users.title}</h1>
          <p className="text-gray-400 mt-1">
            {language === 'ko' 
              ? `전체 사용자 ${formatNumber(pagination.totalCount)}명`
              : `Total Users: ${formatNumber(pagination.totalCount)}`}
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setIsCreateUserModalOpen(true)}
            className="flex items-center gap-2 rounded-lg bg-green-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-green-700 transition-colors"
          >
            <Users className="h-4 w-4" />
            {language === 'ko' ? '회원 추가' : 'Add User'}
          </button>
          <button
            onClick={() => setIsCreateAdminModalOpen(true)}
            className="flex items-center gap-2 rounded-lg bg-[#137fec] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#137fec]/90 transition-colors"
          >
            <UserPlus className="h-4 w-4" />
            {t.admin.users.addAdmin}
          </button>
        </div>
      </div>

      {/* 검색 및 필터 */}
      <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.users.search}</label>
            <input
              type="text"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              placeholder={language === 'ko' ? '사용자명, 이메일, 지갑주소 검색' : 'Search by username, email, wallet address'}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.users.status}</label>
            <select
              value={filters.status}
              onChange={(e) => handleFilterChange('status', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="">{t.admin.users.all}</option>
              <option value="ACTIVE">{t.admin.users.active}</option>
              <option value="INACTIVE">{t.admin.users.inactive}</option>
              <option value="SUSPENDED">{t.admin.users.suspended}</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.users.rank}</label>
            <select
              value={filters.rank}
              onChange={(e) => handleFilterChange('rank', e.target.value)}
              className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            >
              <option value="">{t.admin.users.all}</option>
              <option value="1">{language === 'ko' ? '브론즈' : 'Bronze'}</option>
              <option value="2">{language === 'ko' ? '실버' : 'Silver'}</option>
              <option value="3">{language === 'ko' ? '골드' : 'Gold'}</option>
              <option value="4">{language === 'ko' ? '플래티넘' : 'Platinum'}</option>
              <option value="5">{language === 'ko' ? '다이아몬드' : 'Diamond'}</option>
            </select>
          </div>
        </div>

        {(filters.status || filters.rank || filters.search) && (
          <div className="mt-4 flex justify-end">
            <button
              onClick={clearFilters}
              className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors"
            >
              {t.admin.users.filterReset}
            </button>
          </div>
        )}
      </div>

      {/* 사용자 목록 테이블 */}
      <div className="bg-[#1e293b] border border-white/10 rounded-lg overflow-hidden">
        <div className="overflow-x-auto -mx-2 sm:mx-0">
          <table className="min-w-full divide-y divide-white/10 min-w-[800px]">
            <thead className="bg-white/5">
              <tr>
                <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {language === 'ko' ? '사용자' : 'User'}
                </th>
                <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.users.status}
                </th>
                <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.users.rank}
                </th>
                <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.users.totalInvestment}
                </th>
                <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.users.coinBalance}
                </th>
                <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.users.referrer}
                </th>
                <th className="px-3 sm:px-6 py-2 sm:py-3 text-left text-[10px] sm:text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.users.joinDate}
                </th>
                <th className="px-3 sm:px-6 py-2 sm:py-3 text-right text-[10px] sm:text-xs font-medium text-gray-300 uppercase tracking-wider">
                  {t.admin.users.actions}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-3 sm:px-6 py-2 sm:py-4">
                    <div className="min-w-0">
                      <div className="text-xs sm:text-sm font-medium text-white break-words">{user.username}</div>
                      <div className="text-xs sm:text-sm text-gray-400 break-words">{user.email}</div>
                      {user.walletAddress && (
                        <div className="text-[10px] sm:text-xs text-gray-500 truncate max-w-[150px] sm:max-w-[200px]">
                          {user.walletAddress}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-3 sm:px-6 py-2 sm:py-4">
                    {getStatusBadge(user.status, user.isActive)}
                  </td>
                  <td className="px-3 sm:px-6 py-2 sm:py-4">
                    {getRankBadge(user.rank)}
                  </td>
                  <td className="px-3 sm:px-6 py-2 sm:py-4 text-xs sm:text-sm font-medium text-white break-words">
                    {formatCurrency(user.totalInvestment)}
                    <div className="text-[10px] sm:text-xs text-gray-400">
                      {formatNumber(user._count.investments)}건
                    </div>
                  </td>
                  <td className="px-3 sm:px-6 py-2 sm:py-4 text-xs sm:text-sm font-medium text-white break-words">
                    {formatCurrency(user.personalCoin)}
                  </td>
                  <td className="px-3 sm:px-6 py-2 sm:py-4 text-xs sm:text-sm text-white break-words">
                    {formatNumber(user._count.referredUsers)}명
                    {user.referrer && (
                      <div className="text-[10px] sm:text-xs text-gray-400 break-words">
                        추천인: {user.other_users_users_referrerIdTousers.username}
                      </div>
                    )}
                    {user.sponsor && (
                      <div className="text-[10px] sm:text-xs text-gray-400 break-words">
                        후원인: {user.other_users_users_sponsorIdTousers.username}
                      </div>
                    )}
                  </td>
                  <td className="px-3 sm:px-6 py-2 sm:py-4 text-xs sm:text-sm text-white break-words">
                    {formatDate(user.createdAt)}
                  </td>
                  <td className="px-3 sm:px-6 py-2 sm:py-4 text-right text-xs sm:text-sm font-medium">
                    <div className="flex items-center justify-end space-x-1 sm:space-x-2 flex-wrap gap-1">
                      <button
                        onClick={() => setViewPasswordModal({
                          isOpen: true,
                          userId: user.id,
                          username: user.username,
                        })}
                        className="text-purple-400 hover:text-purple-300 text-[10px] sm:text-xs"
                        title={language === 'ko' ? '비밀번호 확인' : 'View Password Info'}
                      >
                        {language === 'ko' ? '비밀번호' : 'Password'}
                      </button>
                      <button
                        onClick={() => setUpdateUsernameModal({
                          isOpen: true,
                          userId: user.id,
                          username: user.username,
                        })}
                        className="text-blue-400 hover:text-blue-300 text-[10px] sm:text-xs"
                        title={language === 'ko' ? '사용자명 변경' : 'Change Username'}
                      >
                        {language === 'ko' ? '이름변경' : 'Username'}
                      </button>
                      <button
                        onClick={() => setUpdateRelationsModal({
                          isOpen: true,
                          userId: user.id,
                          other_users_users_referrerIdTousers: user.referrer || null,
                          other_users_users_sponsorIdTousers: user.sponsor || null,
                        })}
                        className="text-yellow-400 hover:text-yellow-300 text-[10px] sm:text-xs"
                        title={language === 'ko' ? '추천인/후원인 변경' : 'Update Referrer/Sponsor'}
                      >
                        {language === 'ko' ? '관계변경' : 'Relations'}
                      </button>
                      <button
                        onClick={() => setManualRewardModal({
                          isOpen: true,
                          userId: user.id,
                          username: user.username,
                          currentBalance: user.personalCoin,
                        })}
                        className="text-emerald-400 hover:text-emerald-300 text-[10px] sm:text-xs"
                        title={language === 'ko' ? '수동 보상 지급' : 'Manual Reward Payment'}
                      >
                        {language === 'ko' ? '보상지급' : 'Reward'}
                      </button>
                      <a
                        href={`/a0-admin/users/${user.id}`}
                        className="text-[#137fec] hover:text-[#137fec]/80"
                      >
                        {t.admin.users.detail}
                      </a>

                      {user.isActive && user.status === 'ACTIVE' ? (
                        <button
                          onClick={() => handleStatusChange(user.id, 'suspend')}
                          disabled={actionLoading === user.id}
                          className="text-red-400 hover:text-red-300 disabled:opacity-50"
                        >
                          {actionLoading === user.id 
                            ? (language === 'ko' ? '처리중...' : 'Processing...')
                            : t.admin.users.suspend}
                        </button>
                      ) : (
                        <button
                          onClick={() => handleStatusChange(user.id, 'activate')}
                          disabled={actionLoading === user.id}
                          className="text-green-400 hover:text-green-300 disabled:opacity-50"
                        >
                          {actionLoading === user.id 
                            ? (language === 'ko' ? '처리중...' : 'Processing...')
                            : t.admin.users.activate}
                        </button>
                      )}
                      <button
                        onClick={() => setDeleteUserModal({
                          isOpen: true,
                          userId: user.id,
                          username: user.username,
                        })}
                        className="text-red-500 hover:text-red-400 text-[10px] sm:text-xs font-semibold"
                        title={language === 'ko' ? '사용자 삭제' : 'Delete User'}
                      >
                        {language === 'ko' ? '삭제' : 'Delete'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {users.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <svg className="mx-auto h-12 w-12 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
            <h3 className="mt-2 text-sm font-medium text-white">{t.admin.users.noUsers}</h3>
            <p className="mt-1 text-sm text-gray-400">{t.admin.users.noUsersFiltered}</p>
          </div>
        )}
      </div>

      {/* 페이지네이션 */}
      {pagination.totalPages > 1 && (
        <div className="flex items-center justify-between bg-[#1e293b] px-6 py-3 rounded-lg border border-white/10">
          <div className="flex-1 flex justify-between sm:hidden">
            <button
              onClick={() => handlePageChange(pagination.currentPage - 1)}
              disabled={!pagination.hasPrev}
              className="relative inline-flex items-center px-4 py-2 border border-white/10 text-sm font-medium rounded-md text-white bg-white/5 hover:bg-white/10 disabled:opacity-50"
            >
              이전
            </button>
            <button
              onClick={() => handlePageChange(pagination.currentPage + 1)}
              disabled={!pagination.hasNext}
              className="ml-3 relative inline-flex items-center px-4 py-2 border border-white/10 text-sm font-medium rounded-md text-white bg-white/5 hover:bg-white/10 disabled:opacity-50"
            >
              다음
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-300">
                <span className="font-medium">
                  {(pagination.currentPage - 1) * pagination.limit + 1}
                </span>
                {' '}
                부터{' '}
                <span className="font-medium">
                  {Math.min(pagination.currentPage * pagination.limit, pagination.totalCount)}
                </span>
                {' '}
                까지 / 총{' '}
                <span className="font-medium">{formatNumber(pagination.totalCount)}</span>
                명
              </p>
            </div>
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                <button
                  onClick={() => handlePageChange(pagination.currentPage - 1)}
                  disabled={!pagination.hasPrev}
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-white/10 bg-white/5 text-sm font-medium text-white hover:bg-white/10 disabled:opacity-50"
                >
                  이전
                </button>

                {/* 페이지 번호 */}
                {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                  let pageNum
                  if (pagination.totalPages <= 5) {
                    pageNum = i + 1
                  } else if (pagination.currentPage <= 3) {
                    pageNum = i + 1
                  } else if (pagination.currentPage >= pagination.totalPages - 2) {
                    pageNum = pagination.totalPages - 4 + i
                  } else {
                    pageNum = pagination.currentPage - 2 + i
                  }

                  return (
                    <button
                      key={pageNum}
                      onClick={() => handlePageChange(pageNum)}
                      className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                        pageNum === pagination.currentPage
                          ? 'z-10 bg-[#137fec]/20 border-[#137fec] text-[#137fec]'
                          : 'bg-white/5 border-white/10 text-white hover:bg-white/10'
                      }`}
                    >
                      {pageNum}
                    </button>
                  )
                })}

                <button
                  onClick={() => handlePageChange(pagination.currentPage + 1)}
                  disabled={!pagination.hasNext}
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-white/10 bg-white/5 text-sm font-medium text-white hover:bg-white/10 disabled:opacity-50"
                >
                  다음
                </button>
              </nav>
            </div>
          </div>
        </div>
      )}

      {/* 회원 추가 모달 */}
      <CreateUserModal
        isOpen={isCreateUserModalOpen}
        onClose={() => setIsCreateUserModalOpen(false)}
        onSuccess={() => {
          fetchUsers(); // 목록 새로고침
        }}
      />

      {/* 관리자 추가 모달 */}
      <CreateAdminModal
        isOpen={isCreateAdminModalOpen}
        onClose={() => setIsCreateAdminModalOpen(false)}
        onSuccess={() => {
          fetchUsers(); // 목록 새로고침
        }}
      />

      {/* 추천인/후원인 변경 모달 */}
      <UpdateRelationsModal
        isOpen={updateRelationsModal.isOpen}
        onClose={() => setUpdateRelationsModal({ isOpen: false, userId: '' })}
        userId={updateRelationsModal.userId}
        currentReferrer={updateRelationsModal.referrer}
        currentSponsor={updateRelationsModal.sponsor}
        onSuccess={() => {
          fetchUsers(); // 목록 새로고침
        }}
      />

      {/* 사용자명 변경 모달 */}
      <UpdateUsernameModal
        isOpen={updateUsernameModal.isOpen}
        userId={updateUsernameModal.userId}
        currentUsername={updateUsernameModal.username}
        onClose={() => setUpdateUsernameModal({ isOpen: false, userId: '', username: '' })}
        onSuccess={() => {
          setUpdateUsernameModal({ isOpen: false, userId: '', username: '' })
          fetchUsers()
        }}
      />

      {/* 사용자 삭제 모달 */}
      <DeleteUserModal
        isOpen={deleteUserModal.isOpen}
        userId={deleteUserModal.userId}
        username={deleteUserModal.username}
        onClose={() => setDeleteUserModal({ isOpen: false, userId: '', username: '' })}
        onSuccess={() => {
          setDeleteUserModal({ isOpen: false, userId: '', username: '' })
          fetchUsers()
        }}
      />

      {/* 비밀번호 정보 확인 모달 */}
      <ViewPasswordModal
        isOpen={viewPasswordModal.isOpen}
        onClose={() => setViewPasswordModal({ isOpen: false, userId: '', username: '' })}
        userId={viewPasswordModal.userId}
        username={viewPasswordModal.username}
        onSuccess={() => {
          fetchUsers()
        }}
      />

      {/* 수동 보상 지급 모달 */}
      <ManualRewardModal
        isOpen={manualRewardModal.isOpen}
        onClose={() => setManualRewardModal({ isOpen: false, userId: '', username: '', currentBalance: 0 })}
        userId={manualRewardModal.userId}
        username={manualRewardModal.username}
        currentBalance={manualRewardModal.currentBalance}
        onSuccess={() => {
          setManualRewardModal({ isOpen: false, userId: '', username: '', currentBalance: 0 })
          fetchUsers()
        }}
      />
    </div>
  )
}

function formatNumber(num: number): string {
  return new Intl.NumberFormat('ko-KR').format(num)
}