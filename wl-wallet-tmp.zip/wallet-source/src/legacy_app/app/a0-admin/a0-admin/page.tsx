'use client'

import NewAdminDashboard from './NewAdminDashboard'

interface DashboardData {
  overview: {
    totalUsers: number
    activeUsers: number
    todayUsers: number
    totalInvestment: number
    totalInvestmentCount: number
    activeInvestments: number
    monthlyInvestment: number
    investmentGrowthRate: number
    todayInvestment: number
    totalWithdrawal: number
    pendingWithdrawals: number
    approvedWithdrawals: number
    rejectedWithdrawals: number
    todayWithdrawal: number
    totalRewards: number
    monthlyRewards: number
    todayRewards: number
  }
  rankDistribution: Array<{
    rank: number
    count: number
  }>
  recentActivities: {
    newUsers: Array<{
      id: string
      username: string
      email: string
      rank: number
      totalInvestment: number
      createdAt: string
      referrer?: { username: string }
    }>
    withdrawals: Array<{
      id: string
      amount: number
      status: string
      requestedAt: string
      users: { username: string; email: string }
    }>
  }
  topInvestors: Array<{
    id: string
    username: string
    email: string
    rank: number
    totalInvestment: number
    createdAt: string
    _count: { other_users_users_referrerIdTousers: number; investments: number }
  }>
  systemMetrics: {
    daysSinceLaunch: number
    firstInvestmentDate?: string
    firstWithdrawalDate?: string
    firstRewardDate?: string
  }
}

export default function AdminDashboard() {
  return <NewAdminDashboard />
}

