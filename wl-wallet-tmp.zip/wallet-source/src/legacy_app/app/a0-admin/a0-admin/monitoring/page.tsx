'use client'

import { useEffect, useState, useCallback } from 'react'

interface AnomalyData {
  type: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  count: number
  data: any[]
  message: string
}

interface MonitoringData {
  anomalies: AnomalyData[]
  stats: {
    totalAnomalies: number
    severityCount: {
      low: number
      medium: number
      high: number
      critical: number
    }
    monitoringPeriod: string
    liquidityRatio: number
    lastChecked: string
  }
  systemHealth: {
    liquidityRatio: number
    status: 'healthy' | 'warning'
    message: string
  }
}

export default function MonitoringPage() {
  const [data, setData] = useState<MonitoringData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [hours, setHours] = useState('24')
  const [autoRefresh, setAutoRefresh] = useState(false)
  const [lastRefresh, setLastRefresh] = useState(new Date())

  const fetchMonitoringData = useCallback(async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/admin/monitoring/abnormal?hours=${hours}`)
      if (response.ok) {
        const result = await response.json()
        setData(result.data)
        setLastRefresh(new Date())
      }
    } catch (error) {
      console.error('모니터링 데이터 조회 실패:', error)
    } finally {
      setIsLoading(false)
    }
  }, [hours])

  useEffect(() => {
    fetchMonitoringData()

    let interval: NodeJS.Timeout | undefined
    if (autoRefresh) {
      interval = setInterval(fetchMonitoringData, 30000) // 30초마다 새로고침
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [fetchMonitoringData, autoRefresh])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(num)
  }

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('ko-KR')
  }

  const getSeverityColor = (severity: string) => {
    const colors = {
      low: 'bg-gray-500/20 text-gray-400 border-gray-500/50',
      medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
      high: 'bg-orange-500/20 text-orange-400 border-orange-500/50',
      critical: 'bg-red-500/20 text-red-400 border-red-500/50',
    }
    return colors[severity as keyof typeof colors] || colors.low
  }

  const getSeverityIcon = (severity: string) => {
    const icons = {
      low: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      medium: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
        </svg>
      ),
      high: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      critical: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 1H21l-3 6 3 6h-8.5l-1-1H5a2 2 0 01-2-2zm9-13.5V9" />
        </svg>
      ),
    }
    return icons[severity as keyof typeof icons] || icons.low
  }

  const getAnomalyTypeName = (type: string) => {
    const typeNames = {
      large_investment: '대규모 투자',
      frequent_investment: '단시간 다수 투자',
      large_withdrawal: '대규모 출금',
      abnormal_reward: '이상 수당 지급',
      rewards_without_investment: '투자 없는 수당 수령',
      low_liquidity: '유동성 부족',
    }
    return typeNames[type as keyof typeof typeNames] || type
  }

  const renderAnomalyDetails = (anomaly: AnomalyData) => {
    switch (anomaly.type) {
      case 'large_investment':
        return (
          <div className="space-y-2">
            {anomaly.data.map((item: any, index: number) => (
              <div key={index} className="p-3 bg-white/5 rounded-lg border border-white/10">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">{item.users.username}</p>
                    <p className="text-xs text-gray-400">{item.users.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-white">{formatCurrency(item.amount)}</p>
                    <p className="text-xs text-gray-400">Tier {item.investmentTier}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )

      case 'large_withdrawal':
        return (
          <div className="space-y-2">
            {anomaly.data.map((item: any, index: number) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{item.users.username}</p>
                    <p className="text-xs text-gray-500">{item.users.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-gray-900">{formatCurrency(item.amount)}</p>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${
                      item.status === 'PENDING' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50' :
                      item.status === 'APPROVED' ? 'bg-green-500/20 text-green-400 border-green-500/50' :
                      'bg-red-500/20 text-red-400 border-red-500/50'
                    }`}>
                      {item.status === 'PENDING' ? '대기' : item.status === 'APPROVED' ? '승인' : '거절'}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )

      case 'frequent_investment':
        return (
          <div className="space-y-2">
            {anomaly.data.map((item: any, index: number) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">{item.username}</p>
                    <p className="text-xs text-gray-400">{item.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-white">{formatNumber(item.investment_count)}건</p>
                    <p className="text-xs text-gray-400">{formatCurrency(item.total_amount)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )

      case 'abnormal_reward':
        return (
          <div className="space-y-2">
            {anomaly.data.map((item: any, index: number) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">{item.users.username}</p>
                    <p className="text-xs text-gray-400">{item.users.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-white">{formatCurrency(item.amount)}</p>
                    <p className="text-xs text-gray-400">{formatDateTime(item.paidAt)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )

      default:
        return (
          <div className="p-4 bg-white/5 rounded-lg border border-white/10">
            <p className="text-sm text-gray-400">{anomaly.message}</p>
          </div>
        )
    }
  }

  if (isLoading && !data) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-[#1e293b] rounded w-64 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
                <div className="h-4 bg-white/5 rounded mb-4"></div>
                <div className="h-8 bg-white/5 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="p-6">
        <div className="text-center text-gray-400">
          모니터링 데이터를 불러올 수 없습니다.
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">실시간 모니터링</h1>
          <p className="text-gray-400 mt-1">이상 거동 및 시스템 상태를 실시간으로 모니터링합니다.</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="autoRefresh"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="w-4 h-4 text-[#137fec] border-white/10 rounded focus:ring-[#137fec] bg-white/5"
            />
            <label htmlFor="autoRefresh" className="text-sm text-gray-300">
              자동 새로고침 (30초)
            </label>
          </div>
          <select
            value={hours}
            onChange={(e) => setHours(e.target.value)}
            className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
          >
            <option value="1">최근 1시간</option>
            <option value="6">최근 6시간</option>
            <option value="24">최근 24시간</option>
            <option value="72">최근 3일</option>
            <option value="168">최근 7일</option>
          </select>
          <button
            onClick={fetchMonitoringData}
            disabled={isLoading}
            className="px-4 py-2 bg-[#137fec] text-white rounded-lg hover:bg-[#137fec]/90 transition-colors disabled:opacity-50"
          >
            {isLoading ? '조회 중...' : '새로고침'}
          </button>
        </div>
      </div>

      {/* 마지막 업데이트 시간 */}
      <div className="text-sm text-gray-400">
        마지막 업데이트: {formatDateTime(lastRefresh.toISOString())}
      </div>

      {/* 시스템 헬스 상태 */}
      <div className={`p-6 rounded-lg border-2 ${
        data.systemHealth.status === 'healthy'
          ? 'bg-green-500/10 border-green-500/50'
          : 'bg-red-500/10 border-red-500/50'
      }`}>
        <div className="flex items-center space-x-3">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
            data.systemHealth.status === 'healthy'
              ? 'bg-green-500/20 text-green-400'
              : 'bg-red-500/20 text-red-400'
          }`}>
            {data.systemHealth.status === 'healthy' ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            )}
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-white">
              {data.systemHealth.status === 'healthy' ? '시스템 정상' : '시스템 경고'}
            </h3>
            <p className="text-gray-400 mt-1">{data.systemHealth.message}</p>
            <p className="text-sm text-gray-400 mt-2">
              유동성 비율: {data.systemHealth.liquidityRatio.toFixed(1)}%
            </p>
          </div>
        </div>
      </div>

      {/* 통계 요약 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-400">총 이상 감지</p>
              <p className="text-2xl font-bold text-white mt-1">{formatNumber(data.stats.totalAnomalies)}</p>
            </div>
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-yellow-400">중간 등급</p>
              <p className="text-2xl font-bold text-yellow-400 mt-1">{formatNumber(data.stats.severityCount.medium)}</p>
            </div>
            <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-orange-400">높은 등급</p>
              <p className="text-2xl font-bold text-orange-400 mt-1">{formatNumber(data.stats.severityCount.high)}</p>
            </div>
            <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 21v-4m0 0V5a2 2 0 012-2h6.5l1 1H21l-3 6 3 6h-8.5l-1-1H5a2 2 0 01-2-2z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-red-400">심각 등급</p>
              <p className="text-2xl font-bold text-red-400 mt-1">{formatNumber(data.stats.severityCount.critical)}</p>
            </div>
            <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* 이상 거동 상세 정보 */}
      <div className="space-y-4">
        {data.anomalies.length === 0 ? (
          <div className="bg-[#1e293b] p-12 rounded-lg border border-white/10 text-center">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-white mb-2">이상 거동 없음</h3>
            <p className="text-gray-400">최근 {hours}시간 동안 감지된 이상 거동이 없습니다.</p>
          </div>
        ) : (
          data.anomalies.map((anomaly, index) => (
            <div key={index} className="bg-[#1e293b] rounded-lg border border-white/10 overflow-hidden">
              <div className={`p-4 border-b border-white/10 ${getSeverityColor(anomaly.severity)}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={getSeverityColor(anomaly.severity)}>
                      {getSeverityIcon(anomaly.severity)}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">
                        {getAnomalyTypeName(anomaly.type)}
                      </h3>
                      <p className="text-sm text-gray-400 mt-1">{anomaly.message}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getSeverityColor(anomaly.severity)}`}>
                      {anomaly.severity.toUpperCase()}
                    </span>
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-white/10 text-gray-300 border border-white/10">
                      {formatNumber(anomaly.count)}건
                    </span>
                  </div>
                </div>
              </div>
              <div className="p-4">
                {renderAnomalyDetails(anomaly)}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}