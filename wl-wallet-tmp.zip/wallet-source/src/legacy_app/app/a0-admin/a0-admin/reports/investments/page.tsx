'use client'

import { useEffect, useState, useCallback } from 'react'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend,
  AreaChart,
  Area,
} from 'recharts'

interface InvestmentStats {
  summary: {
    totalInvestments: number
    totalAmount: number
    averageAmount: number
    averageDailyRate: number
    maxAmount: number
    minAmount: number
  }
  tierDistribution: Array<{
    tier: number
    count: number
    totalAmount: number
    averageAmount: number
    averageDailyRate: number
  }>
  recentInvestments: Array<{
    id: string
    amount: number
    dailyRate: number
    matchingDepth: number
    investment_tiers: number
    startDate: string
    endDate: string
    isActive: boolean
    users: {
      id: string
      username: string
      email: string
      rank: number
    }
    dailyProfit: number
  }>
  topInvestors: Array<{
    id: string
    username: string
    email: string
    rank: number
    investmentCount: number
    totalInvested: number
    averageInvestment: number
    lastInvestmentDate: string
  }>
  trends: {
    monthlyGrowth: Array<{
      month: string
      count: number
      totalAmount: number
      averageAmount: number
    }>
    dailyVolume: Array<{
      date: string
      count: number
      totalAmount: number
    }>
    rateDistribution: Array<{
      rateCategory: string
      count: number
      totalAmount: number
    }>
  }
  period: {
    startDate: string
    endDate: string
    days: number
  }
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899']

export default function InvestmentStatsPage() {
  const [data, setData] = useState<InvestmentStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [period, setPeriod] = useState('30d')
  const [tier, setTier] = useState<string>('')

  const fetchStats = useCallback(async () => {
    try {
      setIsLoading(true)
      const params = new URLSearchParams({ period })
      if (tier) params.set('tier', tier)

      const response = await fetch(`/api/admin/reports/investments?${params}`)
      if (response.ok) {
        const result = await response.json()
        setData(result.data)
      }
    } catch (error) {
      console.error('투자 통계 조회 실패:', error)
    } finally {
      setIsLoading(false)
    }
  }, [period, tier])

  useEffect(() => {
    fetchStats()
  }, [fetchStats])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(num)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ko-KR')
  }

  const formatDateShort = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ko-KR', { month: 'short', day: 'numeric' })
  }

  const getTierName = (tier: number) => {
    const tierNames = {
      1: '$50-$199',
      2: '$200-$499',
      3: '$500-$999',
      4: '$1000-$4999',
      5: '$5000-$9999',
      6: '$10000+',
    }
    return tierNames[tier as keyof typeof tierNames] || `Tier ${tier}`
  }

  const getRankName = (rank: number) => {
    const rankNames = {
      1: '브론즈',
      2: '실버',
      3: '골드',
      4: '플래티넘',
      5: '다이아몬드',
    }
    return rankNames[rank as keyof typeof rankNames] || `랭크 ${rank}`
  }

  if (isLoading && !data) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-64 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-white p-6 rounded-lg shadow">
                <div className="h-4 bg-gray-200 rounded mb-4"></div>
                <div className="h-8 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="p-6">
        <div className="text-center text-gray-500">
          투자 통계 데이터를 불러올 수 없습니다.
        </div>
      </div>
    )
  }

  // 차트 데이터 준비
  const dailyVolumeData = data.trends.dailyVolume.map(item => ({
    ...item,
    date: formatDateShort(item.date),
    amount: item.totalAmount,
  })).reverse()

  const tierDistributionData = data.tierDistribution.map(item => ({
    name: getTierName(item.tier),
    value: item.totalAmount,
    count: item.count,
  }))

  const rateDistributionData = data.trends.rateDistribution.map(item => ({
    name: item.rateCategory,
    value: item.totalAmount,
    count: item.count,
  }))

  const monthlyGrowthData = data.trends.monthlyGrowth.map(item => ({
    ...item,
    month: formatDate(item.month),
  })).reverse()

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">투자 통계</h1>
          <p className="text-gray-600 mt-1">
            {formatDate(data.period.startDate)} - {formatDate(data.period.endDate)} ({data.period.days}일)
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={tier}
            onChange={(e) => setTier(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">모든 등급</option>
            <option value="1">Tier 1 ($50-$199)</option>
            <option value="2">Tier 2 ($200-$499)</option>
            <option value="3">Tier 3 ($500-$999)</option>
            <option value="4">Tier 4 ($1000-$4999)</option>
            <option value="5">Tier 5 ($5000-$9999)</option>
            <option value="6">Tier 6 ($10000+)</option>
          </select>
          <select
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="7d">최근 7일</option>
            <option value="30d">최근 30일</option>
            <option value="90d">최근 90일</option>
            <option value="1y">최근 1년</option>
          </select>
          <button
            onClick={fetchStats}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            새로고침
          </button>
        </div>
      </div>

      {/* 요약 통계 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <p className="text-sm font-medium text-gray-600">총 투자</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{formatNumber(data.summary.totalInvestments)}</p>
          <p className="text-xs text-gray-500">건</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <p className="text-sm font-medium text-gray-600">총 금액</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{formatCurrency(data.summary.totalAmount)}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <p className="text-sm font-medium text-gray-600">평균 금액</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{formatCurrency(data.summary.averageAmount)}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <p className="text-sm font-medium text-gray-600">평균 이율</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{data.summary.averageDailyRate.toFixed(2)}%</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <p className="text-sm font-medium text-gray-600">최대 금액</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{formatCurrency(data.summary.maxAmount)}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <p className="text-sm font-medium text-gray-600">최소 금액</p>
          <p className="text-xl font-bold text-gray-900 mt-1">{formatCurrency(data.summary.minAmount)}</p>
        </div>
      </div>

      {/* 차트 영역 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 일별 투자량 추세 */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">일별 투자량 추세</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={dailyVolumeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`} />
              <Tooltip
                formatter={(value: number) => formatCurrency(value)}
                labelFormatter={(label) => `날짜: ${label}`}
              />
              <Area type="monotone" dataKey="amount" stroke="#3B82F6" fill="#93C5FD" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* 월별 성장 추세 */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">월별 성장 추세</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyGrowthData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip
                formatter={(value: number, name: string) => [
                  name === 'count' ? formatNumber(value) : formatCurrency(value),
                  name === 'count' ? '건수' : '금액'
                ]}
              />
              <Legend />
              <Bar yAxisId="left" dataKey="count" fill="#10B981" name="건수" />
              <Line yAxisId="right" type="monotone" dataKey="totalAmount" stroke="#3B82F6" name="금액" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* 등급별 분포 */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">등급별 투자 분포</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={tierDistributionData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }: any) => `${name || ''} ${((percent || 0) * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {tierDistributionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => formatCurrency(value)} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* 수익률 분포 */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">수익률 분포</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={rateDistributionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip
                formatter={(value: number) => [
                  value > 1000 ? formatCurrency(value) : formatNumber(value),
                  value > 1000 ? '금액' : '건수'
                ]}
              />
              <Bar dataKey="value" fill="#F59E0B" name="금액" />
              <Bar dataKey="count" fill="#EF4444" name="건수" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 등급별 상세 통계 */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">등급별 상세 통계</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">등급</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">금액 범위</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">투자 건수</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">총 금액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">평균 금액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">평균 이율</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {data.tierDistribution.map((tier) => (
                <tr key={tier.tier} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      Tier {tier.tier}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {getTierName(tier.tier)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatNumber(tier.count)}건
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {formatCurrency(tier.totalAmount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatCurrency(tier.averageAmount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {tier.averageDailyRate.toFixed(2)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 상위 투자자 */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">상위 투자자</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">사용자</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">랭크</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">투자 건수</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">총 투자액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">평균 투자액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">마지막 투자일</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {data.topInvestors.map((investor, index) => (
                <tr key={investor.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{investor.username}</div>
                      <div className="text-sm text-gray-500">{investor.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${investor.rank === 1 ? 'bg-gray-100 text-gray-800' :
                        investor.rank === 2 ? 'bg-green-100 text-green-800' :
                        investor.rank === 3 ? 'bg-blue-100 text-blue-800' :
                        investor.rank === 4 ? 'bg-purple-100 text-purple-800' : 'bg-yellow-100 text-yellow-800'}`}>
                      {getRankName(investor.rank)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatNumber(investor.investmentCount)}건
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {formatCurrency(investor.totalInvested)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatCurrency(investor.averageInvestment)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatDate(investor.lastInvestmentDate)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 최신 투자 내역 */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">최신 투자 내역</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">사용자</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">금액</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">이율</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">매칭</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">등급</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">상태</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">일일 수익</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {data.recentInvestments.map((investment) => (
                <tr key={investment.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{investment.users.username}</div>
                      <div className="text-sm text-gray-500">{investment.users.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {formatCurrency(investment.amount)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {investment.dailyRate.toFixed(2)}%
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {investment.matchingDepth}세대
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      Tier {investment.investmentTier}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      investment.isActive
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {investment.isActive ? '활성' : '만료'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-600">
                    {formatCurrency(investment.dailyProfit)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}