'use client'

import { useEffect, useState, useCallback } from 'react'

interface FinancialReport {
  summary: {
    totalUsers: number
    activeUsers: number
    inactiveUsers: number
    totalInvestments: {
      count: number
      amount: number
    }
    activeInvestments: {
      count: number
      amount: number
      avgDailyRate: number
    }
    totalRewards: {
      count: number
      amount: number
    }
    totalWithdrawals: {
      count: number
      amount: number
    }
    systemLiquidity: {
      totalUserBalance: number
      investedAmount: number
      availableRatio: number
    }
  }
  distributions: {
    investment_tiers: Array<{
      tier: number
      count: number
    }>
    ranks: Array<{
      rank: number
      count: number
    }>
    rewardTypes: Array<{
      type: string
      count: number
      amount: number
    }>
    withdrawalStatuses: Array<{
      status: string
      count: number
      amount: number
    }>
  }
  trends: {
    dailyRewards: Array<{
      date: string
      amount: number
      count: number
    }>
    dailyInvestments: Array<{
      date: string
      amount: number
      count: number
    }>
  }
  period: {
    startDate: string
    endDate: string
    days: number
  }
}

export default function ReportsPage() {
  const [data, setData] = useState<FinancialReport | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [period, setPeriod] = useState('30d')
  const [activeTab, setActiveTab] = useState<'overview' | 'trends' | 'distribution'>('overview')

  const fetchReport = useCallback(async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/admin/reports/financial?period=${period}`)
      if (response.ok) {
        const result = await response.json()
        setData(result.data)
      }
    } catch (error) {
      console.error('리포트 조회 실패:', error)
    } finally {
      setIsLoading(false)
    }
  }, [period])

  useEffect(() => {
    fetchReport()
  }, [fetchReport])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ko-KR').format(num)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ko-KR')
  }

  const getRewardTypeName = (type: string) => {
    const typeNames = {
      DAILY: '정기 수익',
      REFERRAL: '추천인 수익',
      MATCHING: '매칭 수익',
      RANK: '랭크 수익',
      TEAM: '팀 매출 수익',
    }
    return typeNames[type as keyof typeof typeNames] || type
  }

  const getTierName = (tier: number) => {
    const tierNames = {
      1: '$50-$199',
      2: '$200-$499',
      3: '$500-$999',
      4: '$1000-$4999',
      5: '$5000-$9999',
      6: '$10000+',
    }
    return tierNames[tier as keyof typeof tierNames] || `Tier ${tier}`
  }

  const getRankName = (rank: number) => {
    const rankNames = {
      1: '브론즈',
      2: '실버',
      3: '골드',
      4: '플래티넘',
      5: '다이아몬드',
    }
    return rankNames[rank as keyof typeof rankNames] || `랭크 ${rank}`
  }

  const getWithdrawalStatusName = (status: string) => {
    const statusNames = {
      PENDING: '대기',
      APPROVED: '승인',
      REJECTED: '거절',
    }
    return statusNames[status as keyof typeof statusNames] || status
  }

  if (isLoading && !data) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-[#1e293b] rounded w-48 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-[#1e293b] p-6 rounded-lg border border-white/10">
                <div className="h-4 bg-white/5 rounded mb-4"></div>
                <div className="h-8 bg-white/5 rounded"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="p-6">
        <div className="text-center text-gray-400">
          리포트 데이터를 불러올 수 없습니다.
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">금융 리포트</h1>
          <p className="text-gray-400 mt-1">
            {formatDate(data.period.startDate)} - {formatDate(data.period.endDate)} ({data.period.days}일)
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
            className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
          >
            <option value="7d">최근 7일</option>
            <option value="30d">최근 30일</option>
            <option value="90d">최근 90일</option>
            <option value="1y">최근 1년</option>
          </select>
          <button
            onClick={fetchReport}
            className="px-4 py-2 bg-[#137fec] text-white rounded-lg hover:bg-[#137fec]/90 transition-colors"
          >
            새로고침
          </button>
        </div>
      </div>

      {/* 탭 네비게이션 */}
      <div className="bg-[#1e293b] rounded-lg border border-white/10">
        <div className="border-b border-white/10">
          <nav className="flex space-x-8 px-6">
            {[
              { key: 'overview', label: '개요' },
              { key: 'trends', label: '추세' },
              { key: 'distribution', label: '분포' },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as any)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.key
                    ? 'border-[#137fec] text-[#137fec]'
                    : 'border-transparent text-gray-400 hover:text-white hover:border-white/30'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* 개요 탭 */}
          {activeTab === 'overview' && (
            <div className="space-y-8">
              {/* 핵심 지표 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">핵심 지표</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-400">총 사용자</p>
                        <p className="text-2xl font-bold text-white mt-1">{formatNumber(data.summary.totalUsers)}</p>
                        <p className="text-xs text-gray-400 mt-2">
                          활성: {formatNumber(data.summary.activeUsers)} ({data.summary.totalUsers > 0 ? Math.round((data.summary.activeUsers / data.summary.totalUsers) * 100) : 0}%)
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                        <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">총 투자</p>
                        <p className="text-2xl font-bold text-gray-900 mt-1">{formatCurrency(data.summary.totalInvestments.amount)}</p>
                        <p className="text-xs text-gray-500 mt-2">
                          총 {formatNumber(data.summary.totalInvestments.count)}건
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                        <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">지급 수당</p>
                        <p className="text-2xl font-bold text-gray-900 mt-1">{formatCurrency(data.summary.totalRewards.amount)}</p>
                        <p className="text-xs text-gray-500 mt-2">
                          {formatNumber(data.summary.totalRewards.count)}건
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
                        <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">총 출금</p>
                        <p className="text-2xl font-bold text-gray-900 mt-1">{formatCurrency(data.summary.totalWithdrawals.amount)}</p>
                        <p className="text-xs text-gray-500 mt-2">
                          {formatNumber(data.summary.totalWithdrawals.count)}건
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                        <svg className="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 시스템 유동성 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">시스템 유동성</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-blue-500/10 p-6 rounded-lg border border-blue-500/20">
                    <p className="text-sm font-medium text-blue-400">사용자 잔고 총액</p>
                    <p className="text-2xl font-bold text-white mt-1">
                      {formatCurrency(data.summary.systemLiquidity.totalUserBalance)}
                    </p>
                  </div>
                  <div className="bg-green-500/10 p-6 rounded-lg border border-green-500/20">
                    <p className="text-sm font-medium text-green-400">총 투자 금액</p>
                    <p className="text-2xl font-bold text-white mt-1">
                      {formatCurrency(data.summary.systemLiquidity.investedAmount)}
                    </p>
                  </div>
                  <div className="bg-purple-500/10 p-6 rounded-lg border border-purple-500/20">
                    <p className="text-sm font-medium text-purple-400">유동성 비율</p>
                    <p className="text-2xl font-bold text-white mt-1">
                      {data.summary.systemLiquidity.availableRatio.toFixed(2)}%
                    </p>
                  </div>
                </div>
              </div>

              {/* 활성 투자 정보 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">활성 투자 정보</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                    <p className="text-sm font-medium text-gray-400">활성 투자 수</p>
                    <p className="text-2xl font-bold text-white mt-1">{formatNumber(data.summary.activeInvestments.count)}</p>
                    <p className="text-sm text-gray-400 mt-2">
                      평균 일이율: {data.summary.activeInvestments.avgDailyRate.toFixed(2)}%
                    </p>
                  </div>
                  <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                    <p className="text-sm font-medium text-gray-400">활성 투자 금액</p>
                    <p className="text-2xl font-bold text-white mt-1">
                      {formatCurrency(data.summary.activeInvestments.amount)}
                    </p>
                    <p className="text-sm text-gray-400 mt-2">
                      평균 투자액: {data.summary.activeInvestments.count > 0 ? formatCurrency(data.summary.activeInvestments.amount / data.summary.activeInvestments.count) : formatCurrency(0)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 추세 탭 */}
          {activeTab === 'trends' && (
            <div className="space-y-8">
              {/* 일별 수당 추세 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">일별 수당 추세</h3>
                <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-white/10">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            날짜
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            수당 금액
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            건수
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {data.trends.dailyRewards.map((reward, index) => (
                          <tr key={index} className="hover:bg-white/5">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatDate(reward.date)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                              {formatCurrency(reward.amount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatNumber(reward.count)}건
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* 일별 투자 추세 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">일별 투자 추세</h3>
                <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-white/10">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            날짜
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            투자 금액
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            건수
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {data.trends.dailyInvestments.map((investment, index) => (
                          <tr key={index} className="hover:bg-white/5">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatDate(investment.date)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                              {formatCurrency(investment.amount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatNumber(investment.count)}건
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 분포 탭 */}
          {activeTab === 'distribution' && (
            <div className="space-y-8">
              {/* 수당 유형 분포 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">수당 유형 분포</h3>
                <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-white/10">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            유형
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            금액
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            건수
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            비율
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {data.distributions.rewardTypes.map((type) => (
                          <tr key={type.type} className="hover:bg-white/5">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                              {getRewardTypeName(type.type)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                              {formatCurrency(type.amount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatNumber(type.count)}건
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {data.summary.totalRewards.amount > 0 ? ((type.amount / data.summary.totalRewards.amount) * 100).toFixed(1) : '0.0'}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* 투자 등급 분포 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">투자 등급 분포</h3>
                <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {data.distributions.investmentTiers.map((tier) => (
                      <div key={tier.tier} className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-400">{getTierName(tier.tier)}</p>
                            <p className="text-lg font-semibold text-white mt-1">
                              {formatNumber(tier.count)}건
                            </p>
                          </div>
                          <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                            <span className="text-blue-400 font-bold">{tier.tier}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 랭크 분포 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">사용자 랭크 분포</h3>
                <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    {data.distributions.ranks.map((rank) => (
                      <div key={rank.rank} className="bg-white/5 p-4 rounded-lg border border-white/10">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-400">{getRankName(rank.rank)}</p>
                            <p className="text-lg font-semibold text-white mt-1">
                              {formatNumber(rank.count)}명
                            </p>
                          </div>
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold
                            ${rank.rank === 1 ? 'bg-gray-500' :
                              rank.rank === 2 ? 'bg-green-500' :
                              rank.rank === 3 ? 'bg-blue-500' :
                              rank.rank === 4 ? 'bg-purple-500' : 'bg-yellow-500'}`}>
                            {rank.rank}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 출금 상태 분포 */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">출금 상태 분포</h3>
                <div className="bg-white/5 p-6 rounded-lg border border-white/10">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-white/10">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            상태
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            금액
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            건수
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                            비율
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {data.distributions.withdrawalStatuses.map((status) => (
                          <tr key={status.status} className="hover:bg-white/5">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${
                                status.status === 'PENDING' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50' :
                                status.status === 'APPROVED' ? 'bg-green-500/20 text-green-400 border-green-500/50' :
                                'bg-red-500/20 text-red-400 border-red-500/50'
                              }`}>
                                {getWithdrawalStatusName(status.status)}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                              {formatCurrency(status.amount)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {formatNumber(status.count)}건
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                              {data.distributions.withdrawalStatuses.length > 0
                                ? ((status.count / data.distributions.withdrawalStatuses.reduce((sum, s) => sum + s.count, 0)) * 100).toFixed(1)
                                : 0}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}