
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface Investment {
    id: string;
    amount: number;
    txHash: string;
    createdAt: string;
    users: {
        username: string;
        email: string;
    };
    investment_tiers: number;
}

export default function PendingInvestmentsPage() {
    const [investments, setInvestments] = useState<Investment[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchInvestments = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/admin/investments/pending');
            const data = await res.json();
            if (data.ok) {
                setInvestments(data.data);
            }
        } catch (e) {
            console.error('Failed to fetch investments:', e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchInvestments();
    }, []);

    const handleAction = async (id: string, action: 'APPROVE' | 'REJECT') => {
        if (!confirm(action === 'APPROVE' ? '이 투자를 승인하시겠습니까?' : '이 투자를 거절하시겠습니까?')) return;

        try {
            const res = await fetch('/api/admin/investments/approve', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ investmentId: id, action })
            });

            const data = await res.json();
            if (data.ok) {
                alert('처리되었습니다.');
                fetchInvestments();
            } else {
                alert(data.error || '처리 실패');
            }
        } catch (e) {
            console.error('Error processing investments:', e);
            alert('오류가 발생했습니다.');
        }
    };

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">투자 승인 대기 목록</h1>
                <Link href="/a0-admin" className="text-blue-500 hover:underline">
                    대시보드로 돌아가기
                </Link>
            </div>

            {loading ? (
                <div className="text-center py-10">로딩 중...</div>
            ) : investments.length === 0 ? (
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-10 text-center text-gray-500">
                    대기 중인 투자 신청이 없습니다.
                </div>
            ) : (
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead className="bg-gray-50 dark:bg-gray-700">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">신청일시</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">사용자</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">금액</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">등급</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">TXID</th>
                                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">관리</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                {investments.map((inv) => (
                                    <tr key={inv.id}>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                            {new Date(inv.createdAt).toLocaleString()}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="text-sm font-medium text-gray-900 dark:text-white">{inv.users.username}</div>
                                            <div className="text-sm text-gray-500 dark:text-gray-400">{inv.users.email}</div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white font-bold">
                                            ${Number(inv.amount).toLocaleString()}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                            Tier {inv.investmentTier}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-500 font-mono max-w-xs truncate" title={inv.txHash}>
                                            {inv.txHash}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                            <button
                                                onClick={() => handleAction(inv.id, 'APPROVE')}
                                                className="text-green-600 hover:text-green-900 bg-green-100 hover:bg-green-200 px-3 py-1 rounded"
                                            >
                                                승인
                                            </button>
                                            <button
                                                onClick={() => handleAction(inv.id, 'REJECT')}
                                                className="text-red-600 hover:text-red-900 bg-red-100 hover:bg-red-200 px-3 py-1 rounded"
                                            >
                                                거절
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
}
