import { redirect } from 'next/navigation';
import { getCurrentAdminUser } from '@/lib/admin-auth';
import GameSharePurchasesAdminClient from './GameSharePurchasesAdminClient';

export const dynamic = 'force-dynamic';

export default async function GameSharePurchasesPendingPage() {
  // 관리자 인증 확인
  const user = await getCurrentAdminUser();
  if (!user) {
    redirect('/a0-admin/login');
  }

  return <GameSharePurchasesAdminClient />;
}

