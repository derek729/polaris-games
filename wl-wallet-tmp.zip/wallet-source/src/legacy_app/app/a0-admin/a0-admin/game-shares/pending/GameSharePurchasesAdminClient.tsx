'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface GameSharePurchase {
  id: string;
  userId: string;
  username: string | null;
  email: string | null;
  gameId: string;
  gameName: string;
  gameShareId: string;
  sharePercentage: number;
  sharePrice: number;
  shareCount: number;
  purchasePrice: number;
  originalPrice: number | null;
  discountAmount: number | null;
  paymentPeriod: string;
  txHash: string | null;
  status: string;
  purchasedAt: string;
}

export default function GameSharePurchasesAdminClient() {
  const router = useRouter();
  const [game_share_purchases, setPurchases] = useState<GameSharePurchase[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPurchases();
  }, []);

  const fetchPurchases = async () => {
    try {
      const res = await fetch('/api/admin/game-game_shares/pending');
      const data = await res.json();
      if (data.ok) {
        setPurchases(data.data);
      }
    } catch (error) {
      console.error('구매 목록 조회 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (id: string, action: 'APPROVE' | 'REJECT') => {
    if (!confirm(action === 'APPROVE' ? '이 구매를 승인하시겠습니까?' : '이 구매를 거절하시겠습니까?')) return;

    try {
      const res = await fetch('/api/admin/game-game_shares/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ purchaseId: id, action }),
      });

      const data = await res.json();
      if (data.ok) {
        alert('처리되었습니다.');
        fetchPurchases();
      } else {
        alert(data.error || '처리 실패');
      }
    } catch (error) {
      console.error('구매 승인/거절 실패:', error);
      alert('오류가 발생했습니다.');
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="text-center py-10">로딩 중...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">게임 지분 구매 승인 대기</h1>
        <button
          onClick={() => router.push('/a0-admin/games')}
          className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
        >
          게임 관리로 돌아가기
        </button>
      </div>

      {game_share_purchases.length === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-gray-800 rounded-lg shadow">
          <p className="text-gray-500 dark:text-gray-400">승인 대기 중인 구매 내역이 없습니다.</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    구매일시
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    사용자
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    게임
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    지분 정보
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    구매 금액
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    지급 주기
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    TXID
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    작업
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {game_share_purchases.map((purchase) => (
                  <tr key={purchase.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      {new Date(purchase.purchasedAt).toLocaleString('ko-KR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      <div>
                        <div className="font-medium">{purchase.username || 'N/A'}</div>
                        <div className="text-gray-500 dark:text-gray-400 text-xs">{purchase.email || 'N/A'}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      {purchase.gameName}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      <div>
                        <div>{purchase.sharePercentage.toFixed(2)}% 지분</div>
                        <div className="text-gray-500 dark:text-gray-400 text-xs">
                          {purchase.shareCount}개 × ${purchase.sharePrice.toLocaleString()}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      <div>
                        <div className="font-semibold">${purchase.purchasePrice.toLocaleString()}</div>
                        {purchase.discountAmount && purchase.discountAmount > 0 && (
                          <div className="text-xs text-green-600 dark:text-green-400">
                            할인: ${purchase.discountAmount.toLocaleString()}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                      {purchase.paymentPeriod === 'DAILY'
                        ? '매일'
                        : purchase.paymentPeriod === 'WEEKLY'
                          ? '매주'
                          : '매월'}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900 dark:text-gray-100">
                      {purchase.txHash ? (
                        <div className="max-w-xs truncate font-mono text-xs" title={purchase.txHash}>
                          {purchase.txHash}
                        </div>
                      ) : (
                        <span className="text-gray-400">없음</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                      <button
                        onClick={() => handleAction(purchase.id, 'APPROVE')}
                        className="text-green-600 hover:text-green-900 bg-green-100 hover:bg-green-200 px-3 py-1 rounded"
                      >
                        승인
                      </button>
                      <button
                        onClick={() => handleAction(purchase.id, 'REJECT')}
                        className="text-red-600 hover:text-red-900 bg-red-100 hover:bg-red-200 px-3 py-1 rounded"
                      >
                        거절
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export {};

