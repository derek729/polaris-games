'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { CompanyBrand } from '@/components/CompanyBrand';

export default function AdminLoginPage() {
  const { t, language } = useI18n();
  const router = useRouter();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/admin/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          // 입력값에 @가 있으면 email로, 없으면 username으로 처리
          ...(formData.username.trim().includes('@')
            ? { email: formData.username.trim() }
            : { username: formData.username.trim() }),
          password: formData.password,
        }),
      });

      const data = await res.json();

      console.log('[Admin Login Page] 응답:', { 
        ok: data.ok, 
        error: data.error,
        status: res.status,
        headers: Object.fromEntries(res.headers.entries())
      });

      if (data.ok) {
        console.log('[Admin Login Page] 로그인 성공, 리다이렉트');
        // 쿠키가 설정될 시간을 주기 위해 약간의 지연
        await new Promise(resolve => setTimeout(resolve, 200));
        // 페이지를 완전히 새로고침하여 쿠키를 확실히 로드
        window.location.href = '/a0-admin';
      } else {
        console.log('[Admin Login Page] 로그인 실패:', data.error);
        setError(data.error || '관리자 로그인에 실패했습니다.');
      }
    } catch (err) {
      console.error('관리자 로그인 오류:', err);
      setError('네트워크 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] flex min-h-screen w-full flex-col items-center justify-center p-4 bg-gradient-to-br from-[#0a1118] via-[#101922] to-[#0a1118]">
      {/* 상단 헤더: 회사 로고와 번역 탭을 한 줄로 배치 */}
      <div className="fixed top-4 left-4 right-4 z-20 flex items-center justify-between px-4 sm:px-6">
        <CompanyBrand
          wrapperClassName="drop-shadow-lg flex-shrink-0"
          size={48}
          textClassName="text-base sm:text-lg text-white drop-shadow-lg"
          imageClassName="drop-shadow-lg"
        />
        <div className="flex-shrink-0 ml-4">
          <LanguageSwitcher />
        </div>
      </div>

      {/* 콘텐츠 영역 */}
      <div className="relative z-10 w-full max-w-md">
        <header className="mb-8 text-center pt-24 sm:pt-20">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight text-white mb-3 break-words drop-shadow-lg">
            {language === 'ko' ? '관리자 로그인' : 'Admin Login'}
          </h1>
          <p className="text-sm sm:text-base text-slate-200 break-words drop-shadow-md">
            {language === 'ko'
              ? '관리자 계정으로 로그인하세요.'
              : 'Please log in with your admin account.'}
          </p>
          <div className="mt-4 p-3 bg-yellow-900/20 border border-yellow-700/50 rounded-lg">
            <p className="text-xs text-yellow-200">
              {language === 'ko'
                ? '⚠️ 관리자 전용 페이지입니다. 일반 사용자는 접근할 수 없습니다.'
                : '⚠️ Admin only. Regular users cannot access this page.'}
            </p>
          </div>
        </header>

        <main className="w-full space-y-6">
          {error && (
            <div className="p-3 bg-red-900/80 backdrop-blur-sm border border-red-500 rounded-lg text-red-100 text-sm shadow-lg">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-white drop-shadow-md"
                htmlFor="username"
              >
                {t.auth.usernameOrEmail}
              </label>
              <input
                className="h-12 w-full rounded-lg border-slate-300 bg-white/95 backdrop-blur-sm p-3 text-slate-900 placeholder:text-slate-500 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] shadow-lg"
                id="username"
                type="text"
                placeholder={t.auth.usernameOrEmail}
                value={formData.username}
                onChange={(e) =>
                  setFormData({ ...formData, username: e.target.value })
                }
                required
                autoComplete="username"
              />
            </div>

            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-white drop-shadow-md"
                htmlFor="password"
              >
                {t.auth.password}
              </label>
              <div className="relative">
                <input
                  className="h-12 w-full rounded-lg border-slate-300 bg-white/95 backdrop-blur-sm p-3 pr-10 text-slate-900 placeholder:text-slate-500 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] shadow-lg"
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) =>
                    setFormData({ ...formData, password: e.target.value })
                  }
                  required
                  autoComplete="current-password"
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 dark:text-slate-500">
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="material-symbols-outlined cursor-pointer text-xl"
                  >
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </button>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex h-12 w-full items-center justify-center rounded-lg bg-[#3A4DFF] px-4 text-base font-semibold text-white transition-colors hover:bg-[#3A4DFF]/90 focus:outline-none focus:ring-2 focus:ring-[#3A4DFF] focus:ring-offset-2 dark:focus:ring-offset-[#101922] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (language === 'ko' ? '로그인 중...' : 'Logging in...') : (language === 'ko' ? '관리자 로그인' : 'Admin Login')}
            </button>
          </form>

          <div className="text-center">
            <p className="text-sm text-slate-300">
              {language === 'ko' ? '일반 사용자이신가요? ' : 'Regular user? '}
              <a
                href="/login"
                className="font-medium text-white hover:underline drop-shadow-md"
              >
                {language === 'ko' ? '일반 로그인' : 'User Login'}
              </a>
            </p>
          </div>
        </main>

        <footer className="mt-12 text-center">
          <p className="text-xs text-slate-300">
            <span className="text-yellow-400">🔒</span>{' '}
            {language === 'ko'
              ? '관리자 전용 보안 로그인'
              : 'Secure Admin Login Only'}
          </p>
        </footer>
      </div>
    </div>
  );
}

