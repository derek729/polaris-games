'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Game {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  isActive: boolean;
  defaultPaymentPeriod?: string; // 기본 수익 분배 주기 (DAILY, WEEKLY, MONTHLY)
  winRate?: number | null; // 승률 (0 ~ 1)
  prizeAmounts?: {
    rank1?: number; // 1등 (Jackpot)
    rank2?: number; // 2등
    rank3?: number; // 3등
    rank4?: number; // 4등
    rank5?: number; // 5등
    rankEtc?: number; // 파워볼 적중 등
  } | null;
  game_shares: GameShare[];
  purchaseCount: number;
  revenueCount: number;
  createdAt: string;
  updatedAt: string;
}

interface GameShare {
  id: string;
  sharePercentage: number;
  price: number;
  totalShares: number;
  availableShares: number;
  soldShares: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function GamesAdminClient() {
  const router = useRouter();
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [showCreateGameModal, setShowCreateGameModal] = useState(false);
  const [showEditGameModal, setShowEditGameModal] = useState(false);
  const [showCreateShareModal, setShowCreateShareModal] = useState(false);
  const [showRevenueModal, setShowRevenueModal] = useState(false);
  const [editingShare, setEditingShare] = useState<GameShare | null>(null);
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  const [viewMode, setViewMode] = useState<'table' | 'card'>('table');
  const [revenueForm, setRevenueForm] = useState({
    gameId: '',
    totalRevenue: 0,
    periodStart: new Date().toISOString().split('T')[0],
    periodEnd: new Date().toISOString().split('T')[0],
    description: '',
  });

  // 게임 생성 폼
  const [newGame, setNewGame] = useState({
    name: '',
    description: '',
    imageUrl: '',
    defaultPaymentPeriod: 'DAILY' as 'DAILY' | 'WEEKLY' | 'MONTHLY',
    winRate: '', // 승률 (0 ~ 1)
    prizeAmounts: {
      rank1: 1000000000, // 1등 (Jackpot)
      rank2: 50000000, // 2등
      rank3: 1000000, // 3등
      rank4: 50000, // 4등
      rank5: 5000, // 5등
      rankEtc: 1000, // 파워볼 적중 등
    },
    createShare: false, // 지분 상품도 함께 생성할지 여부
    sharePercentage: 1, // 지분 비율 (%)
    sharePrice: 100, // 지분당 가격 (USDT)
    totalShares: 100, // 총 지분 수
  });

  // 지분 상품 생성/수정 폼
  const [shareForm, setShareForm] = useState({
    sharePercentage: 1,
    price: 100,
    totalShares: 100,
  });

  useEffect(() => {
    fetchGames();
  }, []);

  const fetchGames = async () => {
    try {
      const res = await fetch('/api/admin/games?includeInactive=true');
      const data = await res.json();
      if (data.ok) {
        setGames(data.data);
      }
    } catch (error) {
      console.error('게임 목록 조회 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateGame = async () => {
    try {
      // 게임 생성
      const gameRes = await fetch('/api/admin/games', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newGame.name,
          description: newGame.description,
          imageUrl: newGame.imageUrl,
          defaultPaymentPeriod: newGame.defaultPaymentPeriod,
          winRate: newGame.winRate ? parseFloat(newGame.winRate) : null,
          prizeAmounts: newGame.prizeAmounts,
        }),
      });

      const gameData = await gameRes.json();
      if (!gameData.ok) {
        alert(gameData.error || '게임 생성 실패');
        return;
      }

      const createdGameId = gameData.data.id;

      // 지분 상품도 함께 생성하는 경우
      if (newGame.createShare) {
        const shareRes = await fetch(`/api/admin/games/${createdGameId}/game_shares`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sharePercentage: newGame.sharePercentage,
            price: newGame.sharePrice,
            totalShares: newGame.totalShares,
          }),
        });

        const shareData = await shareRes.json();
        if (!shareData.ok) {
          alert(`게임은 생성되었지만 지분 상품 생성에 실패했습니다: ${shareData.error}`);
        } else {
          alert('게임과 지분 상품이 생성되었습니다.');
        }
      } else {
        alert('게임이 생성되었습니다.');
      }

      setShowCreateGameModal(false);
      setNewGame({
        name: '',
        description: '',
        imageUrl: '',
        defaultPaymentPeriod: 'DAILY',
        winRate: '',
        prizeAmounts: {
          rank1: 1000000000,
          rank2: 50000000,
          rank3: 1000000,
          rank4: 50000,
          rank5: 5000,
          rankEtc: 1000,
        },
        createShare: false,
        sharePercentage: 1,
        sharePrice: 100,
        totalShares: 100,
      });
      fetchGames();
    } catch (error) {
      console.error('게임 생성 실패:', error);
      alert('게임 생성 중 오류가 발생했습니다.');
    }
  };

  const handleCreateShare = async () => {
    if (!selectedGame) return;

    try {
      const res = await fetch(`/api/admin/games/${selectedGame.id}/game_shares`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(shareForm),
      });

      const data = await res.json();
      if (data.ok) {
        alert('지분 상품이 생성되었습니다.');
        setShowCreateShareModal(false);
        setShareForm({ sharePercentage: 1, price: 100, totalShares: 100 });
        fetchGames();
      } else {
        alert(data.error || '지분 상품 생성 실패');
      }
    } catch (error) {
      console.error('지분 상품 생성 실패:', error);
      alert('지분 상품 생성 중 오류가 발생했습니다.');
    }
  };

  const handleUpdateShare = async () => {
    if (!selectedGame || !editingShare) return;

    try {
      const res = await fetch(`/api/admin/games/${selectedGame.id}/game_shares`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editingShare.id,
          ...shareForm,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        alert('지분 상품이 수정되었습니다.');
        setEditingShare(null);
        setShareForm({ sharePercentage: 1, price: 100, totalShares: 100 });
        fetchGames();
      } else {
        alert(data.error || '지분 상품 수정 실패');
      }
    } catch (error) {
      console.error('지분 상품 수정 실패:', error);
      alert('지분 상품 수정 중 오류가 발생했습니다.');
    }
  };

  const handleEditShare = (share: GameShare) => {
    setEditingShare(share);
    setShareForm({
      sharePercentage: share.sharePercentage,
      price: share.price,
      totalShares: share.totalShares,
    });
    setShowCreateShareModal(true);
  };

  const handleEditGame = (game: Game) => {
    setEditingGame(game);
    setShowEditGameModal(true);
  };

  const handleUpdateGame = async () => {
    if (!editingGame) return;

    try {
      const res = await fetch('/api/admin/games', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editingGame.id,
          name: editingGame.name,
          description: editingGame.description,
          imageUrl: editingGame.imageUrl,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        alert('게임 정보가 수정되었습니다.');
        setShowEditGameModal(false);
        setEditingGame(null);
        fetchGames();
      } else {
        alert(data.error || '게임 수정 실패');
      }
    } catch (error) {
      console.error('게임 수정 실패:', error);
      alert('게임 수정 중 오류가 발생했습니다.');
    }
  };

  const handleToggleActive = async (game: Game) => {
    if (!confirm(`게임을 ${game.isActive ? '비활성화' : '활성화'}하시겠습니까?`)) {
      return;
    }

    try {
      const res = await fetch('/api/admin/games', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: game.id,
          isActive: !game.isActive,
        }),
      });

      const data = await res.json();
      if (data.ok) {
        alert(`게임이 ${!game.isActive ? '활성화' : '비활성화'}되었습니다.`);
        fetchGames();
      } else {
        alert(data.error || '상태 변경 실패');
      }
    } catch (error) {
      console.error('게임 상태 변경 실패:', error);
      alert('게임 상태 변경 중 오류가 발생했습니다.');
    }
  };

  const handleDeleteGame = async (game: Game) => {
    if (!confirm(`정말로 "${game.name}" 게임을 삭제하시겠습니까?\n\n구매 내역이나 수익 기록이 있으면 삭제할 수 없습니다.`)) {
      return;
    }

    try {
      const res = await fetch(`/api/admin/games/${game.id}`, {
        method: 'DELETE',
      });

      const data = await res.json();
      if (data.ok) {
        alert('게임이 삭제되었습니다.');
        fetchGames();
      } else {
        alert(data.error || '게임 삭제 실패');
      }
    } catch (error) {
      console.error('게임 삭제 실패:', error);
      alert('게임 삭제 중 오류가 발생했습니다.');
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="text-center py-10">로딩 중...</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">게임 관리</h1>
        <div className="flex gap-2">
          <div className="flex gap-1 bg-gray-200 dark:bg-gray-700 rounded-lg p-1">
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1 rounded text-sm ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow'
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              테이블
            </button>
            <button
              onClick={() => setViewMode('card')}
              className={`px-3 py-1 rounded text-sm ${
                viewMode === 'card'
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow'
                  : 'text-gray-600 dark:text-gray-400'
              }`}
            >
              카드
            </button>
          </div>
          <button
            onClick={() => {
              setSelectedGame(null);
              setShowCreateGameModal(true);
            }}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
          >
            게임 추가
          </button>
        </div>
      </div>

      {viewMode === 'table' ? (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    게임명
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    상태
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    지분 상품
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    구매 건수
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    수익 기록
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    분배 주기
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    승률
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    관리
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {games.map((game) => (
                  <tr key={game.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {game.imageUrl && (
                          <img
                            src={game.imageUrl}
                            alt={game.name}
                            className="h-10 w-10 rounded-lg object-cover mr-3"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = 'none';
                            }}
                          />
                        )}
                        <div>
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {game.name}
                          </div>
                          {game.description && (
                            <div className="text-xs text-gray-500 dark:text-gray-400 truncate max-w-xs">
                              {game.description}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          game.isActive
                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                            : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
                        }`}
                      >
                        {game.isActive ? '활성' : '비활성'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {game.game_shares.length}개
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {game.purchaseCount}건
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {game.revenueCount}건
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {game.defaultPaymentPeriod === 'DAILY'
                        ? '일일'
                        : game.defaultPaymentPeriod === 'WEEKLY'
                        ? '주간'
                        : game.defaultPaymentPeriod === 'MONTHLY'
                        ? '월간'
                        : '일일'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {game.winRate !== null && game.winRate !== undefined
                        ? `${(game.winRate * 100).toFixed(2)}%`
                        : '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => handleEditGame(game)}
                          className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                          title="수정"
                        >
                          수정
                        </button>
                        <button
                          onClick={() => handleToggleActive(game)}
                          className={`${
                            game.isActive
                              ? 'text-yellow-600 hover:text-yellow-900 dark:text-yellow-400 dark:hover:text-yellow-300'
                              : 'text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300'
                          }`}
                          title={game.isActive ? '비활성화' : '활성화'}
                        >
                          {game.isActive ? '비활성' : '활성'}
                        </button>
                        <button
                          onClick={() => {
                            setSelectedGame(game);
                            setShowCreateShareModal(true);
                            setEditingShare(null);
                            setShareForm({ sharePercentage: 1, price: 100, totalShares: 100 });
                          }}
                          className="text-[#2F7F6A] hover:text-[#2F7F6A]/80 dark:text-[#2F7F6A] dark:hover:text-[#2F7F6A]/80"
                          title="지분 추가"
                        >
                          지분
                        </button>
                        <button
                          onClick={() => {
                            setSelectedGame(game);
                            setRevenueForm({
                              gameId: game.id,
                              totalRevenue: 0,
                              periodStart: new Date().toISOString().split('T')[0],
                              periodEnd: new Date().toISOString().split('T')[0],
                              description: '',
                            });
                            setShowRevenueModal(true);
                          }}
                          className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300"
                          title="수익 기록"
                        >
                          수익
                        </button>
                        <button
                          onClick={() => setSelectedGame(game)}
                          className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-300"
                          title="상세보기"
                        >
                          상세
                        </button>
                        <button
                          onClick={() => handleDeleteGame(game)}
                          className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                          title="삭제"
                        >
                          삭제
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {games.length === 0 && (
            <div className="text-center py-10 text-gray-500 dark:text-gray-400">
              등록된 게임이 없습니다.
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {games.map((game) => (
          <div
            key={game.id}
            className="bg-white dark:bg-gray-800 rounded-lg shadow p-6 border border-gray-200 dark:border-gray-700"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">{game.name}</h3>
                {game.description && (
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{game.description}</p>
                )}
              </div>
              <span
                className={`px-2 py-1 rounded text-xs ${
                  game.isActive
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
                }`}
              >
                {game.isActive ? '활성' : '비활성'}
              </span>
            </div>

            <div className="space-y-2 mb-4">
              <div className="text-sm text-gray-600 dark:text-gray-400">
                지분 상품: <span className="font-semibold text-gray-900 dark:text-white">{game.game_shares.length}개</span>
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                구매 건수: <span className="font-semibold text-gray-900 dark:text-white">{game.purchaseCount}건</span>
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                수익 기록: <span className="font-semibold text-gray-900 dark:text-white">{game.revenueCount}건</span>
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                기본 분배 주기: <span className="font-semibold text-gray-900 dark:text-white">
                  {game.defaultPaymentPeriod === 'DAILY' ? '일일' : 
                   game.defaultPaymentPeriod === 'WEEKLY' ? '주간' : 
                   game.defaultPaymentPeriod === 'MONTHLY' ? '월간' : '일일'}
                </span>
              </div>
              {game.winRate !== null && game.winRate !== undefined && (
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  승률: <span className="font-semibold text-gray-900 dark:text-white">{(game.winRate * 100).toFixed(2)}%</span>
                </div>
              )}
            </div>

            <div className="flex gap-2 flex-wrap">
              <button
                onClick={() => handleEditGame(game)}
                className="flex-1 px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 text-sm min-w-[100px]"
              >
                수정
              </button>
              <button
                onClick={() => handleToggleActive(game)}
                className={`flex-1 px-3 py-2 rounded-lg text-sm min-w-[100px] ${
                  game.isActive
                    ? 'bg-yellow-500 text-white hover:bg-yellow-600'
                    : 'bg-green-500 text-white hover:bg-green-600'
                }`}
              >
                {game.isActive ? '비활성' : '활성'}
              </button>
              <button
                onClick={() => {
                  setSelectedGame(game);
                  setShowCreateShareModal(true);
                  setEditingShare(null);
                  setShareForm({ sharePercentage: 1, price: 100, totalShares: 100 });
                }}
                className="flex-1 px-3 py-2 bg-[#2F7F6A] text-white rounded-lg hover:bg-[#2F7F6A]/90 text-sm min-w-[100px]"
              >
                지분 추가
              </button>
              <button
                onClick={() => setSelectedGame(game)}
                className="flex-1 px-3 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 text-sm min-w-[100px]"
              >
                상세보기
              </button>
              <button
                onClick={() => {
                  setSelectedGame(game);
                  setRevenueForm({
                    gameId: game.id,
                    totalRevenue: 0,
                    periodStart: new Date().toISOString().split('T')[0],
                    periodEnd: new Date().toISOString().split('T')[0],
                    description: '',
                  });
                  setShowRevenueModal(true);
                }}
                className="flex-1 px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 text-sm min-w-[100px]"
              >
                수익 기록
              </button>
              <button
                onClick={() => handleDeleteGame(game)}
                className="flex-1 px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 text-sm min-w-[100px]"
              >
                삭제
              </button>
            </div>

            {selectedGame?.id === game.id && (
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                <div className="mb-4 pb-4 border-b border-gray-200 dark:border-gray-700">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">게임 설정</h4>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        기본 수익 분배 주기
                      </label>
                      <select
                        value={game.defaultPaymentPeriod || 'DAILY'}
                        onChange={async (e) => {
                          try {
                            const res = await fetch('/api/admin/games', {
                              method: 'PUT',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({
                                id: game.id,
                                defaultPaymentPeriod: e.target.value,
                              }),
                            });
                            const data = await res.json();
                            if (data.ok) {
                              alert('기본 분배 주기가 변경되었습니다.');
                              fetchGames();
                            } else {
                              alert(data.error || '변경 실패');
                            }
                          } catch (error) {
                            console.error('기본 주기 변경 실패:', error);
                            alert('기본 주기 변경 중 오류가 발생했습니다.');
                          }
                        }}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      >
                        <option value="DAILY">일일</option>
                        <option value="WEEKLY">주간</option>
                        <option value="MONTHLY">월간</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        승률 (0 ~ 1, 예: 0.5 = 50%)
                      </label>
                      <input
                        type="number"
                        value={game.winRate !== null && game.winRate !== undefined ? game.winRate : ''}
                        onChange={async (e) => {
                          const value = e.target.value;
                          if (value === '' || (parseFloat(value) >= 0 && parseFloat(value) <= 1)) {
                            try {
                              const res = await fetch('/api/admin/games', {
                                method: 'PUT',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                  id: game.id,
                                  winRate: value === '' ? null : parseFloat(value),
                                }),
                              });
                              const data = await res.json();
                              if (data.ok) {
                                alert('승률이 변경되었습니다.');
                                fetchGames();
                              } else {
                                alert(data.error || '변경 실패');
                              }
                            } catch (error) {
                              console.error('승률 변경 실패:', error);
                              alert('승률 변경 중 오류가 발생했습니다.');
                            }
                          }
                        }}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        min="0"
                        max="1"
                        step="0.0001"
                        placeholder="예: 0.5 (50%)"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        추첨 금액 설정
                      </label>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <label className="text-xs text-gray-600 dark:text-gray-400 w-20">1등 (Jackpot):</label>
                          <input
                            type="number"
                            value={game.prizeAmounts?.rank1 || ''}
                            onChange={async (e) => {
                              const value = parseFloat(e.target.value) || 0;
                              const updatedPrizeAmounts = {
                                ...(game.prizeAmounts || {}),
                                rank1: value,
                              };
                              try {
                                const res = await fetch('/api/admin/games', {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    id: game.id,
                                    prizeAmounts: updatedPrizeAmounts,
                                  }),
                                });
                                const data = await res.json();
                                if (data.ok) {
                                  fetchGames();
                                } else {
                                  alert(data.error || '변경 실패');
                                }
                              } catch (error) {
                                console.error('추첨 금액 변경 실패:', error);
                                alert('추첨 금액 변경 중 오류가 발생했습니다.');
                              }
                            }}
                            className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            placeholder="0"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <label className="text-xs text-gray-600 dark:text-gray-400 w-20">2등:</label>
                          <input
                            type="number"
                            value={game.prizeAmounts?.rank2 || ''}
                            onChange={async (e) => {
                              const value = parseFloat(e.target.value) || 0;
                              const updatedPrizeAmounts = {
                                ...(game.prizeAmounts || {}),
                                rank2: value,
                              };
                              try {
                                const res = await fetch('/api/admin/games', {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    id: game.id,
                                    prizeAmounts: updatedPrizeAmounts,
                                  }),
                                });
                                const data = await res.json();
                                if (data.ok) {
                                  fetchGames();
                                } else {
                                  alert(data.error || '변경 실패');
                                }
                              } catch (error) {
                                console.error('추첨 금액 변경 실패:', error);
                                alert('추첨 금액 변경 중 오류가 발생했습니다.');
                              }
                            }}
                            className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            placeholder="0"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <label className="text-xs text-gray-600 dark:text-gray-400 w-20">3등:</label>
                          <input
                            type="number"
                            value={game.prizeAmounts?.rank3 || ''}
                            onChange={async (e) => {
                              const value = parseFloat(e.target.value) || 0;
                              const updatedPrizeAmounts = {
                                ...(game.prizeAmounts || {}),
                                rank3: value,
                              };
                              try {
                                const res = await fetch('/api/admin/games', {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    id: game.id,
                                    prizeAmounts: updatedPrizeAmounts,
                                  }),
                                });
                                const data = await res.json();
                                if (data.ok) {
                                  fetchGames();
                                } else {
                                  alert(data.error || '변경 실패');
                                }
                              } catch (error) {
                                console.error('추첨 금액 변경 실패:', error);
                                alert('추첨 금액 변경 중 오류가 발생했습니다.');
                              }
                            }}
                            className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            placeholder="0"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <label className="text-xs text-gray-600 dark:text-gray-400 w-20">4등:</label>
                          <input
                            type="number"
                            value={game.prizeAmounts?.rank4 || ''}
                            onChange={async (e) => {
                              const value = parseFloat(e.target.value) || 0;
                              const updatedPrizeAmounts = {
                                ...(game.prizeAmounts || {}),
                                rank4: value,
                              };
                              try {
                                const res = await fetch('/api/admin/games', {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    id: game.id,
                                    prizeAmounts: updatedPrizeAmounts,
                                  }),
                                });
                                const data = await res.json();
                                if (data.ok) {
                                  fetchGames();
                                } else {
                                  alert(data.error || '변경 실패');
                                }
                              } catch (error) {
                                console.error('추첨 금액 변경 실패:', error);
                                alert('추첨 금액 변경 중 오류가 발생했습니다.');
                              }
                            }}
                            className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            placeholder="0"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <label className="text-xs text-gray-600 dark:text-gray-400 w-20">5등:</label>
                          <input
                            type="number"
                            value={game.prizeAmounts?.rank5 || ''}
                            onChange={async (e) => {
                              const value = parseFloat(e.target.value) || 0;
                              const updatedPrizeAmounts = {
                                ...(game.prizeAmounts || {}),
                                rank5: value,
                              };
                              try {
                                const res = await fetch('/api/admin/games', {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    id: game.id,
                                    prizeAmounts: updatedPrizeAmounts,
                                  }),
                                });
                                const data = await res.json();
                                if (data.ok) {
                                  fetchGames();
                                } else {
                                  alert(data.error || '변경 실패');
                                }
                              } catch (error) {
                                console.error('추첨 금액 변경 실패:', error);
                                alert('추첨 금액 변경 중 오류가 발생했습니다.');
                              }
                            }}
                            className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            placeholder="0"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <label className="text-xs text-gray-600 dark:text-gray-400 w-20">기타:</label>
                          <input
                            type="number"
                            value={game.prizeAmounts?.rankEtc || ''}
                            onChange={async (e) => {
                              const value = parseFloat(e.target.value) || 0;
                              const updatedPrizeAmounts = {
                                ...(game.prizeAmounts || {}),
                                rankEtc: value,
                              };
                              try {
                                const res = await fetch('/api/admin/games', {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({
                                    id: game.id,
                                    prizeAmounts: updatedPrizeAmounts,
                                  }),
                                });
                                const data = await res.json();
                                if (data.ok) {
                                  fetchGames();
                                } else {
                                  alert(data.error || '변경 실패');
                                }
                              } catch (error) {
                                console.error('추첨 금액 변경 실패:', error);
                                alert('추첨 금액 변경 중 오류가 발생했습니다.');
                              }
                            }}
                            className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            placeholder="0"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">지분 상품 목록</h4>
                {game.game_shares.length === 0 ? (
                  <p className="text-sm text-gray-500">지분 상품이 없습니다.</p>
                ) : (
                  <div className="space-y-2">
                    {game.game_shares.map((share) => (
                      <div
                        key={share.id}
                        className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-700 rounded"
                      >
                        <div className="text-sm">
                          <div className="font-semibold text-gray-900 dark:text-white">
                            {share.sharePercentage.toFixed(2)}% 지분
                          </div>
                          <div className="text-gray-600 dark:text-gray-400">
                            {share.price.toLocaleString()} USDT / 판매: {share.soldShares}/{share.totalShares}
                          </div>
                        </div>
                        <button
                          onClick={() => handleEditShare(share)}
                          className="px-2 py-1 bg-blue-500 text-white rounded text-xs hover:bg-blue-600"
                        >
                          수정
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
        </div>
      )}

      {/* 게임 수정 모달 */}
      {showEditGameModal && editingGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">게임 수정</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">게임 이름</label>
                <input
                  type="text"
                  value={editingGame.name}
                  onChange={(e) => setEditingGame({ ...editingGame, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="예: 블랙잭"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">설명</label>
                <textarea
                  value={editingGame.description || ''}
                  onChange={(e) => setEditingGame({ ...editingGame, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  rows={3}
                  placeholder="게임 설명"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">이미지 URL</label>
                <input
                  type="text"
                  value={editingGame.imageUrl || ''}
                  onChange={(e) => setEditingGame({ ...editingGame, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="https://..."
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleUpdateGame}
                  className="flex-1 px-4 py-2 bg-[#2F7F6A] text-white rounded-lg hover:bg-[#2F7F6A]/90"
                >
                  수정
                </button>
                <button
                  onClick={() => {
                    setShowEditGameModal(false);
                    setEditingGame(null);
                  }}
                  className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
                >
                  취소
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 게임 생성 모달 */}
      {showCreateGameModal && !selectedGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">게임 생성</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">게임 이름</label>
                <input
                  type="text"
                  value={newGame.name}
                  onChange={(e) => setNewGame({ ...newGame, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="예: 블랙잭"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">설명</label>
                <textarea
                  value={newGame.description}
                  onChange={(e) => setNewGame({ ...newGame, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  rows={3}
                  placeholder="게임 설명"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">이미지 URL</label>
                <input
                  type="text"
                  value={newGame.imageUrl}
                  onChange={(e) => setNewGame({ ...newGame, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  placeholder="https://..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  기본 수익 분배 주기
                </label>
                <select
                  value={newGame.defaultPaymentPeriod}
                  onChange={(e) => setNewGame({ ...newGame, defaultPaymentPeriod: e.target.value as 'DAILY' | 'WEEKLY' | 'MONTHLY' })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="DAILY">일일</option>
                  <option value="WEEKLY">주간</option>
                  <option value="MONTHLY">월간</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  승률 (0 ~ 1, 예: 0.5 = 50%)
                </label>
                <input
                  type="number"
                  value={newGame.winRate}
                  onChange={(e) => setNewGame({ ...newGame, winRate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  min="0"
                  max="1"
                  step="0.0001"
                  placeholder="예: 0.5 (50%)"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  추첨 금액 설정
                </label>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <label className="text-xs text-gray-600 dark:text-gray-400 w-20">1등 (Jackpot):</label>
                    <input
                      type="number"
                      value={newGame.prizeAmounts.rank1}
                      onChange={(e) => setNewGame({
                        ...newGame,
                        prizeAmounts: { ...newGame.prizeAmounts, rank1: parseFloat(e.target.value) || 0 }
                      })}
                      className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-xs text-gray-600 dark:text-gray-400 w-20">2등:</label>
                    <input
                      type="number"
                      value={newGame.prizeAmounts.rank2}
                      onChange={(e) => setNewGame({
                        ...newGame,
                        prizeAmounts: { ...newGame.prizeAmounts, rank2: parseFloat(e.target.value) || 0 }
                      })}
                      className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-xs text-gray-600 dark:text-gray-400 w-20">3등:</label>
                    <input
                      type="number"
                      value={newGame.prizeAmounts.rank3}
                      onChange={(e) => setNewGame({
                        ...newGame,
                        prizeAmounts: { ...newGame.prizeAmounts, rank3: parseFloat(e.target.value) || 0 }
                      })}
                      className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-xs text-gray-600 dark:text-gray-400 w-20">4등:</label>
                    <input
                      type="number"
                      value={newGame.prizeAmounts.rank4}
                      onChange={(e) => setNewGame({
                        ...newGame,
                        prizeAmounts: { ...newGame.prizeAmounts, rank4: parseFloat(e.target.value) || 0 }
                      })}
                      className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-xs text-gray-600 dark:text-gray-400 w-20">5등:</label>
                    <input
                      type="number"
                      value={newGame.prizeAmounts.rank5}
                      onChange={(e) => setNewGame({
                        ...newGame,
                        prizeAmounts: { ...newGame.prizeAmounts, rank5: parseFloat(e.target.value) || 0 }
                      })}
                      className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-xs text-gray-600 dark:text-gray-400 w-20">기타:</label>
                    <input
                      type="number"
                      value={newGame.prizeAmounts.rankEtc}
                      onChange={(e) => setNewGame({
                        ...newGame,
                        prizeAmounts: { ...newGame.prizeAmounts, rankEtc: parseFloat(e.target.value) || 0 }
                      })}
                      className="flex-1 px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              {/* 지분 상품 함께 생성 옵션 */}
              <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
                <div className="flex items-center gap-2 mb-4">
                  <input
                    type="checkbox"
                    id="createShare"
                    checked={newGame.createShare}
                    onChange={(e) => setNewGame({ ...newGame, createShare: e.target.checked })}
                    className="w-4 h-4 text-[#2F7F6A] border-gray-300 rounded focus:ring-[#2F7F6A]"
                  />
                  <label htmlFor="createShare" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    지분 상품도 함께 생성
                  </label>
                </div>

                {newGame.createShare && (
                  <div className="space-y-3 pl-6 border-l-2 border-[#2F7F6A]">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        지분 비율 (%)
                      </label>
                      <input
                        type="number"
                        value={newGame.sharePercentage}
                        onChange={(e) =>
                          setNewGame({ ...newGame, sharePercentage: parseFloat(e.target.value) || 0 })
                        }
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        min="0.01"
                        max="100"
                        step="0.01"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        총 {newGame.sharePercentage * newGame.totalShares}% 지분이 생성됩니다.
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        지분당 가격 (USDT)
                      </label>
                      <input
                        type="number"
                        value={newGame.sharePrice}
                        onChange={(e) => setNewGame({ ...newGame, sharePrice: parseFloat(e.target.value) || 0 })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        min="0.01"
                        step="0.01"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">총 지분 수</label>
                      <input
                        type="number"
                        value={newGame.totalShares}
                        onChange={(e) => setNewGame({ ...newGame, totalShares: parseInt(e.target.value) || 0 })}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        min="1"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleCreateGame}
                  className="flex-1 px-4 py-2 bg-[#2F7F6A] text-white rounded-lg hover:bg-[#2F7F6A]/90"
                >
                  생성
                </button>
                <button
                  onClick={() => {
                    setShowCreateGameModal(false);
                    setNewGame({
                      name: '',
                      description: '',
                      imageUrl: '',
                      defaultPaymentPeriod: 'DAILY',
                      winRate: '',
                      prizeAmounts: {
                        rank1: 1000000000,
                        rank2: 50000000,
                        rank3: 1000000,
                        rank4: 50000,
                        rank5: 5000,
                        rankEtc: 1000,
                      },
                      createShare: false,
                      sharePercentage: 1,
                      sharePrice: 100,
                      totalShares: 100,
                    });
                  }}
                  className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
                >
                  취소
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 지분 상품 생성/수정 모달 */}
      {showCreateShareModal && selectedGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
              {editingShare ? '지분 상품 수정' : '지분 상품 생성'}
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  지분 비율 (%)
                </label>
                <input
                  type="number"
                  value={shareForm.sharePercentage}
                  onChange={(e) => setShareForm({ ...shareForm, sharePercentage: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  min="0.01"
                  max="100"
                  step="0.01"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  지분당 가격 (USDT)
                </label>
                <input
                  type="number"
                  value={shareForm.price}
                  onChange={(e) => setShareForm({ ...shareForm, price: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  min="0.01"
                  step="0.01"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">총 지분 수</label>
                <input
                  type="number"
                  value={shareForm.totalShares}
                  onChange={(e) => setShareForm({ ...shareForm, totalShares: parseInt(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  min="1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  총 {shareForm.sharePercentage * shareForm.totalShares}% 지분이 생성됩니다.
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={editingShare ? handleUpdateShare : handleCreateShare}
                  className="flex-1 px-4 py-2 bg-[#2F7F6A] text-white rounded-lg hover:bg-[#2F7F6A]/90"
                >
                  {editingShare ? '수정' : '생성'}
                </button>
                <button
                  onClick={() => {
                    setShowCreateShareModal(false);
                    setEditingShare(null);
                    setShareForm({ sharePercentage: 1, price: 100, totalShares: 100 });
                  }}
                  className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
                >
                  취소
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 게임 수익 기록 모달 */}
      {showRevenueModal && selectedGame && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">게임 수익 기록</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">게임</label>
                <input
                  type="text"
                  value={selectedGame.name}
                  disabled
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  총 수익 (USDT)
                </label>
                <input
                  type="number"
                  value={revenueForm.totalRevenue}
                  onChange={(e) =>
                    setRevenueForm({ ...revenueForm, totalRevenue: parseFloat(e.target.value) || 0 })
                  }
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  min="0"
                  step="0.01"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">기간 시작일</label>
                <input
                  type="date"
                  value={revenueForm.periodStart}
                  onChange={(e) => setRevenueForm({ ...revenueForm, periodStart: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">기간 종료일</label>
                <input
                  type="date"
                  value={revenueForm.periodEnd}
                  onChange={(e) => setRevenueForm({ ...revenueForm, periodEnd: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">설명</label>
                <textarea
                  value={revenueForm.description}
                  onChange={(e) => setRevenueForm({ ...revenueForm, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  rows={3}
                  placeholder="수익 설명 (선택사항)"
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={async () => {
                    try {
                      const res = await fetch('/api/admin/games/revenue', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                          ...revenueForm,
                          autoDistribute: true,
                        }),
                      });

                      const data = await res.json();
                      if (data.ok) {
                        alert('게임 수익이 기록되고 분배되었습니다.');
                        setShowRevenueModal(false);
                        setRevenueForm({
                          gameId: '',
                          totalRevenue: 0,
                          periodStart: new Date().toISOString().split('T')[0],
                          periodEnd: new Date().toISOString().split('T')[0],
                          description: '',
                        });
                        fetchGames();
                      } else {
                        alert(data.error || '수익 기록 실패');
                      }
                    } catch (error) {
                      console.error('수익 기록 실패:', error);
                      alert('수익 기록 중 오류가 발생했습니다.');
                    }
                  }}
                  className="flex-1 px-4 py-2 bg-[#2F7F6A] text-white rounded-lg hover:bg-[#2F7F6A]/90"
                >
                  기록 및 분배
                </button>
                <button
                  onClick={() => {
                    setShowRevenueModal(false);
                    setRevenueForm({
                      gameId: '',
                      totalRevenue: 0,
                      periodStart: new Date().toISOString().split('T')[0],
                      periodEnd: new Date().toISOString().split('T')[0],
                      description: '',
                    });
                  }}
                  className="flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
                >
                  취소
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export {};

