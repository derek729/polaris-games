import { redirect } from 'next/navigation';
import { getCurrentAdminUser } from '@/lib/admin-auth';
import GamesAdminClient from './GamesAdminClient';

export const dynamic = 'force-dynamic';

export default async function AdminGamesPage() {
  // 관리자 인증 확인
  const user = await getCurrentAdminUser();
  if (!user) {
    redirect('/a0-admin/login');
  }

  return <GamesAdminClient />;
}

