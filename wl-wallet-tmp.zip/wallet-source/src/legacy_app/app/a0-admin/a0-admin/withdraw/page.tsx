import { redirect } from 'next/navigation';
import { getCurrentAdminUser } from '@/lib/admin-auth';
import WithdrawalAdminClient from './WithdrawalAdminClient';

export default async function WithdrawalAdminPage() {
  // 관리자 인증 확인
  const user = await getCurrentAdminUser();
  if (!user) {
    redirect('/a0-admin/login');
  }

  return <WithdrawalAdminClient />;
}

