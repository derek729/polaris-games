'use client';

import { useState, useEffect, useCallback } from 'react';
import { useI18n } from '@/lib/i18n/context';

type WithdrawalItem = {
  id: string;
  userId: string;
  username: string | null;
  email: string | null;
  amount: number;
  address: string;
  status: string;
  requestedAt: string;
  processedAt: string | null;
};

const coinFormat = new Intl.NumberFormat('ko-KR', {
  maximumFractionDigits: 2,
});

export default function WithdrawalAdminClient() {
  const { t } = useI18n();
  const [withdrawals, setWithdrawals] = useState<WithdrawalItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'ALL' | 'PENDING' | 'APPROVED' | 'REJECTED'>('ALL');
  const [processingId, setProcessingId] = useState<string | null>(null);

  // 출금 신청 목록 불러오기
  const fetchWithdrawals = useCallback(async () => {
    setLoading(true);
    try {
      const url = filter === 'ALL' ? '/api/admin/withdraw/list' : `/api/admin/withdraw/list?status=${filter}`;
      const res = await fetch(url, {
        credentials: 'include',
      });
      const result = await res.json();
      if (result.ok) {
        setWithdrawals(result.data || []);
      } else {
        console.error('출금 내역 조회 실패:', result.error);
        setWithdrawals([]);
      }
    } catch (error) {
      console.error('출금 내역 조회 실패:', error);
      setWithdrawals([]);
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    fetchWithdrawals();
  }, [fetchWithdrawals]);

  // 승인/거절 처리
  const handleAction = async (requestId: string, action: 'APPROVE' | 'REJECT') => {
    if (processingId) return;

    const confirmed = window.confirm(
      action === 'APPROVE'
        ? t.admin.withdraw.approveConfirm
        : t.admin.withdraw.rejectConfirm
    );

    if (!confirmed) return;

    setProcessingId(requestId);
    try {
      const res = await fetch('/api/admin/withdraw/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId, action }),
      });

      const result = await res.json();

      if (!res.ok || !result.ok) {
        throw new Error(result.error || '처리 중 오류가 발생했습니다.');
      }

      alert(result.message || '처리되었습니다.');
      fetchWithdrawals(); // 목록 새로고침
    } catch (error: any) {
      console.error('출금 처리 실패:', error);
      alert(error.message || '처리 중 오류가 발생했습니다.');
    } finally {
      setProcessingId(null);
    }
  };

  const statusColors = {
    PENDING: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    APPROVED: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    REJECTED: 'bg-red-500/20 text-red-400 border-red-500/30',
  };

  const statusLabels = {
    PENDING: t.admin.withdraw.statusLabels.pending,
    APPROVED: t.admin.withdraw.statusLabels.approved,
    REJECTED: t.admin.withdraw.statusLabels.rejected,
  };

  const pendingCount = withdrawals.filter((w) => w.status === 'PENDING').length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 px-4 py-6 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-6">
        {/* 헤더 */}
        <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-6 shadow-xl backdrop-blur-sm">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">{t.admin.withdraw.title}</h1>
              <p className="mt-1 text-sm text-slate-400">{t.admin.withdraw.subtitle}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="rounded-lg bg-yellow-500/20 border border-yellow-500/30 px-4 py-2">
                <p className="text-xs text-yellow-400">{t.admin.withdraw.pending}</p>
                <p className="text-2xl font-bold text-yellow-300">{pendingCount}</p>
              </div>
            </div>
          </div>
        </div>

        {/* 필터 */}
        <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-4 shadow-xl backdrop-blur-sm">
          <div className="flex flex-wrap items-center gap-2">
            {(['ALL', 'PENDING', 'APPROVED', 'REJECTED'] as const).map((option) => (
              <button
                key={option}
                onClick={() => setFilter(option)}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                  filter === option
                    ? 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white shadow-lg shadow-indigo-500/50'
                    : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {option === 'ALL' ? t.admin.withdraw.all : statusLabels[option]}
              </button>
            ))}
          </div>
        </div>

        {/* 출금 신청 목록 */}
        <div className="rounded-2xl border border-white/5 bg-slate-900/40 p-4 shadow-xl backdrop-blur-sm sm:p-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <p className="text-slate-400">{t.admin.withdraw.loading}</p>
            </div>
          ) : withdrawals.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-800/60">
                <thead className="bg-slate-900/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                      {t.admin.withdraw.requestedDate}
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                      {t.admin.withdraw.users}
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                      {t.admin.withdraw.amount}
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                      {t.admin.withdraw.walletAddress}
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                      {t.admin.withdraw.status}
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                      {t.admin.withdraw.processedDate}
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium uppercase tracking-wider text-slate-400 sm:px-6">
                      {t.admin.withdraw.actions}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 bg-slate-950/50">
                  {withdrawals.map((withdrawal) => (
                    <tr key={withdrawal.id} className="transition-colors hover:bg-white/5">
                      <td className="whitespace-nowrap px-4 py-4 text-sm text-slate-300 sm:px-6">
                        {new Date(withdrawal.requestedAt).toLocaleString('ko-KR')}
                      </td>
                      <td className="px-4 py-4 text-sm sm:px-6">
                        <div>
                          <p className="font-medium text-white">{withdrawal.username || 'Unknown'}</p>
                          <p className="text-xs text-slate-400">{withdrawal.email || '-'}</p>
                        </div>
                      </td>
                      <td className="whitespace-nowrap px-4 py-4 text-sm font-semibold text-white sm:px-6">
                        {coinFormat.format(withdrawal.amount)} MSUO
                      </td>
                      <td className="px-4 py-4 text-sm text-slate-400 sm:px-6">
                        <span className="font-mono text-xs">
                          {withdrawal.address.slice(0, 10)}...{withdrawal.address.slice(-8)}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-4 py-4 sm:px-6">
                        <span
                          className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-semibold ${
                            statusColors[withdrawal.status as keyof typeof statusColors] || statusColors.PENDING
                          }`}
                        >
                          {statusLabels[withdrawal.status as keyof typeof statusLabels] || withdrawal.status}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-4 py-4 text-sm text-slate-400 sm:px-6">
                        {withdrawal.processedAt
                          ? new Date(withdrawal.processedAt).toLocaleString('ko-KR')
                          : '-'}
                      </td>
                      <td className="whitespace-nowrap px-4 py-4 text-right text-sm font-medium sm:px-6">
                        {withdrawal.status === 'PENDING' ? (
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => handleAction(withdrawal.id, 'APPROVE')}
                              disabled={processingId === withdrawal.id}
                              className="rounded-lg bg-emerald-500/20 border border-emerald-500/30 px-3 py-1.5 text-xs font-semibold text-emerald-300 transition hover:bg-emerald-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              {processingId === withdrawal.id ? t.admin.withdraw.processing : t.admin.withdraw.approve}
                            </button>
                            <button
                              onClick={() => handleAction(withdrawal.id, 'REJECT')}
                              disabled={processingId === withdrawal.id}
                              className="rounded-lg bg-red-500/20 border border-red-500/30 px-3 py-1.5 text-xs font-semibold text-red-300 transition hover:bg-red-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              {processingId === withdrawal.id ? t.admin.withdraw.processing : t.admin.withdraw.reject}
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-500">{t.admin.withdraw.completed}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12">
              <svg
                className="mx-auto h-12 w-12 text-slate-600"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
              <p className="mt-4 text-sm text-slate-500">
                {filter === 'ALL' ? t.admin.withdraw.noWithdrawals : t.admin.withdraw.noWithdrawalsFiltered}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

