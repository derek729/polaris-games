import { redirect } from 'next/navigation';
import { getCurrentAdminUser } from '@/lib/admin-auth';
import StakingAdminClient from './StakingAdminClient';

export default async function StakingAdminPage() {
  // 관리자 인증 확인
  const user = await getCurrentAdminUser();
  if (!user) {
    redirect('/a0-admin/login');
  }

  return <StakingAdminClient />;
}

