'use client';

import { useEffect, useState, useCallback } from 'react';
import { useI18n } from '@/lib/i18n/context';

interface InvestmentTier {
  tier: number;
  minAmount: number;
  maxAmount: number | null;
  dailyRate: number;
  matchingDepth: number;
  label: string;
  description: string;
}

export default function ProductsClient() {
  const { t, language } = useI18n();
  const [tiers, setTiers] = useState<InvestmentTier[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetchTiers();
  }, []);

  const fetchTiers = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/investment/tiers');
      const data = await response.json();
      if (data.ok && data.data) {
        setTiers(data.data);
      } else {
        setMessage({ type: 'error', text: '상품 목록을 불러오는데 실패했습니다.' });
      }
    } catch (error) {
      console.error('상품 목록 조회 실패:', error);
      setMessage({ type: 'error', text: '상품 목록을 불러오는데 실패했습니다.' });
    } finally {
      setLoading(false);
    }
  };

  const updateTier = (index: number, field: keyof InvestmentTier, value: number | string | null) => {
    const updated = [...tiers];
    if (field === 'maxAmount' && value === '') {
      updated[index] = { ...updated[index], [field]: null };
    } else {
      updated[index] = { ...updated[index], [field]: value as any };
    }
    setTiers(updated);
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setMessage(null);

      const response = await fetch('/api/admin/investment/tiers', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tiers }),
      });

      const data = await response.json();
      if (data.ok) {
        setMessage({ type: 'success', text: '상품 설정이 저장되었습니다.' });
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage({ type: 'error', text: data.error || '저장에 실패했습니다.' });
      }
    } catch (error) {
      console.error('상품 설정 저장 실패:', error);
      setMessage({ type: 'error', text: '저장에 실패했습니다.' });
    } finally {
      setSaving(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ko-KR', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatRate = (rate: number) => {
    return (rate * 100).toFixed(4);
  };

  const calculateAnnualRate = (dailyRate: number) => {
    return (dailyRate * 365 * 100).toFixed(2);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
          <p className="text-gray-400 text-sm">로딩 중...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">
            {t.admin.products.title}
          </h1>
          <p className="text-sm text-gray-400 mt-1">
            {t.admin.products.subtitle}
          </p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-6 py-2 bg-[#137fec] text-white rounded-lg font-medium hover:bg-[#0f6bc7] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {saving ? t.admin.products.saving : t.admin.products.save}
        </button>
      </div>

      {/* Message */}
      {message && (
        <div
          className={`p-4 rounded-lg border ${message.type === 'success'
              ? 'bg-green-900/20 text-green-200 border-green-800'
              : 'bg-red-900/20 text-red-200 border-red-800'
            }`}
        >
          {message.text}
        </div>
      )}

      {/* Products Table */}
      <div className="bg-[#192633] rounded-lg border border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[#111a22]">
              <tr>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">
                  {t.admin.products.tier}
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">
                  {t.admin.products.minAmount}
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">
                  {t.admin.products.maxAmount}
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">
                  {t.admin.products.dailyRate}
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">
                  {t.admin.products.annualRate}
                </th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-300">
                  {t.admin.products.matchingDepth}
                </th>
              </tr>
            </thead>
            <tbody>
              {tiers.map((tier, index) => (
                <tr key={tier.tier} className="border-b border-gray-700 hover:bg-[#111a22]">
                  <td className="py-3 px-4">
                    <div className="font-medium text-white">{tier.label}</div>
                    <div className="text-xs text-gray-400 mt-1">{tier.description}</div>
                  </td>
                  <td className="py-3 px-4">
                    <input
                      type="number"
                      min="0"
                      step="1"
                      value={tier.minAmount}
                      onChange={(e) => updateTier(index, 'minAmount', parseFloat(e.target.value) || 0)}
                      className="w-32 px-3 py-1 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                    />
                  </td>
                  <td className="py-3 px-4">
                    <input
                      type="number"
                      min="0"
                      step="1"
                      value={tier.maxAmount || ''}
                      onChange={(e) =>
                        updateTier(index, 'maxAmount', e.target.value ? parseFloat(e.target.value) : null)
                      }
                      placeholder={t.admin.products.unlimited}
                      className="w-32 px-3 py-1 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                    />
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        step="0.0001"
                        min="0"
                        max="1"
                        value={tier.dailyRate * 100}
                        onChange={(e) => updateTier(index, 'dailyRate', parseFloat(e.target.value) / 100 || 0)}
                        className="w-24 px-3 py-1 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                      />
                      <span className="text-gray-400 text-sm">%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-white font-medium">
                      {calculateAnnualRate(tier.dailyRate)}%
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <input
                      type="number"
                      min="0"
                      max="12"
                      value={tier.matchingDepth}
                      onChange={(e) => updateTier(index, 'matchingDepth', parseInt(e.target.value) || 0)}
                      className="w-20 px-3 py-1 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Info Box */}
      <div className="bg-blue-900/20 border border-blue-800 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <span className="material-symbols-outlined text-blue-400">info</span>
          <div className="text-sm text-blue-200">
            <p className="font-medium mb-1">
              {t.admin.products.guide}
            </p>
            <ul className="list-disc list-inside space-y-1 text-blue-300">
              <li>{t.admin.products.guide1}</li>
              <li>{t.admin.products.guide2}</li>
              <li>{t.admin.products.guide3}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

