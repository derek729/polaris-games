"use client";

import React, { useState, useEffect, useCallback } from 'react';
import {
  Search,
  Filter,
  Calendar,
  User,
  Activity,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  RefreshCw,
  Download,
  Eye
} from 'lucide-react';
// date-fns 대신 내장 Date 메서드 사용
// import { format } from 'date-fns';
// import { ko } from 'date-fns/locale';

interface AuditLog {
  id: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  action: string;
  target?: string;
  targetId?: string;
  details: Record<string, any>;
  ipAddress: string;
  userAgent?: string;
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
  timestamp: Date;
}

const AuditLogsClient: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAction, setSelectedAction] = useState('ALL');
  const [selectedSeverity, setSelectedSeverity] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [dateRange, setDateRange] = useState({
    start: '',
    end: ''
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  const ITEMS_PER_PAGE = 20;

  const actions = [
    'ALL',
    'LOGIN',
    'LOGOUT',
    'USER_CREATE',
    'USER_UPDATE',
    'USER_SUSPEND',
    'WITHDRAWAL_APPROVE',
    'WITHDRAWAL_REJECT',
    'INVESTMENT_CREATE',
    'REWARD_PROCESS',
    'SYSTEM_CONFIG_UPDATE',
    'DATA_EXPORT',
    'BULK_OPERATION'
  ];

  const severities = ['ALL', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'];
  const statuses = ['ALL', 'SUCCESS', 'FAILED', 'PENDING'];

  const fetchAuditLogs = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: ITEMS_PER_PAGE.toString(),
        ...(searchTerm && { search: searchTerm }),
        ...(selectedAction !== 'ALL' && { action: selectedAction }),
        ...(selectedSeverity !== 'ALL' && { severity: selectedSeverity }),
        ...(selectedStatus !== 'ALL' && { status: selectedStatus }),
        ...(dateRange.start && { startDate: dateRange.start }),
        ...(dateRange.end && { endDate: dateRange.end })
      });

      const response = await fetch(`/api/admin/audit?${params}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch audit logs');

      const data = await response.json();
      setLogs(data.logs || []);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      // 임시 데이터 표시
      setLogs(getMockAuditLogs());
    } finally {
      setLoading(false);
    }
  }, [currentPage, searchTerm, selectedAction, selectedSeverity, selectedStatus, dateRange.start, dateRange.end]);

  useEffect(() => {
    fetchAuditLogs();
  }, [fetchAuditLogs]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL': return 'text-red-400 bg-red-500/20 border-red-500/50';
      case 'ERROR': return 'text-red-400 bg-red-500/20 border-red-500/50';
      case 'WARNING': return 'text-yellow-400 bg-yellow-500/20 border-yellow-500/50';
      case 'INFO': return 'text-blue-400 bg-blue-500/20 border-blue-500/50';
      default: return 'text-gray-400 bg-gray-500/20 border-gray-500/50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'SUCCESS': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'FAILED': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'PENDING': return <Clock className="w-4 h-4 text-yellow-500" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'CRITICAL':
      case 'ERROR': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'WARNING': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'INFO': return <Activity className="w-4 h-4 text-blue-500" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  const handleExportLogs = async () => {
    try {
      const params = new URLSearchParams({
        ...(searchTerm && { search: searchTerm }),
        ...(selectedAction !== 'ALL' && { action: selectedAction }),
        ...(selectedSeverity !== 'ALL' && { severity: selectedSeverity }),
        ...(selectedStatus !== 'ALL' && { status: selectedStatus }),
        ...(dateRange.start && { startDate: dateRange.start }),
        ...(dateRange.end && { endDate: dateRange.end })
      });

      const response = await fetch(`/api/admin/audit/export?${params}`);
      if (!response.ok) throw new Error('Failed to export logs');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `audit-logs-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error exporting logs:', error);
      alert('로그 내보내기에 실패했습니다.');
    }
  };

  const openLogDetail = (log: AuditLog) => {
    setSelectedLog(log);
    setShowDetailModal(true);
  };

  const filteredLogs = logs; // 이미 필터링된 데이터가 옴

  // 임시 mock 데이터 함수
  const getMockAuditLogs = (): AuditLog[] => {
    return [
      {
        id: '1',
        userId: 'user1',
        userName: '관리자',
        userEmail: 'admin@example.com',
        action: 'LOGIN',
        details: { method: 'email' },
        ipAddress: '192.168.1.100',
        userAgent: 'Mozilla/5.0...',
        severity: 'INFO',
        status: 'SUCCESS',
        timestamp: new Date(Date.now() - 1000 * 60 * 5)
      },
      {
        id: '2',
        userId: 'user2',
        userName: '관리자',
        userEmail: 'admin@example.com',
        action: 'USER_SUSPEND',
        target: 'user123',
        targetId: 'user123',
        details: { reason: '비정상 활동' },
        ipAddress: '192.168.1.100',
        severity: 'WARNING',
        status: 'SUCCESS',
        timestamp: new Date(Date.now() - 1000 * 60 * 30)
      }
    ];
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto">
      {/* 헤더 */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">감사 로그</h1>
          <p className="text-gray-400 mt-1">시스템의 모든 활동 로그를 모니터링합니다</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={fetchAuditLogs}
            className="flex items-center gap-2 px-4 py-2 bg-[#137fec] text-white rounded-lg hover:bg-[#137fec]/90"
          >
            <RefreshCw className="w-4 h-4" />
            새로고침
          </button>
          <button
            onClick={handleExportLogs}
            className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
          >
            <Download className="w-4 h-4" />
            내보내기
          </button>
        </div>
      </div>

      {/* 필터 */}
      <div className="bg-[#1e293b] rounded-xl border border-white/10 p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 검색 */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="사용자, IP 주소 검색..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>

          {/* 액션 필터 */}
          <select
            value={selectedAction}
            onChange={(e) => setSelectedAction(e.target.value)}
            className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
          >
            {actions.map(action => (
              <option key={action} value={action}>
                {action === 'ALL' ? '모든 액션' : action}
              </option>
            ))}
          </select>

          {/* 심각도 필터 */}
          <select
            value={selectedSeverity}
            onChange={(e) => setSelectedSeverity(e.target.value)}
            className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
          >
            {severities.map(severity => (
              <option key={severity} value={severity}>
                {severity === 'ALL' ? '모든 심각도' : severity}
              </option>
            ))}
          </select>

          {/* 상태 필터 */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
          >
            {statuses.map(status => (
              <option key={status} value={status}>
                {status === 'ALL' ? '모든 상태' : status}
              </option>
            ))}
          </select>
        </div>

        {/* 날짜 범위 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">시작일</label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">종료일</label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* 로그 테이블 */}
      <div className="bg-[#1e293b] rounded-xl border border-white/10 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <RefreshCw className="w-8 h-8 animate-spin text-[#137fec]" />
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-white/5 border-b border-white/10">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      시간
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      사용자
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      액션
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      대상
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      심각도
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      상태
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      IP 주소
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                      상세보기
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-white/5">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {new Date(log.timestamp).toLocaleString('ko-KR', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div>
                          <div className="text-sm font-medium text-white">
                            {log.userName || 'Unknown'}
                          </div>
                          <div className="text-xs text-gray-400">
                            {log.userEmail}
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {log.action}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {log.target || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getSeverityColor(log.severity)}`}>
                          {getSeverityIcon(log.severity)}
                          <span className="ml-1">{log.severity}</span>
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          {getStatusIcon(log.status)}
                          <span className="ml-1 text-sm text-white">{log.status}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        {log.ipAddress}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                        <button
                          onClick={() => openLogDetail(log)}
                          className="text-[#137fec] hover:text-[#137fec]/80"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* 페이지네이션 */}
            <div className="bg-white/5 px-6 py-3 border-t border-white/10 flex items-center justify-between">
              <div className="text-sm text-gray-300">
                총 {logs.length}개의 로그
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1 text-sm border border-white/10 rounded-md bg-white/5 text-white hover:bg-white/10 disabled:opacity-50"
                >
                  이전
                </button>
                <span className="px-3 py-1 text-sm text-white">
                  {currentPage}
                </span>
                <button
                  onClick={() => setCurrentPage(currentPage + 1)}
                  disabled={logs.length < ITEMS_PER_PAGE}
                  className="px-3 py-1 text-sm border border-white/10 rounded-md bg-white/5 text-white hover:bg-white/10 disabled:opacity-50"
                >
                  다음
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* 상세 정보 모달 */}
      {showDetailModal && selectedLog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-[#1e293b] rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto border border-white/10">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">감사 로그 상세 정보</h2>
              <button
                onClick={() => setShowDetailModal(false)}
                className="text-gray-400 hover:text-white"
              >
                ×
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-400">시간</label>
                  <p className="text-white">
                    {new Date(selectedLog.timestamp).toLocaleString('ko-KR', { year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-400">액션</label>
                  <p className="text-white">{selectedLog.action}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-400">사용자</label>
                  <p className="text-white">
                    {selectedLog.userName} ({selectedLog.userEmail})
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-400">IP 주소</label>
                  <p className="text-white">{selectedLog.ipAddress}</p>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-400">상세 정보</label>
                <pre className="bg-white/5 p-3 rounded-lg text-sm overflow-x-auto text-white border border-white/10">
                  {JSON.stringify(selectedLog.details, null, 2)}
                </pre>
              </div>

              {selectedLog.userAgent && (
                <div>
                  <label className="text-sm font-medium text-gray-400">User Agent</label>
                  <p className="text-white text-sm break-all">{selectedLog.userAgent}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AuditLogsClient;