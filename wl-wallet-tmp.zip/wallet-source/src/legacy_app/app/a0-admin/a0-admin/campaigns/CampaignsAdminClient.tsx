'use client'

import { useEffect, useState, useCallback } from 'react'
import { useI18n } from '@/lib/i18n/context'

interface Campaign {
  id: string
  name: string
  description?: string
  startDate: string
  endDate: string
  discountRate: number
  isActive: boolean
  createdAt: string
}

interface CampaignsResponse {
  ok: boolean
  data: {
    campaigns: Campaign[]
    pagination: {
      currentPage: number
      totalPages: number
      totalCount: number
      limit: number
      hasNext: boolean
      hasPrev: boolean
    }
  }
}

export default function CampaignsAdminClient() {
  const { t } = useI18n()
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalCount: 0,
    limit: 20,
    hasNext: false,
    hasPrev: false,
  })
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    startDate: '',
    endDate: '',
    discountRate: 0,
    isActive: true,
  })

  const fetchCampaigns = useCallback(async () => {
    try {
      setIsLoading(true)
      const response = await fetch('/api/admin/campaigns')
      if (response.ok) {
        const data: CampaignsResponse = await response.json()
        setCampaigns(data.data.campaigns)
        setPagination(data.data.pagination)
      }
    } catch (error) {
      console.error('캠페인 조회 실패:', error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchCampaigns()
  }, [fetchCampaigns])

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/admin/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setIsCreateModalOpen(false)
        setFormData({
          name: '',
          description: '',
          startDate: '',
          endDate: '',
          discountRate: 0,
          isActive: true,
        })
        fetchCampaigns()
        alert(t.admin.campaigns.createSuccess)
      } else {
        alert(t.admin.campaigns.createFailed)
      }
    } catch (error) {
      console.error('캠페인 생성 실패:', error)
      alert(t.admin.campaigns.createError)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    })
  }

  const isActive = (campaign: Campaign) => {
    const now = new Date()
    const start = new Date(campaign.startDate)
    const end = new Date(campaign.endDate)
    return campaign.isActive && now >= start && now <= end
  }

  if (isLoading && campaigns.length === 0) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-[#1e293b] rounded w-48 mb-6"></div>
          <div className="bg-[#1e293b] rounded-lg border border-white/10 overflow-hidden">
            <div className="h-16 bg-white/5"></div>
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-white/5 border-t border-white/10"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 페이지 제목 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">{t.admin.campaigns.title}</h1>
          <p className="text-gray-400 mt-1">{t.admin.campaigns.subtitle}</p>
        </div>
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-2 rounded-lg bg-[#137fec] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#137fec]/90 transition-colors"
        >
          <span className="material-symbols-outlined">add</span>
          {t.admin.campaigns.create}
        </button>
      </div>

      {/* 캠페인 목록 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {campaigns.length === 0 ? (
          <div className="col-span-full text-center py-12 bg-[#1e293b] rounded-lg border border-white/10">
            <span className="material-symbols-outlined text-gray-400 text-6xl mb-4">campaign</span>
            <h3 className="text-lg font-medium text-gray-300 mb-2">{t.admin.campaigns.noCampaigns}</h3>
            <p className="text-gray-500 text-sm mb-4">{t.admin.campaigns.noCampaignsMessage}</p>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="inline-flex items-center gap-2 rounded-lg bg-[#137fec] px-4 py-2 text-sm font-medium text-white hover:bg-[#137fec]/90 transition-colors"
            >
              <span className="material-symbols-outlined">add</span>
              {t.admin.campaigns.createNewCampaign}
            </button>
          </div>
        ) : (
          campaigns.map((campaign) => (
            <div
              key={campaign.id}
              className="flex flex-col gap-4 rounded-xl p-6 bg-[#1e293b] border border-white/10 hover:border-[#137fec]/50 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-white text-lg font-semibold mb-1">{campaign.name}</h3>
                  {campaign.description && (
                    <p className="text-gray-400 text-sm">{campaign.description}</p>
                  )}
                </div>
                {isActive(campaign) ? (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-500/20 text-green-400">
                    {t.admin.campaigns.activeStatus}
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-500/20 text-gray-400">
                    {t.admin.campaigns.inactiveStatus}
                  </span>
                )}
              </div>

              <div className="flex flex-col gap-2 pt-4 border-t border-white/10">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">{t.admin.campaigns.discountRate}</span>
                  <span className="text-white font-medium">{campaign.discountRate}%</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">{t.admin.campaigns.startDate}</span>
                  <span className="text-white">{formatDate(campaign.startDate)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">{t.admin.campaigns.endDate}</span>
                  <span className="text-white">{formatDate(campaign.endDate)}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-4 border-t border-white/10">
                <button className="flex-1 px-4 py-2 bg-white/5 hover:bg-white/10 text-white text-sm font-medium rounded-lg transition-colors">
                  {t.admin.campaigns.edit}
                </button>
                <button className="flex-1 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 text-sm font-medium rounded-lg transition-colors">
                  {t.admin.campaigns.delete}
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* 캠페인 생성 모달 */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-[#1e293b] rounded-xl p-6 w-full max-w-md border border-white/10">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-white text-xl font-semibold">{t.admin.campaigns.create}</h2>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleCreateCampaign} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.campaigns.name}</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  placeholder={t.admin.campaigns.namePlaceholder}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.campaigns.description}</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  placeholder={t.admin.campaigns.descriptionPlaceholder}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.campaigns.startDate}</label>
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.campaigns.endDate}</label>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">{t.admin.campaigns.discountRate} (%)</label>
                <input
                  type="number"
                  value={formData.discountRate}
                  onChange={(e) => setFormData({ ...formData, discountRate: parseFloat(e.target.value) || 0 })}
                  min="0"
                  max="100"
                  step="0.1"
                  className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
                  placeholder="0"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="w-4 h-4 rounded border-white/10 bg-white/5 text-[#137fec] focus:ring-[#137fec]"
                />
                <label htmlFor="isActive" className="text-sm text-gray-300">
                  {t.admin.campaigns.active}
                </label>
              </div>

              <div className="flex items-center gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="flex-1 px-4 py-2 bg-white/5 hover:bg-white/10 text-white text-sm font-medium rounded-lg transition-colors"
                >
                  {t.admin.campaigns.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-[#137fec] hover:bg-[#137fec]/90 text-white text-sm font-medium rounded-lg transition-colors"
                >
                  {t.admin.campaigns.createButton}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

