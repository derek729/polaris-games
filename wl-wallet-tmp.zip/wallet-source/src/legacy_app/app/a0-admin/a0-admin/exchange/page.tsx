import ExchangeAdminClient from './ExchangeAdminClient';

export default function ExchangeAdminPage() {
  return <ExchangeAdminClient />;
}

