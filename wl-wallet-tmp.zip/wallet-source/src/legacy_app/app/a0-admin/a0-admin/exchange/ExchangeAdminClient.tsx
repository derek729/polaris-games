'use client';

import { useState, useEffect } from 'react';
import { useI18n } from '@/lib/i18n/context';

interface ExchangeSettings {
  upcInitialPrice: string;
  upcCurrentPrice: string;
  upcSellAmount: string;
  exchangeBotEnabled: string;
  exchangeBotMinPrice: string;
  exchangeBotMaxPrice: string;
  exchangeBotSpread: string;
  exchangeBotOrderAmount: string;
}

interface MarketStats {
  currentPrice: number;
  volume24h: number;
  tradeCount24h: number;
  avgPrice24h: number;
  buyOrders: number;
  sellOrders: number;
}

export default function ExchangeAdminClient() {
  const { language } = useI18n();
  const [settings, setSettings] = useState<ExchangeSettings>({
    upcInitialPrice: '0.00010',
    upcCurrentPrice: '',
    upcSellAmount: '0',
    exchangeBotEnabled: 'false',
    exchangeBotMinPrice: '0.00005',
    exchangeBotMaxPrice: '0.00015',
    exchangeBotSpread: '0.00001',
    exchangeBotOrderAmount: '1000',
  });
  const [marketStats, setMarketStats] = useState<MarketStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetchSettings();
    fetchMarketStats();
    const interval = setInterval(fetchMarketStats, 10000); // 10초마다 갱신
    return () => clearInterval(interval);
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/admin/system-settings', {
        credentials: 'include',
      });
      const data = await res.json();
      if (data.ok && data.data) {
        setSettings({
          upcInitialPrice: data.data.upcInitialPrice || '0.00010',
          upcCurrentPrice: data.data.upcCurrentPrice || '',
          upcSellAmount: data.data.upcSellAmount || '0',
          exchangeBotEnabled: data.data.exchangeBotEnabled || 'false',
          exchangeBotMinPrice: data.data.exchangeBotMinPrice || '0.00005',
          exchangeBotMaxPrice: data.data.exchangeBotMaxPrice || '0.00015',
          exchangeBotSpread: data.data.exchangeBotSpread || '0.00001',
          exchangeBotOrderAmount: data.data.exchangeBotOrderAmount || '1000',
        });
      }
    } catch (error) {
      console.error('설정 조회 실패:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMarketStats = async () => {
    try {
      const res = await fetch('/api/user/exchange/orderbook', {
        credentials: 'include',
      });
      const data = await res.json();
      if (data.ok && data.data) {
        setMarketStats({
          currentPrice: data.data.currentPrice || 0,
          volume24h: data.data.stats24h?.volume || 0,
          tradeCount24h: data.data.stats24h?.tradeCount || 0,
          avgPrice24h: data.data.stats24h?.avgPrice || 0,
          buyOrders: data.data.buyOrders?.length || 0,
          sellOrders: data.data.sellOrders?.length || 0,
        });
      }
    } catch (error) {
      console.error('시장 통계 조회 실패:', error);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      const response = await fetch('/api/admin/system-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(settings),
      });

      const result = await response.json();
      if (result.ok) {
        setMessage({ type: 'success', text: language === 'ko' ? '설정이 저장되었습니다.' : 'Settings saved.' });
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage({ type: 'error', text: result.error || (language === 'ko' ? '저장에 실패했습니다.' : 'Failed to save.') });
      }
    } catch (error) {
      console.error('설정 저장 실패:', error);
      setMessage({ type: 'error', text: language === 'ko' ? '저장 중 오류가 발생했습니다.' : 'Error saving settings.' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#137fec]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 페이지 헤더 */}
      <div>
        <h1 className="text-3xl font-bold text-white">
          {language === 'ko' ? '거래소 관리' : 'Exchange Management'}
        </h1>
        <p className="text-gray-400 mt-1">
          {language === 'ko' ? '거래소 가격 및 봇 설정을 관리합니다.' : 'Manage exchange prices and bot settings.'}
        </p>
      </div>

      {/* 메시지 */}
      {message && (
        <div
          className={`p-4 rounded-lg border ${
            message.type === 'success'
              ? 'bg-green-900/20 text-green-200 border-green-800'
              : 'bg-red-900/20 text-red-200 border-red-800'
          }`}
        >
          {message.text}
        </div>
      )}

      {/* 시장 통계 */}
      {marketStats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
            <div className="text-gray-400 text-sm mb-1">
              {language === 'ko' ? '현재가' : 'Current Price'}
            </div>
            <div className="text-white text-2xl font-bold">
              ${marketStats.currentPrice.toFixed(8)} USDT
            </div>
          </div>
          <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
            <div className="text-gray-400 text-sm mb-1">
              {language === 'ko' ? '24h 거래량' : '24h Volume'}
            </div>
            <div className="text-white text-2xl font-bold">
              {marketStats.volume24h.toFixed(2)} MSUO
            </div>
          </div>
          <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
            <div className="text-gray-400 text-sm mb-1">
              {language === 'ko' ? '24h 거래 건수' : '24h Trades'}
            </div>
            <div className="text-white text-2xl font-bold">
              {marketStats.tradeCount24h}건
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 가격 관리 */}
        <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
          <div className="mb-4">
            <h2 className="text-xl font-bold text-white">
              {language === 'ko' ? '가격 관리' : 'Price Management'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko' ? 'MSUO 코인의 가격을 설정합니다.' : 'Set the price for MSUO Coin.'}
            </p>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '시작가 (NKT)' : 'Initial Price (NKT)'}
              </label>
              <input
                type="number"
                step="0.00000001"
                value={settings.upcInitialPrice}
                onChange={(e) => setSettings({ ...settings, upcInitialPrice: e.target.value })}
                placeholder="0.00010"
                className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">
                {language === 'ko' ? '거래 내역이 없을 때 사용되는 기본 가격' : 'Default price when no trades exist'}
              </p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '현재 시세 강제 설정 (NKT)' : 'Current Price Override (NKT)'}
              </label>
              <input
                type="number"
                step="0.00000001"
                value={settings.upcCurrentPrice}
                onChange={(e) => setSettings({ ...settings, upcCurrentPrice: e.target.value })}
                placeholder={marketStats?.currentPrice.toFixed(8) || '0.00010'}
                className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">
                {language === 'ko' ? '설정 시 현재 시세를 강제로 변경합니다. (비워두면 최근 거래 가격 사용)' : 'Override current market price. (Leave empty to use recent trade price)'}
              </p>
            </div>
          </div>
        </div>

        {/* 판매 수량 관리 */}
        <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
          <div className="mb-4">
            <h2 className="text-xl font-bold text-white">
              {language === 'ko' ? '판매 수량 관리' : 'Sell Amount Management'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko' ? '판매할 MSUO 코인 수량을 설정합니다.' : 'Set the amount of MSUO coins to sell.'}
            </p>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '판매할 MSUO 코인 수량' : 'MSUO Coin Sell Amount'}
              </label>
              <input
                type="number"
                step="1"
                value={settings.upcSellAmount}
                onChange={(e) => setSettings({ ...settings, upcSellAmount: e.target.value })}
                placeholder="0"
                className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">
                {language === 'ko' ? '관리자가 판매할 MSUO 코인 수량 (0이면 제한 없음)' : 'Amount of MSUO coins to sell (0 = unlimited)'}
              </p>
            </div>
          </div>
        </div>

        {/* 봇 관리 */}
        <div className="bg-[#192633] rounded-xl border border-gray-700 p-6">
          <div className="mb-4">
            <h2 className="text-xl font-bold text-white">
              {language === 'ko' ? '거래 봇 관리' : 'Trading Bot Management'}
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              {language === 'ko' ? '자동 매수/매도 봇을 설정합니다.' : 'Configure automatic buy/sell bot.'}
            </p>
          </div>
          <div className="space-y-4">
            <div>
              <label className="flex items-center gap-2 mb-2">
                <input
                  type="checkbox"
                  checked={settings.exchangeBotEnabled === 'true'}
                  onChange={(e) => setSettings({ ...settings, exchangeBotEnabled: e.target.checked ? 'true' : 'false' })}
                  className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                />
                <span className="text-sm font-medium text-gray-300">
                  {language === 'ko' ? '거래 봇 활성화' : 'Enable Trading Bot'}
                </span>
              </label>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '최저가 (USDT)' : 'Min Price (USDT)'}
              </label>
              <input
                type="number"
                step="0.00000001"
                value={settings.exchangeBotMinPrice}
                onChange={(e) => setSettings({ ...settings, exchangeBotMinPrice: e.target.value })}
                placeholder="0.00005"
                className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '최고가 (USDT)' : 'Max Price (USDT)'}
              </label>
              <input
                type="number"
                step="0.00000001"
                value={settings.exchangeBotMaxPrice}
                onChange={(e) => setSettings({ ...settings, exchangeBotMaxPrice: e.target.value })}
                placeholder="0.00015"
                className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '스프레드 (USDT)' : 'Spread (USDT)'}
              </label>
              <input
                type="number"
                step="0.00000001"
                value={settings.exchangeBotSpread}
                onChange={(e) => setSettings({ ...settings, exchangeBotSpread: e.target.value })}
                placeholder="0.00001"
                className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">
                {language === 'ko' ? '봇 주문 가격과 사용자 주문 가격의 차이' : 'Price difference between bot and user orders'}
              </p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {language === 'ko' ? '봇 주문 수량 (MSUO)' : 'Bot Order Amount (MSUO)'}
              </label>
              <input
                type="number"
                step="1"
                value={settings.exchangeBotOrderAmount}
                onChange={(e) => setSettings({ ...settings, exchangeBotOrderAmount: e.target.value })}
                placeholder="1000"
                className="w-full px-4 py-2 border border-gray-700 rounded-lg bg-[#111a22] text-white focus:ring-2 focus:ring-[#137fec] focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </div>

      {/* 저장 버튼 */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={saving}
          className="px-6 py-2 bg-[#137fec] text-white rounded-lg font-medium hover:bg-[#0f6bc7] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {saving
            ? (language === 'ko' ? '저장 중...' : 'Saving...')
            : (language === 'ko' ? '설정 저장' : 'Save Settings')}
        </button>
      </div>
    </div>
  );
}

