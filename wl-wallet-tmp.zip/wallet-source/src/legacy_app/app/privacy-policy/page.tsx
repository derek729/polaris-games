'use client';

import { useI18n } from '@/lib/i18n/context';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { CompanyBrand } from '@/components/CompanyBrand';
import LanguageSwitcher from '@/components/LanguageSwitcher';

export default function PrivacyPolicyPage() {
  const { t, language } = useI18n();
  const router = useRouter();

  return (
    <div className="relative flex min-h-screen w-full flex-col bg-[#F5F7FA] dark:bg-[#101922]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <header className="flex items-center justify-between mb-8 pb-4 border-b border-gray-200 dark:border-white/10">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.back()}
                className="flex items-center justify-center rounded-lg h-10 w-10 bg-white dark:bg-white/10 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-white/20 transition-colors"
                title={language === 'ko' ? '뒤로가기' : 'Go back'}
              >
                <span className="material-symbols-outlined text-xl">arrow_back</span>
              </button>
              <CompanyBrand
                wrapperClassName="flex items-center gap-3 text-gray-900 dark:text-white"
                size={40}
                textClassName="text-lg font-bold tracking-[-0.015em] text-gray-900 dark:text-white"
              />
            </div>
            <LanguageSwitcher />
          </header>

          {/* Page Heading */}
          <div className="mb-8 pb-4 border-b border-gray-200 dark:border-white/10">
            <h1 className="text-3xl md:text-4xl font-black text-gray-900 dark:text-white tracking-[-0.033em] mb-2">
              {language === 'ko' ? '개인정보 처리 방침' : 'Privacy Policy'}
            </h1>
            <p className="text-base text-gray-500 dark:text-gray-400">
              {language === 'ko' ? '시행일자: 2025년 11월 20일' : 'Effective Date: November 20, 2025'}
            </p>
          </div>

          {/* Content */}
          <article className="prose prose-lg dark:prose-invert max-w-none space-y-8">
            <section id="section-1">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                1. {language === 'ko' ? '총칙' : 'General Provisions'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                {language === 'ko'
                  ? 'UOC GROUP은 정보통신망 이용촉진 및 정보보호 등에 관한 법률, 개인정보보호법 등 관련 법령상의 개인정보보호 규정을 준수하며, 관련 법령에 의거한 개인정보처리방침을 정하여 이용자 권익 보호에 최선을 다하고 있습니다. 본 개인정보처리방침은 회사가 제공하는 UOC GROUP AO 월렛 서비스에 적용됩니다.'
                  : 'UOC GROUP complies with personal information protection regulations under relevant laws such as the Act on Promotion of Information and Communications Network Utilization and Information Protection, and the Personal Information Protection Act, and strives to protect user rights and interests by establishing a personal information processing policy in accordance with relevant laws. This privacy policy applies to the UOC GROUP MSUO Wallet service provided by the company.'}
              </p>
            </section>

            <section id="section-2">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                2. {language === 'ko' ? '수집하는 개인정보의 항목 및 수집 방법' : 'Personal Information Items Collected and Collection Methods'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-4">
                {language === 'ko'
                  ? '회사는 회원가입, 원활한 고객상담, 각종 서비스의 제공을 위해 아래와 같은 최소한의 개인정보를 필수항목으로 수집하고 있습니다.'
                  : 'The company collects the following minimum personal information as required items for membership registration, smooth customer consultation, and provision of various services.'}
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300">
                <li>
                  <strong>{language === 'ko' ? '필수항목:' : 'Required Items:'}</strong>{' '}
                  {language === 'ko'
                    ? '이름, 아이디, 비밀번호, 이메일 주소, 휴대폰 번호'
                    : 'Name, ID, Password, Email Address, Mobile Phone Number'}
                </li>
                <li>
                  <strong>{language === 'ko' ? '선택항목:' : 'Optional Items:'}</strong>{' '}
                  {language === 'ko' ? '프로필 사진, 생년월일' : 'Profile Photo, Date of Birth'}
                </li>
                <li>
                  <strong>
                    {language === 'ko'
                      ? '서비스 이용 과정에서 생성/수집될 수 있는 정보:'
                      : 'Information that may be generated/collected during service use:'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '서비스 이용기록, 접속 로그, 쿠키, 접속 IP 정보, 결제기록, MSUO코인 지갑 주소'
                    : 'Service usage records, access logs, cookies, access IP information, payment records, MSUO Coin wallet address'}
                </li>
              </ul>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed mt-4">
                {language === 'ko'
                  ? '수집방법은 홈페이지(회원가입), 서면양식, 팩스, 전화, 상담 게시판, 이메일, 이벤트 응모, 배송요청, 생성정보 수집 툴을 통한 수집을 통해 이루어집니다.'
                  : 'Collection is made through the website (membership registration), written forms, fax, phone, consultation board, email, event participation, delivery requests, and collection tools for generated information.'}
              </p>
            </section>

            <section id="section-3">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                3. {language === 'ko' ? '개인정보의 수집 및 이용 목적' : 'Purpose of Collection and Use of Personal Information'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-4">
                {language === 'ko'
                  ? '회사는 수집한 개인정보를 다음의 목적을 위해 활용합니다.'
                  : 'The company uses the collected personal information for the following purposes.'}
              </p>
              <ol className="list-decimal pl-6 space-y-2 text-gray-700 dark:text-gray-300">
                <li>
                  <strong>
                    {language === 'ko'
                      ? '서비스 제공에 관한 계약 이행 및 요금 정산:'
                      : 'Contract fulfillment and fee settlement for service provision:'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '콘텐츠 제공, 구매 및 요금 결제, 물품배송 또는 청구지 등 발송, 금융거래 본인 인증 및 금융 서비스'
                    : 'Content provision, purchase and fee payment, shipping of goods or invoices, financial transaction identity verification and financial services'}
                </li>
                <li>
                  <strong>{language === 'ko' ? '회원 관리:' : 'Member Management:'}</strong>{' '}
                  {language === 'ko'
                    ? '회원제 서비스 이용에 따른 본인확인, 개인 식별, 불량회원의 부정 이용 방지와 비인가 사용 방지, 가입 의사 확인, 연령확인, 불만처리 등 민원처리, 고지사항 전달'
                    : 'Identity verification for membership service use, personal identification, prevention of unauthorized use by bad members, confirmation of membership intention, age verification, complaint handling, notice delivery'}
                </li>
                <li>
                  <strong>
                    {language === 'ko' ? '마케팅 및 광고에 활용:' : 'Use for Marketing and Advertising:'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '신규 서비스(제품) 개발 및 특화, 이벤트 등 광고성 정보 전달, 인구통계학적 특성에 따른 서비스 제공 및 광고 게재, 접속 빈도 파악 또는 회원의 서비스 이용에 대한 통계'
                    : 'Development and specialization of new services (products), delivery of promotional information such as events, service provision and advertising placement according to demographic characteristics, understanding of access frequency or statistics on member service use'}
                </li>
              </ol>
            </section>

            <section id="section-4">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                4. {language === 'ko' ? '개인정보의 보유 및 이용기간' : 'Retention and Use Period of Personal Information'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                {language === 'ko'
                  ? '원칙적으로, 개인정보 수집 및 이용목적이 달성된 후에는 해당 정보를 지체 없이 파기합니다. 단, 관계법령의 규정에 의하여 보존할 필요가 있는 경우 회사는 아래와 같이 관계법령에서 정한 일정한 기간 동안 회원정보를 보관합니다.'
                  : 'In principle, personal information is destroyed without delay after the purpose of collection and use is achieved. However, if it is necessary to retain information in accordance with relevant laws and regulations, the company retains member information for a certain period as prescribed by relevant laws and regulations.'}
              </p>
            </section>

            <section id="section-5">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                5. {language === 'ko' ? '개인정보의 제3자 제공' : 'Provision of Personal Information to Third Parties'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                {language === 'ko'
                  ? '회사는 이용자들의 개인정보를 "3. 개인정보의 수집목적 및 이용목적"에서 고지한 범위 내에서 사용하며, 이용자의 사전 동의 없이는 동 범위를 초과하여 이용하거나 원칙적으로 이용자의 개인정보를 외부에 공개하지 않습니다.'
                  : 'The company uses users\' personal information within the scope notified in "3. Purpose of Collection and Use of Personal Information" and does not use it beyond this scope or disclose users\' personal information to external parties without prior consent.'}
              </p>
            </section>

            <section id="section-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                6. {language === 'ko' ? '이용자의 권리 및 그 행사방법' : 'User Rights and How to Exercise Them'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                {language === 'ko'
                  ? '이용자는 언제든지 등록되어 있는 자신의 개인정보를 조회하거나 수정할 수 있으며 가입해지를 요청할 수도 있습니다. 개인정보 조회, 수정을 위해서는 \'개인정보변경\'(또는 \'회원정보수정\' 등)을, 가입해지(동의철회)를 위해서는 \'회원탈퇴\'를 클릭하여 본인 확인 절차를 거치신 후 직접 열람, 정정 또는 탈퇴가 가능합니다.'
                  : 'Users can view or modify their registered personal information at any time and may also request membership cancellation. To view or modify personal information, click \'Change Personal Information\' (or \'Modify Member Information\'), and to cancel membership (withdraw consent), click \'Withdraw Membership\' and go through the identity verification process to directly view, correct, or withdraw.'}
              </p>
            </section>

            <section id="section-7">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                7. {language === 'ko' ? '개인정보의 파기절차 및 방법' : 'Procedure and Method of Personal Information Destruction'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                {language === 'ko'
                  ? '회사는 원칙적으로 개인정보 수집 및 이용목적이 달성된 후에는 해당 정보를 지체없이 파기합니다. 파기절차 및 방법은 다음과 같습니다.'
                  : 'The company destroys personal information without delay after the purpose of collection and use is achieved. The procedure and method of destruction are as follows.'}
              </p>
            </section>

            <section id="section-8">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                8. {language === 'ko' ? '개인정보 보호책임자' : 'Personal Information Protection Officer'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                {language === 'ko'
                  ? '회사는 고객의 개인정보를 보호하고 개인정보와 관련한 불만을 처리하기 위하여 아래와 같이 관련 부서 및 개인정보 보호책임자를 지정하고 있습니다.'
                  : 'The company has designated the relevant department and personal information protection officer as follows to protect customers\' personal information and handle complaints related to personal information.'}
                <br />
                <strong>{language === 'ko' ? '이름:' : 'Name:'}</strong> {language === 'ko' ? '홍길동' : 'Hong Gildong'}
                <br />
                <strong>
                  {language === 'ko' ? '소속/직위:' : 'Department/Position:'}
                </strong>{' '}
                {language === 'ko' ? '정보보호팀 / 팀장' : 'Information Security Team / Team Leader'}
                <br />
                <strong>{language === 'ko' ? '이메일:' : 'Email:'}</strong> privacy@aogroup.com
                <br />
                <strong>{language === 'ko' ? '전화번호:' : 'Phone:'}</strong> 02-1234-5678
              </p>
            </section>

            <section id="section-9">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                9. {language === 'ko' ? '고지의 의무' : 'Duty to Notify'}
              </h2>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                {language === 'ko'
                  ? '현 개인정보처리방침 내용 추가, 삭제 및 수정이 있을 시에는 개정 최소 7일전부터 홈페이지의 \'공지사항\'을 통해 고지할 것입니다.'
                  : 'If there are additions, deletions, or modifications to this privacy policy, we will notify you through the \'Notice\' section of the website at least 7 days before the revision.'}
              </p>
            </section>
          </article>

          {/* Footer */}
          <footer className="mt-12 pt-8 border-t border-gray-200 dark:border-white/10 text-center">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
              © 2026 MSUO Foundation. All Rights Reserved.
            </p>
            <div className="flex justify-center gap-4 text-xs">
              <Link
                href="/service-terms"
                className="text-[#137fec] hover:underline"
              >
                {language === 'ko' ? '서비스 약관' : 'Terms of Service'}
              </Link>
              <span className="text-gray-400">·</span>
              <Link
                href="/privacy-policy"
                className="text-[#137fec] hover:underline"
              >
                {language === 'ko' ? '개인정보처리방침' : 'Privacy Policy'}
              </Link>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
}

