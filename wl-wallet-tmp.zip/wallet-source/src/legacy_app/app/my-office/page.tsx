import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { cookies } from 'next/headers';
import MyOfficeClient from './MyOfficeClient';
import { isAdminUser } from '@/lib/admin-auth';

export default async function MyOfficePage() {
  // 인증 확인
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  // 관리자는 관리자 페이지로 리다이렉트
  if (isAdminUser(user)) {
    redirect('/a0-admin');
  }

  try {
    // 쿠키에서 userId 가져오기
    const cookieStore = await cookies();
    const userId = cookieStore.get('userId')?.value;

    if (!userId) {
      redirect('/login');
    }

    // API에서 사용자 데이터 가져오기
    const baseUrl = process.env.NODE_ENV === 'production'
      ? process.env.NEXT_PUBLIC_BASE_URL || 'https://your-domain.com'
      : 'http://localhost:3009';

    const response = await fetch(`${baseUrl}/api/user/me`, {
      cache: 'no-store',
      headers: {
        'Content-Type': 'application/json',
        'Cookie': `userId=${userId}`,
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        // redirect는 try-catch 밖에서 호출해야 함
        // 여기서는 에러를 throw하고 catch 블록에서 처리
        throw new Error('UNAUTHORIZED');
      }
      throw new Error('사용자 데이터를 불러올 수 없습니다.');
    }

    const userData = await response.json();
    
    if (!userData.ok) {
      throw new Error(userData.error || '사용자 데이터를 불러올 수 없습니다.');
    }

    // API 응답 구조에 맞게 user 데이터 추출
    // /api/user/me는 { ok: true, users: {...} } 형태로 반환
    const user = userData.users || userData.data;
    
    if (!user) {
      throw new Error('사용자 데이터를 불러올 수 없습니다.');
    }

    // _count 필드가 없으면 기본값 설정
    const userWithCount = {
      ...users,
      _count: user._count || {
        other_users_users_referrerIdTousers: 0,
        investments: 0,
      },
    };

    return <MyOfficeClient user={userWithCount} />;
  } catch (error: any) {
    // NEXT_REDIRECT 에러는 다시 throw (Next.js가 처리)
    if (error?.digest === 'NEXT_REDIRECT') {
      throw error;
    }
    
    // 인증 오류인 경우 리다이렉트
    if (error?.message === 'UNAUTHORIZED') {
      redirect('/login');
    }
    
    console.error('My Office error:', error);
    redirect('/login');
  }
}

