'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import MobileNavigation from '@/components/MobileNavigation';
import DesktopNavLinks from '@/components/navigation/DesktopNavLinks';
import { CompanyBrand } from '@/components/CompanyBrand';
import { X, Edit2, Loader2, Lock } from 'lucide-react';

interface User {
  id: string;
  username: string;
  email: string;
  rank: number;
  totalInvestment: number;
  personalCoin: number;
  createdAt: string;
  referralCode?: string | null;
  referrer?: { username: string } | null;
  _count: {
    other_users_users_referrerIdTousers: number;
    investments: number;
  };
}

export default function MyOfficeClient({ users: initialUser }: { users: User }) {
  const router = useRouter();
  const pathname = usePathname();
  const { t, language } = useI18n();
  const [mounted, setMounted] = useState(false);
  const [currentPath, setCurrentPath] = useState('/my-office');
  const [copied, setCopied] = useState<'code' | 'link' | null>(null);
  const [user, setUser] = useState<User>(initialUser);
  const [isUsernameModalOpen, setIsUsernameModalOpen] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [isChangingUsername, setIsChangingUsername] = useState(false);
  const [usernameError, setUsernameError] = useState<string | null>(null);
  
  // 비밀번호 변경 관련 상태
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  useEffect(() => {
    setMounted(true);
    setCurrentPath(pathname);
  }, [pathname]);

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-white">{t.common.loading}</div>
      </div>
    );
  }

  // user가 없으면 에러 표시
  if (!user) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-red-400">{t.common.error}: {t.errors.notFound}</div>
      </div>
    );
  }

  // 등급 이름 (언어별) - team.ranks 번역 사용
  const getRankName = (rank: number) => {
    switch (rank) {
      case 0: return t.team.ranks.new;
      case 1: return t.team.ranks.star1;
      case 2: return t.team.ranks.star2;
      case 3: return t.team.ranks.star3;
      case 4: return t.team.ranks.star4;
      case 5: return t.team.ranks.star5;
      default: return t.team.ranks.new;
    }
  };
  const rankName = getRankName(user.rank ?? 0);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleCopyCode = async () => {
    if (!user.referralCode) return;
    
    try {
      await navigator.clipboard.writeText(user.referralCode);
      setCopied('code');
      setTimeout(() => setCopied(null), 2000);
    } catch (error) {
      console.error('Failed to copy code:', error);
    }
  };

  const handleCopyLink = async () => {
    if (!user.referralCode) return;
    
    const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
    const referralLink = `${baseUrl}/register?ref=${user.referralCode}`;
    
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopied('link');
      setTimeout(() => setCopied(null), 2000);
    } catch (error) {
      console.error('Failed to copy link:', error);
    }
  };

  const handleOpenUsernameModal = () => {
    setNewUsername(user.username);
    setUsernameError(null);
    setIsUsernameModalOpen(true);
  };

  const handleCloseUsernameModal = () => {
    setIsUsernameModalOpen(false);
    setNewUsername('');
    setUsernameError(null);
  };

  const handleChangeUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    setUsernameError(null);

    // 유효성 검사
    if (!newUsername || newUsername.trim().length === 0) {
      setUsernameError('사용자명을 입력해주세요.');
      return;
    }

    if (newUsername.trim().length < 3) {
      setUsernameError('사용자명은 최소 3자 이상이어야 합니다.');
      return;
    }

    if (newUsername.trim().length > 50) {
      setUsernameError('사용자명은 50자 이하여야 합니다.');
      return;
    }

    // 영문, 숫자, 언더스코어, 하이픈만 허용
    const usernameRegex = /^[a-zA-Z0-9_-]+$/;
    if (!usernameRegex.test(newUsername.trim())) {
      setUsernameError('사용자명은 영문, 숫자, 언더스코어(_), 하이픈(-)만 사용할 수 있습니다.');
      return;
    }

    if (newUsername.trim() === user.username) {
      setUsernameError('현재 사용자명과 동일합니다.');
      return;
    }

    setIsChangingUsername(true);

    try {
      const response = await fetch('/api/user/username', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          username: newUsername.trim(),
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setUsernameError(result.error || '사용자명 변경에 실패했습니다.');
        return;
      }

      // 사용자 정보 업데이트
      setUser({ ...users, username: result.data.users.username });
      handleCloseUsernameModal();
      
      // 페이지 새로고침하여 최신 정보 반영
      router.refresh();
      
      // 성공 메시지 (선택사항)
      alert('사용자명이 성공적으로 변경되었습니다.');
    } catch (error: any) {
      console.error('사용자명 변경 실패:', error);
      setUsernameError('사용자명 변경 중 오류가 발생했습니다.');
    } finally {
      setIsChangingUsername(false);
    }
  };

  // 비밀번호 변경 관련 함수들
  const handleOpenPasswordModal = () => {
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setPasswordError(null);
    setShowCurrentPassword(false);
    setShowNewPassword(false);
    setShowConfirmPassword(false);
    setIsPasswordModalOpen(true);
  };

  const handleClosePasswordModal = () => {
    setIsPasswordModalOpen(false);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setPasswordError(null);
    setShowCurrentPassword(false);
    setShowNewPassword(false);
    setShowConfirmPassword(false);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);

    // 유효성 검사
    if (!currentPassword) {
      setPasswordError('현재 비밀번호를 입력해주세요.');
      return;
    }

    if (!newPassword) {
      setPasswordError('새 비밀번호를 입력해주세요.');
      return;
    }

    if (newPassword.length < 6) {
      setPasswordError('비밀번호는 최소 6자 이상이어야 합니다.');
      return;
    }

    if (newPassword.length > 100) {
      setPasswordError('비밀번호는 100자 이하여야 합니다.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('새 비밀번호와 확인 비밀번호가 일치하지 않습니다.');
      return;
    }

    if (currentPassword === newPassword) {
      setPasswordError('현재 비밀번호와 새 비밀번호가 동일합니다.');
      return;
    }

    setIsChangingPassword(true);

    try {
      const response = await fetch('/api/user/password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          currentPassword,
          newPassword,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.ok) {
        setPasswordError(result.error || '비밀번호 변경에 실패했습니다.');
        return;
      }

      handleClosePasswordModal();
      
      // 성공 메시지
      alert('비밀번호가 성공적으로 변경되었습니다.');
    } catch (error: any) {
      console.error('비밀번호 변경 실패:', error);
      setPasswordError('비밀번호 변경 중 오류가 발생했습니다.');
    } finally {
      setIsChangingPassword(false);
    }
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1 overflow-visible">
            {/* Header */}
            <header className="flex flex-col border-b border-solid border-white/10 dark:border-white/10 px-6 py-3">
              {/* 첫 번째 줄: 회사 로고만 */}
              <div className="flex items-center justify-between w-full">
                <Link href="/dashboard" className="flex items-center gap-4 text-white hover:opacity-80 transition-opacity shrink-0">
                  <CompanyBrand
                    wrapperClassName="gap-4"
                    size={44}
                    textClassName="text-white text-lg font-bold leading-tight tracking-[-0.015em]"
                  />
                </Link>
              </div>
              
              {/* 두 번째 줄: 햄버거 버튼(왼쪽) + 데스크탑 네비게이션(중앙) + 오른쪽 버튼들 */}
              <div className="flex items-center justify-between w-full mt-2">
                {/* 왼쪽: 햄버거 버튼 (모바일에서만 표시) */}
                <div className="md:hidden">
                  <MobileNavigation
                    user={user}
                    currentPath={currentPath}
                  />
                </div>
                
                {/* 중앙: 데스크탑 네비게이션 */}
                <div className="hidden md:flex flex-1 justify-center">
                  <DesktopNavLinks currentPath={currentPath} />
                </div>
                
                {/* 오른쪽: 언어 전환 + 버튼들 */}
                <div className="flex items-center gap-3 sm:gap-4">
                  <LanguageSwitcher />
                  <div className="flex gap-2">
                    <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white">
                      <span className="material-symbols-outlined">notifications</span>
                    </button>
                    <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white">
                      <span className="material-symbols-outlined">help</span>
                    </button>
                    <button
                      onClick={handleLogout}
                      className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors"
                      title="Logout"
                    >
                      <span className="material-symbols-outlined">logout</span>
                    </button>
                  </div>
                  <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] flex items-center justify-center text-white font-bold">
                    {user.username?.[0]?.toUpperCase() || 'U'}
                  </div>
                </div>
              </div>
            </header>

            <main className="flex-1 p-2 sm:p-4 md:p-6 overflow-visible relative z-0">
              {/* Page Title */}
              <div className="flex flex-wrap justify-between gap-4 py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    {t.myOffice.title}
                  </p>
                  <p className="text-gray-400 dark:text-gray-400 text-base font-normal leading-normal">
                    {t.myOffice.subtitle}
                  </p>
                </div>
              </div>

              {/* Profile Section */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 p-2 mt-4">
                {/* Profile Card */}
                <div className="lg:col-span-2 flex flex-col gap-4 rounded-xl border border-white/10 p-6 bg-white/5">
                  <h3 className="text-white text-xl font-bold">{t.myOffice.profileInfo}</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="bg-gradient-to-br from-[#137fec] to-[#3A4DFF] rounded-full size-20 flex items-center justify-center text-white text-3xl font-bold">
                        {user.username?.[0]?.toUpperCase() || 'U'}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <p className="text-white text-2xl font-bold">{user.username}</p>
                          <button
                            onClick={handleOpenUsernameModal}
                            className="flex items-center gap-1 px-2 py-1 text-xs text-blue-400 hover:text-blue-300 hover:bg-white/5 rounded-lg transition-colors"
                            title="사용자명 변경"
                          >
                            <Edit2 className="h-3 w-3" />
                            <span>{language === 'ko' ? '변경' : 'Edit'}</span>
                          </button>
                        </div>
                        <p className="text-gray-400 text-sm">{user.email}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-6">
                      <div className="flex flex-col gap-2 rounded-xl p-4 bg-white/5 border border-white/10">
                        <p className="text-gray-300 text-sm font-medium">{t.myOffice.rank}</p>
                        <p className="text-white text-xl font-bold">{rankName}</p>
                      </div>
                      <div className="flex flex-col gap-2 rounded-xl p-4 bg-white/5 border border-white/10">
                        <p className="text-gray-300 text-sm font-medium">{t.myOffice.joinDate}</p>
                        <p className="text-white text-xl font-bold">
                          {new Date(user.createdAt).toLocaleDateString(language === 'ko' ? 'ko-KR' : 'en-US')}
                        </p>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-white/10">
                      <button
                        onClick={handleOpenPasswordModal}
                        className="flex items-center gap-2 px-4 py-2 text-sm text-blue-400 hover:text-blue-300 hover:bg-white/5 rounded-lg transition-colors"
                        title="비밀번호 변경"
                      >
                        <Lock className="h-4 w-4" />
                        <span>{language === 'ko' ? '비밀번호 변경' : 'Change Password'}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Stats Card */}
                <div className="lg:col-span-1 flex flex-col gap-4">
                  <div className="rounded-xl border border-white/10 bg-white/5 p-6">
                    <h3 className="text-white text-lg font-bold mb-4">{t.myOffice.statistics}</h3>
                    <div className="space-y-4">
                      <div>
                        <p className="text-gray-300 text-sm font-medium">{t.myOffice.totalInvestment}</p>
                        <p className="text-white text-2xl font-bold mt-1">
                          ${user.totalInvestment.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US')}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-300 text-sm font-medium">{t.myOffice.coinBalance}</p>
                        <p className="text-white text-2xl font-bold mt-1">
                          {user.personalCoin.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US')} MSUO
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-300 text-sm font-medium">{t.myOffice.referredMembers}</p>
                        <p className="text-white text-2xl font-bold mt-1">
                          {user._count.referredUsers}{language === 'ko' ? '명' : ''}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-300 text-sm font-medium">{t.myOffice.investmentCount}</p>
                        <p className="text-white text-2xl font-bold mt-1">
                          {user._count.investments}{language === 'ko' ? '건' : ''}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Referral Code Card */}
              {user.referralCode && (
                <div className="mt-4 p-2">
                  <div className="rounded-xl border border-white/10 bg-gradient-to-br from-blue-500/10 to-purple-500/10 p-6">
                    <h3 className="text-white text-lg font-bold mb-2">{t.myOffice.referralCodeTitle}</h3>
                    <p className="text-gray-400 text-sm mb-4">{t.myOffice.referralCodeDescription}</p>
                    
                    {/* Referral Code Display */}
                    <div className="flex items-center gap-3 mb-4">
                      <div className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-3">
                        <p className="text-white font-mono text-xl font-bold tracking-wider">
                          {user.referralCode}
                        </p>
                      </div>
                      <button
                        onClick={handleCopyCode}
                        className="flex items-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
                      >
                        <span className="material-symbols-outlined text-lg">
                          {copied === 'code' ? 'check' : 'content_copy'}
                        </span>
                        {copied === 'code' ? t.myOffice.codeCopied : t.myOffice.copyCode}
                      </button>
                    </div>

                    {/* Referral Link */}
                    <div className="flex items-center gap-3">
                      <div className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2">
                        <p className="text-gray-300 text-sm truncate">
                          {typeof window !== 'undefined' ? `${window.location.origin}/register?ref=${user.referralCode}` : ''}
                        </p>
                      </div>
                      <button
                        onClick={handleCopyLink}
                        className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors"
                      >
                        <span className="material-symbols-outlined text-lg">
                          {copied === 'link' ? 'check' : 'link'}
                        </span>
                        {copied === 'link' ? t.myOffice.linkCopied : t.myOffice.copyLink}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Referrer Info */}
              {user.referrer && (
                <div className="mt-4 p-2">
                  <div className="rounded-xl border border-white/10 bg-white/5 p-6">
                    <h3 className="text-white text-lg font-bold mb-4">{t.myOffice.referrerInfo}</h3>
                    <p className="text-gray-300">
                      {t.myOffice.referrer}: <span className="text-white font-semibold">{user.other_users_users_referrerIdTousers.username}</span>
                    </p>
                  </div>
                </div>
              )}
            </main>
          </div>
        </div>
      </div>

      {/* 사용자명 변경 모달 */}
      {isUsernameModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
            {/* 헤더 */}
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 p-2">
                  <Edit2 className="h-5 w-5 text-blue-400" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">
                    {language === 'ko' ? '사용자명 변경' : 'Change Username'}
                  </h2>
                  <p className="text-sm text-slate-400">
                    {language === 'ko' ? '새로운 사용자명을 입력해주세요' : 'Enter a new username'}
                  </p>
                </div>
              </div>
              <button
                onClick={handleCloseUsernameModal}
                className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* 에러 메시지 */}
            {usernameError && (
              <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
                {usernameError}
              </div>
            )}

            {/* 폼 */}
            <form onSubmit={handleChangeUsername} className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">
                  {language === 'ko' ? '현재 사용자명' : 'Current Username'}
                </label>
                <input
                  type="text"
                  value={user.username}
                  disabled
                  className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-slate-400 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">
                  {language === 'ko' ? '새 사용자명' : 'New Username'} <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={newUsername}
                  onChange={(e) => {
                    setNewUsername(e.target.value);
                    setUsernameError(null);
                  }}
                  className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  placeholder={language === 'ko' ? '3-50자, 영문/숫자/_/-만 가능' : '3-50 characters, letters/numbers/_/- only'}
                  required
                  minLength={3}
                  maxLength={50}
                  pattern="[a-zA-Z0-9_-]+"
                />
                <p className="mt-2 text-xs text-slate-400">
                  {language === 'ko' 
                    ? '• 최소 3자, 최대 50자\n• 영문, 숫자, 언더스코어(_), 하이픈(-)만 사용 가능'
                    : '• Minimum 3 characters, maximum 50\n• Only letters, numbers, underscore(_), and hyphen(-)'}
                </p>
              </div>

              {/* 버튼 */}
              <div className="mt-6 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={handleCloseUsernameModal}
                  className="rounded-lg border border-white/10 bg-slate-800/50 px-5 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
                >
                  {language === 'ko' ? '취소' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isChangingUsername}
                  className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-blue-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isChangingUsername ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      {language === 'ko' ? '변경 중...' : 'Changing...'}
                    </>
                  ) : (
                    <>
                      <Edit2 className="h-4 w-4" />
                      {language === 'ko' ? '변경하기' : 'Change'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 비밀번호 변경 모달 */}
      {isPasswordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 shadow-2xl">
            {/* 헤더 */}
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 p-2">
                  <Lock className="h-5 w-5 text-blue-400" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">
                    {language === 'ko' ? '비밀번호 변경' : 'Change Password'}
                  </h2>
                  <p className="text-sm text-slate-400">
                    {language === 'ko' ? '현재 비밀번호를 확인하고 새 비밀번호를 입력해주세요' : 'Verify current password and enter new password'}
                  </p>
                </div>
              </div>
              <button
                onClick={handleClosePasswordModal}
                className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-800 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* 에러 메시지 */}
            {passwordError && (
              <div className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
                {passwordError}
              </div>
            )}

            {/* 폼 */}
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">
                  {language === 'ko' ? '현재 비밀번호' : 'Current Password'} <span className="text-red-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showCurrentPassword ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={(e) => {
                      setCurrentPassword(e.target.value);
                      setPasswordError(null);
                    }}
                    className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 pr-10 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    placeholder={language === 'ko' ? '현재 비밀번호를 입력하세요' : 'Enter current password'}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-300"
                  >
                    <span className="material-symbols-outlined text-lg">
                      {showCurrentPassword ? 'visibility_off' : 'visibility'}
                    </span>
                  </button>
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">
                  {language === 'ko' ? '새 비밀번호' : 'New Password'} <span className="text-red-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => {
                      setNewPassword(e.target.value);
                      setPasswordError(null);
                    }}
                    className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 pr-10 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    placeholder={language === 'ko' ? '새 비밀번호를 입력하세요 (최소 6자)' : 'Enter new password (min 6 characters)'}
                    required
                    minLength={6}
                    maxLength={100}
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-300"
                  >
                    <span className="material-symbols-outlined text-lg">
                      {showNewPassword ? 'visibility_off' : 'visibility'}
                    </span>
                  </button>
                </div>
                <p className="mt-2 text-xs text-slate-400">
                  {language === 'ko' 
                    ? '• 최소 6자, 최대 100자'
                    : '• Minimum 6 characters, maximum 100'}
                </p>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">
                  {language === 'ko' ? '새 비밀번호 확인' : 'Confirm New Password'} <span className="text-red-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => {
                      setConfirmPassword(e.target.value);
                      setPasswordError(null);
                    }}
                    className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-2.5 pr-10 text-white placeholder-slate-500 focus:border-blue-500/50 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    placeholder={language === 'ko' ? '새 비밀번호를 다시 입력하세요' : 'Re-enter new password'}
                    required
                    minLength={6}
                    maxLength={100}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-300"
                  >
                    <span className="material-symbols-outlined text-lg">
                      {showConfirmPassword ? 'visibility_off' : 'visibility'}
                    </span>
                  </button>
                </div>
              </div>

              {/* 버튼 */}
              <div className="mt-6 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={handleClosePasswordModal}
                  className="rounded-lg border border-white/10 bg-slate-800/50 px-5 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/50"
                >
                  {language === 'ko' ? '취소' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  disabled={isChangingPassword}
                  className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-500 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/50 transition hover:scale-105 hover:shadow-xl hover:shadow-blue-500/50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isChangingPassword ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      {language === 'ko' ? '변경 중...' : 'Changing...'}
                    </>
                  ) : (
                    <>
                      <Lock className="h-4 w-4" />
                      {language === 'ko' ? '변경하기' : 'Change'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

