'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import MobileNavigation from '@/components/MobileNavigation';
import { CompanyBrand } from '@/components/CompanyBrand';

interface Reward {
  id: string;
  type: string;
  amount: number;
  description: string;
  createdAt: string;
  sourceUserId?: string | null;
  generation?: number | null;
}

interface RewardsData {
  rewards: Reward[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  stats: {
    total: number;
    daily: number;
    referralMatching: number;
    matching: number;
    rankLeadership: number;
    leadership: number;
  };
}

interface User {
  id: string;
  username: string;
  email: string;
  rank: number;
  personalCoin: number;
}

export default function RewardsClient({
  user,
  initialRewards,
}: {
  users: User;
  initialRewards: RewardsData;
}) {
  const router = useRouter();
  const { t, language } = useI18n();
  const [mounted, setMounted] = useState(false);
  const [currentPath, setCurrentPath] = useState('/rewards');
  const [rewards, setRewards] = useState<RewardsData>(initialRewards);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<'all' | 'DAILY' | 'REFERRAL' | 'MATCHING' | 'RANK' | 'TEAM'>('all');
  const [timeRange, setTimeRange] = useState<'7' | '30' | '90' | 'all'>('30');

  useEffect(() => {
    setMounted(true);
  }, []);

  const fetchRewards = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        type: filter,
        period: timeRange,
        page: '1',
        limit: '50',
      });

      const res = await fetch(`/api/user/rewards?${params}`, {
        credentials: 'include',
      });
      const data = await res.json();
      if (data.ok && data.data) {
        setRewards(data.data);
      }
    } catch (err) {
      console.error('리워드 조회 실패:', err);
    } finally {
      setLoading(false);
    }
  }, [filter, timeRange]);

  useEffect(() => {
    if (mounted) {
      fetchRewards();
    }
  }, [mounted, filter, timeRange, fetchRewards]);

  const getIcon = useCallback((type: string) => {
    switch (type) {
      case 'REFERRAL':
      case 'MATCHING':
        return 'emoji_events';
      case 'DAILY':
        return 'account_balance_wallet';
      case 'RANK':
      case 'TEAM':
        return 'workspace_premium';
      default:
        return 'description';
    }
  }, []);

  const getColor = useCallback((type: string) => {
    switch (type) {
      case 'REFERRAL':
      case 'MATCHING':
        return 'bg-blue-500/20 text-blue-400';
      case 'DAILY':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'RANK':
      case 'TEAM':
        return 'bg-purple-500/20 text-purple-400';
      default:
        return 'bg-green-500/20 text-green-400';
    }
  }, []);

  const getTypeName = useCallback((type: string) => {
    const typeNames: Record<string, string> = {
      DAILY: language === 'ko' ? '일일 리워드' : 'Daily Reward',
      REFERRAL: language === 'ko' ? '추천인 보너스' : 'Referral Bonus',
      MATCHING: language === 'ko' ? '매칭 보너스' : 'Matching Bonus',
      RANK: language === 'ko' ? '랭크 보너스' : 'Rank Bonus',
      TEAM: language === 'ko' ? '리더십 보너스' : 'Leadership Bonus',
    };
    return typeNames[type] || type;
  }, [language]);

  const formatDate = useCallback((dateString: string) => {
    return new Date(dateString).toLocaleDateString(language === 'ko' ? 'ko-KR' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }, [language]);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-white">{t.common.loading}</div>
      </div>
    );
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1 overflow-visible">
            {/* Header */}
            <header className="flex flex-col border-b border-solid border-white/10 dark:border-white/10 px-6 py-3">
              {/* 첫 번째 줄: 회사 로고만 */}
              <div className="flex items-center justify-between w-full">
                <Link href="/dashboard" className="flex items-center gap-4 text-white hover:opacity-80 transition-opacity shrink-0">
                  <CompanyBrand
                    wrapperClassName="gap-4"
                    size={44}
                    textClassName="text-white text-lg font-bold leading-tight tracking-[-0.015em]"
                  />
                </Link>
              </div>
              
              {/* 두 번째 줄: 햄버거 버튼(왼쪽) + 데스크탑 네비게이션(중앙) + 오른쪽 버튼들 */}
              <div className="flex items-center justify-between w-full mt-2">
                {/* 왼쪽: 햄버거 버튼 (모바일에서만 표시) */}
                <div className="md:hidden">
                  <MobileNavigation
                    user={user || { username: '', personalCoin: 0 }}
                    currentPath={currentPath}
                  />
                </div>
                
                {/* 중앙: 데스크탑 네비게이션 */}
                <div className="hidden md:flex flex-1 justify-center gap-8 min-w-0">
                  <div className="flex items-center gap-9">
                    <Link
                      href="/dashboard"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.dashboard}
                    </Link>
                    <Link
                      href="/my-office"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.myOffice}
                    </Link>
                    <Link
                      href="/products"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.products}
                    </Link>
                    <Link
                      href="/games"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.games}
                    </Link>
                    <Link
                      href="/team"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.team}
                    </Link>
                    <Link
                      href="/rewards"
                      className="text-[#137fec] text-sm font-medium leading-normal"
                    >
                      {t.common.rewards}
                    </Link>
                  </div>
                </div>
                
                {/* 오른쪽: 언어 전환 + 버튼들 */}
                <div className="flex items-center gap-3 sm:gap-4">
                  <LanguageSwitcher />
                  <div className="flex gap-2">
                    <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white">
                      <span className="material-symbols-outlined">notifications</span>
                    </button>
                    <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white">
                      <span className="material-symbols-outlined">help</span>
                    </button>
                    <button
                      onClick={handleLogout}
                      className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors"
                      title="Logout"
                    >
                      <span className="material-symbols-outlined">logout</span>
                    </button>
                  </div>
                  <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] flex items-center justify-center text-white font-bold">
                    {user?.username?.[0]?.toUpperCase() || 'U'}
                  </div>
                </div>
              </div>
            </header>

            <main className="flex-1 p-2 sm:p-4 md:p-6 overflow-visible relative z-0">
              {/* Page Title */}
              <div className="flex flex-wrap justify-between gap-4 py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    {language === 'ko' ? '리워드 내역' : 'Reward History'}
                  </p>
                  <p className="text-gray-400 dark:text-gray-400 text-base font-normal leading-normal">
                    {language === 'ko'
                      ? '나의 리워드 수령 내역 및 통계'
                      : 'My reward receipt history and statistics'}
                  </p>
                </div>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-2">
                <div className="flex flex-col gap-2 rounded-xl p-6 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-base font-medium leading-normal">
                    {language === 'ko' ? '총 리워드' : 'Total Rewards'}
                  </p>
                  <p className="text-white tracking-light text-3xl font-bold leading-tight">
                    {rewards.stats.total.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US', {
                      maximumFractionDigits: 2,
                    })}{' '}
                    MSUO
                  </p>
                </div>
                <div className="flex flex-col gap-2 rounded-xl p-6 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-base font-medium leading-normal">
                    {language === 'ko' ? '일일 리워드' : 'Daily Rewards'}
                  </p>
                  <p className="text-white tracking-light text-3xl font-bold leading-tight">
                    {rewards.stats.daily.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US', {
                      maximumFractionDigits: 2,
                    })}{' '}
                    MSUO
                  </p>
                </div>
                <div className="flex flex-col gap-2 rounded-xl p-6 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-base font-medium leading-normal">
                    {language === 'ko' ? '추천/매칭 보너스' : 'Referral/Matching Bonus'}
                  </p>
                  <p className="text-white tracking-light text-3xl font-bold leading-tight">
                    {rewards.stats.referralMatching.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US', {
                      maximumFractionDigits: 2,
                    })}{' '}
                    AO
                  </p>
                </div>
                <div className="flex flex-col gap-2 rounded-xl p-6 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-base font-medium leading-normal">
                    {language === 'ko' ? '랭크/리더십 보너스' : 'Rank/Leadership Bonus'}
                  </p>
                  <p className="text-white tracking-light text-3xl font-bold leading-tight">
                    {rewards.stats.rankLeadership.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US', {
                      maximumFractionDigits: 2,
                    })}{' '}
                    MSUO
                  </p>
                </div>
              </div>

              {/* Filters */}
              <div className="mt-4 p-2">
                <div className="flex flex-wrap gap-4 items-center">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-300 text-sm font-medium">
                      {language === 'ko' ? '유형:' : 'Type:'}
                    </span>
                    <div className="flex gap-1.5">
                      {(['all', 'DAILY', 'REFERRAL', 'MATCHING', 'RANK', 'TEAM'] as const).map((type) => (
                        <button
                          key={type}
                          onClick={() => setFilter(type)}
                          className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${filter === type
                            ? 'text-white bg-white/10'
                            : 'text-gray-300 hover:text-white'
                            }`}
                        >
                          {type === 'all'
                            ? language === 'ko'
                              ? '전체'
                              : 'All'
                            : type === 'DAILY'
                              ? language === 'ko'
                                ? '일일'
                                : 'Daily'
                              : type === 'REFERRAL'
                                ? language === 'ko'
                                  ? '추천'
                                  : 'Refer'
                                : type === 'MATCHING'
                                  ? language === 'ko'
                                    ? '매칭'
                                    : 'Match'
                                  : type === 'RANK'
                                    ? language === 'ko'
                                      ? '랭크'
                                      : 'Rank'
                                    : language === 'ko'
                                      ? '리더십'
                                      : 'Lead'}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-300 text-sm font-medium">
                      {language === 'ko' ? '기간:' : 'Period:'}
                    </span>
                    <div className="flex gap-2">
                      {(['7', '30', '90', 'all'] as const).map((range) => (
                        <button
                          key={range}
                          onClick={() => setTimeRange(range)}
                          className={`px-3 py-1 text-xs font-medium rounded-md ${timeRange === range
                            ? 'text-white bg-white/10'
                            : 'text-gray-300 hover:text-white'
                            }`}
                        >
                          {range === '7'
                            ? language === 'ko'
                              ? '7일'
                              : '7 days'
                            : range === '30'
                              ? language === 'ko'
                                ? '30일'
                                : '30 days'
                              : range === '90'
                                ? language === 'ko'
                                  ? '90일'
                                  : '90 days'
                                : language === 'ko'
                                  ? '전체'
                                  : 'All'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Rewards List */}
              <div className="mt-4 p-2">
                <div className="rounded-xl border border-white/10 bg-white/5 p-6">
                  <h3 className="text-white text-lg font-bold mb-4">
                    {language === 'ko' ? '리워드 내역' : 'Reward History'}
                  </h3>
                  {loading ? (
                    <div className="text-center py-12">
                      <div className="text-gray-400">{t.common.loading}</div>
                    </div>
                  ) : rewards.rewards.length > 0 ? (
                    <div className="space-y-3">
                      {rewards.rewards.map((reward) => (
                        <div
                          key={reward.id}
                          className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <div
                              className={`flex-shrink-0 size-12 rounded-full ${getColor(
                                reward.type
                              )} flex items-center justify-center`}
                            >
                              <span className="material-symbols-outlined text-xl">
                                {getIcon(reward.type)}
                              </span>
                            </div>
                            <div>
                              <p className="text-white text-base font-medium">
                                {getTypeName(reward.type)}
                              </p>
                              <p className="text-gray-400 text-sm">
                                {reward.description ? reward.description.replace(/USDT/g, 'AOT') : `${getTypeName(reward.type)} 지급`}
                              </p>
                              <p className="text-gray-500 text-xs mt-1">
                                {formatDate(reward.createdAt)}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-white text-lg font-bold">
                              +{reward.amount.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US', {
                                maximumFractionDigits: 2,
                              })}{' '}
                              MSUO
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <span className="material-symbols-outlined text-6xl text-gray-600 mb-4">
                        emoji_events
                      </span>
                      <p className="text-gray-400 text-lg">
                        {language === 'ko' ? '리워드 내역이 없습니다' : 'No reward history'}
                      </p>
                      <p className="text-gray-500 text-sm mt-2">
                        {filter !== 'all' || timeRange !== 'all'
                          ? language === 'ko'
                            ? '선택한 필터 조건에 맞는 리워드가 없습니다.'
                            : 'No rewards matching the selected filter conditions.'
                          : language === 'ko'
                            ? '아직 받은 리워드가 없습니다.'
                            : 'You have not received any rewards yet.'}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}
