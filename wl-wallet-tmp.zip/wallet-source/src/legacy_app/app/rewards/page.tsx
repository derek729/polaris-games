import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { cookies } from 'next/headers';
import RewardsClient from './RewardsClient';
import { isAdminUser } from '@/lib/admin-auth';

export default async function RewardsPage() {
  // 인증 확인
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  // 관리자는 관리자 페이지로 리다이렉트
  if (isAdminUser(user)) {
    redirect('/a0-admin');
  }

  try {
    // 쿠키에서 userId 가져오기
    const cookieStore = await cookies();
    const userId = cookieStore.get('userId')?.value;

    if (!userId) {
      redirect('/login');
    }

    // API에서 리워드 데이터 가져오기
    const baseUrl = process.env.NODE_ENV === 'production'
      ? process.env.NEXT_PUBLIC_BASE_URL || 'https://your-domain.com'
      : 'http://localhost:3009';

    const [userResponse, rewardsResponse] = await Promise.all([
      fetch(`${baseUrl}/api/user/me`, {
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/json',
          'Cookie': `userId=${userId}`,
        },
      }),
      fetch(`${baseUrl}/api/user/rewards?limit=50&page=1`, {
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/json',
          'Cookie': `userId=${userId}`,
        },
      }),
    ]);

    if (!userResponse.ok || userResponse.status === 401) {
      throw new Error('UNAUTHORIZED');
    }

    const userData = await userResponse.json();
    const rewardsData = await rewardsResponse.json();

    if (!userData.ok || !rewardsData.ok) {
      throw new Error('리워드 데이터를 불러올 수 없습니다.');
    }

    return (
      <RewardsClient
        user={userData.users || userData.data}
        initialRewards={rewardsData.data}
      />
    );
  } catch (error: any) {
    // NEXT_REDIRECT 에러는 다시 throw (Next.js가 처리)
    if (error?.digest === 'NEXT_REDIRECT') {
      throw error;
    }
    
    // 인증 오류인 경우 리다이렉트
    if (error?.message === 'UNAUTHORIZED') {
      redirect('/login');
    }
    
    console.error('Rewards error:', error);
    redirect('/login');
  }
}

