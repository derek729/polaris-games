'use client';

import { useEffect, useState, useMemo, useCallback, useRef } from 'react';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { User } from 'lucide-react';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import MobileNavigation from '@/components/MobileNavigation';
import { CompanyBrand } from '@/components/CompanyBrand';

// react-d3-tree는 클라이언트 사이드에서만 동작하므로 dynamic import
const Tree = dynamic(() => import('react-d3-tree').then((mod) => mod.Tree), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center text-gray-400">조직도 로딩 중...</div>
  ),
});

interface OrgTreeNode {
  name: string;
  attributes: {
    Rank: string;
    투자: string;
  };
  children?: OrgTreeNode[];
}

interface TeamData {
  users: {
    id: string;
    username: string;
    email: string;
    rank: number;
    totalInvestment: number;
    personalCoin: number;
    createdAt: string;
    referrer?: { username: string } | null;
    _count: {
      other_users_users_referrerIdTousers: number;
      totalTeamMembers?: number; // 전체 하위 조직원 수 (재귀적 계산)
      investments: number;
    };
  };
  stats: {
    totalInvestment: number;
    activeInvestments: number;
    todayEarnings: number;
    monthlyEarnings: number;
    totalEarnings: number;
    expectedDailyEarnings: number;
    availableBalance: number;
  };
  recentActivities: {
    investments: Array<{
      id: string;
      amount: number;
      dailyRate: number;
      isActive: boolean;
      createdAt: string;
      endDate: string;
    }>;
    rewards: Array<{
      id: string;
      type: string;
      amount: number;
      description: string;
      createdAt: string;
    }>;
  };
  orgTree: OrgTreeNode | null;
}

// RANK_NAMES은 i18n으로 이동

export default function TeamClient({ data }: { data: TeamData }) {
  const router = useRouter();
  const { t, language } = useI18n();
  const [mounted, setMounted] = useState(false);
  const [zoom, setZoom] = useState(0.7);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPath, setCurrentPath] = useState('/team');
  const [viewMode, setViewMode] = useState<'tree' | 'list'>('tree');
  const treeContainerRef = useRef<HTMLDivElement | null>(null);
  const [treeTranslate, setTreeTranslate] = useState<{ x: number; y: number }>({
    x: 360,
    y: 100,
  });
  
  // 트리 루트 추적 (뒤로가기용)
  const [treeHistory, setTreeHistory] = useState<Array<{ username: string; orgTree: OrgTreeNode | null }>>([]);
  const [currentTreeRoot, setCurrentTreeRoot] = useState<{ username: string; orgTree: OrgTreeNode | null }>({
    username: data.users.username || '',
    orgTree: data.orgTree,
  });
  const [isLoadingTree, setIsLoadingTree] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // 데스크톱 조직도 컨테이너 크기에 맞춰 루트 노드를 항상 중앙에 배치
  useEffect(() => {
    if (!mounted) return;

    const updateTranslate = () => {
      if (treeContainerRef.current) {
        const width = treeContainerRef.current.clientWidth || 720;
        setTreeTranslate({
          x: width / 2,
          y: 100,
        });
      }
    };

    updateTranslate();
    window.addEventListener('resize', updateTranslate);
    return () => window.removeEventListener('resize', updateTranslate);
  }, [mounted]);

  const user = data.users;
  const stats = data.stats;
  const orgTree = data.orgTree;

  // 팀 통계 계산 (전체 하위 조직원 수)
  const totalTeamMembers = useMemo(() => user?._count?.totalTeamMembers || user?._count?.referredUsers || 0, [user?._count?.totalTeamMembers, user?._count?.referredUsers]);
  const totalInvestment = useMemo(() => stats?.totalInvestment || 0, [stats?.totalInvestment]);
  const totalReward = useMemo(() => stats?.totalEarnings || 0, [stats?.totalEarnings]);
  const personalCoin = useMemo(() => user?.personalCoin || 0, [user?.personalCoin]);

  // 라인별 회원 수 계산 (간단한 추정)
  const line1Members = useMemo(() => Math.floor(totalTeamMembers * 0.36), [totalTeamMembers]);
  const line2Members = useMemo(() => Math.floor(totalTeamMembers * 0.40), [totalTeamMembers]);
  const line3Members = useMemo(() => Math.floor(totalTeamMembers * 0.24), [totalTeamMembers]);

  // 조직도 데이터 변환 (현재 루트 기준)
  const orgTreeData = useMemo(() => {
    if (!currentTreeRoot.orgTree) return [];
    return [currentTreeRoot.orgTree];
  }, [currentTreeRoot]);

  // 모바일용 조직도 목록 데이터 추출
  const orgListData = useMemo(() => {
    const extractMembers = (node: OrgTreeNode | null, level = 0): Array<{ name: string; rank: string; investments: string; level: number }> => {
      if (!node) return [];
      const members = [{
        name: node.name,
        rank: node.attributes?.Rank || t.team.ranks.new,
        investments: node.attributes?.투자 || '$0',
        level
      }];
      if (node.children) {
        node.children.forEach(child => {
          members.push(...extractMembers(child, level + 1));
        });
      }
      return members;
    };
    return extractMembers(currentTreeRoot.orgTree);
  }, [currentTreeRoot.orgTree, t.team.ranks.new]);

  // 검색 필터링
  const filteredMembers = useMemo(() => {
    if (!searchQuery) return orgListData;
    return orgListData.filter(member =>
      member.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [orgListData, searchQuery]);

  // 랭크 이름 변환 함수
  const getRankName = useCallback((rankNumber: number) => {
    switch (rankNumber) {
      case 0: return t.team.ranks.new;
      case 1: return t.team.ranks.star1;
      case 2: return t.team.ranks.star2;
      case 3: return t.team.ranks.star3;
      case 4: return t.team.ranks.star4;
      case 5: return t.team.ranks.star5;
      default: return t.team.ranks.new;
    }
  }, [t.team.ranks]);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  // 특정 사용자의 조직도 트리 로드
  const loadUserTree = useCallback(async (username: string) => {
    if (isLoadingTree) return;
    
    setIsLoadingTree(true);
    try {
      const response = await fetch(`/api/team/tree?username=${encodeURIComponent(username)}`);
      const result = await response.json();
      
      if (result.ok && result.data) {
        // 현재 트리를 히스토리에 추가
        setTreeHistory(prev => [...prev, currentTreeRoot]);
        
        // 새로운 트리로 전환
        setCurrentTreeRoot({
          username: result.data.users.username || username,
          orgTree: result.data.orgTree,
        });
        
        // 검색 쿼리 초기화
        setSearchQuery('');
      } else {
        alert(result.error || '사용자를 찾을 수 없습니다.');
      }
    } catch (error) {
      console.error('트리 로드 실패:', error);
      alert('트리를 불러오는데 실패했습니다.');
    } finally {
      setIsLoadingTree(false);
    }
  }, [currentTreeRoot, isLoadingTree]);

  // 뒤로가기 (이전 루트로 돌아가기)
  const handleGoBack = useCallback(() => {
    if (treeHistory.length > 0) {
      const previousTree = treeHistory[treeHistory.length - 1];
      setTreeHistory(prev => prev.slice(0, -1));
      setCurrentTreeRoot(previousTree);
      setSearchQuery('');
    }
  }, [treeHistory]);

  // 검색 실행
  const handleSearch = useCallback(() => {
    if (searchQuery.trim()) {
      loadUserTree(searchQuery.trim());
    }
  }, [searchQuery, loadUserTree]);

  // Enter 키로 검색
  const handleSearchKeyPress = useCallback((e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  }, [handleSearch]);

  // 커스텀 노드 렌더링 함수 (카드형 디자인)
  const renderCustomNodeElement = useCallback(({ nodeDatum, toggleNode }: any) => {
    const rank = nodeDatum.attributes?.Rank || t.team.ranks.new;
    const investment = nodeDatum.attributes?.투자 || '$0';
    const investmentNum = parseFloat(investment.replace(/[^0-9.]/g, '')) || 0;
    const isHighRank = rank.includes('2') || rank.includes('3') || rank.includes('4') || rank.includes('5');

    // 카드 크기
    const cardWidth = 192; // w-48 = 192px
    const cardHeight = 180;

    // 노드 중심점 기준으로 카드 위치 계산 (중앙 정렬)
    const nodeX = typeof nodeDatum.x === 'number' ? nodeDatum.x : 0;
    const nodeY = typeof nodeDatum.y === 'number' ? nodeDatum.y : 0;
    const x = nodeX - cardWidth / 2;
    const y = nodeY - cardHeight / 2;

    // NaN 체크
    if (isNaN(x) || isNaN(y)) {
      return null;
    }

    return (
      <g>
        {/* HTML 카드 렌더링 */}
        <foreignObject
          x={x}
          y={y}
          width={cardWidth}
          height={cardHeight}
        >
          <div
            onClick={(e) => {
              e.stopPropagation();
              // 노드 클릭 시 해당 사용자 기준으로 트리 재로드
              if (nodeDatum.name) {
                loadUserTree(nodeDatum.name);
              }
            }}
            className={`flex flex-col items-center bg-gradient-to-br from-slate-700 to-slate-800 border-2 rounded-xl p-3 shadow-2xl w-full h-full cursor-pointer transition-all duration-200 hover:scale-105 ${isHighRank
              ? 'border-purple-400 hover:border-purple-300 shadow-purple-500/30'
              : 'border-slate-500 hover:border-slate-400'
              }`}
            style={{
              position: 'relative',
              overflow: 'visible',
              zIndex: 1000,
              pointerEvents: 'auto'
            }}
          >
            {/* 사람 아이콘 */}
            <div
              className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 ${isHighRank
                ? 'bg-gradient-to-br from-purple-500/40 to-pink-500/40 border-2 border-purple-400'
                : 'bg-slate-600 border-2 border-slate-500'
                }`}
            >
              <User className="text-white w-6 h-6" />
            </div>

            {/* 사용자명 */}
            <h3 className="text-white font-bold text-sm mb-1 truncate w-full text-center drop-shadow-lg">
              {nodeDatum.name || 'Unknown'}
            </h3>

            {/* 등급 뱃지 */}
            <span
              className={`text-xs font-semibold px-2.5 py-1 rounded-full mb-2 ${isHighRank
                ? 'text-purple-100 bg-purple-500/30 border border-purple-400/50'
                : 'text-slate-200 bg-slate-600/60 border border-slate-500/60'
                }`}
            >
              {rank}
            </span>

            {/* 투자금 정보 */}
            <div className="w-full text-center">
              <p className="text-xs text-slate-300 mb-0.5">{language === 'ko' ? '총 투자금' : 'Total Investment'}</p>
              <p className="text-sm font-semibold text-emerald-300 drop-shadow-lg">
                ${investmentNum.toLocaleString()}
              </p>
            </div>
          </div>
        </foreignObject>
      </g>
    );
  }, [language, loadUserTree]);

  // 줌 컨트롤
  const handleZoomIn = useCallback(() => {
    setZoom((prev) => Math.min(prev + 0.1, 1.0));
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoom((prev) => Math.max(prev - 0.1, 0.5));
  }, []);

  const handleReset = useCallback(() => {
    setZoom(0.7);
  }, []);

  if (!mounted) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-white">로딩 중...</div>
      </div>
    );
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-8 md:px-12 lg:px-20 xl:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col w-full max-w-[1280px] flex-1 overflow-visible">
            {/* Header */}
            <header className="flex flex-col border-b border-solid border-white/10 dark:border-white/10 px-6 py-3">
              {/* 첫 번째 줄: 회사 로고만 */}
              <div className="flex items-center justify-between w-full">
                <Link href="/dashboard" className="flex items-center gap-4 text-white hover:opacity-80 transition-opacity shrink-0">
                  <CompanyBrand
                    wrapperClassName="gap-4"
                    size={44}
                    textClassName="text-white text-lg font-bold leading-tight tracking-[-0.015em]"
                  />
                </Link>
              </div>
              
              {/* 두 번째 줄: 햄버거 버튼(왼쪽) + 데스크탑 네비게이션(중앙) + 오른쪽 버튼들 */}
              <div className="flex items-center justify-between w-full mt-2">
                {/* 왼쪽: 햄버거 버튼 (모바일에서만 표시) */}
                <div className="md:hidden">
                  <MobileNavigation
                    user={user}
                    currentPath={currentPath}
                  />
                </div>
                
                {/* 중앙: 데스크탑 네비게이션 */}
                <div className="hidden md:flex flex-1 justify-center gap-8 min-w-0">
                  <div className="flex items-center gap-9">
                    <Link
                      href="/dashboard"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.dashboard}
                    </Link>
                    <Link
                      href="/my-office"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.myOffice}
                    </Link>
                    <Link
                      href="/products"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.products}
                    </Link>
                    <Link
                      href="/games"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.games}
                    </Link>
                    <Link
                      href="/team"
                      className="text-[#137fec] text-sm font-medium leading-normal"
                    >
                      {t.common.team}
                    </Link>
                    <Link
                      href="/rewards"
                      className="text-gray-300 hover:text-white text-sm font-medium leading-normal"
                    >
                      {t.common.rewards}
                    </Link>
                  </div>
                </div>
                
                {/* 오른쪽: 언어 전환 + 버튼들 */}
                <div className="flex items-center gap-3 sm:gap-4">
                  <LanguageSwitcher />
                  <div className="flex gap-2">
                    <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white">
                      <span className="material-symbols-outlined">notifications</span>
                    </button>
                    <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white">
                      <span className="material-symbols-outlined">help</span>
                    </button>
                    <button
                      onClick={handleLogout}
                      className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors"
                      title="Logout"
                    >
                      <span className="material-symbols-outlined">logout</span>
                    </button>
                  </div>
                  <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] flex items-center justify-center text-white font-bold">
                    {user.username?.[0]?.toUpperCase() || 'U'}
                  </div>
                </div>
              </div>
            </header>

            <main className="flex-1 p-2 sm:p-4 md:p-6 overflow-visible relative z-0">
              {/* Page Title */}
              <div className="flex flex-wrap justify-between gap-4 items-center py-4 px-2">
                <div className="flex flex-col gap-2">
                  <p className="text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    {t.team.title}
                  </p>
                  <p className="text-gray-400 text-base font-normal leading-normal">
                    {t.team.subtitle}
                  </p>
                </div>
                {/* View Mode Toggle */}
                <div className="flex gap-2 bg-white/5 rounded-lg p-1 md:hidden">
                  <button
                    onClick={() => setViewMode('tree')}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors touch-manipulation ${viewMode === 'tree'
                        ? 'bg-[#137fec] text-white'
                        : 'text-gray-400 hover:text-white'
                      }`}
                  >
                    <span className="material-symbols-outlined text-base mr-1">account_tree</span>
                    {t.team.treeView}
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors touch-manipulation ${viewMode === 'list'
                        ? 'bg-[#137fec] text-white'
                        : 'text-gray-400 hover:text-white'
                      }`}
                  >
                    <span className="material-symbols-outlined text-base mr-1">list</span>
                    {t.team.listView}
                  </button>
                </div>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
                <div className="flex flex-col gap-2 rounded-xl p-6 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-base font-medium leading-normal">
                    {t.team.totalTeamMembers}
                  </p>
                  <p className="text-white tracking-light text-2xl font-bold leading-tight">
                    {totalTeamMembers.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US')}
                  </p>
                  <p className="text-green-500 text-base font-medium leading-normal">
                    +{totalTeamMembers > 0 ? '5.2' : '0'}%
                  </p>
                </div>
                <div className="flex flex-col gap-2 rounded-xl p-6 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-base font-medium leading-normal">
                    {t.team.membersByLine}
                  </p>
                  <p className="text-white tracking-light text-2xl font-bold leading-tight">
                    L1: {line1Members} / L2: {line2Members} / L3: {line3Members}
                  </p>
                  <p className="text-green-500 text-base font-medium leading-normal">
                    +{totalTeamMembers > 0 ? '3.1' : '0'}%
                  </p>
                </div>
                <div className="flex flex-col gap-2 rounded-xl p-6 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-base font-medium leading-normal">
                    {t.team.totalRewards}
                  </p>
                  <p className="text-white tracking-light text-2xl font-bold leading-tight">
                    {totalReward.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US', {
                      maximumFractionDigits: 0,
                    })}
                  </p>
                  <p className="text-green-500 text-base font-medium leading-normal">
                    +{totalReward > 0 ? '8.0' : '0'}%
                  </p>
                </div>
                <div className="flex flex-col gap-2 rounded-xl p-6 bg-white/5 border border-white/10">
                  <p className="text-gray-300 text-base font-medium leading-normal">
                    {t.team.myCoinHoldings}
                  </p>
                  <p className="text-white tracking-light text-2xl font-bold leading-tight">
                    {personalCoin.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US', {
                      maximumFractionDigits: 0,
                    })}
                  </p>
                  <p className="text-green-500 text-base font-medium leading-normal">
                    +{personalCoin > 0 ? '1.5' : '0'}%
                  </p>
                </div>
              </div>

              {/* Org Chart Section */}
              <div className="flex flex-col gap-4">
                <div className="flex flex-wrap gap-4 justify-between items-center p-4 bg-[#192633]/50 backdrop-blur-sm rounded-xl border border-white/10">
                  {/* SearchBar */}
                  <div className="flex-grow min-w-[280px]">
                    <label className="flex flex-col h-12 w-full">
                      <div className="flex w-full flex-1 items-stretch rounded-lg h-full">
                        <div className="text-gray-400 flex bg-white/5 items-center justify-center pl-4 rounded-l-lg">
                          <span className="material-symbols-outlined">search</span>
                        </div>
                        <input
                          className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-white focus:outline-0 focus:ring-0 border-none bg-white/5 h-full placeholder:text-gray-400 px-4 rounded-l-none pl-2 text-base font-normal leading-normal"
                          placeholder={t.team.searchPlaceholder}
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          onKeyPress={handleSearchKeyPress}
                        />
                        <button
                          onClick={handleSearch}
                          disabled={isLoadingTree || !searchQuery.trim()}
                          className="px-4 py-2 bg-[#137fec] text-white rounded-r-lg hover:bg-[#0f6bc7] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                          {isLoadingTree ? '...' : '검색'}
                        </button>
                      </div>
                    </label>
                  </div>
                  {/* ToolBar */}
                  <div className="flex gap-2">
                    {treeHistory.length > 0 && (
                      <button
                        onClick={handleGoBack}
                        className="p-3 text-gray-300 rounded-lg hover:bg-white/10 touch-manipulation active:scale-95 transition-transform"
                        title="뒤로가기"
                      >
                        <span className="material-symbols-outlined text-xl">arrow_back</span>
                      </button>
                    )}
                    <button
                      onClick={handleZoomIn}
                      className="p-3 text-gray-300 rounded-lg hover:bg-white/10 touch-manipulation active:scale-95 transition-transform"
                      title={t.team.zoomIn}
                    >
                      <span className="material-symbols-outlined text-xl">zoom_in</span>
                    </button>
                    <button
                      onClick={handleZoomOut}
                      className="p-3 text-gray-300 rounded-lg hover:bg-white/10 touch-manipulation active:scale-95 transition-transform"
                      title={t.team.zoomOut}
                    >
                      <span className="material-symbols-outlined text-xl">zoom_out</span>
                    </button>
                    <button
                      onClick={handleReset}
                      className="p-3 text-gray-300 rounded-lg hover:bg-white/10 touch-manipulation active:scale-95 transition-transform"
                      title={t.team.reset}
                    >
                      <span className="material-symbols-outlined text-xl">refresh</span>
                    </button>
                  </div>
                </div>
                {/* Desktop: Tree View (컨테이너 안에서만 스크롤 가능) */}
                <div className="hidden md:block h-[600px] bg-[#192633] rounded-xl border border-white/10 p-4 overflow-auto">
                  {orgTreeData.length > 0 ? (
                    <div ref={treeContainerRef} className="w-full h-full min-h-[600px]">
                      <Tree
                        data={orgTreeData}
                        orientation="vertical"
                        translate={treeTranslate}
                        zoom={zoom}
                        zoomable
                        draggable
                        enableLegacyTransitions
                        pathFunc="step"
                        renderCustomNodeElement={renderCustomNodeElement}
                        nodeSize={{ x: 170, y: 210 }}
                        separation={{ siblings: 1.25, nonSiblings: 1.25 }}
                        scaleExtent={{ min: 0.5, max: 1.6 }}
                        initialDepth={5}
                      />
                    </div>
                  ) : (
                    <div className="flex h-full items-center justify-center text-gray-400">
                      <p>{t.team.organizationChart}</p>
                    </div>
                  )}
                </div>

                {/* Mobile: Tree or List View */}
                <div className="md:hidden">
                  {viewMode === 'tree' ? (
                    <div className="h-[520px] bg-[#192633] rounded-xl border border-white/10 p-4 overflow-hidden">
                      {orgTreeData.length > 0 ? (
                        <div className="w-full h-full min-h-[520px]">
                          <Tree
                            data={orgTreeData}
                            orientation="vertical"
                            translate={{ x: 180, y: 70 }}
                            zoom={0.55}
                            zoomable
                            draggable
                            enableLegacyTransitions
                            pathFunc="step"
                            renderCustomNodeElement={renderCustomNodeElement}
                            nodeSize={{ x: 140, y: 220 }}
                            separation={{ siblings: 1.6, nonSiblings: 1.6 }}
                            scaleExtent={{ min: 0.4, max: 1.4 }}
                            initialDepth={5}
                          />
                        </div>
                      ) : (
                        <div className="flex h-full items-center justify-center text-gray-400">
                          <p>{t.team.noOrgChart}</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="bg-[#192633] rounded-xl border border-white/10 p-4">
                      <div className="max-h-[500px] overflow-y-auto">
                        {filteredMembers.length > 0 ? (
                          <div className="space-y-2">
                            {filteredMembers.map((member, index) => (
                              <div
                                key={index}
                                className="bg-white/5 border border-white/10 rounded-lg p-4 hover:bg-white/10 transition-colors"
                                style={{ marginLeft: `${member.level * 20}px` }}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-3">
                                    <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] flex items-center justify-center text-white font-bold text-sm">
                                      {member.name?.[0]?.toUpperCase() || 'U'}
                                    </div>
                                    <div>
                                      <p className="text-white font-semibold text-sm">{member.name}</p>
                                      <p className="text-gray-400 text-xs">Level {member.level + 1}</p>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <span className={`text-xs font-semibold px-2 py-1 rounded-full ${member.rank.includes('2') || member.rank.includes('3') || member.rank.includes('4') || member.rank.includes('5')
                                        ? 'text-purple-200 bg-purple-500/20 border border-purple-400/30'
                                        : 'text-slate-300 bg-slate-700/50 border border-slate-600/50'
                                      }`}>
                                      {member.rank}
                                    </span>
                                    <p className="text-emerald-400 text-xs font-semibold mt-1">
                                      ${parseFloat(member.investments.replace(/[^0-9.]/g, '')).toLocaleString()}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="flex flex-col items-center justify-center py-8 text-gray-400">
                            <span className="material-symbols-outlined text-4xl mb-3">search_off</span>
                            <p className="text-center">
                              {searchQuery
                                ? (language === 'ko' ? `'${searchQuery}'에 대한 검색 결과가 없습니다.` : `No results found for '${searchQuery}'.`)
                                : t.team.noOrgChart
                              }
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    </div>
  );
}

