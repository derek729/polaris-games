import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { cookies } from 'next/headers';
import TeamClient from './TeamClient';
import { isAdminUser } from '@/lib/admin-auth';

export default async function TeamPage() {
  // 인증 확인
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login');
  }

  // 관리자는 관리자 페이지로 리다이렉트
  if (isAdminUser(user)) {
    redirect('/a0-admin');
  }

  try {
    // 쿠키에서 userId 가져오기
    const cookieStore = await cookies();
    const userId = cookieStore.get('userId')?.value;

    if (!userId) {
      redirect('/login');
    }

    // API에서 대시보드 데이터 가져오기 (조직도 포함)
    const baseUrl = process.env.NODE_ENV === 'production'
      ? process.env.NEXT_PUBLIC_BASE_URL || 'https://your-domain.com'
      : 'http://localhost:3009';

    const response = await fetch(`${baseUrl}/api/dashboard`, {
      cache: 'no-store',
      headers: {
        'Content-Type': 'application/json',
        'Cookie': `userId=${userId}`,
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        // redirect는 try-catch 밖에서 호출해야 함
        // 여기서는 에러를 throw하고 catch 블록에서 처리
        throw new Error('UNAUTHORIZED');
      }
      throw new Error('팀 데이터를 불러올 수 없습니다.');
    }

    const dashboardData = await response.json();
    
    if (!dashboardData.ok) {
      throw new Error(dashboardData.error || '팀 데이터를 불러올 수 없습니다.');
    }

    return <TeamClient data={dashboardData.data} />;
  } catch (error: any) {
    // NEXT_REDIRECT 에러는 다시 throw (Next.js가 처리)
    if (error?.digest === 'NEXT_REDIRECT') {
      throw error;
    }
    
    // 인증 오류인 경우 리다이렉트
    if (error?.message === 'UNAUTHORIZED') {
      redirect('/login');
    }
    
    console.error('Team error:', error);
    redirect('/login');
  }
}

