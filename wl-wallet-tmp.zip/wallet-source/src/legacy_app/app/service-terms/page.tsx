'use client';

import { useI18n } from '@/lib/i18n/context';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { CompanyBrand } from '@/components/CompanyBrand';
import LanguageSwitcher from '@/components/LanguageSwitcher';

export default function ServiceTermsPage() {
  const { t, language } = useI18n();
  const router = useRouter();

  const handlePrint = () => {
    window.print();
  };

  const handleClose = () => {
    router.back();
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-[#101922]">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-10 md:px-20 lg:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col max-w-[960px] flex-1 bg-[#111a22] rounded-xl shadow-lg">
            {/* TopNavBar */}
            <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-[#233648] px-6 sm:px-10 py-3 sticky top-0 bg-[#111a22]/80 backdrop-blur-sm z-10">
              <CompanyBrand
                wrapperClassName="flex items-center gap-3 text-slate-800 dark:text-white"
                size={40}
                textClassName="text-slate-800 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em]"
              />
              <div className="flex items-center gap-3">
                <LanguageSwitcher />
                <button
                  onClick={handlePrint}
                  className="flex cursor-pointer items-center justify-center rounded-lg h-10 w-10 bg-slate-200/80 dark:bg-[#233648] text-slate-600 dark:text-white hover:bg-slate-300/80 dark:hover:bg-[#2f455c] transition-colors"
                  title={language === 'ko' ? '인쇄' : 'Print'}
                >
                  <span className="material-symbols-outlined text-xl">print</span>
                </button>
                <button
                  onClick={handleClose}
                  className="flex cursor-pointer items-center justify-center rounded-lg h-10 w-10 bg-slate-200/80 dark:bg-[#233648] text-slate-600 dark:text-white hover:bg-slate-300/80 dark:hover:bg-[#2f455c] transition-colors"
                  title={language === 'ko' ? '닫기' : 'Close'}
                >
                  <span className="material-symbols-outlined text-xl">close</span>
                </button>
              </div>
            </header>

            <main className="flex-1 p-4 sm:p-6 md:p-10">
              {/* PageHeading */}
              <div className="flex flex-wrap justify-between gap-4 pb-8">
                <div className="flex min-w-72 flex-col gap-3">
                  <p className="text-slate-900 dark:text-white text-3xl md:text-4xl font-black leading-tight tracking-[-0.033em]">
                    {language === 'ko'
                      ? 'MSUO Foundation MSUO 월렛 서비스 이용약관'
                      : 'MSUO Foundation MSUO Wallet Service Terms of Use'}
                  </p>
                  <p className="text-slate-500 dark:text-[#92adc9] text-base font-normal leading-normal">
                    {language === 'ko' ? '시행일: 2025년 11월 20일' : 'Effective Date: November 20, 2025'}
                  </p>
                </div>
              </div>

              {/* BodyText */}
              <div className="space-y-6 text-slate-700 dark:text-white text-base font-normal leading-relaxed">
                <p>
                  <strong>
                    {language === 'ko' ? '제 1조 (목적)' : 'Article 1 (Purpose)'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '이 약관은 UOC GROUP이 운영하는 MSUO코인 유니레벨 3줄 MSUO 월렛 서비스의 이용과 관련하여 회사와 회원 간의 권리, 의무 및 책임사항, 기타 필요한 사항을 규정함을 목적으로 합니다.'
                    : 'This agreement aims to stipulate the rights, obligations, and responsibilities between the company and members, as well as other necessary matters, regarding the use of the MSUO Coin Unilevel 3-line MSUO Wallet service operated by UOC GROUP.'}
                </p>

                <p>
                  <strong>
                    {language === 'ko' ? '제 2조 (정의)' : 'Article 2 (Definitions)'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '1. \'서비스\'라 함은 회사가 제공하는 AO코인 관련 모든 서비스를 의미합니다. 2. \'회원\'이라 함은 본 약관에 따라 회사와 이용계약을 체결하고 회사가 제공하는 서비스를 이용하는 고객을 말합니다. 3. \'지갑\'이라 함은 회원의 AO코인을 보관하고 관리하기 위한 디지털 자산 지갑을 의미합니다.'
                    : '1. "Service" means all MSUO Coin-related services provided by the company. 2. "Member" refers to a customer who enters into a service agreement with the company in accordance with this agreement and uses the services provided by the company. 3. "Wallet" means a digital asset wallet for storing and managing members\' MSUO Coins.'}
                </p>

                <p>
                  <strong>
                    {language === 'ko' ? '제 3조 (약관의 명시와 개정)' : 'Article 3 (Display and Amendment of Terms)'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '1. 회사는 이 약관의 내용을 회원이 쉽게 알 수 있도록 서비스 초기 화면에 게시합니다. 2. 회사는 \'약관의 규제에 관한 법률\', \'정보통신망 이용촉진 및 정보보호 등에 관한 법률(이하 \'정보통신망법\')\' 등 관련 법을 위배하지 않는 범위에서 이 약관을 개정할 수 있습니다. 3. 회사가 약관을 개정할 경우에는 적용일자 및 개정사유를 명시하여 현행약관과 함께 제1항의 방식에 따라 그 개정약관의 적용일자 7일 전부터 적용일자 전일까지 공지합니다.'
                    : '1. The company posts the contents of this agreement on the initial service screen so that members can easily know them. 2. The company may amend this agreement within the scope that does not violate related laws such as the "Act on Regulation of Terms and Conditions" and the "Act on Promotion of Information and Communications Network Utilization and Information Protection" (hereinafter "Information and Communications Network Act"). 3. When the company amends the terms, it specifies the application date and reason for amendment and notifies from 7 days before the application date to the day before the application date in accordance with the method of paragraph 1 along with the current terms.'}
                </p>
              </div>

              {/* Card */}
              <div className="py-8">
                <div className="flex flex-col items-stretch justify-start rounded-lg bg-[#137fec]/10 dark:bg-[#137fec]/20 p-4 xl:flex-row xl:items-start border border-[#137fec]/20 dark:border-[#137fec]/30">
                  <div className="flex w-full min-w-72 grow flex-col items-stretch justify-center gap-2 xl:px-4">
                    <p className="text-[#137fec] dark:text-blue-300 text-lg font-bold leading-tight tracking-[-0.015em]">
                      {language === 'ko' ? '주요 안내사항: 수수료 및 책임' : 'Important Notice: Fees and Responsibilities'}
                    </p>
                    <div className="flex items-end gap-3 justify-between">
                      <p className="text-slate-600 dark:text-[#c4d6eb] text-base font-normal leading-relaxed">
                        {language === 'ko'
                          ? '서비스 이용 중 발생하는 모든 거래 수수료, 데이터 사용료, 책임의 한계 및 서비스 해지 조항은 사용자의 권익에 중대한 영향을 미칠 수 있으니 반드시 주의 깊게 확인하시기 바랍니다. 회사는 본 조항에 대해 사전 고지 없이 변경할 수 없으며, 변경 시에는 최소 30일 전에 공지합니다.'
                          : 'All transaction fees, data usage fees, limitations of liability, and service termination clauses that occur during service use may have a significant impact on user rights and interests, so please check carefully. The company cannot change these terms without prior notice, and will notify at least 30 days in advance if changes are made.'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* More BodyText */}
              <div className="space-y-6 text-slate-700 dark:text-white text-base font-normal leading-relaxed">
                <p>
                  <strong>
                    {language === 'ko' ? '제 4조 (서비스의 제공 및 변경)' : 'Article 4 (Provision and Modification of Service)'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '1. 회사는 다음과 같은 업무를 수행합니다. 가. MSUO코인 지갑 생성 및 관리 서비스 나. MSUO코인 전송 및 수신 서비스 다. 기타 회사가 정하는 업무. 2. 회사는 기술적 사양의 변경 등의 경우에는 장차 체결되는 계약에 의해 제공할 서비스의 내용을 변경할 수 있습니다.'
                    : '1. The company performs the following tasks: a. MSUO Coin wallet creation and management services b. MSUO Coin transfer and reception services c. Other tasks determined by the company. 2. The company may change the contents of services to be provided by contracts to be concluded in the future in cases such as changes in technical specifications.'}
                </p>

                <p>
                  <strong>
                    {language === 'ko' ? '제 5조 (서비스의 중단)' : 'Article 5 (Suspension of Service)'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '1. 회사는 컴퓨터 등 정보통신설비의 보수점검, 교체 및 고장, 통신의 두절 등의 사유가 발생한 경우에는 서비스의 제공을 일시적으로 중단할 수 있습니다. 2. 사업종목의 전환, 사업의 포기, 업체 간의 통합 등의 이유로 서비스를 제공할 수 없게 되는 경우에는 회사는 회원에게 통지하고 당초 회사에서 제시한 조건에 따라 소비자에게 보상합니다.'
                    : '1. The company may temporarily suspend the provision of services if there are reasons such as maintenance, replacement, and failure of information and communication equipment such as computers, or interruption of communication. 2. If the service cannot be provided due to reasons such as conversion of business items, abandonment of business, or integration between companies, the company notifies members and compensates consumers according to the conditions initially presented by the company.'}
                </p>

                <p>
                  <strong>
                    {language === 'ko' ? '제 6조 (회원의 의무)' : 'Article 6 (Member Obligations)'}
                  </strong>{' '}
                  {language === 'ko'
                    ? '1. 회원은 다음 행위를 하여서는 안 됩니다. 가. 신청 또는 변경 시 허위 내용의 등록 나. 타인의 정보 도용 다. 회사가 게시한 정보의 변경. 2. 회원은 관계법, 이 약관의 규정, 이용안내 및 서비스와 관련하여 공지한 주의사항, 회사가 통지하는 사항 등을 준수하여야 하며, 기타 회사의 업무에 방해되는 행위를 하여서는 아니 됩니다.'
                    : '1. Members must not engage in the following acts: a. Registration of false information when applying or changing b. Misappropriation of others\' information c. Modification of information posted by the company. 2. Members must comply with related laws, the provisions of this agreement, notices related to use guidelines and services, matters notified by the company, etc., and must not engage in any other acts that interfere with the company\'s business.'}
                </p>

                <p className="pt-4 text-center text-slate-500 dark:text-gray-400">
                  {language === 'ko' ? '-- 이용약관의 끝 --' : '-- End of Terms of Use --'}
                </p>
              </div>
            </main>
            <footer className="py-6 text-center text-sm text-slate-500 dark:text-gray-400">
              © 2026 MSUO Foundation. All rights reserved.
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}

