'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { CompanyBrand } from '@/components/CompanyBrand';

function RegisterForm() {
  const { t, language } = useI18n();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    referrerCode: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // URL 파라미터에서 추천인 코드 가져오기
  useEffect(() => {
    const ref = searchParams.get('ref');
    if (ref) {
      setFormData(prev => ({ ...prev, referrerCode: ref.toUpperCase() }));
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // 입력값 검증
    if (!formData.username.trim()) {
      setError(t.errors.required);
      return;
    }

    if (!formData.email.trim()) {
      setError(t.errors.required);
      return;
    }

    // 이메일 형식 검증
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email.trim())) {
      setError(t.errors.invalidEmail);
      return;
    }

    // 추천인 코드 필수 검증
    if (!formData.referrerCode.trim()) {
      setError(language === 'ko' 
        ? '추천인 코드는 필수입니다.' 
        : language === 'en'
        ? 'Referrer code is required.'
        : language === 'zh'
        ? '推荐代码是必需的。'
        : language === 'ja'
        ? '紹介コードは必須です。'
        : 'Mã giới thiệu là bắt buộc.');
      return;
    }

    // 비밀번호 확인
    if (formData.password !== formData.confirmPassword) {
      setError(t.errors.passwordMismatch);
      return;
    }

    if (formData.password.length < 6) {
      setError(t.errors.invalidPassword);
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          username: formData.username.trim(),
          email: formData.email.trim(),
          password: formData.password,
          referrerCode: formData.referrerCode.trim() || undefined,
        }),
      });

      const data = await res.json();

      if (data.ok) {
        router.push('/dashboard');
        router.refresh();
      } else {
        setError(data.error || t.auth.registerFailed);
      }
    } catch (err) {
      console.error('회원가입 오류:', err);
      setError(t.errors.networkError);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col items-center justify-center p-4 bg-[#F5F7FA] dark:bg-[#101922]">
      {/* 상단 헤더: 회사 로고와 번역 탭을 한 줄로 배치 */}
      <div className="fixed top-4 left-4 right-4 z-20 flex items-center justify-between">
        <CompanyBrand
          wrapperClassName="drop-shadow-lg"
          size={48}
          textClassName="text-base sm:text-lg text-slate-800 dark:text-white drop-shadow-lg"
          imageClassName="drop-shadow-lg"
        />
        <LanguageSwitcher />
      </div>

      <div className="w-full max-w-md">
        <header className="mb-8 text-center pt-16">

          {/* Page Title */}
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-white mb-3 break-words">
            {language === 'ko' ? '새 계정 만들기' : 'Create New Account'}
          </h1>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 break-words">
            {language === 'ko' 
              ? '계정에 로그인하거나 새로 만들어 시작하세요.' 
              : 'Log in to your account or create a new one to get started.'}
          </p>
        </header>

        <main className="w-full space-y-6">
          {error && (
            <div className="p-3 bg-red-900/50 border border-red-500 rounded-lg text-red-200 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300"
                htmlFor="username"
              >
                {t.auth.usernameOrEmail.split(' 또는 ')[0]}
              </label>
              <input
                className="h-12 w-full rounded-lg border-slate-300 bg-white p-3 text-slate-900 placeholder:text-slate-400 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] dark:border-slate-600 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500"
                id="username"
                type="text"
                placeholder={language === 'ko' ? '사용자명을 입력하세요' : 'Enter username'}
                value={formData.username}
                onChange={(e) =>
                  setFormData({ ...formData, username: e.target.value })
                }
                required
              />
            </div>

            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300"
                htmlFor="email"
              >
                {language === 'ko' ? '이메일' : 'Email'}
              </label>
              <input
                className="h-12 w-full rounded-lg border-slate-300 bg-white p-3 text-slate-900 placeholder:text-slate-400 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] dark:border-slate-600 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500"
                id="email"
                type="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
                required
              />
            </div>

            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300"
                htmlFor="password"
              >
                {t.auth.password}
              </label>
              <div className="relative">
                <input
                  className="h-12 w-full rounded-lg border-slate-300 bg-white p-3 pr-10 text-slate-900 placeholder:text-slate-400 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] dark:border-slate-600 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500"
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder={language === 'ko' ? '•••••••• (최소 6자)' : '•••••••• (min 6 chars)'}
                  value={formData.password}
                  onChange={(e) =>
                    setFormData({ ...formData, password: e.target.value })
                  }
                  required
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 dark:text-slate-500">
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="material-symbols-outlined cursor-pointer text-xl"
                  >
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300"
                htmlFor="confirmPassword"
              >
                {t.auth.confirmPassword}
              </label>
              <div className="relative">
                <input
                  className="h-12 w-full rounded-lg border-slate-300 bg-white p-3 pr-10 text-slate-900 placeholder:text-slate-400 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] dark:border-slate-600 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500"
                  id="confirmPassword"
                  type={showConfirmPassword ? 'text' : 'password'}
                  placeholder={language === 'ko' ? '비밀번호를 다시 입력하세요' : 'Re-enter password'}
                  value={formData.confirmPassword}
                  onChange={(e) =>
                    setFormData({ ...formData, confirmPassword: e.target.value })
                  }
                  required
                />
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 dark:text-slate-500">
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="material-symbols-outlined cursor-pointer text-xl"
                  >
                    {showConfirmPassword ? 'visibility_off' : 'visibility'}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex flex-col">
              <label
                className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300"
                htmlFor="referrerCode"
              >
                {t.auth.referrerCode} <span className="text-red-500">*</span>
              </label>
              <input
                className="h-12 w-full rounded-lg border-slate-300 bg-white p-3 text-slate-900 placeholder:text-slate-400 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] dark:border-slate-600 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500"
                id="referrerCode"
                type="text"
                placeholder={language === 'ko' ? '추천인 코드 또는 사용자명' : 'Referrer code or username'}
                value={formData.referrerCode}
                onChange={(e) =>
                  setFormData({ ...formData, referrerCode: e.target.value.toUpperCase() })
                }
                required
              />
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                {language === 'ko' 
                  ? '※ 후원인은 추천인을 기준으로 자동 배정됩니다.' 
                  : '※ Sponsor will be automatically assigned based on referrer.'}
              </p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex h-12 w-full items-center justify-center rounded-lg bg-[#3A4DFF] px-4 text-base font-semibold text-white transition-colors hover:bg-[#3A4DFF]/90 focus:outline-none focus:ring-2 focus:ring-[#3A4DFF] focus:ring-offset-2 dark:focus:ring-offset-[#101922] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? t.auth.registering : t.auth.registerButton}
            </button>
          </form>

          <p className="text-center text-sm text-slate-600 dark:text-slate-400">
            {t.auth.alreadyHaveAccount}{' '}
            <Link
              className="font-medium text-[#3A4DFF] hover:underline"
              href="/login"
            >
              {t.auth.loginButton}
            </Link>
          </p>
        </main>

        <footer className="mt-12 text-center">
          <p className="text-xs text-slate-500 dark:text-slate-500">
            <Link className="hover:underline text-[#3A4DFF]" href="/service-terms">
              {language === 'ko' ? '서비스 약관' : 'Terms of Service'}
            </Link>{' '}
            ·{' '}
            <Link className="hover:underline text-[#3A4DFF]" href="/privacy-policy">
              {language === 'ko' ? '개인정보처리방침' : 'Privacy Policy'}
            </Link>
          </p>
        </footer>
      </div>
    </div>
  );
}

export default function RegisterPage() {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center min-h-screen bg-[#F5F7FA] dark:bg-[#101922]">
        <div className="text-white">로딩 중...</div>
      </div>
    }>
      <RegisterForm />
    </Suspense>
  );
}

