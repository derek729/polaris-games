'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { CompanyBrand } from '@/components/CompanyBrand';
import { checkAdminRole } from '@/lib/admin-auth';

interface UserData {
  id: string;
  personalCoin: number;
  username: string;
}

interface InvestmentTier {
  id: number;
  tier?: number;
  name: string;
  amount: number;
  dailyRate: number;
  annualRate?: number;
  period: number;
  category: string;
  recommended?: boolean;
  matchingDepth?: number;
  description?: string;
}

export default function InvestPage() {
  const router = useRouter();
  const { t, language } = useI18n();
  const [user, setUser] = useState<UserData | null>(null);
  const categories = useMemo(() => {
    return [
      t.categories.all,
      t.categories.shortTermHighYield,
      t.categories.longTermStable,
      t.categories.recommended
    ];
  }, [t.categories]);

  const [selectedCategory, setSelectedCategory] = useState(categories[0]);

  // language가 변경되면 selectedCategory도 업데이트
  useEffect(() => {
    setSelectedCategory(categories[0]);
  }, [categories]);
  const [selectedTier, setSelectedTier] = useState<InvestmentTier | null>(null);
  const [loading, setLoading] = useState(true);
  const [investing, setInvesting] = useState(false);
  const [error, setError] = useState('');
  const [investmentTiers, setInvestmentTiers] = useState<InvestmentTier[]>([]);
  const [usdtAddress, setUsdtAddress] = useState('');
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [txHash, setTxHash] = useState('');

  useEffect(() => {
    fetch('/api/admin/system-settings')
      .then(res => res.json())
      .then(data => {
        if (data.ok && data.data.usdtAddress) {
          setUsdtAddress(data.data.usdtAddress);
        }
      })
      .catch(err => console.error('시스템 설정 조회 실패:', err));
  }, []);

  const fetchUserData = useCallback(async () => {
    try {
      // 관리자 체크
      const isAdmin = await checkAdminRole();
      if (isAdmin) {
        router.push('/a0-admin');
        return;
      }

      const res = await fetch('/api/user/me', {
        credentials: 'include',
      });
      const data = await res.json();
      if (data.ok && data.users) {
        setUser(data.users);
      } else {
        router.push('/login');
      }
    } catch (err) {
      console.error('사용자 정보 조회 실패:', err);
      router.push('/login');
    } finally {
      setLoading(false);
    }
  }, [router]);

  const fetchInvestmentProducts = useCallback(async () => {
    try {
      const url = `/api/investment/products?lang=${language}&t=${Date.now()}`;
      console.log('[Invest Page] Fetching products with language:', language, 'URL:', url);
      const res = await fetch(url, {
        credentials: 'include',
        cache: 'no-store', // 캐시 방지
      });
      const data = await res.json();
      if (data.ok && data.data) {
        console.log('[Invest Page] Products received (language:', language, '):', data.data.map((p: any) => ({
          name: p.name,
          category: p.category,
          description: p.description?.substring(0, 40) + '...'
        })));
        setInvestmentTiers(data.data);
      } else {
        console.error('[Invest Page] API response error:', data);
      }
    } catch (err) {
      console.error('투자 상품 조회 실패:', err);
    }
  }, [language]);

  useEffect(() => {
    fetchUserData();
  }, [fetchUserData]);

  useEffect(() => {
    fetchInvestmentProducts();
  }, [fetchInvestmentProducts, language]);

  // 투자 상품은 API에서 가져옴

  const filteredTiers = useMemo(() => {
    if (!investmentTiers || investmentTiers.length === 0) return [];

    // 언어별 카테고리 매핑
    const categoryMap = {
      ko: {
        shortTerm: '단기',
        stable: '안정형',
        highYield: '고수익',
      },
      en: {
        shortTerm: 'Short-term',
        stable: 'Stable',
        highYield: 'High Yield',
      },
    };

    const currentCategories = categoryMap[language as 'ko' | 'en'];

    return investmentTiers.filter((tier) => {
      if (selectedCategory === t.categories.all) return true;
      if (selectedCategory === t.categories.shortTermHighYield)
        return tier.category === currentCategories.shortTerm || tier.category === currentCategories.highYield;
      if (selectedCategory === t.categories.longTermStable)
        return tier.category === currentCategories.stable;
      if (selectedCategory === t.categories.recommended) return tier.recommended;
      return true;
    });
  }, [selectedCategory, investmentTiers, t.categories, language]);

  const handleInvestClick = (tier: InvestmentTier) => {
    if (!user || !user.id) {
      router.push('/login');
      return;
    }
    setSelectedTier(tier);
    setShowDepositModal(true);
    setError('');
    setTxHash('');
  };

  const handleDepositSubmit = async () => {
    if (!selectedTier || !user) return;
    if (!txHash) {
      setError('TXID를 입력해주세요.');
      return;
    }

    setInvesting(true);
    setError('');

    try {
      const res = await fetch('/api/user/invest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          userId: user.id,
          amount: selectedTier.amount,
          txHash: txHash
        }),
      });

      const data = await res.json();

      if (data.ok) {
        await fetchUserData();
        alert('투자 신청이 완료되었습니다. 관리자 승인 후 활성화됩니다.');
        setShowDepositModal(false);
        router.push('/dashboard');
        router.refresh();
      } else {
        setError(data.error || t.invest.investmentFailed);
      }
    } catch (err) {
      console.error('투자 실패:', err);
      setError(t.errors.networkError);
    } finally {
      setInvesting(false);
    }
  };

  const getMatchingDepth = useCallback((amount: number): number => {
    if (amount >= 10000) return 12;
    if (amount >= 5000) return 11;
    if (amount >= 1000) return 10;
    if (amount >= 500) return 8;
    if (amount >= 200) return 6;
    if (amount >= 50) return 4;
    return 0;
  }, []);

  const getTierNumber = useCallback((amount: number): number => {
    if (amount >= 10000) return 6;
    if (amount >= 5000) return 5;
    if (amount >= 1000) return 4;
    if (amount >= 500) return 3;
    if (amount >= 200) return 2;
    return 1;
  }, []);

  const getAnnualRate = useCallback((dailyRate: number): number => {
    return dailyRate * 365 * 100;
  }, []);

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      router.push('/login');
      router.refresh();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#101922] flex items-center justify-center">
        <div className="text-white">{t.common.loading}</div>
      </div>
    );
  }

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-[#101922] overflow-x-hidden">
      <div className="layout-container flex h-full grow flex-col">
        <div className="px-4 sm:px-10 md:px-20 lg:px-40 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col max-w-[960px] flex-1">
            {/* Header */}
            <header className="flex items-center justify-between border-b border-solid border-white/10 px-4 sm:px-10 py-3">
              <Link href="/dashboard" className="flex items-center gap-4 text-white hover:opacity-80 transition-opacity shrink-0">
                <CompanyBrand
                  wrapperClassName="gap-4"
                  size={44}
                  textClassName="text-white text-lg font-bold leading-tight tracking-[-0.015em]"
                />
              </Link>

              <div className="hidden md:flex flex-1 justify-center gap-8 min-w-0">
                <div className="flex items-center gap-9">
                  <Link
                    href="/dashboard"
                    className="text-white text-sm font-medium leading-normal hover:text-[#137fec]"
                  >
                    {t.common.dashboard}
                  </Link>
                  <Link
                    href="/my-office"
                    className="text-white text-sm font-medium leading-normal hover:text-[#137fec]"
                  >
                    {t.common.myOffice}
                  </Link>
                  <Link
                    href="/transactions"
                    className="text-white text-sm font-medium leading-normal hover:text-[#137fec]"
                  >
                    {t.common.transactions}
                  </Link>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <LanguageSwitcher />
                <button className="hidden md:flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#233648] text-white text-sm font-bold leading-normal tracking-[0.015em]">
                  <span className="truncate">
                    {language === 'ko' ? '보유' : 'Balance'} {user?.personalCoin.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US') || 0} MSUO
                  </span>
                </button>
                <button
                  onClick={handleLogout}
                  className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white transition-colors"
                  title="Logout"
                >
                  <span className="material-symbols-outlined">logout</span>
                </button>
                <div className="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 bg-gradient-to-br from-[#137fec] to-[#3A4DFF] flex items-center justify-center text-white font-bold">
                  {user?.username?.[0]?.toUpperCase() || 'U'}
                </div>
              </div>
            </header>

            <main className="flex-1">
              {/* Page Heading */}
              <div className="flex flex-wrap justify-between gap-3 p-4 mt-8 mb-4">
                <div className="flex min-w-72 flex-col gap-3">
                  <p className="text-white text-4xl font-black leading-tight tracking-[-0.033em]">
                    {t.invest.title}
                  </p>
                  <p className="text-[#92adc9] text-base font-normal leading-normal">
                    {t.invest.description}
                  </p>
                </div>
              </div>

              {error && (
                <div className="mx-4 mb-4 p-3 bg-red-900/50 border border-red-500 rounded-lg text-red-200 text-sm">
                  {error}
                </div>
              )}

              {/* Category Chips */}
              <div className="flex gap-3 p-3 overflow-x-auto">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-lg pl-4 pr-4 cursor-pointer transition-colors ${selectedCategory === category
                      ? 'bg-[#137fec] text-white'
                      : 'bg-[#233648] hover:bg-[#137fec]/50 text-white'
                      }`}
                  >
                    <p className="text-sm font-medium leading-normal">{category}</p>
                  </button>
                ))}
              </div>

              {/* Investment Cards */}
              <div className="grid grid-cols-[repeat(auto-fit,minmax(280px,1fr))] gap-6 px-4 py-6">
                {loading && investmentTiers.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <div className="text-white">{t.common.loading}</div>
                  </div>
                ) : filteredTiers.length === 0 ? (
                  <div className="col-span-full text-center py-12">
                    <p className="text-gray-400 dark:text-gray-500">
                      {language === 'ko' ? '투자 상품이 없습니다.' : 'No investment products available.'}
                    </p>
                  </div>
                ) : (
                  filteredTiers.map((tier) => (
                    <div
                      key={tier.id}
                      className={`flex flex-1 flex-col gap-4 rounded-xl border border-solid p-6 transition-colors duration-300 relative ${tier.recommended
                        ? 'border-[#137fec] bg-[#192633] ring-2 ring-[#137fec]/50'
                        : 'border-[#324d67] bg-[#192633] hover:border-[#137fec]'
                        }`}
                    >
                      {tier.recommended && (
                        <div className="absolute top-0 right-0 bg-[#137fec] text-white text-xs font-bold px-8 py-1 -rotate-45 translate-x-1/4 translate-y-2.5">
                          {language === 'ko' ? '추천' : 'Recommended'}
                        </div>
                      )}
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center justify-between">
                          <h1 className="text-white text-lg font-bold leading-tight">
                            {tier.name}
                          </h1>
                          <p className="text-white text-xs font-medium leading-normal tracking-[0.015em] rounded-full bg-[#137fec]/30 px-3 py-[3px] text-center">
                            #{tier.category}
                          </p>
                        </div>
                        {tier.description && (
                          <p className="text-gray-400 text-sm leading-normal">
                            {tier.description}
                          </p>
                        )}
                        <p className="flex items-baseline gap-1 text-white mt-2">
                          <span className="text-white text-4xl font-black leading-tight tracking-[-0.033em]">
                            ${tier.amount.toLocaleString(language === 'ko' ? 'ko-KR' : 'en-US')}
                          </span>
                        </p>
                      </div>
                      <div className="flex flex-col gap-3 my-4">
                        <div className="text-[13px] font-normal leading-normal flex gap-3 text-white items-center">
                          <span className="material-symbols-outlined text-[#137fec] text-base">
                            check_circle
                          </span>
                          <span>
                            {language === 'ko' ? '일일 수익률:' : 'Daily Rate:'} {(tier.dailyRate * 100).toFixed(4)}%
                          </span>
                        </div>
                        <div className="text-[13px] font-normal leading-normal flex gap-3 text-white items-center">
                          <span className="material-symbols-outlined text-[#137fec] text-base">
                            check_circle
                          </span>
                          <span>
                            {t.invest.expectedReturn} {tier.annualRate || getAnnualRate(tier.dailyRate).toFixed(1)}%
                          </span>
                        </div>
                        <div className="text-[13px] font-normal leading-normal flex gap-3 text-white items-center">
                          <span className="material-symbols-outlined text-[#137fec] text-base">
                            check_circle
                          </span>
                          <span>
                            {language === 'ko' ? '매칭 깊이:' : 'Matching Depth:'} {tier.matchingDepth || 0} {language === 'ko' ? '세대' : 'generations'}
                          </span>
                        </div>
                        <div className="text-[13px] font-normal leading-normal flex gap-3 text-white items-center">
                          <span className="material-symbols-outlined text-[#137fec] text-base">
                            check_circle
                          </span>
                          <span>
                            {t.invest.investmentPeriod} {Math.floor(tier.period / 30)} {t.common.months}
                          </span>
                        </div>
                        {tier.recommended && (
                          <div className="text-[13px] font-normal leading-normal flex gap-3 text-white items-center">
                            <span className="material-symbols-outlined text-[#137fec] text-base">
                              check_circle
                            </span>
                            <span>{t.invest.additionalBonus}</span>
                          </div>
                        )}
                      </div>
                      <button
                        onClick={() => handleInvestClick(tier)}
                        disabled={investing}
                        className="flex mt-auto min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#137fec] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-opacity-80 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <span className="truncate">
                          {investing && selectedTier?.id === tier.id
                            ? t.invest.investing
                            : t.invest.invest}
                        </span>
                      </button>
                    </div>
                  ))
                )}
              </div>
            </main>

            {/* Footer */}
            <footer className="flex flex-col gap-6 px-5 py-10 text-center mt-12 border-t border-solid border-white/10 dark:border-t-[#233648]">
              <div className="flex flex-wrap items-center justify-center gap-6">
                <Link
                  href="/about"
                  className="text-[#92adc9] text-sm font-normal leading-normal min-w-40 hover:text-[#137fec]"
                >
                  {language === 'ko' ? '회사 정보' : 'About Us'}
                </Link>
                <Link
                  href="/service-terms"
                  className="text-[#92adc9] text-sm font-normal leading-normal min-w-40 hover:text-[#137fec]"
                >
                  {language === 'ko' ? '이용약관' : 'Terms of Service'}
                </Link>
                <Link
                  href="/support"
                  className="text-[#92adc9] text-sm font-normal leading-normal min-w-40 hover:text-[#137fec]"
                >
                  {language === 'ko' ? '고객센터' : 'Support'}
                </Link>
              </div>
              <p className="text-[#92adc9] text-xs font-normal leading-normal">
                © 2026 MSUO Foundation. All rights reserved.
              </p>
            </footer>
          </div>
        </div>
      </div>
      {/* Deposit Modal */}
      {showDepositModal && selectedTier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="bg-[#1e293b] rounded-xl max-w-md w-full p-6 border border-white/10 shadow-2xl">
            <h3 className="text-xl font-bold text-white mb-4">USDT 입금 안내</h3>
            <p className="text-gray-300 text-sm mb-4 leading-relaxed">
              아래 주소로 <strong className="text-[#137fec] text-lg">${selectedTier.amount.toLocaleString()} USDT</strong>를 입금해주세요.<br />
              입금 후 TXID(거래 해시)를 입력하고 신청 버튼을 눌러주세요.
            </p>

            <div className="bg-black/30 p-4 rounded-lg mb-6 break-all border border-white/5">
              <p className="text-xs text-gray-500 mb-2 font-medium">입금 주소 (TRC20)</p>
              <div className="flex items-center justify-between gap-2">
                <p className="text-[#137fec] font-mono text-sm font-bold">{usdtAddress || '주소가 설정되지 않았습니다.'}</p>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(usdtAddress);
                    alert('주소가 복사되었습니다.');
                  }}
                  className="text-gray-400 hover:text-white"
                >
                  <span className="material-symbols-outlined text-sm">content_copy</span>
                </button>
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm text-gray-400 mb-2 font-medium">TXID (Transaction Hash)</label>
              <input
                type="text"
                value={txHash}
                onChange={(e) => setTxHash(e.target.value)}
                className="w-full bg-[#0f172a] border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#137fec] outline-none transition-colors placeholder-gray-600"
                placeholder="거래 해시를 입력하세요"
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowDepositModal(false)}
                className="flex-1 py-3 rounded-lg bg-gray-700 text-white font-bold hover:bg-gray-600 transition-colors"
              >
                취소
              </button>
              <button
                onClick={handleDepositSubmit}
                disabled={investing || !txHash}
                className="flex-1 py-3 rounded-lg bg-[#137fec] text-white font-bold hover:bg-[#0f6bc7] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {investing ? '처리 중...' : '입금 완료 신청'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

