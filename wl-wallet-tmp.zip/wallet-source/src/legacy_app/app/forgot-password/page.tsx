'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useI18n } from '@/lib/i18n/context';
import LanguageSwitcher from '@/components/LanguageSwitcher';
import { CompanyBrand } from '@/components/CompanyBrand';

export default function ForgotPasswordPage() {
  const { t, language } = useI18n();
  const router = useRouter();
  const [formData, setFormData] = useState({
    email: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    setLoading(true);

    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: formData.email.trim(),
        }),
      });

      const data = await res.json();

      if (data.ok) {
        setSuccess(true);
      } else {
        setError(data.error || (language === 'ko' ? '비밀번호 재설정 요청에 실패했습니다.' : 'Failed to request password reset.'));
      }
    } catch (err) {
      console.error('비밀번호 찾기 오류:', err);
      setError(language === 'ko' ? '네트워크 오류가 발생했습니다.' : 'Network error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col items-center justify-center p-4 bg-[#F5F7FA] dark:bg-[#101922]">
      {/* 상단 헤더: 회사 로고와 번역 탭을 한 줄로 배치 */}
      <div className="fixed top-4 left-4 right-4 z-20 flex items-center justify-between">
        <CompanyBrand
          wrapperClassName="drop-shadow-lg"
          size={48}
          textClassName="text-base sm:text-lg text-slate-800 dark:text-white drop-shadow-lg"
          imageClassName="drop-shadow-lg"
        />
        <LanguageSwitcher />
      </div>

      <div className="w-full max-w-md">
        <header className="mb-8 text-center pt-16">

          {/* Page Title */}
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-slate-900 dark:text-white mb-3">
            {language === 'ko' ? '비밀번호 찾기' : 'Forgot Password'}
          </h1>
          <p className="text-base text-slate-600 dark:text-slate-400 whitespace-nowrap overflow-hidden text-ellipsis">
            {language === 'ko' 
              ? '등록된 이메일 주소를 입력하시면 비밀번호 재설정 링크를 보내드립니다.' 
              : 'Enter your registered email address and we will send you a password reset link.'}
          </p>
        </header>

        <main className="w-full space-y-6">
          {error && (
            <div className="p-3 bg-red-900/50 border border-red-500 rounded-lg text-red-200 text-sm">
              {error}
            </div>
          )}

          {success ? (
            <div className="p-4 bg-green-900/50 border border-green-500 rounded-lg text-green-200 text-sm space-y-4">
              <p>
                {language === 'ko' 
                  ? '비밀번호 재설정 링크가 이메일로 전송되었습니다. 이메일을 확인해주세요.' 
                  : 'Password reset link has been sent to your email. Please check your email.'}
              </p>
              <Link
                href="/login"
                className="block text-center text-sm font-medium text-green-300 hover:underline"
              >
                {language === 'ko' ? '로그인 페이지로 돌아가기' : 'Back to Login'}
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex flex-col">
                <label
                  className="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300"
                  htmlFor="email"
                >
                  {language === 'ko' ? '이메일 주소' : 'Email Address'}
                </label>
                <input
                  className="h-12 w-full rounded-lg border-slate-300 bg-white p-3 text-slate-900 placeholder:text-slate-400 focus:border-[#3A4DFF] focus:ring-[#3A4DFF] dark:border-slate-600 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500"
                  id="email"
                  type="email"
                  placeholder={language === 'ko' ? 'you@example.com' : 'you@example.com'}
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  required
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="flex h-12 w-full items-center justify-center rounded-lg bg-[#3A4DFF] px-4 text-base font-semibold text-white transition-colors hover:bg-[#3A4DFF]/90 focus:outline-none focus:ring-2 focus:ring-[#3A4DFF] focus:ring-offset-2 dark:focus:ring-offset-[#101922] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading 
                  ? (language === 'ko' ? '전송 중...' : 'Sending...') 
                  : (language === 'ko' ? '비밀번호 재설정 링크 전송' : 'Send Reset Link')}
              </button>
            </form>
          )}

          <div className="text-center">
            <Link
              href="/login"
              className="text-sm font-medium text-[#3A4DFF] hover:underline"
            >
              {language === 'ko' ? '← 로그인 페이지로 돌아가기' : '← Back to Login'}
            </Link>
          </div>
        </main>
      </div>
    </div>
  );
}

