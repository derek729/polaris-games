/** @type {import('next').NextConfig} */
const nextConfig = {
  // Railway 배포를 위해 standalone output 설정
  output: 'standalone',

  // Turbopack workspace root 설정
  turbopack: {
    resolveAlias: {
      // workspace root 경로 명시
    },
  },

  // Railway 배포를 위해 안정적인 설정만 유지
  experimental: {
    optimizePackageImports: ['lucide-react', 'recharts'],
  },

  // Turbopack 설정 제거 (프로덕션 빌드에서 문제 발생 가능)
  // turbopack: {},

  // 빌드 최적화
  productionBrowserSourceMaps: false,

  // 이미지 최적화
  images: {
    domains: [],
    formats: ['image/webp', 'image/avif'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    minimumCacheTTL: 60 * 60 * 24 * 7, // 7일
  },

  compress: true,
  poweredByHeader: false,
  reactStrictMode: true,

  // Static generation 및 캐싱 최적화
  generateEtags: true,

  // SWC 최적화
  // swcMinify: true, // Deprecated in Next.js 15+ (enabled by default)

  // 성능 최적화
  compiler: {
    // console.error는 유지 (스케줄러 로그 확인용)
    removeConsole: process.env.NODE_ENV === 'production'
      ? { exclude: ['error', 'warn'] }
      : false,
  },

  // 헤더 최적화
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-DNS-Prefetch-Control',
            value: 'on'
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block'
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY'
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff'
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin'
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()'
          }
        ]
      },
      // 게임 파일들은 iframe으로 로드 가능하도록 설정
      {
        source: '/games/:path*',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'SAMEORIGIN'
          },
          {
            key: 'Content-Security-Policy',
            value: "frame-ancestors 'self'"
          }
        ]
      },
      {
        source: '/sw.js',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=0, must-revalidate'
          }
        ]
      },
      {
        source: '/manifest.json',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable'
          }
        ]
      }
    ];
  },

  // 리다이렉트 설정
  async redirects() {
    return [
      // 기본 리다이렉트만 유지
      {
        source: '/home',
        destination: '/',
        permanent: true
      },
      // 관리자 경로 리다이렉트 (/admin, /a0-admin -> /u0-admin)
      {
        source: '/admin',
        destination: '/u0-admin',
        permanent: true
      },
      {
        source: '/admin/:path*',
        destination: '/u0-admin/:path*',
        permanent: true
      },
      {
        source: '/a0-admin',
        destination: '/u0-admin',
        permanent: true
      },
      {
        source: '/a0-admin/:path*',
        destination: '/u0-admin/:path*',
        permanent: true
      }
    ];
  },


  // 게임 파일들이 Next.js의 처리를 받지 않도록 설정
  pageExtensions: ['ts', 'tsx', 'js', 'jsx', 'mdx'],

  // Static file handling for games
  excludeDefaultMomentLocales: true,

  // Ensure public folder files are served statically
  trailingSlash: false,
};

module.exports = nextConfig;