# UOC GROUP Marketing Wallet

AO 그룹 글로벌 리워드 마케팅 시스템

## � 배포

### Railway 배포 (권장)
1. [Railway](https://railway.app) 계정 생성
2. 새 프로젝트 생성 → "Deploy from GitHub repo"
3. `https://github.com/derek729/muoc` 리포지토리 연결
4. 환경 변수 설정:
   ```
   DATABASE_URL=postgresql://... (Railway에서 제공)
   NEXT_PUBLIC_APP_URL=https://your-app.railway.app
   NODE_ENV=production
   ```
5. 배포 완료

### Vercel 배포
1. [Vercel](https://vercel.com) 계정 생성
2. "Import Project" → GitHub 연결
3. `derek729/muoc` 리포지토리 선택
4. 환경 변수 설정 (위와 동일)
5. 배포

### 필수 환경 변수
```
DATABASE_URL=postgresql://username:password@host:port/database
NEXT_PUBLIC_APP_URL=https://your-deployment-url
NODE_ENV=production
```

## 🚀 시작하기

### 필수 요구사항

- Node.js 18 이상
- PostgreSQL 데이터베이스
- npm, yarn, pnpm 또는 bun

### 환경 변수 설정

프로젝트 루트에 `.env` 파일을 생성하고 다음 변수들을 설정하세요:

```env
# 데이터베이스 연결
DATABASE_URL="postgresql://user:password@localhost:5432/dbname?schema=public"

# Next.js 설정
NEXT_PUBLIC_BASE_URL="http://localhost:3009"
NODE_ENV="development"

# 스케줄러 타임존
CRON_TIMEZONE="Asia/Seoul"
```

### 설치 및 실행

1. 의존성 설치:
```bash
npm install
# or
yarn install
# or
pnpm install
```

2. 데이터베이스 마이그레이션:
```bash
npx prisma migrate dev
# or
npx prisma db push
```

3. (선택) 시드 데이터 생성:
```bash
npm run prisma:seed
```

4. 개발 서버 실행:
```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

서버가 시작되면 [http://localhost:3009](http://localhost:3009)에서 애플리케이션을 확인할 수 있습니다.

## 📁 프로젝트 구조

```
aowa/
├── prisma/
│   └── schema.prisma          # 데이터베이스 스키마
├── src/
│   ├── app/
│   │   ├── api/               # API 라우트
│   │   │   ├── auth/          # 인증 API
│   │   │   ├── user/          # 사용자 API
│   │   │   └── admin/         # 관리자 API
│   │   ├── dashboard/         # 대시보드 페이지
│   │   ├── admin/             # 관리자 페이지
│   │   ├── login/             # 로그인 페이지
│   │   └── register/          # 회원가입 페이지
│   ├── services/              # 비즈니스 로직
│   │   ├── dailyReward.ts     # 일일 리워드
│   │   ├── matchingBonus.ts   # 매칭 보너스
│   │   ├── leadershipBonus.ts # 리더십 보너스
│   │   ├── referralBonus.ts   # 추천인 보너스
│   │   └── scheduler.ts       # 스케줄러
│   └── lib/                   # 유틸리티
│       ├── prisma.ts          # Prisma 클라이언트
│       ├── auth.ts            # 인증 유틸리티
│       ├── logger.ts          # 로깅 시스템
│       ├── retry.ts           # 재시도 로직
│       └── api-response.ts    # API 응답 유틸리티
├── instrumentation.ts         # 서버 초기화 (스케줄러 자동 시작)
└── next.config.js             # Next.js 설정
```

## 🔑 주요 기능

### 사용자 기능
- 회원가입 및 로그인
- 투자 상품 선택 및 투자
- 대시보드 (자산 현황, 조직도, 리워드 내역)
- 코인 이체 (P2P)
- 출금 신청

### 관리자 기능
- 사용자 관리
- 출금 승인/거절
- 리워드 설정 관리
- 투자 등급 설정
- 시스템 모니터링
- 리포트 생성

### 리워드 시스템
- **일일 리워드**: 투자 금액에 따른 일일 수익
- **추천인 보너스**: 직접 추천 시 10% 보너스
- **매칭 보너스**: 세대별 매칭 보너스 (1대: 12%, 2~4대: 8%, 5~8대: 5%, 9~12대: 3%)
- **리더십 보너스**: Roll-up 방식의 리더십 보너스
- **랭크 보상**: A/B/C 라인 매출 기반 랭크 보상

## 🔧 스크립트

```bash
# 개발 서버 실행
npm run dev

# 프로덕션 빌드
npm run build

# 프로덕션 서버 실행
npm run start

# 린트 검사
npm run lint

# 슈퍼 관리자 생성
npm run create-super-admin
```

## 📊 데이터베이스

### Prisma 사용

```bash
# 마이그레이션 생성
npx prisma migrate dev --name migration_name

# 데이터베이스 스키마 동기화
npx prisma db push

# Prisma Studio 실행 (데이터베이스 GUI)
npx prisma studio

# 시드 데이터 생성
npm run prisma:seed
```

## 🔐 인증 및 보안

- 쿠키 기반 세션 관리
- bcryptjs를 사용한 비밀번호 해싱
- 관리자 권한 체크 (ADMIN, SUPER_ADMIN)
- 보안 헤더 설정 (XSS Protection, Frame Options 등)

## 📝 API 문서

### 인증 API

- `POST /api/auth/login` - 로그인
- `POST /api/auth/register` - 회원가입
- `POST /api/auth/logout` - 로그아웃
- `GET /api/auth/session` - 세션 확인
- `GET /api/auth/me` - 현재 사용자 정보

### 사용자 API

- `GET /api/dashboard` - 대시보드 데이터
- `GET /api/user/me` - 사용자 프로필
- `POST /api/user/invest` - 투자 신청
- `GET /api/user/invest` - 투자 내역 조회
- `POST /api/user/transfer` - 코인 이체
- `GET /api/user/transfer` - 이체 내역 조회
- `POST /api/user/withdraw` - 출금 신청
- `GET /api/user/withdraw` - 출금 내역 조회

### 관리자 API

- `GET /api/admin/dashboard` - 관리자 대시보드
- `GET /api/admin/users` - 사용자 목록
- `GET /api/admin/users/[userId]` - 사용자 상세
- `POST /api/admin/users/create` - 사용자 생성 (SUPER_ADMIN)
- `GET /api/admin/withdraw/list` - 출금 신청 목록
- `POST /api/admin/withdraw/approve` - 출금 승인
- `GET /api/admin/reward-settings` - 보상 설정 조회
- `PUT /api/admin/reward-settings` - 보상 설정 수정
- `GET /api/admin/investment/tiers` - 투자 등급 조회
- `PUT /api/admin/investment/tiers` - 투자 등급 수정
- `POST /api/admin/start-scheduler` - 스케줄러 수동 시작
- `POST /api/admin/run-daily` - 일일 리워드 수동 실행
- `POST /api/admin/run-leadership` - 리더십 보너스 수동 실행

## 🎨 기술 스택

- **프레임워크**: Next.js 16.0.3
- **언어**: TypeScript
- **데이터베이스**: PostgreSQL
- **ORM**: Prisma 5.22.0
- **UI**: React 19.2.0, Tailwind CSS
- **스케줄러**: node-cron
- **차트**: recharts
- **조직도**: react-d3-tree

## 📚 추가 문서

### 사용자 문서
- **[빠른 시작 가이드](./QUICK_START_GUIDE.md)** - 5분 만에 UPC 시작하기
- **[사용자 설명서](./USER_MANUAL.md)** - 전체 기능 상세 가이드
- **[FAQ](./FAQ.md)** - 자주 묻는 질문과 답변

### 관리자 문서
- **[관리자 설명서](./ADMIN_MANUAL.md)** - 시스템 관리 및 운영 가이드

### 기술 문서
- **[프로젝트 용어 사전](./PROJECT_TERMS.md)** - 용어 정리 및 설명
- **[기능 설명서](./FEATURE_GUIDE.md)** - 시스템 기능 상세 설명
- **[시스템 점검 보고서](./SYSTEM_AUDIT_REPORT.md) - 전체 시스템 점검 결과

### 개발자 문서
- [Prisma 문서](https://www.prisma.io/docs) - 데이터베이스 ORM
- [Next.js 문서](https://nextjs.org/docs) - 프레임워크 가이드

## 🐛 문제 해결

### 데이터베이스 연결 오류
- `.env` 파일의 `DATABASE_URL` 확인
- PostgreSQL 서버가 실행 중인지 확인

### 스케줄러가 작동하지 않음
- `next.config.js`에 `instrumentationHook: true` 설정 확인
- 서버 재시작

### 빌드 오류
- `node_modules` 삭제 후 재설치: `rm -rf node_modules && npm install`
- Prisma 클라이언트 재생성: `npx prisma generate`

## 📄 라이선스

이 프로젝트는 비공개 프로젝트입니다.

## 👥 기여

프로젝트 개선을 위한 제안이나 버그 리포트는 이슈로 등록해주세요.
