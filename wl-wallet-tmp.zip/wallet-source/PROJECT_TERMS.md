# UPC Coin Foundation - 프로젝트 용어 설명서

## 📖 개요

UPC Coin Foundation는 블록체인 기반의 디지털 자산 관리 및 투자 플랫폼입니다. 본 문서는 프로젝트의 핵심 용어들을 정리하여 사용자와 개발자가 시스템을 쉽게 이해할 수 있도록 합니다.

## 🏷️ 기본 용어

### UPC (UPC Coin)
- **정의**: UPC Coin Foundation의 기본 암호화폐
- **용도**:
  - 투자 상품의 기본 통화
  - 게임 내 베팅 및 보상
  - P2P 전송
  - 거래소 거래
  - 모든 리워드 지급의 기본 통화
- **특징**: 모든 서비스의 핵심 통화로 사용되는 유일한 기반 코인


## 👥 회원 관리 용어

### 사용자 등급 (User Roles)
- **USER**: 일반 사용자 (기본 등급)
- **ADMIN**: 관리자 (사용자 관리 권한)
- **SUPER_ADMIN**: 최고 관리자 (시스템 전체 권한)

### 사용자 상태 (User Status)
- **ACTIVE**: 활성 사용자 (정상 이용 가능)
- **INACTIVE**: 비활성 사용자 (휴면 계정)
- **SUSPENDED**: 정지 사용자 (이용 제한)


## 💰 투자 용어

### 투자 상품
- **Investment Tier**: 투자 등급 (최소/최대 투자 금액에 따른 등급)
- **Rate**: 수익률 (투자 금액에 대한 비율)


## 🎰 게임 관련 용어

### 게임 종류
- **Blackjack**: 블랙잭 카드 게임
- **Baccarat**: 바카라 카드 게임
- **Lotto**: 로또 복권 게임
- **Spin**: 슬롯머신 게임
- **Pack**: 팩 게임
- **Loullet**: 룰렛 게임
- **Ocell**: 오셀로 게임
- **Neon Slot**: 네온 슬롯머신

### 게임 공유 (Game Shares)
- **Game Share**: 게임 지분 보유
- **Share Percentage**: 지분 비율
- **Game Revenue Distribution**: 게임 수익 분배
- **Payment Period**: 지급 주기 (일일/주간/월간)

## 💸 금융 서비스 용어

### 채굴/스테이킹 (Mining/Staking)
- **Mining Record**: 채굴 기록
- **Staking Record**: 스테이킹 기록
- **APY (Annual Percentage Yield)**: 연간 수익률
- **Lock Period**: 잠금 기간

### 거래소 (Exchange)
- **Order**: 주문 (매수/매도)
- **Trade**: 체결된 거래
- **Order Type**: 주문 종류 (LIMIT/MARKET)
- **Buy Order**: 매수 주문
- **Sell Order**: 매도 주문

### 자산 이동
- **Transfer**: P2P 코인 전송
- **Withdrawal Request**: 출금 신청
- **Off-chain**: 온체인 미사용 내부 거래
- **On-chain**: 블록체인 기반 거래
- **TxHash**: 트랜잭션 해시

## 🔧 시스템 용어

### 데이터베이스
- **Prisma**: 데이터베이스 ORM
- **Schema**: 데이터베이스 구조 정의
- **Migration**: 데이터베이스 구조 변경

### API 관리
- **Route**: API 엔드포인트
- **Middleware**: 요청 처리 중간 단계
- **Authentication**: 인증 처리
- **Authorization**: 권한 확인

### 보안
- **Session**: 사용자 세션
- **Token**: 인증 토큰
- **Hash**: 암호화된 해시 값
- **Encryption**: 데이터 암호화

## 📊 리포트 및 모니터링

### 시스템 모니터링
- **Metrics**: 시스템 측정 지표
- **Audit Log**: 감사 기록
- **Monitoring**: 시스템 상태 감시
- **Health Check**: 시스템 상태 확인

### 스케줄링
- **Daily Reward**: 일일 리워드 지급 작업
- **Leadership Bonus**: 리더십 보너스 지급 작업
- **Rank Update**: 랭크 업데이트 작업
- **Cron Job**: 주기적으로 실행되는 작업

## 🌐 멀티언어 지원

### 지원 언어
- **Korean (ko)**: 한국어
- **English (en)**: 영어
- **Chinese (zh)**: 중국어
- **Japanese (ja)**: 일본어

### 국제화 (i18n)
- **Translation Key**: 번역 키
- **Language Detection**: 언어 자동 감지
- **Locale**: 지역 설정

## 🔗 네트워크 관련

### 메인넷 (Mainnet)
- **Mainnet Address**: 메인넷 지갑 주소
- **Block Number**: 블록 번호
- **Confirmations**: 거래 확인 수
- **Gas Fee**: 가스비

## 📱 모바일 앱

### Capacitor
- **PWA (Progressive Web App)**: 프로그레시브 웹 앱
- **Native Build**: 네이티브 앱 빌드
- **Android**: 안드로이드 앱
- **Push Notification**: 푸시 알림

---

**참고**: 본 용어집은 시스템 업데이트에 따라 지속적으로 업데이트됩니다. 최신 정보는 항상 공식 문서를 확인해 주세요.