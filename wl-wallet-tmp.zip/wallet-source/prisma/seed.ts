import { Prisma } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

// 기본 비밀번호 (모든 테스트 유저가 동일한 비밀번호 사용)
const DEFAULT_PASSWORD = 'password123';
const SUPER_ADMIN_PASSWORD = 'admin123'; // 슈퍼관리자 비밀번호

async function main() {
  console.log('🌱 리더십 보너스 검증을 위한 시드 데이터 생성을 시작합니다...');

  // 기본 비밀번호 해싱
  const hashedPassword = await bcrypt.hash(DEFAULT_PASSWORD, 10);
  const superAdminPassword = await bcrypt.hash(SUPER_ADMIN_PASSWORD, 10);

  // 1. 기존 데이터 삭제 (깨끗하게 시작)
  await prisma.rewardLog.deleteMany();
  await prisma.teamSales.deleteMany();
  await prisma.investment.deleteMany();
  await prisma.investmentTier.deleteMany();
  await prisma.user.deleteMany();

  // 2. 슈퍼관리자 계정 생성
  const superAdmin = await prisma.user.create({
    data: {
      username: 'admin',
      email: 'admin@upcwallet.com',
      password: superAdminPassword,
      role: UserRole.SUPER_ADMIN,
      rank: 5, // 최고 랭크
      personalCoin: new Prisma.Decimal(10000000), // 1천만 코인
      totalInvestment: new Prisma.Decimal(100000), // $100,000 투자
      status: 'ACTIVE',
      isActive: true,
      accumulatedSales: new Prisma.Decimal(0),
      line1Sales: new Prisma.Decimal(0),
      line2Sales: new Prisma.Decimal(0),
      line3Sales: new Prisma.Decimal(0),
      line4Sales: new Prisma.Decimal(0),
      line5Sales: new Prisma.Decimal(0),
    },
  });

  // 슈퍼관리자 투자 생성
  await prisma.investment.create({
    data: {
      userId: superAdmin.id,
      amount: new Prisma.Decimal(100000),
      dailyRate: new Prisma.Decimal(0.015), // 1.5%
      matchingDepth: 12,
      investmentTier: 6,
      startDate: new Date(),
      endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
    },
  });

  console.log('👑 슈퍼관리자 계정 생성 완료:');
  console.log('   사용자명: admin');
  console.log('   이메일: admin@upcwallet.com');
  console.log('   비밀번호: admin123');
  console.log('   권한: SUPER_ADMIN');
  console.log('');

  // 투자 상품 등록 (AO GROUP 글로벌 리워드 마케팅 구조 문서 기준)
  console.log('📦 투자 상품 등록 중...');
  await prisma.investmentTier.createMany({
    data: [
      {
        id: 1,
        tier: 1,
        minAmount: new Prisma.Decimal(50),
        maxAmount: new Prisma.Decimal(99),
        dailyRate: new Prisma.Decimal(0.003), // 0.3% 일일 수익율
        matchingDepth: 0, // 매칭 보너스 없음
        referralRates: [], // 매칭 보너스 없음
        description: '$50-$99: 초보 투자자 (매칭 보너스 없음)',
      },
      {
        id: 2,
        tier: 2,
        minAmount: new Prisma.Decimal(100),
        maxAmount: new Prisma.Decimal(999),
        dailyRate: new Prisma.Decimal(0.005), // 0.5% 일일 수익율
        matchingDepth: 4, // 1~4대 매칭 보너스
        referralRates: [0.12, 0.08, 0.08, 0.08], // 1대: 12%, 2~4대: 8%
        description: '$100-$999: 일반 투자자 (1~4대 매칭 보너스)',
      },
      {
        id: 3,
        tier: 3,
        minAmount: new Prisma.Decimal(1000),
        maxAmount: new Prisma.Decimal(9999),
        dailyRate: new Prisma.Decimal(0.010), // 1% 일일 수익율
        matchingDepth: 8, // 5~8대 매칭 보너스
        referralRates: [0.05, 0.05, 0.05, 0.05], // 5~8대: 5%
        description: '$1,000-$9,999: 고급 투자자 (5~8대 매칭 보너스)',
      },
      {
        id: 4,
        tier: 4,
        minAmount: new Prisma.Decimal(10000),
        maxAmount: new Prisma.Decimal(999999),
        dailyRate: new Prisma.Decimal(0.012), // 1.2% 일일 수익율
        matchingDepth: 12, // 9~12대 매칭 보너스
        referralRates: [0.03, 0.03, 0.03, 0.03], // 9~12대: 3%
        description: '$10,000+: 최고 등급 투자자 (9~12대 매칭 보너스)',
      },
    ],
  });
  console.log('✅ 4개의 투자 상품 등록 완료');
  console.log('');

  // 3. 리더십 보너스 테스트를 위한 3단계 계층 구조 생성
  console.log('📊 리더십 보너스 테스트 데이터 생성 중...');

  // 최상위 리더 (Grand Leader) - Rank 2 (리더십 요율 8% 가정)
  const grandMaster = await prisma.user.create({
    data: {
      username: 'GrandMaster',
      email: 'grandmaster@test.com',
      password: hashedPassword,
      referrerId: superAdmin.id, // 슈퍼관리자의 1대 파트너
      rank: 2, // 최상위 리더
      role: UserRole.USER,
      personalCoin: new Prisma.Decimal(1000000), // 100만 코인
      totalInvestment: new Prisma.Decimal(50000), // $50,000 투자
      status: 'ACTIVE',
      // 매출 집계 필드 초기화
      accumulatedSales: new Prisma.Decimal(0),
      line1Sales: new Prisma.Decimal(0),
      line2Sales: new Prisma.Decimal(0),
      line3Sales: new Prisma.Decimal(0),
      line4Sales: new Prisma.Decimal(0),
      line5Sales: new Prisma.Decimal(0),
    },
  });

  // GrandMaster의 투자 생성
  await prisma.investment.create({
    data: {
      userId: grandMaster.id,
      amount: new Prisma.Decimal(50000),
      dailyRate: new Prisma.Decimal(0.012), // 1.2%
      matchingDepth: 12,
      investmentTier: 6,
      startDate: new Date(),
      endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
    },
  });

  console.log('👑 GrandMaster (Rank 2) 생성 완료 - 리더십 요율: 8%');

  // 중간 리더 (Middle Leader) - Rank 1 (리더십 요율 4% 가정)
  const middleBoss = await prisma.user.create({
    data: {
      username: 'MiddleBoss',
      email: 'middleboss@test.com',
      password: hashedPassword,
      rank: 1, // 중간 리더
      personalCoin: new Prisma.Decimal(500000), // 50만 코인
      totalInvestment: new Prisma.Decimal(20000), // $20,000 투자
      referrerId: grandMaster.id, // GrandMaster의 1대 파트너
      status: 'ACTIVE',
      // 매출 집계 필드 초기화
      accumulatedSales: new Prisma.Decimal(0),
      line1Sales: new Prisma.Decimal(0),
      line2Sales: new Prisma.Decimal(0),
      line3Sales: new Prisma.Decimal(0),
      line4Sales: new Prisma.Decimal(0),
      line5Sales: new Prisma.Decimal(0),
    },
  });

  // MiddleBoss의 투자 생성
  await prisma.investment.create({
    data: {
      userId: middleBoss.id,
      amount: new Prisma.Decimal(20000),
      dailyRate: new Prisma.Decimal(0.010), // 1.0%
      matchingDepth: 8,
      investmentTier: 5,
      startDate: new Date(),
      endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
    },
  });

  console.log('🎯 MiddleBoss (Rank 1) 생성 완료 - GrandMaster의 1대 파트너, 리더십 요율: 4%');

  // 일반 투자자 (Investor) - Rank 1 (리더십 요율 0% - 일반 유저)
  const newbie = await prisma.user.create({
    data: {
      username: 'Newbie',
      email: 'newbie@test.com',
      password: hashedPassword,
      rank: 1, // 일반 유저 (Rank 1은 기본값)
      personalCoin: new Prisma.Decimal(100000), // 10만 코인
      totalInvestment: new Prisma.Decimal(10000), // $10,000 투자 (매출 발생원)
      referrerId: middleBoss.id, // MiddleBoss의 1대 파트너
      status: 'ACTIVE',
      // 매출 집계 필드 초기화
      accumulatedSales: new Prisma.Decimal(0),
      line1Sales: new Prisma.Decimal(0),
      line2Sales: new Prisma.Decimal(0),
      line3Sales: new Prisma.Decimal(0),
      line4Sales: new Prisma.Decimal(0),
      line5Sales: new Prisma.Decimal(0),
    },
  });

  // Newbie의 투자 생성 ($10,000 매출 발생)
  await prisma.investment.create({
    data: {
      userId: newbie.id,
      amount: new Prisma.Decimal(10000), // 핵심: $10,000 매출 발생원
      dailyRate: new Prisma.Decimal(0.008), // 0.8%
      matchingDepth: 4,
      investmentTier: 4,
      startDate: new Date(),
      endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
    },
  });

  console.log('💰 Newbie (Rank 1) 생성 완료 - MiddleBoss의 1대 파트너, 투자금: $10,000 (매출 발생원)');

  // 3. 팀 매출 집계 데이터 생성 (리더십 보너스 계산 기준)
  // Newbie의 매출이 상위 리더들에게 전파되도록 TeamSales 생성

  // Newbie 자신의 매출 (본인 투자 $10,000)
  await prisma.teamSales.create({
    data: {
      userId: newbie.id,
      generation: 0, // 자기 자신
      salesAmount: new Prisma.Decimal(10000),
      date: new Date(),
    },
  });

  // MiddleBoss의 1대 라인 매출 (Newbie의 $10,000)
  await prisma.teamSales.create({
    data: {
      userId: middleBoss.id,
      generation: 1, // 1대 파트너 매출
      salesAmount: new Prisma.Decimal(10000),
      date: new Date(),
    },
  });

  // GrandMaster의 2대 라인 매출 (Newbie의 $10,000)
  await prisma.teamSales.create({
    data: {
      userId: grandMaster.id,
      generation: 2, // 2대 파트너 매출
      salesAmount: new Prisma.Decimal(10000),
      date: new Date(),
    },
  });

  console.log('📈 팀 매출 집계 데이터 생성 완료');

  // 4. 검증 포인트 출력
  console.log('\n🧪 리더십 보너스 검증 포인트:');
  console.log('=====================================');
  console.log('📊 데이터 구조:');
  console.log('   GrandMaster (Rank 2) ────▶ MiddleBoss (Rank 1) ────▶ Newbie (Rank 1)');
  console.log('        (8% 리더십 요율)           (4% 리더십 요율)           (0% 리더십 요율)');
  console.log('');
  console.log('💰 데일리 리워드 발생 시 예상 보너스:');
  console.log(`   Newbie: $10,000 투자 × 0.8% = $80 일일 수익 (리더십 보너스 없음)`);
  console.log(`   MiddleBoss: Newbie 매출($10,000)의 4% = $400 리더십 보너스 예상`);
  console.log(`   GrandMaster: Newbie 매출($10,000)의 (8%-4%) = 4% = $400 리더십 보너스 예상`);
  console.log('');
  console.log('🎯 핵심 검증: "상위 리더가 하위 리더의 보너스 요율을 뺀 차액(Differential)을 잘 가져가는가?"');
  console.log('   ✅ GrandMaster는 MiddleBoss보다 높은 랭크(Rank 2)이므로, 차등 보너스(8%-4%=4%)를 수령해야 함');
  console.log('');
  console.log('✅ 리더십 보너스 테스트 데이터 생성 완료!');
  console.log('   이제 데일리 리워드 시스템을 실행하여 보너스 계산을 검증하세요.');
  console.log('');
  console.log('🔐 테스트 계정 정보:');
  console.log('   슈퍼관리자:');
  console.log('   - admin / admin@upcwallet.com (비밀번호: admin123)');
  console.log('');
  console.log('   일반 테스트 계정 (비밀번호: password123):');
  console.log('   - GrandMaster / grandmaster@test.com');
  console.log('   - MiddleBoss / middleboss@test.com');
  console.log('   - Newbie / newbie@test.com');
}

// 거대 투자자 생성 헬퍼 함수
async function createWhaleUser(name: string, referrerId: string, amount: number, hashedPassword: string) {
  const user = await prisma.user.create({
    data: {
      username: name,
      email: `${name.toLowerCase()}@test.com`,
      password: hashedPassword,
      referrerId: referrerId,
      rank: 1,
      personalCoin: new Prisma.Decimal(100000),
      totalInvestment: new Prisma.Decimal(amount),
      // 하위 매출 집계를 위해 초기값 설정 (RankSystem이 돌면 덮어씌워짐)
      accumulatedSales: new Prisma.Decimal(amount),
    },
  });

  await prisma.investment.create({
    data: {
      userId: user.id,
      amount: new Prisma.Decimal(amount),
      dailyRate: new Prisma.Decimal(0.012), // 1.2% 하루 이자만 72만원!
      matchingDepth: 12,
      investmentTier: 6,
      startDate: new Date(),
      endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
    },
  });

  console.log(`🐳 ${name} 생성 완료 (투자금: ${amount})`);
  return user;
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });


