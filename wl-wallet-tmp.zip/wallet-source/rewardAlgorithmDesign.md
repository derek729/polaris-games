# AO GROUP 핵심 수익 로직 상세 설계

## 1. 랭크 승급 심사 알고리즘 (Rank System)

### 1.1 기본 로직 정의

```
라인(Leg) = 직추천인(1대 파트너)를 시작점으로 하는 전체 하위 트리
A/B/C 라인 = 레그들을 매출 기준으로 정렬하여 분리
```

### 1.2 의사코드 - 랭크 승급 심사

```pseudocode
FUNCTION evaluateRankPromotion(userId):
    // STEP 0: 사용자 기본 정보 조회
    user = getUser(userId)
    currentRank = user.rank

    // STEP 1: 코인 보유량 기본 조건 체크
    IF user.personalCoin < 2000000:
        RETURN {
            eligible: false,
            currentRank: currentRank,
            reason: "코인 보유량 200만개 미만",
            requiredCoin: 2000000,
            currentCoin: user.personalCoin
        }

    // STEP 2: 직추천인(레그) 조회
    directReferrals = getDirectReferrals(userId)
    legCount = directReferrals.length

    // 엣지 케이스 1: 직추천인이 3명 미만인 경우
    IF legCount < 3:
        RETURN {
            eligible: false,
            currentRank: currentRank,
            reason: `직추천인 ${legCount}명 (최소 3명 필요)`,
            requiredLegs: 3,
            currentLegs: legCount
        }

    // STEP 3: 각 레그별 산하 전체 매출 계산
    legSales = []
    FOR each referral IN directReferrals:
        legTotalVolume = calculateSubTreeTotalVolume(referral.id)
        legSales.add({
            legUserId: referral.id,
            totalSales: legTotalVolume,
            directUsers: countDirectUsersInLeg(referral.id)
        })

    // 엣지 케이스 2: 모든 레그의 매출이 0인 경우
    totalVolume = legSales.reduce((sum, leg) => sum + leg.totalSales, 0)
    IF totalVolume == 0:
        RETURN {
            eligible: false,
            currentRank: currentRank,
            reason: "모든 레그의 매출이 0",
            legs: legSales
        }

    // STEP 4: 매출 기준 내림차순 정렬
    sortedLegs = sortLegsBySales(legSales, DESCENDING)

    // STEP 5: A/B/C 라인 분류
    aLine = sortedLegs[0]                    // 가장 큰 매출
    bLine = sortedLegs[1]                    // 두 번째로 큰 매출
    cLineSales = 0                           // 나머지 모든 레그 합산
    cLineLegs = []

    FOR i FROM 2 TO sortedLegs.length-1:
        cLineSales += sortedLegs[i].totalSales
        cLineLegs.add(sortedLegs[i])

    // STEP 6: 레벨별 조건 체크
    levelRequirements = {
        1: { coin: 2000000, a: 50000000,  b: 50000000,  c: 50000000 },
        2: { coin: 2000000, a: 200000000, b: 200000000, c: 200000000 },
        3: { coin: 2000000, a: 500000000, b: 500000000, c: 500000000 },
        4: { coin: 2000000, a: 1000000000, b: 1000000000, c: 1000000000 },
        5: { coin: 2000000, a: 10000000000, b: 10000000000, c: 10000000000 }
    }

    maxEligibleLevel = 0
    failedLevels = []

    FOR level FROM 1 TO 5:
        requirements = levelRequirements[level]
        levelEligible = true

        // 조건별 체크
        IF user.personalCoin < requirements.coin:
            levelEligible = false
            failedReason = `코인 보유량 부족: ${requirements.coin} 필요 (현재: ${user.personalCoin})`

        IF aLine.totalSales < requirements.a:
            levelEligible = false
            failedReason = `A라인 매출 부족: ${requirements.a} 필요 (현재: ${aLine.totalSales})`

        IF bLine.totalSales < requirements.b:
            levelEligible = false
            failedReason = `B라인 매출 부족: ${requirements.b} 필요 (현재: ${bLine.totalSales})`

        IF cLineSales < requirements.c:
            levelEligible = false
            failedReason = `C라인 매출 부족: ${requirements.c} 필요 (현재: ${cLineSales})`

        IF levelEligible:
            maxEligibleLevel = level
        ELSE:
            failedLevels.add({
                level: level,
                reason: failedReason,
                requirements: requirements,
                current: {
                    coin: user.personalCoin,
                    aLine: aLine.totalSales,
                    bLine: bLine.totalSales,
                    cLine: cLineSales
                }
            })
            BREAK // 상위 레벨 실패 시 더 이상 체크하지 않음

    // STEP 7: 결과 반환
    isEligible = maxEligibleLevel > currentRank

    RETURN {
        eligible: isEligible,
        currentRank: currentRank,
        eligibleRank: maxEligibleLevel,
        coinBalance: user.personalCoin,
        legs: {
            A: aLine,
            B: bLine,
            C: {
                totalSales: cLineSales,
                legCount: cLineLegs.length,
                legs: cLineLegs
            }
        },
        levelRequirements: levelRequirements,
        failedLevels: failedLevels,
        promotionAvailable: isEligible
    }

FUNCTION calculateSubTreeTotalVolume(startUserId):
    // DFS를 사용한 하위 트리 전체 매출 집계
    totalVolume = 0
    visitedUsers = SET()
    userQueue = [startUserId]

    WHILE userQueue NOT EMPTY:
        currentUserId = userQueue.pop()

        IF currentUserId IN visitedUsers:
            CONTINUE

        visitedUsers.add(currentUserId)

        // 해당 유저의 활성 투자액 합산
        userInvestments = getActiveInvestments(currentUserId)
        FOR each investment IN userInvestments:
            totalVolume += investment.amount

        // 하위 추천인들 탐색
        referrals = getDirectReferrals(currentUserId)
        FOR each referral IN referrals:
            IF referral.isActive AND referral.id NOT IN visitedUsers:
                userQueue.push(referral.id)

    RETURN totalVolume

// 엣지 케이스 처리 함수
FUNCTION handleRankPromotionEdgeCases(userId, evaluationResult):
    CASE evaluationResult.reason:
        WHEN "직추천인 3명 미만":
            return {
                action: "INFORM_USER",
                message: "추천인 3명을 모집해야 승급 심사가 가능합니다.",
                requiredAction: "DIRECT_RECRUITMENT"
            }

        WHEN "코인 보유량 200만개 미만":
            return {
                action: "INFORM_USER",
                message: "200만 코인 보유가 승급의 기본 조건입니다.",
                requiredAction: "COIN_PURCHASE"
            }

        WHEN "모든 레그의 매출이 0":
            return {
                action: "INFORM_USER",
                message: "팀원들의 투자 활성화가 필요합니다.",
                requiredAction: "TEAM_ACTIVATION"
            }

        DEFAULT:
            return {
                action: "STANDARD_EVALUATION",
                message: "정상적인 승급 심사 진행"
            }
```

## 2. 추천 매칭 보너스 로직 (Matching Bonus)

### 2.1 투자금액별 Depth Cut-off 테이블

| 투자 금액 구간 | 최소 매칭 대수 | 최대 매칭 대수 | 지급 세대 범위 |
|--------------|--------------|--------------|--------------|
| $0 - $49     | 0            | 0            | 없음 |
| $50 - $99    | 1            | 4            | 1~4대 |
| $100 - $999  | 1            | 8            | 1~8대 |
| $1,000 - $9,999 | 1        | 12           | 1~12대 |
| $10,000+     | 1            | 12           | 1~12대 |

### 2.2 세대별 지급율 테이블

| 세대 | 지급율 |
|------|--------|
| 1대  | 12% |
| 2~4대 | 8% |
| 5~8대 | 5% |
| 9~12대 | 3% |

### 2.3 의사코드 - 매칭 보너스 계산

```pseudocode
FUNCTION calculateMatchingBonus(downlineUserId, dailyRewardAmount):
    matchingBonuses = []

    // STEP 1: 하위 유저의 상위 12대 스폰서 조회
    sponsors = findUpTo12Sponsors(downlineUserId)

    FOR each sponsor IN sponsors:
        sponsorGeneration = sponsor.generation

        // STEP 2: 스폰서 활성 상태 체크
        IF NOT isUserActive(sponsor.id):
            CONTINUE // 비활성 스폰서는 매칭 보너스 없음

        // STEP 3: 스폰서의 투자 정보 조회
        sponsorInvestment = getTotalInvestment(sponsor.id)
        maxMatchingDepth = getMaxMatchingDepth(sponsorInvestment)

        // STEP 4: Cut-off 체크
        IF sponsorGeneration > maxMatchingDepth:
            CONTINUE // 지급 범위 초과

        // STEP 5: 세대별 지급율 계산
        matchingRate = getMatchingRateByGeneration(sponsorGeneration)

        // STEP 6: 매칭 보너스 계산 (소수점 오차 방지)
        bonusAmount = calculatePreciseBonus(dailyRewardAmount, matchingRate)

        // STEP 7: 탈퇴/비활성 스폰서 처리 (압축 롤업)
        actualBonusAmount = processSponsorCompression(
            sponsor.id,
            bonusAmount,
            sponsorGeneration
        )

        IF actualBonusAmount > 0:
            matchingBonuses.add({
                sponsorUserId: sponsor.id,
                generation: sponsorGeneration,
                matchingRate: matchingRate,
                originalAmount: bonusAmount,
                actualAmount: actualBonusAmount,
                sponsorInvestment: sponsorInvestment,
                maxDepth: maxMatchingDepth
            })

    RETURN matchingBonuses

FUNCTION getMaxMatchingDepth(investmentAmount):
    // 투자 금액에 따른 최대 매칭 깊이 반환
    IF investmentAmount < 50:
        RETURN 0
    ELSE IF investmentAmount < 100:
        RETURN 4
    ELSE IF investmentAmount < 1000:
        RETURN 8
    ELSE IF investmentAmount < 10000:
        RETURN 12
    ELSE:
        RETURN 12

FUNCTION getMatchingRateByGeneration(generation):
    // 세대별 지급율 반환
    IF generation == 1:
        RETURN 12    // 12%
    ELSE IF generation >= 2 AND generation <= 4:
        RETURN 8     // 8%
    ELSE IF generation >= 5 AND generation <= 8:
        RETURN 5     // 5%
    ELSE IF generation >= 9 AND generation <= 12:
        RETURN 3     // 3%
    ELSE:
        RETURN 0

FUNCTION calculatePreciseBonus(baseAmount, ratePercent):
    // 소수점 오차 방지를 위한 정밀 계산
    rateDecimal = ratePercent / 100

    // 모든 금액을 최소 단위(8자리 소수점)로 변환 후 계산
    baseInCents = Math.round(baseAmount * 100000000) // 8자리 소수점으로 변환
    bonusInCents = Math.round(baseInCents * rateDecimal)

    RETURN bonusInCents / 100000000 // 다시 소수점으로 변환

// 스폰서 압축 롤업 처리
FUNCTION processSponsorCompression(sponsorId, originalBonusAmount, generation):
    sponsor = getUser(sponsorId)

    CASE sponsor.status:
        WHEN "ACTIVE":
            RETURN originalBonusAmount

        WHEN "SUSPENDED":
            RETURN 0 // 정지된 스폰서는 보너스 없음

        WHEN "INACTIVE":
            // 엣지 케이스: 비활성 스폰서의 상위 스폰서에게 롤업
            nextSponsor = findNextActiveSponsor(sponsorId, generation + 1)
            IF nextSponsor EXISTS:
                // 롤업 시 90%만 지급 (10%는 시스템 수수료)
                RETURN originalBonusAmount * 0.9
            ELSE:
                RETURN 0

        WHEN "TERMINATED":
            // 완전 탈퇴한 경우, 즉시 상위 스폰서에게 롤업
            nextSponsor = findNextActiveSponsor(sponsorId, generation + 1)
            IF nextSponsor EXISTS:
                RETURN originalBonusAmount * 0.95 // 탈퇴 롤업은 95% 지급
            ELSE:
                RETURN 0

        DEFAULT:
            RETURN 0

FUNCTION findNextActiveSponsor(inactiveUserId, startGeneration):
    // 비활성 유저의 상위 스폰서 중 활성인 사람 찾기
    currentUser = getUser(inactiveUserId)
    currentGeneration = startGeneration

    WHILE currentUser.referrerId EXISTS AND currentGeneration <= 12:
        potentialSponsor = getUser(currentUser.referrerId)

        IF isUserActive(potentialSponsor.id):
            RETURN {
                userId: potentialSponsor.id,
                generation: currentGeneration,
                isRolledUp: true
            }

        currentUser = potentialSponsor
        currentGeneration += 1

    RETURN NULL // 활성 스폰서 없음
```

### 2.4 예외 처리 규칙

#### 2.4.1 스폰서 상태별 처리
```pseudocode
// 스폰서 상태에 따른 매칭 보너스 처리 규칙
SPONSOR_STATUS_RULES = {
    "ACTIVE": {
        action: "PAY_FULL",
        rate: 1.0,
        description: "정상 지급"
    },
    "INACTIVE": {
        action: "ROLL_UP",
        rate: 0.9,
        description: "상위 스폰서에게 90% 롤업"
    },
    "SUSPENDED": {
        action: "HOLD",
        rate: 0.0,
        description: "보유 (해제 시 지급)"
    },
    "TERMINATED": {
        action: "ROLL_UP_IMMEDIATE",
        rate: 0.95,
        description: "즉시 상위 스폰서에게 95% 롤업"
    }
}
```

#### 2.4.2 소수점 처리 가이드
```javascript
// 실제 구현용 소수점 처리 코드
class DecimalProcessor {
    static calculateMatchingBonus(baseAmount, ratePercent) {
        // 1. 입력값 검증
        if (baseAmount <= 0 || ratePercent <= 0) return 0;

        // 2. 정밀도 설정 (8자리 소수점)
        const PRECISION = 8;
        const MULTIPLIER = Math.pow(10, PRECISION);

        // 3. 정수로 변환하여 계산
        const baseInt = Math.round(baseAmount * MULTIPLIER);
        const rateInt = Math.round(ratePercent * 100); // 밀리퍼센트로 변환
        const bonusInt = Math.round((baseInt * rateInt) / 10000);

        // 4. 소수점으로 복원
        return bonusInt / MULTIPLIER;
    }

    static roundDownToMinimumUnit(amount) {
        // 최소 지급 단위(0.00000001)로 내림
        const PRECISION = 8;
        const MULTIPLIER = Math.pow(10, PRECISION);
        return Math.floor(amount * MULTIPLIER) / MULTIPLIER;
    }
}
```

### 2.5 통합 실행 함수

```pseudocode
FUNCTION processDailyRewardWithMatching(userId, investmentAmount, dailyRate):
    results = {
        dailyReward: 0,
        matchingBonuses: [],
        totalReward: 0
    }

    // 1. 기본 데일리 리워드 계산
    results.dailyReward = calculateDailyReward(investmentAmount, dailyRate)

    // 2. 매칭 보너스 계산
    results.matchingBonuses = calculateMatchingBonus(userId, results.dailyReward)

    // 3. 총보상 집계
    totalMatchingBonus = results.matchingBonuses.reduce((sum, bonus) => sum + bonus.actualAmount, 0)
    results.totalReward = results.dailyReward + totalMatchingBonus

    // 4. 리워드 로그 기록
    saveRewardLog(userId, "DAILY", results.dailyReward, investmentId: currentInvestment.id)

    FOR each bonus IN results.matchingBonuses:
        saveRewardLog(
            bonus.sponsorUserId,
            "MATCHING",
            bonus.actualAmount,
            sourceUserId: userId,
            generation: bonus.generation
        )

    RETURN results
```

## 3. 핵심 엣지 케이스 정리

### 3.1 랭크 승급 관련
1. **직추천인 부족**: 3명 미만 시 승급 불가
2. **매출 0인 레그**: 모든 레그의 매출이 0이면 실패
3. **코인 부족**: 200만개 미만 보유 시 기본 실패
4. **동일 매출 레그**: 동률 시 가입일 기준 정렬

### 3.2 매칭 보너스 관련
1. **스폰서 탈퇴**: 상위 활성 스폰서에게 롤업 (90-95%)
2. **투자금액 Cut-off**: 투자액에 따른 지급 대수 제한
3. **소수점 오차**: 8자리 소수점 정밀도로 계산
4. **12대 초과**: 12대 이상 스폰서는 보너스 없음