# 빠른 시작 가이드

## 🚀 서버 실행

### 1. 환경 변수 설정
`.env` 파일을 생성하고 다음 내용을 추가하세요:

```env
DATABASE_URL="postgresql://user:password@localhost:5432/dbname?schema=public"
NEXT_PUBLIC_BASE_URL="http://localhost:3009"
NODE_ENV="development"
CRON_TIMEZONE="Asia/Seoul"
```

### 2. 데이터베이스 설정
```bash
# Prisma 마이그레이션
npx prisma db push

# 또는
npx prisma migrate dev
```

### 3. 서버 실행
```bash
npm run dev
```

서버가 시작되면:
- http://localhost:3009 접속
- 자동으로 `/login` 페이지로 리다이렉트됩니다

## 📋 주요 페이지

- **로그인**: http://localhost:3009/login
- **회원가입**: http://localhost:3009/register
- **대시보드**: http://localhost:3009/dashboard (로그인 필요)
- **투자**: http://localhost:3009/invest (로그인 필요)
- **관리자**: http://localhost:3009/admin (관리자 권한 필요)

## 🔧 문제 해결

### 404 에러 발생 시
1. 서버 재시작
2. 브라우저 캐시 삭제
3. 직접 `/login` 페이지 접근

### 데이터베이스 연결 오류
1. `.env` 파일 확인
2. PostgreSQL 서버 실행 확인
3. `DATABASE_URL` 형식 확인

## ✅ 확인 사항

서버 실행 후:
- [ ] 콘솔에 "Ready" 메시지 표시
- [ ] 스케줄러 시작 메시지 확인
- [ ] http://localhost:3009 접근 가능
- [ ] 로그인 페이지 표시

