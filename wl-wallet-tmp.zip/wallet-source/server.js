// Railway 배포를 위한 Next.js 서버 실행 파일
// Next.js standalone output의 server.js를 실행합니다

const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

// standalone output 경로 확인
const standalonePath = path.join(__dirname, '.next', 'standalone', 'server.js');
const standaloneDir = path.join(__dirname, '.next', 'standalone');

// standalone output이 있는 경우 해당 server.js 실행
if (fs.existsSync(standalonePath)) {
  // standalone 디렉토리로 이동하여 실행
  const originalCwd = process.cwd();
  process.chdir(standaloneDir);
  
  try {
    require('./server.js');
  } catch (error) {
    console.error('Failed to start standalone server:', error);
    process.chdir(originalCwd);
    // Fallback to npm start
    const npmProcess = spawn('npm', ['start'], {
      stdio: 'inherit',
      shell: true,
      cwd: __dirname
    });
    
    npmProcess.on('error', (err) => {
      console.error('Failed to start server:', err);
      process.exit(1);
    });
  }
} else {
  // standalone output이 없는 경우 일반 next start 실행
  console.warn('Standalone output not found, using npm start');
  const npmProcess = spawn('npm', ['start'], {
    stdio: 'inherit',
    shell: true,
    cwd: __dirname
  });
  
  npmProcess.on('error', (err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

