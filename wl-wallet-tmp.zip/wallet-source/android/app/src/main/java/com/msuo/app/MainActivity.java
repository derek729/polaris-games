package com.msuo.app;

import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // WebView 만들고 화면 전체로 사용
        webView = new WebView(this);
        setContentView(webView);

        // WebView 설정
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);       // 자바스크립트 허용
        settings.setDomStorageEnabled(true);       // localStorage 등 허용
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        // 여기에서 우리 사이트 열기
        webView.loadUrl("https://msuo.org");
    }

    @Override
    public void onBackPressed() {
        // 웹에서 뒤로 갈 수 있으면 웹 뒤로가기
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            // 더 이상 없으면 앱 종료
            super.onBackPressed();
        }
    }
}
