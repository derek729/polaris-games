import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.msuo.app',
  appName: 'MSUO',
  webDir: 'public',
  server: {
    androidScheme: 'https',
    // -------------------------------------------------------------------------
    // [중요] Next.js API 라우트를 사용하려면 앱이 배포된 URL을 입력해야 합니다.
    // 예: url: 'https://your-deployed-app.com',
    // 로컬 개발 시(Android Emulator): url: 'http://10.0.2.2:3009', cleartext: true
    // -------------------------------------------------------------------------
    url: 'https://msuo.org',
    cleartext: false
  }
};

export default config;
