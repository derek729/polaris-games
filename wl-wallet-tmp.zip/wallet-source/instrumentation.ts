/**
 * Next.js Instrumentation Hook
 * 서버 시작 시 자동으로 실행되는 코드
 * 
 * 이 파일은 Next.js 서버가 시작될 때 자동으로 실행됩니다.
 * 스케줄러와 같은 백그라운드 작업을 초기화하는 데 사용됩니다.
 */

export async function register() {
  // 서버 사이드에서만 실행
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    // 기본값: 스케줄러 자동 시작 비활성화 (로컬/재단용 모드에서 DB 없이도 서버가 떠야 함)
    // - ENABLE_REWARD_SCHEDULER=true 로 명시한 경우에만 시작
    // - APP_MODE=foundation 인 경우에는 항상 비활성화
    const appMode = (process.env.APP_MODE || 'foundation').toLowerCase();
    const enableScheduler = (process.env.ENABLE_REWARD_SCHEDULER || '').toLowerCase() === 'true';

    if (appMode === 'foundation' || !enableScheduler) {
      console.log(
        `ℹ️ [Instrumentation] 스케줄러 자동 시작 비활성화 (APP_MODE=${appMode}, ENABLE_REWARD_SCHEDULER=${process.env.ENABLE_REWARD_SCHEDULER || 'undefined'})`
      );
      return;
    }

    // 약간의 지연을 두어 Prisma 클라이언트가 완전히 초기화되도록 함
    setTimeout(async () => {
      try {
        const { startDailyRewardScheduler } = await import('./src/services/scheduler');
        
        console.log('🚀 [Instrumentation] 서버 초기화 중...');
        console.log(`[Instrumentation] 환경: ${process.env.NODE_ENV || 'development'}`);
        console.log(`[Instrumentation] 타임존: ${process.env.CRON_TIMEZONE || 'Asia/Seoul'}`);
        
        const result = startDailyRewardScheduler();
        
        if (result.success) {
          console.log('✅ [Instrumentation] 일일 리워드 스케줄러가 자동으로 시작되었습니다.');
        } else {
          console.error('❌ [Instrumentation] 스케줄러 시작 실패:', result.message);
        }
      } catch (error: any) {
        console.error('❌ [Instrumentation] 스케줄러 시작 중 오류 발생:', error);
        console.error('❌ [Instrumentation] 오류 상세:', error.stack);
      }
    }, 2000); // 2초 지연
  }
}

