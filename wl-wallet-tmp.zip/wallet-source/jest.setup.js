// Jest setup file for @testing-library/react
import '@testing-library/jest-dom'

// Mock Next.js modules
jest.mock('next/headers', () => ({
  cookies: jest.fn(() => Promise.resolve({
    get: jest.fn(() => ({ value: null })),
    set: jest.fn(),
    delete: jest.fn(),
    getAll: jest.fn(() => []),
  })),
  headers: jest.fn(() => Promise.resolve({
    get: jest.fn(),
  })),
}))

// Mock Prisma client
jest.mock('@/lib/prisma', () => ({
  prisma: {
    users: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
      count: jest.fn(),
    },
    investments: {
      findUnique: jest.fn(),
      findMany: jest.fn(),
      create: jest.fn(),
      update: jest.fn(),
      delete: jest.fn(),
    },
    reward_logs: {
      create: jest.fn(),
      findMany: jest.fn(),
    },
    $transaction: jest.fn((callback) => callback({
      users: { update: jest.fn() },
      reward_logs: { create: jest.fn() },
    })),
  },
}))

// Mock bcryptjs
jest.mock('bcryptjs', () => ({
  hash: jest.fn((password) => Promise.resolve(`hashed_${password}`)),
  compare: jest.fn((password, hash) => Promise.resolve(hash === `hashed_${password}`)),
}))

// Global test utilities
global.mockRequest = (data = {}) => ({
  json: jest.fn(() => Promise.resolve(data)),
  headers: { get: jest.fn() },
  ...data,
})

global.mockResponse = () => {
  const res = {
    status: jest.fn(() => res),
    json: jest.fn(() => res),
    send: jest.fn(() => res),
    end: jest.fn(() => res),
    setHeader: jest.fn(() => res),
  }
  return res
}

console.log('Jest setup completed')
