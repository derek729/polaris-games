const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Use DATABASE_URL from .env file
const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL is not set in .env file');
  console.error('Railway Console에서 다음 명령어를 먼저 실행하세요:');
  console.error('export DATABASE_URL="postgresql://<user>:<password>@<host>:<port>/<database>"');
  process.exit(1);
}

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: DATABASE_URL
    }
  }
});

async function createAdminWithDB() {
  try {
    console.log('🔐 Railway 데이터베이스에 연결하여 관리자 계정 생성...');
    console.log('');

    // 데이터베이스 연결 테스트
    await prisma.$connect();
    console.log('✅ 데이터베이스 연결 성공!');

    // 테이블 존재 확인
    try {
      const userCount = await prisma.users.count();
      console.log(`📊 현재 사용자 수: ${userCount}`);
    } catch (error) {
      if (error.message.includes('does not exist')) {
        console.log('❌ users 테이블이 존재하지 않습니다. 먼저 스키마를 생성해야 합니다.');
        console.log('🔄 Prisma 스키마 동기화 시작...');

        const { execSync } = require('child_process');
        execSync('npx prisma db push', {
          stdio: 'inherit',
          env: { ...process.env, DATABASE_URL }
        });

        console.log('✅ 스키마 동기화 완료!');
      } else {
        throw error;
      }
    }

    // 관리자 계정 생성
    console.log('👑 관리자 계정 생성 중...');

    const hashedPassword = await bcrypt.hash('Admin@123456', 10);

    const adminData = {
      username: 'admin',
      email: 'admin@upc.co.kr',
      password: hashedPassword,
      role: 'SUPER_ADMIN',
      rank: 5,
      personalCoin: 1000000,
      totalInvestment: 0,
      status: 'ACTIVE',
      isActive: true,
      accumulatedSales: 0,
      line1Sales: 0,
      line2Sales: 0,
      line3Sales: 0,
      line4Sales: 0,
      line5Sales: 0,
    };

    // 기존 계정 확인 및 업서트
    const admin = await prisma.users.upsert({
      where: { username: 'admin' },
      update: {
        email: adminData.email,
        role: adminData.role,
        rank: adminData.rank,
        status: adminData.status,
        isActive: adminData.isActive,
        password: adminData.password,
      },
      create: adminData,
    });

    console.log('✅ 관리자 계정 생성/업데이트 완료!');
    console.log('');
    console.log('📋 생성된 계정 정보:');
    console.log(`- ID: ${admin.id}`);
    console.log(`- 사용자명: ${admin.username}`);
    console.log(`- 이메일: ${admin.email}`);
    console.log(`- 권한: ${admin.role}`);
    console.log(`- 랭크: ${admin.rank}`);
    console.log(`- 상태: ${admin.status}`);
    console.log('');
    console.log('🔗 로그인 정보:');
    console.log('- URL: https://<your-deployed-app>/a0-admin/login');
    console.log('- 사용자명: admin');
    console.log('- 비밀번호: Admin@123456');
    console.log('');
    console.log('⚠️  중요: 보안을 위해 첫 로그인 후 비밀번호를 변경하세요!');

    // 모든 관리자 계정 목록 확인
    const allAdmins = await prisma.users.findMany({
      where: {
        role: {
          in: ['ADMIN', 'SUPER_ADMIN']
        }
      },
      select: {
        id: true,
        username: true,
        email: true,
        role: true,
        status: true,
        createdAt: true
      }
    });

    if (allAdmins.length > 0) {
      console.log('');
      console.log('👥 모든 관리자 계정:');
      allAdmins.forEach((adminUser, index) => {
        console.log(`${index + 1}. ${adminUser.username} (${adminUser.email}) - ${adminUser.role}`);
      });
    }

  } catch (error) {
    console.error('❌ 오류 발생:', error.message);

    if (error.code === 'ECONNREFUSED') {
      console.log('');
      console.log('💡 데이터베이스 연결 거부');
      console.log('Railway 환경에서 실행해야 합니다.');
    } else if (error.message.includes('authentication failed')) {
      console.log('');
      console.log('💡 데이터베이스 인증 실패');
      console.log('연결 정보를 확인하세요.');
    }

    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

createAdminWithDB();