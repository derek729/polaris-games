/**
 * 데이터베이스 마이그레이션 실행 스크립트
 * Prisma 마이그레이션을 안전하게 실행합니다.
 */

import { PrismaClient } from '@prisma/client';
import { execSync } from 'child_process';

const prisma = new PrismaClient();

async function migrateDatabase() {
  try {
    console.log('========================================');
    console.log('데이터베이스 마이그레이션 시작');
    console.log('========================================\n');

    // 1. 현재 데이터베이스 상태 확인
    console.log('[1단계] 데이터베이스 상태 확인...');
    try {
      const result = await prisma.$queryRaw<Array<{ column_name: string }>>`
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name = 'users' 
        AND column_name IN ('twoFactorEnabled', 'twoFactorSecret', 'twoFactorBackupCodes')
      `;
      
      const existingColumns = result.map(r => r.column_name);
      console.log(`현재 존재하는 컬럼: ${existingColumns.length > 0 ? existingColumns.join(', ') : '없음'}\n`);

      if (existingColumns.length === 3) {
        console.log('✅ 모든 2FA 컬럼이 이미 존재합니다. 마이그레이션이 필요 없습니다.');
        return;
      }
    } catch (error) {
      console.log('⚠️  데이터베이스 상태 확인 중 오류 (계속 진행):', error);
    }

    // 2. 마이그레이션 SQL 실행
    console.log('[2단계] 마이그레이션 SQL 실행...');
    
    const migrationSQL = `
      -- 2FA 필드 추가
      ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "twoFactorEnabled" BOOLEAN NOT NULL DEFAULT false;
      ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "twoFactorSecret" TEXT;
      ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "twoFactorBackupCodes" TEXT[] DEFAULT ARRAY[]::TEXT[];
      
      -- 기존 사용자 데이터 업데이트
      UPDATE "users" 
      SET "twoFactorEnabled" = false 
      WHERE "twoFactorEnabled" IS NULL;
      
      UPDATE "users" 
      SET "twoFactorBackupCodes" = ARRAY[]::TEXT[] 
      WHERE "twoFactorBackupCodes" IS NULL;
    `;

    await prisma.$executeRawUnsafe(migrationSQL);
    console.log('✅ 마이그레이션 SQL 실행 완료\n');

    // 3. 마이그레이션 확인
    console.log('[3단계] 마이그레이션 확인...');
    const verifyResult = await prisma.$queryRaw<Array<{ column_name: string }>>`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'users' 
      AND column_name IN ('twoFactorEnabled', 'twoFactorSecret', 'twoFactorBackupCodes')
    `;
    
    const verifiedColumns = verifyResult.map(r => r.column_name);
    console.log(`확인된 컬럼: ${verifiedColumns.join(', ')}`);

    if (verifiedColumns.length === 3) {
      console.log('\n✅ 마이그레이션이 성공적으로 완료되었습니다!');
    } else {
      console.log('\n⚠️  일부 컬럼이 누락되었을 수 있습니다.');
    }

  } catch (error: any) {
    console.error('\n❌ 마이그레이션 실패:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

// 스크립트 실행
migrateDatabase()
  .then(() => {
    console.log('\n✅ 마이그레이션 프로세스 완료');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ 마이그레이션 프로세스 실패:', error);
    process.exit(1);
  });

