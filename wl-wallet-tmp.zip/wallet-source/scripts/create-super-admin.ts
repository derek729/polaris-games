import { Prisma } from '@prisma/client';
import bcrypt from 'bcryptjs';
import * as readline from 'readline';

const prisma = new PrismaClient();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(query: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(query, resolve);
  });
}

async function main() {
  console.log('👑 슈퍼관리자 계정 생성 도구');
  console.log('=====================================\n');

  try {
    // 사용자 입력 받기
    const username = await question('사용자명을 입력하세요 (기본값: admin): ') || 'admin';
    const email = await question('이메일을 입력하세요 (기본값: admin@upcwallet.com): ') || 'admin@upcwallet.com';
    const password = await question('비밀번호를 입력하세요 (기본값: admin123): ') || 'admin123';

    // 기존 계정 확인
    const existingUser = await prisma.users.findFirst({
      where: {
        OR: [
          { username },
          { email },
        ],
      },
    });

    if (existingUser) {
      console.log('\n⚠️  이미 존재하는 사용자명 또는 이메일입니다.');
      const overwrite = await question('기존 계정을 업데이트하시겠습니까? (y/N): ');
      
      if (overwrite.toLowerCase() !== 'y') {
        console.log('취소되었습니다.');
        return;
      }

      // 기존 계정 업데이트
      const hashedPassword = await bcrypt.hash(password, 10);
      await prisma.users.update({
        where: { id: existingUser.id },
        data: {
          username,
          email,
          password: hashedPassword,
          role: UserRole.SUPER_ADMIN,
          rank: 5,
          status: 'ACTIVE',
          isActive: true,
        },
      });

      console.log('\n✅ 기존 계정이 슈퍼관리자로 업데이트되었습니다!');
      console.log(`   사용자명: ${username}`);
      console.log(`   이메일: ${email}`);
      console.log(`   권한: SUPER_ADMIN`);
    } else {
      // 새 계정 생성
      const hashedPassword = await bcrypt.hash(password, 10);
      
      const superAdmin = await prisma.1.create({{ data: {
          username,
          email,
          password: hashedPassword,
          role: UserRole.SUPER_ADMIN,
          rank: 5, // 최고 랭크
          personalCoin: new Prisma.Decimal(10000000), // 1천만 코인
          totalInvestment: new Prisma.Decimal(100000), // $100,000 투자
          status: 'ACTIVE',
          isActive: true,
          accumulatedSales: new Prisma.Decimal(0),
          line1Sales: new Prisma.Decimal(0),
          line2Sales: new Prisma.Decimal(0),
          line3Sales: new Prisma.Decimal(0),
          line4Sales: new Prisma.Decimal(0),
          line5Sales: new Prisma.Decimal(0),
        },
      });

      // 슈퍼관리자 투자 생성
      await prisma.1.create({{ data: {
          userId: superAdmin.id,
          amount: new Prisma.Decimal(100000),
          dailyRate: new Prisma.Decimal(0.015), // 1.5%
          matchingDepth: 12,
          investment_tiers: 6,
          startDate: new Date(),
          endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
        },
      });

      console.log('\n✅ 슈퍼관리자 계정이 생성되었습니다!');
      console.log(`   사용자명: ${username}`);
      console.log(`   이메일: ${email}`);
      console.log(`   비밀번호: ${password}`);
      console.log(`   권한: SUPER_ADMIN`);
      console.log(`   랭크: 5 (최고 랭크)`);
    }
  } catch (error) {
    console.error('\n❌ 오류 발생:', error);
    process.exit(1);
  } finally {
    rl.close();
    await prisma.$disconnect();
  }
}

main();



