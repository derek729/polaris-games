/**
 * Railway 데이터베이스에 직접 연결하여 보상 재처리 스크립트
 * 
 * 사용 방법:
 * 1. Railway CLI 설치: npm install -g @railway/cli
 * 2. Railway 프로젝트 연결: railway link
 * 3. 스크립트 실행: railway run npx tsx scripts/process-railway-rewards.ts
 * 
 * 또는 로컬에서 DATABASE_URL 설정:
 * export DATABASE_URL="postgresql://user:password@host:5432/dbname"
 * npx tsx scripts/process-railway-rewards.ts
 */

import { Prisma } from '@prisma/client';
import { processDailyRewards } from '../src/services/dailyReward';
import { processAllLeadershipBonuses } from '../src/services/leadershipBonus';

const prisma = new PrismaClient();

async function main() {
  console.log('🚀 Railway 데이터베이스 보상 재처리 시작...\n');

  // Railway DATABASE_URL 확인
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.error('❌ DATABASE_URL 환경 변수가 설정되지 않았습니다.');
    console.log('\n사용 방법:');
    console.log('1. Railway CLI 사용: railway run npx tsx scripts/process-railway-rewards.ts');
    console.log('2. 로컬에서 DATABASE_URL 설정: export DATABASE_URL="postgresql://..."');
    process.exit(1);
  }

  console.log('✅ 데이터베이스 연결 확인');
  console.log(`   URL: ${databaseUrl.replace(/:[^:@]+@/, ':****@')}\n`);

  // 연결 테스트
  try {
    await prisma.$connect();
    console.log('✅ 데이터베이스 연결 성공\n');
  } catch (error) {
    console.error('❌ 데이터베이스 연결 실패:', error);
    process.exit(1);
  }

  // 명령줄 인자 확인
  const args = process.argv.slice(2);
  const startDate = args[0] || '2024-12-11';
  const endDate = args[1] || '2024-12-12';
  const forceRepayment = args[2] === 'force' || args[2] === 'true';

  console.log('📅 처리 기간:');
  console.log(`   시작일: ${startDate}`);
  console.log(`   종료일: ${endDate}`);
  console.log(`   강제 재지급: ${forceRepayment ? '예' : '아니오'}\n`);

  // 날짜 범위 확인
  const start = new Date(startDate);
  const end = new Date(endDate);
  start.setHours(0, 0, 0, 0);
  end.setHours(23, 59, 59, 999);

  if (start > end) {
    console.error('❌ 시작일이 종료일보다 늦습니다.');
    process.exit(1);
  }

  // 활성 투자 건 확인
  console.log('📊 활성 투자 건 확인 중...');
  const investments = await prisma.investments.findMany({
    where: {
      isActive: true,
      startDate: { lte: end },
      endDate: { gte: start },
    },
  });
  console.log(`   총 활성 투자 건: ${investments.length}건\n`);

  if (investments.length === 0) {
    console.log('⚠️  해당 기간에 활성 투자 건이 없습니다.');
    console.log('   투자 건의 startDate와 endDate를 확인해주세요.\n');
    
    // 전체 활성 투자 건 확인
    const allActiveInvestments = await prisma.investments.findMany({
      where: { isActive: true },
      take: 5,
      orderBy: { createdAt: 'desc' },
    });
    
    if (allActiveInvestments.length > 0) {
      console.log('📋 최근 활성 투자 건 샘플:');
      allActiveInvestments.forEach((inv) => {
        console.log(`   - ID: ${inv.id}`);
        console.log(`     시작일: ${inv.startDate.toISOString().split('T')[0]}`);
        console.log(`     종료일: ${inv.endDate.toISOString().split('T')[0]}`);
        console.log(`     금액: ${inv.amount} USDT\n`);
      });
    }
  }

  // 날짜별 처리
  const results = [];
  const currentDate = new Date(start);

  while (currentDate <= end) {
    const targetDate = new Date(currentDate);
    targetDate.setHours(0, 0, 0, 0);

    const dateStr = targetDate.toISOString().split('T')[0];
    console.log(`\n📅 ${dateStr} 처리 중...`);

    try {
      // 일일 수익 지급
      const dailyResult = await processDailyRewards(targetDate, forceRepayment);
      console.log(`   ✅ 일일 수익: ${dailyResult.processedCount}건 처리, ${dailyResult.skippedCount}건 스킵, ${dailyResult.errorCount}건 오류`);
      console.log(`   📊 총 투자 건: ${dailyResult.totalInvestments}건`);

      // 리더십 보너스 지급
      const leadershipResult = await processAllLeadershipBonuses(targetDate);
      console.log(`   ✅ 리더십 보너스: ${leadershipResult.processedCount}명 처리, ${leadershipResult.errorCount}명 오류`);
      console.log(`   📊 총 대상: ${leadershipResult.totalUsers}명`);

      results.push({
        date: dateStr,
        daily: dailyResult,
        leadership: leadershipResult,
        success: true,
      });
    } catch (error: any) {
      console.error(`   ❌ 오류: ${error.message}`);
      results.push({
        date: dateStr,
        success: false,
        error: error.message,
      });
    }

    // 다음 날로 이동
    currentDate.setDate(currentDate.getDate() + 1);
  }

  // 결과 요약
  console.log('\n\n📊 처리 결과 요약:');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  results.forEach((result) => {
    if (result.success && result.daily && result.leadership) {
      console.log(`✅ ${result.date}:`);
      console.log(`   일일: ${result.daily.processedCount}건 처리`);
      console.log(`   리더십: ${result.leadership.processedCount}명 처리`);
    } else {
      console.log(`❌ ${result.date}: ${result.error || '알 수 없는 오류'}`);
    }
  });
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  const successCount = results.filter((r) => r.success).length;
  const failCount = results.filter((r) => !r.success).length;

  console.log(`✅ 성공: ${successCount}일`);
  console.log(`❌ 실패: ${failCount}일`);
  console.log(`📅 총 처리: ${results.length}일\n`);

  await prisma.$disconnect();
  console.log('✅ 완료!');
}

main()
  .catch((error) => {
    console.error('❌ 오류 발생:', error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });



