/**
 * 기존 사용자들의 추천인 코드 생성 스크립트
 * 
 * 사용법: npm run generate-referral-codes
 * 또는: tsx scripts/generate-referral-codes.ts
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * 고유한 추천인 코드 생성
 */
function generateReferralCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 0, O, I, 1 제외
  let code = '';
  
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return code;
}

/**
 * 고유한 추천인 코드 생성 및 중복 확인
 */
async function generateUniqueReferralCode(): Promise<string> {
  let code: string;
  let isUnique = false;
  let attempts = 0;
  const maxAttempts = 10;

  while (!isUnique && attempts < maxAttempts) {
    code = generateReferralCode();
    
    const existing = await prisma.users.findUnique({
      where: { referralCode: code },
      select: { id: true },
    });

    if (!existing) {
      isUnique = true;
      return code;
    }

    attempts++;
  }

  // 최대 시도 횟수 초과 시 타임스탬프 추가
  const timestamp = Date.now().toString(36).toUpperCase().slice(-4);
  return generateReferralCode().slice(0, 4) + timestamp;
}

async function main() {
  try {
    console.log('🔄 기존 사용자들의 추천인 코드 생성 시작...\n');

    // referralCode가 null인 사용자들 조회
    const usersWithoutCode = await prisma.users.findMany({
      where: {
        referralCode: null,
      },
      select: {
        id: true,
        username: true,
      },
    });

    if (usersWithoutCode.length === 0) {
      console.log('✅ 모든 사용자가 이미 추천인 코드를 가지고 있습니다.');
      return;
    }

    console.log(`📊 추천인 코드가 없는 사용자: ${usersWithoutCode.length}명\n`);

    let successCount = 0;
    let errorCount = 0;

    // 각 사용자에게 추천인 코드 생성
    for (const user of usersWithoutCode) {
      try {
        const referralCode = await generateUniqueReferralCode();
        
        await prisma.users.update({
          where: { id: user.id },
          data: { referralCode },
        });

        console.log(`✅ ${user.username || user.id}: ${referralCode}`);
        successCount++;
      } catch (error: any) {
        console.error(`❌ ${user.username || user.id}: ${error.message}`);
        errorCount++;
      }
    }

    console.log(`\n📈 완료: 성공 ${successCount}명, 실패 ${errorCount}명`);
    console.log('✅ 추천인 코드 생성이 완료되었습니다.');
  } catch (error) {
    console.error('❌ 오류 발생:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();

