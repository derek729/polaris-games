/**
 * 프로덕션 환경 데이터베이스 백업 스크립트
 * Railway 또는 프로덕션 환경에서 실행
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';

const execAsync = promisify(exec);

/**
 * DATABASE_URL에서 연결 정보 파싱
 */
function parseDatabaseUrl(databaseUrl: string): {
  host: string;
  port: string;
  database: string;
  users: string;
  password: string;
} {
  try {
    // postgresql://user:password@host:port/database 형식
    const url = new URL(databaseUrl);
    return {
      host: url.hostname,
      port: url.port || '5432',
      database: url.pathname.slice(1).split('?')[0], // 첫 번째 '/' 제거 및 쿼리 제거
      users: url.username,
      password: url.password,
    };
  } catch (error) {
    throw new Error(`DATABASE_URL 파싱 실패: ${error}`);
  }
}

/**
 * 프로덕션 데이터베이스 백업 실행
 */
async function backupProductionDatabase() {
  try {
    console.log('========================================');
    console.log('프로덕션 데이터베이스 백업 시작');
    console.log('========================================\n');

    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) {
      throw new Error('DATABASE_URL 환경 변수가 설정되지 않았습니다.');
    }

    const dbInfo = parseDatabaseUrl(databaseUrl);
    
    // 프로덕션 환경 확인
    const isProduction = process.env.NODE_ENV === 'production' || 
                         databaseUrl.includes('railway') ||
                         databaseUrl.includes('amazonaws') ||
                         databaseUrl.includes('azure') ||
                         databaseUrl.includes('cloud');

    if (isProduction) {
      console.log('⚠️  프로덕션 환경 감지됨');
      console.log(`   데이터베이스: ${dbInfo.database}`);
      console.log(`   호스트: ${dbInfo.host}:${dbInfo.port}\n`);
    }

    const outputDir = process.env.BACKUP_DIR || path.join(process.cwd(), 'backups');
    const keepDays = parseInt(process.env.BACKUP_KEEP_DAYS || '7', 10);
    const compress = process.env.BACKUP_COMPRESS !== 'false';

    // 백업 디렉토리 생성
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
      console.log(`[Backup] 백업 디렉토리 생성: ${outputDir}`);
    }

    // 타임스탬프 생성
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    const envLabel = isProduction ? 'production' : 'development';
    const backupFileName = `backup-${envLabel}-${dbInfo.database}-${timestamp}.sql`;
    const backupPath = path.join(outputDir, backupFileName);
    const compressedPath = `${backupPath}.gz`;

    console.log('[Backup] 데이터베이스 백업 시작...');
    console.log(`[Backup] 데이터베이스: ${dbInfo.database}`);
    console.log(`[Backup] 호스트: ${dbInfo.host}:${dbInfo.port}`);
    console.log(`[Backup] 백업 파일: ${backupFileName}\n`);

    // pg_dump 명령어 구성
    const pgDumpCmd = [
      'pg_dump',
      `--host=${dbInfo.host}`,
      `--port=${dbInfo.port}`,
      `--username=${dbInfo.users}`,
      `--dbname=${dbInfo.database}`,
      '--no-password', // PGPASSWORD 환경 변수 사용
      '--verbose',
      '--clean', // DROP 문 포함
      '--if-exists', // IF EXISTS 사용
      '--format=plain', // SQL 형식
      `--file=${backupPath}`,
    ].join(' ');

    // 환경 변수 설정
    const env = {
      ...process.env,
      PGPASSWORD: dbInfo.password,
    };

    // 백업 실행
    console.log('[Backup] pg_dump 실행 중...');
    const startTime = Date.now();
    
    try {
      const { stdout, stderr } = await execAsync(pgDumpCmd, { 
        env,
        maxBuffer: 10 * 1024 * 1024, // 10MB 버퍼
      });

      if (stderr && !stderr.includes('NOTICE') && !stderr.includes('WARNING')) {
        console.warn('[Backup] 경고:', stderr);
      }
    } catch (error: any) {
      // pg_dump는 stderr로 진행 상황을 출력하므로, 실제 오류인지 확인 필요
      if (error.code !== 0 && !fs.existsSync(backupPath)) {
        throw new Error(`pg_dump 실행 실패: ${error.message}`);
      }
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);

    // 파일 존재 확인
    if (!fs.existsSync(backupPath)) {
      throw new Error('백업 파일이 생성되지 않았습니다.');
    }

    // 파일 크기 확인
    const stats = fs.statSync(backupPath);
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    console.log(`[Backup] 백업 파일 생성 완료 (${duration}초)`);
    console.log(`[Backup] 파일 크기: ${fileSizeMB} MB\n`);

    // 압축 (선택사항)
    if (compress) {
      console.log('[Backup] 백업 파일 압축 중...');
      try {
        await execAsync(`gzip ${backupPath}`, { env: process.env });
        const compressedStats = fs.statSync(compressedPath);
        const compressedSizeMB = (compressedStats.size / (1024 * 1024)).toFixed(2);
        const compressionRatio = ((1 - compressedStats.size / stats.size) * 100).toFixed(1);
        console.log(`[Backup] 압축 완료: ${compressedSizeMB} MB (${compressionRatio}% 감소)\n`);
        return { path: compressedPath, size: compressedStats.size, originalSize: stats.size };
      } catch (error) {
        console.warn('[Backup] 압축 실패 (gzip이 설치되지 않았을 수 있음), 원본 파일 유지');
        return { path: backupPath, size: stats.size, originalSize: stats.size };
      }
    }

    return { path: backupPath, size: stats.size, originalSize: stats.size };
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : '알 수 없는 오류';
    console.error('\n========================================');
    console.error('백업 실패:', errorMessage);
    console.error('========================================\n');
    throw error;
  }
}

/**
 * 오래된 백업 파일 삭제
 */
function cleanupOldBackups(outputDir: string, keepDays: number) {
  try {
    if (!fs.existsSync(outputDir)) {
      return;
    }

    const files = fs.readdirSync(outputDir);
    const now = Date.now();
    const keepTime = keepDays * 24 * 60 * 60 * 1000;

    let deletedCount = 0;
    let freedSpace = 0;

    for (const file of files) {
      if (!file.startsWith('backup-') || (!file.endsWith('.sql') && !file.endsWith('.sql.gz'))) {
        continue;
      }

      const filePath = path.join(outputDir, file);
      const stats = fs.statSync(filePath);
      const fileAge = now - stats.mtimeMs;

      if (fileAge > keepTime) {
        freedSpace += stats.size;
        fs.unlinkSync(filePath);
        deletedCount++;
        console.log(`[Backup] 오래된 백업 파일 삭제: ${file}`);
      }
    }

    if (deletedCount > 0) {
      const freedSpaceMB = (freedSpace / (1024 * 1024)).toFixed(2);
      console.log(`[Backup] ${deletedCount}개의 오래된 백업 파일 삭제 (${freedSpaceMB} MB 해제)\n`);
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : '알 수 없는 오류';
    console.error('[Backup] 백업 정리 실패:', errorMessage);
  }
}

/**
 * 메인 함수
 */
async function main() {
  try {
    const outputDir = process.env.BACKUP_DIR || path.join(process.cwd(), 'backups');
    const keepDays = parseInt(process.env.BACKUP_KEEP_DAYS || '7', 10);

    // 백업 실행
    const result = await backupProductionDatabase();

    // 오래된 백업 정리
    cleanupOldBackups(outputDir, keepDays);

    console.log('========================================');
    console.log('✅ 백업 완료!');
    console.log('========================================');
    console.log(`백업 파일: ${result.path}`);
    console.log(`파일 크기: ${(result.size / (1024 * 1024)).toFixed(2)} MB`);
    if (result.originalSize !== result.size) {
      console.log(`원본 크기: ${(result.originalSize / (1024 * 1024)).toFixed(2)} MB`);
    }
    console.log('========================================\n');

    console.log('💡 다음 단계:');
    console.log('1. 백업 파일을 안전한 위치에 복사하세요');
    console.log('2. 백업 파일이 제대로 생성되었는지 확인하세요');
    console.log('3. 마이그레이션을 진행하세요: npm run migrate-2fa-safe\n');

    process.exit(0);
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : '알 수 없는 오류';
    console.error('========================================');
    console.error('❌ 백업 실패:', errorMessage);
    console.error('========================================\n');
    console.error('⚠️  마이그레이션을 진행하기 전에 백업이 필요합니다!');
    console.error('   수동으로 백업을 실행하거나 문제를 해결한 후 다시 시도하세요.\n');
    process.exit(1);
  }
}

// 스크립트 직접 실행 시
if (require.main === module) {
  main();
}

export { backupProductionDatabase, cleanupOldBackups };

