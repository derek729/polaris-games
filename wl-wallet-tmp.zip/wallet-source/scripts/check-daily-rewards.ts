/**
 * 일일 수익 지급 문제 진단 스크립트
 * 
 * 이 스크립트는 다음을 확인합니다:
 * 1. 활성 투자 건 수
 * 2. 최근 일일 수익 지급 내역
 * 3. 스케줄러 실행 상태
 * 4. 지급되지 않은 투자 건 확인
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkDailyRewards() {
  try {
    console.log('='.repeat(60));
    console.log('일일 수익 지급 문제 진단');
    console.log('='.repeat(60));
    console.log('');

    // 1. 활성 투자 건 확인
    console.log('1️⃣ 활성 투자 건 확인');
    console.log('-'.repeat(60));
    
    const activeInvestments = await prisma.investments.findMany({
      where: { isActive: true },
      include: {
        users: {
          select: {
            id: true,
            username: true,
            email: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    console.log(`   총 활성 투자 건: ${activeInvestments.length}건`);
    
    if (activeInvestments.length === 0) {
      console.log('   ⚠️  활성 투자 건이 없습니다. 일일 수익을 지급할 투자가 없습니다.');
    } else {
      console.log('');
      console.log('   투자 건 상세:');
      let totalAmount = 0;
      for (const inv of activeInvestments.slice(0, 10)) {
        const amount = Number(inv.amount);
        const dailyRate = Number(inv.dailyRate);
        const dailyProfit = amount * dailyRate;
        totalAmount += amount;
        
        console.log(`   - ${inv.users.username || inv.users.email || inv.userId}`);
        console.log(`     투자금: $${amount.toFixed(2)}, 일일 수익률: ${(dailyRate * 100).toFixed(2)}%, 일일 수익: $${dailyProfit.toFixed(2)}`);
      }
      
      if (activeInvestments.length > 10) {
        console.log(`   ... 외 ${activeInvestments.length - 10}건`);
      }
      
      console.log('');
      console.log(`   총 투자금: $${totalAmount.toFixed(2)}`);
    }
    console.log('');

    // 2. 최근 일일 수익 지급 내역 확인
    console.log('2️⃣ 최근 일일 수익 지급 내역');
    console.log('-'.repeat(60));

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    // 오늘 지급 내역
    const todayRewards = await prisma.reward_logs.findMany({
      where: {
        type: 'DAILY',
        isPaid: true,
        createdAt: { gte: today },
      },
      include: {
        users: {
          select: {
            username: true,
            email: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // 어제 지급 내역
    const yesterdayRewards = await prisma.reward_logs.findMany({
      where: {
        type: 'DAILY',
        isPaid: true,
        createdAt: {
          gte: yesterday,
          lt: today,
        },
      },
      include: {
        users: {
          select: {
            username: true,
            email: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    console.log(`   오늘 지급 건수: ${todayRewards.length}건`);
    if (todayRewards.length > 0) {
      const todayTotal = todayRewards.reduce((sum, r) => sum + Number(r.amount), 0);
      console.log(`   오늘 지급 총액: $${todayTotal.toFixed(2)}`);
      console.log('');
      console.log('   최근 5건:');
      todayRewards.slice(0, 5).forEach((reward, index) => {
        console.log(`   ${index + 1}. ${reward.users.username || reward.users.email || reward.userId}: $${Number(reward.amount).toFixed(2)} (${reward.createdAt.toLocaleString('ko-KR')})`);
      });
    } else {
      console.log('   ⚠️  오늘 일일 수익이 지급되지 않았습니다.');
    }

    console.log('');
    console.log(`   어제 지급 건수: ${yesterdayRewards.length}건`);
    if (yesterdayRewards.length > 0) {
      const yesterdayTotal = yesterdayRewards.reduce((sum, r) => sum + Number(r.amount), 0);
      console.log(`   어제 지급 총액: $${yesterdayTotal.toFixed(2)}`);
    } else {
      console.log('   ⚠️  어제 일일 수익이 지급되지 않았습니다.');
    }
    console.log('');

    // 3. 지급되지 않은 투자 건 확인
    console.log('3️⃣ 지급되지 않은 투자 건 확인');
    console.log('-'.repeat(60));

    // unpaidInvestments 변수를 블록 밖에서 초기화
    let unpaidInvestments: typeof activeInvestments = [];

    if (activeInvestments.length > 0) {
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);

      // 오늘 지급된 투자 ID 목록
      const paidInvestmentIds = new Set(
        todayRewards
          .map((r) => r.sourceInvestmentId)
          .filter((id): id is string => id !== null)
      );

      unpaidInvestments = activeInvestments.filter(
        (inv) => !paidInvestmentIds.has(inv.id)
      );

      console.log(`   오늘 지급되지 않은 투자 건: ${unpaidInvestments.length}건`);
      
      if (unpaidInvestments.length > 0) {
        console.log('');
        console.log('   지급되지 않은 투자 건 목록:');
        unpaidInvestments.slice(0, 10).forEach((inv, index) => {
          const amount = Number(inv.amount);
          const dailyRate = Number(inv.dailyRate);
          const dailyProfit = amount * dailyRate;
          console.log(`   ${index + 1}. ${inv.users.username || inv.users.email || inv.userId}`);
          console.log(`      투자 ID: ${inv.id}`);
          console.log(`      투자금: $${amount.toFixed(2)}, 예상 일일 수익: $${dailyProfit.toFixed(2)}`);
          console.log(`      투자 시작일: ${inv.startDate.toLocaleString('ko-KR')}`);
        });
        
        if (unpaidInvestments.length > 10) {
          console.log(`   ... 외 ${unpaidInvestments.length - 10}건`);
        }
      } else {
        console.log('   ✅ 모든 활성 투자 건에 대해 오늘 일일 수익이 지급되었습니다.');
      }
    }
    console.log('');

    // 4. 자동 모드 상태 확인
    console.log('4️⃣ 자동 모드 상태 확인');
    console.log('-'.repeat(60));

    const autoModeSetting = await prisma.system_settings.findUnique({
      where: { key: 'autoSettlementEnabled' },
    });

    const isAutoModeEnabled = autoModeSetting?.value === 'true';
    console.log(`   자동 모드: ${isAutoModeEnabled ? '✅ 활성화' : '❌ 비활성화'}`);
    console.log('');

    // 5. 결론 및 권장 사항
    console.log('5️⃣ 결론 및 권장 사항');
    console.log('-'.repeat(60));

    if (activeInvestments.length === 0) {
      console.log('   ⚠️  활성 투자 건이 없어 일일 수익을 지급할 수 없습니다.');
      console.log('   💡 투자가 활성화되어 있는지 확인하세요.');
    } else if (todayRewards.length === 0) {
      console.log('   ❌ 오늘 일일 수익이 지급되지 않았습니다.');
      console.log('');
      console.log('   가능한 원인:');
      console.log('   1. 스케줄러가 실행되지 않았을 수 있습니다.');
      console.log('   2. 자동 모드가 비활성화되어 있을 수 있습니다.');
      console.log('   3. 서버가 자정 시간에 재시작되었거나 다운되었을 수 있습니다.');
      console.log('   4. 데이터베이스 연결 오류가 발생했을 수 있습니다.');
      console.log('');
      console.log('   권장 조치:');
      console.log('   1. 관리자 페이지에서 수동으로 마감을 실행하세요.');
      console.log('   2. Railway 로그에서 자정 시간대의 에러를 확인하세요.');
      console.log('   3. 자동 모드가 활성화되어 있는지 확인하세요.');
    } else if (unpaidInvestments.length > 0) {
      console.log('   ⚠️  일부 투자 건에 대해 일일 수익이 지급되지 않았습니다.');
      console.log(`   - 지급됨: ${activeInvestments.length - unpaidInvestments.length}건`);
      console.log(`   - 미지급: ${unpaidInvestments.length}건`);
      console.log('');
      console.log('   권장 조치:');
      console.log('   1. 관리자 페이지에서 수동으로 마감을 다시 실행하세요.');
      console.log('   2. Railway 로그에서 에러를 확인하세요.');
    } else {
      console.log('   ✅ 일일 수익 지급이 정상적으로 작동하고 있습니다.');
      console.log(`   - 오늘 ${todayRewards.length}건의 일일 수익이 지급되었습니다.`);
    }

    console.log('');
    console.log('='.repeat(60));
    console.log('진단 완료');
    console.log('='.repeat(60));
  } catch (error: any) {
    console.error('❌ 진단 중 오류 발생:', error);
    console.error(error.stack);
  } finally {
    await prisma.$disconnect();
  }
}

// 스크립트 실행
checkDailyRewards();

