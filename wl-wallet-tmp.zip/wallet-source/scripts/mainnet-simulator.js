/**
 * AO 코인 메인넷 노드 시뮬레이터
 * 개발 및 테스트용 메인넷 API 서버
 */

const express = require('express');
const crypto = require('crypto');
const cors = require('cors');

const app = express();
const PORT = process.env.MAINNET_PORT || 8334;
const HOST = process.env.MAINNET_HOST || 'localhost';

app.use(cors());
app.use(express.json());

// 메모리 저장소 (실제로는 데이터베이스 사용)
let wallets = new Map();
let transactions = new Map();
let blocks = [];
let blockchainState = {
  height: 0,
  difficulty: 1,
  blockReward: 50,
  totalSupply: 21000000,
  isMining: false,
  minerAddress: null,
  hashrate: 0
};

// 초기 제네시스 블록 생성
const genesisBlock = {
  hash: '000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f',
  previousHash: '0'.repeat(64),
  timestamp: Date.now(),
  height: 0,
  transactions: [],
  nonce: 0
};

blocks.push(genesisBlock);

/**
 * 지갑 생성 함수
 */
function createWallet() {
  const privateKey = crypto.randomBytes(32).toString('hex');
  // 간단한 퍼블릭 키 시뮬레이션 (실제로는 타원곡선 암호화 사용)
  const publicKeyHash = crypto.createHash('sha256').update(privateKey).digest('hex');
  const address = `AO${publicKeyHash.substring(0, 28).toUpperCase()}`;

  wallets.set(address, {
    address,
    publicKey: publicKeyHash,
    privateKey,
    balance: 0,
    nonce: 0,
    createdAt: new Date().toISOString()
  });

  return {
    address,
    publicKey: publicKeyHash,
    privateKey
  };
}

/**
 * 트랜잭션 생성 함수
 */
function createTransaction(from, to, amount) {
  const txHash = crypto.createHash('sha256')
    .update(`${from}${to}${amount}${Date.now()}`)
    .digest('hex');

  const transaction = {
    hash: txHash,
    from,
    to,
    amount,
    timestamp: Date.now(),
    status: 'PENDING',
    blockHeight: null,
    confirmations: 0,
    gasFee: 0.001
  };

  transactions.set(txHash, transaction);
  return transaction;
}

/**
 * 블록 생성 함수
 */
function createBlock(transactions) {
  const previousBlock = blocks[blocks.length - 1];
  const timestamp = Date.now();
  let nonce = 0;
  let hash;

  // 간단한 Proof of Work 시뮬레이션
  do {
    const blockData = JSON.stringify({
      height: blockchainState.height + 1,
      previousHash: previousBlock.hash,
      transactions: transactions.map(tx => tx.hash),
      timestamp,
      nonce
    });
    hash = crypto.createHash('sha256').update(blockData).digest('hex');
    nonce++;
  } while (!hash.startsWith('0000')); // 난이도 4

  const block = {
    hash,
    previousHash: previousBlock.hash,
    timestamp,
    height: blockchainState.height + 1,
    transactions: transactions.map(tx => tx.hash),
    nonce: nonce - 1
  };

  // 트랜잭션 상태 업데이트
  transactions.forEach(tx => {
    tx.status = 'CONFIRMED';
    tx.blockHeight = block.height;
    tx.confirmations = 1;
  });

  // 블록체인 상태 업데이트
  blockchainState.height++;
  blocks.push(block);

  return block;
}

/**
 * 지갑 잔액 확인
 */
function getBalance(address) {
  const wallet = wallets.get(address);
  if (!wallet) return 0;

  let balance = wallet.balance;

  // 트랜잭션에서 잔액 계산
  transactions.forEach(tx => {
    if (tx.status === 'CONFIRMED') {
      if (tx.to === address) {
        balance += tx.amount;
      }
      if (tx.from === address) {
        balance -= (tx.amount + tx.gasFee);
      }
    }
  });

  return balance;
}

// API 라우트

/**
 * 블록체인 정보 조회
 */
app.get('/api/blockchain/info', (req, res) => {
  res.json({
    success: true,
    data: {
      height: blockchainState.height,
      difficulty: blockchainState.difficulty,
      blockReward: blockchainState.blockReward,
      totalSupply: blockchainState.totalSupply,
      lastBlockHash: blocks[blocks.length - 1]?.hash || null,
      timestamp: Date.now()
    }
  });
});

/**
 * 채굴 상태 조회
 */
app.get('/api/mining/status', (req, res) => {
  res.json({
    success: true,
    data: {
      mining: blockchainState.isMining,
      blocksMined: blockchainState.height,
      minerAddress: blockchainState.minerAddress,
      hashrate: blockchainState.hashrate
    }
  });
});

/**
 * 채굴 시작
 */
app.post('/api/mining/start', (req, res) => {
  const { minerAddress } = req.body;

  if (!minerAddress || !wallets.has(minerAddress)) {
    return res.json({
      success: false,
      error: '유효한 지갑 주소가 필요합니다.'
    });
  }

  blockchainState.isMining = true;
  blockchainState.minerAddress = minerAddress;
  blockchainState.hashrate = Math.floor(Math.random() * 1000) + 100;

  // 시뮬레이션된 채굴 보상 트랜잭션 생성
  const miningTx = createTransaction('COINBASE', minerAddress, blockchainState.blockReward);
  const newBlock = createBlock([miningTx]);

  console.log(`⛏️ 블록 채굴 완료: #${newBlock.height}, 해시: ${newBlock.hash}`);

  res.json({
    success: true,
    data: `채굴 시작됨. 블록 #${newBlock.height} 생성됨.`
  });
});

/**
 * 채굴 중지
 */
app.post('/api/mining/stop', (req, res) => {
  blockchainState.isMining = false;
  blockchainState.minerAddress = null;
  blockchainState.hashrate = 0;

  res.json({
    success: true,
    data: '채굴 중지됨.'
  });
});

/**
 * 지갑 생성
 */
app.post('/api/wallet/new', (req, res) => {
  try {
    const wallet = createWallet();
    console.log(`🔑 새 지갑 생성: ${wallet.address}`);

    res.json({
      success: true,
      data: wallet
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message
    });
  }
});

/**
 * 지갑 잔액 조회
 */
app.get('/api/wallet/balance/:address', (req, res) => {
  const { address } = req.params;
  const balance = getBalance(address);

  res.json({
    success: true,
    data: {
      balance,
      address
    }
  });
});

/**
 * 트랜잭션 전송
 */
app.post('/api/transaction/send', (req, res) => {
  try {
    const { from, to, amount } = req.body;

    // 기본 검증
    if (!from || !to || !amount) {
      return res.json({
        success: false,
        error: '필수 파라미터가 누락되었습니다.'
      });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.json({
        success: false,
        error: '유효하지 않은 금액입니다.'
      });
    }

    const senderBalance = getBalance(from);
    const gasFee = 0.001;
    const totalDeduct = numAmount + gasFee;

    if (senderBalance < totalDeduct) {
      return res.json({
        success: false,
        error: `잔고가 부족합니다. (보유: ${senderBalance}, 필요: ${totalDeduct})`
      });
    }

    // 트랜잭션 생성 및 블록에 포함
    const transaction = createTransaction(from, to, numAmount);
    const block = createBlock([transaction]);

    console.log(`💸 트랜잭션 전송: ${from} → ${to}, 금액: ${numAmount} AO`);

    res.json({
      success: true,
      data: {
        txId: transaction.hash,
        txHash: transaction.hash,
        blockNumber: block.height,
        confirmations: 1,
        gasFee,
        blockHash: block.hash
      }
    });

  } catch (error) {
    res.json({
      success: false,
      error: error.message
    });
  }
});

/**
 * 블록 정보 조회
 */
app.get('/api/blockchain/block/:hash', (req, res) => {
  const { hash } = req.params;
  const block = blocks.find(b => b.hash === hash);

  if (!block) {
    return res.json({
      success: false,
      error: '블록을 찾을 수 없습니다.'
    });
  }

  res.json({
    success: true,
    data: block
  });
});

/**
 * 전체 블록 목록 조회
 */
app.get('/api/blockchain/blocks', (req, res) => {
  res.json({
    success: true,
    data: blocks.reverse().slice(0, 50) // 최근 50개 블록
  });
});

/**
 * 트랜잭션 정보 조회
 */
app.get('/api/transaction/:hash', (req, res) => {
  const { hash } = req.params;
  const transaction = transactions.get(hash);

  if (!transaction) {
    return res.json({
      success: false,
      error: '트랜잭션을 찾을 수 없습니다.'
    });
  }

  // 컨펌 수 계산
  if (transaction.status === 'CONFIRMED' && transaction.blockHeight) {
    transaction.confirmations = blockchainState.height - transaction.blockHeight + 1;
  }

  res.json({
    success: true,
    data: transaction
  });
});

/**
 * 헬스 체크
 */
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    data: {
      status: 'running',
      uptime: process.uptime(),
      timestamp: Date.now(),
      blockchainHeight: blockchainState.height,
      walletCount: wallets.size,
      transactionCount: transactions.size
    }
  });
});

// 서버 시작
app.listen(PORT, HOST, () => {
  console.log(`🚀 AO 코인 메인넷 시뮬레이터 시작`);
  console.log(`📍 서버 주소: http://${HOST}:${PORT}`);
  console.log(`📊 블록체인 상태: 높이 ${blockchainState.height}`);
  console.log(`🔑 생성된 지갑: ${wallets.size}개`);
  console.log(`📝 트랜잭션: ${transactions.size}개`);

  // 테스트용 지갑 생성
  const testWallet1 = createWallet();
  const testWallet2 = createWallet();

  // 초기 잔액 설정
  wallets.get(testWallet1.address).balance = 1000;

  console.log(`🧪 테스트 지갑 1: ${testWallet1.address} (잔액: 1000 AO)`);
  console.log(`🧪 테스트 지갑 2: ${testWallet2.address} (잔액: 0 AO)`);
});

module.exports = app;