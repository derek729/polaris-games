const { Client } = require('pg');

async function createTables() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL || 'postgresql://user:password@localhost:5432/dbname'
  });

  try {
    console.log('Railway PostgreSQL에 연결 중...');
    await client.connect();
    console.log('✅ 연결 성공!');

    // 테이블 생성 SQL
    const tables = `
      -- Jackpot 시스템
      CREATE TABLE IF NOT EXISTS jackpots (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        game_id TEXT,
        type VARCHAR(20) DEFAULT 'GLOBAL',
        current_amount DECIMAL(18, 8) DEFAULT 0,
        seed_amount DECIMAL(18, 8) DEFAULT 0,
        contribution_rate DECIMAL(5, 4) DEFAULT 0.05,
        last_won_at TIMESTAMP,
        last_won_amount DECIMAL(18, 8),
        last_won_by TEXT,
        is_active BOOLEAN DEFAULT true,
        auto_win_enabled BOOLEAN DEFAULT true,
        base_win_probability DECIMAL(10, 8) DEFAULT 0.0001,
        cumulative_plays BIGINT DEFAULT 0,
        last_auto_win_check_at TIMESTAMP,
        min_games_between_wins INT DEFAULT 1000,
        max_days_between_wins INT DEFAULT 30,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS jackpot_wins (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        jackpot_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        amount DECIMAL(18, 8) NOT NULL,
        won_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        metadata JSONB
      );

      CREATE TABLE IF NOT EXISTS auto_win_logs (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        jackpot_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        win_amount DECIMAL(18, 8) NOT NULL,
        trigger_reason VARCHAR(255),
        metadata JSONB,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS jackpot_play_trackers (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        jackpot_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        play_count INT DEFAULT 0,
        last_played_at TIMESTAMP,
        total_bet_amount DECIMAL(18, 8) DEFAULT 0,
        metadata JSONB,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS game_loss_distributions (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id TEXT NOT NULL,
        game_id TEXT NOT NULL,
        loss_amount DECIMAL(18, 8) NOT NULL,
        jackpot_amount DECIMAL(18, 8) NOT NULL,
        foundation_amount DECIMAL(18, 8) NOT NULL,
        node_pool_amount DECIMAL(18, 8) NOT NULL,
        played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        metadata JSONB
      );

      CREATE TABLE IF NOT EXISTS node_revenue_pools (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        total_amount DECIMAL(18, 8) DEFAULT 0,
        distributed_amount DECIMAL(18, 8) DEFAULT 0,
        pending_amount DECIMAL(18, 8) DEFAULT 0,
        last_distributed_at TIMESTAMP,
        period_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        period_end TIMESTAMP,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS node_revenue_distributions (
        id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        pool_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        total_pool_amount DECIMAL(18, 8) NOT NULL,
        distributed_amount DECIMAL(18, 8) NOT NULL,
        distribution_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        is_paid BOOLEAN DEFAULT false,
        paid_at TIMESTAMP,
        metadata JSONB,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;

    // 각 테이블 생성
    await client.query(tables);

    console.log('✅ 모든 테이블 생성 완료!');

    // 테이블 확인
    const result = await client.query(`
      SELECT table_name
      FROM information_schema.tables
      WHERE table_schema = 'public'
        AND table_name IN (
          'jackpots',
          'jackpot_wins',
          'auto_win_logs',
          'jackpot_play_trackers',
          'game_loss_distributions',
          'node_revenue_pools',
          'node_revenue_distributions'
        )
      `);

    console.log('생성된 테이블:');
    result.rows.forEach(row => {
      console.log(`  ✓ ${row.table_name}`);
    });

  } catch (error) {
    console.error('❌ 오류:', error.message);
    process.exit(1);
  } finally {
    await client.end();
    console.log('연결 종료');
  }
}

createTables();
