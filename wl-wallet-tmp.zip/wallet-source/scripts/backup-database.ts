/**
 * 데이터베이스 자동 백업 스크립트
 * PostgreSQL 데이터베이스를 백업하고 관리합니다.
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';

const execAsync = promisify(exec);

interface BackupOptions {
  outputDir?: string;
  keepDays?: number;
  compress?: boolean;
}

/**
 * DATABASE_URL에서 연결 정보 파싱
 */
function parseDatabaseUrl(databaseUrl: string): {
  host: string;
  port: string;
  database: string;
  users: string;
  password: string;
} {
  // postgresql://user:password@host:port/database 형식
  const url = new URL(databaseUrl);
  return {
    host: url.hostname,
    port: url.port || '5432',
    database: url.pathname.slice(1), // 첫 번째 '/' 제거
    users: url.username,
    password: url.password,
  };
}

/**
 * 데이터베이스 백업 실행
 */
async function backupDatabase(options: BackupOptions = {}) {
  try {
    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) {
      throw new Error('DATABASE_URL 환경 변수가 설정되지 않았습니다.');
    }

    const dbInfo = parseDatabaseUrl(databaseUrl);
    const outputDir = options.outputDir || path.join(process.cwd(), 'backups');
    const keepDays = options.keepDays || 7;
    const compress = options.compress !== false; // 기본값 true

    // 백업 디렉토리 생성
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
      console.log(`[Backup] 백업 디렉토리 생성: ${outputDir}`);
    }

    // 타임스탬프 생성
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    const backupFileName = `backup-${dbInfo.database}-${timestamp}.sql`;
    const backupPath = path.join(outputDir, backupFileName);
    const compressedPath = `${backupPath}.gz`;

    console.log('[Backup] 데이터베이스 백업 시작...');
    console.log(`[Backup] 데이터베이스: ${dbInfo.database}`);
    console.log(`[Backup] 호스트: ${dbInfo.host}:${dbInfo.port}`);

    // pg_dump 명령어 구성
    const pgDumpCmd = [
      'pg_dump',
      `--host=${dbInfo.host}`,
      `--port=${dbInfo.port}`,
      `--username=${dbInfo.users}`,
      `--dbname=${dbInfo.database}`,
      '--no-password', // PGPASSWORD 환경 변수 사용
      '--verbose',
      '--clean', // DROP 문 포함
      '--if-exists', // IF EXISTS 사용
      '--format=plain', // SQL 형식
      `--file=${backupPath}`,
    ].join(' ');

    // 환경 변수 설정
    const env = {
      ...process.env,
      PGPASSWORD: dbInfo.password,
    };

    // 백업 실행
    console.log('[Backup] pg_dump 실행 중...');
    const { stdout, stderr } = await execAsync(pgDumpCmd, { env });

    if (stderr && !stderr.includes('NOTICE')) {
      console.warn('[Backup] 경고:', stderr);
    }

    // 파일 크기 확인
    const stats = fs.statSync(backupPath);
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    console.log(`[Backup] 백업 파일 생성 완료: ${backupFileName} (${fileSizeMB} MB)`);

    // 압축 (선택사항)
    if (compress) {
      console.log('[Backup] 백업 파일 압축 중...');
      await execAsync(`gzip ${backupPath}`, { env: process.env });
      const compressedStats = fs.statSync(compressedPath);
      const compressedSizeMB = (compressedStats.size / (1024 * 1024)).toFixed(2);
      console.log(`[Backup] 압축 완료: ${compressedPath} (${compressedSizeMB} MB)`);
      return { path: compressedPath, size: compressedStats.size };
    }

    return { path: backupPath, size: stats.size };
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : '알 수 없는 오류';
    console.error('[Backup] 백업 실패:', errorMessage);
    throw error;
  }
}

/**
 * 오래된 백업 파일 삭제
 */
function cleanupOldBackups(outputDir: string, keepDays: number) {
  try {
    if (!fs.existsSync(outputDir)) {
      return;
    }

    const files = fs.readdirSync(outputDir);
    const now = Date.now();
    const keepTime = keepDays * 24 * 60 * 60 * 1000; // 밀리초로 변환

    let deletedCount = 0;
    let freedSpace = 0;

    for (const file of files) {
      if (!file.startsWith('backup-') || (!file.endsWith('.sql') && !file.endsWith('.sql.gz'))) {
        continue;
      }

      const filePath = path.join(outputDir, file);
      const stats = fs.statSync(filePath);
      const fileAge = now - stats.mtimeMs;

      if (fileAge > keepTime) {
        freedSpace += stats.size;
        fs.unlinkSync(filePath);
        deletedCount++;
        console.log(`[Backup] 오래된 백업 파일 삭제: ${file}`);
      }
    }

    if (deletedCount > 0) {
      const freedSpaceMB = (freedSpace / (1024 * 1024)).toFixed(2);
      console.log(`[Backup] ${deletedCount}개의 오래된 백업 파일 삭제 (${freedSpaceMB} MB 해제)`);
    }
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : '알 수 없는 오류';
    console.error('[Backup] 백업 정리 실패:', errorMessage);
  }
}

/**
 * 메인 함수
 */
async function main() {
  try {
    const args = process.argv.slice(2);
    const options: BackupOptions = {
      outputDir: process.env.BACKUP_DIR,
      keepDays: parseInt(process.env.BACKUP_KEEP_DAYS || '7', 10),
      compress: process.env.BACKUP_COMPRESS !== 'false',
    };

    // 커맨드라인 인자 파싱
    for (let i = 0; i < args.length; i++) {
      if (args[i] === '--output-dir' && args[i + 1]) {
        options.outputDir = args[i + 1];
        i++;
      } else if (args[i] === '--keep-days' && args[i + 1]) {
        options.keepDays = parseInt(args[i + 1], 10);
        i++;
      } else if (args[i] === '--no-compress') {
        options.compress = false;
      }
    }

    console.log('========================================');
    console.log('데이터베이스 백업 시작');
    console.log('========================================');

    // 백업 실행
    const result = await backupDatabase(options);

    // 오래된 백업 정리
    if (options.outputDir) {
      cleanupOldBackups(options.outputDir, options.keepDays || 7);
    }

    console.log('========================================');
    console.log('백업 완료!');
    console.log(`백업 파일: ${result.path}`);
    console.log(`파일 크기: ${(result.size / (1024 * 1024)).toFixed(2)} MB`);
    console.log('========================================');

    process.exit(0);
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : '알 수 없는 오류';
    console.error('========================================');
    console.error('백업 실패:', errorMessage);
    console.error('========================================');
    process.exit(1);
  }
}

// 스크립트 직접 실행 시
if (require.main === module) {
  main();
}

export { backupDatabase, cleanupOldBackups };

