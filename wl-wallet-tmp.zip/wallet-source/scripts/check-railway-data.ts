/**
 * Railway 데이터베이스 데이터 확인 스크립트
 * 
 * 사용 방법:
 * railway run npx tsx scripts/check-railway-data.ts 2024-12-11
 */

import { PrismaClient } from '@prisma/client';
import { RewardType } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const args = process.argv.slice(2);
  const dateStr = args[0] || new Date().toISOString().split('T')[0];

  console.log(`📊 ${dateStr} 데이터 확인\n`);

  const target = new Date(dateStr);
  target.setHours(0, 0, 0, 0);
  
  const targetEnd = new Date(target);
  targetEnd.setHours(23, 59, 59, 999);

  // 활성 투자 건 조회
  const investments = await prisma.investments.findMany({
    where: {
      isActive: true,
      startDate: { lte: targetEnd },
      endDate: { gte: target },
    },
    include: { users: true },
    take: 20,
  });

  const totalInvestments = await prisma.investments.count({
    where: {
      isActive: true,
      startDate: { lte: targetEnd },
      endDate: { gte: target },
    },
  });

  // 기존 지급 내역 조회
  const existingRewards = await prisma.reward_logs.findMany({
    where: {
      type: RewardType.DAILY,
      createdAt: {
        gte: target,
        lte: targetEnd,
      },
      isPaid: true,
    },
    include: { users: true },
    take: 20,
  });

  const totalRewards = await prisma.reward_logs.count({
    where: {
      type: RewardType.DAILY,
      createdAt: {
        gte: target,
        lte: targetEnd,
      },
      isPaid: true,
    },
  });

  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('📈 활성 투자 건');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`총 건수: ${totalInvestments}건\n`);

  if (investments.length > 0) {
    console.log('샘플 (최대 20건):');
    investments.forEach((inv, index) => {
      console.log(`\n${index + 1}. ID: ${inv.id}`);
      console.log(`   사용자: ${inv.users.username || inv.userId}`);
      console.log(`   금액: ${inv.amount} USDT`);
      console.log(`   일일 수익률: ${inv.dailyRate} (${(Number(inv.dailyRate) * 100).toFixed(2)}%)`);
      console.log(`   시작일: ${inv.startDate.toISOString().split('T')[0]}`);
      console.log(`   종료일: ${inv.endDate.toISOString().split('T')[0]}`);
      console.log(`   활성: ${inv.isActive ? '예' : '아니오'}`);
    });
  } else {
    console.log('⚠️  활성 투자 건이 없습니다.');
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('💰 기존 지급 내역');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`총 건수: ${totalRewards}건\n`);

  if (existingRewards.length > 0) {
    console.log('샘플 (최대 20건):');
    existingRewards.forEach((reward, index) => {
      console.log(`\n${index + 1}. ID: ${reward.id}`);
      console.log(`   사용자: ${reward.users.username || reward.userId}`);
      console.log(`   금액: ${reward.amount} USDT`);
      console.log(`   투자 ID: ${reward.sourceInvestmentId || 'N/A'}`);
      console.log(`   생성일: ${reward.createdAt.toISOString()}`);
      console.log(`   설명: ${reward.description || 'N/A'}`);
    });
  } else {
    console.log('⚠️  기존 지급 내역이 없습니다.');
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  // 날짜 범위 확인
  console.log('📅 날짜 범위 확인:');
  console.log(`   시작: ${target.toISOString()}`);
  console.log(`   종료: ${targetEnd.toISOString()}\n`);

  // 전체 활성 투자 건 확인 (날짜 무관)
  const allActiveInvestments = await prisma.investments.count({
    where: { isActive: true },
  });

  console.log(`📊 전체 활성 투자 건 (날짜 무관): ${allActiveInvestments}건\n`);

  await prisma.$disconnect();
}

main()
  .catch((error) => {
    console.error('❌ 오류 발생:', error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

