import * as fs from 'fs';
import * as path from 'path';
import * as readline from 'readline';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(query: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(query, resolve);
  });
}

async function main() {
  console.log('🚀 새 프로젝트 템플릿 생성 도구');
  console.log('=====================================\n');

  try {
    // 사용자 입력 받기
    const companyName = await question('상호명을 입력하세요 (예: ABC Coin Foundation): ');
    if (!companyName.trim()) {
      console.log('❌ 상호명은 필수입니다.');
      process.exit(1);
    }

    const symbolName = await question('코인 심볼명을 입력하세요 (예: ABC): ');
    if (!symbolName.trim()) {
      console.log('❌ 심볼명은 필수입니다.');
      process.exit(1);
    }

    const totalSupply = await question('총 발행량을 입력하세요 (예: 1000000000): ');
    if (!totalSupply.trim() || !/^\d+$/.test(totalSupply)) {
      console.log('❌ 총 발행량은 숫자여야 합니다.');
      process.exit(1);
    }

    const symbolNameUpper = symbolName.toUpperCase();
    const symbolNameLower = symbolName.toLowerCase();
    const projectName = symbolNameLower + 'wallet';

    // 소스 디렉토리와 타겟 디렉토리
    const sourceDir = process.cwd();
    const targetDir = path.join('D:', 'OEM', 'new', projectName);

    console.log('\n📋 프로젝트 정보:');
    console.log(`   상호명: ${companyName}`);
    console.log(`   심볼명: ${symbolNameUpper}`);
    console.log(`   총 발행량: ${parseInt(totalSupply).toLocaleString()}개`);
    console.log(`   프로젝트명: ${projectName}`);
    console.log(`   타겟 디렉토리: ${targetDir}\n`);

    const confirm = await question('위 정보로 프로젝트를 생성하시겠습니까? (y/N): ');
    if (confirm.toLowerCase() !== 'y') {
      console.log('취소되었습니다.');
      process.exit(0);
    }

    // 타겟 디렉토리 생성
    if (fs.existsSync(targetDir)) {
      const overwrite = await question(`\n⚠️  디렉토리가 이미 존재합니다. 덮어쓰시겠습니까? (y/N): `);
      if (overwrite.toLowerCase() !== 'y') {
        console.log('취소되었습니다.');
        process.exit(0);
      }
      console.log('🗑️  기존 디렉토리 삭제 중...');
      fs.rmSync(targetDir, { recursive: true, force: true });
    }

    console.log('\n📁 프로젝트 복사 중...');
    copyDirectory(sourceDir, targetDir, [
      'node_modules',
      '.next',
      'out',
      'build',
      '.git',
      'dist',
      'coverage',
      '.env',
      '.env.local',
      '.env.*.local',
      '*.log',
      'tsconfig.tsbuildinfo',
      'temp_*',
      'KakaoTalk_*',
      'backup',
      'Newbie',
      '보너스',
    ]);

    console.log('🔄 파일 내용 변경 중...');
    replaceInFiles(targetDir, {
      'UPC': symbolNameUpper,
      'upc': symbolNameLower,
      'UPC Coin Foundation': companyName,
      'UPC Foundation': companyName.replace(/Coin Foundation/i, 'Foundation'),
      '10000000000': totalSupply,
      '100억개': formatSupply(totalSupply),
      'upcwallet': projectName,
      'UOC GROUP': companyName.split(' ')[0].toUpperCase() + ' GROUP',
    });

    // package.json 수정
    const packageJsonPath = path.join(targetDir, 'package.json');
    if (fs.existsSync(packageJsonPath)) {
      const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
      packageJson.name = projectName;
      fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2) + '\n');
    }

    console.log('\n✅ 프로젝트 템플릿이 생성되었습니다!');
    console.log(`   위치: ${targetDir}`);
    console.log('\n📝 다음 단계:');
    console.log(`   1. cd ${targetDir}`);
    console.log('   2. npm install');
    console.log('   3. .env 파일 생성 및 DATABASE_URL 설정');
    console.log('   4. npx prisma db push');
    console.log('   5. npm run dev');
  } catch (error) {
    console.error('\n❌ 오류 발생:', error);
    process.exit(1);
  } finally {
    rl.close();
  }
}

function copyDirectory(src: string, dest: string, ignoreList: string[] = []) {
  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }

  const entries = fs.readdirSync(src, { withFileTypes: true });

  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    // 무시할 항목 체크
    if (ignoreList.some(pattern => {
      if (pattern.includes('*')) {
        const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
        return regex.test(entry.name);
      }
      return entry.name === pattern;
    })) {
      continue;
    }

    if (entry.isDirectory()) {
      copyDirectory(srcPath, destPath, ignoreList);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function replaceInFiles(dir: string, replacements: Record<string, string>, fileExtensions: string[] = ['.ts', '.tsx', '.js', '.jsx', '.json', '.md', '.html', '.css', '.prisma']) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);

    // .git 디렉토리 무시
    if (entry.name === '.git') {
      continue;
    }

    if (entry.isDirectory()) {
      replaceInFiles(fullPath, replacements, fileExtensions);
    } else {
      const ext = path.extname(entry.name);
      if (fileExtensions.includes(ext) || fileExtensions.length === 0) {
        try {
          let content = fs.readFileSync(fullPath, 'utf-8');
          let modified = false;

          for (const [search, replace] of Object.entries(replacements)) {
            if (content.includes(search)) {
              content = content.replace(new RegExp(search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), replace);
              modified = true;
            }
          }

          if (modified) {
            fs.writeFileSync(fullPath, content, 'utf-8');
          }
        } catch (error) {
          // 바이너리 파일 등은 무시
        }
      }
    }
  }
}

function formatSupply(supply: string): string {
  const num = parseInt(supply);
  if (num >= 100000000) {
    return `${(num / 100000000).toFixed(0)}억개`;
  } else if (num >= 10000) {
    return `${(num / 10000).toFixed(0)}만개`;
  }
  return `${num.toLocaleString()}개`;
}

main();

