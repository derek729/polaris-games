/**
 * 어제 수당 마감 실행 여부 확인 스크립트
 * 
 * 이 스크립트는 다음을 확인합니다:
 * 1. 어제 날짜의 마감 내역 (RewardLog)
 * 2. 자동 모드 활성화 상태
 * 3. 어제 자정 시간대의 마감 실행 여부
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkYesterdaySettlement() {
  try {
    console.log('='.repeat(60));
    console.log('어제 수당 마감 실행 여부 확인');
    console.log('='.repeat(60));
    console.log('');

    // 어제 날짜 계산 (한국 시간 기준)
    const now = new Date();
    const koreaTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Seoul' }));
    const yesterday = new Date(koreaTime);
    yesterday.setDate(yesterday.getDate() - 1);
    yesterday.setHours(0, 0, 0, 0);

    const yesterdayEnd = new Date(yesterday);
    yesterdayEnd.setHours(23, 59, 59, 999);

    const yesterdayStr = yesterday.toISOString().split('T')[0];
    console.log(`📅 확인 날짜: ${yesterdayStr}`);
    console.log('');

    // 1. 자동 모드 활성화 상태 확인
    console.log('1️⃣ 자동 모드 상태 확인');
    console.log('-'.repeat(60));
    const autoModeSetting = await prisma.system_settings.findUnique({
      where: { key: 'autoSettlementEnabled' },
    });

    const isAutoModeEnabled = autoModeSetting?.value === 'true';
    console.log(`   자동 모드: ${isAutoModeEnabled ? '✅ 활성화' : '❌ 비활성화'}`);
    if (autoModeSetting) {
      console.log(`   설정 값: ${autoModeSetting.value}`);
      console.log(`   설명: ${autoModeSetting.description || '-'}`);
      console.log(`   업데이트: ${autoModeSetting.updatedAt.toLocaleString('ko-KR')}`);
    } else {
      console.log('   ⚠️  자동 모드 설정이 데이터베이스에 없습니다.');
    }
    console.log('');

    // 2. 어제 날짜의 마감 내역 통계
    console.log('2️⃣ 어제 마감 내역 통계');
    console.log('-'.repeat(60));

    const stats = await prisma.reward_logs.groupBy({
      by: ['type'],
      where: {
        createdAt: {
          gte: yesterday,
          lte: yesterdayEnd,
        },
        isPaid: true,
      },
      _count: true,
      _sum: {
        amount: true,
      },
    });

    if (stats.length === 0) {
      console.log('   ❌ 어제 날짜에 지급된 수당 내역이 없습니다.');
      console.log('   ⚠️  마감이 실행되지 않았거나, 지급할 수당이 없었을 수 있습니다.');
    } else {
      console.log(`   ✅ 총 ${stats.length}개 타입의 수당이 지급되었습니다.`);
      console.log('');
      console.log('   상세 내역:');
      let totalAmount = 0;
      let totalCount = 0;

      for (const stat of stats) {
        const amount = Number(stat._sum.amount || 0);
        const count = stat._count;
        totalAmount += amount;
        totalCount += count;

        const typeName = {
          DAILY: '일일 수익',
          REFERRAL: '추천 보너스',
          MATCHING: '매칭 보너스',
          RANK: '랭크 보상',
          TEAM: '리더십 보너스',
          CENTER_FEE: '센터비',
          CENTER_INCENTIVE: '센터 개설 인센티브',
        }[stat.type] || stat.type;

        console.log(`   - ${typeName}: ${count}건, 총 ${amount.toFixed(2)} US$`);
      }

      console.log('');
      console.log(`   📊 합계: ${totalCount}건, 총 ${totalAmount.toFixed(2)} US$`);
    }
    console.log('');

    // 3. 어제 자정 시간대 (00:00 ~ 01:00) 마감 실행 확인
    console.log('3️⃣ 어제 자정 시간대 마감 실행 확인');
    console.log('-'.repeat(60));

    const midnightStart = new Date(yesterday);
    midnightStart.setHours(0, 0, 0, 0);

    const midnightEnd = new Date(yesterday);
    midnightEnd.setHours(1, 0, 0, 0);

    const midnightRewards = await prisma.reward_logs.findMany({
      where: {
        createdAt: {
          gte: midnightStart,
          lt: midnightEnd,
        },
        isPaid: true,
      },
      orderBy: {
        createdAt: 'asc',
      },
      take: 10,
    });

    if (midnightRewards.length === 0) {
      console.log('   ⚠️  어제 자정 시간대(00:00 ~ 01:00)에 생성된 수당 내역이 없습니다.');
      console.log('   💡 자동 마감이 실행되지 않았거나, 지급할 수당이 없었을 수 있습니다.');
    } else {
      console.log(`   ✅ 어제 자정 시간대에 ${midnightRewards.length}건 이상의 수당이 지급되었습니다.`);
      console.log('');
      console.log('   첫 5건 내역:');
      midnightRewards.slice(0, 5).forEach((reward, index) => {
        const typeName = {
          DAILY: '일일 수익',
          REFERRAL: '추천 보너스',
          MATCHING: '매칭 보너스',
          RANK: '랭크 보상',
          TEAM: '리더십 보너스',
          CENTER_FEE: '센터비',
          CENTER_INCENTIVE: '센터 개설 인센티브',
        }[reward.type] || reward.type;

        console.log(
          `   ${index + 1}. ${typeName} - ${Number(reward.amount).toFixed(2)} US$ (${reward.createdAt.toLocaleString('ko-KR')})`
        );
      });
    }
    console.log('');

    // 4. 최근 3일간 마감 내역 비교
    console.log('4️⃣ 최근 3일간 마감 내역 비교');
    console.log('-'.repeat(60));

    for (let i = 2; i >= 0; i--) {
      const checkDate = new Date(koreaTime);
      checkDate.setDate(checkDate.getDate() - i);
      checkDate.setHours(0, 0, 0, 0);

      const checkDateEnd = new Date(checkDate);
      checkDateEnd.setHours(23, 59, 59, 999);

      const dateStats = await prisma.reward_logs.groupBy({
        by: ['type'],
        where: {
          createdAt: {
            gte: checkDate,
            lte: checkDateEnd,
          },
          isPaid: true,
        },
        _count: true,
        _sum: {
          amount: true,
        },
      });

      const totalCount = dateStats.reduce((sum, stat) => sum + stat._count, 0);
      const totalAmount = dateStats.reduce(
        (sum, stat) => sum + Number(stat._sum.amount || 0),
        0
      );

      const dateStr = checkDate.toISOString().split('T')[0];
      const isToday = i === 0;
      const isYesterday = i === 1;

      console.log(
        `   ${isToday ? '오늘' : isYesterday ? '어제' : i + '일 전'}: ${dateStr} - ${totalCount}건, ${totalAmount.toFixed(2)} US$`
      );
    }
    console.log('');

    // 5. 결론 및 권장 사항
    console.log('5️⃣ 결론 및 권장 사항');
    console.log('-'.repeat(60));

    const yesterdayTotal = stats.reduce(
      (sum, stat) => sum + Number(stat._sum.amount || 0),
      0
    );
    const yesterdayCount = stats.reduce((sum, stat) => sum + stat._count, 0);

    if (yesterdayCount === 0) {
      console.log('   ❌ 어제 마감이 실행되지 않았습니다.');
      console.log('');
      console.log('   가능한 원인:');
      console.log('   1. 자동 모드가 비활성화되어 있었을 수 있습니다.');
      console.log('   2. 서버가 자정 시간에 재시작되었거나 다운되었을 수 있습니다.');
      console.log('   3. 스케줄러가 제대로 시작되지 않았을 수 있습니다.');
      console.log('   4. 지급할 수당이 없었을 수 있습니다.');
      console.log('');
      console.log('   권장 조치:');
      console.log('   1. 관리자 페이지에서 자동 모드 상태를 확인하세요.');
      console.log('   2. 서버 로그를 확인하여 자정 시간대의 에러를 확인하세요.');
      console.log('   3. 수동으로 어제 날짜 마감을 실행하세요.');
    } else {
      console.log('   ✅ 어제 마감이 정상적으로 실행되었습니다.');
      console.log(`   - 총 ${yesterdayCount}건의 수당이 지급되었습니다.`);
      console.log(`   - 총 ${yesterdayTotal.toFixed(2)} US$가 지급되었습니다.`);
    }

    console.log('');
    console.log('='.repeat(60));
    console.log('확인 완료');
    console.log('='.repeat(60));
  } catch (error: any) {
    console.error('❌ 확인 중 오류 발생:', error);
    console.error(error.stack);
  } finally {
    await prisma.$disconnect();
  }
}

// 스크립트 실행
checkYesterdaySettlement();

