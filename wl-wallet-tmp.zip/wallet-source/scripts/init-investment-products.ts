import { PrismaClient, Prisma } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('📦 투자 상품 초기화 시작...');

  try {
    // 기존 상품 확인
    const existing = await prisma.investment_tiers.findMany({
      orderBy: { tier: 'asc' },
    });

    if (existing.length > 0) {
      console.log(`✅ 이미 ${existing.length}개의 투자 상품이 존재합니다.`);
      existing.forEach((tier) => {
        console.log(`   - Tier ${tier.tier}: $${tier.minAmount} - $${tier.maxAmount}`);
      });
      return;
    }

    console.log('🔄 기본 투자 상품 생성 중...');

    const result = await prisma.investment_tiers.createMany({
      data: [
        {
          id: 1,
          tier: 1,
          minAmount: new Prisma.Decimal(50),
          maxAmount: new Prisma.Decimal(99),
          dailyRate: new Prisma.Decimal(0.003),
          matchingDepth: 0,
          referralRates: [],
          description: '$50-$99: 초보 투자자 (매칭 보너스 없음)',
        },
        {
          id: 2,
          tier: 2,
          minAmount: new Prisma.Decimal(100),
          maxAmount: new Prisma.Decimal(999),
          dailyRate: new Prisma.Decimal(0.005),
          matchingDepth: 4,
          referralRates: [0.12, 0.08, 0.08, 0.08],
          description: '$100-$999: 일반 투자자 (1~4대 매칭 보너스)',
        },
        {
          id: 3,
          tier: 3,
          minAmount: new Prisma.Decimal(1000),
          maxAmount: new Prisma.Decimal(9999),
          dailyRate: new Prisma.Decimal(0.01),
          matchingDepth: 8,
          referralRates: [0.15, 0.12, 0.10, 0.08, 0.08, 0.08, 0.08, 0.08],
          description: '$1,000-$9,999: 고급 투자자 (1~8대 매칭 보너스)',
        },
        {
          id: 4,
          tier: 4,
          minAmount: new Prisma.Decimal(10000),
          maxAmount: new Prisma.Decimal(999999),
          dailyRate: new Prisma.Decimal(0.012),
          matchingDepth: 12,
          referralRates: [0.20, 0.15, 0.12, 0.10, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08],
          description: '$10,000+: VIP 투자자 (1~12대 매칭 보너스)',
        },
      ],
      skipDuplicates: true,
    });

    console.log(`✅ ${result.count}개의 투자 상품이 생성되었습니다.`);
    console.log('');
    console.log('생성된 상품:');
    console.log('  1. 스타터 패키지 ($50-$99)');
    console.log('  2. 비즈니스 패키지 ($100-$999) - 추천');
    console.log('  3. 프로페셔널 패키지 ($1,000-$9,999)');
    console.log('  4. 엔터프라이즈 패키지 ($10,000+)');
  } catch (error) {
    console.error('❌ 투자 상품 초기화 실패:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });

