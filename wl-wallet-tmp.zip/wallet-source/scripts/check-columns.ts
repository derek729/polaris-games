/**
 * 데이터베이스 컬럼 존재 여부 확인 스크립트
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkColumns() {
  try {
    console.log('========================================');
    console.log('데이터베이스 컬럼 확인');
    console.log('========================================\n');

    // users 테이블의 모든 컬럼 조회
    const columns = await prisma.$queryRaw<Array<{ column_name: string; data_type: string; column_default: string | null }>>`
      SELECT column_name, data_type, column_default 
      FROM information_schema.columns 
      WHERE table_name = 'users' 
      AND table_schema = 'public'
      ORDER BY column_name;
    `;

    console.log(`users 테이블의 총 컬럼 수: ${columns.length}\n`);
    console.log('컬럼 목록:');
    columns.forEach(col => {
      console.log(`  - ${col.column_name} (${col.data_type})${col.column_default ? ` default: ${col.column_default}` : ''}`);
    });

    // 2FA 관련 컬럼 확인
    const twoFactorColumns = columns.filter(col => 
      col.column_name.includes('twoFactor') || 
      col.column_name.includes('two_factor')
    );

    console.log('\n========================================');
    console.log('2FA 관련 컬럼 확인');
    console.log('========================================\n');

    if (twoFactorColumns.length === 0) {
      console.log('❌ 2FA 관련 컬럼이 없습니다.');
      console.log('\n필요한 컬럼:');
      console.log('  - twoFactorEnabled (boolean, default: false)');
      console.log('  - twoFactorSecret (text, nullable)');
      console.log('  - twoFactorBackupCodes (text[], default: ARRAY[]::TEXT[])');
    } else {
      console.log(`✅ 2FA 관련 컬럼 ${twoFactorColumns.length}개 발견:\n`);
      twoFactorColumns.forEach(col => {
        console.log(`  - ${col.column_name} (${col.data_type})${col.column_default ? ` default: ${col.column_default}` : ''}`);
      });

      const requiredColumns = ['twoFactorEnabled', 'twoFactorSecret', 'twoFactorBackupCodes'];
      const missingColumns = requiredColumns.filter(req => 
        !twoFactorColumns.some(col => col.column_name === req)
      );

      if (missingColumns.length > 0) {
        console.log('\n⚠️  누락된 컬럼:');
        missingColumns.forEach(col => console.log(`  - ${col}`));
      } else {
        console.log('\n✅ 모든 필수 컬럼이 존재합니다!');
      }
    }

    // 정확한 컬럼 이름 확인 (대소문자 구분)
    console.log('\n========================================');
    console.log('정확한 컬럼 이름 확인');
    console.log('========================================\n');
    
    const exactCheck = await prisma.$queryRaw<Array<{ column_name: string }>>`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'users' 
      AND table_schema = 'public'
      AND (
        column_name = 'twoFactorEnabled' OR
        column_name = 'twoFactorSecret' OR
        column_name = 'twoFactorBackupCodes' OR
        column_name = 'two_factor_enabled' OR
        column_name = 'two_factor_secret' OR
        column_name = 'two_factor_backup_codes' OR
        LOWER(column_name) LIKE '%twofactor%'
      )
      ORDER BY column_name;
    `;

    if (exactCheck.length > 0) {
      console.log('발견된 컬럼 (대소문자 포함):');
      exactCheck.forEach(col => console.log(`  - "${col.column_name}"`));
    } else {
      console.log('❌ 2FA 관련 컬럼을 찾을 수 없습니다.');
    }

  } catch (error: any) {
    console.error('\n❌ 확인 실패:', error.message);
    if (error.message.includes('Can\'t reach database')) {
      console.error('\n⚠️  데이터베이스 연결 실패');
      console.error('   Railway 환경에서 실행해야 합니다.');
    }
  } finally {
    await prisma.$disconnect();
  }
}

checkColumns()
  .then(() => {
    console.log('\n✅ 확인 완료');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ 확인 실패:', error);
    process.exit(1);
  });

