const { updateAllUserRanks } = require('../services/ranking-service');

/**
 * 자동 랭크 업데이트 스크립트
 * 매시간 실행되어 모든 사용자의 랭크를 스테이킹 양에 따라 업데이트
 */

async function autoRankUpdate() {
  console.log('🔄 [Auto Rank Update] 랭크 자동 업데이트 시작');
  console.log(`실행 시간: ${new Date().toISOString()}`);

  try {
    const result = await updateAllUserRanks();

    console.log('✅ [Auto Rank Update] 랭크 업데이트 완료');
    console.log(`📊 결과:`);
    console.log(`  - 전체 사용자: ${result.totalUsers}`);
    console.log(`  - 승급: ${result.rankChanges.upgraded}`);
    console.log(`  - 하락: ${result.rankChanges.downgraded}`);
    console.log(`  - 유지: ${result.rankChanges.same}`);
    console.log(`  - 오류: ${result.errors.length}`);

    if (result.errors.length > 0) {
      console.log('❌ 발생한 오류들:');
      result.errors.forEach((error, index) => {
        console.log(`  ${index + 1}. ${error}`);
      });
    }

    // 상세한 변경 내역 기록 (승급/하락 사용자만)
    const changedUsers = result.users.filter(u => u.rankChange !== 'same');
    if (changedUsers.length > 0) {
      console.log(`\n📋 랭크 변경 상세 내역 (${changedUsers.length}명):`);
      changedUsers.forEach(user => {
        const changeType = user.rankChange === 'upgraded' ? '⬆️ 승급' : '⬇️ 하락';
        console.log(`  ${changeType} ${user.username}: ${user.previousRankName} → ${user.newRankName} (${user.totalStaking.toLocaleString()} AOT)`);
      });
    }

  } catch (error) {
    console.error('❌ [Auto Rank Update] 치명적 오류 발생:', error);
    process.exit(1);
  }
}

// 스크립트 실행
autoRankUpdate()
  .then(() => {
    console.log('\n✨ [Auto Rank Update] 랭크 자동 업데이트 성공적으로 완료');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n💥 [Auto Rank Update] 랭크 자동 업데이트 실패:', error);
    process.exit(1);
  });