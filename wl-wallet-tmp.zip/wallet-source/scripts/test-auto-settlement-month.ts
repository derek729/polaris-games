/**
 * 자동 수당 지급 모드 한 달 분량 테스트 스크립트
 * 
 * 이 스크립트는 자동 마감 기능이 정상적으로 작동하는지
 * 한 달(30일) 분량을 시뮬레이션하여 테스트합니다.
 */

import { prisma } from '../src/lib/prisma';
import { processDailyRewards } from '../src/services/dailyReward';
import { processAllLeadershipBonuses } from '../src/services/leadershipBonus';

interface TestResult {
  day: number;
  date: string;
  dailyReward: {
    success: boolean;
    processedCount?: number;
    errorCount?: number;
    error?: string;
  };
  leadershipBonus: {
    success: boolean;
    processedCount?: number;
    errorCount?: number;
    error?: string;
  };
  totalRewards: number;
  executionTime: number;
}

async function runAutoSettlementTest() {
  console.log('🚀 자동 수당 지급 모드 한 달 분량 테스트 시작\n');
  console.log('='.repeat(80));

  // 자동 모드 활성화 확인
  const autoModeSetting = await prisma.system_settings.findUnique({
    where: { key: 'autoSettlementEnabled' },
  });

  const isAutoModeEnabled = autoModeSetting?.value === 'true';

  if (!isAutoModeEnabled) {
    console.log('⚠️  자동 모드가 비활성화되어 있습니다. 활성화 후 테스트를 진행합니다...\n');
    await prisma.system_settings.upsert({
      where: { key: 'autoSettlementEnabled' },
      update: { value: 'true' },
      create: {
        key: 'autoSettlementEnabled',
        value: 'true',
        description: '수당 마감 자동 모드 활성화 여부',
      },
    });
    console.log('✅ 자동 모드가 활성화되었습니다.\n');
  } else {
    console.log('✅ 자동 모드가 이미 활성화되어 있습니다.\n');
  }

  // 테스트 시작 전 현재 상태 확인
  const beforeStats = await prisma.reward_logs.groupBy({
    by: ['type'],
    _count: true,
    _sum: {
      amount: true,
    },
  });

  console.log('📊 테스트 시작 전 현재 상태:');
  beforeStats.forEach((stat) => {
    console.log(
      `   ${stat.type}: ${stat._count}건, 총액: ${Number(stat._sum.amount || 0).toFixed(2)} USDT`
    );
  });
  console.log('');

  const testResults: TestResult[] = [];
  const testDays = 30; // 한 달 = 30일
  const startDate = new Date();

  console.log(`📅 테스트 기간: ${testDays}일 (시뮬레이션)\n`);
  console.log('='.repeat(80));
  console.log('');

  // 각 날짜별로 테스트 실행
  for (let day = 1; day <= testDays; day++) {
    const testDate = new Date(startDate);
    testDate.setDate(startDate.getDate() + day - 1);
    const dateStr = testDate.toISOString().split('T')[0];

    console.log(`📆 Day ${day}/${testDays} - ${dateStr}`);
    console.log('-'.repeat(80));

    const dayStartTime = Date.now();
    const dayResult: TestResult = {
      day,
      date: dateStr,
      dailyReward: { success: false },
      leadershipBonus: { success: false },
      totalRewards: 0,
      executionTime: 0,
    };

    // 1. 일일 수익 지급 테스트
    console.log('  🔄 일일 수익 지급 처리 중...');
    try {
      const dailyResult = await processDailyRewards();
      dayResult.dailyReward = {
        success: true,
        processedCount: dailyResult.processedCount || 0,
        errorCount: dailyResult.errorCount || 0,
      };
      console.log(
        `  ✅ 일일 수익 처리 완료: ${dailyResult.processedCount || 0}건 처리, ${dailyResult.errorCount || 0}건 오류`
      );
    } catch (error: any) {
      dayResult.dailyReward = {
        success: false,
        error: error.message || '알 수 없는 오류',
      };
      console.log(`  ❌ 일일 수익 처리 실패: ${error.message}`);
    }

    // 잠시 대기 (데이터베이스 처리 시간 확보)
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // 2. 리더십 보너스 지급 테스트
    console.log('  🔄 리더십 보너스 처리 중...');
    try {
      const leadershipResult = await processAllLeadershipBonuses();
      dayResult.leadershipBonus = {
        success: true,
        processedCount: leadershipResult.processedCount || 0,
        errorCount: leadershipResult.errorCount || 0,
      };
      console.log(
        `  ✅ 리더십 보너스 처리 완료: ${leadershipResult.processedCount || 0}명 처리, ${leadershipResult.errorCount || 0}명 오류`
      );
    } catch (error: any) {
      dayResult.leadershipBonus = {
        success: false,
        error: error.message || '알 수 없는 오류',
      };
      console.log(`  ❌ 리더십 보너스 처리 실패: ${error.message}`);
    }

    // 오늘 생성된 리워드 통계
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayEnd = new Date(today);
    todayEnd.setHours(23, 59, 59, 999);

    const todayStats = await prisma.reward_logs.groupBy({
      by: ['type'],
      where: {
        createdAt: {
          gte: today,
          lte: todayEnd,
        },
        isPaid: true,
      },
      _sum: {
        amount: true,
      },
    });

    const todayTotal = todayStats.reduce(
      (sum, stat) => sum + Number(stat._sum.amount || 0),
      0
    );
    dayResult.totalRewards = todayTotal;
    dayResult.executionTime = Date.now() - dayStartTime;

    console.log(`  💰 오늘 지급된 총 수당: ${todayTotal.toFixed(2)} USDT`);
    console.log(`  ⏱️  실행 시간: ${dayResult.executionTime}ms`);
    console.log('');

    testResults.push(dayResult);

    // 진행률 표시
    if (day % 5 === 0 || day === testDays) {
      const progress = ((day / testDays) * 100).toFixed(1);
      console.log(`📈 진행률: ${progress}% (${day}/${testDays}일 완료)\n`);
    }
  }

  // 테스트 완료 후 최종 상태 확인
  const afterStats = await prisma.reward_logs.groupBy({
    by: ['type'],
    _count: true,
    _sum: {
      amount: true,
    },
  });

  console.log('='.repeat(80));
  console.log('📊 테스트 완료 후 최종 상태:');
  afterStats.forEach((stat) => {
    const beforeStat = beforeStats.find((s) => s.type === stat.type);
    const beforeCount = beforeStat?._count || 0;
    const beforeAmount = Number(beforeStat?._sum.amount || 0);
    const newCount = stat._count - beforeCount;
    const newAmount = Number(stat._sum.amount || 0) - beforeAmount;

    console.log(
      `   ${stat.type}: 총 ${stat._count}건 (+${newCount}건), 총액: ${Number(stat._sum.amount || 0).toFixed(2)} USDT (+${newAmount.toFixed(2)} USDT)`
    );
  });
  console.log('');

  // 테스트 결과 요약
  console.log('='.repeat(80));
  console.log('📋 테스트 결과 요약');
  console.log('='.repeat(80));

  const successfulDays = testResults.filter(
    (r) => r.dailyReward.success && r.leadershipBonus.success
  ).length;
  const failedDays = testDays - successfulDays;

  const totalProcessedDaily = testResults.reduce(
    (sum, r) => sum + (r.dailyReward.processedCount || 0),
    0
  );
  const totalProcessedLeadership = testResults.reduce(
    (sum, r) => sum + (r.leadershipBonus.processedCount || 0),
    0
  );
  const totalRewardsAmount = testResults.reduce((sum, r) => sum + r.totalRewards, 0);
  const avgExecutionTime =
    testResults.reduce((sum, r) => sum + r.executionTime, 0) / testResults.length;

  console.log(`✅ 성공한 날: ${successfulDays}일 / ${testDays}일`);
  console.log(`❌ 실패한 날: ${failedDays}일 / ${testDays}일`);
  console.log(`📊 성공률: ${((successfulDays / testDays) * 100).toFixed(2)}%`);
  console.log('');
  console.log(`💰 총 지급된 수당: ${totalRewardsAmount.toFixed(2)} USDT`);
  console.log(`📈 일일 수익 처리: 총 ${totalProcessedDaily}건`);
  console.log(`👥 리더십 보너스 처리: 총 ${totalProcessedLeadership}명`);
  console.log(`⏱️  평균 실행 시간: ${avgExecutionTime.toFixed(2)}ms`);
  console.log('');

  // 실패한 날짜 상세 정보
  const failedResults = testResults.filter(
    (r) => !r.dailyReward.success || !r.leadershipBonus.success
  );

  if (failedResults.length > 0) {
    console.log('='.repeat(80));
    console.log('⚠️  실패한 날짜 상세 정보');
    console.log('='.repeat(80));
    failedResults.forEach((result) => {
      console.log(`\n📅 Day ${result.day} - ${result.date}:`);
      if (!result.dailyReward.success) {
        console.log(`  ❌ 일일 수익: ${result.dailyReward.error}`);
      }
      if (!result.leadershipBonus.success) {
        console.log(`  ❌ 리더십 보너스: ${result.leadershipBonus.error}`);
      }
    });
    console.log('');
  }

  // 일별 상세 리포트 (최근 5일)
  console.log('='.repeat(80));
  console.log('📅 최근 5일 상세 리포트');
  console.log('='.repeat(80));
  testResults.slice(-5).forEach((result) => {
    console.log(`\n📆 Day ${result.day} - ${result.date}:`);
    console.log(
      `   일일 수익: ${result.dailyReward.success ? '✅' : '❌'} ${result.dailyReward.processedCount || 0}건 처리`
    );
    console.log(
      `   리더십 보너스: ${result.leadershipBonus.success ? '✅' : '❌'} ${result.leadershipBonus.processedCount || 0}명 처리`
    );
    console.log(`   총 수당: ${result.totalRewards.toFixed(2)} USDT`);
    console.log(`   실행 시간: ${result.executionTime}ms`);
  });
  console.log('');

  console.log('='.repeat(80));
  console.log('✅ 테스트 완료!');
  console.log('='.repeat(80));

  // 자동 모드 상태 유지 (테스트 후에도 활성화 상태 유지)
  console.log('\n💡 자동 모드는 활성화 상태로 유지됩니다.');
  console.log('   비활성화하려면 관리자 페이지에서 수동으로 중지하세요.\n');
}

// 스크립트 실행
runAutoSettlementTest()
  .then(() => {
    console.log('스크립트 실행 완료');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ 테스트 실행 중 오류 발생:', error);
    process.exit(1);
  });

