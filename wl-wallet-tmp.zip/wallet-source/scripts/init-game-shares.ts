import { Prisma } from '@prisma/client';

const prisma = new PrismaClient();

const GAMES = [
  {
    name: '블랙잭',
    description: '럭셔리 카지노 블랙잭 게임',
    id: 'blackjack',
  },
  {
    name: '오션',
    description: '화려한 3D 슬롯머신 게임',
    id: 'spin',
  },
  {
    name: '파워볼',
    description: '행운의 숫자를 선택하고 잭팟에 도전하세요!',
    id: 'lotto',
  },
  {
    name: '로얄 카지노',
    description: 'GEMINI 로얄 카지노 룰렛',
    id: 'loullet',
  },
];

/**
 * 게임 지분 상품 초기화
 * 각 게임의 100% 지분을 여러 단위로 나눔
 */
async function initGameShares() {
  console.log('🎮 게임 지분 상품 초기화 시작...\n');

  for (const gameData of GAMES) {
    try {
      // 게임 조회 또는 생성
      let game = await prisma.games.findFirst({
        where: {
          OR: [
            { name: gameData.name },
            { id: gameData.id },
          ],
        },
      });

      if (!game) {
        game = await prisma.1.create({{ data: {
            name: gameData.name,
            description: gameData.description,
            isActive: true,
          },
        });
        console.log(`✅ 게임 생성: ${game.name} (ID: ${game.id})`);
      } else {
        console.log(`📋 기존 게임 발견: ${game.name} (ID: ${game.id})`);
      }

      // 기존 지분 상품 확인
      const existingShares = await prisma.game_shares.findMany({
        where: { gameId: game.id, isActive: true },
      });

      // 기존 지분 총합 확인
      const existingTotalPercentage = existingShares.reduce(
        (sum, share) => sum.add(share.sharePercentage),
        new Prisma.Decimal(0)
      );

      // 이미 100% 지분이 등록되어 있으면 스킵
      if (existingTotalPercentage.gte(1)) {
        console.log(`  ⚠️  이미 지분 상품이 100% 등록되어 있습니다. (${existingShares.length}개)`);
        console.log(`  💡 관리자 페이지에서 가격과 수량을 변경할 수 있습니다.\n`);
        continue;
      }

      // 100% 지분을 1%씩 100개로 나눔 (총 100%)
      // 관리자 페이지에서 가격과 수량을 변경할 수 있음
      const sharePercentage = new Prisma.Decimal(0.01); // 1%
      const totalShares = 100; // 100개 = 100%
      const pricePerShare = new Prisma.Decimal(100); // 지분당 100 USDT (기본값, 관리자가 수정 가능)

      // 기존에 같은 지분 상품이 있는지 확인
      const existingShare = existingShares.find(
        (s) => s.sharePercentage.eq(sharePercentage) && s.totalShares === totalShares
      );

      if (existingShare) {
        console.log(`  ℹ️  지분 상품이 이미 존재합니다. (ID: ${existingShare.id})`);
        console.log(`     - 지분 비율: ${sharePercentage.mul(100).toFixed(2)}%`);
        console.log(`     - 지분당 가격: ${existingShare.price.toFixed(2)} USDT`);
        console.log(`     - 총 지분 수: ${existingShare.totalShares}개`);
        console.log(`     - 판매 가능: ${existingShare.availableShares}개`);
        console.log(`     - 판매 완료: ${existingShare.soldShares}개\n`);
        continue;
      }

      const gameShare = await prisma.1.create({{ data: {
          gameId: game.id,
          sharePercentage,
          price: pricePerShare,
          totalShares,
          availableShares: totalShares,
          soldShares: 0,
          isActive: true,
        },
      });

      console.log(`  ✅ 지분 상품 생성 완료:`);
      console.log(`     - 상품 ID: ${gameShare.id}`);
      console.log(`     - 지분 비율: ${sharePercentage.mul(100).toFixed(2)}%`);
      console.log(`     - 지분당 가격: ${pricePerShare.toFixed(2)} USDT (관리자에서 변경 가능)`);
      console.log(`     - 총 지분 수: ${totalShares}개 (100%)`);
      console.log(`     - 판매 가능: ${totalShares}개\n`);
    } catch (error: any) {
      console.error(`❌ ${gameData.name} 처리 실패:`, error.message);
    }
  }

  console.log('✅ 게임 지분 상품 초기화 완료!');
}

// 실행
initGameShares()
  .catch((error) => {
    console.error('❌ 초기화 실패:', error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });



