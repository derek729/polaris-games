const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

// DATABASE_URL is read from the environment (.env). Never hardcode credentials.
const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL 환경 변수가 설정되지 않았습니다. .env 파일을 확인하세요.');
  process.exit(1);
}

const prisma = new PrismaClient({
  datasources: {
    db: {
      url: DATABASE_URL
    }
  }
});

async function createAccounts() {
  try {
    console.log('🔐 계정 생성 시작...');
    console.log(`📡 데이터베이스: ${DATABASE_URL.replace(/:[^:@]+@/, ':****@')}`);
    console.log('');

    // 데이터베이스 연결 테스트
    await prisma.$connect();
    console.log('✅ 데이터베이스 연결 성공!');
    console.log('');

    // ============================================
    // 1. 관리자 계정 생성
    // ============================================
    console.log('👑 관리자 계정 생성 중...');
    
    const adminPassword = await bcrypt.hash('Admin@123456', 10);
    const adminData = {
      username: 'admin',
      email: 'admin@upc.co.kr',
      password: adminPassword,
      role: 'SUPER_ADMIN',
      rank: 5,
      personalCoin: 1000000.0,
      totalInvestment: 0.0,
      status: 'ACTIVE',
      isActive: true,
      accumulatedSales: 0.0,
      line1Sales: 0.0,
      line2Sales: 0.0,
      line3Sales: 0.0,
      line4Sales: 0.0,
      line5Sales: 0.0,
    };

    const existingAdmin = await prisma.users.findFirst({
      where: {
        OR: [
          { username: 'admin' },
          { email: 'admin@upc.co.kr' }
        ]
      }
    });

    let admin;
    if (existingAdmin) {
      console.log('⚠️  기존 관리자 계정 발견 - 권한 업데이트 중...');
      admin = await prisma.users.update({
        where: { id: existingAdmin.id },
        data: {
          role: 'SUPER_ADMIN',
          rank: 5,
          status: 'ACTIVE',
          isActive: true,
          password: adminPassword,
          email: adminData.email,
        }
      });
      console.log('✅ 관리자 계정 업데이트 완료!');
    } else {
      admin = await prisma.users.create({
        data: adminData
      });
      console.log('✅ 새 관리자 계정 생성 완료!');
    }

    console.log(`   - ID: ${admin.id}`);
    console.log(`   - 사용자명: ${admin.username}`);
    console.log(`   - 이메일: ${admin.email}`);
    console.log(`   - 권한: ${admin.role}`);
    console.log(`   - 랭크: ${admin.rank}`);
    console.log('');

    // ============================================
    // 2. 테스트 계정 생성
    // ============================================
    console.log('🧪 테스트 계정 생성 중...');
    
    const testPassword = await bcrypt.hash('Test@123456', 10);
    const testUserData = {
      username: 'testuser',
      email: 'test@upc.co.kr',
      password: testPassword,
      role: 'USER',
      rank: 0,
      personalCoin: 10000.0,
      totalInvestment: 0.0,
      status: 'ACTIVE',
      isActive: true,
      accumulatedSales: 0.0,
      line1Sales: 0.0,
      line2Sales: 0.0,
      line3Sales: 0.0,
      line4Sales: 0.0,
      line5Sales: 0.0,
    };

    const existingTestUser = await prisma.users.findFirst({
      where: {
        OR: [
          { username: 'testuser' },
          { email: 'test@upc.co.kr' }
        ]
      }
    });

    let testUser;
    if (existingTestUser) {
      console.log('⚠️  기존 테스트 계정 발견 - 업데이트 중...');
      testUser = await prisma.users.update({
        where: { id: existingTestUser.id },
        data: {
          status: 'ACTIVE',
          isActive: true,
          password: testPassword,
          email: testUserData.email,
        }
      });
      console.log('✅ 테스트 계정 업데이트 완료!');
    } else {
      testUser = await prisma.users.create({
        data: testUserData
      });
      console.log('✅ 새 테스트 계정 생성 완료!');
    }

    console.log(`   - ID: ${testUser.id}`);
    console.log(`   - 사용자명: ${testUser.username}`);
    console.log(`   - 이메일: ${testUser.email}`);
    console.log(`   - 권한: ${testUser.role}`);
    console.log(`   - 랭크: ${testUser.rank}`);
    console.log('');

    // ============================================
    // 결과 요약
    // ============================================
    console.log('🎉 계정 생성 완료!');
    console.log('');
    console.log('📋 관리자 계정 로그인 정보:');
    console.log('   - URL: http://localhost:3009/a0-admin/login');
    console.log('   - 사용자명: admin');
    console.log('   - 비밀번호: Admin@123456');
    console.log('');
    console.log('📋 테스트 계정 로그인 정보:');
    console.log('   - URL: http://localhost:3009/');
    console.log('   - 사용자명: testuser');
    console.log('   - 비밀번호: Test@123456');
    console.log('');
    console.log('⚠️  중요: 보안을 위해 첫 로그인 후 비밀번호를 변경하세요!');

  } catch (error) {
    console.error('❌ 오류 발생:', error.message);
    console.error('상세:', error);
    
    if (error.message.includes("Can't reach database server")) {
      console.log('');
      console.log('💡 데이터베이스 연결 오류입니다.');
      console.log('DATABASE_URL 환경 변수를 확인하세요.');
      console.log('현재 DATABASE_URL:', DATABASE_URL.replace(/:[^:@]+@/, ':****@'));
    }
    
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

createAccounts();

