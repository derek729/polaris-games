/**
 * 로컬 자동 수당 지급 모드 테스트 스크립트
 * 
 * 실제 데이터베이스에 접근하지 않고, 자동 마감 로직만 검증합니다.
 * 관리자 페이지에서 "마감 실행" 버튼을 여러 번 눌러서 테스트하는 것을 시뮬레이션합니다.
 */

import { processDailyRewards } from '../src/services/dailyReward';
import { processAllLeadershipBonuses } from '../src/services/leadershipBonus';

interface TestResult {
  testNumber: number;
  timestamp: string;
  dailyReward: {
    success: boolean;
    processedCount?: number;
    errorCount?: number;
    error?: string;
  };
  leadershipBonus: {
    success: boolean;
    processedCount?: number;
    errorCount?: number;
    error?: string;
  };
  executionTime: number;
}

async function runLocalTest() {
  console.log('🧪 로컬 자동 수당 지급 모드 테스트 시작\n');
  console.log('='.repeat(80));
  console.log('⚠️  주의: 이 테스트는 실제 데이터베이스에 접근합니다.');
  console.log('⚠️  프로덕션 환경에서는 신중하게 실행하세요.\n');
  console.log('='.repeat(80));
  console.log('');

  const testResults: TestResult[] = [];
  const testCount = 5; // 5회 테스트 (한 달 대신 짧은 테스트)

  console.log(`📊 테스트 횟수: ${testCount}회\n`);
  console.log('💡 팁: 관리자 페이지에서 "마감 실행" 버튼을 눌러도 동일한 결과를 얻을 수 있습니다.\n');
  console.log('='.repeat(80));
  console.log('');

  for (let i = 1; i <= testCount; i++) {
    console.log(`🔄 테스트 ${i}/${testCount}`);
    console.log('-'.repeat(80));

    const testStartTime = Date.now();
    const timestamp = new Date().toISOString();
    const testResult: TestResult = {
      testNumber: i,
      timestamp,
      dailyReward: { success: false },
      leadershipBonus: { success: false },
      executionTime: 0,
    };

    // 1. 일일 수익 지급 테스트
    console.log('  📈 일일 수익 지급 처리 중...');
    try {
      const dailyResult = await processDailyRewards();
      testResult.dailyReward = {
        success: true,
        processedCount: dailyResult.processedCount || 0,
        errorCount: dailyResult.errorCount || 0,
      };
      console.log(
        `  ✅ 일일 수익 처리 완료: ${dailyResult.processedCount || 0}건 처리, ${dailyResult.errorCount || 0}건 오류`
      );
    } catch (error: any) {
      testResult.dailyReward = {
        success: false,
        error: error.message || '알 수 없는 오류',
      };
      console.log(`  ❌ 일일 수익 처리 실패: ${error.message}`);
    }

    // 잠시 대기 (데이터베이스 처리 시간 확보)
    await new Promise((resolve) => setTimeout(resolve, 1000));

    // 2. 리더십 보너스 지급 테스트
    console.log('  👥 리더십 보너스 처리 중...');
    try {
      const leadershipResult = await processAllLeadershipBonuses();
      testResult.leadershipBonus = {
        success: true,
        processedCount: leadershipResult.processedCount || 0,
        errorCount: leadershipResult.errorCount || 0,
      };
      console.log(
        `  ✅ 리더십 보너스 처리 완료: ${leadershipResult.processedCount || 0}명 처리, ${leadershipResult.errorCount || 0}명 오류`
      );
    } catch (error: any) {
      testResult.leadershipBonus = {
        success: false,
        error: error.message || '알 수 없는 오류',
      };
      console.log(`  ❌ 리더십 보너스 처리 실패: ${error.message}`);
    }

    testResult.executionTime = Date.now() - testStartTime;
    console.log(`  ⏱️  실행 시간: ${testResult.executionTime}ms`);
    console.log('');

    testResults.push(testResult);

    // 테스트 간 대기 (실제 자동 모드처럼 하루 간격 시뮬레이션)
    if (i < testCount) {
      console.log('  ⏳ 다음 테스트까지 대기 중... (3초)\n');
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }

  // 테스트 결과 요약
  console.log('='.repeat(80));
  console.log('📋 테스트 결과 요약');
  console.log('='.repeat(80));

  const successfulTests = testResults.filter(
    (r) => r.dailyReward.success && r.leadershipBonus.success
  ).length;
  const failedTests = testCount - successfulTests;

  const totalProcessedDaily = testResults.reduce(
    (sum, r) => sum + (r.dailyReward.processedCount || 0),
    0
  );
  const totalProcessedLeadership = testResults.reduce(
    (sum, r) => sum + (r.leadershipBonus.processedCount || 0),
    0
  );
  const avgExecutionTime =
    testResults.reduce((sum, r) => sum + r.executionTime, 0) / testResults.length;

  console.log(`✅ 성공한 테스트: ${successfulTests}회 / ${testCount}회`);
  console.log(`❌ 실패한 테스트: ${failedTests}회 / ${testCount}회`);
  console.log(`📊 성공률: ${((successfulTests / testCount) * 100).toFixed(2)}%`);
  console.log('');
  console.log(`📈 일일 수익 처리: 총 ${totalProcessedDaily}건`);
  console.log(`👥 리더십 보너스 처리: 총 ${totalProcessedLeadership}명`);
  console.log(`⏱️  평균 실행 시간: ${avgExecutionTime.toFixed(2)}ms`);
  console.log('');

  // 실패한 테스트 상세 정보
  const failedResults = testResults.filter(
    (r) => !r.dailyReward.success || !r.leadershipBonus.success
  );

  if (failedResults.length > 0) {
    console.log('='.repeat(80));
    console.log('⚠️  실패한 테스트 상세 정보');
    console.log('='.repeat(80));
    failedResults.forEach((result) => {
      console.log(`\n🔄 테스트 ${result.testNumber} - ${result.timestamp}:`);
      if (!result.dailyReward.success) {
        console.log(`  ❌ 일일 수익: ${result.dailyReward.error}`);
      }
      if (!result.leadershipBonus.success) {
        console.log(`  ❌ 리더십 보너스: ${result.leadershipBonus.error}`);
      }
    });
    console.log('');
  }

  // 모든 테스트 상세 리포트
  console.log('='.repeat(80));
  console.log('📅 전체 테스트 상세 리포트');
  console.log('='.repeat(80));
  testResults.forEach((result) => {
    console.log(`\n🔄 테스트 ${result.testNumber} - ${result.timestamp}:`);
    console.log(
      `   일일 수익: ${result.dailyReward.success ? '✅' : '❌'} ${result.dailyReward.processedCount || 0}건 처리`
    );
    console.log(
      `   리더십 보너스: ${result.leadershipBonus.success ? '✅' : '❌'} ${result.leadershipBonus.processedCount || 0}명 처리`
    );
    console.log(`   실행 시간: ${result.executionTime}ms`);
  });
  console.log('');

  console.log('='.repeat(80));
  console.log('✅ 테스트 완료!');
  console.log('='.repeat(80));
  console.log('');
  console.log('💡 다음 단계:');
  console.log('   1. 관리자 페이지에서 "자동 모드"를 활성화하세요');
  console.log('   2. 자동 모드가 매일 자정에 정상 작동하는지 모니터링하세요');
  console.log('   3. 로그를 확인하여 오류가 없는지 확인하세요');
  console.log('');
}

// 스크립트 실행
runLocalTest()
  .then(() => {
    console.log('스크립트 실행 완료');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ 테스트 실행 중 오류 발생:', error);
    process.exit(1);
  });

