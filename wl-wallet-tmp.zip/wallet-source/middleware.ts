import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const nextUrl = request.nextUrl;
  const { pathname } = nextUrl;
  const appMode = (process.env.APP_MODE || 'foundation').toLowerCase();

  // 재단 모드에서 비활성 기능 경로 차단
  if (appMode === 'foundation') {
    // 채굴, 보상 등 비활성 기능 차단
    const disabledPaths = [
      '/team',
      '/mining-staking',
      '/rewards',
      '/products',
      '/game-shares',
      '/exchange',
      '/withdraw',
      '/dashboard',
      '/my-office',
      '/register',
      '/forgot-password',
    ];
    
    // 관리자 경로는 허용 (API 라우트는 이미 matcher에서 제외됨)
    if (pathname.startsWith('/u0-admin') || pathname.startsWith('/api/admin')) {
      return NextResponse.next();
    }

    // 비활성 경로로 접근 시 홈으로 리다이렉트
    if (disabledPaths.some(path => pathname.startsWith(path))) {
      return NextResponse.redirect(new URL('/', request.url));
    }

    // 허용된 경로: 지갑, 전송, 거래내역, 게임, 스테이킹, 재단, 백서, 문의, 로그인
    const allowedPaths = [
      '/',
      '/about',
      '/whitepaper',
      '/contact',
      '/transfer',
      '/transactions',
      '/games',
      '/staking',
      '/mining',
      '/landing',
      '/login',
      '/my-profile',
    ];

    const isAllowed =
      allowedPaths.includes(pathname) ||
      pathname.startsWith('/icons') ||
      pathname === '/manifest.json' ||
      pathname === '/sw.js' ||
      pathname.startsWith('/downloads') ||
      pathname.startsWith('/whitepaper/') ||
      /\.(png|ico|svg|webp|jpg|jpeg|gif|css|js|map|json|txt|xml|apk|pdf)$/i.test(pathname);

    if (!isAllowed) {
      return NextResponse.redirect(new URL('/', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};

