# 배포 체크리스트 - 스키마 변경 시 필수 확인사항

## ⚠️ Prisma 스키마 변경 시 반드시 확인

### 배포 전 체크리스트

1. **Prisma 스키마 변경 확인**
   ```bash
   git diff prisma/schema.prisma
   ```

2. **마이그레이션 파일 생성**
   ```bash
   npx prisma migrate dev --name describe_your_changes
   ```

3. **로컬에서 마이그레이션 테스트**
   ```bash
   npx prisma migrate reset  # 주의: 데이터 삭제됨
   npx prisma migrate deploy
   ```

4. **프로덕션 배포 전 마이그레이션 실행**
   ```bash
   # Railway에서 실행
   railway run npm run migrate-db
   # 또는
   railway run npx prisma migrate deploy
   ```

5. **코드 배포**
   ```bash
   git push origin main
   ```

### 배포 후 확인

1. **데이터베이스 스키마 확인**
   ```sql
   SELECT column_name, data_type 
   FROM information_schema.columns 
   WHERE table_name = 'users';
   ```

2. **기능 테스트**
   - 회원 가입 테스트
   - 회원 추가 테스트
   - 관련 기능 모두 테스트

## 🚨 문제 발생 시 대응

### 에러: "column does not exist"

**즉시 조치:**
1. Railway 대시보드 → PostgreSQL → Query 탭
2. 필요한 컬럼 추가 SQL 실행
3. 또는 `railway run npm run migrate-db` 실행

**근본 해결:**
- 마이그레이션 파일 생성 및 배포 프로세스 개선

