import * as fs from 'fs';
import * as path from 'path';
import * as readline from 'readline';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(query: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(query, resolve);
  });
}

async function main() {
  console.log('🏭 OEM 템플릿 생성 도구');
  console.log('=====================================\n');
  console.log('이 도구는 다른 회사에 납품 가능한 OEM 버전을 생성합니다.\n');

  try {
    // 사용자 입력 받기
    const companyName = await question('상호명을 입력하세요 (예: ABC Coin Foundation): ');
    if (!companyName.trim()) {
      console.log('❌ 상호명은 필수입니다.');
      process.exit(1);
    }

    const symbolName = await question('코인 심볼명을 입력하세요 (예: ABC): ');
    if (!symbolName.trim()) {
      console.log('❌ 심볼명은 필수입니다.');
      process.exit(1);
    }

    const totalSupply = await question('총 발행량을 입력하세요 (예: 1000000000): ');
    if (!totalSupply.trim() || !/^\d+$/.test(totalSupply)) {
      console.log('❌ 총 발행량은 숫자여야 합니다.');
      process.exit(1);
    }

    const symbolNameUpper = symbolName.toUpperCase();
    const symbolNameLower = symbolName.toLowerCase();
    const projectName = symbolNameLower + 'wallet';

    // 소스 디렉토리와 타겟 디렉토리
    const sourceDir = process.cwd();
    const targetDir = path.join('D:', 'OEM', 'new', projectName);

    console.log('\n📋 OEM 프로젝트 정보:');
    console.log(`   상호명: ${companyName}`);
    console.log(`   심볼명: ${symbolNameUpper}`);
    console.log(`   총 발행량: ${parseInt(totalSupply).toLocaleString()}개`);
    console.log(`   프로젝트명: ${projectName}`);
    console.log(`   타겟 디렉토리: ${targetDir}\n`);

    const confirm = await question('위 정보로 OEM 템플릿을 생성하시겠습니까? (y/N): ');
    if (confirm.toLowerCase() !== 'y') {
      console.log('취소되었습니다.');
      process.exit(0);
    }

    // 타겟 디렉토리 생성
    if (fs.existsSync(targetDir)) {
      const overwrite = await question(`\n⚠️  디렉토리가 이미 존재합니다. 덮어쓰시겠습니까? (y/N): `);
      if (overwrite.toLowerCase() !== 'y') {
        console.log('취소되었습니다.');
        process.exit(0);
      }
      console.log('🗑️  기존 디렉토리 삭제 중...');
      fs.rmSync(targetDir, { recursive: true, force: true });
    }

    console.log('\n📁 프로젝트 복사 중...');
    copyDirectory(sourceDir, targetDir, [
      'node_modules',
      '.next',
      'out',
      'build',
      '.git',
      'dist',
      'coverage',
      '.env',
      '.env.local',
      '.env.*.local',
      '*.log',
      'tsconfig.tsbuildinfo',
      'temp_*',
      'KakaoTalk_*',
      'backup',
      'Newbie',
      '보너스',
      '.claude',
      'assets',
      'ADMIN_MANUAL.md',
      'FAQ.md',
      'QUICK_START_GUIDE.md',
      'USER_MANUAL.md',
      'UPC-*.pdf',
    ]);

    console.log('🔄 파일 내용 변경 중...');
    const replacements: Record<string, string> = {
      'UPC': symbolNameUpper,
      'upc': symbolNameLower,
      'UPC Coin Foundation': companyName,
      'UPC Foundation': companyName.replace(/Coin Foundation/i, 'Foundation'),
      '10000000000': totalSupply,
      '100억개': formatSupply(totalSupply),
      'upcwallet': projectName,
      'UOC GROUP': companyName.split(' ')[0].toUpperCase() + ' GROUP',
    };

    // 추가로 찾아서 교체할 패턴들
    const additionalReplacements: Record<string, string> = {
      'UPC COIN FOUNDATION': companyName.toUpperCase(),
      'UPC코인': symbolNameUpper + '코인',
      'UPC 코인': symbolNameUpper + ' 코인',
      'upccoin': symbolNameLower + 'coin',
    };

    Object.assign(replacements, additionalReplacements);
    replaceInFiles(targetDir, replacements);

    // package.json 수정
    const packageJsonPath = path.join(targetDir, 'package.json');
    if (fs.existsSync(packageJsonPath)) {
      const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
      packageJson.name = projectName;
      packageJson.version = '1.0.0';
      fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2) + '\n');
    }

    // OEM 설정 파일 생성
    const oemConfigPath = path.join(targetDir, 'OEM_CONFIG.json');
    const oemConfig = {
      companyName,
      symbolName: symbolNameUpper,
      symbolNameLower,
      totalSupply: parseInt(totalSupply),
      projectName,
      createdAt: new Date().toISOString(),
      version: '1.0.0',
    };
    fs.writeFileSync(oemConfigPath, JSON.stringify(oemConfig, null, 2) + '\n');

    // OEM 가이드 문서 생성
    const oemGuidePath = path.join(targetDir, 'OEM_GUIDE.md');
    const oemGuide = `# OEM 템플릿 가이드

## 📋 프로젝트 정보

- **상호명**: ${companyName}
- **코인 심볼**: ${symbolNameUpper}
- **총 발행량**: ${parseInt(totalSupply).toLocaleString()}개
- **프로젝트명**: ${projectName}

## 🚀 시작하기

### 1. 의존성 설치

\`\`\`bash
npm install
\`\`\`

### 2. 환경 변수 설정

\`.env\` 파일을 생성하고 다음 변수들을 설정하세요:

\`\`\`env
DATABASE_URL="postgresql://user:password@localhost:5432/dbname"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://localhost:3009"
\`\`\`

### 3. 데이터베이스 설정

\`\`\`bash
npx prisma db push
\`\`\`

### 4. 개발 서버 실행

\`\`\`bash
npm run dev
\`\`\`

## 🎨 커스터마이징

### 로고 변경

\`public/icons/logo.png\` 파일을 교체하세요.

### 브랜딩 텍스트 변경

다음 파일들에서 브랜딩 텍스트를 수정할 수 있습니다:

- \`src/components/CompanyBrand.tsx\`
- \`src/app/_components/WalletHeader.tsx\`
- \`src/app/_components/LandingPage.tsx\`

### 색상 테마 변경

\`tailwind.config.js\` 또는 CSS 변수를 수정하세요.

## 📝 주요 기능

- ✅ 사용자 인증 및 회원가입
- ✅ 지갑 관리 (UPC 코인)
- ✅ 코인 전송 및 거래 내역
- ✅ 게임 통합
- ✅ 관리자 대시보드

## 🔧 추가 설정

### 슈퍼 관리자 생성

\`\`\`bash
npm run create-super-admin
\`\`\`

### 게임 주식 초기화

\`\`\`bash
npm run init-game-game_shares
\`\`\`

### 투자 상품 초기화

\`\`\`bash
npm run init-investment-products
\`\`\`

## 📞 지원

문제가 발생하면 OEM 제공업체에 문의하세요.

---
생성일: ${new Date().toLocaleString('ko-KR')}
`;
    fs.writeFileSync(oemGuidePath, oemGuide, 'utf-8');

    // .gitignore 파일 생성 (OEM 버전용)
    const gitignorePath = path.join(targetDir, '.gitignore');
    if (!fs.existsSync(gitignorePath)) {
      const gitignoreContent = `# Dependencies
node_modules/
/.pnp
.pnp.js

# Testing
/coverage

# Next.js
/.next/
/out/
/build
/dist

# Production
/build

# Misc
.DS_Store
*.pem

# Debug
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Local env files
.env*.local
.env

# Vercel
.vercel

# TypeScript
*.tsbuildinfo
next-env.d.ts

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# OS
Thumbs.db
.DS_Store

# Logs
logs
*.log

# Temporary files
temp_*
KakaoTalk_*
`;
      fs.writeFileSync(gitignorePath, gitignoreContent, 'utf-8');
    }

    console.log('\n✅ OEM 템플릿이 생성되었습니다!');
    console.log(`   위치: ${targetDir}`);
    console.log('\n📝 다음 단계:');
    console.log(`   1. cd "${targetDir}"`);
    console.log('   2. npm install');
    console.log('   3. .env 파일 생성 및 DATABASE_URL 설정');
    console.log('   4. npx prisma db push');
    console.log('   5. npm run dev');
    console.log('\n📖 자세한 가이드는 OEM_GUIDE.md 파일을 참고하세요.');
  } catch (error) {
    console.error('\n❌ 오류 발생:', error);
    process.exit(1);
  } finally {
    rl.close();
  }
}

function copyDirectory(src: string, dest: string, ignoreList: string[] = []) {
  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }

  const entries = fs.readdirSync(src, { withFileTypes: true });

  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);

    // 무시할 항목 체크
    if (ignoreList.some(pattern => {
      if (pattern.includes('*')) {
        const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
        return regex.test(entry.name);
      }
      return entry.name === pattern;
    })) {
      continue;
    }

    if (entry.isDirectory()) {
      copyDirectory(srcPath, destPath, ignoreList);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

function replaceInFiles(
  dir: string,
  replacements: Record<string, string>,
  fileExtensions: string[] = ['.ts', '.tsx', '.js', '.jsx', '.json', '.md', '.html', '.css', '.prisma', '.txt']
) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);

    // .git 디렉토리 무시
    if (entry.name === '.git' || entry.name === 'node_modules') {
      continue;
    }

    if (entry.isDirectory()) {
      replaceInFiles(fullPath, replacements, fileExtensions);
    } else {
      const ext = path.extname(entry.name);
      if (fileExtensions.includes(ext) || fileExtensions.length === 0) {
        try {
          let content = fs.readFileSync(fullPath, 'utf-8');
          let modified = false;

          for (const [search, replace] of Object.entries(replacements)) {
            if (content.includes(search)) {
              content = content.replace(new RegExp(search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), replace);
              modified = true;
            }
          }

          if (modified) {
            fs.writeFileSync(fullPath, content, 'utf-8');
          }
        } catch (error) {
          // 바이너리 파일 등은 무시
        }
      }
    }
  }
}

function formatSupply(supply: string): string {
  const num = parseInt(supply);
  if (num >= 100000000) {
    return `${(num / 100000000).toFixed(0)}억개`;
  } else if (num >= 10000) {
    return `${(num / 10000).toFixed(0)}만개`;
  }
  return `${num.toLocaleString()}개`;
}

main();

