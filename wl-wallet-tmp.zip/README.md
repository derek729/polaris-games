# White-label Mining Wallet (Polaris OEM Edition)

> 화이트라벨 마이닝 지갑 플랫폼 — 소스 코드 판매 패키지
> White-label Mining Wallet Platform — Source Code Package

---

## 한국어

### 개요

본 패키지는 Next.js 기반의 마이닝 지갑 플랫폼 전체 소스 코드입니다. 하나의 코드베이스에서
웹(Next.js App Router)과 모바일(Capacitor Android)을 모두 지원하며, 내장 OEM 생성기로
고객사 브랜드의 지갑을 상품명·심볼·총 발행량만 바꿔 신속하게 납품할 수 있습니다.

### 주요 기능

- **마이닝 / 스테이킹 지갑** — 코인 지갑, 전송, 거래내역, 마이닝·스테이킹
- **투자 상품 · 리워드 시스템** — 투자 티어별 데일리 리워드, 추천·매칭·리더십 보너스, 랭크 시스템, 잭팟
- **게임 통합** — HTML5 게임 다수 (Baccarat, Blackjack, Lotto, Roulette, Neon Slot, Spin 등) 및 게임 수익 정산
- **관리자 대시보드** — 회원·투자·정산·게임 통계 관리 (2FA 인증 지원)
- **Swagger API 문서** — OpenAPI 스펙: `/api/docs`, Swagger UI: `/api-docs`
- **다국어** — 한국어 / English / 日本語 / Tiếng Việt
- **모바일 (Capacitor)** — Android 프로젝트 내장 (`android/`), `npx cap sync`로 웹 에셋 동기화
- **OEM 생성기** — 상호명·심볼·총 발행량 입력 시 브랜딩이 교체된 신규 프로젝트 자동 생성

### 기술 스택

| 구분 | 내용 |
|---|---|
| Framework | Next.js (App Router) + React 19 |
| DB / ORM | PostgreSQL + Prisma |
| API | Next.js API Routes (+ OpenAPI/Swagger 문서화) |
| UI | Tailwind CSS |
| 인증 | JWT + 2FA (TOTP) |
| 모바일 | Capacitor 6 (Android) |
| Runtime | Node.js 22.12 이상 |

### 디렉터리 구성

```
white-label-wallet/
├─ wallet-source/              # 플랫폼 전체 소스 (Next.js + Prisma + Capacitor)
│  ├─ src/                     # 앱 소스 (app/, components/, services/, lib/)
│  ├─ prisma/                  # schema.prisma, seed.ts (데모 시드)
│  ├─ scripts/                 # 운영·설정 스크립트 (OEM 생성기 포함)
│  ├─ android/                 # Capacitor Android 프로젝트
│  ├─ public/                  # 웹 에셋, HTML5 게임, PWA manifest
│  └─ docs/                    # API · 관리자/사용자 매뉴얼 · 문제해결 문서
├─ tools/create-oem-template.ts  # OEM 생성기 단독 사본 (독립 실행용)
├─ README.md                   # 본 문서
├─ INSTALL-KO.md               # 한국어 설치 가이드
└─ LICENSE.txt                 # 폴라리스 EULA
```

### 빠른 시작 (요약)

```bash
cd wallet-source
npm install
cp .env.example .env          # DATABASE_URL, JWT_SECRET 등 설정
npx prisma db push
npm run dev                   # http://localhost:3009
```

자세한 설치 과정은 **INSTALL-KO.md**를 참고하세요.

### OEM 생성기 사용법

플랫폼에는 다른 회사(고객사)에 납품 가능한 화이트라벨 사본을 만들어 주는 생성기가 포함되어 있습니다.

```bash
cd wallet-source
npm run create-oem
# 또는 단독 실행:
npx tsx ../tools/create-oem-template.ts
```

실행하면 다음을 대화형으로 입력받습니다:

1. **상호명** (예: `ABC Coin Foundation`)
2. **코인 심볼** (예: `ABC`)
3. **총 발행량** (예: `1000000000`)

생성기는 소스를 새 디렉터리로 복사한 뒤 브랜딩 문자열을 일괄 교체하고,
`OEM_CONFIG.json`(OEM 메타정보)과 `OEM_GUIDE.md`(납품용 가이드)를 자동 생성합니다.
기본 출력 경로는 Windows 기준(`D:\OEM\new\<프로젝트명>`)이므로, 필요 시 스크립트 상단의
`targetDir`을 환경에 맞게 수정하세요.

추가 브랜딩 포인트 (수동 변경):

- `capacitor.config.ts` — `appId`, `appName`, `server.url`
- `public/manifest.json` — PWA 앱 이름
- `src/components/CompanyBrand.tsx` 등 브랜딩 컴포넌트
- `tailwind.config.js` — 색상 테마

### 데모 계정 (시드 데이터)

```bash
npx prisma db seed
```

- 슈퍼관리자: `admin` / `admin@upcwallet.com` / 비밀번호 `admin123`
- 테스트 유저: `GrandMaster`, `MiddleBoss`, `Newbie` / 비밀번호 `password123`

> ⚠️ 데모용 비밀번호이므로 실제 운영 전 반드시 변경하세요.

### 문서

| 문서 | 내용 |
|---|---|
| `INSTALL-KO.md` | 설치 가이드 (한국어) |
| `wallet-source/docs/API.md` | API 개요 |
| `/api-docs` (실행 후) | Swagger UI |
| `wallet-source/docs/ADMIN_MANUAL.md` | 관리자 매뉴얼 |
| `wallet-source/docs/USER_MANUAL.md` | 사용자 매뉴얼 |
| `wallet-source/docs/TROUBLESHOOTING.md` | 문제해결 |
| `wallet-source/FEATURE_GUIDE.md` | 기능 안내 |
| `wallet-source/CAPACITOR_GUIDE.md` · `APK_BUILD_GUIDE.md` | 모바일 빌드 |
| `wallet-source/OEM_GUIDE.md` | OEM 개요 |

### 보안 안내

- 배포 전 `.env`의 `JWT_SECRET`, `SESSION_SECRET`을 반드시 강한 값으로 교체하세요.
- 본 패키지는 원본에서 운영 DB 자격증명·내부 문서·개발용 테스트 엔드포인트를 제거(스크럽)한
  판매용 사본입니다. 그래도 운영 전 시크릿 스캔을 다시 수행하는 것을 권장합니다.
- `APP_MODE=foundation`(기본값)에서는 채굴·스테이킹 등 일반 기능이 비활성화되고,
  `APP_MODE=operation` + `ENABLE_REWARD_SCHEDULER=true`에서 전체 기능이 활성화됩니다.

### 라이선스

본 소프트웨어는 폴라리스 소프트웨어 라이선스 계약(EULA)에 따라 제공됩니다. 전체 내용은
`LICENSE.txt`를 참고하세요. (Personal / Commercial / Extended 3종, 재판매·재배포 제한)

---

## English

### Overview

A complete mining-wallet platform source code built on Next.js. One codebase powers both
web (Next.js App Router) and mobile (Capacitor Android), and the bundled OEM generator lets
you rebrand and deliver a client-specific wallet in minutes — just change the company name,
symbol, and total supply.

### Key Features

- **Mining / staking wallet** — balances, transfers, transaction history, mining and staking
- **Investment & rewards** — tiered daily rewards, referral / matching / leadership bonuses, rank system, jackpot
- **Games** — bundled HTML5 games (Baccarat, Blackjack, Lotto, Roulette, Neon Slot, Spin) with revenue settlement
- **Admin dashboard** — member, investment, settlement and game statistics, with 2FA
- **Swagger API docs** — OpenAPI spec at `/api/docs`, Swagger UI at `/api-docs`
- **i18n** — Korean / English / Japanese / Vietnamese
- **Mobile (Capacitor)** — Android project included (`android/`), sync with `npx cap sync`
- **OEM generator** — interactive tool that produces a rebranded copy of the whole platform

### Tech Stack

Next.js (App Router) · React 19 · PostgreSQL · Prisma · Tailwind CSS · JWT + TOTP 2FA · Capacitor 6 · Node.js >= 22.12

### Quick Start

```bash
cd wallet-source
npm install
cp .env.example .env          # set DATABASE_URL, JWT_SECRET, ...
npx prisma db push
npm run dev                   # http://localhost:3009
```

### OEM Generator

```bash
cd wallet-source
npm run create-oem            # or: npx tsx ../tools/create-oem-template.ts
```

Enter the client's company name, coin symbol and total supply; the tool copies the source
tree, replaces branding strings, and writes `OEM_CONFIG.json` + `OEM_GUIDE.md` into the new
project. Adjust `targetDir` in the script for non-Windows paths.

### Documentation & Support

See `INSTALL-KO.md` (Korean install guide), `wallet-source/docs/` for API, admin/user
manuals and troubleshooting, and the Swagger UI at `/api-docs` once the server is running.

### License

This software is licensed under the Polaris Software EULA — see `LICENSE.txt`.
(Personal / Commercial / Extended licenses; redistribution and resale restrictions apply.)
